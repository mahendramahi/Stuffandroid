package com.twc.dailylog.model.beans;


/**
 * Created by PalakC on 7/6/2016.
 */
public class ExerciseItem {

    private int ExerciseID;
    private double ActivityCalorie;
    private String ActivityName;

    public int getExerciseID() {
        return ExerciseID;
    }

    public void setExerciseID(int ExerciseID) {
        this.ExerciseID = ExerciseID;
    }

    public double getActivityCalorie() {
        return ActivityCalorie;
    }

    public void setActivityCalorie(double ActivityCalorie) {
        this.ActivityCalorie = ActivityCalorie;
    }

    public String getActivityName() {
        return ActivityName;
    }

    public void setActivityName(String ActivityName) {
        this.ActivityName = ActivityName;
    }
}
