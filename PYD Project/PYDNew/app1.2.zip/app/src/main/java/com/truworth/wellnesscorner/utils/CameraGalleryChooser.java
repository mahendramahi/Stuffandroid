package com.truworth.wellnesscorner.utils;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.support.design.widget.BottomSheetDialog;
import android.support.v4.app.FragmentActivity;
import android.view.View;
import android.widget.LinearLayout;

import com.truworth.wellnesscorner.R;
import com.truworth.wellnesscorner.ui.mainapp.createpost.CreatePostActivity;

public class CameraGalleryChooser {


    public static void selectImageProfile(FragmentActivity activity, CameraGalleryUtil cameraGalleryUtil) {
        final CharSequence[] items = {"Take Photo", "Choose from Library", "Cancel"};
        AlertDialog.Builder builder = new AlertDialog.Builder(activity);
        builder.setTitle("Change Profile Picture!");
        builder.setItems(items, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int item) {
                //  boolean result=Utils.checkPermission(getActivity());
                if (items[item].equals("Take Photo")) {
                    Utils.checkForCameraPermissions(activity, cameraGalleryUtil);

                } else if (items[item].equals("Choose from Library")) {
                    Utils.checkForGalleryPermissions(activity, cameraGalleryUtil);

                } else if (items[item].equals("Cancel")) {
                    dialog.dismiss();
                }

            }
        });
        builder.show();
    }



    public static void selectImageForPost(CreatePostActivity activity, CameraGalleryUtil cameraGalleryUtil) {
        final CharSequence[] items = {"Take Photo", "Choose from Library", "Cancel"};
        AlertDialog.Builder builder = new AlertDialog.Builder(activity);
        builder.setTitle("Add Photo/ Video");
        builder.setItems(items, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int item) {
                if (items[item].equals("Take Photo")) {

                    View view = activity.getLayoutInflater().inflate(R.layout.bottomsheet_camera_image_chooser, null);

                    BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(activity);
                    bottomSheetDialog.setContentView(view);
                    LinearLayout llCamera = view.findViewById(R.id.llCamera);
                    LinearLayout llCamcorder = view.findViewById(R.id.llCamcorder);
                    llCamera.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            bottomSheetDialog.dismiss();
                            Utils.checkForCameraPermissions(activity, cameraGalleryUtil);
                        }
                    });
                    llCamcorder.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            bottomSheetDialog.dismiss();
                            Utils.checkForCamCoderPermissions(activity, cameraGalleryUtil);
                        }
                    });

                    bottomSheetDialog.show();
                } else if (items[item].equals("Choose from Library")) {
                    Utils.checkForGalleryVideoPermissions(activity, cameraGalleryUtil);

                } else if (items[item].equals("Cancel")) {
                    dialog.dismiss();
                }

            }
        });
        builder.show();
    }
}
