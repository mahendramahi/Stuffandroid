package com.twc.store.model.requestbody;

/**
 * Created by GurvinderS on 9/19/2017.
 */

public class StoreUpdateOrderBody {


    /**
     * CartIds : 10
     * OrderID : 184
     * MemberId : 240095
     * TransactionId : 123
     * TransactionDetail : test
     * Status : Success
     */

    private String CartIds;
    private int OrderID;
    private String MemberId;
    private String TransactionId;
    private String TransactionDetail;
    private String Status;

    public String getCartIds() {
        return CartIds;
    }

    public void setCartIds(String CartIds) {
        this.CartIds = CartIds;
    }

    public int getOrderID() {
        return OrderID;
    }

    public void setOrderID(int OrderID) {
        this.OrderID = OrderID;
    }

    public String getMemberId() {
        return MemberId;
    }

    public void setMemberId(String MemberId) {
        this.MemberId = MemberId;
    }

    public String getTransactionId() {
        return TransactionId;
    }

    public void setTransactionId(String TransactionId) {
        this.TransactionId = TransactionId;
    }

    public String getTransactionDetail() {
        return TransactionDetail;
    }

    public void setTransactionDetail(String TransactionDetail) {
        this.TransactionDetail = TransactionDetail;
    }

    public String getStatus() {
        return Status;
    }

    public void setStatus(String Status) {
        this.Status = Status;
    }
}
