package com.truworth.wellnesscorner.repo.model.request;

import java.util.List;

/**
 * Created by PalakC on 4/11/2018.
 */

public class SaveMemberHealthGoalsRequest {

    private List<Integer> HealthGoalIds;

    public List<Integer> getHealthGoalIds() {
        return HealthGoalIds;
    }

    public void setHealthGoalIds(List<Integer> HealthGoalIds) {
        this.HealthGoalIds = HealthGoalIds;
    }
}
