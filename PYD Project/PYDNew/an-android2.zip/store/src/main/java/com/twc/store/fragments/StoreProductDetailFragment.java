package com.twc.store.fragments;

import android.app.Fragment;
import android.graphics.Paint;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.CardView;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.RelativeLayout;
import android.widget.TextView;


import com.twc.store.R;
import com.twc.store.R2;
import com.twc.store.StoreActivity;
import com.twc.store.StoreCategoryActivity;
import com.twc.store.StoreDetailActivity;
import com.twc.store.adapter.WellnessPlansPagerAdapter;
import com.twc.store.dialog.ApiErrorDialog;
import com.twc.store.dialog.NetworkErrorDialog;
import com.twc.store.dialog.StoreCartDialog;
import com.twc.store.interfaces.OnRetryAfterNetworkError;
import com.twc.store.model.beans.ProductItem;
import com.twc.store.model.requestbody.BaseMemberIdBody;
import com.twc.store.model.requestbody.SaveMemberBillingDetailsBody;
import com.twc.store.model.requestbody.StoreProductDetailBody;
import com.twc.store.model.requestbody.StoreSaveCartRequestBody;
import com.twc.store.model.response.StoreCartCountResponse;
import com.twc.store.model.response.StoreProductDetailResponse;
import com.twc.store.model.response.StoreSaveCartResponse;
import com.twc.store.rest.RestClient;
import com.twc.store.utils.Constant;
import com.twc.store.utils.DialogFactory;
import com.twc.store.utils.NetworkFactory;
import com.twc.store.utils.StoreConfig;
import com.twc.store.utils.Utils;
import com.twc.store.views.CirclePageIndicator;
import com.twc.store.views.CustomProgressDialog;

import java.util.List;
import java.util.Locale;

import butterknife.BindView;
import butterknife.OnClick;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by GurvinderS on 5/4/2017.
 */

public class StoreProductDetailFragment extends BaseFragment implements OnRetryAfterNetworkError {
    private static final String BUNDLE_KEY_TITLE = "TITLE";
    @BindView(R2.id.pagerProducts)
    ViewPager pagerProducts;
    @BindView(R2.id.ivAddQuantity)
    ImageView ivAddQuantity;
    @BindView(R2.id.ivSubtractQuantity)
    ImageView ivSubtractQuantity;
    @BindView(R2.id.tvInStock)
    TextView tvInStock;
    @BindView(R2.id.tvQuantity)
    TextView tvQuantity;
    @BindView(R2.id.ratingBar)
    RatingBar ratingBar;
    @BindView(R2.id.ivProductDescription)
    ImageView ivProductDescription;
    @BindView(R2.id.ivProductReviews)
    ImageView ivProductReviews;
    @BindView(R2.id.tvProductTitle)
    TextView tvProductTitle;
    @BindView(R2.id.tvRating)
    TextView tvRating;
    @BindView(R2.id.tvProductDescription)
    TextView tvProductDescription;
    @BindView(R2.id.llReviews)
    LinearLayout llReviews;
    @BindView(R2.id.pageIndicator)
    CirclePageIndicator pageIndicator;
    @BindView(R2.id.tvPrice)
    TextView tvPrice;
    @BindView(R2.id.tvYouSave)
    TextView tvYouSave;
    @BindView(R2.id.tvSavePrice)
    TextView tvSavePrice;
    @BindView(R2.id.tvSymbolRupeeSmall)
    TextView tvSymbolRupeeSmall;
    @BindView(R2.id.tvSpecialPrice)
    TextView tvSpecialPrice;
    @BindView(R2.id.cvBuyNow)
    CardView cvBuyNow;
    @BindView(R2.id.llAddQuantity)
    LinearLayout llAddQuantity;

    @BindView(R2.id.tvVendorName)
    TextView tvVendorName;


    @BindView(R2.id.rlRating)
    RelativeLayout rlRating;

    @BindView(R2.id.llRupees)
    LinearLayout llRupees;

    @BindView(R2.id.tvBestPrice)
    TextView tvBestPrice;


    private int quantity = 1;
    private TextView tvBadge;
    private int productId;
    private CustomProgressDialog customProgressDialog;
    private String fromFragment;
    private ProductItem productItemMain;

    private String sku;
    private double texAmount;
    private String categoryId, image;
    private Button notificationButton;
    private ImageView imgpendingFriend;
    private int cartItemCount;
    private SaveMemberBillingDetailsBody memberBillingDetails;


    public static StoreProductDetailFragment newInstance(int productId, String sku, String fromFragment) {
        Bundle args = new Bundle();
        args.putInt("ProductId", productId);
        args.putString("sku", sku);
        args.putString("FromFragment", fromFragment);
        StoreProductDetailFragment fragment = new StoreProductDetailFragment();
        fragment.setArguments(args);
        return fragment;
    }

    private static void replaceFragment(android.app.FragmentManager fragmentManager, Fragment fragment, String tag, boolean addTobackStack, int container) {
        android.app.FragmentTransaction ft = fragmentManager.beginTransaction();
        ft.setCustomAnimations(R.animator.enter, R.animator.exit, R.animator.pop_enter, R.animator.pop_exit);
        if (addTobackStack) {
            ft.addToBackStack(tag);
        }
        ft.replace(container, fragment, tag);
        ft.commit();
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
        if (getArguments() != null) {
            if (getArguments().containsKey("ProductId")) {
                productId = getArguments().getInt("ProductId");
                fromFragment = getArguments().getString("FromFragment");
                sku = getArguments().getString("sku");
            }
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        if (getActivity() instanceof StoreActivity) {
            ((StoreActivity) getActivity()).setToolBarTitle("");
            ((StoreActivity) getActivity()).showHomeAsUpEnableToolbar();
        }else if(getActivity() instanceof StoreDetailActivity){
            ((StoreDetailActivity) getActivity()).setToolBarTitle("");
            ((StoreDetailActivity) getActivity()).showHomeAsUpEnableToolbar();
        }else if(getActivity() instanceof StoreCategoryActivity){
            ((StoreCategoryActivity) getActivity()).setToolBarTitle("");
            ((StoreCategoryActivity) getActivity()).showHomeAsUpEnableToolbar();
        }
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        inflater.inflate(R.menu.menu_save, menu);
        MenuItem menuItemRefresh = menu.findItem(R.id.action_save);

        menuItemRefresh = menuItemRefresh.setActionView(R.layout.pending_request_count);
        menuItemRefresh.setTitle("Notification");

        View view = menuItemRefresh.getActionView();
        RelativeLayout rlayout = view.findViewById(R.id.rlayout);
        notificationButton = view.findViewById(R.id.notif_count);
        imgpendingFriend = view.findViewById(R.id.imgpendingFriend);
        imgpendingFriend.setImageResource(R.drawable.ic_store_cartcount);

        notificationButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Utils.replaceFragment(getFragmentManager(), StoreMyCartFragment.newInstance(), StoreMyCartFragment.class.getSimpleName(), true, R.id.fragmentContainer);
            }
        });
        imgpendingFriend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Utils.replaceFragment(getFragmentManager(), StoreMyCartFragment.newInstance(), StoreMyCartFragment.class.getSimpleName(), true, R.id.fragmentContainer);
            }
        });

    }

    @Override
    public int getFragmentLayout() {
        return R.layout.fragment_store_product_detail;
    }

    @Override
    public void onFragmentReady() {
        new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        getCartCountApiCall();
                    }
                },50);


        if (fromFragment != null) {
            if (fromFragment.equalsIgnoreCase(Constant.WELLNESS_PLAN)) {
                llAddQuantity.setVisibility(View.INVISIBLE);
            }
        }
        if (productItemMain == null) {
            getProductDetailById();
        } else {
            tvQuantity.setText(String.format(Locale.getDefault(), "%d", quantity));
            setUIData(productItemMain);

        }
    }

    private void getProductDetailById() {
        if (NetworkFactory.getInstance().isNetworkAvailable(getActivity())) {
            customProgressDialog = new CustomProgressDialog(getActivity(), R.style.custom_progress_style, true);
            customProgressDialog.setCancelable(false);
            customProgressDialog.show();

            final StoreProductDetailBody storeProductDetailBody = new StoreProductDetailBody();
            if (fromFragment.equalsIgnoreCase(Constant.WELLNESS_PLAN)) {
                storeProductDetailBody.setProductId(productId);
                storeProductDetailBody.setSku("");
                storeProductDetailBody.setMemberID(StoreConfig.storeUser.getMemberId());

            } else {
                storeProductDetailBody.setProductId(0);
                storeProductDetailBody.setSku(String.valueOf(productId));
                storeProductDetailBody.setMemberID(StoreConfig.storeUser.getMemberId());
            }
            RestClient restClient = new RestClient(getActivity(), StoreConfig.BASE_URL, StoreConfig.mdebug);

            restClient.getWellnessStoreService().getProductDetail(storeProductDetailBody).enqueue(new Callback<StoreProductDetailResponse>() {
                @Override
                public void onResponse(Call<StoreProductDetailResponse> call, Response<StoreProductDetailResponse> response) {
                    if (getActivity() != null && isAdded()) {
                        if (customProgressDialog != null) {
                            customProgressDialog.dismiss();
                        }
                        if (response != null && response.body() != null) {
                            if (response.body().getStatus() == 0 && response.body().getData() != null && response.body().getData().getProducts() != null) {

                                productItemMain = response.body().getData().getProducts();
                                memberBillingDetails = response.body().getData().getMemberBillingDetails();
                                setUIData(productItemMain);


                            } else if (response.body().getStatus() == -1) {
                                // DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_response_failure), getString(R.string.str_ok), false);
                                showApiErrorDialog();
                            }
                        } else {
                            //DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_response_null), getString(R.string.str_ok), false);
                            showApiErrorDialog();
                        }
                    }
                }

                @Override
                public void onFailure(Call<StoreProductDetailResponse> call, Throwable t) {
                    if (getActivity() != null && isAdded()) {
                        if (customProgressDialog != null) {
                            customProgressDialog.dismiss();
                        }
                        //DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_failure), getString(R.string.str_ok), false);
                        showApiErrorDialog();
                    }
                }
            });
        }
    }

    private void addImages(List<ProductItem.ImagesBean> imagesList) {
        WellnessPlansPagerAdapter wellnessPlansPagerAdapter = new WellnessPlansPagerAdapter(getActivity(), imagesList);
        pagerProducts.setAdapter(wellnessPlansPagerAdapter);
        pageIndicator.setViewPager(pagerProducts);
        image = imagesList.get(0).getUrl();
    }

    @OnClick(R2.id.ivAddQuantity)
    public void addQuantity() {
        quantity = quantity + 1;
        tvQuantity.setText(String.format(Locale.getDefault(), "%d", quantity));
    }

    @OnClick(R2.id.ivSubtractQuantity)
    public void subtractQuantity() {
        if (quantity > 1) {
            quantity = quantity - 1;
            tvQuantity.setText(String.format(Locale.getDefault(), "%d", quantity));
        }
    }

    @OnClick(R2.id.ivProductDescription)
    public void viewProductDescription() {
        if (tvProductDescription.getVisibility() == View.VISIBLE) {
            tvProductDescription.setVisibility(View.GONE);
            ivProductDescription.setImageDrawable(ContextCompat.getDrawable(getActivity(), R.drawable.arrow_down));
        } else {
            tvProductDescription.setVisibility(View.VISIBLE);
            ivProductDescription.setImageDrawable(ContextCompat.getDrawable(getActivity(), R.drawable.arrow_up));
        }
    }

    @OnClick(R2.id.ivProductReviews)
    public void viewProductReviews() {
        if (llReviews.getVisibility() == View.VISIBLE) {
            llReviews.setVisibility(View.GONE);
            ivProductReviews.setImageDrawable(ContextCompat.getDrawable(getActivity(), R.drawable.arrow_up));
        } else {
            llReviews.setVisibility(View.VISIBLE);
            ivProductReviews.setImageDrawable(ContextCompat.getDrawable(getActivity(), R.drawable.arrow_down));
        }
    }

    @OnClick(R2.id.cvBuyNow)
    public void clickBuyNow() {

        if (productItemMain != null) {
            if (fromFragment.equalsIgnoreCase(Constant.WELLNESS_PLAN)) {
                if (productItemMain.isIsPurchased()) {
                    DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, "You have already enrolled wellness plan before completing the wellness plan you cannot enroll in another or same program.", getString(R.string.str_ok), false);
                } else {
                    //showMemberBillingScreen();
                    saveCartApiCall();
                }

            } else {
                // checkProductAvailableAPI();
                saveCartApiCall();
            }
        }
    }

    private void saveCartApiCall() {
        customProgressDialog = new CustomProgressDialog(getActivity(), R.style.custom_progress_style, true);
        customProgressDialog.setCancelable(false);
        customProgressDialog.show();

        StoreSaveCartRequestBody saveCartRequestBody = new StoreSaveCartRequestBody();
        saveCartRequestBody.setMemberId(Integer.parseInt(StoreConfig.storeUser.getMemberId()));
        saveCartRequestBody.setProductCategoryId(Integer.parseInt(categoryId));
        saveCartRequestBody.setPrice(Double.parseDouble(tvPrice.getText().toString().replace(",", "")));
        saveCartRequestBody.setProductId(productId);
        saveCartRequestBody.setProductImage(image);
        saveCartRequestBody.setProductName(tvProductTitle.getText().toString());
        saveCartRequestBody.setQuantity(Integer.parseInt(tvQuantity.getText().toString()));
        saveCartRequestBody.setTaxAmount(texAmount);
        saveCartRequestBody.setProductVendorId(productItemMain.getVendorId());
        if (productItemMain.getSpecialPrice() > 0) {
            saveCartRequestBody.setPrice(productItemMain.getSpecialPrice());
        } else {
            saveCartRequestBody.setPrice(productItemMain.getPrice());
        }
        RestClient restClient = new RestClient(getActivity(), StoreConfig.BASE_URL, StoreConfig.mdebug);

        restClient.getStoreService().saveCart(saveCartRequestBody).enqueue(new Callback<StoreSaveCartResponse>() {
            @Override
            public void onResponse(Call<StoreSaveCartResponse> call, Response<StoreSaveCartResponse> response) {
                if (getActivity() != null && isAdded()) {
                    customProgressDialog.dismiss();
                    if (response != null && response.body() != null) {
                        if (response.body().getStatus() == 0 && response.body().getData() != null) {
                            if (response.body().getData().getSaveItems() != null) {
                                cartItemCount = response.body().getData().getSaveItems().getTotalItems();
                            }
                            displayCartItemCount();
                            //DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, response.body().getData().getMessage(), getString(R.string.str_ok), false);
                            StoreCartDialog storeCartDialog = new StoreCartDialog(getActivity(), getActivity());
                            storeCartDialog.show();
                            // Window window = storeCartDialog.getWindow();
                            //window.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT);

                            /* As per nikhil sir discuss dialog not show like web 19 sep 2107
                              DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, response.body().getData().getMessage(),"Proceed to cart", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    dialogInterface.cancel();
                                    Utils.replaceFragment(getFragmentManager(), StoreMyCartFragment.newInstance(), StoreMyCartFragment.class.getSimpleName(), true, R.id.fragmentContainer);

                                }
                            }, "Continue Shopping", false);*/
                        }

                    } else {
                        DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_response_null), getString(R.string.str_ok), false);
                    }
                }
            }

            @Override
            public void onFailure(Call<StoreSaveCartResponse> call, Throwable t) {
                if (getActivity() != null && isAdded()) {
                    customProgressDialog.dismiss();
                    DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_failure), getString(R.string.str_ok), false);
                }
            }
        });

    }


    private void setUIData(ProductItem productItem) {
        try {
            texAmount = productItem.getTaxAmount();
            categoryId = productItem.getCategoryId();

            rlRating.setVisibility(View.VISIBLE);
            llRupees.setVisibility(View.VISIBLE);

            tvProductTitle.setText(productItem.getName());
            tvProductDescription.setText(Utils.fromHtml(productItem.getDescription()));
            tvRating.setText(String.format("%s", productItem.getProductRating()));

            tvPrice.setText(Utils.getFormattedAmountManageZero(productItem.getPrice()));
            tvVendorName.setText(String.format("By %s", productItem.getVendorName()));
            if (!productItem.getInStock()) {
                tvInStock.setText("Out of Stock");
                cvBuyNow.setVisibility(View.GONE);
                tvInStock.setTextColor(ContextCompat.getColor(getActivity(), android.R.color.holo_red_light));
            } else {
                tvInStock.setText("IN STOCK");
            }

            if (productItem.getSpecialPrice() == 0.0) {
                tvSpecialPrice.setVisibility(View.GONE);
                tvSavePrice.setVisibility(View.GONE);
                tvYouSave.setVisibility(View.GONE);
                tvSymbolRupeeSmall.setVisibility(View.GONE);
                tvBestPrice.setVisibility(View.GONE);
            } else if (productItem.getPrice() != productItem.getSpecialPrice()) {
                // set special price in view tvPrice case when special price greater than 0 and set price in view tvSpecial Price
                tvBestPrice.setVisibility(View.VISIBLE);
                productItem.getSpecialFromDate();

                tvSpecialPrice.setVisibility(View.VISIBLE);
                tvSavePrice.setVisibility(View.VISIBLE);
                tvYouSave.setVisibility(View.VISIBLE);
                tvYouSave.setText("You save");
                tvSymbolRupeeSmall.setVisibility(View.VISIBLE);

                tvPrice.setText(Utils.getFormattedAmountManageZero(Double.valueOf(Utils.doubleToString(productItem.getSpecialPrice()))));

                tvSpecialPrice.setPaintFlags(tvSpecialPrice.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
                tvSpecialPrice.setText(Utils.getFormattedAmountManageZero(Double.valueOf(Utils.doubleToString(productItem.getPrice()))));
                double specialPrice = productItem.getSpecialPrice();
                double price = productItem.getPrice();
                double savePrice = price - specialPrice;
                tvSavePrice.setText(Utils.getFormattedAmountManageZero(Double.valueOf(Utils.doubleToString(savePrice))));
            }
            if (productItem.getImages() != null && productItem.getImages().size() > 0) {
                addImages(productItem.getImages());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private void displayCartItemCount() {
        notificationButton.setVisibility(View.GONE);
        imgpendingFriend.setVisibility(View.VISIBLE);

        if (cartItemCount > 0) {
            notificationButton.setVisibility(View.VISIBLE);
            if (cartItemCount > 99) {
                notificationButton.setText("99+");
            } else {
                notificationButton.setText(String.format(Locale.getDefault(), "%d", cartItemCount));
            }
        }
    }

    private void getCartCountApiCall() {
        if (NetworkFactory.getInstance().isNetworkAvailable(getActivity())) {
            //body
            BaseMemberIdBody baseMemberIdBody = new BaseMemberIdBody();
            baseMemberIdBody.setMemberID(StoreConfig.storeUser.getMemberId());
            RestClient restClient = new RestClient(getActivity(), StoreConfig.BASE_URL, StoreConfig.mdebug);

            restClient.getStoreService().getCartCount(baseMemberIdBody).enqueue(new Callback<StoreCartCountResponse>() {
                @Override
                public void onResponse(Call<StoreCartCountResponse> call, Response<StoreCartCountResponse> response) {

                    if (isAdded() && getActivity() != null) {
                        if (response != null && response.body() != null) {
                            if (response.body().getStatus() == 0) {
                                cartItemCount = response.body().getData();
                                displayCartItemCount();
                            } else {
                                // DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_response_failure), getString(R.string.str_ok), false);
                                showApiErrorDialog();
                            }
                        } else {
                            //DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_response_null), getString(R.string.str_ok), false);
                            showApiErrorDialog();
                        }
                    }
                }

                @Override
                public void onFailure(Call<StoreCartCountResponse> call, Throwable t) {
                    if (isAdded() && getActivity() != null) {
                        //DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_failure), getString(R.string.str_ok), false);
                        showApiErrorDialog();
                    }
                }
            });
        } else {
            // show Network Error Screen Dialog
            NetworkErrorDialog networkErrorDialog = new NetworkErrorDialog(getActivity(), getActivity(), StoreProductDetailFragment.this);
            networkErrorDialog.show();
            Window window = networkErrorDialog.getWindow();
            window.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);
        }
    }

    // method to show Api Error Screen Dialog
    private void showApiErrorDialog() {
        ApiErrorDialog apiErrorDialog = new ApiErrorDialog(getActivity(), getActivity(), StoreProductDetailFragment.this);
        apiErrorDialog.show();
        Window window = apiErrorDialog.getWindow();
        window.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);
    }


    @Override
    public void onRetry() {
        getCartCountApiCall();
        getProductDetailById();
    }
}
