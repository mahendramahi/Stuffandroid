package com.truworth.wellnesscorner.repo.model.response;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.truworth.wellnesscorner.model.PopularCircle;

import java.util.ArrayList;

/**
 * Created by rajeshs on 4/13/2018.
 */

public class PopularCircleResponse {

    @SerializedName("data")
    @Expose
    private ArrayList<PopularCircle> data;
    @SerializedName("hasError")
    @Expose
    private boolean hasError;


    public ArrayList<PopularCircle> getData() {
        return data;
    }

    public void setData(ArrayList<PopularCircle> data) {
        this.data = data;
    }

    public boolean isHasError() {
        return hasError;
    }

    public void setHasError(boolean hasError) {
        this.hasError = hasError;
    }

    public Error getError() {
        return error;
    }

    public void setError(Error error) {
        this.error = error;
    }

    @SerializedName("error")
    @Expose
    private Error error;

}
