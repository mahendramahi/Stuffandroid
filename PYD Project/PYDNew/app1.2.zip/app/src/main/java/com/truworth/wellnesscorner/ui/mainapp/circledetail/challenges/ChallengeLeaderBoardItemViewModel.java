package com.truworth.wellnesscorner.ui.mainapp.circledetail.challenges;

import android.content.Context;
import android.graphics.drawable.Drawable;

import com.truworth.wellnesscorner.R;
import com.truworth.wellnesscorner.base.BaseViewModel;
import com.truworth.wellnesscorner.model.ChallengeLeaderboardBean;
import com.truworth.wellnesscorner.utils.SingleLiveEvent;

public class ChallengeLeaderBoardItemViewModel extends BaseViewModel {

    ChallengeLeaderboardBean challengeLeaderboardBean;
    String challengeIdentity;
    private Context context;
    private int challengeTypeId;
    private int myRank;

    public ChallengeLeaderBoardItemViewModel(ChallengeLeaderboardBean challengeLeaderboardBean, String challengeIdentity, Context context, int challengeTypeId, int myRank) {
        this.challengeLeaderboardBean = challengeLeaderboardBean;
        this.challengeIdentity = challengeIdentity;
        this.context = context;
        this.challengeTypeId = challengeTypeId;
        this.myRank = myRank;
    }

    public ChallengeLeaderboardBean getChallengeLeaderboardBean() {
        return challengeLeaderboardBean;
    }

    public void setChallengeLeaderboardBean(ChallengeLeaderboardBean challengeLeaderboardBean) {
        this.challengeLeaderboardBean = challengeLeaderboardBean;
    }

    public boolean isSelfCheck(int rank){
        boolean isSelf = false;

        if(rank==myRank)
            isSelf=true;
        else
            isSelf=false;

        return isSelf;
    }

    public Drawable getRatingImage(int rank, int previousRank){
        Drawable image;
        if(rank<previousRank)
            image =  context.getResources().getDrawable(R.drawable.ic_up_icon);
        else if(rank==previousRank)
            image = context.getResources().getDrawable(R.drawable.ic_no_change_icon);
        else
            image = context.getResources().getDrawable(R.drawable.ic_icon_red_traingle);

        return image;
    }
    public String getTypeIdData(){
        String typeIdData = "";

        if(challengeTypeId==1)
            typeIdData = "steps";
        else  if(challengeTypeId==2)
            typeIdData = "check-in";

        return typeIdData;
    }

}
