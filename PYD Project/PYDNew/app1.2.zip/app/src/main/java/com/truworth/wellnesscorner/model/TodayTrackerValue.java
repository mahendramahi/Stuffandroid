package com.truworth.wellnesscorner.model;


import com.google.gson.JsonObject;

public class TodayTrackerValue {


    private String trackerName;

    public TrackerData getTrackerData() {
        return trackerData;
    }

    public void setTrackerData(TrackerData trackerData) {
        this.trackerData = trackerData;
    }

    private TrackerData trackerData;

    public String getTrackerName() {
        return trackerName;
    }

    public void setTrackerName(String trackerName) {
        this.trackerName = trackerName;
    }




}
