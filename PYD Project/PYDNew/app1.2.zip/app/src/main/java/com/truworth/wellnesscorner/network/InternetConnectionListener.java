package com.truworth.wellnesscorner.network;

public interface InternetConnectionListener {
    void onInternetUnavailable();
}