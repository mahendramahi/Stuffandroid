package com.truworth.wellnesscorner.model;

public class HabitStatus {

    private int completedHabits;
    private int totalHabits;
    private String habitReminderUpdateDate;

    public int getCompletedHabits() {
        return completedHabits;
    }

    public void setCompletedHabits(int completedHabits) {
        this.completedHabits = completedHabits;
    }

    public int getTotalHabits() {
        return totalHabits;
    }

    public void setTotalHabits(int totalHabits) {
        this.totalHabits = totalHabits;
    }

    public String getHabitReminderUpdateDate() {
        return habitReminderUpdateDate;
    }

    public void setHabitReminderUpdateDate(String habitReminderUpdateDate) {
        this.habitReminderUpdateDate = habitReminderUpdateDate;
    }
}
