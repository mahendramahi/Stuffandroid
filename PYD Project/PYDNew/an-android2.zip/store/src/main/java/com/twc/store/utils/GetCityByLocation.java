package com.twc.store.utils;

import android.app.Activity;
import android.app.Fragment;
import android.content.Context;
import android.content.IntentSender;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.BottomSheetDialog;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationSettingsRequest;
import com.google.android.gms.location.LocationSettingsResult;
import com.google.android.gms.location.LocationSettingsStates;
import com.google.android.gms.location.LocationSettingsStatusCodes;
import com.twc.store.dialog.LocationAccessDialog;
import com.twc.store.fragments.StoreMemberAddressFragment;
import com.twc.store.interfaces.OnCityFindListener;
import com.twc.store.interfaces.OnLocationAccess;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

/**
 * Created by GurvinderS on 3/17/2017.
 */

public class GetCityByLocation implements GoogleApiClient.ConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener, LocationListener,OnLocationAccess {
    private final int REQUEST_LOCATION = 200;
    private final int REQUEST_CHECK_SETTINGS = 300;
    private String LocationResult = null;
    private Fragment mFragment;
    private Activity mActivity;
    private OnCityFindListener onFindCityFindListener;
    private Location mLastLocation;
    private LocationRequest mLocationRequest;
    private GoogleApiClient mGoogleApiClient;
    private LocationSettingsRequest.Builder builder;
    private PendingResult<LocationSettingsResult> result;
    private PermissionHelper permissionHelper;
    private BottomSheetDialog dialog;
    private Status status;
    private LocationAccessDialog locationAccessDialog;

    public GetCityByLocation(Activity activity, PermissionHelper permissionHelper, Fragment fragment, OnCityFindListener onFindCityFindListener) {
        mActivity = activity;
        mFragment = fragment;
        this.permissionHelper = permissionHelper;
        this.onFindCityFindListener = onFindCityFindListener;
    }


    public void buildGoogleApiConnection() {
        buildGoogleApiClient();
        if (!mGoogleApiClient.isConnected()) {
            mGoogleApiClient.connect();
        }

    }

    @Override
    public void onConnected(@Nullable Bundle bundle) {
        builder = new LocationSettingsRequest.Builder().addLocationRequest(mLocationRequest);
        result = LocationServices.SettingsApi.checkLocationSettings(mGoogleApiClient, builder.build());
        result.setResultCallback(new ResultCallback<LocationSettingsResult>() {
            @Override
            public void onResult(LocationSettingsResult result) {
                 status = result.getStatus();
                final LocationSettingsStates mState = result.getLocationSettingsStates();
                switch (status.getStatusCode()) {

                    case LocationSettingsStatusCodes.SUCCESS:
                        permissionHelper.build();
                        break;
                    case LocationSettingsStatusCodes.RESOLUTION_REQUIRED:

                            try {
                                status.startResolutionForResult(mActivity, REQUEST_CHECK_SETTINGS);
                            } catch (IntentSender.SendIntentException e) {
                                e.printStackTrace();
                            }


                        break;
                    case LocationSettingsStatusCodes.SETTINGS_CHANGE_UNAVAILABLE:
                        break;
                }
            }
        });
    }


    @Override
    public void onConnectionSuspended(int i) {

    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

    }

    @Override
    public void onLocationChanged(Location location) {
        if (mLastLocation == null && location != null) {
            getAddressFromLocation(location, mActivity);
        }
        mLastLocation = location;
        LocationServices.FusedLocationApi.removeLocationUpdates(mGoogleApiClient, this);
    }

    private synchronized void buildGoogleApiClient() {
        if (mGoogleApiClient == null) {
            mGoogleApiClient = new GoogleApiClient.Builder(mActivity)
                    .addOnConnectionFailedListener(this)
                    .addConnectionCallbacks(this)
                    .addApi(LocationServices.API)
                    .build();
        }

        mLocationRequest = new LocationRequest();
        mLocationRequest.setInterval(5000);
        mLocationRequest.setFastestInterval(2000);
        mLocationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
    }


    @SuppressWarnings("MissingPermission")
    public void accessLocation() {

        mLastLocation = LocationServices.FusedLocationApi.getLastLocation(mGoogleApiClient);
        if (mLastLocation != null) {
            getAddressFromLocation(mLastLocation, mActivity);
        } else {
            LocationServices.FusedLocationApi.requestLocationUpdates(mGoogleApiClient, mLocationRequest, this);
        }
    }

    public void dismissDialog() {
        if (locationAccessDialog != null) {
            locationAccessDialog.dismiss();
        }
    }

    private void getAddressFromLocation(final Location location, final Context context) {
        Thread thread = new Thread() {
            @Override
            public void run() {
                Geocoder geocoder = new Geocoder(context, Locale.getDefault());

                try {
                    List<Address> list = geocoder.getFromLocation(location.getLatitude(), location.getLongitude(), 1);
                    if (list != null && list.size() > 0) {
                        Address address = list.get(0);

                        if (mFragment instanceof StoreMemberAddressFragment) {

                            LocationResult = address.getLocality() + "-" + address.getCountryName() + "-" + address.getPostalCode() + "-" + address.getAdminArea();
                        }  else {
                            LocationResult = address.getLocality();
                        }
                    }
                } catch (IOException ignored) {

                } finally {
                    mActivity.runOnUiThread(new Runnable() {
                        public void run() {
                            Message msg = Message.obtain();


                            msg.setTarget(new GeoCoderHandler());
                            if (result != null) {
                                msg.what = 1;
                                Bundle bundle = new Bundle();
                                bundle.putString("address", LocationResult);
                                msg.setData(bundle);
                            } else {
                                msg.what = 0;
                            }
                            msg.sendToTarget();
                        }
                    });
                }
            }
        };
        thread.start();
    }

    public Location getCurrentLocation() {
        return mLastLocation;
    }

    public GoogleApiClient getGoogleApiClientInstance() {
        return mGoogleApiClient;
    }



    private class GeoCoderHandler extends Handler {
        @Override
        public void handleMessage(Message message) {
            String result;
            switch (message.what) {
                case 1:
                    Bundle bundle = message.getData();
                    result = bundle.getString("address");
                    break;
                default:
                    result = null;
            }


            onFindCityFindListener.onCityFound(result);

        }
    }

    @Override
    public void onAccess() {
        try {

            status.startResolutionForResult(mActivity, REQUEST_CHECK_SETTINGS);
        } catch (IntentSender.SendIntentException e) {
            e.printStackTrace();
        }
    }
}
