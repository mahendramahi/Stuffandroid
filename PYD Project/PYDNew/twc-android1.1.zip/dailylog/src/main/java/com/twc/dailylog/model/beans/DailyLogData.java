package com.twc.dailylog.model.beans;

/**
 * Created by PankajS on 8/5/2016.
 */
public class DailyLogData
{
    private double MemberTargetCalories;
    private double MemberTargetBurned;
    private double MemberTotalTargetCal;
    private double TotalCaloriesConsumed;
    private double TotalCaloriesBurned;
    private double TotalFatConsumed;
    private double TotalProteinConsumed;
    private double TotalCarbsConsumed;
    private double MemberTargetFat;
    private double MemberTargetProtein;
    private double MemberTargetCarbs;
    private double Difference;
    private int Percentage;
    private String OverUnder;
    private int WaterIntake;
    private int TodayStep;
    private String LastStepSyncDate;
    private String LastConnectedDevice;
    private String FirstStepSyncDate;
    private String LastStepUpdatedDate;

    public String getLastStepSyncDate() {
        return LastStepSyncDate;
    }

    public void setLastStepSyncDate(String lastStepSyncDate) {
        LastStepSyncDate = lastStepSyncDate;
    }

    public String getLastConnectedDevice() {
        return LastConnectedDevice;
    }

    public void setLastConnectedDevice(String lastConnectedDevice) {
        LastConnectedDevice = lastConnectedDevice;
    }

    public String getFirstStepSyncDate() {
        return FirstStepSyncDate;
    }

    public void setFirstStepSyncDate(String firstStepSyncDate) {
        FirstStepSyncDate = firstStepSyncDate;
    }

    public double getMemberTargetCalories() {
        return MemberTargetCalories;
    }

    public void setMemberTargetCalories(double MemberTargetCalories) {
        this.MemberTargetCalories = MemberTargetCalories;
    }

    public double getMemberTargetBurned() {
        return MemberTargetBurned;
    }

    public void setMemberTargetBurned(double MemberTargetBurned) {
        this.MemberTargetBurned = MemberTargetBurned;
    }

    public double getMemberTotalTargetCal() {
        return MemberTotalTargetCal;
    }

    public void setMemberTotalTargetCal(double MemberTotalTargetCal) {
        this.MemberTotalTargetCal = MemberTotalTargetCal;
    }

    public double getTotalCaloriesConsumed() {
        return TotalCaloriesConsumed;
    }

    public void setTotalCaloriesConsumed(double TotalCaloriesConsumed) {
        this.TotalCaloriesConsumed = TotalCaloriesConsumed;
    }

    public double getTotalCaloriesBurned() {
        return TotalCaloriesBurned;
    }

    public void setTotalCaloriesBurned(double TotalCaloriesBurned) {
        this.TotalCaloriesBurned = TotalCaloriesBurned;
    }

    public double getTotalFatConsumed() {
        return TotalFatConsumed;
    }

    public void setTotalFatConsumed(double TotalFatConsumed) {
        this.TotalFatConsumed = TotalFatConsumed;
    }

    public double getTotalProteinConsumed() {
        return TotalProteinConsumed;
    }

    public void setTotalProteinConsumed(double TotalProteinConsumed) {
        this.TotalProteinConsumed = TotalProteinConsumed;
    }

    public double getTotalCarbsConsumed() {
        return TotalCarbsConsumed;
    }

    public void setTotalCarbsConsumed(double TotalCarbsConsumed) {
        this.TotalCarbsConsumed = TotalCarbsConsumed;
    }

    public double getMemberTargetFat() {
        return MemberTargetFat;
    }

    public void setMemberTargetFat(double MemberTargetFat) {
        this.MemberTargetFat = MemberTargetFat;
    }

    public double getMemberTargetProtein() {
        return MemberTargetProtein;
    }

    public void setMemberTargetProtein(double MemberTargetProtein) {
        this.MemberTargetProtein = MemberTargetProtein;
    }

    public double getMemberTargetCarbs() {
        return MemberTargetCarbs;
    }

    public void setMemberTargetCarbs(double MemberTargetCarbs) {
        this.MemberTargetCarbs = MemberTargetCarbs;
    }

    public int getPercentage() {
        return Percentage;
    }

    public void setPercentage(int percentage) {
        Percentage = percentage;
    }

    public double getDifference() {
        return Difference;
    }

    public void setDifference(double difference) {
        Difference = difference;
    }

    public String getOverUnder() {
        return OverUnder;
    }

    public void setOverUnder(String overUnder) {
        OverUnder = overUnder;
    }

    public int getWaterIntake() {
        return WaterIntake;
    }

    public void setWaterIntake(int waterIntake) {
        WaterIntake = waterIntake;
    }

    public int getTodayStep() {
        return TodayStep;
    }

    public void setTodayStep(int todayStep) {
        TodayStep = todayStep;
    }

    public String getLastStepUpdatedDate() {
        return LastStepUpdatedDate;
    }

    public void setLastStepUpdatedDate(String lastStepUpdatedDate) {
        LastStepUpdatedDate = lastStepUpdatedDate;
    }
}
