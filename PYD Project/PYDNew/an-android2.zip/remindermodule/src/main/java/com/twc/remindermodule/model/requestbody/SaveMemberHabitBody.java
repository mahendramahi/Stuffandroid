package com.twc.remindermodule.model.requestbody;

/**
 * Created by richas on 9/21/2017.
 */

public class SaveMemberHabitBody {

    private String habitIDs;
    private int MemberId;

    public String getHabitIDs() {
        return habitIDs;
    }

    public void setHabitIDs(String habitIDs) {
        this.habitIDs = habitIDs;
    }

    public int getMemberId() {
        return MemberId;
    }

    public void setMemberId(int MemberId) {
        this.MemberId = MemberId;
    }
}
