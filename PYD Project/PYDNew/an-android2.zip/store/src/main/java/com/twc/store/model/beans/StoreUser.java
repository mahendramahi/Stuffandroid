package com.twc.store.model.beans;

/**
 * Created by GurvinderS on 3/27/2018.
 */

public class StoreUser {
    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    private String phone;
    private String email;

    private String memberId;
    private String gender;
    private String userType;
    private String accessToken;

    public StoreUser(String nm, String phn, String eml, String memberid, String gender, String userType, String s1) {
       this.name=nm;
       this.phone=phn;
       this.email=eml;


        this.memberId = memberid;
        this.gender = gender;
        this.userType = userType;
        this.accessToken = s1;

    }

    public String getMemberId() {
        return memberId;
    }

    public void setMemberId(String memberId) {
        this.memberId = memberId;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getUserType() {
        return userType;
    }

    public void setUserType(String userType) {
        this.userType = userType;
    }

    public String getAccessToken() {
        return accessToken;
    }

    public void setAccessToken(String accessToken) {
        this.accessToken = accessToken;
    }


}
