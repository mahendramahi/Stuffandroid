package com.twc.remindermodule.model.response;

/**
 * Created by GurvinderS on 9/21/2017.
 */

public class SaveHabitReminderResponse {


    /**
     * status : 0
     * Data : {"LastUpdateDate":"2017-09-25T16:04:10"}
     */

    private int status;
    private DataBean Data;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public DataBean getData() {
        return Data;
    }

    public void setData(DataBean Data) {
        this.Data = Data;
    }

    public static class DataBean {
        /**
         * LastUpdateDate : 2017-09-25T16:04:10
         */

        private String LastUpdateDate;

        public String getLastUpdateDate() {
            return LastUpdateDate;
        }

        public void setLastUpdateDate(String LastUpdateDate) {
            this.LastUpdateDate = LastUpdateDate;
        }
    }
}
