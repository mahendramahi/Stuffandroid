package com.truworth.wellnesscorner.model;

import java.io.Serializable;
import java.util.List;

public class PostMediaList implements Serializable {

    private int postMediaType;
    private List<PostMediaData> postMediaData;

    public int getPostMediaType() {
        return postMediaType;
    }

    public void setPostMediaType(int postMediaType) {
        this.postMediaType = postMediaType;
    }

    public List<PostMediaData> getPostMediaData() {
        return postMediaData;
    }

    public void setPostMediaData(List<PostMediaData> postMediaData) {
        this.postMediaData = postMediaData;
    }


}
