package com.truworth.wellnesscorner.network;


import android.content.Context;

import com.truworth.wellnesscorner.BuildConfig;
import com.truworth.wellnesscorner.TheWellnessCornerApp;
import com.truworth.wellnesscorner.data.SharedPreferenceHelper;
import com.truworth.wellnesscorner.di.AppContext;
import com.truworth.wellnesscorner.utils.AppConstants;
import com.truworth.wellnesscorner.utils.NetworkUtils;

import java.io.File;
import java.util.concurrent.TimeUnit;

import javax.inject.Inject;
import javax.inject.Singleton;

import dagger.Module;
import dagger.Provides;
import okhttp3.Cache;
import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory;
import retrofit2.converter.gson.GsonConverterFactory;


@Module
public class NetworkModule {

    private static final int CACHE_SIZE = 4;
    private static final int READ_TIMEOUT = 100 * 1000;
    private static final int CONNECTION_TIMEOUT = 100 * 1000;

    public NetworkModule() {
    }

    @Provides
    @Singleton
    ApiServices provideAPIService(Retrofit retrofit) {
        return retrofit.create(ApiServices.class);
    }

    @Provides
    @Singleton
    Retrofit providesRetrofit(OkHttpClient okHttpClient, RxJava2CallAdapterFactory rxJava2CallAdapterFactory, GsonConverterFactory gsonConverterFactory) {
        return new Retrofit.Builder()
                .baseUrl(AppConstants.API_ENDPOINT)
                .client(okHttpClient)
                .addCallAdapterFactory(rxJava2CallAdapterFactory)
                .addConverterFactory(gsonConverterFactory)
                .build();
    }


    @Singleton
    @Provides
    @Inject
    OkHttpClient getOkHttpClient(@AppContext Context context, SharedPreferenceHelper prefHelper) {
        HttpLoggingInterceptor logger = new HttpLoggingInterceptor();
        logger.setLevel(BuildConfig.DEBUG ? HttpLoggingInterceptor.Level.BODY : HttpLoggingInterceptor.Level.NONE);

//        final String CERTIFICATE_DOMAIN = "www.trovo.in";
//        final String[] CERTIFICATE_SHA = {"sha256/Ko8tivDrEjiY90yGasP6ZpBU4jwXvHqVvQI0GS3GNdA=", "sha256/8Rw90Ej3Ttt8RRkrg+WYDS9n7IS03bk5bjP/UXPtaY8=", "sha256/aWiOzygZ3nMzHD684iCIadyK3bSHs8ISVEPSd7pvk80="};
//        CertificatePinner.Builder certificatePinnerBuilder = new CertificatePinner.Builder();
//        for (String sha : CERTIFICATE_SHA) certificatePinnerBuilder.add(CERTIFICATE_DOMAIN, sha);

        int cacheSize = CACHE_SIZE * 1024 * 1024;

        return new OkHttpClient.Builder()
                .cache(new Cache(new File(context.getCacheDir(), "http"), cacheSize))
//                .certificatePinner(certificatePinnerBuilder.build())
                .retryOnConnectionFailure(false)
                .readTimeout(READ_TIMEOUT, TimeUnit.MILLISECONDS)
                .connectTimeout(CONNECTION_TIMEOUT, TimeUnit.MILLISECONDS)
                .addInterceptor(new AuthorizationInterceptor(context, prefHelper))
                .addInterceptor(new ConnectivityInterceptor() {
                    @Override
                    public boolean isInternetAvailable() {
                        return NetworkUtils.isOnline(context);
                    }

                    @Override
                    public void onInternetUnavailable() {
                        if (TheWellnessCornerApp.getApp().getInternetConnectionListener() != null)
                            TheWellnessCornerApp.getApp().getInternetConnectionListener().onInternetUnavailable();

                        //                        if (listener != null)
//                            listener.onInternetUnavailable();
                    }
                })
                .addInterceptor(logger)
                .build();
    }


    @Singleton
    @Provides
    RxJava2CallAdapterFactory providesRxJava2CallAdapterFactory() {
        return RxJava2CallAdapterFactory.create();
    }

    @Singleton
    @Provides
    GsonConverterFactory providesGsonConverterFactory() {
        return GsonConverterFactory.create();
    }


}
