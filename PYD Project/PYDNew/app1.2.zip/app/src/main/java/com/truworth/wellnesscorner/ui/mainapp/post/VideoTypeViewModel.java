package com.truworth.wellnesscorner.ui.mainapp.post;

import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.View;

import com.truworth.wellnesscorner.base.BaseViewModel;

import im.ene.toro.ToroPlayer;
import im.ene.toro.exoplayer.ExoPlayerViewHelper;
import im.ene.toro.media.PlaybackInfo;
import im.ene.toro.widget.Container;

public class VideoTypeViewModel extends BaseViewModel {


}
