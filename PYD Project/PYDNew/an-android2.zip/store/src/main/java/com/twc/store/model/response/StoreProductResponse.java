package com.twc.store.model.response;



import com.twc.store.model.beans.StoreDataBeanItem;

import java.util.List;

/**
 * If this code works it was written by Somesh Kumar on 04 May, 2017. If not, I don't know who wrote it.
 */
public class StoreProductResponse {
    private int status;
    private List<StoreDataBeanItem> Products;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public List<StoreDataBeanItem> getProducts() {
        return Products;
    }

    public void setProducts(List<StoreDataBeanItem> Products) {
        this.Products = Products;
    }

}
