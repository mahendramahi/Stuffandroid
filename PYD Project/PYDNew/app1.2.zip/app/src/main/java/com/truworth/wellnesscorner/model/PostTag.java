package com.truworth.wellnesscorner.model;

import java.io.Serializable;

public class PostTag implements Serializable {
    int postTagIndex;
    int postTagTypeId;
    String postTagName;
    String postTagMapIdentity;


    public int getPostTagIndex() {
        return postTagIndex;
    }

    public void setPostTagIndex(int postTagIndex) {
        this.postTagIndex = postTagIndex;
    }

    public int getPostTagTypeId() {
        return postTagTypeId;
    }

    public void setPostTagTypeId(int postTagTypeId) {
        this.postTagTypeId = postTagTypeId;
    }

    public String getPostTagName() {
        return postTagName;
    }

    public void setPostTagName(String postTagName) {
        this.postTagName = postTagName;
    }

    public String getPostTagMapIdentity() {
        return postTagMapIdentity;
    }

    public void setPostTagMapIdentity(String postTagMapIdentity) {
        this.postTagMapIdentity = postTagMapIdentity;
    }
}
