package com.truworth.wellnesscorner.ui.mainapp.post;

import android.content.res.Resources;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.WindowManager;

import com.truworth.wellnesscorner.databinding.ItemImageSliderBinding;
import com.truworth.wellnesscorner.model.PostMediaData;
import com.truworth.wellnesscorner.customviews.FullImageDialog;

import static com.facebook.FacebookSdk.getApplicationContext;

public class MediaImageViewHolder extends RecyclerView.ViewHolder {

    ItemImageSliderBinding itemImageSliderBinding;

    public MediaImageViewHolder(ItemImageSliderBinding binding) {
        super(binding.getRoot());
        itemImageSliderBinding = binding;

    }

    public void bind(@NonNull PostMediaData postMediaData) {
        DisplayMetrics displayMetrics = new DisplayMetrics();
        WindowManager windowmanager;
        windowmanager = (WindowManager) getApplicationContext().getSystemService(itemImageSliderBinding.getRoot().getContext().WINDOW_SERVICE);
        windowmanager.getDefaultDisplay().getMetrics(displayMetrics);
        int deviceWidth = Resources.getSystem().getDisplayMetrics().widthPixels;
        itemImageSliderBinding.getRoot().setLayoutParams(new RecyclerView.LayoutParams(deviceWidth, RecyclerView.LayoutParams.MATCH_PARENT));


        itemImageSliderBinding.setViewModel(postMediaData);
        itemImageSliderBinding.executePendingBindings();
        itemImageSliderBinding.imageLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FullImageDialog dialog = new FullImageDialog(view.getContext(), postMediaData.getFileName(), "");
                dialog.show();
            }
        });
    }

}
