package com.truworth.wellnesscorner.ui.mainapp.createpost.shareexercise;

import android.content.Context;
import android.databinding.ObservableField;
import android.text.SpannableStringBuilder;

import com.truworth.wellnesscorner.base.BaseViewModel;
import com.truworth.wellnesscorner.model.ExerciseData;
import com.truworth.wellnesscorner.model.MealDataBean;
import com.truworth.wellnesscorner.utils.Utils;

public class ShareExerciseItemViewModel extends BaseViewModel {
    public ObservableField<SpannableStringBuilder> calValues = new ObservableField<>();
    public ExerciseData exerciseData;
    private ExerciseListener exerciseListener;

    public ShareExerciseItemViewModel(ExerciseData exerciseData, ExerciseListener exerciseListener) {
        this.exerciseListener = exerciseListener;
        this.exerciseData = exerciseData;
    }

    public ExerciseData getExerciseData() {
        return exerciseData;
    }

    public void onItemClick() {
        exerciseListener.onItemClick(exerciseData);
    }

    public void getCalories() {
        SpannableStringBuilder value = Utils.makeSpecificTextBoldSize((String.valueOf((int)exerciseData.getCalorie()) + "\ncals."), String.valueOf((int) exerciseData.getCalorie()), 2f);
        calValues.set(value);
    }

    public interface ExerciseListener {
        void onItemClick(ExerciseData exerciseData);
    }
}
