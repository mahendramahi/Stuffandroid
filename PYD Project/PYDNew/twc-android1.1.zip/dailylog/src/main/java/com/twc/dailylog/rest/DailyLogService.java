package com.twc.dailylog.rest;


import com.twc.dailylog.model.beans.AddFoodItem;
import com.twc.dailylog.model.requestbody.AddFoodBody;
import com.twc.dailylog.model.requestbody.AddSuggestedFoodBody;
import com.twc.dailylog.model.requestbody.DailyLogBody;
import com.twc.dailylog.model.requestbody.DeleteActivityByID;
import com.twc.dailylog.model.requestbody.DeleteFoodByID;
import com.twc.dailylog.model.requestbody.FoodDetailBody;
import com.twc.dailylog.model.requestbody.FoodSearchBody;
import com.twc.dailylog.model.requestbody.HomeBody;
import com.twc.dailylog.model.requestbody.SaveExerciseBody;
import com.twc.dailylog.model.requestbody.SearchExerciseBody;
import com.twc.dailylog.model.response.ActivityMarkAsReadResponse;
import com.twc.dailylog.model.response.AddFoodResponse;
import com.twc.dailylog.model.response.GetDailyLogResponse;
import com.twc.dailylog.model.response.GetDietPlanResponse;
import com.twc.dailylog.model.response.GetFoodDetailResponse;
import com.twc.dailylog.model.response.GetFoodSearchResponse;
import com.twc.dailylog.model.response.SaveExerciseResponse;
import com.twc.dailylog.model.response.TrackExerciseResponse;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

/**
 * Created by GurvinderS on 10/15/2016.
 */
public interface DailyLogService {

    @POST("member/food/GetDietPlanDetails")
    Call<GetDietPlanResponse> getDietPlan(@Body HomeBody homeBody);

    @POST("member/food/GetFrequentlyTrackedFoods")
    Call<GetDietPlanResponse> getFreqentlyFood(@Body HomeBody homeBody);

    @POST("member/food/GetFoodListForSearch")
    Call<GetFoodSearchResponse> getFoodSearchByKeyword(@Body FoodSearchBody foodSearchBody);

    @POST("member/food/GetFoodDetailByID")
    Call<GetFoodDetailResponse> getFoodDetailById(@Body FoodDetailBody foodDetailBody);

    @POST("member/food/SaveCalorieIntake")
    Call<AddFoodResponse> addFoodData(@Body AddFoodBody addFoodBody);

    @POST("member/food/UpdateCalorieIntake")
    Call<AddFoodResponse> updateFoodData(@Body AddFoodItem updateFoodItem);

    @POST("member/food/GetDailyDietLog")
    Call<GetDailyLogResponse> getDailyLog(@Body DailyLogBody dailylogBody);

    @POST("member/food/DeleteCalorieIntake")
    Call<ActivityMarkAsReadResponse> getDeleteFoodByID(@Body DeleteFoodByID deleteFoodByID);

    @POST("member/food/SaveSuggestedDietFood")
    Call<AddFoodResponse> saveSuggestedDietFood(@Body AddSuggestedFoodBody suggestedFoodBody);

    @POST("member/Activity/DeleteCalorieBurnout")
    Call<ActivityMarkAsReadResponse> getDeleteActivityByID(@Body DeleteActivityByID deleteActivityByID);

    @POST("member/Exercise/SaveCalorieBurnout")
    Call<SaveExerciseResponse> getSaveExercise(@Body SaveExerciseBody saveExerciseBody);

    @POST("member/Activity/GetActivitySearchByKeyword")
    Call<TrackExerciseResponse> getTrackExercise(@Body SearchExerciseBody searchExerciseBody);

}
