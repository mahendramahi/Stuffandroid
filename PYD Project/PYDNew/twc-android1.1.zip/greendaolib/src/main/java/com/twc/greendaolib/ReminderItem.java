package com.twc.greendaolib;

import org.greenrobot.greendao.annotation.Entity;
import org.greenrobot.greendao.annotation.Generated;
import org.greenrobot.greendao.annotation.Id;

/**
 * Created by ManishJ1 on 11/15/2016.
 */
@Entity
public class ReminderItem {
    public int serverID;
    public String userId;
    public String reminderName;
    public String reminderText;
    public String reminderDesc;
    public boolean isActive;
    public boolean isCustom;
    @Id(autoincrement = true)
    private Long id;

    @Generated(hash = 1402045086)
    public ReminderItem(int serverID, String userId, String reminderName,
            String reminderText, String reminderDesc, boolean isActive,
            boolean isCustom, Long id) {
        this.serverID = serverID;
        this.userId = userId;
        this.reminderName = reminderName;
        this.reminderText = reminderText;
        this.reminderDesc = reminderDesc;
        this.isActive = isActive;
        this.isCustom = isCustom;
        this.id = id;
    }

    @Generated(hash = 499086432)
    public ReminderItem() {
    }

    public boolean getIsCustom() {
        return this.isCustom;
    }

    public void setIsCustom(boolean isCustom) {
        this.isCustom = isCustom;
    }

    public boolean getIsActive() {
        return this.isActive;
    }

    public void setIsActive(boolean isActive) {
        this.isActive = isActive;
    }

    public String getReminderDesc() {
        return this.reminderDesc;
    }

    public void setReminderDesc(String reminderDesc) {
        this.reminderDesc = reminderDesc;
    }

    public String getReminderText() {
        return this.reminderText;
    }

    public void setReminderText(String reminderText) {
        this.reminderText = reminderText;
    }

    public String getReminderName() {
        return this.reminderName;
    }

    public void setReminderName(String reminderName) {
        this.reminderName = reminderName;
    }

    public String getUserId() {
        return this.userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public int getServerID() {
        return this.serverID;
    }

    public void setServerID(int serverID) {
        this.serverID = serverID;
    }

    public Long getId() {
        return this.id;
    }

    public void setId(Long id) {
        this.id = id;
    }

}
