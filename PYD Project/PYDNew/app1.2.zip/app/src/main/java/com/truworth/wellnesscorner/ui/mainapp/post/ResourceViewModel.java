package com.truworth.wellnesscorner.ui.mainapp.post;

import com.truworth.wellnesscorner.base.BaseViewModel;
import com.truworth.wellnesscorner.model.PostMediaData;
import com.truworth.wellnesscorner.model.PostMediaList;

import java.util.List;

public class ResourceViewModel extends BaseViewModel {
    List<PostMediaList> mPostMediaList;
    PostMediaList mediaDataList = new PostMediaList();
    public PostMediaData postMediaData = new PostMediaData();

    public ResourceViewModel(List<PostMediaList> mediaList) {
        this.mPostMediaList = mediaList;
        if (mPostMediaList.size() > 0) {
            mediaDataList = mPostMediaList.get(0);
            if (mediaDataList.getPostMediaData().size() > 0)
                postMediaData = mediaDataList.getPostMediaData().get(0);
        }
    }
}
