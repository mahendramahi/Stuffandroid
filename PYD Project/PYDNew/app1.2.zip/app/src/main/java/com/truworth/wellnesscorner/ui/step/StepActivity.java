package com.truworth.wellnesscorner.ui.step;

import android.app.Activity;
import android.app.Fragment;
import android.app.FragmentManager;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;

import com.truworth.wellnesscorner.R;
import com.truworth.wellnesscorner.utils.AppConstants;
import com.truworth.wellnesscorner.utils.Utils;

public class StepActivity extends AppCompatActivity {
    public Toolbar mToolbar;
    private TextView tvToolbarTitle;
    private String connectedDevice;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_step);

        connectedDevice = getIntent().getStringExtra("connectedDevice");
        setupToolbar();
        if (connectedDevice.equalsIgnoreCase("")) {
            Utils.replaceFragment(getFragmentManager(), ConnectDeviceListFragment.newInstance(null), ConnectDeviceListFragment.class.getSimpleName(), true, R.id.fragmentContainer);
        } else {
            StepsTrackerFragment stepsTrackerFragment = (StepsTrackerFragment) getFragmentManager().findFragmentByTag(StepsTrackerFragment.class.getSimpleName());

            stepsTrackerFragment = StepsTrackerFragment.newInstance();
            stepsTrackerFragment.setConnectedDeviceType(connectedDevice);
            Utils.replaceFragment(getFragmentManager(), stepsTrackerFragment, StepsTrackerFragment.class.getSimpleName(), true, R.id.fragmentContainer);

        }
    }

    private void setupToolbar() {
        mToolbar = findViewById(R.id.toolbar);
        tvToolbarTitle = findViewById(R.id.tbTitle);
        setSupportActionBar(mToolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        mToolbar.setNavigationIcon(R.drawable.ic_arrow_left_white_24dp);
    }

    public void setToolBarTitle(String toolBarTitle) {
        tvToolbarTitle.setText(toolBarTitle);
        assert getSupportActionBar() != null;
        getSupportActionBar().show();
    }

    public void showHomeAsUpEnableToolbar() {
        mToolbar.setNavigationIcon(R.drawable.ic_arrow_left_white_24dp);
        mToolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int count = getFragmentManager().getBackStackEntryCount();
                if (count > 1 && getCurrentFragmentName(StepsTrackerFragment.class.getSimpleName())) {
                    setResult(Activity.RESULT_OK);
                    finish();
                } else {
                    onBackPressed();
                }
            }
        });
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }
    }

    public void changeToolbarColor(int color) {
        mToolbar.setBackgroundColor(color);
    }

    public void makeToolbarColorDefault() {
        mToolbar.setBackgroundColor(ContextCompat.getColor(this, R.color.colorPrimary));
    }

    public void makeStatusBarColorDefault() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = this.getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
            window.setStatusBarColor(ContextCompat.getColor(this, R.color.colorPrimaryDark));
        }
    }

    public void changeStatusBarColor(int color) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = this.getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
            window.setStatusBarColor(color);
        }
    }

    public void makeToolBarTitleColorDefault() {
        tvToolbarTitle.setTextColor(ContextCompat.getColor(this, R.color.color_FFFFFF));
        assert getSupportActionBar() != null;
        getSupportActionBar().show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Fragment fragment = getFragmentManager().findFragmentByTag(ConnectDeviceDetailFragment.class.getSimpleName());
        if (fragment != null) {
            fragment.onActivityResult(requestCode, resultCode, data);
        }

        Fragment stepsSettingFragment = getFragmentManager().findFragmentByTag(StepTrackerSettingFragment.class.getSimpleName());
        if (stepsSettingFragment != null) {
            stepsSettingFragment.onActivityResult(requestCode, resultCode, data);
        }

    }

    private boolean getCurrentFragmentName(String fragmentName) {
        FragmentManager fragmentManager = getFragmentManager();
        if (fragmentManager.findFragmentByTag(fragmentName) != null) {
            String fragmentTag = fragmentManager.getBackStackEntryAt(fragmentManager.getBackStackEntryCount() - 1).getName();
            return fragmentTag.equalsIgnoreCase(fragmentName);
        } else
            return false;
    }

    @Override
    public void onBackPressed() {
        Utils.hideSoftKeyboard(this);
        int count = getFragmentManager().getBackStackEntryCount();
        if (count == 1) {
            setResult(Activity.RESULT_OK);
            finish();
        } else {
            super.onBackPressed();
        }
    }
}
