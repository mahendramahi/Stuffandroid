package com.twc.dailylog.interfaces;

/**
 * Created by GurvinderS on 10/12/2016.
 */
public interface OnTrackerReadingSave {

    void onTrackerReadingSuccess();
}
