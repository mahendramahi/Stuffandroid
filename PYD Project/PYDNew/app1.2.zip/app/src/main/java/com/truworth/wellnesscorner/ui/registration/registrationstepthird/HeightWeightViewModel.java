package com.truworth.wellnesscorner.ui.registration.registrationstepthird;

import android.databinding.ObservableBoolean;
import android.databinding.ObservableInt;

import com.truworth.wellnesscorner.base.BaseViewModel;
import com.truworth.wellnesscorner.utils.SingleLiveEvent;

/**
 * If this code works, it was written by Somesh Kumar  on 29 March, 2018. If not, I don't know who wrote it.
 */
public class HeightWeightViewModel extends BaseViewModel {
    public ObservableInt height = new ObservableInt();
    public ObservableInt weight = new ObservableInt();
    public SingleLiveEvent<Void> getOnClickContinue() {
        return onClickContinue;
    }

    SingleLiveEvent<Void> onClickContinue = new SingleLiveEvent<>();

    public ObservableInt getHeight() {
        return height;
    }

    public void setHeight(ObservableInt height) {
        this.height = height;
    }

    public ObservableInt getWeight() {
        return weight;
    }

    public void setWeight(ObservableInt weight) {
        this.weight = weight;
    }

    public void onClickContinueCall() {
        if(height.get() != 0 && weight.get()!= 0) {
            onClickContinue.call();
        }
    }
}
