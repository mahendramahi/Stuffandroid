package com.twc.dailylog.model.beans;

import java.util.List;

/**
 * Created by PankajS on 8/5/2016.
 */
public class DailyLogItemDetail {

    private DailyLogData DietLogData;

    private List<MemberActivityItem> MemberActivity;

    private List<NutritionDataItem> NutritionData;

    public DailyLogData getDietLogData() {
        return DietLogData;
    }

    public void setDietLogData(DailyLogData DietLogData) {
        this.DietLogData = DietLogData;
    }

    public List<MemberActivityItem> getMemberActivity() {
        return MemberActivity;
    }

    public void setMemberActivity(List<MemberActivityItem> MemberActivity) {
        this.MemberActivity = MemberActivity;
    }

    public List<NutritionDataItem> getNutritionData() {
        return NutritionData;
    }

    public void setNutritionData(List<NutritionDataItem> NutritionData) {
        this.NutritionData = NutritionData;
    }
}
