package com.twc.dailylog;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.TextView;

import com.twc.dailylog.fragments.WaterTrackerFragmentNew;
import com.twc.dailylog.model.beans.DailyLogUser;
import com.twc.dailylog.utils.Utils;
import com.twc.dailylog.utils.WaterConfig;


public class WaterActivity extends AppCompatActivity {
    public Toolbar mToolbar;

    private TextView tvToolbarTitle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_water_tracker);
        setupToolbar();
        if (getIntent() != null) {
            String waterIntake = getIntent().getStringExtra("waterIntake");

            Bundle bundle = new Bundle();
            bundle.putInt("waterIntake", Integer.parseInt(waterIntake));


            WaterTrackerFragmentNew waterTrackerFragment = WaterTrackerFragmentNew.newInstance(bundle);
            Utils.replaceFragment(getFragmentManager(), waterTrackerFragment, WaterTrackerFragmentNew.class.getSimpleName(), true, R.id.fragmentContainer);

        }


    }

    @Override
    public void onBackPressed() {
        int count = getFragmentManager().getBackStackEntryCount();
        if (count == 1) {
            setResult(Activity.RESULT_OK);
            finish();
        } else {
            super.onBackPressed();
        }
    }

    private void setupToolbar() {
        mToolbar = findViewById(R.id.toolbar);
        tvToolbarTitle = findViewById(R.id.tbTitle);
        setSupportActionBar(mToolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        mToolbar.setNavigationIcon(R.drawable.ic_arrow_left_white_24dp);
    }

    public void setToolBarTitle(String toolBarTitle) {
        tvToolbarTitle.setText(toolBarTitle);
        assert getSupportActionBar() != null;
        getSupportActionBar().show();
    }

    public void showHomeAsUpEnableToolbar() {
        mToolbar.setNavigationIcon(R.drawable.ic_arrow_left_white_24dp);
        mToolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }
    }
}
