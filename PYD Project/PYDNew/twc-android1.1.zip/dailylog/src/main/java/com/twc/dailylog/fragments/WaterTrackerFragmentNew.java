package com.twc.dailylog.fragments;

import android.app.Fragment;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.CardView;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;

import com.twc.dailylog.R;
import com.twc.dailylog.R2;
import com.twc.dailylog.WaterActivity;
import com.twc.dailylog.adapter.WaterIntakeAdapter;
import com.twc.dailylog.interfaces.IContainerType;
import com.twc.dailylog.model.beans.WaterBean;
import com.twc.dailylog.model.requestbody.SaveWaterTrackerBody;
import com.twc.dailylog.model.requestbody.WaterTrackerDataRequest;
import com.twc.dailylog.model.response.SaveWaterTrackerResponse;
import com.twc.dailylog.model.response.WaterTrackerDataResponse;
import com.twc.dailylog.rest.RestClient;
import com.twc.dailylog.utils.Constant;
import com.twc.dailylog.utils.DailyLogConfig;
import com.twc.dailylog.utils.DateFactory;
import com.twc.dailylog.utils.DialogFactory;
import com.twc.dailylog.utils.NetworkFactory;
import com.twc.dailylog.utils.Utils;
import com.twc.dailylog.utils.WaterConfig;
import com.twc.dailylog.views.CustomTextView;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class WaterTrackerFragmentNew extends Fragment implements IContainerType {


    @BindView(R2.id.rlWaterTracker)
    RelativeLayout rlWaterTracker;

    @BindView(R2.id.tvWaterIntake)
    CustomTextView tvWaterIntake;

    @BindView(R2.id.cvWaterTracker)
    CardView cvWaterTracker;
    @BindView(R2.id.rvWaterIntake)
    RecyclerView rvUploadPhoto;
    private WaterIntakeAdapter waterIntakeAdapter;
    ArrayList<WaterBean> arrList = new ArrayList<>();
    private String containerType;
    private int waterIntake;

    public static WaterTrackerFragmentNew newInstance(Bundle bundle) {
        WaterTrackerFragmentNew fragment = new WaterTrackerFragmentNew();
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

       /* if (getArguments() != null) {
            waterIntake = getArguments().getInt("waterIntake");
            //  count=waterIntake;

            // Water Tracker RecyclerView


        }*/

    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.water_tracker_fragment_new, container, false);
        ButterKnife.bind(this, rootView);


        rvUploadPhoto.setHasFixedSize(true);
        RecyclerView.LayoutManager layoutManager = new GridLayoutManager(getActivity(), 8);
        rvUploadPhoto.setLayoutManager(layoutManager);
        containerType = WaterConfig.containerType;
        waterIntakeAdapter = new WaterIntakeAdapter(WaterTrackerFragmentNew.this, arrList, containerType);
        rvUploadPhoto.setAdapter(waterIntakeAdapter);

        getWaterTrackerDataApiCall();
        return rootView;
    }

    private void setGlassContainer(double waterLastValue) {
        arrList.clear();

        double glassSize = waterLastValue;
        double actualGlassSize = glassSize + 1;
        if (actualGlassSize < Constant.DEFAULT_SIZE_GLASS) {
            actualGlassSize = Constant.DEFAULT_SIZE_GLASS;
        }
        for (int i = 0; i < actualGlassSize; i++) {
            WaterBean bean = new WaterBean();
            if (i < glassSize)
                setItemFilled(bean);
            if (i == glassSize)
                setAddIconInLastPosition(bean);
            arrList.add(bean);
        }
        waterIntakeAdapter.notifyDataSetChanged();

        updateCount(arrList, false);
    }

    private void setBottleContainer(double waterLastValue) {
        arrList.clear();
        double glassSize = waterLastValue / 2;
        double actualGlassSize = glassSize + 1;
        if (actualGlassSize < Constant.DEFAULT_SIZE_BOTTLE) {
            actualGlassSize = Constant.DEFAULT_SIZE_BOTTLE;
        }
        for (int i = 0; i < actualGlassSize; i++) {
            WaterBean bean = new WaterBean();
            if (i < glassSize)
                setItemFilled(bean);
            if (i == glassSize)
                setAddIconInLastPosition(bean);
            arrList.add(bean);
        }
        waterIntakeAdapter.setList(arrList);
        waterIntakeAdapter.notifyDataSetChanged();
        updateCount(arrList, false);
    }

    public void setItemFilled(WaterBean bean) {
        bean.setFill(true);
        bean.setAdd(true);
    }

    public void setAddIconInLastPosition(WaterBean bean) {
        bean.setFill(false);
        bean.setAdd(false);
        bean.setShowAddIcon(true);
    }

    public void updateCount(List<WaterBean> waterIntakeList, boolean shouldSaveApiCall) {

        float count = 0;
        for (WaterBean bean : waterIntakeList) {
            if (bean.isFill()) {
                if (containerType.equalsIgnoreCase(Constant.GLASS)) {
                    count = count + Float.parseFloat(".25");

                } else {
                    count = count + Float.parseFloat(".50");
                }
            }
        }
        tvWaterIntake.setText(count + "L");
        rlWaterTracker.invalidate();
        cvWaterTracker.invalidate();
        float waterIntakeGlassCount = count * 100 / 25;
        if (shouldSaveApiCall)
            saveWaterTrackerData((int) waterIntakeGlassCount);
    }

    @Override
    public void onChange() {
        Utils.hideSoftKeyboard(getActivity());
        setContainerType();
    }

    public void setContainerType() {
        if (WaterConfig.containerType.equalsIgnoreCase(Constant.GLASS)) {

            containerType = Constant.GLASS;
            waterIntakeAdapter.setContainerType(containerType);
            List<WaterBean> filledItemList = waterIntakeAdapter.getFilledItemList();
            if (filledItemList.size() > 0) {
                int glassSize = (filledItemList.size() * 2) + 1;
                int actualGlassSize = glassSize;
                if (actualGlassSize < Constant.DEFAULT_SIZE_GLASS) {
                    actualGlassSize = Constant.DEFAULT_SIZE_GLASS;
                }
                for (int i = filledItemList.size(); i < actualGlassSize; i++) {
                    WaterBean bean = new WaterBean();
                    if (i < glassSize) {
                        setItemFilled(bean);
                    }
                    if (i == glassSize - 1) {
                        setAddIconInLastPosition(bean);
                    }
                    filledItemList.add(bean);
                }
                waterIntakeAdapter.setList(filledItemList);
                waterIntakeAdapter.notifyDataSetChanged();
            } else {
                setGlassContainer(0);
            }
        } else {

            containerType = Constant.BOTTLE;
            waterIntakeAdapter.setContainerType(containerType);

            List<WaterBean> filledItemList = waterIntakeAdapter.getFilledItemList();
            if (filledItemList.size() > 0) {
                filledItemList.get(filledItemList.size() / 2).setFill(false);
                filledItemList.get(filledItemList.size() / 2).setAdd(false);
                filledItemList.get(filledItemList.size() / 2).setShowAddIcon(true);

                List<WaterBean> list = filledItemList.subList(0, filledItemList.size() / 2 + 1);
                int bottleSize = list.size();
                if (bottleSize < Constant.DEFAULT_SIZE_BOTTLE) {
                    for (int i = filledItemList.size() / 2 + 1; i < Constant.DEFAULT_SIZE_BOTTLE; i++) {
                        WaterBean bean = new WaterBean();
                        list.add(bean);
                    }
                }
                waterIntakeAdapter.setList(list);
                waterIntakeAdapter.notifyDataSetChanged();
            } else {
                setBottleContainer(0);
            }
        }
    }
    public void getWaterTrackerDataApiCall() {
        if (NetworkFactory.getInstance().isNetworkAvailable(getActivity())) {
            WaterTrackerDataRequest waterTrackerDataRequest = new WaterTrackerDataRequest();
            waterTrackerDataRequest.setDate(DateFactory.getInstance().getTodayDate("MM/dd/yyyy HH:mm:ss a"));

            RestClient restClient = new RestClient(getActivity(), DailyLogConfig.BASE_URL, DailyLogConfig.DEBUG);
            restClient.getTrackersService().getWaterTrackerData(waterTrackerDataRequest).enqueue(new Callback<WaterTrackerDataResponse>() {
                @Override
                public void onResponse(Call<WaterTrackerDataResponse> call, Response<WaterTrackerDataResponse> response) {
                    if (isAdded() && getActivity() != null) {
                        if (response != null && response.body() != null) {
                            if (response.body().getStatus() == 0) {
                                waterIntake = Integer.parseInt(response.body().getData().getNoOfWaterGlass());

                                if (containerType.equalsIgnoreCase(Constant.GLASS)) {
                                    setGlassContainer(waterIntake);
                                } else {
                                    setBottleContainer(waterIntake);
                                }
                            } else {
                                DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_response_failure), getString(R.string.str_ok), false);
                            }

                        } else {
                            DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_response_failure), getString(R.string.str_ok), false);
                        }
                    }
                }

                @Override
                public void onFailure(Call<WaterTrackerDataResponse> call, Throwable t) {
                    if (isAdded() && getActivity() != null) {
                        DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_failure), getString(R.string.str_ok), false);
                    }
                }
            });
        }
    }

    public void saveWaterTrackerData(int waterIntakeGlassCount) {
        if (NetworkFactory.getInstance().isNetworkAvailable(getActivity())) {
            SaveWaterTrackerBody saveWaterTrackerBody = new SaveWaterTrackerBody();
            // saveWaterTrackerBody.setMemberID(WellnessCornerApp.getPreferenceManager().getUserId());
            saveWaterTrackerBody.setDate(DateFactory.getInstance().getTodayDate("MM/dd/yyyy HH:mm:ss"));
            saveWaterTrackerBody.setNoOfWaterGlass(String.valueOf(waterIntakeGlassCount));
            RestClient restClient = new RestClient(getActivity(), DailyLogConfig.BASE_URL, DailyLogConfig.DEBUG);
            restClient.getTrackersService().getSaveWaterTrackerData(saveWaterTrackerBody).enqueue(new Callback<SaveWaterTrackerResponse>() {
                @Override
                public void onResponse(Call<SaveWaterTrackerResponse> call, Response<SaveWaterTrackerResponse> response) {
                    if (isAdded() && getActivity() != null) {
                        if (response != null && response.body() != null) {
                            if (response.body().getStatus() == 0) {
                                // WellnessCornerApp.getPreferenceManager().setWaterTrackerDate(DateFactory.getInstance().getTodayDate("MM/dd/yyyy HH:mm:ss"));
                            } else {
                                DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_response_failure), getString(R.string.str_ok), false);
                            }

                        } else {
                            DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_response_failure), getString(R.string.str_ok), false);
                        }
                    }
                }

                @Override
                public void onFailure(Call<SaveWaterTrackerResponse> call, Throwable t) {
                    if (isAdded() && getActivity() != null) {
                        // Toast.makeText(getActivity(), getString(R.string.msg_api_failure), Toast.LENGTH_SHORT).show();
                        DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_failure), getString(R.string.str_ok), false);
                    }
                }
            });
        }
    }
    @Override
    public void onResume() {
        super.onResume();
        if (getActivity() instanceof WaterActivity) {
            ((WaterActivity) getActivity()).showHomeAsUpEnableToolbar();

            ((WaterActivity) getActivity()).setToolBarTitle("Water");
        }
    }
    @OnClick({R2.id.ivWaterDropImage})
    public void onClick(View view) {
        if (view.getId() == R.id.ivWaterDropImage) {

            WaterBottomSheetFragment waterBottomSheetFragment = new WaterBottomSheetFragment();
            waterBottomSheetFragment.setCallBack(this);
            waterBottomSheetFragment.show(((WaterActivity) getActivity()).getSupportFragmentManager(), waterBottomSheetFragment.getTag());


        }
    }
}
