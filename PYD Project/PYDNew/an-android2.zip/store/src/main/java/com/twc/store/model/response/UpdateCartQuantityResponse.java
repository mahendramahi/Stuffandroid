package com.twc.store.model.response;


import com.twc.store.model.beans.UpdateCartQuantityBean;

/**
 * Created by richas on 9/14/2017.
 */

public class UpdateCartQuantityResponse {

    private int status;
    private UpdateCartQuantityBean Data;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public UpdateCartQuantityBean getData() {
        return Data;
    }

    public void setData(UpdateCartQuantityBean Data) {
        this.Data = Data;
    }


}
