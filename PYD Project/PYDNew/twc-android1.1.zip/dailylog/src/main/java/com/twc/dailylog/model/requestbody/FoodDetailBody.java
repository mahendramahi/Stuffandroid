package com.twc.dailylog.model.requestbody;

/**
 * Created by ManishJ1 on 6/30/2016.
 */
public class FoodDetailBody extends BaseBody {

    private String FoodID;

    public String getFoodID() {
        return FoodID;
    }

    public void setFoodID(String foodID) {
        FoodID = foodID;
    }
}
