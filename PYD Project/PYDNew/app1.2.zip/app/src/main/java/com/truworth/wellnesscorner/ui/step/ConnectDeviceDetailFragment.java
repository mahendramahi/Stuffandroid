
package com.truworth.wellnesscorner.ui.step;

import android.app.Activity;
import android.app.Fragment;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentSender;
import android.content.res.Resources;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GoogleApiAvailability;
import com.google.android.gms.common.api.GoogleApiClient;
import com.truworth.stepmodule.StepConfig;
import com.truworth.stepmodule.StepConnectionHelper;
import com.truworth.stepmodule.inteface.OnConnectionResultInfo;
import com.truworth.wellnesscorner.R;
import com.truworth.wellnesscorner.TheWellnessCornerApp;
import com.truworth.wellnesscorner.data.SharedPreferenceHelper;
import com.truworth.wellnesscorner.utils.AppConstants;
import com.truworth.wellnesscorner.utils.Utils;


import javax.inject.Inject;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;





public class ConnectDeviceDetailFragment extends Fragment implements OnConnectionResultInfo {
    @Inject
    SharedPreferenceHelper prefHelper;

    private static final int GOOGLE_FITNESS_REQUEST_CODE = 9010;
    private StepConnectionHelper connectionHelper;
    private int GOOGLE_OAUTH_REQUEST_CODE = 9011;
    private int MISFIT_REQUEST_CODE = 9012;
    private int FITBIT_REQUEST_CODE = 9013;
    @BindView(R.id.tvDeviceName)
    TextView tvDeviceName;
    @BindView(R.id.tvConnect)
    TextView tvConnect;
    @BindView(R.id.tvDeviceDetail)
    TextView tvDeviceDetail;
    @BindView(R.id.ivDeviceImage)
    ImageView ivDeviceImage;

    private String deviceName;

    private String imageUrl;
    private boolean isRedirectFromRecommendation;

    public ConnectDeviceDetailFragment() {
        TheWellnessCornerApp.getApp().component().inject(this);
    }


    public static ConnectDeviceDetailFragment newInstance(Bundle bundle) {
        ConnectDeviceDetailFragment fragment = new ConnectDeviceDetailFragment();
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        connectionHelper = new StepConnectionHelper(getActivity(), this);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_connectdevice_detail, container, false);
        ButterKnife.bind(this, rootView);

        if (getArguments() != null) {
            isRedirectFromRecommendation = getArguments().getBoolean("isRedirectFromRecommendation");
            deviceName = getArguments().getString(AppConstants.BUNDLE_KEY_DEVICE_NAME);
            tvDeviceName.setText(deviceName);
            tvConnect.setText(String.format("Connect %s", deviceName));
            Resources res = getResources();
            String deviceDetail = String.format(res.getString(R.string.fitbit_detail), deviceName);
            tvDeviceDetail.setText(deviceDetail);

            if (deviceName.equalsIgnoreCase(AppConstants.GOOGLE_FIT)) {
                imageUrl = AppConstants.IMAGE_GOOGLE_FIT_LARGE_URL;
                tvDeviceName.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_google_fit, 0, 0, 0);
            } else if (deviceName.equalsIgnoreCase(AppConstants.S_HEALTH)) {
                imageUrl = AppConstants.IMAGE_S_HEALTH_LARGE_URL;
                tvDeviceName.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_samsung_health, 0, 0, 0);
            } else if (deviceName.equalsIgnoreCase(AppConstants.FITBIT)) {
                imageUrl = AppConstants.IMAGE_FIT_BIT_LARGE_URL;
                tvDeviceName.setCompoundDrawablesWithIntrinsicBounds(R.drawable.fitbit_logo, 0, 0, 0);
            } else if (deviceName.equalsIgnoreCase(AppConstants.E_FIT)) {
                imageUrl = AppConstants.IMAGE_E_FIT_LARGE_URL;
                tvDeviceName.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_efit, 0, 0, 0);
            } else if (deviceName.equalsIgnoreCase(AppConstants.MISFIT)) {
                imageUrl = AppConstants.IMAGE_MIS_FIT_LARGE_URL;
                tvDeviceName.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_misfit_logo, 0, 0, 0);
            } else if (deviceName.equalsIgnoreCase(AppConstants.GARMIN)) {
                imageUrl = AppConstants.IMAGE_MIS_FIT_LARGE_URL;
                tvDeviceName.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_misfit_logo, 0, 0, 0);
            }
            Glide.with(getActivity())
                    .load(Uri.parse(imageUrl))
                    .apply(new RequestOptions().dontAnimate()
                            .dontTransform()
                            .placeholder(R.color.white)
                            .error(R.color.white))
                    .into(ivDeviceImage);
        }
        return rootView;
    }


    @OnClick(R.id.tvConnect)
    public void onConnect() {
        StepsTrackerFragment stepsTrackerFragment = (StepsTrackerFragment) getActivity().getFragmentManager().findFragmentByTag(StepsTrackerFragment.class.getSimpleName());

        switch (deviceName) {
            case AppConstants.S_HEALTH:

              connectSamsungHealth();
                break;

            case AppConstants.FITBIT:
                connectFitbit();
                break;
            case AppConstants.GOOGLE_FIT:
                connectGoogleFit();
                break;
            case AppConstants.E_FIT:
                Bundle bundle = new Bundle();
                bundle.putBoolean("isRedirectFromRecommendation", isRedirectFromRecommendation);
                Utils.replaceFragment(getFragmentManager(), EFitLoginFragment.newInstance(bundle), EFitLoginFragment.class.getSimpleName(), true, R.id.fragmentContainer);
                break;
            case AppConstants.MISFIT:
                connectMisFit();
                break;
            case AppConstants.GARMIN:

                break;
        }

    }


    @Override
    public void onResume() {
        super.onResume();
        ((StepActivity) getActivity()).showHomeAsUpEnableToolbar();
        ((StepActivity) getActivity()).setToolBarTitle(deviceName);
    }


    @Override
    public void onDestroy() {
        super.onDestroy();

    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();

    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == GOOGLE_OAUTH_REQUEST_CODE) {
                connectionHelper.requestGoogleFitnessPermission();
            } else if (requestCode == GOOGLE_FITNESS_REQUEST_CODE) {
                connectionHelper.onGoogleFitPermissionGranted();
            } else if (requestCode == MISFIT_REQUEST_CODE) {
                String status = data.getStringExtra("misFitStatus");
                if (status.equalsIgnoreCase("success")) {
                    String deviceType = data.getStringExtra("device_type");
                    String token = data.getStringExtra("token");
                    connectionHelper.onMisFitPermissionGranted(deviceType, token);
                } else {
                    Toast.makeText(getActivity(), "Misfit connection error... Please try again", Toast.LENGTH_SHORT).show();
                }

            } else if (requestCode == FITBIT_REQUEST_CODE) {
                String status = data.getStringExtra("fitBitStatus");
                if (status.equalsIgnoreCase("success")) {
                    String deviceType = data.getStringExtra("device_type");
                    String token = data.getStringExtra("token");
                    connectionHelper.onFitbitPermissionGranted(deviceType, token);
                } else {
                    Toast.makeText(getActivity(), "fitbit connection error... Please try again", Toast.LENGTH_SHORT).show();
                }
            }
        }
    }


    @Override
    public void onResultInfo(String deviceType, String info) {
        //Toast.makeText(getActivity(), info, Toast.LENGTH_SHORT).show();

        if(deviceType.equalsIgnoreCase(AppConstants.FITBIT)){
            prefHelper.setPrefKeyFitBitAccessToken(info);
            prefHelper.setPrefKeyDeviceConnected(AppConstants.FITBIT);
            StepsTrackerFragment stepsTrackerFragment = (StepsTrackerFragment) getActivity().getFragmentManager().findFragmentByTag(StepsTrackerFragment.class.getSimpleName());

            if (stepsTrackerFragment == null) {
                stepsTrackerFragment = StepsTrackerFragment.newInstance();
                stepsTrackerFragment.setConnectedDeviceType(AppConstants.FITBIT);
                Utils.replaceFragment(getFragmentManager(), stepsTrackerFragment, StepsTrackerFragment.class.getSimpleName(), true, R.id.fragmentContainer);
            } else {
                stepsTrackerFragment.setConnectedDeviceType(AppConstants.FITBIT);
                getFragmentManager().popBackStackImmediate(StepsTrackerFragment.class.getSimpleName(), 0);
            }
        }
        else if(deviceType.equalsIgnoreCase(AppConstants.MISFIT)){
            prefHelper.setPrefKeyMisFitAccessToken(info);
            prefHelper.setPrefKeyDeviceConnected(AppConstants.MISFIT);
            StepsTrackerFragment stepsTrackerFragment = (StepsTrackerFragment) getActivity().getFragmentManager().findFragmentByTag(StepsTrackerFragment.class.getSimpleName());

            if (stepsTrackerFragment == null) {
                stepsTrackerFragment = StepsTrackerFragment.newInstance();
                stepsTrackerFragment.setConnectedDeviceType(AppConstants.MISFIT);
                Utils.replaceFragment(getFragmentManager(), stepsTrackerFragment, StepsTrackerFragment.class.getSimpleName(), true, R.id.fragmentContainer);
            } else {
                stepsTrackerFragment.setConnectedDeviceType(AppConstants.MISFIT);
                getFragmentManager().popBackStackImmediate(StepsTrackerFragment.class.getSimpleName(), 0);
            }
        }
        else if (deviceType.equalsIgnoreCase(AppConstants.S_HEALTH)){
            prefHelper.setPrefKeyDeviceConnected(AppConstants.S_HEALTH);
            prefHelper.clearDeviceConnectTokenPreferences();

            StepsTrackerFragment stepsTrackerFragment = (StepsTrackerFragment) getActivity().getFragmentManager().findFragmentByTag(StepsTrackerFragment.class.getSimpleName());

            if (stepsTrackerFragment == null) {
                stepsTrackerFragment = StepsTrackerFragment.newInstance();
                stepsTrackerFragment.setConnectedDeviceType(AppConstants.S_HEALTH);
                Utils.replaceFragment(getFragmentManager(), stepsTrackerFragment, StepsTrackerFragment.class.getSimpleName(), true, R.id.fragmentContainer);
            } else {
                stepsTrackerFragment.setConnectedDeviceType(AppConstants.S_HEALTH);
                getFragmentManager().popBackStackImmediate(StepsTrackerFragment.class.getSimpleName(), 0);
            }
        }
        else if(deviceType.equalsIgnoreCase(AppConstants.GOOGLE_FIT)){
            prefHelper.setPrefKeyDeviceConnected(AppConstants.GOOGLE_FIT);
            prefHelper.clearDeviceConnectTokenPreferences();

            StepsTrackerFragment stepsTrackerFragment = (StepsTrackerFragment) getActivity().getFragmentManager().findFragmentByTag(StepsTrackerFragment.class.getSimpleName());

            if (stepsTrackerFragment == null) {
                stepsTrackerFragment = StepsTrackerFragment.newInstance();
                stepsTrackerFragment.setConnectedDeviceType(AppConstants.GOOGLE_FIT);
                Utils.replaceFragment(getFragmentManager(), stepsTrackerFragment, StepsTrackerFragment.class.getSimpleName(), true, R.id.fragmentContainer);
            } else {
                stepsTrackerFragment.setConnectedDeviceType(AppConstants.GOOGLE_FIT);
                getFragmentManager().popBackStackImmediate(StepsTrackerFragment.class.getSimpleName(), 0);
            }
        }


       // StepConfig.accessToken = info;


    }

    @Override
    public void onConnectionError(String error) {
        Toast.makeText(getActivity(), error + " found", Toast.LENGTH_SHORT).show();
    }

    private void connectMisFit() {
        if (prefHelper.getPrefKeyMisFitAccessToken() != null && prefHelper.getPrefKeyMisFitAccessToken().length() > 0) {
            StepsTrackerFragment stepsTrackerFragment = (StepsTrackerFragment) getActivity().getFragmentManager().findFragmentByTag(StepsTrackerFragment.class.getSimpleName());

            if (stepsTrackerFragment == null) {
                stepsTrackerFragment = StepsTrackerFragment.newInstance();
                stepsTrackerFragment.setConnectedDeviceType(AppConstants.MISFIT);
                Utils.replaceFragment(getFragmentManager(), stepsTrackerFragment, StepsTrackerFragment.class.getSimpleName(), true, R.id.fragmentContainer);
            } else {
                stepsTrackerFragment.setConnectedDeviceType(AppConstants.MISFIT);
                getFragmentManager().popBackStackImmediate(StepsTrackerFragment.class.getSimpleName(), 0);
            }

        } else {
            connectionHelper.startMisfitProcess(MISFIT_REQUEST_CODE);
        }
    }

    private void connectFitbit() {
        if (prefHelper.getPrefKeyFitBitAccessToken() != null && prefHelper.getPrefKeyFitBitAccessToken().length() > 0) {
            StepsTrackerFragment stepsTrackerFragment = (StepsTrackerFragment) getActivity().getFragmentManager().findFragmentByTag(StepsTrackerFragment.class.getSimpleName());

            if (stepsTrackerFragment == null) {
                stepsTrackerFragment = StepsTrackerFragment.newInstance();
                stepsTrackerFragment.setConnectedDeviceType(AppConstants.FITBIT);
                Utils.replaceFragment(getFragmentManager(), stepsTrackerFragment, StepsTrackerFragment.class.getSimpleName(), true, R.id.fragmentContainer);
            } else {
                stepsTrackerFragment.setConnectedDeviceType(AppConstants.FITBIT);
                getFragmentManager().popBackStackImmediate(StepsTrackerFragment.class.getSimpleName(), 0);
            }

        } else {
            connectionHelper.startFitbitProcess(FITBIT_REQUEST_CODE);
        }
    }

    private void connectGoogleFit(){
        if (prefHelper.getPrefKeyDeviceConnected() != null && prefHelper.getPrefKeyDeviceConnected().equalsIgnoreCase(AppConstants.GOOGLE_FIT)) {
            StepsTrackerFragment stepsTrackerFragment = (StepsTrackerFragment) getActivity().getFragmentManager().findFragmentByTag(StepsTrackerFragment.class.getSimpleName());

            if (stepsTrackerFragment == null) {
                stepsTrackerFragment = StepsTrackerFragment.newInstance();
                stepsTrackerFragment.setConnectedDeviceType(AppConstants.GOOGLE_FIT);
                Utils.replaceFragment(getFragmentManager(), stepsTrackerFragment, StepsTrackerFragment.class.getSimpleName(), true, R.id.fragmentContainer);
            } else {
                stepsTrackerFragment.setConnectedDeviceType(AppConstants.GOOGLE_FIT);
                getFragmentManager().popBackStackImmediate(StepsTrackerFragment.class.getSimpleName(), 0);
            }

        } else {
            connectionHelper.startGoogleFitProcess(GOOGLE_OAUTH_REQUEST_CODE, GOOGLE_FITNESS_REQUEST_CODE);
        }

    }
    private void connectSamsungHealth(){
        if (prefHelper.getPrefKeyDeviceConnected() != null && prefHelper.getPrefKeyDeviceConnected().equalsIgnoreCase(AppConstants.S_HEALTH)) {
            StepsTrackerFragment stepsTrackerFragment = (StepsTrackerFragment) getActivity().getFragmentManager().findFragmentByTag(StepsTrackerFragment.class.getSimpleName());

            if (stepsTrackerFragment == null) {
                stepsTrackerFragment = StepsTrackerFragment.newInstance();
                stepsTrackerFragment.setConnectedDeviceType(AppConstants.S_HEALTH);
                Utils.replaceFragment(getFragmentManager(), stepsTrackerFragment, StepsTrackerFragment.class.getSimpleName(), true, R.id.fragmentContainer);
            } else {
                stepsTrackerFragment.setConnectedDeviceType(AppConstants.S_HEALTH);
                getFragmentManager().popBackStackImmediate(StepsTrackerFragment.class.getSimpleName(), 0);
            }

        } else {
            connectionHelper.startSamsungProcess();
        }
    }

}
