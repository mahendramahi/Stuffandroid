package com.twc.dailylog.adapter;

import android.app.Activity;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.TextView;

import com.twc.dailylog.R;
import com.twc.dailylog.fragments.AddFoodFragment;
import com.twc.dailylog.model.beans.FoodSearchItem;
import com.twc.dailylog.utils.Utils;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by ManishJ1 on 7/5/2016.
 */
public class FoodSearchAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> implements Filterable {

    String searchType = "";
    private ArrayList<FoodSearchItem> mFoodItemArrayList;
    private ArrayList<FoodSearchItem> mGlobalFoodItemArrayList;
    private Activity mActivity;
    private ValueFilter valueFilter;

    public FoodSearchAdapter(ArrayList<FoodSearchItem> mFoodItemArrayList, Activity activity) {
        this.mFoodItemArrayList = mFoodItemArrayList;
        this.mGlobalFoodItemArrayList = mFoodItemArrayList;
        this.mActivity = activity;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.row_trackmeal_diet_paln, parent, false);

        return new ItemViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        ItemViewHolder itemViewHolder = (ItemViewHolder) holder;
        itemViewHolder.tvFoodName.setText(mFoodItemArrayList.get(position).getFoodName());
        itemViewHolder.tvFoodData.setText(String.format("%s %s %s Calories", Utils.doubleToString(mFoodItemArrayList.get(position).getFoodQuantity()), mFoodItemArrayList.get(position).getFoodStandardServing(), Math.round(mFoodItemArrayList.get(position).getFoodCalories())));
    }

    @Override
    public int getItemCount() {
        return (null != mFoodItemArrayList ? mFoodItemArrayList.size() : 0);
    }

    @Override
    public Filter getFilter() {
        if (valueFilter == null) {
            valueFilter = new ValueFilter();
        }

        return valueFilter;
    }

    public void setSearchType(String searchType) {
        this.searchType = searchType;
    }

    // ItemViewHolder Class for Items in each Section
    public class ItemViewHolder extends RecyclerView.ViewHolder {

        final TextView tvFoodName;
        final TextView tvFoodData;

        public ItemViewHolder(View itemView) {
            super(itemView);
            tvFoodName = itemView.findViewById(R.id.tvFoodName);
            tvFoodData = itemView.findViewById(R.id.tvFoodData);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    Utils.printLog("onClick ", getLayoutPosition() + "");
                    Bundle bundle = new Bundle();
                    bundle.putInt("foodId", mFoodItemArrayList.get(getLayoutPosition()).getFoodId());
                    Utils.replaceFragment(mActivity.getFragmentManager(), AddFoodFragment.newInstance(bundle), AddFoodFragment.class.getSimpleName(), true, R.id.fragmentContainerMeal);
                }
            });
        }


    }

    private class ValueFilter extends Filter {
        @Override
        protected FilterResults performFiltering(CharSequence constraint) {
            FilterResults results = new FilterResults();
            // We implement here the filter logic
            if (constraint == null || constraint.length() == 0) {
                // No filter implemented we return all the list
                results.values = mFoodItemArrayList;
                results.count = mFoodItemArrayList.size();
            } else {
                // We perform filtering operation
                List<FoodSearchItem> mStringFilterList = new ArrayList<>();

                for (FoodSearchItem p : mGlobalFoodItemArrayList) {
                    if (p.getFoodName().toLowerCase().contains(constraint.toString().toLowerCase()))
                        mStringFilterList.add(p);
                }

                results.values = mStringFilterList;
                results.count = mStringFilterList.size();
            }


            return results;
        }

        @SuppressWarnings("unchecked")
        @Override
        protected void publishResults(CharSequence constraint, FilterResults results) {


            // Now we have to inform the adapter about the new list filtered
           /* if (results.count == 0)
                notifyDataSetChanged();
            else {*/
                mFoodItemArrayList = (ArrayList<FoodSearchItem>) results.values;
                notifyDataSetChanged();
          //  }


        }

    }
}
