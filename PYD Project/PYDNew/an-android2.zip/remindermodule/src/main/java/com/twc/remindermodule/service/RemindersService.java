package com.twc.remindermodule.service;

import android.app.AlarmManager;
import android.app.IntentService;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.support.v4.app.NotificationCompat;

import com.twc.greendaolib.GreenDaoApp;
import com.twc.greendaolib.ReminderItem;
import com.twc.greendaolib.ReminderItemDao;
import com.twc.greendaolib.ReminderTimeItem;
import com.twc.greendaolib.ReminderTimeItemDao;
import com.twc.remindermodule.receiver.AlarmReceiver;
import com.twc.remindermodule.utils.Constant;
import com.twc.remindermodule.utils.DateFactory;
import com.twc.remindermodule.utils.Utils;

import java.util.Calendar;
import java.util.List;

/**
 * Created by ManishJ1 on 11/18/2016.
 */

public class RemindersService extends IntentService {

    private AlarmManager alarmMgr;
    private boolean isMealReminder = false;

    public RemindersService() {
        super("RemindersService");
    }

    @Override
    public void onCreate() {
        super.onCreate();
        if (Build.VERSION.SDK_INT >= 26) {
            String CHANNEL_ID = Constant.NOTIFICATION_CHANNEL_ID_REMINDERS;
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID,
                    Constant.NOTIFICATION_CHANNEL_NAME_REMINDERS,
                    NotificationManager.IMPORTANCE_HIGH);

            ((NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE)).createNotificationChannel(channel);
            Notification notification = new NotificationCompat.Builder(this, CHANNEL_ID)
                    .setContentTitle("Reminders")
                    .setContentText("App is syncing reminders")
                    .build();

            startForeground(1002, notification);
        }
        alarmMgr = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
    }

    @Override
    protected void onHandleIntent(Intent intent) {
        Utils.printLog("Day onHandleIntent", "onHandleIntent change");
        getRemindersFromDatabase();
    }

    private void getRemindersFromDatabase() {
        ReminderItemDao reminderItemDao = GreenDaoApp.getInstance(this).getDaoSession(this).getReminderItemDao();
        ReminderTimeItemDao reminderTimeItemDao = GreenDaoApp.getInstance(this).getDaoSession(this).getReminderTimeItemDao();
        List<ReminderItem> reminderItems = reminderItemDao.loadAll();
        for (int i = 0; i < reminderItems.size(); i++) {
            List<ReminderTimeItem> reminderTimeItems = reminderTimeItemDao.queryBuilder().where(ReminderTimeItemDao.Properties.ReminderId.eq(reminderItems.get(i).getId())).list();
            String title = reminderItems.get(i).getReminderText();
            for (int k = 0; k < reminderTimeItems.size(); k++) {
                if (reminderItems.get(i).getIsActive() && reminderTimeItems.get(k).getIsActive()) {
                    //String title = reminderTimeItems.get(k).getReminderType();
                    if (reminderTimeItems.get(k).getReminderTime() != null && !reminderTimeItems.get(k).getReminderTime().isEmpty())
                        setNotificationAlarm((int) (long) reminderTimeItems.get(k).getId(), title, "", reminderTimeItems.get(k).getReminderTime());

                }
            }
        }
        stopSelf();
    }

    private void setNotificationAlarm(final int id, String title, String message, String time) {


        Intent intent = new Intent(this, AlarmReceiver.class);
        intent.putExtra("id", id);
        intent.putExtra("title", title);
        intent.putExtra("message", message);
        PendingIntent alarmIntent = PendingIntent.getBroadcast(this, id, intent, PendingIntent.FLAG_UPDATE_CURRENT);

        String formatTime = DateFactory.getInstance().formatTime("hh:mm a", "HH:mm", time);
        String timeArray[] = formatTime.split(":");

        Calendar calendar1 = Calendar.getInstance();
        int hour = calendar1.get(Calendar.HOUR_OF_DAY);
        int minute = calendar1.get(Calendar.MINUTE);


        if (Integer.parseInt(Integer.valueOf(timeArray[0]).toString()) >= hour) {
            if (hour == 0) {
                Utils.printLog("current/time hour", Integer.valueOf(timeArray[0]).toString());
                Utils.printLog("current/time minute", Integer.valueOf(timeArray[1]).toString());
                Calendar calendar = Calendar.getInstance();
                calendar.set(Calendar.HOUR_OF_DAY, Integer.parseInt(Integer.valueOf(timeArray[0]).toString()));
                calendar.set(Calendar.MINUTE, Integer.parseInt(Integer.valueOf(timeArray[1]).toString()));
                calendar.set(Calendar.SECOND, 0);

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                    alarmMgr.setExact(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), alarmIntent);
                } else {
                    alarmMgr.set(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), alarmIntent);
                }
            } else {
                if (Integer.parseInt(Integer.valueOf(timeArray[0]).toString()) == hour) {
                    if (Integer.parseInt(Integer.valueOf(timeArray[1]).toString()) > minute) {
                        Utils.printLog("current/time hour", Integer.valueOf(timeArray[0]).toString());
                        Utils.printLog("current/time minute", Integer.valueOf(timeArray[1]).toString());
                        Calendar calendar = Calendar.getInstance();
                        calendar.set(Calendar.HOUR_OF_DAY, Integer.parseInt(Integer.valueOf(timeArray[0]).toString()));
                        calendar.set(Calendar.MINUTE, Integer.parseInt(Integer.valueOf(timeArray[1]).toString()));
                        calendar.set(Calendar.SECOND, 0);

                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                            alarmMgr.setExact(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), alarmIntent);
                        } else {
                            alarmMgr.set(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), alarmIntent);
                        }
                    }
                } else if (Integer.parseInt(Integer.valueOf(timeArray[0]).toString()) > hour) {
                    Utils.printLog("current/time hour", Integer.valueOf(timeArray[0]).toString());
                    Utils.printLog("current/time minute", Integer.valueOf(timeArray[1]).toString());
                    Calendar calendar = Calendar.getInstance();
                    calendar.set(Calendar.HOUR_OF_DAY, Integer.parseInt(Integer.valueOf(timeArray[0]).toString()));
                    calendar.set(Calendar.MINUTE, Integer.parseInt(Integer.valueOf(timeArray[1]).toString()));
                    calendar.set(Calendar.SECOND, 0);

                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                        alarmMgr.setExact(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), alarmIntent);
                    } else {
                        alarmMgr.set(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), alarmIntent);
                    }
                }


            }
        }

    }

}
