package com.truworth.wellnesscorner.ui.login;

/**
 * Created by rajeshs on 3/26/2018.
 */

public interface LoginCategoryNavigator {
    void logInWithFacebook();

    void logInWithGoogle();

    void loginWithEmail();

}
