package com.twc.store.model.beans;

/**
 * Created by PalakC on 9/18/2017.
 */

public class DataSaveCartItem {

    private SaveItem SaveItems;
    private String message;

    public SaveItem getSaveItems() {
        return SaveItems;
    }

    public void setSaveItems(SaveItem SaveItems) {
        this.SaveItems = SaveItems;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }


}
