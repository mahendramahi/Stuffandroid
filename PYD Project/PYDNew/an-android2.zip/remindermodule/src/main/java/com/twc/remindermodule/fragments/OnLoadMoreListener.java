package com.twc.remindermodule.fragments;

/**
 * If this code works it was written by Somesh Kumar on 08 August, 2016. If not, I don't know who wrote it.
 */
public interface OnLoadMoreListener {
    void onLoadMore();
}
