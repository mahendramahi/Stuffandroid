package com.truworth.wellnesscorner.ui.login;

import com.truworth.wellnesscorner.base.BaseViewModel;
import com.truworth.wellnesscorner.utils.SingleLiveEvent;

/**
 * Created by rajeshs on 3/26/2018.
 */

public class LoginCategoryViewModel extends BaseViewModel {


    public SingleLiveEvent<Void> getCallBottomSheetFB() {
        return callBottomSheetFB;
    }

    public SingleLiveEvent<Void> getCallBottomSheetGoogle() {
        return callBottomSheetGoogle;
    }

    private final SingleLiveEvent<Void> callBottomSheetFB = new SingleLiveEvent<>();

    public SingleLiveEvent<Void> getCallLoginScreen() {
        return callLoginScreen;
    }

    private final SingleLiveEvent<Void> callLoginScreen = new SingleLiveEvent<>();
    private final SingleLiveEvent<Void> callBottomSheetGoogle = new SingleLiveEvent<>();





    public void openGoogleCorporateDialog(){
        callBottomSheetGoogle.call();
    }
    public void openFbCorporateDialog(){
        callBottomSheetFB.call();
    }
    public void openLoginScreenDialog(){
        callLoginScreen.call();
    }

}
