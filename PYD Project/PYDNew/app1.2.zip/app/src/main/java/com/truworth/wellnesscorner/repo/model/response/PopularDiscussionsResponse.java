package com.truworth.wellnesscorner.repo.model.response;

import com.truworth.wellnesscorner.model.Discussions;

import java.util.List;

/**
 * Created by PalakC on 4/19/2018.
 */

public class PopularDiscussionsResponse {

    private boolean hasError;
    private Error error;
    private List<Discussions> data;

    public boolean isHasError() {
        return hasError;
    }

    public void setHasError(boolean hasError) {
        this.hasError = hasError;
    }

    public Error getError() {
        return error;
    }

    public void setError(Error error) {
        this.error = error;
    }

    public List<Discussions> getData() {
        return data;
    }

    public void setData(List<Discussions> data) {
        this.data = data;
    }
}
