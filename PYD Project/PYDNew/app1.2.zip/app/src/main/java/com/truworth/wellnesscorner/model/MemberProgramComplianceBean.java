package com.truworth.wellnesscorner.model;

/**
 * Created by richas on 2/26/2018.
 */

public class MemberProgramComplianceBean {
    private double Program_Compliance;
    private int DayNo;
    private int Total_Days;
    private int RemaningDays;
    private int Total_Peps;
    private int Earned_Peps;

    public double getProgram_Compliance() {
        return Program_Compliance;
    }

    public void setProgram_Compliance(double Program_Compliance) {
        this.Program_Compliance = Program_Compliance;
    }

    public int getDayNo() {
        return DayNo;
    }

    public void setDayNo(int DayNo) {
        this.DayNo = DayNo;
    }

    public int getTotal_Days() {
        return Total_Days;
    }

    public void setTotal_Days(int Total_Days) {
        this.Total_Days = Total_Days;
    }

    public int getRemaningDays() {
        return RemaningDays;
    }

    public void setRemaningDays(int RemaningDays) {
        this.RemaningDays = RemaningDays;
    }

    public int getTotal_Peps() {
        return Total_Peps;
    }

    public void setTotal_Peps(int Total_Peps) {
        this.Total_Peps = Total_Peps;
    }

    public int getEarned_Peps() {
        return Earned_Peps;
    }

    public void setEarned_Peps(int Earned_Peps) {
        this.Earned_Peps = Earned_Peps;
    }
}
