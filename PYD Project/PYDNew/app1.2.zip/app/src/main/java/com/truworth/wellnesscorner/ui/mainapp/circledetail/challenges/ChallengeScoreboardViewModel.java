package com.truworth.wellnesscorner.ui.mainapp.circledetail.challenges;


import android.content.Context;
import android.databinding.ObservableBoolean;
import android.databinding.ObservableField;
import android.databinding.ObservableInt;
import android.graphics.drawable.Drawable;

import com.truworth.wellnesscorner.R;
import com.truworth.wellnesscorner.TheWellnessCornerApp;
import com.truworth.wellnesscorner.base.BaseViewModel;
import com.truworth.wellnesscorner.model.ChallengeLeaderboardBean;
import com.truworth.wellnesscorner.repo.DashboardRepository;
import com.truworth.wellnesscorner.repo.model.request.ChallengeLeaderBoardRequest;
import com.truworth.wellnesscorner.repo.model.request.MyRankRequest;
import com.truworth.wellnesscorner.repo.model.response.ChallengeLeaderBoardResponse;
import com.truworth.wellnesscorner.repo.model.response.MyRankResponse;
import com.truworth.wellnesscorner.utils.SingleLiveEvent;
import com.twc.dailylog.utils.Constant;

import java.util.List;
import java.util.logging.Handler;

import javax.inject.Inject;

import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;

public class ChallengeScoreboardViewModel extends BaseViewModel {

    public ObservableField<String> member1Name = new ObservableField<>();
    public ObservableField<String> member2Name = new ObservableField<>();
    public ObservableField<String> member3Name = new ObservableField<>();
    public ObservableField<String> member1Image = new ObservableField<>();
    public ObservableField<String> member2Image = new ObservableField<>();
    public ObservableField<String> member3Image = new ObservableField<>();
    public ObservableInt member1Steps = new ObservableInt();
    public ObservableInt member2Steps = new ObservableInt();
    public ObservableInt member3Steps = new ObservableInt();
    public ObservableInt member1rank = new ObservableInt();
    public ObservableInt member2rank = new ObservableInt();
    public ObservableInt member3rank = new ObservableInt();
    public ObservableInt member1prevoiusRank = new ObservableInt();
    public ObservableInt member2prevoiusRank = new ObservableInt();
    public ObservableInt member3prevoiusRank = new ObservableInt();


    public SingleLiveEvent<Void> clearList = new SingleLiveEvent<>();

    public SingleLiveEvent<Void> getClearList() {
        return clearList;
    }

    public boolean scrollGap = false;
    public int page = 1;
    public int upPageIndex = -1;
    public boolean loading;
    public boolean isLastResult = false;
    int myRank;
    int myRankPageIndex;
    public int challengeTypeId;

    public int getChallengeTypeId() {
        return challengeTypeId;
    }

    public void setChallengeTypeId(int challengeTypeId) {
        this.challengeTypeId = challengeTypeId;
    }

    SingleLiveEvent<Void> scrollToMyPos = new SingleLiveEvent<>();

    public SingleLiveEvent<Void> getScrollToMyPos() {
        return scrollToMyPos;
    }

    SingleLiveEvent<Integer> resultRating1 = new SingleLiveEvent<>();

    public SingleLiveEvent<Integer> getResultRating1() {
        return resultRating1;
    }

    SingleLiveEvent<Integer> resultRating2 = new SingleLiveEvent<>();

    public SingleLiveEvent<Integer> getResultRating2() {
        return resultRating2;
    }

    SingleLiveEvent<Integer> resultRating3 = new SingleLiveEvent<>();

    public SingleLiveEvent<Integer> getResultRating3() {
        return resultRating3;
    }

    public SingleLiveEvent<Void> removeLoading = new SingleLiveEvent<>();

    //public SingleLiveEvent<Void> showTopBar = new SingleLiveEvent<>();

    public SingleLiveEvent<Void> getRemoveLoading() {
        return removeLoading;
    }

//    public SingleLiveEvent<Void> getTopBarVisibilty() {
//        return showTopBar;
//    }

    public SingleLiveEvent<List<ChallengeLeaderboardBean>> challengeLeaderBoard = new SingleLiveEvent<>();

    public SingleLiveEvent<List<ChallengeLeaderboardBean>> getChallengeLeaderBoard() {
        return challengeLeaderBoard;
    }

    SingleLiveEvent<Void> upArrow = new SingleLiveEvent<>();

    public SingleLiveEvent<Void> getUpArrow() {
        return upArrow;
    }

    public ObservableBoolean showMember1Data = new ObservableBoolean();
    public ObservableBoolean showMember2Data = new ObservableBoolean();
    public ObservableBoolean showMember3Data = new ObservableBoolean();
    public ObservableBoolean showListData = new ObservableBoolean();

    public ObservableBoolean hideTopMembers = new ObservableBoolean();

    @Inject
    DashboardRepository dashboardRepository;

    public ChallengeScoreboardViewModel() {
        TheWellnessCornerApp.getApp().component().inject(this);
    }

    private int prevPageIndex;
    private String prevChallengeIdentity;

    public int getPrevPageIndex() {
        return prevPageIndex;
    }

    public void loadChallengeLeaderBoardData(String challengeIdentity, int pageIndex, String mTabType) {

        ChallengeLeaderBoardRequest challengeLeaderBoardRequest = new ChallengeLeaderBoardRequest();
        challengeLeaderBoardRequest.setId(challengeIdentity);
        challengeLeaderBoardRequest.setPageIndex(pageIndex);
        if (mTabType.equalsIgnoreCase(ChallengeLeaderBoardActivity.ALL_TIME)) {
            challengeLeaderBoardRequest.setToday(false);
        } else {
            challengeLeaderBoardRequest.setToday(true);
        }
        prevChallengeIdentity = challengeIdentity;

        dashboardRepository.getLeaderBoardData(challengeLeaderBoardRequest).subscribe(new Observer<ChallengeLeaderBoardResponse>() {
            @Override
            public void onSubscribe(Disposable d) {

            }

            @Override
            public void onNext(ChallengeLeaderBoardResponse response) {
                removeLoading.call();
                loading = false;

                if (!response.isHasError()) {

                    //set data in list pagewise

                    // setting top 3 members data
                    List<ChallengeLeaderboardBean> listLeaderBoard = response.getData().getChallengeLeaderboard();
                    if (pageIndex == 1) {
                        if (response.getData().getChallengeLeaderboard().size() > 0) {
                            member1Name.set(response.getData().getChallengeLeaderboard().get(0).getName());
                            member1Steps.set(response.getData().getChallengeLeaderboard().get(0).getPoints());
                            member1Image.set(response.getData().getChallengeLeaderboard().get(0).getImage());
                            member1rank.set(response.getData().getChallengeLeaderboard().get(0).getRank());
                            member1prevoiusRank.set(response.getData().getChallengeLeaderboard().get(0).getRankPrevious());

                            resultRating1.setValue(member1rank.get() - member1prevoiusRank.get());
                            showMember1Data.set(true);
                        }
                        if (response.getData().getChallengeLeaderboard().size() > 1) {
                            member2Name.set(response.getData().getChallengeLeaderboard().get(1).getName());
                            member2Steps.set(response.getData().getChallengeLeaderboard().get(1).getPoints());
                            member2Image.set(response.getData().getChallengeLeaderboard().get(1).getImage());
                            member2rank.set(response.getData().getChallengeLeaderboard().get(1).getRank());
                            member2prevoiusRank.set(response.getData().getChallengeLeaderboard().get(1).getRankPrevious());

                            resultRating2.setValue(member2rank.get() - member2prevoiusRank.get());
                            showMember2Data.set(true);
                        }
                        if (response.getData().getChallengeLeaderboard().size() > 2) {
                            member3Name.set(response.getData().getChallengeLeaderboard().get(2).getName());
                            member3Steps.set(response.getData().getChallengeLeaderboard().get(2).getPoints());
                            member3Image.set(response.getData().getChallengeLeaderboard().get(2).getImage());
                            member3rank.set(response.getData().getChallengeLeaderboard().get(2).getRank());
                            member3prevoiusRank.set(response.getData().getChallengeLeaderboard().get(2).getRankPrevious());

                            resultRating3.setValue(member3rank.get() - member3prevoiusRank.get());
                            showMember3Data.set(true);
                        }
                        if (listLeaderBoard.size() > 2) {
                            listLeaderBoard.subList(0, 3).clear();
                        }
                    }
                    challengeLeaderBoard.setValue(listLeaderBoard);
                    showListData.set(true);

                } else {
                    isLastResult = true;
                }
            }

            @Override
            public void onError(Throwable e) {
                removeLoading.call();
            }

            @Override
            public void onComplete() {

            }
        });
    }


    public void getMyRankData() {
        isLastResult = false;
        prevPageIndex = page;
        MyRankRequest myRankRequest = new MyRankRequest();
        myRankRequest.setId(prevChallengeIdentity);
        //challengeLeaderBoardRequest.setPageIndex(pageIndex);
        myRankRequest.setToday(false);

        dashboardRepository.getMyRank(myRankRequest).subscribe(new Observer<MyRankResponse>() {
            @Override
            public void onSubscribe(Disposable d) {

            }

            @Override
            public void onNext(MyRankResponse response) {

                //showTopBar.call();
                removeLoading.call();
                loading = false;

                if (!response.isHasError()) {

                    //set data in list pagewise


                    myRank = response.getData().getRank();
                    myRankPageIndex = response.getData().getPageIndex();
                    if (prevPageIndex < myRankPageIndex) {
                        challengeLeaderBoard.getValue().clear();
                        clearData();
                        challengeLeaderBoard.setValue(response.getData().getChallengeLeaderboard());

                        page = myRankPageIndex;
                        upPageIndex = myRankPageIndex;
                        new android.os.Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                //showTopBar.call();
                                hideTopMembers.set(true);
                                scrollToMyPos.call();
                            }
                        }, Constant.API_POST_DELAYED_TIME);


                    } else {
                        if(myRank>3){
                            //showTopBar.call();
                            hideTopMembers.set(true);
                            scrollToMyPos.call();
                        }
                    }


                } else {
                    isLastResult = true;
                }
            }

            @Override
            public void onError(Throwable e) {
                removeLoading.call();
            }

            @Override
            public void onComplete() {

            }
        });
    }

    public void getScrollPosition() {
        scrollToMyPos.call();
    }

    public void upArrowClick() {
        upArrow.call();
    }

    public String getTypeIdData() {
        String typeIdData = "";

        if (getChallengeTypeId() == 1)
            typeIdData = "steps";
        else
            typeIdData = "check-in";

        return typeIdData;
    }

    public void clearData() {
        clearList.call();
    }


}
