package com.truworth.wellnesscorner.model;

import java.io.Serializable;

public class ExerciseData implements Serializable {
        private String name;
        private double duration;
        private double calorie;

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public double getDuration() {
            return duration;
        }

        public void setDuration(double duration) {
            this.duration = duration;
        }

        public double getCalorie() {
            return calorie;
        }

        public void setCalorie(double calorie) {
            this.calorie = calorie;
        }
}
