package com.twc.dailylog.model.response;

/**
 * Created by PalakC on 8/9/2016.
 */
public class SaveTargetWeightResponse {


    /**
     * status : 0
     */

    private int status;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }
}
