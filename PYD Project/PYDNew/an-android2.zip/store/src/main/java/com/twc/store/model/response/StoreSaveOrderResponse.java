package com.twc.store.model.response;


import com.twc.store.model.beans.StoreSaveOrderBean;

/**
 * Created by richas on 9/18/2017.
 */

public class StoreSaveOrderResponse {


    private int status;
    private StoreSaveOrderBean Data;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public StoreSaveOrderBean getData() {
        return Data;
    }

    public void setData(StoreSaveOrderBean Data) {
        this.Data = Data;
    }


}
