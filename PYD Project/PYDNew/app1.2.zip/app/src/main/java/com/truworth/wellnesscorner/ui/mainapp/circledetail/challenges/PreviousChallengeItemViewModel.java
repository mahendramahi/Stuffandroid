package com.truworth.wellnesscorner.ui.mainapp.circledetail.challenges;

import com.truworth.wellnesscorner.base.BaseViewModel;
import com.truworth.wellnesscorner.model.PreviousChallengesBean;
import com.truworth.wellnesscorner.utils.DateUtils;

public class PreviousChallengeItemViewModel extends BaseViewModel {
    PreviousChallengesBean previousChallenge;
    public MyChallengeListener myChallengeListener;
    String postMapId;

    public PreviousChallengeItemViewModel(PreviousChallengesBean previousChallenge, MyChallengeListener myChallengeListener, String postMapId) {
        this.previousChallenge = previousChallenge;
        this.myChallengeListener = myChallengeListener;
        this.postMapId = postMapId;
    }

    public PreviousChallengesBean getPreviousChallenge() {
        return previousChallenge;
    }

    public void setPreviousChallenge(PreviousChallengesBean previousChallenge) {
        this.previousChallenge = previousChallenge;
    }

    public String getDateinFormat(String date) {
        String newDateString = "";
        if (date != null)
            newDateString = DateUtils.formatDate(date, "yyyy-MM-dd'T'HH:mm:ss", "MMMM dd,yyyy");

        return newDateString;
    }

    public String getChallengeType(int challengeTypeId) {
        String typeString = "";

        if (challengeTypeId == 1)
            typeString = ", Check-Ins - ";
        else
            typeString = ", Steps - ";

        return typeString;
    }

    public void onItemClick() {
        myChallengeListener.onItemClick(previousChallenge, postMapId);
    }

    public interface MyChallengeListener {

        void onItemClick(PreviousChallengesBean onGoingChallenge, String postMapId);
    }
}
