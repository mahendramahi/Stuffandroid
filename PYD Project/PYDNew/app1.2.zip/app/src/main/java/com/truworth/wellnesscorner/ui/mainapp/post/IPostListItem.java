package com.truworth.wellnesscorner.ui.mainapp.post;

import java.io.Serializable;

public interface IPostListItem extends Serializable{
    int TYPE_TODAY_DASHBOARD=100;
    int TYPE_SHARE = 101;
    int TYPE_POST = 102;
    int TYPE_VIEW_PREVIOUS = 103;
    int TYPE_COMMENT = 104;

    int getPostListItemType();
}
