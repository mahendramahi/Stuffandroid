package com.twc.greendaolib;

import android.app.Application;
import android.content.Context;

import org.greenrobot.greendao.database.Database;


/**
 * Created by ManishJ1 on 4/3/2018.
 */

public class GreenDaoApp {

    private DaoSession daoSession;
    private static GreenDaoApp greenDaoApp;

    private GreenDaoApp(Context context) {
        getDaoSession(context);
    }

    public static GreenDaoApp getInstance(Context context){
        if(greenDaoApp == null){
            greenDaoApp = new GreenDaoApp(context);
        }
        return greenDaoApp;
    }


    public DaoSession getDaoSession(Context context) {
        if (daoSession == null) {
            DaoMaster.DevOpenHelper helper = new DaoMaster.DevOpenHelper(context, "obinix-db");
            Database db = helper.getWritableDb();
            if (db != null) {
                daoSession = new DaoMaster(db).newSession();
            }
        }
        return daoSession;
    }
}
