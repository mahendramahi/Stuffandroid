package com.truworth.stepmodule.rest;

import android.content.Context;


import com.truworth.stepmodule.utils.Constant;

import java.io.IOException;

import okhttp3.Interceptor;
import okhttp3.Request;
import okhttp3.Response;

public class FitBitInterceptor implements Interceptor {
    private Context context;
    private String type;
    private String token;

    public FitBitInterceptor(Context context, String type,String token) {
        this.context = context;
        this.type=type;
        this.token = token;
    }

    @Override
    public Response intercept(Chain chain) throws IOException {
        Request originalRequest = chain.request();
        Request.Builder request = originalRequest.newBuilder();
        Response response;
        if (type.equalsIgnoreCase(Constant.FITBIT)) {
            response = chain.proceed(request.addHeader("Authorization", token).build());
        }else
            response = chain.proceed(request.addHeader("access_token", token).build());

        return response;
    }

}
