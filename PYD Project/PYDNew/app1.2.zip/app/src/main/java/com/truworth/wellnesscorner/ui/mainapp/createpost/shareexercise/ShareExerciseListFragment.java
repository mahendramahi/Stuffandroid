package com.truworth.wellnesscorner.ui.mainapp.createpost.shareexercise;

import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import com.truworth.wellnesscorner.BR;
import com.truworth.wellnesscorner.R;
import com.truworth.wellnesscorner.TheWellnessCornerApp;
import com.truworth.wellnesscorner.base.BaseFragment;
import com.truworth.wellnesscorner.data.SharedPreferenceHelper;
import com.truworth.wellnesscorner.databinding.FragmentShareMealBinding;
import com.truworth.wellnesscorner.interfaces.OnLoadMoreListener;
import com.truworth.wellnesscorner.model.ShareExerciseBean;
import com.truworth.wellnesscorner.ui.mainapp.createpost.ShareActivity;
import com.truworth.wellnesscorner.ui.mainapp.createpost.sharemeal.ShareMealViewModel;
import com.truworth.wellnesscorner.utils.AppConstants;
import com.twc.dailylog.MealActivity;
import com.twc.dailylog.model.beans.DailyLogUser;
import com.twc.dailylog.utils.DailyLogConfig;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

public class ShareExerciseListFragment extends BaseFragment<FragmentShareMealBinding, ShareMealViewModel> {
    public static final String TAG = "ShareExerciseListFragment";
    private final int visibleThreshold = 5;
    ShareMealViewModel viewModel;
    private List<ShareExerciseBean> exerciseHeaderList;
    private FragmentShareMealBinding binding;
    private boolean isLoadMore = false;
    private ShareExerciseListAdapter exerciseListAdapter;
    @Inject
    SharedPreferenceHelper prefHelper;
    private int page = 1;
    private int lastVisibleItem, totalItemCount;
    private OnLoadMoreListener onLoadMoreListener;
    private Handler handler = new Handler();
    private Runnable runnableApiCall = new Runnable() {
        @Override
        public void run() {
            viewModel.isLastResult = false;
            viewModel.loading = false;
            if (page == 1) {
                exerciseHeaderList.clear();
            }
            exerciseListAdapter.notifyDataSetChanged();
            viewModel.loadPostExerciseData(page);
        }
    };

    public static ShareExerciseListFragment newInstance() {
        ShareExerciseListFragment fragment = new ShareExerciseListFragment();
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        TheWellnessCornerApp.getApp().component().inject(this);
        exerciseHeaderList = new ArrayList<>();
        exerciseListAdapter = new ShareExerciseListAdapter(getActivity(),exerciseHeaderList,getFragmentManager());

        handler.postDelayed(runnableApiCall, 100);
    }

    @Override
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        binding = getViewDataBinding();
        binding.tvTrackTodayMeal.setText("Track your today’s exercise");

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getActivity());
        binding.rvShareMeal.setLayoutManager(linearLayoutManager);
        binding.rvShareMeal.setAdapter(exerciseListAdapter);
        setOnLoadMoreListener(linearLayoutManager);
        //handler.postDelayed(runnableApiCall, 100);
        setHeaderDataObserver();
        attachRemoveLoadingObserver();

    }
    @Override
    public int getBindingVariable() {
        return BR.viewModel;
    }

    @Override
    public int getLayoutId() {
        return R.layout.fragment_share_meal;
    }

    @Override
    public ShareMealViewModel getViewModel() {
        viewModel = ViewModelProviders.of(this).get(ShareMealViewModel.class);
        return viewModel;
    }

    private void setHeaderDataObserver() {
        viewModel.getExerciseHeaderList().observe(this, new Observer<List<ShareExerciseBean>>() {
            @Override
            public void onChanged(@Nullable List<ShareExerciseBean> shareExerciseBeans) {
                exerciseHeaderList.clear();
                exerciseHeaderList.addAll(shareExerciseBeans);
                exerciseListAdapter.notifyDataSetChanged();
            }
        });
       viewModel.getTrackTodayMeal().observe(this, new Observer<Void>() {
            @Override
            public void onChanged(@Nullable Void aVoid) {
                //Success, update UI

                DailyLogConfig.dailyLogUser.setType("Exercise");
                DailyLogConfig.dailyLogUser.setMealType("");
                Intent intent = new Intent(getActivity(), MealActivity.class);
                startActivityForResult(intent, AppConstants.ADD_FOOD_DAILY_LOG);
                //startActivity(intent);
            }
        });
    }

    private void attachRemoveLoadingObserver() {
        viewModel.getRemoveLoading().observe(this, new Observer<Void>() {
            @Override
            public void onChanged(@Nullable Void aVoid) {
                if (exerciseHeaderList.size() > 0 && exerciseHeaderList.get(exerciseHeaderList.size() - 1) == null) {
                    exerciseHeaderList.remove(exerciseHeaderList.size() - 1);
                    exerciseListAdapter.notifyDataSetChanged();
                }
            }
        });
    }

    private void setOnLoadMoreListener(final LinearLayoutManager linearLayoutManager) {
        onLoadMoreListener = new OnLoadMoreListener() {
            @Override
            public void onLoadMore() {
                if (!viewModel.isLastResult) {
                    if (exerciseHeaderList.size() > 5) {
                        isLoadMore = true;
                        exerciseHeaderList.add(null);
                        exerciseListAdapter.notifyItemInserted(exerciseHeaderList.size() - 1);
                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {

                                page = page + 1;
                                handler.postDelayed(runnableApiCall, 100);
                            }

                        }, 500);
                    } else {
                        //showNetWorkDialog();
                    }

                }
            }
        };

        binding.rvShareMeal.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                totalItemCount = linearLayoutManager.getItemCount();
                lastVisibleItem = linearLayoutManager.findLastVisibleItemPosition();
                if (!viewModel.loading && totalItemCount <= (lastVisibleItem + visibleThreshold)) {
                    onLoadMoreListener.onLoadMore();
                    viewModel.loading = true;
                }
            }
        });
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (exerciseHeaderList != null) {
            exerciseHeaderList.clear();
            exerciseListAdapter.notifyDataSetChanged();
            exerciseListAdapter = null;
            exerciseHeaderList = null;
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        viewModel.loadPostExerciseData(1);
    }
}
