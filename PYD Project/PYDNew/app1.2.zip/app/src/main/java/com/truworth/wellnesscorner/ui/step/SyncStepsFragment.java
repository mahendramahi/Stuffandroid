package com.truworth.wellnesscorner.ui.step;

import android.app.Fragment;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.DatePicker;
import android.widget.LinearLayout;

import com.truworth.stepmodule.StepHelper;
import com.truworth.stepmodule.inteface.OnRangeStepsFound;
import com.truworth.stepmodule.inteface.OnTodayStepsFound;
import com.truworth.stepmodule.model.EFitMonthStepsBody;
import com.truworth.stepmodule.model.EFitMonthStepsResponse;
import com.truworth.stepmodule.model.FitBitStepsItem;
import com.truworth.stepmodule.model.StepItem;
import com.truworth.stepmodule.rest.FitBitRestClient;
import com.truworth.stepmodule.utils.FitBitConfig;
import com.truworth.wellnesscorner.R;
import com.truworth.wellnesscorner.TheWellnessCornerApp;
import com.truworth.wellnesscorner.customviews.CustomProgressDialog;
import com.truworth.wellnesscorner.customviews.CustomTextView;
import com.truworth.wellnesscorner.data.SharedPreferenceHelper;
import com.truworth.wellnesscorner.repo.StepRepository;

import com.truworth.wellnesscorner.repo.model.request.SaveDeviceStepsBody;
import com.truworth.wellnesscorner.repo.model.response.SaveStepsResponse;
import com.truworth.wellnesscorner.utils.AppConstants;
import com.truworth.wellnesscorner.utils.CommonUtils;
import com.truworth.wellnesscorner.utils.DateUtils;
import com.truworth.wellnesscorner.utils.Utils;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SyncStepsFragment extends Fragment {
    @Inject
    StepRepository repository;
    @BindView(R.id.rootLayout)
    LinearLayout rootLayout;

    @BindView(R.id.tvSyncStartDate)
    CustomTextView tvSyncStartDate;

    @BindView(R.id.tvSyncEndDate)
    CustomTextView tvSyncEndDate;

    @BindView(R.id.syncStartDateLayout)
    LinearLayout syncStartDateLayout;

    @BindView(R.id.syncEndDateLayout)
    LinearLayout syncEndDateLayout;

    @BindView(R.id.tvSyncNow)
    CustomTextView tvSyncNow;
    private int mMonth, mDay, mYear;
    private boolean isStartDate;
    private long startDate;
    private long endDate;
    private CustomProgressDialog pd;
    private OnStepSync onStepSync;
    private String connectedDeviceType;
    private boolean isFromSyncNowButtonPressed;
    private StepHelper stepHelper;
    @Inject
    SharedPreferenceHelper prefHelper;
    private String accessToken;
    private String[] dobArray;

    private android.app.DatePickerDialog.OnDateSetListener ondate = new android.app.DatePickerDialog.OnDateSetListener() {
        @Override
        public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
            if (DateUtils.isFutureDate(dayOfMonth, monthOfYear, year)) {
                CommonUtils.showAlertDialog(getActivity(), null, 0, getString(R.string.err_invalid_date), getString(R.string.str_ok), false);
            } else {
                mMonth = monthOfYear + 1;
                mYear = year;
                mDay = dayOfMonth;
                monthOfYear = monthOfYear + 1;
                StringBuilder date = new StringBuilder();

                date.append(year);
                if (monthOfYear < 10) {
                    date.append("0").append(monthOfYear).append(dayOfMonth);
                } else {
                    date.append(monthOfYear).append(dayOfMonth);
                }
                String formattedDate = DateUtils.getInstance().formatDateStep(AppConstants.DATE_FORMAT_YYYYMMDD, AppConstants.DATE_FORMAT_MM_DD_YYYY_FORWARD_SLASH, date.toString());
                if (isStartDate) {
                    startDate = DateUtils.getInstance().getMillisFromStringDate(formattedDate, AppConstants.DATE_FORMAT_MM_DD_YYYY_FORWARD_SLASH);
                    tvSyncStartDate.setText(formattedDate);
                } else {
                    endDate = DateUtils.getInstance().getMillisFromStringDate(formattedDate, AppConstants.DATE_FORMAT_MM_DD_YYYY_FORWARD_SLASH);
                    tvSyncEndDate.setText(formattedDate);
                }
            }

        }
    };

    public SyncStepsFragment() {
        TheWellnessCornerApp.getApp().component().inject(this);
    }

    public static SyncStepsFragment newInstance() {
        SyncStepsFragment syncStepsFragment = new SyncStepsFragment();
        return syncStepsFragment;

    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Calendar calendar = Calendar.getInstance();
        mDay = calendar.get(Calendar.DAY_OF_MONTH);
        mMonth = calendar.get(Calendar.MONTH);
        mYear = calendar.get(Calendar.YEAR);
        if (prefHelper.getPrefKeyDeviceConnected().equalsIgnoreCase(AppConstants.FITBIT))
            accessToken = prefHelper.getPrefKeyFitBitAccessToken();
        else if (prefHelper.getPrefKeyDeviceConnected().equalsIgnoreCase(AppConstants.MISFIT))
            accessToken = prefHelper.getPrefKeyMisFitAccessToken();


        stepHelper = new StepHelper(getActivity(), accessToken);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_sync_steps, container, false);
        ButterKnife.bind(this, rootView);

        onStepSync = new OnStepSync() {
            @Override
            public void OnStepSynced() {
                Utils.showToast(getActivity(), "Steps sync successfully");
                getFragmentManager().popBackStackImmediate(StepsTrackerFragment.class.getSimpleName(), 0);
            }
        };
        pd = new CustomProgressDialog(getActivity(), R.style.custom_progress_style, true);

        connectedDeviceType = prefHelper.getPrefKeyDeviceConnected();

        isStartDate = true;
        String todayDate = DateUtils.getInstance().getTodayDate(AppConstants.DATE_FORMAT_MM_DD_YYYY_FORWARD_SLASH);
        startDate = DateUtils.getInstance().getMillisFromStringDate(todayDate, AppConstants.DATE_FORMAT_MM_DD_YYYY_FORWARD_SLASH);
        endDate = startDate;
        tvSyncStartDate.setText(todayDate);
        tvSyncEndDate.setText(todayDate);
        return rootView;
    }

    @Override
    public void onResume() {
        super.onResume();
        ((StepActivity) getActivity()).setToolBarTitle("Sync Steps");
        ((StepActivity) getActivity()).showHomeAsUpEnableToolbar();
    }

    @OnClick({R.id.tvSyncNow, R.id.syncStartDateLayout, R.id.syncEndDateLayout})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.tvSyncNow:

                if (TheWellnessCornerApp.getInstance().getStepServerResponse() != null
                        && TheWellnessCornerApp.getInstance().getStepServerResponse().getData() != null
                        && TheWellnessCornerApp.getInstance().getStepServerResponse().getData().getFirstStepSyncDate() != null) {
                    String firstStepSyncDate = DateUtils.getInstance().truncateMilliseconds(TheWellnessCornerApp.getInstance().getStepServerResponse().getData().getFirstStepSyncDate());
                    long syncDateMillis = DateUtils.getInstance().getMillisFromStringDate(firstStepSyncDate, AppConstants.SERVER_DATE_FORMAT_WITH_MILLISECONDS);
                    long mSyncDateMillis = DateUtils.getInstance().getStartTimeOfGivenDay(syncDateMillis);

                    long startDateMillis = DateUtils.getInstance().getMillisFromStringDate(tvSyncStartDate.getText().toString(), AppConstants.DATE_FORMAT_MM_DD_YYYY_FORWARD_SLASH);
                    if (startDateMillis >= mSyncDateMillis) {
                        if (isFromSyncNowButtonPressed) {
                            Utils.showToast(getActivity(), "Please wait sync is already in progress");
                        } else {
                            pd.show();
                            isFromSyncNowButtonPressed = true;
                            long maxNoOfDays = DateUtils.getInstance().getDaysDifferenceStep(tvSyncStartDate.getText().toString().trim(), tvSyncEndDate.getText().toString().trim(), "MM/dd/yyyy");
                            if (maxNoOfDays > 0 && maxNoOfDays <= 30)
                            {

                                syncSteps();
                            }
                            else if (maxNoOfDays == 0)
                                syncTodaySteps();
                            else if (maxNoOfDays < 0) {
                                removeProgress();
                                CommonUtils.showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_invalid_end_date), getString(R.string.str_ok), false);
                            } else if (maxNoOfDays > 30) {
                                removeProgress();
                                CommonUtils.showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_not_sync_30days), getString(R.string.str_ok), false);
                            }
                        }
                    } else {
                        removeProgress();
                        CommonUtils.showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_date_selected_before_first_date), getString(R.string.str_ok), false);
                    }
                }
                break;
            case R.id.syncStartDateLayout:
                isStartDate = true;
                openSyncDateDialog(tvSyncStartDate.getText().toString().trim());
                break;
            case R.id.syncEndDateLayout:
                isStartDate = false;
                openSyncDateDialog(tvSyncEndDate.getText().toString().trim());
                break;
        }
    }

    private void syncSteps() {
        if (getActivity() != null && isAdded()) {
            if (connectedDeviceType != null && connectedDeviceType.length() > 0) {
                if (connectedDeviceType.equalsIgnoreCase(AppConstants.GOOGLE_FIT)) {
                    stepHelper.getStepsFromGoogle(startDate, endDate, new OnRangeStepsFound() {
                        @Override
                        public void onRangeStepsFound(ArrayList<StepItem> foundStepList) {

                            prefHelper.setPrefKeyDeviceConnected(AppConstants.GOOGLE_FIT);
                            prefHelper.clearDeviceConnectTokenPreferences();
                            ArrayList<StepsBean> stepsBeanList = new ArrayList<>();
                            for (StepItem stepItem : foundStepList) {
                                //String date = DateUtils.formatDateStep(AppConstants.DATE_FORMAT_YYYY_MM_DD, AppConstants.DATE_FORMAT_MM_DD_YYYY_HHMM_FORWARD_SLASH, stepItem.getStepTime());
                                StepsBean stepsBean = new StepsBean();
                                stepsBean.setSteps(Integer.parseInt(stepItem.getStepCount()));
                                stepsBean.setStepsDate(stepItem.getStepTime());
                                stepsBean.setCalories(stepItem.getCalories());
                                stepsBean.setActivityDate(stepItem.getStepTime());
                                stepsBeanList.add(stepsBean);
                            }

                            saveStepsToServer(onStepSync, AppConstants.GOOGLE_FIT, stepsBeanList, stepsBeanList);
                        }

                        @Override
                        public void onStepsFoundError(String error) {

                        }
                    });
                } else if (connectedDeviceType.equalsIgnoreCase(AppConstants.E_FIT)) {
                   getEFitStepsForSync();
                } else if (connectedDeviceType.equalsIgnoreCase(AppConstants.S_HEALTH)) {
                    stepHelper.getStepsFromSamsung(startDate, endDate, new OnRangeStepsFound() {
                        @Override
                        public void onRangeStepsFound(ArrayList<StepItem> foundStepList) {
                            prefHelper.setPrefKeyDeviceConnected(AppConstants.S_HEALTH);
                            prefHelper.clearDeviceConnectTokenPreferences();
                            ArrayList<StepsBean> stepsBeanList = new ArrayList<>();
                            for (StepItem stepItem : foundStepList) {
                                //String date = DateUtils.formatDateStep(AppConstants.DATE_FORMAT_YYYY_MM_DD, AppConstants.DATE_FORMAT_MM_DD_YYYY_HHMM_FORWARD_SLASH, stepItem.getStepTime());
                                StepsBean stepsBean = new StepsBean();
                                stepsBean.setSteps(Integer.parseInt(stepItem.getStepCount()));
                                stepsBean.setStepsDate(stepItem.getStepTime());
                                stepsBean.setCalories(stepItem.getCalories());
                                stepsBean.setActivityDate(stepItem.getStepTime());
                                stepsBeanList.add(stepsBean);
                            }

                            saveStepsToServer(onStepSync, AppConstants.S_HEALTH, stepsBeanList, stepsBeanList);
                        }

                        @Override
                        public void onStepsFoundError(String error) {

                        }
                    });
                } else if (connectedDeviceType.equalsIgnoreCase(AppConstants.FITBIT)) {
                    stepHelper.getStepsFromFitbit(startDate, endDate, new OnRangeStepsFound() {
                        @Override
                        public void onRangeStepsFound(ArrayList<StepItem> foundStepList) {
                            final ArrayList<StepsBean> stepsBeanList = new ArrayList<>();
                            for (StepItem stepItem : foundStepList) {
                                StepsBean stepsBean = new StepsBean();
                                stepsBean.setCalories(stepItem.getCalories());
                                stepsBean.setSteps(Integer.parseInt(stepItem.getStepCount()));

                                //String date = DateUtils.formatDateStep(AppConstants.DATE_FORMAT_YYYY_MM_DD, AppConstants.DATE_FORMAT_MM_DD_YYYY_HHMM_FORWARD_SLASH, stepItem.getStepTime());
                                stepsBean.setStepsDate(stepItem.getStepTime());
                                stepsBean.setActivityDate(stepItem.getStepTime());
                                stepsBeanList.add(stepsBean);
                            }


                            saveStepsToServer(onStepSync, AppConstants.FITBIT, stepsBeanList, stepsBeanList);
                        }

                        @Override
                        public void onStepsFoundError(String error) {

                        }
                    });
                } else if (connectedDeviceType.equalsIgnoreCase(AppConstants.MISFIT)) {
                    stepHelper.getStepsFromMisfit(startDate, endDate, new OnRangeStepsFound() {
                        @Override
                        public void onRangeStepsFound(ArrayList<StepItem> foundStepList) {

                            final ArrayList<StepsBean> stepsBeanList = new ArrayList<>();
                            for (StepItem stepItem : foundStepList) {
                                StepsBean stepsBean = new StepsBean();
                                stepsBean.setCalories(stepItem.getCalories());
                                stepsBean.setSteps(Integer.parseInt(stepItem.getStepCount()));

                               // String date = DateUtils.formatDateStep(AppConstants.DATE_FORMAT_YYYY_MM_DD, AppConstants.DATE_FORMAT_MM_DD_YYYY_HHMM_FORWARD_SLASH, stepItem.getStepTime());
                                stepsBean.setStepsDate(stepItem.getStepTime());
                                stepsBean.setActivityDate(stepItem.getStepTime());
                                stepsBeanList.add(stepsBean);
                            }


                            saveStepsToServer(onStepSync, AppConstants.MISFIT, stepsBeanList, stepsBeanList);

                        }

                        @Override
                        public void onStepsFoundError(String error) {

                        }
                    });
                } else if (connectedDeviceType.equalsIgnoreCase(AppConstants.GARMIN)) {
                    //  long startTime = DateFactory.getInstance().getEpochFromStringDate(DateFactory.getInstance().formatDate(Constant.DATE_FORMAT_MM_DD_YYYY_FORWARD_SLASH, "yyyy-MM-dd HH:mm:ss.SSS zzz", tvSyncStartDate.getText().toString()), "yyyy-MM-dd HH:mm:ss.SSS zzz") / 1000L;
                    // fetchGarminStepsData(startTime);
                }
            }
        }
    }

    private void syncTodaySteps() {
        if (connectedDeviceType != null && connectedDeviceType.length() > 0) {
            if (connectedDeviceType.equalsIgnoreCase(AppConstants.FITBIT)) {
                stepHelper.getTodayStepsFromFitbit(new OnTodayStepsFound() {
                    @Override
                    public void onTodayStepsFound(ArrayList<StepItem> foundStepList) {

                        saveTodayStepsToServer(foundStepList.get(0).getStepCount(), foundStepList.get(0).getCalories(), AppConstants.FITBIT);

                    }

                    @Override
                    public void onTodayStepsError(String error) {

                    }
                });
            } else if (connectedDeviceType.equalsIgnoreCase(AppConstants.S_HEALTH)) {
                stepHelper.getTodayStepsFromSamsung(new OnTodayStepsFound() {
                    @Override
                    public void onTodayStepsFound(ArrayList<StepItem> foundStepList) {
                        prefHelper.setPrefKeyDeviceConnected(connectedDeviceType);
                        prefHelper.clearDeviceConnectTokenPreferences();

                        saveTodayStepsToServer((foundStepList.get(0).getStepCount()), foundStepList.get(0).getCalories(), AppConstants.S_HEALTH);


                    }

                    @Override
                    public void onTodayStepsError(String error) {

                    }
                });
            } else if (connectedDeviceType.equalsIgnoreCase(AppConstants.GOOGLE_FIT)) {
                stepHelper.getTodayStepsFromGoogle(new OnTodayStepsFound() {
                    @Override
                    public void onTodayStepsFound(ArrayList<StepItem> foundStepList) {
                        prefHelper.setPrefKeyDeviceConnected(connectedDeviceType);
                        prefHelper.clearDeviceConnectTokenPreferences();
                        saveTodayStepsToServer((foundStepList.get(0).getStepCount()), foundStepList.get(0).getCalories(), AppConstants.GOOGLE_FIT);

                    }

                    @Override
                    public void onTodayStepsError(String error) {

                    }
                });
            } else if (connectedDeviceType.equalsIgnoreCase(AppConstants.E_FIT)) {
               getEFitTodaySteps();
            } else if (connectedDeviceType.equalsIgnoreCase(AppConstants.MISFIT)) {
                stepHelper.getTodayStepsMisfit(new OnTodayStepsFound() {
                    @Override
                    public void onTodayStepsFound(ArrayList<StepItem> foundStepList) {

                        saveTodayStepsToServer((foundStepList.get(0).getStepCount()), foundStepList.get(0).getCalories(), AppConstants.MISFIT);

                    }

                    @Override
                    public void onTodayStepsError(String error) {

                    }
                });
            } else if (connectedDeviceType.equalsIgnoreCase(AppConstants.GARMIN)) {
                //fetchGarminTodayStepsData();
            }
        }
    }

    private void saveTodayStepsToServer(final String steps, final int calories, String connectedDevice) {
        String date = DateUtils.getTodayDate(AppConstants.DATE_FORMAT_MM_DD_YYYY_HHMM_FORWARD_SLASH);

        StepsBean stepsBean = new StepsBean();
        stepsBean.setSteps(Integer.parseInt(steps));
        stepsBean.setCalories(calories);
        stepsBean.setStepsDate(date);
        ArrayList<StepsBean> stepsBeanList = new ArrayList<>();
        stepsBeanList.add(stepsBean);

        SaveDeviceStepsBody saveDeviceStepsBody = new SaveDeviceStepsBody();
        saveDeviceStepsBody.setDevice(connectedDevice);
        // saveDeviceStepsBody.setMemberID(Integer.parseInt(WellnessCornerApp.getPreferenceManager().getUserId()));
        saveDeviceStepsBody.setSteps(stepsBeanList);

        repository.saveDeviceSteps(saveDeviceStepsBody).subscribe(new Observer<SaveStepsResponse>() {
            @Override
            public void onSubscribe(Disposable d) {

            }

            @Override
            public void onNext(SaveStepsResponse response) {
                if (getActivity() != null && isAdded()) {
                    if (response != null ) {
                        if (response.getStatus() == 0) {

                            Utils.showToast(getActivity(), "Steps sync successfully");
                            getFragmentManager().popBackStackImmediate(StepsTrackerFragment.class.getSimpleName(), 0);
                        }
                    }
                }
            }

            @Override
            public void onError(Throwable e) {

            }

            @Override
            public void onComplete() {

            }
        });


    }
    private void openSyncDateDialog(String syncDate) {

        if (syncDate != null) {
            dobArray = syncDate.split("/");
            if (dobArray.length > 0) {
                try {
                    mMonth = Integer.parseInt(dobArray[0]);
                    mDay = Integer.parseInt(dobArray[1]);
                    mYear = Integer.parseInt(dobArray[2]);
                } catch (Exception e) {
                    e.printStackTrace();
                }

            }

        }
        DatePickerFragment date = new DatePickerFragment();
        /**
         * Set Up Current Date Into dialog
         */
        Bundle args = new Bundle();
        args.putInt("year", mYear);
        args.putInt("month", mMonth - 1);
        args.putInt("day", mDay);

        args.putBoolean("maxDate", true);
        args.putBoolean("setMinimumDate", false);
        date.setArguments(args);
        /**
         * Set Call back to capture selected date
         */
        date.setCallBack(ondate);

        date.show(getActivity().getFragmentManager(), "Date Picker");
    }


    private void saveStepsToServer(OnStepSync onStepSync, String connectedDevice, ArrayList<StepsBean> stepsBeanList, ArrayList<StepsBean> caloriesBeanList) {
        SaveDeviceStepsBody saveDeviceStepsBody = new SaveDeviceStepsBody();
        saveDeviceStepsBody.setDevice(connectedDevice);
        //saveDeviceStepsBody.setMemberID(Integer.parseInt(WellnessCornerApp.getPreferenceManager().getUserId()));
        saveDeviceStepsBody.setSteps(stepsBeanList);
        if (caloriesBeanList != null && caloriesBeanList.size() > 0)
            saveDeviceStepsBody.setCalories(caloriesBeanList);


        repository.saveDeviceSteps(saveDeviceStepsBody).subscribe(new Observer<SaveStepsResponse>() {
            @Override
            public void onSubscribe(Disposable d) {

            }

            @Override
            public void onNext(SaveStepsResponse response) {
                removeProgress();
                if (response != null ) {
                    if (response.getStatus() == 0) {
                        if (TheWellnessCornerApp.getInstance().getStepServerResponse() != null
                                && TheWellnessCornerApp.getInstance().getStepServerResponse().getData() != null) {
                            TheWellnessCornerApp.getInstance().getStepServerResponse().getData().setLastConnectedDevice(response.getLastConnectedDevice());
                            TheWellnessCornerApp.getInstance().getStepServerResponse().getData().setLastStepSyncDate(response.getLastStepsTrackerDate());
                        }
                        if (onStepSync != null) {
                            onStepSync.OnStepSynced();
                        }
                    }
                }
            }

            @Override
            public void onError(Throwable e) {
                if (onStepSync != null) {
                    onStepSync.OnStepSynced();
                }
            }

            @Override
            public void onComplete() {

            }
        });

    }
    private void getEFitStepsForSync() {
        String fromDateEFit = DateUtils.getInstance().getDateFromMillis(startDate, AppConstants.DATE_FORMAT_YYYY_MM_DD);
        String toDateEFit = DateUtils.getInstance().getDateFromMillis(endDate, AppConstants.DATE_FORMAT_YYYY_MM_DD);

        EFitMonthStepsBody eFitMonthStepsBody = new EFitMonthStepsBody();
        eFitMonthStepsBody.setMemberId(prefHelper.getEFitUserId());
        eFitMonthStepsBody.setStartDate(fromDateEFit);
        eFitMonthStepsBody.setEndDate(toDateEFit);

        FitBitRestClient restClient = new FitBitRestClient("EFit", "",getActivity(), FitBitConfig.E_FIT_BASE_URL, false);
        restClient.getFitBitStepsService().getEFitMonthSteps(eFitMonthStepsBody).enqueue(new Callback<EFitMonthStepsResponse>() {
            @SuppressWarnings("StatementWithEmptyBody")
            @Override
            public void onResponse(Call<EFitMonthStepsResponse> call, Response<EFitMonthStepsResponse> response) {
                if (getActivity() != null && isAdded()) {

                    if (response != null) {
                        EFitMonthStepsResponse eFitMonthStepsResponse = response.body();
                        if (eFitMonthStepsResponse != null) {
                            if (eFitMonthStepsResponse.getSuccess().equalsIgnoreCase("1")) {
                                List<FitBitStepsItem> stepsItemList = eFitMonthStepsResponse.getStepsData();
                                if (stepsItemList != null && stepsItemList.size() > 0) {

                                    HashMap<String, FitBitStepsItem> hashMap = new HashMap<>();
                                    Calendar fromCalendar = Calendar.getInstance();
                                    fromCalendar.setTimeInMillis(startDate);

                                    Calendar toCalendar = Calendar.getInstance();
                                    toCalendar.setTimeInMillis(endDate);
                                    String dateFromMillis = DateUtils.getInstance().getDateFromMillis(startDate, AppConstants.DATE_FORMAT_YYYY_MM_DD);
                                    System.out.println("steps dateFromMillis====" + dateFromMillis);
                                    FitBitStepsItem stepItemEmpty = new FitBitStepsItem();
                                    stepItemEmpty.setDateTime(dateFromMillis);
                                    stepItemEmpty.setCalory(0);
                                    stepItemEmpty.setValue("0");
                                    hashMap.put(dateFromMillis, stepItemEmpty);

                                    String dateToMillis = DateUtils.getInstance().getDateFromMillis(endDate, AppConstants.DATE_FORMAT_YYYY_MM_DD);
                                    System.out.println("steps dateToMillis====" + dateToMillis);
                                    stepItemEmpty = new FitBitStepsItem();
                                    stepItemEmpty.setDateTime(dateToMillis);
                                    stepItemEmpty.setCalory(0);
                                    stepItemEmpty.setValue("0");
                                    hashMap.put(dateToMillis, stepItemEmpty);

                                    if (!dateFromMillis.equalsIgnoreCase(dateToMillis)) {
                                        while (!dateFromMillis.equalsIgnoreCase(dateToMillis)) {
                                            fromCalendar.add(Calendar.DATE, 1);
                                            String dateMillis = DateUtils.getInstance().getDateFromMillis(fromCalendar.getTimeInMillis(), AppConstants.DATE_FORMAT_YYYY_MM_DD);
                                            dateFromMillis = dateMillis;
                                            stepItemEmpty = new FitBitStepsItem();
                                            stepItemEmpty.setDateTime(dateMillis);
                                            stepItemEmpty.setCalory(0);
                                            stepItemEmpty.setValue("0");
                                            System.out.println("steps dateMillis====" + dateMillis);
                                            hashMap.put(dateMillis, stepItemEmpty);
                                        }
                                    }
                                    for (FitBitStepsItem fitBitStepsItem : stepsItemList) {
                                        hashMap.put(fitBitStepsItem.getDateTime(), fitBitStepsItem);
                                    }

                                    ArrayList<StepsBean> stepsBeanList = new ArrayList<>();

                                    for (Map.Entry<String, FitBitStepsItem> entry : hashMap.entrySet()) {
                                        String key = entry.getKey();
                                        FitBitStepsItem fitBitStepsItem = entry.getValue();

                                        String date = DateUtils.getInstance().formatDateStep(AppConstants.DATE_FORMAT_YYYY_MM_DD, AppConstants.DATE_FORMAT_MM_DD_YYYY_HHMM_FORWARD_SLASH, fitBitStepsItem.getDateTime());
                                        String steps = fitBitStepsItem.getValue();
                                        StepsBean stepsBean = new StepsBean();
                                        stepsBean.setSteps(Integer.parseInt(steps));
                                        stepsBean.setStepsDate(date);
                                        stepsBean.setActivityDate(date);
                                        stepsBean.setCalories((int) fitBitStepsItem.getCalory());
                                        stepsBeanList.add(stepsBean);

                                    }
                                    // As discussed with Rohit  and Testing Team zeros won't be included at the time of showing data
                                    // Steps will be shown as it is. 1/7/2017
                                    // ArrayList<StepsBean> stepListToSync = addAbsentDayWithZeroSteps(stepsBeanList, finalLastSyncedMillis);
                                    saveStepsToServer(onStepSync, AppConstants.E_FIT, stepsBeanList, stepsBeanList);
                                }

                            } else if (eFitMonthStepsResponse.getSuccess().equalsIgnoreCase("2")) {
                                // no steps available
                                HashMap<String, FitBitStepsItem> hashMap = new HashMap<>();
                                Calendar fromCalendar = Calendar.getInstance();
                                fromCalendar.setTimeInMillis(startDate);

                                Calendar toCalendar = Calendar.getInstance();
                                toCalendar.setTimeInMillis(endDate);
                                String dateFromMillis = DateUtils.getInstance().getDateFromMillis(startDate, AppConstants.DATE_FORMAT_YYYY_MM_DD);
                                System.out.println("steps dateFromMillis====" + dateFromMillis);
                                FitBitStepsItem stepItemEmpty = new FitBitStepsItem();
                                stepItemEmpty.setDateTime(dateFromMillis);
                                stepItemEmpty.setCalory(0);
                                stepItemEmpty.setValue("0");
                                hashMap.put(dateFromMillis, stepItemEmpty);

                                String dateToMillis = DateUtils.getInstance().getDateFromMillis(endDate, AppConstants.DATE_FORMAT_YYYY_MM_DD);
                                System.out.println("steps dateToMillis====" + dateToMillis);
                                stepItemEmpty = new FitBitStepsItem();
                                stepItemEmpty.setDateTime(dateToMillis);
                                stepItemEmpty.setCalory(0);
                                stepItemEmpty.setValue("0");
                                hashMap.put(dateToMillis, stepItemEmpty);

                                if (!dateFromMillis.equalsIgnoreCase(dateToMillis)) {
                                    while (!dateFromMillis.equalsIgnoreCase(dateToMillis)) {
                                        fromCalendar.add(Calendar.DATE, 1);
                                        String dateMillis = DateUtils.getInstance().getDateFromMillis(fromCalendar.getTimeInMillis(), AppConstants.DATE_FORMAT_YYYY_MM_DD);
                                        dateFromMillis = dateMillis;
                                        stepItemEmpty = new FitBitStepsItem();
                                        stepItemEmpty.setDateTime(dateMillis);
                                        stepItemEmpty.setCalory(0);
                                        stepItemEmpty.setValue("0");
                                        System.out.println("steps dateMillis====" + dateMillis);
                                        hashMap.put(dateMillis, stepItemEmpty);
                                    }
                                }
                                ArrayList<StepsBean> stepsBeanList = new ArrayList<>();

                                for (Map.Entry<String, FitBitStepsItem> entry : hashMap.entrySet()) {
                                    String key = entry.getKey();
                                    FitBitStepsItem fitBitStepsItem = entry.getValue();

                                    String date = DateUtils.getInstance().formatDateStep(AppConstants.DATE_FORMAT_YYYY_MM_DD, AppConstants.DATE_FORMAT_MM_DD_YYYY_HHMM_FORWARD_SLASH, fitBitStepsItem.getDateTime());
                                    String steps = fitBitStepsItem.getValue();
                                    StepsBean stepsBean = new StepsBean();
                                    stepsBean.setSteps(Integer.parseInt(steps));
                                    stepsBean.setStepsDate(date);
                                    stepsBean.setActivityDate(date);
                                    stepsBean.setCalories((int) fitBitStepsItem.getCalory());
                                    stepsBeanList.add(stepsBean);

                                }
                                saveStepsToServer(onStepSync, AppConstants.E_FIT, stepsBeanList, stepsBeanList);
                            } else {
                                Utils.showToast(getActivity(), "An error occurred while syncing your steps to server. Please try to connect your device again.");
                            }
                        } else {
                            Utils.showToast(getActivity(), "An error occurred while syncing your steps to server. Please try to connect your device again.");
                        }
                    } else {
                        Utils.showToast(getActivity(), "An error occurred while syncing your steps to server. Please try to connect your device again.");
                    }
                }
            }

            @Override
            public void onFailure(Call<EFitMonthStepsResponse> call, Throwable t) {
                if (getActivity() != null && isAdded()) {

                    Utils.showToast(getActivity(), "An error occurred while syncing your steps to server. Please try to connect your device again.");
                    CommonUtils.showAlertDialog(getActivity(), null, 0, getString(R.string.msg_api_failure), getString(R.string.str_ok), true);
                }
            }
        });
    }

    private void getEFitTodaySteps() {
        String fromDateEFit = DateUtils.getInstance().getTodayDate("yyyy MM dd");
        String toDateEFit = DateUtils.getInstance().getTodayDate("yyyy MM dd");
        EFitMonthStepsBody eFitMonthStepsBody = new EFitMonthStepsBody();
        eFitMonthStepsBody.setMemberId(prefHelper.getEFitUserId());
        eFitMonthStepsBody.setStartDate(fromDateEFit);
        eFitMonthStepsBody.setEndDate(toDateEFit);

        FitBitRestClient restClient = new FitBitRestClient("EFit", "", getActivity(), FitBitConfig.E_FIT_BASE_URL, false);
        restClient.getFitBitStepsService().getEFitMonthSteps(eFitMonthStepsBody).enqueue(new Callback<EFitMonthStepsResponse>() {
            @SuppressWarnings("StatementWithEmptyBody")
            @Override
            public void onResponse(Call<EFitMonthStepsResponse> call, Response<EFitMonthStepsResponse> response) {
                if (getActivity() != null && isAdded()) {

                    if (response != null) {
                        EFitMonthStepsResponse eFitMonthStepsResponse = response.body();
                        if (eFitMonthStepsResponse != null) {
                            if (eFitMonthStepsResponse.getSuccess().equalsIgnoreCase("1")) {
                                List<FitBitStepsItem> stepsItemList = eFitMonthStepsResponse.getStepsData();
                                if (stepsItemList != null && stepsItemList.size() > 0) {
                                    saveTodayStepsToServer(stepsItemList.get(0).getValue(), (int) stepsItemList.get(0).getCalory(), AppConstants.E_FIT);

                                } else {
                                }
                            } else if (eFitMonthStepsResponse.getSuccess().equalsIgnoreCase("2")) {
                                // no steps available
                                saveTodayStepsToServer("0", 0,AppConstants.E_FIT);


                            } else {
                                CommonUtils.showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_response_failure), getString(R.string.str_ok), false);
                            }
                        } else {
                            CommonUtils.showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_response_null), getString(R.string.str_ok), false);
                        }
                    } else {
                        CommonUtils.showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_response_null), getString(R.string.str_ok), false);
                    }
                }
            }

            @Override
            public void onFailure(Call<EFitMonthStepsResponse> call, Throwable t) {
                if (getActivity() != null && isAdded()) {

                    CommonUtils.showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_failure), getString(R.string.str_ok), false);
                }
            }
        });
    }
    private void removeProgress() {
        isFromSyncNowButtonPressed = false;
        if (pd != null && pd.isShowing())
            pd.dismiss();
    }

}
