package com.truworth.wellnesscorner.model;

import com.google.gson.annotations.SerializedName;

public class PostHiFiData {
    @SerializedName(value="totalLike", alternate={"totalHiFive"})
    private int totalLike;
    private boolean isHiFive;

    public int getTotalLike() {
        return totalLike;
    }

    public void setTotalLike(int totalLike) {
        this.totalLike = totalLike;
    }

    public boolean isHiFive() {
        return isHiFive;
    }

    public void setHiFive(boolean hiFive) {
        isHiFive = hiFive;
    }
}
