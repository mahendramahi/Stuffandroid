package com.truworth.wellnesscorner.ui.tagfeature;

import android.app.Activity;
import android.content.Context;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.truworth.wellnesscorner.R;
import com.truworth.wellnesscorner.TheWellnessCornerApp;
import com.truworth.wellnesscorner.model.TagPerson;
import com.truworth.wellnesscorner.repo.CreatePostRepository;
import com.truworth.wellnesscorner.repo.model.request.PostTagRequest;
import com.truworth.wellnesscorner.repo.model.response.TagResponse;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.inject.Inject;

import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;


public class SocialTagsCompletionView extends TokenCompleteTextView {
    @Inject
    CreatePostRepository createPostRepository;

    public void setCircleId(String circleId) {
        this.circleId = circleId;
    }

    //circle ID for searching
    private String circleId;

    TagAutoCompleteAdapter tagAutoCompleteAdapter;
    private final String AT = "@";

    public SocialTagsCompletionView(Context context) {
        super(context);
        initializeComponents();
    }

    public SocialTagsCompletionView(Context context, AttributeSet attrs) {
        super(context, attrs);
        initializeComponents();
    }

    public SocialTagsCompletionView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        initializeComponents();
    }

    private void initializeComponents() {
        TheWellnessCornerApp.getApp().component().inject(this);
        addTextChangedListener(textWatcher);
    }

    @Override
    protected int beforeReplacingText(Editable editable, int start, int end) {
        return !editable.toString().contains(AT) ? start : editable.toString().lastIndexOf(AT);
    }


    public String getProcessedString() {
        String s = getText().toString();
        String regex = "д,";
        StringBuffer sb = new StringBuffer();
        StringBuilder spannable = new StringBuilder();

        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(s);
        int i = 0;
        while (matcher.find()) {
            sb.setLength(0);
            matcher.appendReplacement(sb, "{{" + i + "}}");
            spannable.append(sb.toString());
        }

        sb.setLength(0);
        matcher.appendTail(sb);
        spannable.append(sb.toString());


        return spannable.toString();
    }


    @Override
    protected View getViewForObject(Object object) {
        LayoutInflater l = (LayoutInflater) getContext().getSystemService(Activity.LAYOUT_INFLATER_SERVICE);

        if (!(object instanceof TagPerson)) {
            TextView view = (TextView) l.inflate(R.layout.default_textview, (ViewGroup) SocialTagsCompletionView.this.getParent(), false);
            view.setText(object.toString());
            return view;
        } else {
            TagPerson p = (TagPerson) object;

            LinearLayout view = (LinearLayout) l.inflate(R.layout.contact_token, (ViewGroup) SocialTagsCompletionView.this.getParent(), false);

            //  ((ImageView)view.findViewById(R.id.icon_image_token)).setBackgroundResource(p.getIcon());
            ((TextView) view.findViewById(R.id.name_token)).setText(p.getPostTagName());
            return view;
        }
    }

    @Override
    protected Object defaultObject(String completionText) {

        return completionText;
    }

    TextWatcher textWatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

        }

        @Override
        public void onTextChanged(CharSequence s, int start, int lengthBefore, int lengthAfter) {

            if (!s.toString().isEmpty() && start < s.length()) {

                String name = s.toString().substring(0, start + 1);

                int lastTokenIndex = name.lastIndexOf(" @");
                int lastIndexOfSpace = name.lastIndexOf(" ");
                int nextIndexOfSpace = name.indexOf(" ", start);

                if (lastIndexOfSpace > 0 && lastTokenIndex < lastIndexOfSpace) {
                    String afterString = s.toString().substring(lastIndexOfSpace, s.length());
                    if (afterString.startsWith(" ")) return;
                }

                if (lastTokenIndex < 0) {
                    if (!name.isEmpty() && name.length() >= 1 && name.startsWith("@")) {
                        lastTokenIndex = 1;
                    } else
                        return;
                }

                int tokenEnd = lastIndexOfSpace;

                if (lastIndexOfSpace <= lastTokenIndex) {
                    tokenEnd = name.length();
                    if (nextIndexOfSpace != -1 && nextIndexOfSpace < tokenEnd) {
                        tokenEnd = nextIndexOfSpace;
                    }
                }

                if (lastTokenIndex >= 0) {
                    name = s.toString().substring(lastTokenIndex, tokenEnd).trim();
                    Pattern pattern = Pattern.compile("^(.+)\\s.+");
                    Matcher matcher = pattern.matcher(name);
                    if (!matcher.find()) {
                        name = name.replace("@", "").trim();
                        if (!name.isEmpty()) {
                            getUsers(name);
                        }
                    }
                }
            }
        }

        @Override
        public void afterTextChanged(Editable editable) {

        }
    };

    public void getUsers(String name) {
        PostTagRequest request = new PostTagRequest();
        request.setId(circleId);
        request.setSearchTerm(name);

        createPostRepository.getTagMembersList(request).subscribe(new Observer<TagResponse>() {
            @Override
            public void onSubscribe(Disposable d) {

            }

            @Override
            public void onNext(TagResponse tagResponse) {
                if (tagResponse != null) {
                    if (!tagResponse.isHasError()) {
                        List<TagPerson> mentionPeople = tagResponse.getData();
                        if (mentionPeople != null && !mentionPeople.isEmpty()) {
                            tagAutoCompleteAdapter =
                                    new TagAutoCompleteAdapter(getContext(), mentionPeople);
                            SocialTagsCompletionView.this.setAdapter(tagAutoCompleteAdapter);
                            SocialTagsCompletionView.this.showDropDown();
                        }
                    }
                }
            }

            @Override
            public void onError(Throwable e) {

            }

            @Override
            public void onComplete() {

            }
        });

    }
}
