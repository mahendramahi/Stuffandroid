package com.truworth.wellnesscorner.ui.mainapp.circledetail.challenges;


import android.databinding.ObservableBoolean;

import com.truworth.wellnesscorner.TheWellnessCornerApp;
import com.truworth.wellnesscorner.base.BaseViewModel;
import com.truworth.wellnesscorner.model.OnGoingChallengesBean;
import com.truworth.wellnesscorner.model.PreviousChallengesBean;
import com.truworth.wellnesscorner.repo.DashboardRepository;
import com.truworth.wellnesscorner.repo.model.request.CircleChallengeRequest;
import com.truworth.wellnesscorner.repo.model.response.CircleChallengeResponse;
import com.truworth.wellnesscorner.utils.SingleLiveEvent;

import java.util.List;

import javax.inject.Inject;

import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;

public class CircleChallengeViewModel extends BaseViewModel {

    List<String> myList;
    public SingleLiveEvent<List<OnGoingChallengesBean>> ongoingChallenges = new SingleLiveEvent<>();

    public SingleLiveEvent<List<OnGoingChallengesBean>> getOngoingChallenges() {
        return ongoingChallenges;
    }

    public SingleLiveEvent<List<PreviousChallengesBean>> previousChallenges = new SingleLiveEvent<>();

    public SingleLiveEvent<List<PreviousChallengesBean>> getPreviousChallenges() {
        return previousChallenges;
    }

    public ObservableBoolean showNoData = new ObservableBoolean();
    public ObservableBoolean showOngoingChallenge = new ObservableBoolean();
    public ObservableBoolean showPreviousChallenge = new ObservableBoolean();

    @Inject
    DashboardRepository dashboardRepository;

    public CircleChallengeViewModel() {
        TheWellnessCornerApp.getApp().component().inject(this);
    }

    public void loadChallenges(String circleIdentity, int pageIndex) {

        CircleChallengeRequest circleChallengeRequest = new CircleChallengeRequest();
        circleChallengeRequest.setId(circleIdentity);
        circleChallengeRequest.setPageIndex(pageIndex);

        setIsLoading(true);
        dashboardRepository.getCircleChallenges(circleChallengeRequest).subscribe(new Observer<CircleChallengeResponse>() {
            @Override
            public void onSubscribe(Disposable d) {

            }

            @Override
            public void onNext(CircleChallengeResponse circleChallengeResponse) {
                if (!circleChallengeResponse.isHasError()) {
                    setIsLoading(false);
                     showNoData.set(false);
                     ongoingChallenges.setValue(circleChallengeResponse.getData().getOnGoingChallenges());
                     previousChallenges.setValue(circleChallengeResponse.getData().getPreviousChallenges());

                     if(circleChallengeResponse.getData().getOnGoingChallenges().size()>0)
                         showOngoingChallenge.set(true);
                     else
                         showOngoingChallenge.set(false);

                    if(circleChallengeResponse.getData().getPreviousChallenges().size()>0)
                        showPreviousChallenge.set(true);
                    else
                        showPreviousChallenge.set(false);
                }
                else{
                    setIsLoading(false);
                    showNoData.set(true);
                }
            }

            @Override
            public void onError(Throwable e) {
                e.printStackTrace();
                setIsLoading(false);
            }

            @Override
            public void onComplete() {

            }
        });
    }
}
