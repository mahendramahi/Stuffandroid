package com.twc.store.fragments;

/**
 * Created by GurvinderS on 9/18/2017.
 */


import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;

import com.twc.store.BillingAddressConfig;

import com.twc.store.R;
import com.twc.store.R2;
import com.twc.store.StoreActivity;
import com.twc.store.StoreCategoryActivity;
import com.twc.store.StoreDetailActivity;
import com.twc.store.interfaces.OnCityFindListener;
import com.twc.store.interfaces.PermissionListener;
import com.twc.store.model.beans.BillingInfoBean;
import com.twc.store.model.requestbody.StateRequestBody;
import com.twc.store.model.response.StateListResponse;
import com.twc.store.rest.RestClient;
import com.twc.store.utils.DialogFactory;
import com.twc.store.utils.GetCityByLocation;
import com.twc.store.utils.PermissionEnum;
import com.twc.store.utils.PermissionHelper;
import com.twc.store.utils.StoreConfig;
import com.twc.store.utils.Utils;
import com.twc.store.views.CustomProgressDialog;

import java.util.ArrayList;

import butterknife.BindView;
import butterknife.OnClick;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by GurvinderS on 5/18/2017.
 */

public class StoreMemberAddressFragment extends BaseFragment implements PermissionListener, OnCityFindListener {
    private final int REQUEST_CHECK_SETTINGS = 300;
    private final int REQUEST_LOCATION = 200;
    @BindView(R2.id.rootView)
    LinearLayout rootView;
    @BindView(R2.id.tvProductName)
    TextView tvProductName;
    @BindView(R2.id.tvProductPrice)
    TextView tvProductPrice;
    @BindView(R2.id.ivProductImage)
    ImageView ivProductImage;
    @BindView(R2.id.edName)
    EditText edName;
    @BindView(R2.id.edPhoneNo)
    EditText edPhoneNo;
    @BindView(R2.id.edAddress1)
    EditText edAddress1;
    @BindView(R2.id.edAddress2)
    EditText edAddress2;
    @BindView(R2.id.edCity)
    EditText edCity;
    @BindView(R2.id.spState)
    Spinner spState;
    @BindView(R2.id.edCountry)
    EditText edCountry;
    @BindView(R2.id.edPincode)
    EditText edPincode;
    @BindView(R2.id.edAddressType)
    EditText edAddressType;
    @BindView(R2.id.btnSave)
    TextView btnSave;
    private BillingInfoBean mMemberBillingDetails;
    private String state;
    private CustomProgressDialog customProgressDialog;
    private GetCityByLocation getCityByLocation;
    private PermissionHelper permissionHelper;
    private ArrayAdapter<String> stateAdapter;

    public static StoreMemberAddressFragment newInstance() {

        StoreMemberAddressFragment fragment = new StoreMemberAddressFragment();


        return fragment;
    }

    @Override
    public int getFragmentLayout() {
        return R.layout.dialog_member_billings_details;
    }

    @Override
    public void onFragmentReady() {


        if (mMemberBillingDetails != null) {
            if (mMemberBillingDetails.getName() != null)
                edName.setText(mMemberBillingDetails.getName());
            if (mMemberBillingDetails.getPhoneNo() != null)
                edPhoneNo.setText(mMemberBillingDetails.getPhoneNo());
            if (mMemberBillingDetails.getAddress1() != null)
                edAddress1.setText(mMemberBillingDetails.getAddress1());
            if (mMemberBillingDetails.getAddress2() != null)
                edAddress2.setText(mMemberBillingDetails.getAddress2());
            if (mMemberBillingDetails.getCity() != null)
                edCity.setText(mMemberBillingDetails.getCity());
            if (mMemberBillingDetails.getState() != null)
                state = mMemberBillingDetails.getState();
            if (mMemberBillingDetails.getPincode() != null)
                edPincode.setText(mMemberBillingDetails.getPincode());
        }


        edAddressType.setText("Billing");
        rootView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                hideKeyBoard(v);
                return false;
            }
        });

        spState.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                hideKeyBoard(v);
                return false;
            }
        });

        getStateList();
        getCityByLocation.buildGoogleApiConnection();


    }

    private void hideKeyBoard(View v) {
        Utils.hideSoftKeyboard(getActivity());


    }

    private void getStateList() {
        customProgressDialog = new CustomProgressDialog(getActivity(), R.style.custom_progress_style, true);
        customProgressDialog.show();

        StateRequestBody body = new StateRequestBody();
        body.setCounryID(1);
        RestClient restClient = new RestClient(getActivity(), StoreConfig.BASE_URL, StoreConfig.mdebug);

     restClient.getSettingService().getStateList(body).enqueue(new Callback<StateListResponse>() {
            @Override
            public void onResponse(Call<StateListResponse> call, Response<StateListResponse> response) {
                if (getActivity() != null && isAdded()) {
                    customProgressDialog.dismiss();
                    if (response != null && response.body() != null) {
                        if (response.body().getStatus() == 0) {

                            ArrayList<String> arrState = new ArrayList<>();
                            arrState.add("--Select State--");
                            arrState.addAll(response.body().getData().getNames());
                            stateAdapter = new ArrayAdapter<>(getActivity(), android.R.layout.simple_spinner_item, arrState);
                            stateAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                            spState.setAdapter(stateAdapter);

                            if (state != null && !state.isEmpty()) {
                                int selectedCountryPosition = stateAdapter.getPosition(state);
                                spState.setSelection(selectedCountryPosition);

                            }

                        } else if (response.body().getStatus() == -1) {
                            DialogFactory.getInstance().showAlertDialog(getActivity(), getActivity().getString(R.string.app_name), 0, getActivity().getString(R.string.msg_api_response_failure), getActivity().getString(R.string.str_ok), false);
                        }
                    } else {
                        DialogFactory.getInstance().showAlertDialog(getActivity(), getActivity().getString(R.string.app_name), 0, getActivity().getString(R.string.msg_api_response_null), getActivity().getString(R.string.str_ok), false);
                    }
                }
            }

            @Override
            public void onFailure(Call<StateListResponse> call, Throwable t) {
                if (getActivity() != null && isAdded()) {
                    customProgressDialog.dismiss();
                    DialogFactory.getInstance().showAlertDialog(getActivity(), getActivity().getString(R.string.app_name), 0, getActivity().getString(R.string.msg_api_failure), getActivity().getString(R.string.str_ok), false);
                }
            }
        });

    }

    public void setMemberBillingDetails(BillingInfoBean billingInfoBean) {

        this.mMemberBillingDetails = billingInfoBean;
    }

    @OnClick(R2.id.btnSave)
    public void saveBillingDetails() {
        saveMemberBillingsDetailsAPI();
    }

    private void saveMemberBillingsDetailsAPI() {

        if (!validateName()) {
            edName.setError("Name is required");
            edName.requestFocus();
        } else if (!validatePhone()) {
            edPhoneNo.setError("PhoneNo is required");
            edPhoneNo.requestFocus();
        } else if (!validateAddress1()) {
            edAddress1.setError("Shipping Address - Line 1 is required");
            edAddress1.requestFocus();
        } else if (!validateCity()) {
            edCity.setError("City is required");
            edCity.requestFocus();
        } else if (!validateState()) {

            Utils.showToast(getActivity(), "Please Select a state!");
            // edState.setError("State is required");
            //edState.requestFocus();
        } else if (!validateCountry()) {
            edCountry.setError("Country is required");
            edCountry.requestFocus();
        } else if (!validatePincode()) {
            edPincode.setError("Pincode is required");
            edPincode.requestFocus();
        } else {


            BillingInfoBean billingInfoBean = new BillingInfoBean();
            billingInfoBean.setName(edName.getText().toString());
            billingInfoBean.setPhoneNo(edPhoneNo.getText().toString());
            billingInfoBean.setAddress1(edAddress1.getText().toString());
            billingInfoBean.setAddress2(edAddress2.getText().toString());
            billingInfoBean.setCity(edCity.getText().toString());
            billingInfoBean.setState(spState.getSelectedItem().toString());
            billingInfoBean.setCountry(edCountry.getText().toString());
            billingInfoBean.setPincode(edPincode.getText().toString());


            BillingAddressConfig.getInstance().setBillingInfoBean(billingInfoBean);
            getFragmentManager().popBackStackImmediate();

        }
    }

    private boolean validateAddress1() {

        if (edAddress1.getText().toString().isEmpty()) {
            return false;
        } else {
            edAddress1.setError(null);
        }


        return true;

    }

    private boolean validatePhone() {

        if (edPhoneNo.getText().toString().isEmpty()) {
            return false;
        } else {
            edPhoneNo.setError(null);
        }


        return true;

    }

    private boolean validateName() {

        if (edName.getText().toString().isEmpty()) {
            return false;
        } else {
            edName.setError(null);
        }


        return true;
    }

    private boolean validateCity() {

        if (edCity.getText().toString().isEmpty()) {
            return false;
        } else {
            edCity.setError(null);
        }


        return true;

    }

    private boolean validateState() {

        if (spState.getSelectedItem().toString().equalsIgnoreCase("--Select State--")) {
            return false;
        } else {

        }


        return true;

    }

    private boolean validateCountry() {

        if (edCountry.getText().toString().isEmpty()) {
            return false;
        } else {
            edCountry.setError(null);
        }
        return true;

    }

    private boolean validatePincode() {

        if (edPincode.getText().toString().isEmpty()) {
            return false;
        } else {
            edPincode.setError(null);
        }
        return true;

    }

    @Override
    public void onCityFound(String address) {
        if (address != null && !address.isEmpty()) {
            String[] arr = address.split("-");
            String city = arr[0];
            String country = arr[1];
            String postalCode = arr[2];
            String addressState = arr[3].toUpperCase();
            if (edCity.getText().toString().isEmpty()) {
                edCity.setText(city);
            }
            if (edPincode.getText().toString().isEmpty()) {
                edPincode.setText(postalCode);
            }

            if (state == null) {
                if (stateAdapter != null && addressState != null && !addressState.isEmpty()) {
                    int selectedCountryPosition = stateAdapter.getPosition(addressState);
                    spState.setSelection(selectedCountryPosition);

                }
            }
        }
    }

    @Override
    public void onPermissionsGranted(int requestCode, ArrayList<String> acceptedPermissionList) {
        if (requestCode == REQUEST_LOCATION) {

            if (acceptedPermissionList.size() == 1) {
                getCityByLocation.accessLocation();
            }

        }

    }

    @Override
    public void onPermissionsDenied(int requestCode, ArrayList<String> deniedPermissionList) {

    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {
            case REQUEST_CHECK_SETTINGS:
                switch (resultCode) {
                    case Activity.RESULT_OK:
                        permissionHelper.build();
                        break;
                    case Activity.RESULT_CANCELED:

                        break;
                }
                break;
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (permissionHelper != null) {
            permissionHelper.onRequestPermissionsResult(requestCode, permissions, grantResults);
        }

    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        permissionHelper = new PermissionHelper();
        permissionHelper.with(this).rationalMessage(getString(R.string.rational_message_location)).requestCode(REQUEST_LOCATION).askFor(PermissionEnum.LOCATION).resultCallback(this);

        getCityByLocation = new GetCityByLocation(getActivity(), permissionHelper, this, this);
    }

    @Override
    public void onResume() {
        super.onResume();
        if(getActivity() instanceof StoreActivity) {
            ((StoreActivity) getActivity()).setToolBarTitle("Shipping Address");
            ((StoreActivity) getActivity()).showHomeAsUpEnableToolbar();
        }else if(getActivity() instanceof StoreDetailActivity){
            ((StoreDetailActivity) getActivity()).setToolBarTitle("Shipping Address");
            ((StoreDetailActivity) getActivity()).showHomeAsUpEnableToolbar();
        }else if(getActivity() instanceof StoreCategoryActivity){
            ((StoreCategoryActivity) getActivity()).setToolBarTitle("Shipping Address");
            ((StoreCategoryActivity) getActivity()).showHomeAsUpEnableToolbar();
        }
    }
}
