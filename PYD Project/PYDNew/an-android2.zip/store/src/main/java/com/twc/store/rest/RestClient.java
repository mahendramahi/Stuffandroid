package com.twc.store.rest;

import android.content.Context;

import com.twc.store.restservice.SettingService;
import com.twc.store.restservice.StoreService;
import com.twc.store.restservice.WellnessStoreService;


/**
 * Created by ManishJ1 on 6/29/2016.
 */
public class RestClient extends AbstractRestClient {


    private WellnessStoreService wellnessStoreService;

    private StoreService storeService;
    private SettingService settingService;

    public RestClient(Context context, String baseUrl, boolean debug) {
        super(context, baseUrl, debug);
    }

    @Override
    public void initApi() {


        wellnessStoreService = client.create(WellnessStoreService.class);

        storeService = client.create(StoreService.class);
        settingService = client.create(SettingService.class);
    }



    public SettingService getSettingService() {
        return settingService;
    }

    public WellnessStoreService getWellnessStoreService() {
        return wellnessStoreService;
    }


    public StoreService getStoreService() {
        return storeService;
    }


}
