package com.twc.hramodule.fragments;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.twc.greendaolib.GreenDaoApp;
import com.twc.greendaolib.HraDBItem;
import com.twc.greendaolib.HraDBItemDao;
import com.twc.hramodule.HraActivity;
import com.twc.hramodule.R;
import com.twc.hramodule.R2;
import com.twc.hramodule.adapter.HraAdapterScreen31;
import com.twc.hramodule.interfaces.OnHraDbAction;
import com.twc.hramodule.model.beans.HraItem;
import com.twc.hramodule.model.requestbody.HraSaveBody;
import com.twc.hramodule.model.response.HraSaveResponse;
import com.twc.hramodule.rest.RestClient;
import com.twc.hramodule.utils.DialogFactory;
import com.twc.hramodule.utils.HraConfig;
import com.twc.hramodule.utils.NetworkFactory;
import com.twc.hramodule.utils.Utils;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by GurvinderS on 10/6/2016.
 */
public class HraQ31Fragment extends BaseFragment {
    private static final long QUESTION_ID = 35;
    private static final String SCREEN_NO = "26";

    @BindView(R2.id.pb)
    ProgressBar pb;

    @BindView(R2.id.background)
    RelativeLayout background;

    @BindView(R2.id.ivQuestionImage)
    ImageView ivQuestionImage;

    @BindView(R2.id.tvQuestionTitle)
    TextView tvQuestionTitle;

    @BindView(R2.id.tvQuestionNo)
    TextView tvQuestionNo;

    @BindView(R2.id.tvQuestionType)
    TextView tvQuestionType;

    @BindView(R2.id.rvHraAnswerOptions)
    RecyclerView rvHraAnswerOptions;

    @BindView(R2.id.btnNextQuestion)
    Button btnNextQuestion;
    @BindView(R2.id.ivHRABack)
    ImageView ivHRABack;

    @BindView(R2.id.ivCancelHRA)
    ImageView ivCancelHRA;
    @BindView(R2.id.rootLayout)
    RelativeLayout rootLayout;

    private ArrayList<HraSaveBody.QuestionBean> arrListQb;
    private HraAdapterScreen31 hraAdapter;
    private ArrayList<HraItem> answerList;
    private OnHraDbAction onHraDbAction;
    private HraDBItemDao hraDBDao;

    public static HraQ31Fragment newInstance(Bundle bundle) {
        HraQ31Fragment fragment = new HraQ31Fragment();
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    public int getFragmentLayout() {
        return R.layout.fragment_hra_type7;
    }

    @Override
    public void onFragmentReady() {
        btnNextQuestion.setText(R.string.finish);
        arrListQb = new ArrayList<>();
        answerList = new ArrayList<>();
        rvHraAnswerOptions.setHasFixedSize(true);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getActivity());
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        rvHraAnswerOptions.setLayoutManager(linearLayoutManager);

        String[] hraQuestion = getActivity().getResources().getStringArray(R.array.hra_questions);
        String[] hraAnswer = getActivity().getResources().getStringArray(R.array.hra_que35_row);
        setHraQuestion(hraQuestion[36], hraAnswer);

    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        onHraDbAction = (OnHraDbAction) context;
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        onHraDbAction = (OnHraDbAction) activity;
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        view.setFocusableInTouchMode(true);
        view.requestFocus();
        view.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (keyCode == KeyEvent.KEYCODE_BACK && event.getAction() == KeyEvent.ACTION_DOWN) {
                    onBack();
                    return true;
                }
                return false;
            }
        });
    }

    private void setHraQuestion(String question, String[] hraAnswer) {
        tvQuestionType.setText("LIFESTYLE");
        tvQuestionNo.setText("31");
        tvQuestionTitle.setText(question);
        ivQuestionImage.setBackgroundResource(R.drawable.baby_stroller);

        for (String ans : hraAnswer) {
            String[] splitArray = ans.split("~");
            String id = splitArray[0];
            String name = splitArray[1];
            HraItem item = new HraItem();
            item.setQuestionID(QUESTION_ID);
            item.setAnswerID(id);
            item.setAnswer(name);
            item.setScreenNo(SCREEN_NO);
            answerList.add(item);
        }

        // get previous selected answer from database
        String answer = "";
        hraDBDao = GreenDaoApp.getInstance(getActivity()).getDaoSession(getActivity()).getHraDBItemDao();
        List<HraDBItem> answerFromDb = hraDBDao.queryBuilder().where(HraDBItemDao.Properties.QuestionId.eq(QUESTION_ID)).list();
        for (HraDBItem hraDBItem : answerFromDb) {
            answer = hraDBItem.getAnswer();
        }

        String[] arr = answer.split("/");
        for (int i = 0; i < answerList.size(); i++) {
            HraItem hraItem = answerList.get(i);
            String answerId = answerList.get(i).getAnswerID();
            for (String selectedAnswerId : arr) {
                if (answerId.equalsIgnoreCase(selectedAnswerId)) {
                    hraItem.setSelected(true);
                    answerList.set(i, hraItem);
                    break;
                }
            }
        }
        hraAdapter = new HraAdapterScreen31(answerList, getActivity(), true);
        rvHraAnswerOptions.setAdapter(hraAdapter);
    }

    @OnClick({R2.id.btnNextQuestion, R2.id.ivCancelHRA, R2.id.ivHRABack})
    public void onClick(View view) {
        int i = view.getId();
        if (i == R.id.ivHRABack) {
            onBack();

        } else if (i == R.id.ivCancelHRA) {
            cancelHra();

        } else if (i == R.id.btnNextQuestion) {
            StringBuilder stringBuilder = new StringBuilder();
            for (HraItem hraItem : hraAdapter.getSelectedAnswers()) {
                if (hraItem.isSelected()) {
                    stringBuilder.append(hraItem.getAnswerID()).append("/");
                }
            }
            if (stringBuilder.length() > 0) {
                stringBuilder.setLength(stringBuilder.length() - 1);
                String mergedAnswer = stringBuilder.toString();
                onHraDbAction.onHraQuestionSave(QUESTION_ID, mergedAnswer, SCREEN_NO, 0);
            } else {
                Utils.showToast(getActivity(), getString(R.string.pls_select_an_answer));
                return;
            }
            if (NetworkFactory.getInstance().isNetworkAvailable(getActivity())) {
                saveHra();
            } else {
                Utils.showSnackBarMessage(rootLayout, getString(R.string.internet_not_available));
            }


        }
    }

    private void saveHra() {
        pb.setVisibility(View.VISIBLE);
        HraSaveBody hraSaveBody = new HraSaveBody();
        hraSaveBody.setMemberID(HraConfig.hraUser.getUserID());
        hraSaveBody.setFromMobile("1");
        HraDBItemDao hraDBDao = GreenDaoApp.getInstance(getActivity()).getDaoSession(getActivity()).getHraDBItemDao();

        List<HraDBItem> answerFromDb = hraDBDao.queryBuilder().orderAsc(HraDBItemDao.Properties.QuestionId).list();
        for (HraDBItem hraDBItem : answerFromDb) {
            HraSaveBody.QuestionBean qb = new HraSaveBody.QuestionBean();
            long questionId = hraDBItem.getQuestionId();

            // convert question_id for similarity with web
            if (questionId == 2) {
                questionId = 3;
            } else if (questionId == 3) {
                questionId = 2;
            } else if (questionId == 19) {
                questionId = 20;
            } else if (questionId == 20) {
                questionId = 19;
            }

            qb.setQuestionID(questionId);
            qb.setAnswer(hraDBItem.getAnswer());
            qb.setIsSure(hraDBItem.getIsSure());
            arrListQb.add(qb);
        }

        hraSaveBody.setQuestion(arrListQb);
        RestClient restClient = new RestClient(getActivity(), HraConfig.BASE_URL, HraConfig.DEBUG);
        restClient.getHraService().saveHra(hraSaveBody).enqueue(new Callback<HraSaveResponse>() {
            @Override
            public void onResponse(Call<HraSaveResponse> call, Response<HraSaveResponse> response) {
                if (isAdded() && getActivity() != null) {

                    pb.setVisibility(View.GONE);
                    if (response != null && response.body() != null) {

                        if (response.body().getStatus() == 0) {
                            Bundle bundle = new Bundle();
                            bundle.putString("score", response.body().getData().getScore() + "");
                            bundle.putString("grade", response.body().getData().getGrade());
                            bundle.putString("msg", response.body().getData().getMessage());

                            HraDBItemDao hraDBDao = GreenDaoApp.getInstance(getActivity()).getDaoSession(getActivity()).getHraDBItemDao();
                            hraDBDao.deleteAll();
                            Utils.replaceFragment(getFragmentManager(), HraRiskGradeFragment.newInstance(bundle), HraRiskGradeFragment.class.getSimpleName(), true, R.id.fragmentContainerHra);

                        } else {
                            DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_response_failure), getString(R.string.str_ok), false);
                        }


                    } else {
                        DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_response_failure), getString(R.string.str_ok), false);
                    }
                }
            }

            @Override
            public void onFailure(Call<HraSaveResponse> call, Throwable t) {

                if (isAdded() && getActivity() != null) {
                    if (pb != null) {
                        pb.setVisibility(View.GONE);
                        DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_failure), getString(R.string.str_ok), false);
                    }
                }
            }
        });
    }

    private void onBack() {
        boolean isExerciseDataSaved;
        List<HraDBItem> exerciseSavedData = hraDBDao.queryBuilder().where(HraDBItemDao.Properties.ScreeNo.eq("24")).limit(1).list();
        isExerciseDataSaved = exerciseSavedData != null && exerciseSavedData.size() > 0;
        if (isExerciseDataSaved) {
            Utils.replaceFragmentHraBackAnimation(getFragmentManager(), HraQ30Fragment.newInstance(getArguments()), HraQ30Fragment.class.getSimpleName(), true, R.id.fragmentContainerHra);
        } else {
            Utils.replaceFragmentHraBackAnimation(getFragmentManager(), HraQ27And28Fragment.newInstance(getArguments()), HraQ27And28Fragment.class.getSimpleName(), true, R.id.fragmentContainerHra);
        }
    }

    private void cancelHra() {
        // if isRetakeTest parameter is true, then user always came here from hra report
        if (getArguments().containsKey("isRetakeTest") && getArguments().getBoolean("isRetakeTest")) {
            getFragmentManager().popBackStackImmediate(HraRiskGradeFragment.class.getSimpleName(), 0);
        } else {
            getActivity().finish();
        }
    }

}
