package com.truworth.wellnesscorner.repo.model.response;

import com.truworth.wellnesscorner.model.MealDataBean;
import com.truworth.wellnesscorner.model.ShareMealBean;

import java.util.List;

public class ShareMealResponse {

    private String memberName;
    private String memberImage;
    private List<ShareMealBean> meal;

    public String getMemberName() {
        return memberName;
    }

    public void setMemberName(String memberName) {
        this.memberName = memberName;
    }

    public String getMemberImage() {
        return memberImage;
    }

    public void setMemberImage(String memberImage) {
        this.memberImage = memberImage;
    }

    public List<ShareMealBean> getMeal() {
        return meal;
    }

    public void setMeal(List<ShareMealBean> meal) {
        this.meal = meal;
    }

}
