package com.truworth.wellnesscorner.ui.mytask;


import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Point;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.CardView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.truworth.discoverlib.ArticleDetailActivity;
import com.truworth.discoverlib.model.DiscoverUser;
import com.truworth.discoverlib.utils.DiscoverConfig;
import com.truworth.wellnesscorner.R;
import com.truworth.wellnesscorner.TheWellnessCornerApp;
import com.truworth.wellnesscorner.customviews.CustomTextView;
import com.truworth.wellnesscorner.data.SharedPreferenceHelper;
import com.truworth.wellnesscorner.model.DataMemberProgramItem;
import com.truworth.wellnesscorner.model.MemberProgramTaskDetailItem;
import com.truworth.wellnesscorner.repo.MyTaskRepository;
import com.truworth.wellnesscorner.repo.model.request.ActivityMarkAsReadBody;
import com.truworth.wellnesscorner.repo.model.request.GetMemberProgramDetailBody;
import com.truworth.wellnesscorner.repo.model.request.LeaveProgramChallengeBody;
import com.truworth.wellnesscorner.repo.model.response.ActivityMarkAsReadResponse;
import com.truworth.wellnesscorner.repo.model.response.GetMemberProgramDetailResponse;
import com.truworth.wellnesscorner.repo.model.response.LeaveProgramChallengeResponse;
import com.truworth.wellnesscorner.repo.model.response.MemberProgramComplianceResponse;
import com.truworth.wellnesscorner.utils.AppConstants;
import com.truworth.wellnesscorner.utils.CommonUtils;
import com.twc.dailylog.MealActivity;
import com.twc.dailylog.model.beans.DailyLogUser;
import com.twc.dailylog.utils.DailyLogConfig;
import com.twc.remindermodule.ReminderActivity;
import com.twc.remindermodule.model.beans.ReminderUser;
import com.twc.remindermodule.rest.ReminderConfig;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

import javax.inject.Inject;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;

/**
 * Created by richas on 2/16/2018.
 */

public class MyTasksFragment extends Fragment implements OnTrackerReadingSave {

    @BindView(R.id.rvMyTasks)
    RecyclerView rvMyTasks;
    @BindView(R.id.rootView)
    CardView rootView;
    @BindView(R.id.ivTaskMenu)
    ImageView ivTaskMenu;
    @BindView(R.id.tvNewestPopup)
    CustomTextView tvNewestPopup;
    @BindView(R.id.tvTasks)
    CustomTextView tvTasks;
    @BindView(R.id.tvSeperator)
    CustomTextView tvSeperator;
    @BindView(R.id.tvWellnessPlans)
    CustomTextView tvWellnessPlans;
    @BindView(R.id.rlNoTask)
    RelativeLayout rlNoTask;
    @BindView(R.id.ivErrorImage)
    ImageView ivErrorImage;
    @BindView(R.id.tvErrorTitle)
    CustomTextView tvErrorTitle;
    @BindView(R.id.tvErrorDescription)
    CustomTextView tvErrorDescription;
    @BindView(R.id.tvProgramName)
    CustomTextView tvProgramName;
    @BindView(R.id.tvProgramCategory)
    CustomTextView tvProgramCategory;
    @BindView(R.id.ivProgramImage)
    ImageView ivProgramImage;
    @BindView(R.id.llTaskPlan)
    LinearLayout llTaskPlan;
    @BindView(R.id.rlProgressTitle)
    RelativeLayout rlProgressTitle;
    @BindView(R.id.llProgressBarView)
    LinearLayout llProgressBarView;
    @BindView(R.id.pbDuration)
    ProgressBar pbDuration;
    @BindView(R.id.pbPeps)
    ProgressBar pbPeps;
    @BindView(R.id.pbCompliance)
    ProgressBar pbCompliance;
    @BindView(R.id.tvDuration)
    CustomTextView tvDuration;
    @BindView(R.id.tvPeps)
    CustomTextView tvPeps;
    @BindView(R.id.tvCompliance)
    CustomTextView tvCompliance;
    @BindView(R.id.tvBack)
    CustomTextView tvBack;
    @BindView(R.id.mainProgressBar)
    ProgressBar mainProgressBar;
    @BindView(R.id.rlRecyclerView)
    RelativeLayout rlRecyclerView;
    @Inject
    MyTaskRepository myTaskRepository;
    @Inject
    SharedPreferenceHelper prefHelper;
    private MyTasksAdapter myTasksAdapter;
    private List<MemberProgramTaskDetailItem> myTaskList;
    private List<MemberProgramTaskDetailItem> myPlanList;
    private MyWellnessPlanAdapter myWellnessPlanAdapter;
    private DataMemberProgramItem dataMemberProgramItem;
    private boolean isTaskSelected = true;
    private int mProgramId;
    private String mItemType;
    private int mitemId;
    private String mItemName;
    private int mWorkShopLevelId;
    private boolean isAllTaskDone = false;

    public static MyTasksFragment getInstance(DataMemberProgramItem dataMemberProgramItem) {
        MyTasksFragment myTasksFragment = new MyTasksFragment();
        myTasksFragment.setDataMemberProgramItem(dataMemberProgramItem);
        return myTasksFragment;
    }

    public DataMemberProgramItem getDataMemberProgramItem() {
        return dataMemberProgramItem;
    }

    public void setDataMemberProgramItem(DataMemberProgramItem dataMemberProgramItem) {
        this.dataMemberProgramItem = dataMemberProgramItem;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        TheWellnessCornerApp.getApp().component().inject(this);
        myTaskList = new ArrayList<>();
        myPlanList = new ArrayList<>();
        myTasksAdapter = new MyTasksAdapter(getActivity(), myTaskList, MyTasksFragment.this);
        myWellnessPlanAdapter = new MyWellnessPlanAdapter(getActivity(), myPlanList);
        if (dataMemberProgramItem != null)
            this.dataMemberProgramItem = dataMemberProgramItem;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.my_tasks_card_layout,
                container, false);
        ButterKnife.bind(this, view);
        setData();
        rvMyTasks.setHasFixedSize(true);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getActivity());
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        rvMyTasks.setLayoutManager(linearLayoutManager);
        rvMyTasks.setAdapter(myTasksAdapter);

        if (myPlanList.size() > 0) {
            tvSeperator.setVisibility(View.VISIBLE);
            tvWellnessPlans.setVisibility(View.VISIBLE);
        } else {
            tvSeperator.setVisibility(View.INVISIBLE);
            tvWellnessPlans.setVisibility(View.INVISIBLE);
        }

        if (isTaskSelected)
            clickMyTask(-1);
        else
            clickWellnessPlan();
        return view;
    }


    @Override
    public void setUserVisibleHint(final boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                if (isVisibleToUser && myTasksAdapter != null && myTasksAdapter.getItemCount() == 0) {
                    getMemberProgramTaskList();
                }
            }
        }, 150);


    }

    @OnClick({R.id.ivTaskMenu, R.id.tvNewestPopup, R.id.tvTasks, R.id.tvWellnessPlans, R.id.tvBack})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.ivTaskMenu:
                int[] location = new int[2];

                // Get the x, y location and store it in the location[] array. location[0] = x, location[1] = y.
                tvProgramName.getLocationOnScreen(location);

                //Initialize the Point with x, and y positions
                Point point = new Point();
                point.x = location[0];
                point.y = location[1];
                showMenuPopup(point);
                break;
            case R.id.tvNewestPopup:

                int[] location1 = new int[2];

                // Get the x, y location and store it in the location[] array. location[0] = x, location[1] = y.
                tvNewestPopup.getLocationOnScreen(location1);

                //Initialize the Point with x, and y positions
                Point point1 = new Point();
                point1.x = location1[0];
                point1.y = location1[1];
                showNewestPopup(point1);
                break;
            case R.id.tvTasks:
                clickMyTask(0);
                break;
            case R.id.tvWellnessPlans:
                clickWellnessPlan();
                break;
            case R.id.tvBack:
                llTaskPlan.setVisibility(View.VISIBLE);
                rlProgressTitle.setVisibility(View.GONE);
                llProgressBarView.setVisibility(View.GONE);

                if (isTaskSelected)      // navigate back to tasks from progress view
                {
                    if (isAllTaskDone) {
                        rlNoTask.setVisibility(View.VISIBLE);  // navigate back to all tasks done screen
                        callAllDone();
                    } else if (!isAllTaskDone && myTaskList.size() > 0) {
                        rlRecyclerView.setVisibility(View.VISIBLE);
                        rvMyTasks.setVisibility(View.VISIBLE);
                    } else if (!isAllTaskDone && myTaskList.size() == 0) {
                        rlNoTask.setVisibility(View.VISIBLE);  // navigate back to no tasks screen
                    }
                } else {           // navigate back to plans from progress view
                    rlRecyclerView.setVisibility(View.VISIBLE);
                    rvMyTasks.setVisibility(View.VISIBLE);
                    rlNoTask.setVisibility(View.GONE);
                }
                break;
        }
    }

    private void clickMyTask(int status) {
        isTaskSelected = true;
        Typeface faceTask = Typeface.createFromAsset(getActivity().getAssets(), "fonts/Roboto-Black.ttf");
        tvTasks.setTypeface(faceTask);

        Typeface facePlan = Typeface.createFromAsset(getActivity().getAssets(), "fonts/Roboto-Light.ttf");
        tvWellnessPlans.setTypeface(facePlan);

        if (isAllTaskDone) {
            callAllDone();
        } else {
            if (status != -1) {
                rvMyTasks.setAdapter(myTasksAdapter);
                if (myTaskList.size() > 0) {
                    rlNoTask.setVisibility(View.GONE);
                    rlRecyclerView.setVisibility(View.VISIBLE);
                    rvMyTasks.setVisibility(View.VISIBLE);
                } else {
                    rlNoTask.setVisibility(View.VISIBLE);
                    rlRecyclerView.setVisibility(View.GONE);
                    rvMyTasks.setVisibility(View.GONE);
                }
            }
        }
    }

    private void clickWellnessPlan() {
        isTaskSelected = false;
        Typeface faceTask = Typeface.createFromAsset(getActivity().getAssets(), "fonts/Roboto-Light.ttf");
        tvTasks.setTypeface(faceTask);

        Typeface facePlan = Typeface.createFromAsset(getActivity().getAssets(), "fonts/Roboto-Black.ttf");
        tvWellnessPlans.setTypeface(facePlan);

        if (myPlanList.size() > 0) {
            rlNoTask.setVisibility(View.GONE);
            rlRecyclerView.setVisibility(View.VISIBLE);
            rvMyTasks.setVisibility(View.VISIBLE);
            rvMyTasks.setAdapter(myWellnessPlanAdapter);
            tvSeperator.setVisibility(View.VISIBLE);
            tvWellnessPlans.setVisibility(View.VISIBLE);
        } else {
            tvSeperator.setVisibility(View.INVISIBLE);
            tvWellnessPlans.setVisibility(View.INVISIBLE);
        }
    }

    private void callAllDone() {
        rlNoTask.setVisibility(View.VISIBLE);
        rlRecyclerView.setVisibility(View.GONE);
        rvMyTasks.setVisibility(View.GONE);
        ivErrorImage.setImageResource(R.drawable.ic_all_done_final);
        tvErrorTitle.setText(getActivity().getResources().getString(R.string.all_done));
        tvErrorDescription.setText(getActivity().getResources().getString(R.string.you_have_completed_all_tasks));
    }

    private void showMenuPopup(Point p) {
        // Inflate the popup_layout.xml
        LayoutInflater layoutInflater = (LayoutInflater) getActivity().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View layout = layoutInflater.inflate(R.layout.my_task_menu_popup, null);

        CustomTextView tvViewProgress = layout.findViewById(R.id.tvViewProgress);
        CustomTextView tvViewProgramDetail = layout.findViewById(R.id.tvViewProgramDetail);
        CustomTextView tvLeaveProgram = layout.findViewById(R.id.tvLeaveProgram);

        // Creating the PopupWindow
        PopupWindow menuMyTask = new PopupWindow(getActivity());
        menuMyTask.setContentView(layout);
        menuMyTask.setWidth(LinearLayout.LayoutParams.WRAP_CONTENT);
        menuMyTask.setHeight(LinearLayout.LayoutParams.WRAP_CONTENT);
        menuMyTask.setFocusable(true);

        // Some offset to align the popup a bit to the left, and a bit down, relative to button's position.
        int OFFSET_X = -10;
        int OFFSET_Y = 90;

        //Clear the default translucent background
        menuMyTask.setBackgroundDrawable(new BitmapDrawable());

        // Displaying the popup at the specified location, + offsets.
        menuMyTask.showAtLocation(layout, Gravity.TOP | Gravity.START, p.x + OFFSET_X, p.y + OFFSET_Y);

        tvViewProgress.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                llTaskPlan.setVisibility(View.GONE);
                rlProgressTitle.setVisibility(View.VISIBLE);
                llProgressBarView.setVisibility(View.VISIBLE);

                if (rvMyTasks.getVisibility() == View.VISIBLE) {
                    rlRecyclerView.setVisibility(View.GONE);
                    rvMyTasks.setVisibility(View.GONE);
                } else if (rlNoTask.getVisibility() == View.VISIBLE)
                    rlNoTask.setVisibility(View.GONE);

                getMemberProgressDetailsApiCall();
                menuMyTask.dismiss();
            }
        });

        tvViewProgramDetail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                menuMyTask.dismiss();
                Bundle bundle = new Bundle();
                bundle.putInt("PROGRAM_ID", getDataMemberProgramItem().getWorkshop_ID());
                //   Utils.replaceFragment(getParentFragment().getFragmentManager(), ProgramDetailFragment.newInstance(bundle), ProgramDetailFragment.class.getSimpleName(), true, R.id.fragmentContainer);
            }
        });
        tvLeaveProgram.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CommonUtils.showAlertDialog(getActivity(), getString(R.string.app_name), 0, "If you leave in the middle of the program, the PEPs you earned during this program will be rolled back. Are you sure you want to leave this program?", getString(R.string.str_yes), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        menuMyTask.dismiss();
                        leaveProgram();
                    }
                }, getString(R.string.no), false);
            }
        });
    }


    private void showNewestPopup(Point p) {
        // Inflate the popup_layout.xml
        LayoutInflater layoutInflater = (LayoutInflater) getActivity().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View layout = layoutInflater.inflate(R.layout.my_task_newest_popup_layout, null);

        CustomTextView tvNewest = layout.findViewById(R.id.tvNewest);
        CustomTextView tvOldest = layout.findViewById(R.id.tvOldest);
        Typeface bold = Typeface.createFromAsset(getActivity().getAssets(), "fonts/Cabin-Bold.ttf");
        Typeface regular = Typeface.createFromAsset(getActivity().getAssets(), "fonts/Cabin-Regular.ttf");

        if (tvNewestPopup.getText().toString().equalsIgnoreCase("Newest"))
            tvNewest.setTypeface(bold);
        else
            tvNewest.setTypeface(regular);
        if (tvNewestPopup.getText().toString().equalsIgnoreCase("oldest"))
            tvOldest.setTypeface(bold);
        else
            tvOldest.setTypeface(regular);

        // Creating the PopupWindow
        PopupWindow menuMyTask = new PopupWindow(getActivity());
        menuMyTask.setContentView(layout);
        menuMyTask.setWidth(LinearLayout.LayoutParams.WRAP_CONTENT);
        menuMyTask.setHeight(LinearLayout.LayoutParams.WRAP_CONTENT);
        menuMyTask.setFocusable(true);

        // Some offset to align the popup a bit to the left, and a bit down, relative to button's position.
        int OFFSET_X = 0;
        int OFFSET_Y = 50;

        //Clear the default translucent background
        menuMyTask.setBackgroundDrawable(new BitmapDrawable());

        // Displaying the popup at the specified location, + offsets.
        menuMyTask.showAtLocation(layout, Gravity.NO_GRAVITY, p.x + OFFSET_X, p.y + OFFSET_Y);

        tvNewest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tvNewest.setTypeface(bold);
                tvOldest.setTypeface(regular);
                tvNewestPopup.setText(getActivity().getResources().getString(R.string.newest));
                menuMyTask.dismiss();
                sortTaskList(myTaskList, myPlanList, 0);
            }
        });

        tvOldest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tvNewest.setTypeface(regular);
                tvOldest.setTypeface(bold);
                tvNewestPopup.setText(getActivity().getResources().getString(R.string.oldest));
                menuMyTask.dismiss();
                sortTaskList(myTaskList, myPlanList, 1);
            }
        });
    }

    public CardView getCardView() {
        return rootView;
    }

    private void setData() {
        tvProgramName.setText(dataMemberProgramItem.getWorkshop_Name());
        tvProgramCategory.setText(dataMemberProgramItem.getProgram_Category());
        Glide.with(getActivity()).load(Uri.parse(dataMemberProgramItem.getWorkshop_Image())).apply(new RequestOptions().placeholder(R.drawable.wellness_no_logo)
                .error(R.drawable.wellness_no_logo).dontAnimate().dontTransform()).into(ivProgramImage);
    }

    // getProgram detail api call for all task
    private void getMemberProgramTaskList() {
        if (NetworkFactory.getInstance().isNetworkAvailable(getActivity())) {
            mainProgressBar.setVisibility(View.VISIBLE);
            GetMemberProgramDetailBody programDetailBody = new GetMemberProgramDetailBody();
            programDetailBody.setMemberPID(dataMemberProgramItem.getMemberPID());


            myTaskRepository.getMemberProgramDetail(programDetailBody).subscribe(new Observer<GetMemberProgramDetailResponse>() {
                @Override
                public void onSubscribe(Disposable d) {

                }

                @Override
                public void onNext(GetMemberProgramDetailResponse detailResponse) {
                    if (isAdded() && getActivity() != null) {
                        mainProgressBar.setVisibility(View.GONE);
                        if (detailResponse != null) {
                            if (detailResponse.getStatus() == 0) {

                                if (detailResponse.getData() != null) {
                                    // Task Status:  0 when all task pending
                                    // 1 when some task pending
                                    // 2 when all task completed
                                    if (detailResponse.getData().getTaskStatus() == 2) {
                                        isAllTaskDone = true;
                                        clickMyTask(detailResponse.getData().getTaskStatus());
                                    } else {
                                        isAllTaskDone = false;
                                        myPlanList.clear();
                                        myTaskList.clear();
                                        if (detailResponse.getData().getTaskDetail() != null && detailResponse.getData().getTaskDetail().size() > 0) {
                                            for (int i = 0; i < detailResponse.getData().getTaskDetail().size(); i++) {
                                                if (detailResponse.getData().getTaskDetail().get(i).getItemType().equalsIgnoreCase("PLANS")) {
                                                    myPlanList.add(detailResponse.getData().getTaskDetail().get(i));
                                                } else {
                                                    myTaskList.add(detailResponse.getData().getTaskDetail().get(i));
                                                }
                                            }
                                            //set data on plan tab
                                            if (myPlanList.size() > 0) {
                                                rvMyTasks.setAdapter(myWellnessPlanAdapter);
                                                rlNoTask.setVisibility(View.GONE);
                                                rvMyTasks.setVisibility(View.VISIBLE);
                                                rlRecyclerView.setVisibility(View.VISIBLE);
                                                tvSeperator.setVisibility(View.VISIBLE);
                                                tvWellnessPlans.setVisibility(View.VISIBLE);
                                            } else {
                                                tvSeperator.setVisibility(View.INVISIBLE);
                                                tvWellnessPlans.setVisibility(View.INVISIBLE);
                                            }
                                            //set data on task tab
                                            if (myTaskList.size() > 0) {
                                                rvMyTasks.setAdapter(myTasksAdapter);
                                                rlNoTask.setVisibility(View.GONE);
                                                rlRecyclerView.setVisibility(View.VISIBLE);
                                                rvMyTasks.setVisibility(View.VISIBLE);
                                            } else {
                                                rlNoTask.setVisibility(View.VISIBLE);
                                                rlRecyclerView.setVisibility(View.GONE);
                                                rvMyTasks.setVisibility(View.GONE);
                                            }

                                            if (isTaskSelected)
                                                clickMyTask(detailResponse.getData().getTaskStatus());
                                            else
                                                clickWellnessPlan();
                                            // to sort the list for new and old type
                                            sortTaskList(myTaskList, myPlanList, 0);
                                        }

                                    }
                                }
                                if (detailResponse.getData().getProgarm() == null) {
                                    MyTaskPagerFragment myplanPagerFragment = (MyTaskPagerFragment) getParentFragment();
                                    MyTaskPagerAdapter myTaskPagerAdapter = (MyTaskPagerAdapter) myplanPagerFragment.viewPager.getAdapter();
                                    myTaskPagerAdapter.removeItem(myplanPagerFragment.viewPager.getCurrentItem());

                                    myplanPagerFragment.viewPager.setAdapter(null);
                                    myplanPagerFragment.viewPager.setAdapter(myTaskPagerAdapter);
                                }
                            }
                        } else {
                            //  DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_response_failure), getString(R.string.str_ok), false);
                            Toast.makeText(getActivity(), getString(R.string.msg_api_response_failure), Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        // DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_response_null), getString(R.string.str_ok), false);
                        Toast.makeText(getActivity(), getString(R.string.msg_api_response_null), Toast.LENGTH_SHORT).show();
                    }
                }

                @Override
                public void onError(Throwable e) {
                    if (isAdded() && getActivity() != null) {
                        mainProgressBar.setVisibility(View.GONE);
                        // DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_failure), getString(R.string.str_ok), false);
                        Toast.makeText(getActivity(), getString(R.string.msg_api_failure), Toast.LENGTH_SHORT).show();
                    }
                }

                @Override
                public void onComplete() {

                }
            });
        } else {
            //Utils.showSnackBarMessage(rootView, getString(R.string.internet_not_available));
            Toast.makeText(getActivity(), getString(R.string.internet_not_available), Toast.LENGTH_SHORT).show();
        }
    }

    private void sortTaskList(List<MemberProgramTaskDetailItem> taskDetailItems, List<MemberProgramTaskDetailItem> planListItems, int sortCategory) {
        // 0 for new 1 for old
        if (sortCategory == 0) {
            Collections.sort(taskDetailItems, new Comparator<MemberProgramTaskDetailItem>() {
                @Override
                public int compare(MemberProgramTaskDetailItem lhs, MemberProgramTaskDetailItem rhs) {
                    return Integer.valueOf(lhs.getWorkshopLevel_Day()).compareTo(rhs.getWorkshopLevel_Day());
                }
            });
            Collections.sort(planListItems, new Comparator<MemberProgramTaskDetailItem>() {
                @Override
                public int compare(MemberProgramTaskDetailItem lhs, MemberProgramTaskDetailItem rhs) {
                    return Integer.valueOf(lhs.getWorkshopLevel_Day()).compareTo(rhs.getWorkshopLevel_Day());
                }
            });
        } else if (sortCategory == 1) {
            Collections.sort(taskDetailItems, new Comparator<MemberProgramTaskDetailItem>() {
                @Override
                public int compare(MemberProgramTaskDetailItem lhs, MemberProgramTaskDetailItem rhs) {
                    return Integer.valueOf(rhs.getWorkshopLevel_Day()).compareTo(lhs.getWorkshopLevel_Day());
                }
            });
            Collections.sort(planListItems, new Comparator<MemberProgramTaskDetailItem>() {
                @Override
                public int compare(MemberProgramTaskDetailItem lhs, MemberProgramTaskDetailItem rhs) {
                    return Integer.valueOf(rhs.getWorkshopLevel_Day()).compareTo(lhs.getWorkshopLevel_Day());
                }
            });
        }
        myTasksAdapter.notifyDataSetChanged();
        myWellnessPlanAdapter.notifyDataSetChanged();
    }

    // api call for task complete
    public void completeTaskApiWithRedirection(int programId, final String itemType, final int itemId, final String itemName, int workShopLevelId, final String articleURL) {
        if (NetworkFactory.getInstance().isNetworkAvailable(getActivity())) {
            final CustomProgressDialog pd;
            pd = new CustomProgressDialog(getActivity(), R.style.custom_progress_style, true);
            pd.show();
            ActivityMarkAsReadBody activityMarkAsReadBody = new ActivityMarkAsReadBody();
            activityMarkAsReadBody.setProgramID(programId);
            activityMarkAsReadBody.setItemType(itemType);
            activityMarkAsReadBody.setItemID(itemId);
            activityMarkAsReadBody.setItemName(itemName);
            activityMarkAsReadBody.setWorkshopLevelID(workShopLevelId);

            myTaskRepository.getActivityMarkAsRead(activityMarkAsReadBody).subscribe(new Observer<ActivityMarkAsReadResponse>() {
                @Override
                public void onSubscribe(Disposable d) {

                }

                @Override
                public void onNext(ActivityMarkAsReadResponse markAsReadResponse) {
                    if (isAdded() && getActivity() != null) {

                        if (pd != null && pd.isShowing())
                            pd.dismiss();
                        if (markAsReadResponse != null) {

                            if (markAsReadResponse.getStatus() == 0) {
                                Bundle bundle = new Bundle();
                                bundle.putInt("ARTICLE_ID", itemId);
                                for (int z = 0; z < myTaskList.size(); z++) {
                                    if (itemName.equalsIgnoreCase(myTaskList.get(z).getItemName())) {
                                        myTaskList.remove(z);
                                        break;
                                    }
                                }
                                if (itemType.equalsIgnoreCase("ARTICLE")) {
                                    //  bundle.putString("ARTICLE_ID", articleURL);
                                    //  Utils.replaceFragment(getActivity().getFragmentManager(), ArticleDetailFragmentNew.newInstance(bundle), ArticleDetailFragmentNew.class.getSimpleName(), true, R.id.fragmentContainer);
                                    DiscoverUser discoverUser = new DiscoverUser("0", "bearer " + prefHelper.getToken());
                                    DiscoverConfig.init("Wellness", "http://demo.truworth.net/twcmobileapi/member/", discoverUser, false);

                                    if (!DiscoverConfig.APP_NAME.isEmpty() && !DiscoverConfig.BASE_URL.isEmpty() && DiscoverConfig.discoverUser != null) {
                                        Intent intent = new Intent(getContext(), ArticleDetailActivity.class);
                                        intent.putExtra("ARTICLE_ID", articleURL);
                                        getContext().startActivity(intent);
                                    }

                                } else if (itemType.equalsIgnoreCase("TASK")) {
                                    rvMyTasks.setAdapter(myTasksAdapter);
                                    myTasksAdapter.notifyDataSetChanged();

                                } else if (itemType.equalsIgnoreCase("")) {

                                    if (itemName.equalsIgnoreCase("Calorie Tracker")) {

                                        // as discussed with Aslam on 9 Jan 2018
                                      /*  WellnessCornerApp.getInstance().setTrackDate(CommonUtils.getTodayDate("MM/dd/yyyy"));
                                        Bundle bundleMeal = new Bundle();
                                        bundleMeal.putString("trackMealType", getString(R.string.breakfast));
                                      Utils.replaceFragment(getFragmentManager(), TrackMealFragment.newInstance(bundleMeal), TrackMealFragment.class.getSimpleName(), true, R.id.fragmentContainer);*/
                                       /* DailyLogUser dailyLogUser = new DailyLogUser("0", "Meal", "Breakfast",
                                                "bearer " + prefHelper.getToken());
                                        DailyLogConfig.init("Wellness", "http://demo.truworth.net/twcmobileapi/", dailyLogUser, false);
                                        Intent intent = new Intent(getActivity(), MealActivity.class);
                                        startActivity(intent);*/
                                    } else {
                                        rvMyTasks.setAdapter(myTasksAdapter);
                                        myTasksAdapter.notifyDataSetChanged();
                                    }

                                } else if (itemType.equalsIgnoreCase("Exercise")) {
                                    rvMyTasks.setAdapter(myTasksAdapter);
                                    myTasksAdapter.notifyDataSetChanged();
                                }
                                // if task type is different
                                else {
                                    rvMyTasks.setAdapter(myTasksAdapter);
                                    myTasksAdapter.notifyDataSetChanged();
                                }
                                if (myTaskList.size() == 0) {
                                    // getParentFragment().getFragmentManager().popBackStackImmediate();
                                    isAllTaskDone = true;
                                    callAllDone();
                                }

                            } else {

                                Toast.makeText(getActivity(), getString(R.string.msg_api_response_failure), Toast.LENGTH_SHORT).show();
                            }
                        } else {
                            Toast.makeText(getActivity(), getString(R.string.msg_api_response_failure), Toast.LENGTH_SHORT).show();

                        }
                    }
                }

                @Override
                public void onError(Throwable e) {
                    if (isAdded() && getActivity() != null) {
                        if (pd != null && pd.isShowing())
                            pd.dismiss();
                        Toast.makeText(getActivity(), getString(R.string.msg_api_failure), Toast.LENGTH_SHORT).show();
                    }
                }

                @Override
                public void onComplete() {

                }
            });
        }
    }

    public void completeTaskApiCall(int programId, final String itemType, final int itemId, final String itemName, int workShopLevelId, final String articleURL) {
        if (NetworkFactory.getInstance().isNetworkAvailable(getActivity())) {
            final CustomProgressDialog pd;
            pd = new CustomProgressDialog(getActivity(), R.style.custom_progress_style, true);
            pd.show();
            ActivityMarkAsReadBody activityMarkAsReadBody = new ActivityMarkAsReadBody();
            activityMarkAsReadBody.setProgramID(programId);
            activityMarkAsReadBody.setItemType(itemType);
            activityMarkAsReadBody.setItemID(itemId);
            activityMarkAsReadBody.setItemName(itemName);
            activityMarkAsReadBody.setWorkshopLevelID(workShopLevelId);

            myTaskRepository.getActivityMarkAsRead(activityMarkAsReadBody).subscribe(new Observer<ActivityMarkAsReadResponse>() {
                @Override
                public void onSubscribe(Disposable d) {

                }

                @Override
                public void onNext(ActivityMarkAsReadResponse markAsReadResponse) {
                    if (isAdded() && getActivity() != null) {

                        if (pd != null && pd.isShowing())
                            pd.dismiss();
                        if (markAsReadResponse != null) {

                            if (markAsReadResponse.getStatus() == 0) {
                                for (int z = 0; z < myTaskList.size(); z++) {
                                    if (itemName.equalsIgnoreCase(myTaskList.get(z).getItemName())) {
                                        myTaskList.remove(z);
                                        break;
                                    }
                                }
                                rvMyTasks.setAdapter(myTasksAdapter);
                                myTasksAdapter.notifyDataSetChanged();

                                if (myTaskList.size() == 0) {
                                    // getParentFragment().getFragmentManager().popBackStackImmediate();
                                    isAllTaskDone = true;
                                    callAllDone();
                                }
                            } else {
                                Toast.makeText(getActivity(), getString(R.string.msg_api_response_failure), Toast.LENGTH_SHORT).show();
                            }
                        } else {
                            Toast.makeText(getActivity(), getString(R.string.msg_api_response_failure), Toast.LENGTH_SHORT).show();
                        }
                    }
                }

                @Override
                public void onError(Throwable e) {
                    if (isAdded() && getActivity() != null) {
                        if (pd != null && pd.isShowing())
                            pd.dismiss();
                        Toast.makeText(getActivity(), getString(R.string.msg_api_failure), Toast.LENGTH_SHORT).show();
                    }
                }

                @Override
                public void onComplete() {

                }
            });
        }
    }

    public void launchTracker(Bundle bundle, int programId, String itemType, int itemId, String itemName, int workShopLevelId) {
        mProgramId = programId;
        mItemType = itemType;
        mitemId = itemId;
        mItemName = itemName;
        mWorkShopLevelId = workShopLevelId;

      /*  AddTrackerReading addTrackerReading = AddTrackerReading.newInstance(bundle);
        addTrackerReading.setTrackerReadingCallback(this);
        Utils.replaceFragment(getParentFragment().getFragmentManager(), addTrackerReading, AddTrackerReading.class.getSimpleName(), true, R.id.fragmentContainer);*/
    }

    public void launchWeightTracker(Bundle bundle, int programId, String itemType, int itemId, String itemName, int workShopLevelId) {
        mProgramId = programId;
        mItemType = itemType;
        mitemId = itemId;
        mItemName = itemName;
        mWorkShopLevelId = workShopLevelId;

        DailyLogConfig.dailyLogUser.setType("TaskWeight");
        DailyLogConfig.dailyLogUser.setMealType("");

        MealActivity mealActivity=new MealActivity(this::onTrackerReadingSuccess);

        Intent intent = new Intent(getActivity(), mealActivity.getClass());
        intent.putExtra("AddWeight", bundle);
        startActivity(intent);
    }

    public void launchFoodTracker(Bundle bundle, int programId, String itemType, int itemId, String itemName, int workShopLevelId) {
        mProgramId = programId;
        mItemType = itemType;
        mitemId = itemId;
        mItemName = itemName;
        mWorkShopLevelId = workShopLevelId;

        //   WellnessCornerApp.getInstance().setTrackDate(DateFactory.getInstance().getTodayDate("MM/dd/yyyy"));
        completeTaskApiCall(mProgramId, mItemType, mitemId, mItemName, mWorkShopLevelId, "");
    }

    public void launchExerciseTracker(Bundle bundle, int programId, String itemType, int itemId, String itemName, int workShopLevelId) {

        mProgramId = programId;
        mItemType = itemType;
        mitemId = itemId;
        mItemName = itemName;
        mWorkShopLevelId = workShopLevelId;

        DailyLogConfig.dailyLogUser.setType("TaskExercise");
        DailyLogConfig.dailyLogUser.setMealType("");

        MealActivity mealActivity=new MealActivity(this::onTrackerReadingSuccess);

        Intent intent = new Intent(getActivity(), mealActivity.getClass());
        intent.putExtras(bundle);
        startActivity(intent);
    }

    public void launchSleepTracker(Bundle bundle, int programId, String itemType, int itemId, String itemName, int workShopLevelId) {

        mProgramId = programId;
        mItemType = itemType;
        mitemId = itemId;
        mItemName = itemName;
        mWorkShopLevelId = workShopLevelId;

   /*     WellnessCornerApp.getInstance().setTrackDate(DateFactory.getInstance().getTodayDate("MM/dd/yyyy"));
        SleepTrackerLogsFragment sleepTrackerFragment = new SleepTrackerLogsFragment();
        sleepTrackerFragment.setTrackerReadingCallback(this);
        Utils.replaceFragment(getParentFragment().getFragmentManager(), sleepTrackerFragment, SleepTrackerLogsFragment.class.getSimpleName(), true, R.id.fragmentContainer);*/

       // ReminderUser reminderUser = new ReminderUser("0", true, "bearer " + prefHelper.getToken());
       // ReminderConfig.init("Wellness", AppConstants.API_ENDPOINT, reminderUser, false, getActivity());

        if (!ReminderConfig.APP_NAME.isEmpty() && !ReminderConfig.BASE_URL.isEmpty() && ReminderConfig.reminderUser != null) {
            Intent intent = new Intent(getActivity(), ReminderActivity.class);
            intent.putExtra("Sleep", "sleep");
            intent.putExtra("token", prefHelper.getToken());
            startActivity(intent);
        }
    }

    @Override
    public void onTrackerReadingSuccess() {
        completeTaskApiCall(mProgramId, mItemType, mitemId, mItemName, mWorkShopLevelId, "");
    }

    // leave program api call
    private void leaveProgram() {
        final CustomProgressDialog pd;
        pd = new CustomProgressDialog(getActivity(), R.style.custom_progress_style, true);
        pd.show();
        if (NetworkFactory.getInstance().isNetworkAvailable(getActivity())) {
            LeaveProgramChallengeBody leaveProgramChallengeBody = new LeaveProgramChallengeBody();
            leaveProgramChallengeBody.setType("Program");
            leaveProgramChallengeBody.setMemberID(Integer.parseInt(MyTaskConfig.myTaskUser.getUserID()));
            leaveProgramChallengeBody.setID(dataMemberProgramItem.getWorkshop_ID());


            myTaskRepository.leaveProgram(leaveProgramChallengeBody).subscribe(new Observer<LeaveProgramChallengeResponse>() {
                @Override
                public void onSubscribe(Disposable d) {

                }

                @Override
                public void onNext(LeaveProgramChallengeResponse leaveProgramChallengeResponse) {
                    if (isAdded() && getActivity() != null) {
                        if (pd != null && pd.isShowing())
                            pd.dismiss();
                        if (leaveProgramChallengeResponse != null) {
                            if (leaveProgramChallengeResponse.getStatus() == 0) {
                                getMemberProgramTaskList();
                            } else if (leaveProgramChallengeResponse.getStatus() == -2) {
                                //DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.err_during_leaving_program), getString(R.string.str_ok), false);
                                Toast.makeText(getActivity(), getString(R.string.err_during_leaving_program), Toast.LENGTH_SHORT).show();
                            } else if (leaveProgramChallengeResponse.getStatus() == -1) {
                                //   DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_response_failure), getString(R.string.str_ok), false);
                                Toast.makeText(getActivity(), getString(R.string.msg_api_response_failure), Toast.LENGTH_SHORT).show();
                            }
                        } else {
                            // DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_response_null), getString(R.string.str_ok), false);
                            Toast.makeText(getActivity(), getString(R.string.msg_api_response_null), Toast.LENGTH_SHORT).show();
                        }
                    }
                }

                @Override
                public void onError(Throwable e) {
                    if (isAdded() && getActivity() != null) {
                        if (pd != null && pd.isShowing())
                            pd.dismiss();
                        //  DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_failure), getString(R.string.str_ok), false);
                        Toast.makeText(getActivity(), getString(R.string.msg_api_failure), Toast.LENGTH_SHORT).show();
                    }
                }

                @Override
                public void onComplete() {

                }
            });
        } else {
            // Utils.showSnackBarMessage(rootView, getString(R.string.internet_not_available));
            Toast.makeText(getActivity(), getString(R.string.internet_not_available), Toast.LENGTH_SHORT).show();
        }
    }

    //api call for progress compliance
    private void getMemberProgressDetailsApiCall() {
        final CustomProgressDialog pd;
        pd = new CustomProgressDialog(getActivity(), R.style.custom_progress_style, true);
        pd.show();
        if (NetworkFactory.getInstance().isNetworkAvailable(getActivity())) {
            GetMemberProgramDetailBody memberProgramDetailBody = new GetMemberProgramDetailBody();
            memberProgramDetailBody.setMemberPID(dataMemberProgramItem.getMemberPID());

            myTaskRepository.memberProgramCompliance(memberProgramDetailBody).subscribe(new Observer<MemberProgramComplianceResponse>() {
                @Override
                public void onSubscribe(Disposable d) {

                }

                @Override
                public void onNext(MemberProgramComplianceResponse complianceResponse) {
                    if (isAdded() && getActivity() != null) {
                        if (pd != null && pd.isShowing())
                            pd.dismiss();
                        if (complianceResponse != null) {
                            if (complianceResponse.getStatus() == 0) {
                                if (complianceResponse.getData() != null) {
                                    // set Duration
                                    int currentDay = complianceResponse.getData().getDayNo();
                                    int totalDays = complianceResponse.getData().getTotal_Days();
                                    pbDuration.setMax(totalDays);
                                    pbDuration.setProgress(currentDay);
                                    if (totalDays > 1)
                                        tvDuration.setText(String.format(Locale.getDefault(), "Duration - %d/%d Days", currentDay, totalDays));
                                    else if (totalDays == 1)
                                        tvDuration.setText(String.format(Locale.getDefault(), "Duration - %d/%d Day", currentDay, totalDays));

                                    // set Peps
                                    int earned_Peps = complianceResponse.getData().getEarned_Peps();
                                    int totalPeps = complianceResponse.getData().getTotal_Peps();
                                    pbPeps.setMax(totalPeps);
                                    pbPeps.setProgress(earned_Peps);
                                    tvPeps.setText(String.format(Locale.getDefault(), "PEPs - %d/%d", earned_Peps, totalPeps));

                                    // set Compliance
                                    int complaincePercent = (int) (complianceResponse.getData().getProgram_Compliance());
                                    pbCompliance.setMax(100);
                                    pbCompliance.setProgress(complaincePercent);
                                    tvCompliance.setText(String.format(Locale.getDefault(), "Compliance - %d%%", complaincePercent));

                                }

                            } else if (complianceResponse.getStatus() == -1) {
                                // DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_response_failure), getString(R.string.str_ok), false);
                                Toast.makeText(getActivity(), getString(R.string.msg_api_response_failure), Toast.LENGTH_SHORT).show();
                            }
                        } else {
                            //  DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_response_null), getString(R.string.str_ok), false);
                            Toast.makeText(getActivity(), getString(R.string.msg_api_failure), Toast.LENGTH_SHORT).show();
                        }
                    }
                }

                @Override
                public void onError(Throwable e) {
                    if (isAdded() && getActivity() != null) {
                        if (pd != null && pd.isShowing())
                            pd.dismiss();
                        //  DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_failure), getString(R.string.str_ok), false);
                        Toast.makeText(getActivity(), getString(R.string.msg_api_failure), Toast.LENGTH_SHORT).show();
                    }
                }

                @Override
                public void onComplete() {

                }
            });
        } else {
            //  Utils.showSnackBarMessage(rootView, getString(R.string.internet_not_available));
            Toast.makeText(getActivity(), getString(R.string.internet_not_available), Toast.LENGTH_SHORT).show();
        }
    }

    // api call for task delete
    public void deleteTaskApiCall(MemberProgramTaskDetailItem position, int programId, final String itemType, final int itemId, final String itemName, int workShopLevelId, final String articleURL) {
        if (NetworkFactory.getInstance().isNetworkAvailable(getActivity())) {
            final CustomProgressDialog pd;
            pd = new CustomProgressDialog(getActivity(), R.style.custom_progress_style, true);
            pd.show();
            ActivityMarkAsReadBody activityMarkAsReadBody = new ActivityMarkAsReadBody();
            activityMarkAsReadBody.setProgramID(programId);
            activityMarkAsReadBody.setItemType(itemType);
            activityMarkAsReadBody.setItemID(itemId);
            activityMarkAsReadBody.setItemName(itemName);
            activityMarkAsReadBody.setWorkshopLevelID(workShopLevelId);

            myTaskRepository.getActivityMarkAsDelete(activityMarkAsReadBody).subscribe(new Observer<ActivityMarkAsReadResponse>() {
                @Override
                public void onSubscribe(Disposable d) {

                }

                @Override
                public void onNext(ActivityMarkAsReadResponse deleteResponse) {
                    if (isAdded() && getActivity() != null) {

                        if (pd != null && pd.isShowing())
                            pd.dismiss();
                        if (deleteResponse != null) {

                            if (deleteResponse.getStatus() == 0) {
                                myTaskList.remove(position);
                                rvMyTasks.setAdapter(myTasksAdapter);
                                myTasksAdapter.notifyDataSetChanged();

                                if (myTaskList.size() == 0) {
                                    isAllTaskDone = true;
                                    callAllDone();
                                }

                            } else {
                                Toast.makeText(getActivity(), getString(R.string.msg_api_response_failure), Toast.LENGTH_SHORT).show();
                            }
                        } else {
                            Toast.makeText(getActivity(), getString(R.string.msg_api_response_failure), Toast.LENGTH_SHORT).show();

                        }
                    }
                }

                @Override
                public void onError(Throwable e) {
                    if (isAdded() && getActivity() != null) {
                        if (pd != null && pd.isShowing())
                            pd.dismiss();
                        Toast.makeText(getActivity(), getString(R.string.msg_api_failure), Toast.LENGTH_SHORT).show();
                    }
                }

                @Override
                public void onComplete() {

                }
            });
        }
    }
}
