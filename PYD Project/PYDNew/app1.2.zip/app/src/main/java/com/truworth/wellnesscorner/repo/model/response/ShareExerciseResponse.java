package com.truworth.wellnesscorner.repo.model.response;

import com.truworth.wellnesscorner.model.ShareExerciseBean;

import java.util.List;

public class ShareExerciseResponse {

    private boolean hasError;
    private Error error;
    private List<ShareExerciseBean> data;

    public boolean isHasError() {
        return hasError;
    }

    public void setHasError(boolean hasError) {
        this.hasError = hasError;
    }

    public Error getError() {
        return error;
    }

    public void setError(Error error) {
        this.error = error;
    }

    public List<ShareExerciseBean> getData() {
        return data;
    }

    public void setData(List<ShareExerciseBean> data) {
        this.data = data;
    }

}
