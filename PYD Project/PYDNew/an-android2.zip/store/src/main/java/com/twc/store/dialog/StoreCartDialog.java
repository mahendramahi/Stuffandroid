package com.twc.store.dialog;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.ImageView;

import com.bumptech.glide.Glide;

import com.twc.store.R;
import com.twc.store.fragments.StoreMyCartFragment;
import com.twc.store.utils.Utils;
import com.twc.store.views.ViewCustomRoundedTextView;


/**
 * Created by GurvinderS on 1/31/2018.
 */

public class StoreCartDialog extends Dialog {

    private Activity activity;
    private Bundle bundle;
    public StoreCartDialog(Context context, Activity activity) {
        super(context, R.style.CustomAlertDialog);

        this.activity = activity;


    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.dialog_store_cart);

        ViewCustomRoundedTextView btnContinueShopping=findViewById(R.id.btnContinueShopping);
        ViewCustomRoundedTextView btnProceedToCheckOut=findViewById(R.id.btnProceedToCheckOut);

       btnContinueShopping.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
               dismiss();
           }
       });
        btnProceedToCheckOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dismiss();
               Utils.replaceFragment(activity.getFragmentManager(), StoreMyCartFragment.newInstance(), StoreMyCartFragment.class.getSimpleName(), true, R.id.fragmentContainer);
            }
        });

        ImageView ivCart=findViewById(R.id.ivCart);
        Glide.with(activity)
                .load(R.drawable.cart_icon)
                .into(ivCart);
        setCancelable(true);
    }
}
