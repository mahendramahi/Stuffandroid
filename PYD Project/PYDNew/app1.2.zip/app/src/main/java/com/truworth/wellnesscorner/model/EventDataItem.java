package com.truworth.wellnesscorner.model;

import java.util.List;

public class EventDataItem {
    private int totalMembersGoing;
    private List<MemberImages> memberImages;

    public int getTotalMembersGoing() {
        return totalMembersGoing;
    }

    public void setTotalMembersGoing(int totalMembersGoing) {
        this.totalMembersGoing = totalMembersGoing;
    }

    public List<MemberImages> getMemberImages() {
        return memberImages;
    }

    public void setMemberImages(List<MemberImages> memberImages) {
        this.memberImages = memberImages;
    }
}
