package com.truworth.wellnesscorner.repo.model.response;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.truworth.wellnesscorner.model.CountryData;

import java.util.ArrayList;

/**
 * Created by rajeshs on 4/2/2018.
 */

public class CountryResponse {

    @SerializedName("data")
    @Expose
    private ArrayList<CountryData> data;
    @SerializedName("hasError")
    @Expose
    private boolean hasError;
    @SerializedName("message")
    @Expose
    private String message;

    @SerializedName("error")
    @Expose
    private Error error;

    public ArrayList<CountryData> getData() {
        return data;
    }

    public void setData(ArrayList<CountryData> data) {
        this.data = data;
    }

    public boolean isHasError() {
        return hasError;
    }

    public void setHasError(boolean hasError) {
        this.hasError = hasError;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Error getError() {
        return error;
    }

    public void setError(Error error) {
        this.error = error;
    }
}
