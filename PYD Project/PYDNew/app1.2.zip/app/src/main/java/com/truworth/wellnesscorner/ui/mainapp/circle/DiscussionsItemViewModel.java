package com.truworth.wellnesscorner.ui.mainapp.circle;

import android.text.SpannableStringBuilder;

import com.truworth.wellnesscorner.base.BaseViewModel;
import com.truworth.wellnesscorner.model.Discussions;
import com.truworth.wellnesscorner.utils.CommonUtils;
import com.truworth.wellnesscorner.utils.DateUtils;
import com.truworth.wellnesscorner.utils.Utils;

/**
 * Created by PalakC on 4/19/2018.
 */

public class DiscussionsItemViewModel extends BaseViewModel {
    Discussions discussions;

    public DiscussionsItemViewModel(Discussions discussions) {
        this.discussions = discussions;
    }

    public Discussions getDiscussions() {
        return discussions;
    }

    public String getImage() {
        return discussions.getMember_Image();
    }

    public String getdays() {
        String discussionDate = DateUtils.getInstance().truncateMilliseconds(discussions.getAnsweredOn());
        String toDate = DateUtils.getInstance().formatDate(discussionDate, "yyyy-MM-dd'T'HH:mm:ss", "yyyy-MM-dd");
        String date = DateUtils.getInstance().getDaysDifference(toDate, DateUtils.getTodayDate("yyyy-MM-dd"), "yyyy-MM-dd");
        return date;
    }

    public SpannableStringBuilder getNameBio() {
        SpannableStringBuilder nameBio = (Utils.makeSpecificTextBold(discussions.getAnsweredBy(),discussions.getAnsweredBy()));
        if (discussions.getAnsweredByBio() != null)
            nameBio = Utils.makeSpecificTextBold((discussions.getAnsweredBy()+", "+discussions.getAnsweredByBio()),discussions.getAnsweredBy()+", ");
        return nameBio;
    }

}
