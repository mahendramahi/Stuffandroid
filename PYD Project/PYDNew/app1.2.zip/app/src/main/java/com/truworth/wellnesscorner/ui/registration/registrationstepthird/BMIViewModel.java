package com.truworth.wellnesscorner.ui.registration.registrationstepthird;

import android.databinding.ObservableDouble;
import android.databinding.ObservableField;
import android.databinding.ObservableInt;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Build;
import android.text.Html;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.style.RelativeSizeSpan;
import android.text.style.StyleSpan;


import com.truworth.wellnesscorner.R;
import com.truworth.wellnesscorner.TheWellnessCornerApp;
import com.truworth.wellnesscorner.base.BaseViewModel;
import com.truworth.wellnesscorner.model.BMIData;
import com.truworth.wellnesscorner.repo.RegistrationRepository;
import com.truworth.wellnesscorner.repo.model.request.BMIRequest;
import com.truworth.wellnesscorner.repo.model.response.BMIResponse;
import com.truworth.wellnesscorner.utils.SingleLiveEvent;

import java.util.Locale;

import javax.inject.Inject;

import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;

/**
 * Created by rajeshs on 4/9/2018.
 */

public class BMIViewModel extends BaseViewModel {
    public ObservableDouble bmiValue = new ObservableDouble();
    public ObservableDouble ibwValue = new ObservableDouble();
    public ObservableField<String> bmiDescription = new ObservableField<>();
    public ObservableField<String> ibwDescription = new ObservableField<>();
    // public ObservableField<String> ibwDescriptionInfo = new ObservableField<>();

    public ObservableField<String> title = new ObservableField<>();
    public ObservableInt bgColor = new ObservableInt();
    public ObservableInt fontColor = new ObservableInt();
    SingleLiveEvent<String> onBmiLoaded = new SingleLiveEvent<>();
    SingleLiveEvent<Void> onClickContinue = new SingleLiveEvent<>();
    SingleLiveEvent<Void> onClickBmiCalculating = new SingleLiveEvent<>();

    SingleLiveEvent<String> onibwDescription = new SingleLiveEvent<>();
    SingleLiveEvent<String> onibwDescriptionInfo = new SingleLiveEvent<>();

    public SingleLiveEvent<String> getOnibwDescription() {
        return onibwDescription;
    }

    public SingleLiveEvent<String> getOnibwDescriptionInfo() {
        return onibwDescriptionInfo;
    }

    public SingleLiveEvent<String> getOnBmiLoaded() {
        return onBmiLoaded;
    }

    public SingleLiveEvent<Void> getOnClickContinue() {
        return onClickContinue;
    }

    public SingleLiveEvent<Void> getOnClickBmiCalculating() {
        return onClickBmiCalculating;
    }

    public ObservableInt getBgColor() {
        return bgColor;
    }

    public ObservableInt getFontColor() {
        return fontColor;
    }

    public void onClickContinueCall() {
        onClickContinue.call();
    }

    public void setBmiData(BMIData bmiData) {
        bgColor.set(Color.parseColor(bmiData.getColorCode()));
        bmiValue.set(bmiData.getBmi());
        ibwValue.set(bmiData.getIbw());
        bmiDescription.set(bmiData.getBmiDescription());
        title.set(bmiData.getBmiTitle());
       // ibwDescription.set(bmiData.getIbwDescription()+bmiData.getIbwDescriptionInfo());
        fontColor.set(Color.parseColor(bmiData.getFontColorCode()));
        onBmiLoaded.setValue(bmiData.getColorCode());
        onibwDescription.setValue(bmiData.getIbwDescription());
        onibwDescriptionInfo.setValue(bmiData.getIbwDescriptionInfo());
    }

    public void callBmiCalculating() {
        onClickBmiCalculating.call();
    }

}
