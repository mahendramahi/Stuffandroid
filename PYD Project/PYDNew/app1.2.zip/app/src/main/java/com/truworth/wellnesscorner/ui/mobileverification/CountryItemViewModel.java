package com.truworth.wellnesscorner.ui.mobileverification;

import com.truworth.wellnesscorner.base.BaseViewModel;
import com.truworth.wellnesscorner.model.CountryData;

public class CountryItemViewModel extends BaseViewModel {
    private CountryData countryData;
    private CountryCodeListener codeListener;

    public CountryItemViewModel(CountryData countryData,CountryCodeListener codeListener) {
        this.countryData = countryData;
        this.codeListener=codeListener;
    }

    public CountryData getCountryData() {
        return countryData;
    }

    public interface CountryCodeListener {
        void onItemClick();
    }
    public void onItemClick() {
        codeListener.onItemClick();
    }

}
