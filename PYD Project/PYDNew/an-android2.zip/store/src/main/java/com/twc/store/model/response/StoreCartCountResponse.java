package com.twc.store.model.response;

/**
 * Created by PalakC on 9/19/2017.
 */

public class StoreCartCountResponse {

    private int status;
    private int Data;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public int getData() {
        return Data;
    }

    public void setData(int Data) {
        this.Data = Data;
    }
}
