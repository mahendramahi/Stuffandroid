package com.twc.hramodule.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.twc.greendaolib.GreenDaoApp;
import com.twc.greendaolib.HraDBItemDao;
import com.twc.hramodule.HraActivity;
import com.twc.hramodule.R;
import com.twc.hramodule.R2;
import com.twc.hramodule.utils.Constant;
import com.twc.hramodule.utils.HRARedirectionUtils;
import com.twc.hramodule.utils.HraConfig;
import com.twc.hramodule.utils.Utils;

import butterknife.BindView;
import butterknife.OnClick;

/**
 * Created by GurvinderS on 10/21/2016.
 */
public class HraRiskGradeFragment extends BaseFragment {


    @BindView(R2.id.tvMsg)
    TextView tvMsg;

    @BindView(R2.id.tvScore)
    TextView tvScore;

    @BindView(R2.id.tvGradeA)
    TextView tvGradeA;

    @BindView(R2.id.tvGradeB)
    TextView tvGradeB;

    @BindView(R2.id.tvGradeC)
    TextView tvGradeC;

    @BindView(R2.id.tvGradeD)
    TextView tvGradeD;


    @BindView(R2.id.btnRetakeTest)
    Button btnRetakeTest;
    @BindView(R2.id.ivHRABack)
    ImageView ivHRABack;
    @BindView(R2.id.ivCancelHRA)
    ImageView ivCancelHRA;

    @BindView(R2.id.btnRecommendation)
    Button btnRecommendation;
    @BindView(R2.id.btnImprove)
    Button btnImprove;

    private String score;
    private String grade;
    private String msg;

    public static HraRiskGradeFragment newInstance(Bundle bundle) {
        HraRiskGradeFragment challengeDetailFragment = new HraRiskGradeFragment();
        challengeDetailFragment.setArguments(bundle);
        return challengeDetailFragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            Bundle bundle = getArguments();
            score = bundle.getString("score");
            grade = bundle.getString("grade");
            msg = bundle.getString("msg");
            if (getArguments().containsKey("isRetakeTest")) {
                getArguments().remove("isRetakeTest");
            }
        }
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        view.setFocusableInTouchMode(true);
        view.requestFocus();
        view.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (keyCode == KeyEvent.KEYCODE_BACK && event.getAction() == KeyEvent.ACTION_DOWN) {
                    onBack();
                    return true;
                }
                return false;
            }
        });
    }

    @Override
    public int getFragmentLayout() {
        return R.layout.fragment_hra_score;
    }

    @Override
    public void onFragmentReady() {

        tvScore.setText(score + "/" + "100");
        if (grade.equalsIgnoreCase("A")) {
            tvGradeA.setBackgroundResource(R.drawable.circle_hra_score_white);
            tvGradeA.setTextColor(ContextCompat.getColor(getActivity(), R.color.colorPrimary));
        } else if (grade.equalsIgnoreCase("B")) {
            tvGradeB.setBackgroundResource(R.drawable.circle_hra_score_white);
            tvGradeB.setTextColor(ContextCompat.getColor(getActivity(), R.color.colorPrimary));
        } else if (grade.equalsIgnoreCase("C")) {
            tvGradeC.setBackgroundResource(R.drawable.circle_hra_score_white);
            tvGradeC.setTextColor(ContextCompat.getColor(getActivity(), R.color.colorPrimary));
        } else if (grade.equalsIgnoreCase("D")) {
            tvGradeD.setBackgroundResource(R.drawable.circle_hra_score_white);
            tvGradeD.setTextColor(ContextCompat.getColor(getActivity(), R.color.colorPrimary));
        }
        changeTextView(msg);

        if (HraConfig.hraUser.getUserType().equalsIgnoreCase("PREMIUM")) {
            btnRecommendation.setText(getString(R.string.Recommendations));
        } else if (HraConfig.hraUser.getUserType().equalsIgnoreCase("BASIC")) {
            btnRecommendation.setText(R.string.proceed_dashboard);
        } else {
            btnRecommendation.setVisibility(View.GONE);
            ivCancelHRA.setVisibility(View.GONE);
        }
    }

    private void onBack() {
        getActivity().finish();
    }

    private void changeTextView(String message) {
        tvMsg.setText(message);
    }

    @OnClick({R2.id.btnImprove, R2.id.ivHRABack, R2.id.btnRetakeTest, R2.id.ivCancelHRA, R2.id.btnRecommendation})
    public void onClick(View view) {
        int i = view.getId();
        if (i == R.id.btnImprove) {
            Bundle bundle = new Bundle();
            bundle.putString(Constant.BUNDLE_GRADE_HRA, grade);
            bundle.putString(Constant.BUNDLE_SCORE_HRA, score);
            Utils.replaceFragment(getFragmentManager(), HraDetailedReportFragment.newInstance(bundle), HraDetailedReportFragment.class.getSimpleName(), true, R.id.fragmentContainerHra);

        } else if (i == R.id.ivHRABack) {
            onBack();

        } else if (i == R.id.btnRetakeTest) {
            Bundle bundleRetake = new Bundle();
            bundleRetake.putBoolean("isRetakeTest", true);
            HraDBItemDao hraDBItemDao = GreenDaoApp.getInstance(getActivity()).getDaoSession(getActivity()).getHraDBItemDao();
            HRARedirectionUtils.getInstance().navigateToHRAQuestionScreen(bundleRetake, getFragmentManager(), hraDBItemDao);

        } else if (i == R.id.ivCancelHRA) {
            getActivity().finish();

        } else if (i == R.id.btnRecommendation) {
            try {
                Intent myIntent = new Intent(getActivity(), Class.forName("com.twc.mvvmdemo.view.ui.MainActivity"));
                startActivity(myIntent);
            }
             catch (ClassNotFoundException e) {
                e.printStackTrace();
            }

        }
    }


}
