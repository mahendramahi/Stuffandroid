package com.truworth.wellnesscorner.ui.mainapp.post;

import android.app.Activity;
import android.databinding.BindingAdapter;
import android.databinding.ObservableBoolean;
import android.databinding.ObservableField;
import android.graphics.Color;
import android.support.v4.content.ContextCompat;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.TextPaint;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.text.style.ForegroundColorSpan;
import android.text.style.StyleSpan;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import com.google.gson.Gson;
import com.truworth.wellnesscorner.R;
import com.truworth.wellnesscorner.TheWellnessCornerApp;
import com.truworth.wellnesscorner.customviews.CustomTextView;
import com.truworth.wellnesscorner.model.OnGoingChallengesBean;
import com.truworth.wellnesscorner.model.Post;
import com.truworth.wellnesscorner.model.PostMediaData;
import com.truworth.wellnesscorner.model.PostMediaList;
import com.truworth.wellnesscorner.model.PostTag;
import com.truworth.wellnesscorner.repo.DashboardRepository;
import com.truworth.wellnesscorner.repo.model.request.BaseRequest;
import com.truworth.wellnesscorner.repo.model.response.PostHiFiResponse;
import com.truworth.wellnesscorner.ui.mainapp.circledetail.challenges.ChallengeDetailActivity;
import com.truworth.wellnesscorner.ui.mainapp.post.postcomment.PostCommentActivity;
import com.truworth.wellnesscorner.utils.KeyBoardUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.inject.Inject;

import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;

public class PostViewModel {
    public ObservableField<String> imageUrlPost = new ObservableField<>();
    public List<PostMediaData> imageMediaData = new ArrayList<>();

    public List<PostMediaData> urlMediaData = new ArrayList<>();
    public List<PostMediaData> videoMediaData = new ArrayList<>();
    public List<PostMediaData> youtubeMediaData = new ArrayList<>();
    //set by palak
    public ObservableField<String> hiFiValue = new ObservableField<>();
    public ObservableField<String> commentValue = new ObservableField<>();
    public ObservableBoolean isHiFiVisible = new ObservableBoolean();
    public ObservableBoolean isCommentVisible = new ObservableBoolean();
    Post post;
    int position;
    @Inject
    DashboardRepository dashboardRepository;

    public PostViewModel(Post post, int position) {
        this.post = post;
        this.position = position;
        this.isHiFiVisible.set(true);
        this.isCommentVisible.set(true);
        //set by palak
        TheWellnessCornerApp.getApp().component().inject(this);
        if (post.getPostIsHasMedia()) {
            extractMediaData();
        }
    }

    @BindingAdapter({"postModel"})
    public static void nameWithSupportingText(TextView view, Post postModel) {
        Gson gson = new Gson();
        OnGoingChallengesBean challenge = gson.fromJson(gson.toJson(postModel.getContentData()), OnGoingChallengesBean.class);

        SpannableStringBuilder titleText = new SpannableStringBuilder("");
        ClickableSpan clickableSpanName = new ClickableSpan() {
            @Override
            public void onClick(View textView) {
                //todo open here member profile

            }

            @Override
            public void updateDrawState(TextPaint ds) {
                super.updateDrawState(ds);
                ds.setUnderlineText(false);
            }
        };
        ClickableSpan clickableSpanChallenge = new ClickableSpan() {
            @Override
            public void onClick(View textView) {
                //todo open here challenge detail
                if (challenge != null) {
                    if (!(view.getContext() instanceof ChallengeDetailActivity)) {
                        ChallengeDetailActivity.start(view.getContext(), challenge.getChallengeIdentity(), postModel.getPostMapIdentity(), challenge.getChallengeTypeId());
                    }
                }
            }

            @Override
            public void updateDrawState(TextPaint ds) {
                super.updateDrawState(ds);
                ds.setUnderlineText(false);
            }
        };
        final StyleSpan titleBold = new StyleSpan(android.graphics.Typeface.BOLD);
        titleText.append(postModel.getPostCreatedByName());
        titleText.setSpan(clickableSpanName, 0, titleText.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        titleText.setSpan(titleBold, 0, titleText.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        titleText.setSpan(new ForegroundColorSpan(Color.BLACK), 0, titleText.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

        if (postModel.getPostContentTypeId() == PostConstants.CONTENT_TYPE_EVENT) {
            titleText.append(" has created an event");
        } else if (postModel.getPostContentTypeId() == PostConstants.CONTENT_TYPE_CHALLENGE) {
            titleText.append(" has created a challenge");

        } else if (postModel.getPostContentTypeId() == PostConstants.CONTENT_TYPE_CHALLENGE_CHECK_IN) {
            titleText.append(" has checked in to");
            int indexStart = titleText.length();
            if (challenge != null) {
                titleText.append(" " + challenge.getChallengeName());
            }

            int indexEnd = titleText.length();
            titleText.append(" challenge");
            titleText.setSpan(clickableSpanChallenge, indexStart, indexEnd, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

            titleText.setSpan(new StyleSpan(android.graphics.Typeface.BOLD), indexStart, indexEnd, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            titleText.setSpan(new ForegroundColorSpan(Color.BLACK), indexStart, indexEnd, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        } else if (postModel.getPostContentTypeId() == PostConstants.CONTENT_TYPE_RESOURCE) {
            titleText.append(" has added a resource");
        }
        view.setText(titleText);
        view.setMovementMethod(LinkMovementMethod.getInstance());
        view.setHighlightColor(Color.TRANSPARENT);

    }

    @BindingAdapter({"addPostModel"})
    public static void postTextWithTag(TextView textView, Post addPostModel) {
        SpannableStringBuilder spannableStringBuilder;
        if (addPostModel.getPostText() != null) {
            spannableStringBuilder = makeSpannable(textView, addPostModel.getPostText(), addPostModel);
        } else {
            spannableStringBuilder = makeSpannable(textView, "", addPostModel);
        }

        if (spannableStringBuilder.toString().equalsIgnoreCase("")) {
            textView.setVisibility(View.GONE);
        } else {
            textView.setVisibility(View.VISIBLE);
            textView.setText(spannableStringBuilder);
        }
    }

    private static SpannableStringBuilder makeSpannable(View v, String text, Post post) {
        String regex = "\\{\\{.*?\\}\\}";
        StringBuffer sb = new StringBuffer();
        SpannableStringBuilder spannable = new SpannableStringBuilder();

        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(text);
        List<PostTag> postTagList = post.getPostTagList();
        while (matcher.find()) {
            sb.setLength(0); // clear
            String group = matcher.group();
            // caution, this code assumes your regex has single char delimiters
            String spanText = group.substring(2, group.length() - 2);
            if (!spanText.equalsIgnoreCase("") && postTagList.size() > Integer.parseInt(spanText)) {
                PostTag postTag = postTagList.get(Integer.parseInt(spanText));
                String tagText = postTag.getPostTagName();
                matcher.appendReplacement(sb, tagText);

                spannable.append(sb.toString());
                int start = spannable.length() - tagText.length();

                spannable.setSpan(new ForegroundColorSpan(ContextCompat.getColor(v.getContext(), R.color.text_green)),
                        start, spannable.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                spannable.setSpan(new ClickableSpan() {
                    @Override
                    public void onClick(View view) {
                        Log.d("postviewmodel", "onClick: " + postTag.getPostTagTypeId());
                        if (postTag.getPostTagTypeId() == PostConstants.POST_TAG_TYPE_CIRCLE) {
                            //todo open circle detail

                        } else if (postTag.getPostTagTypeId() == PostConstants.POST_TAG_TYPE_COACH) {
                            //todo open coach profile

                        } else if (postTag.getPostTagTypeId() == PostConstants.POST_TAG_TYPE_MEMBER) {
                            //todo open member profile

                        }
                    }

                    @Override
                    public void updateDrawState(TextPaint ds) {
                        ds.setUnderlineText(false);
                        // super.updateDrawState(ds);
                    }
                }, start, spannable.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            }
        }

        sb.setLength(0);
        matcher.appendTail(sb);
        spannable.append(sb.toString());

        if (post.getPostIsHasMedia()) {
            for (int i = 0; i < post.getPostMediaList().size(); i++) {
                if (post.getPostMediaList().get(i).getPostMediaType() == PostConstants.MEDIA_TYPE_URL) {
                    PostMediaData postData = post.getPostMediaList().get(i).getPostMediaData().get(0);
                    /*String url = postData.getUrl();
                    if (url!=null){
                        spannable.append(" -"); spannable.append(url);

                    int start = spannable.length() - url.length();
                    spannable.setSpan(new ForegroundColorSpan(ContextCompat.getColor(v.getContext(), R.color.text_green)), start, spannable.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                    spannable.setSpan(new ClickableSpan() {
                        @Override
                        public void onClick(View view) {
                            //todo open url
                            Log.d("postviewmodel", "onClick url: " + url);


                        }

                        @Override
                        public void updateDrawState(TextPaint ds) {
                            ds.setUnderlineText(false);
                            // super.updateDrawState(ds);
                        }
                    }, start, spannable.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);


                }*/
                }
            }
        }


        return spannable;
    }

    @BindingAdapter({"isSelected"})
    public static void setSelected(View view, boolean isSelected) {
        view.setSelected(isSelected);
    }

    public void setImageUrlPost(String url) {
        this.imageUrlPost.set(url);
    }

    private void extractMediaData() {

        for (int i = 0; i < post.getPostMediaList().size(); i++) {
            PostMediaList mediaList = post.getPostMediaList().get(i);
            if (mediaList.getPostMediaType() == PostConstants.MEDIA_TYPE_IMAGE) {
                imageMediaData.add(mediaList.getPostMediaData().get(0));
            } else if (mediaList.getPostMediaType() == PostConstants.MEDIA_TYPE_URL) {
                urlMediaData.add(mediaList.getPostMediaData().get(0));
            } else if (mediaList.getPostMediaType() == PostConstants.MEDIA_TYPE_VIDEO) {
                videoMediaData.add(mediaList.getPostMediaData().get(0));
            }
        }
    }

    public Post getPost() {
        return post;
    }

    public void setPost(Post post) {
        this.post = post;
    }

    public String getDate() {
        //DateUtils dateUtils = DateUtils.getInstance();
        // String toDate = DateUtils.getInstance().formatDate(discussionDate, "yyyy-MM-dd'T'HH:mm:ss", "dd-MM-yyyy");
        return post.getPostCreatedOn();//dateUtils.getFormattedDate(DateUtils.getDate(post.getPostCreatedOn(), DateUtils.SERVER_DATE).getTime());

    }

    // work with palak
    public void onClickHiFive(View view) {
        CustomTextView tv = ((CustomTextView) view);
        hiFiApiCall(post.getPostIdentity(), tv);
    }

    public void hiFiApiCall(String postIdentity, CustomTextView tv) {

        BaseRequest postHiFiRequest = new BaseRequest();
        postHiFiRequest.setId(postIdentity);
        dashboardRepository.getPostHiFi(postHiFiRequest).subscribe(new Observer<PostHiFiResponse>() {
            @Override
            public void onSubscribe(Disposable d) {

            }

            @Override
            public void onNext(PostHiFiResponse postHiFiResponse) {
                if (!postHiFiResponse.getHasError()) {
                    if (postHiFiResponse.getData().isHiFive()) {
                        //  post.setPostTotalHiFives(post.getPostTotalHiFives()+1);
                        post.setPostMemberIsHi5(true);
                        tv.setSelected(true);
                        tv.setFontBold();
                    } else {
                        post.setPostMemberIsHi5(false);
                        tv.setSelected(false);
                        //  post.setPostTotalHiFives(post.getPostTotalHiFives()-1);
                        tv.setFontMedium();
                    }
                    if (postHiFiResponse.getData().getTotalLike() > 1) {
                        isHiFiVisible.set(true);
                        hiFiValue.set(String.valueOf((postHiFiResponse.getData().getTotalLike())) + " High-Fives");
                    } else if (postHiFiResponse.getData().getTotalLike() == 1) {
                        isHiFiVisible.set(true);
                        hiFiValue.set(String.valueOf((postHiFiResponse.getData().getTotalLike())) + " High-Five");
                    } else {
                        isHiFiVisible.set(false);
                    }

                    post.setPostTotalHiFives(postHiFiResponse.getData().getTotalLike());
                }
            }

            @Override
            public void onError(Throwable e) {

            }

            @Override
            public void onComplete() {

            }
        });
    }

    public void getHifiValue() {
        hiFiValue.set(String.valueOf(post.getPostTotalHiFives()));
        if (post.getPostTotalHiFives() > 1) {
            isHiFiVisible.set(true);
            hiFiValue.set(String.valueOf(post.getPostTotalHiFives()) + " High-Fives");
        } else if (post.getPostTotalHiFives() == 1) {
            isHiFiVisible.set(true);
            hiFiValue.set(String.valueOf(post.getPostTotalHiFives()) + " High-Five");
        } else {
            isHiFiVisible.set(false);
        }
    }

    public void getCommentValue() {
        commentValue.set(String.valueOf(post.getPostTotalComments()));
        if (post.getPostTotalComments() > 1) {
            isCommentVisible.set(true);
            commentValue.set(String.valueOf(post.getPostTotalComments()) + " comments");
        } else if (post.getPostTotalComments() == 1) {
            isCommentVisible.set(true);
            commentValue.set(String.valueOf(post.getPostTotalComments()) + " comment");
        } else {
            isCommentVisible.set(false);
        }
    }

    public void clickOnComment(View view, String value) {
        if (view.getContext() instanceof PostCommentActivity) {
            if (value.equalsIgnoreCase("commentView"))
                PostCommentActivity.setComment(PostCommentActivity.OPEN_FOR_COMMENT_VIEW);
            else {
                PostCommentActivity.setComment(PostCommentActivity.OPEN_FOR_COMMENT_WRITE);
                KeyBoardUtils.openKeyboard(view.getContext(), view);
            }
        } else {
            if (value.equalsIgnoreCase("commentView"))
                PostCommentActivity.start(((Activity) view.getContext()), post, position, PostCommentActivity.OPEN_FOR_COMMENT_VIEW);
            else
                PostCommentActivity.start(((Activity) view.getContext()), post, position, PostCommentActivity.OPEN_FOR_COMMENT_WRITE);
        }
    }
}