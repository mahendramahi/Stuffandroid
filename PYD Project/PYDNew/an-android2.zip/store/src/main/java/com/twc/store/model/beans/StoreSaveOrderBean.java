package com.twc.store.model.beans;

/**
 * Created by richas on 9/18/2017.
 */

public class StoreSaveOrderBean {

    private int OrderId;
    private double TotalAmount;
    private double WellCashDiscount;
    private int orderStatus;



    private String SaltKey;

    public int getOrderId() {
        return OrderId;
    }

    public void setOrderId(int orderId) {
        OrderId = orderId;
    }

    public double getTotalAmount() {
        return TotalAmount;
    }

    public void setTotalAmount(double TotalAmount) {
        this.TotalAmount = TotalAmount;
    }

    public double getWellCashDiscount() {
        return WellCashDiscount;
    }

    public void setWellCashDiscount(double WellCashDiscount) {
        this.WellCashDiscount = WellCashDiscount;
    }

    public int getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(int orderStatus) {
        this.orderStatus = orderStatus;
    }

    public String getSaltKey() {
        return SaltKey;
    }

    public void setSaltKey(String saltKey) {
        SaltKey = saltKey;
    }
}
