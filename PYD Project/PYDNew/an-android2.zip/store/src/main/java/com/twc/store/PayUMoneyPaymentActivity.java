package com.twc.store;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;

import com.payumoney.core.PayUmoneyConfig;
import com.payumoney.core.PayUmoneyConstants;
import com.payumoney.core.PayUmoneySdkInitializer;
import com.payumoney.core.entity.TransactionResponse;
import com.payumoney.sdkui.ui.utils.PayUmoneyFlowManager;
import com.payumoney.sdkui.ui.utils.ResultModel;
import com.twc.store.model.beans.CartOrderDetailObject;
import com.twc.store.model.requestbody.StoreUpdateOrderBody;
import com.twc.store.model.response.StoreUpdateOrderResponse;
import com.twc.store.rest.RestClient;
import com.twc.store.utils.Constant;
import com.twc.store.utils.DialogFactory;
import com.twc.store.utils.StoreConfig;
import com.twc.store.utils.Utils;
import com.twc.store.views.CustomProgressDialog;

import org.json.JSONException;
import org.json.JSONObject;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.DateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Random;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class PayUMoneyPaymentActivity extends AppCompatActivity {

    private static final String TRANSACTION_ID_KEY = "TRANSACTION_ID";
    private static final String TRANSACTION_RESULT_KEY = "TRANSACTION_RESULT";
    private CustomProgressDialog customProgressDialog;
    private int orderId;
    private CartOrderDetailObject cartOrderDetailObject;
    private PayUmoneySdkInitializer.PaymentParam mPaymentParams;

    public static final String TAG = "PayUPaymentActivity : ";
    private Toolbar toolbar;
    private String SaltKey;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);

        Bundle bundle = getIntent().getExtras();
        if (bundle != null) {
            cartOrderDetailObject = bundle.getParcelable("cartOrderDetailObject");
            orderId = bundle.getInt("OrderID", 0);
            SaltKey = bundle.getString("SaltKey");

            startPayment();
        }

    }


    private void startPayment() {

        PayUmoneyConfig payUmoneyConfig = PayUmoneyConfig.getInstance();
        payUmoneyConfig.setDoneButtonText("Done");
        payUmoneyConfig.setPayUmoneyActivityTitle("PayUmoney");

        PayUmoneySdkInitializer.PaymentParam.Builder builder = new PayUmoneySdkInitializer.PaymentParam.Builder();
        double amount = 0;
        try {
            amount = cartOrderDetailObject.getGrandTotalAmount();

        } catch (Exception e) {
            e.printStackTrace();
        }
       // String txnId = orderId + "";
        String phone = "";
        if (StoreConfig.storeUser.getPhone()!=null) {
            phone = StoreConfig.storeUser.getPhone();
        }
        String productName = "Truworth Health products.";
        String firstName = StoreConfig.storeUser.getName();
        String email = "";
        if (StoreConfig.storeUser.getEmail()!=null) {
            email = StoreConfig.storeUser.getEmail();
        }
        builder.setAmount(amount)
                .setTxnId(generateTxnid())
                .setPhone(phone)
                .setProductName(productName)
                .setFirstName(firstName)
                .setEmail(email)
                .setsUrl("https://www.payumoney.com/mobileapp/payumoney/success.php")
                .setfUrl("https://www.payumoney.com/mobileapp/payumoney/failure.php")
                .setUdf1("")
                .setUdf2("")
                .setUdf3("")
                .setUdf4("")
                .setUdf5("")
                .setIsDebug(Constant.IS_PAYUMONEY_DEBUG)
                .setKey(Constant.Merchant_KEY)
                .setMerchantId(Constant.Merchant_ID);

        try {
            mPaymentParams = builder.build();
            calculateHashAndInitiatePayment(mPaymentParams);
            PayUmoneyFlowManager.startPayUMoneyFlow(mPaymentParams, PayUMoneyPaymentActivity.this, R.style.MyPayUTheme, true);

        } catch (Exception e) {
            Utils.showToast(this, e.getMessage());

        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PayUmoneyFlowManager.REQUEST_CODE_PAYMENT && resultCode == RESULT_OK && data !=
                null) {
            TransactionResponse transactionResponse = data.getParcelableExtra(PayUmoneyFlowManager
                    .INTENT_EXTRA_TRANSACTION_RESPONSE);

            ResultModel resultModel = data.getParcelableExtra(PayUmoneyFlowManager.ARG_RESULT);


            if (transactionResponse != null && transactionResponse.getPayuResponse() != null) {
                if (transactionResponse.getTransactionStatus().equals(TransactionResponse.TransactionStatus.SUCCESSFUL)) {

                    String payuResponse = transactionResponse.getPayuResponse();
                    try {
                        JSONObject jsonObject = new JSONObject(payuResponse);

                        JSONObject jobjResult = jsonObject.getJSONObject("result");
                        String paymentTransactionId = jobjResult.getInt("paymentId") + "";

                        String txnid = jobjResult.getString("txnid");
                        String pg_TYPE = jobjResult.getString("pg_TYPE");
                        String payuMoneyId = jobjResult.getString("payuMoneyId");
                        String bank_ref_num = jobjResult.getString("bank_ref_num");
                        String bankcode = jobjResult.getString("bankcode");
                        String error = jobjResult.getString("error");
                        String error_Message = jobjResult.getString("error_Message");

                        String transactionDetails = "pg_TYPE:" + pg_TYPE + "|" + "bank_ref_num:" + bank_ref_num + "|" + "bankcode:" + bankcode + "|" + "error:" + error + "|" + "error_Message:" + error_Message + "|" + "payuMoneyId:" + payuMoneyId + "|" + "paymentTransactionId:" + txnid;

                        updateOrderApiCall(paymentStatusType.SUCCESS, paymentTransactionId, transactionDetails);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                } else if (transactionResponse.getTransactionStatus().equals(TransactionResponse.TransactionStatus.FAILED)) {
                    String payuResponse = transactionResponse.getPayuResponse();
                    updateOrderApiCall(paymentStatusType.FAILURE, "Payment Failed", payuResponse);
                } else if (transactionResponse.getTransactionStatus().equals(TransactionResponse.TransactionStatus.CANCELLED)) {
                    updateOrderApiCall(paymentStatusType.CANCEL, "Payment Cancelled", "Payment Cancelled");
                }

            } else if (resultModel != null && resultModel.getError() != null) {
                Log.d(TAG, "Error response : " + resultModel.getError().getTransactionResponse());
            } else {
                // faliure here also
                updateOrderApiCall(paymentStatusType.FAILURE, "Payment Failed", "Payment Failed");
            }
        } else {

            // handle back
            DialogFactory.getInstance().showAlertDialog(PayUMoneyPaymentActivity.this, getString(R.string.app_name), 0, "Are you sure you want to cancel the transaction?", "Yes", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {

                    dialogInterface.dismiss();
                    // updateOrderTransactionAPI(paymentStatusType.CANCEL, "Payment Cancelled");
                    updateOrderApiCall(PayUMoneyPaymentActivity.paymentStatusType.CANCEL, "Payment Cancelled", "Payment Cancelled");

                }
            }, "No", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    dialogInterface.dismiss();
                    startPayment();
                }
            }, false);
        }

    }

    private PayUmoneySdkInitializer.PaymentParam calculateHashAndInitiatePayment(final PayUmoneySdkInitializer.PaymentParam paymentParam) {

        StringBuilder stringBuilder = new StringBuilder();
        HashMap<String, String> params = paymentParam.getParams();
        stringBuilder.append(params.get(PayUmoneyConstants.KEY) + "|");
        stringBuilder.append(params.get(PayUmoneyConstants.TXNID) + "|");
        stringBuilder.append(params.get(PayUmoneyConstants.AMOUNT) + "|");
        stringBuilder.append(params.get(PayUmoneyConstants.PRODUCT_INFO) + "|");
        stringBuilder.append(params.get(PayUmoneyConstants.FIRSTNAME) + "|");
        stringBuilder.append(params.get(PayUmoneyConstants.EMAIL) + "|");
        stringBuilder.append(params.get(PayUmoneyConstants.UDF1) + "|");
        stringBuilder.append(params.get(PayUmoneyConstants.UDF2) + "|");
        stringBuilder.append(params.get(PayUmoneyConstants.UDF3) + "|");
        stringBuilder.append(params.get(PayUmoneyConstants.UDF4) + "|");
        stringBuilder.append(params.get(PayUmoneyConstants.UDF5) + "||||||");


        stringBuilder.append(Constant.Merchant_SALT);

        String hash = hashCal(stringBuilder.toString());
        paymentParam.setMerchantHash(hash);

        return paymentParam;
    }

    public static String hashCal(String str) {
        byte[] hashseq = str.getBytes();
        StringBuilder hexString = new StringBuilder();
        try {
            MessageDigest algorithm = MessageDigest.getInstance("SHA-512");
            algorithm.reset();
            algorithm.update(hashseq);
            byte messageDigest[] = algorithm.digest();
            for (byte aMessageDigest : messageDigest) {
                String hex = Integer.toHexString(0xFF & aMessageDigest);
                if (hex.length() == 1) {
                    hexString.append("0");
                }
                hexString.append(hex);
            }
        } catch (NoSuchAlgorithmException ignored) {
        }
        return hexString.toString();
    }

    private enum paymentStatusType {
        SUCCESS {
            @Override
            public String toString() {
                return "SUCCESS";
            }
        }, FAILURE {
            @Override
            public String toString() {
                return "FAILURE";
            }
        },
        CANCEL {
            @Override
            public String toString() {
                return "CANCEL";
            }
        }

    }

    private void updateOrderApiCall(final paymentStatusType status, final String paymentTransactionId, String transactionDetails) {
        final CustomProgressDialog pb;
        pb = new CustomProgressDialog(PayUMoneyPaymentActivity.this, R.style.custom_progress_style, false);
        pb.show();

        StoreUpdateOrderBody storeUpdateOrderBody = new StoreUpdateOrderBody();
        storeUpdateOrderBody.setCartIds(cartOrderDetailObject.getCartIds());
        storeUpdateOrderBody.setOrderID(orderId);
        storeUpdateOrderBody.setStatus(String.valueOf(status));
        storeUpdateOrderBody.setTransactionId(paymentTransactionId);
        storeUpdateOrderBody.setTransactionDetail(transactionDetails);
        storeUpdateOrderBody.setMemberId(StoreConfig.storeUser.getMemberId());
        RestClient restClient = new RestClient(this, StoreConfig.BASE_URL, StoreConfig.mdebug);

        restClient.getStoreService().updateOrder(storeUpdateOrderBody).enqueue(new Callback<StoreUpdateOrderResponse>() {
            @Override
            public void onResponse(Call<StoreUpdateOrderResponse> call, Response<StoreUpdateOrderResponse> response) {

                if (!isDestroyed()) {
                    if (pb.isShowing()) {
                        pb.dismiss();
                    }

                    if (response != null && response.body() != null && response.body().getStatus() == 0) {
                        if (status.equals(paymentStatusType.SUCCESS)) {
                            finish();
                            start(orderId + "", PaymentConfirmationActivity.TransactionResult.SUCCESS);
                        } else if (status.equals(paymentStatusType.FAILURE)) {
                            finish();
                            start(orderId + "", PaymentConfirmationActivity.TransactionResult.FAILURE);
                        } else {
                            callForFinish(Activity.RESULT_CANCELED);
                        }

                    } else {
                        if (status.equals(paymentStatusType.SUCCESS)) {
                            finish();
                            start(orderId + "", PaymentConfirmationActivity.TransactionResult.SUCCESS);
                        } else if (status.equals(paymentStatusType.FAILURE)) {
                            finish();
                            start(orderId + "", PaymentConfirmationActivity.TransactionResult.FAILURE);
                        } else {
                            callForFinish(Activity.RESULT_CANCELED);
                        }
                    }
                }
            }

            @Override
            public void onFailure(Call<StoreUpdateOrderResponse> call, Throwable t) {
                if (!isDestroyed()) {
                    if (pb.isShowing()) {
                        pb.dismiss();
                    }
                    if (status.equals(paymentStatusType.SUCCESS)) {
                        start(orderId + "", PaymentConfirmationActivity.TransactionResult.SUCCESS);
                    } else if (status.equals(paymentStatusType.FAILURE) || status.equals(paymentStatusType.CANCEL)) {
                        start(orderId + "", PaymentConfirmationActivity.TransactionResult.FAILURE);
                    }
                }
            }
        });
    }

    private void start(String transactionId, PaymentConfirmationActivity.TransactionResult transactionResult) {
        Intent starter = new Intent(this, PaymentConfirmationActivity.class);
        starter.putExtra(TRANSACTION_ID_KEY, transactionId);
        starter.putExtra(TRANSACTION_RESULT_KEY, transactionResult);
        startActivityForResult(starter, Constant.PAYMENT_CONFIRMATION_REQUEST_CODE);
    }

    private void callForFinish(int resultStatus) {
        Intent intent = new Intent();
        setResult(resultStatus, intent);
        finish();
    }

    public String generateTxnid()
    {
        Random rnd = new Random();
        String strHash = hashCal(rnd.toString() + DateFormat.getDateTimeInstance().format(new Date()));
        String txnid1 = strHash.toString().substring(0, 20);

        return txnid1;
    }


}
