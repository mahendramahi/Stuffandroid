package com.truworth.wellnesscorner.ui.mainapp.createpost.shareweight;

import android.app.Activity;
import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.View;

import com.truworth.wellnesscorner.BR;
import com.truworth.wellnesscorner.R;
import com.truworth.wellnesscorner.base.BaseFragment;
import com.truworth.wellnesscorner.databinding.FragmentShareWeightBinding;
import com.truworth.wellnesscorner.ui.mainapp.createpost.ShareActivity;
import com.truworth.wellnesscorner.utils.Utils;

import java.io.ByteArrayOutputStream;

public class ShareWeightFragment extends BaseFragment<FragmentShareWeightBinding, ShareWeightViewModel> {
    ShareWeightViewModel viewModel;
    FragmentShareWeightBinding binding;
    public static final String TAG = "ShareWeightFragment";
    private Bitmap finalBitmap;

    @Override
    public int getBindingVariable() {
        return BR.viewModel;
    }

    @Override
    public int getLayoutId() {
        return R.layout.fragment_share_weight;
    }

    @Override
    public ShareWeightViewModel getViewModel() {
        viewModel = ViewModelProviders.of(this).get(ShareWeightViewModel.class);
        return viewModel;
    }

    @Override
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        binding = getViewDataBinding();
        viewModel.loadSharepostWeight();
        setClickObserver();
        setDefault();
    }
    private void setClickObserver() {


        viewModel.getShareBtnClick().observe(this, new Observer<Void>() {
            @Override
            public void onChanged(@Nullable Void avoid) {
                if (finalBitmap != null) {
                    String path = Utils.getImageUri(getContext(), finalBitmap);

                    Intent returnIntent = new Intent();
                    returnIntent.putExtra("result", path);
                    getActivity().setResult(Activity.RESULT_OK, returnIntent);
                    getActivity().finish();

                }
            }
        });


    }

    public void setDefault() {

        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {

                Bitmap bm = Utils.layoutToImage(binding.llMain);
                ByteArrayOutputStream bytes = new ByteArrayOutputStream();
                bm.compress(Bitmap.CompressFormat.JPEG, 100, bytes);
                finalBitmap = bm;
            }
        }, 500);

    }
    @Override
    public void onDestroy() {
        super.onDestroy();
        if(finalBitmap!=null){
            finalBitmap.recycle();
            finalBitmap=null;
        }


    }
}
