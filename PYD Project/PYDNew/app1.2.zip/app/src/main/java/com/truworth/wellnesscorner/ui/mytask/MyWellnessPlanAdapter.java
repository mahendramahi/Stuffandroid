package com.truworth.wellnesscorner.ui.mytask;

import android.app.Activity;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import com.truworth.wellnesscorner.R;
import com.truworth.wellnesscorner.customviews.CustomTextView;
import com.truworth.wellnesscorner.model.MemberProgramTaskDetailItem;
import com.truworth.wellnesscorner.utils.DateUtils;

import java.util.List;
import java.util.Locale;

import at.blogc.android.views.ExpandableTextView;

/**
 * Created by richas on 2/19/2018.
 */

public class MyWellnessPlanAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private Activity context;
    private List<MemberProgramTaskDetailItem> myPlanList;
    private String lableValue, activeByUserValue, dateValue, planDaysValue, dietTypeValue;
    private double targetCaloriesValue;

    public MyWellnessPlanAdapter(Activity context, List<MemberProgramTaskDetailItem> myPlanList) {
        this.context = context;
        this.myPlanList = myPlanList;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.row_task_card_layout, parent, false);

        return new ItemViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        ItemViewHolder itemViewHolder = (ItemViewHolder) holder;
        MemberProgramTaskDetailItem planItem = myPlanList.get(position);

        itemViewHolder.tvCalories.setVisibility(View.VISIBLE);
        itemViewHolder.tvVeg.setVisibility(View.VISIBLE);
        itemViewHolder.tvTaskPeps.setVisibility(View.GONE);
        itemViewHolder.tvTaskDays.setVisibility(View.GONE);

        if (myPlanList.get(position).getOtherInfo() != null && myPlanList.get(position).getOtherInfo().size() > 0) {
            MemberProgramTaskDetailItem.OtherInfoItem otherInfoItem;
            for (int i = 0; i < myPlanList.get(position).getOtherInfo().size(); i++) {
                otherInfoItem = myPlanList.get(position).getOtherInfo().get(i);
                if (otherInfoItem.getKey().equalsIgnoreCase("Label"))
                    lableValue = otherInfoItem.getValue();
                else if (otherInfoItem.getKey().equalsIgnoreCase("ActiveByUser"))
                    activeByUserValue = otherInfoItem.getValue();
                else if (otherInfoItem.getKey().equalsIgnoreCase("Date"))
                    dateValue = otherInfoItem.getValue();
                else if (otherInfoItem.getKey().equalsIgnoreCase("TARGET CALORIES")) {
                    String[] splitCalories = otherInfoItem.getValue().split("\\s+");
                    targetCaloriesValue = Double.parseDouble(splitCalories[0]);
                }
                else if (otherInfoItem.getKey().equalsIgnoreCase("PLAN DAYS"))
                    planDaysValue = otherInfoItem.getValue();
                else if (otherInfoItem.getKey().equalsIgnoreCase("DIET TYPE"))
                    dietTypeValue = otherInfoItem.getValue();
            }
        }

        // set data
        itemViewHolder.tvTaskName.setText(planItem.getItemName());
        itemViewHolder.tvTaskDescription.setText(planItem.getItemDesc());
        itemViewHolder.tvCalories.setText(String.format(Locale.getDefault(),"%d Calories", Math.round(targetCaloriesValue)));
        itemViewHolder.tvVeg.setText(dietTypeValue);

        itemViewHolder.tvTaskType.setText(planItem.getItemType());
        if (planItem.getProgramName().equalsIgnoreCase("Diet Plan")) {
            itemViewHolder.viewTaskColor.setBackgroundColor(ContextCompat.getColor(context, R.color.color_FF9AAD));
            itemViewHolder.tvCalories.setVisibility(View.VISIBLE);
            itemViewHolder.tvVeg.setVisibility(View.VISIBLE);
        } else if (planItem.getProgramName().equalsIgnoreCase("Exercise Plan")) {
            itemViewHolder.viewTaskColor.setBackgroundColor(ContextCompat.getColor(context, R.color.color_95acff));
            itemViewHolder.tvCalories.setVisibility(View.GONE);
            itemViewHolder.tvVeg.setVisibility(View.GONE);
        } else {
            itemViewHolder.viewTaskColor.setBackgroundColor(ContextCompat.getColor(context, R.color.color_A0A3B8));
            itemViewHolder.tvCalories.setVisibility(View.GONE);
            itemViewHolder.tvVeg.setVisibility(View.GONE);
        }

        if (planItem.getItemType().equalsIgnoreCase("WORKOUT_PLAN_ID")) {
            itemViewHolder.swipeLayout.setLockDrag(true);
        }
    }

    @Override
    public int getItemCount() {
        return (null != myPlanList ? myPlanList.size() : 0);
    }

    public class ItemViewHolder extends RecyclerView.ViewHolder {

        SwipeRevealLayout swipeLayout;
        CustomTextView tvTaskName;
        ExpandableTextView tvTaskDescription;
        CustomTextView tvTaskPeps;
        CustomTextView tvTaskDays;
        CustomTextView tvCalories;
        CustomTextView tvVeg;
        CustomTextView tvTaskType;
        CustomTextView tvIdidIt;
        CustomTextView tvDismiss;
        View viewTaskColor;
        RelativeLayout rlCardBottom;
        LinearLayout llTaskButtons;
        CardView cardTask;
        FrameLayout frameLayout;



        public ItemViewHolder(View itemView) {
            super(itemView);
            swipeLayout = itemView.findViewById(R.id.swipeLayout);
            frameLayout = itemView.findViewById(R.id.frameLayout);
            tvTaskName = itemView.findViewById(R.id.tvTaskName);
            tvTaskDescription = itemView.findViewById(R.id.tvTaskDescription);
            tvTaskPeps = itemView.findViewById(R.id.tvTaskPeps);
            tvTaskDays = itemView.findViewById(R.id.tvTaskDays);
            tvCalories = itemView.findViewById(R.id.tvCalories);
            tvVeg = itemView.findViewById(R.id.tvVeg);
            tvTaskType = itemView.findViewById(R.id.tvTaskType);
            tvIdidIt = itemView.findViewById(R.id.tvIdidIt);
            tvDismiss = itemView.findViewById(R.id.tvDismiss);
            viewTaskColor = itemView.findViewById(R.id.viewTaskColor);
            rlCardBottom = itemView.findViewById(R.id.rlCardBottom);
            llTaskButtons = itemView.findViewById(R.id.llTaskButtons);
            cardTask = itemView.findViewById(R.id.cardTask);
            frameLayout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Bundle bundle = new Bundle();
                    if (myPlanList.get(getAdapterPosition()).getItemType().equalsIgnoreCase("PLANS")) {
                        if (myPlanList.get(getAdapterPosition()).getProgramName().equalsIgnoreCase("Diet Plan")) {
                            Bundle bundleDietPlan = new Bundle();
                            bundleDietPlan.putString("dietPlanId", myPlanList.get(getAdapterPosition()).getID() + "");
                            bundleDietPlan.putString("dietPlanName", myPlanList.get(getAdapterPosition()).getItemName());
                            String formattedDate = DateUtils.getInstance().formatDate("MM/dd/yyyy", "MMM dd, yyyy", dateValue);
                            bundleDietPlan.putString("dietPlanDate", formattedDate);
                            bundleDietPlan.putString("dietPlanCalories", targetCaloriesValue+"");
                            bundleDietPlan.putString("dietPlanDays", planDaysValue);
                            bundleDietPlan.putInt("activeByUser", Integer.parseInt(activeByUserValue));

                          //  Utils.replaceFragment(context.getFragmentManager(), DietPlanWeeklyMenuFragment.newInstance(bundleDietPlan), DietPlanWeeklyMenuFragment.class.getSimpleName(), true, R.id.fragmentContainer);
                        } else if (myPlanList.get(getAdapterPosition()).getProgramName().equalsIgnoreCase("Exercise Plan")) {
                            int workoutPlanId = myPlanList.get(getAdapterPosition()).getID();
                            bundle.putInt("WORKOUT_PLAN_ID", workoutPlanId);
                         //   Utils.replaceFragment(context.getFragmentManager(), TodayWorkoutFragment.newInstance(bundle), TodayWorkoutFragment.class.getSimpleName(), true, R.id.fragmentContainer);
                        }
                    }
                }
            });
        }

    }


}

