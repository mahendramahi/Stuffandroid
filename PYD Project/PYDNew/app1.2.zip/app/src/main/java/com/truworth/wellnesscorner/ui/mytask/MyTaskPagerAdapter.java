package com.truworth.wellnesscorner.ui.mytask;



import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.support.v7.widget.CardView;
import android.view.ViewGroup;

import com.truworth.wellnesscorner.model.DataMemberProgramItem;

import java.util.ArrayList;
import java.util.List;

public class MyTaskPagerAdapter extends FragmentStatePagerAdapter implements CardAdapter {

    private List<MyTasksFragment> fragments;
    private float baseElevation;
    private FragmentManager fm;

    public MyTaskPagerAdapter(FragmentManager fm, float baseElevation, List<DataMemberProgramItem> item) {
        super(fm);
        this.fm = fm;
        fragments = new ArrayList<>();
        this.baseElevation = baseElevation;

        for (int i = 0; i < item.size(); i++) {
            addCardFragment(MyTasksFragment.getInstance(item.get(i)));
        }
    }

    @Override
    public float getBaseElevation() {

        return baseElevation;
    }

    @Override
    public CardView getCardViewAt(int position) {

        return fragments.get(position).getCardView();
    }

    @Override
    public int getCount() {

        return fragments.size();
    }

    @Override
    public android.support.v4.app.Fragment getItem(int position) {
        return fragments.get(position);
    }

    @Override
    public Object instantiateItem(ViewGroup container, int position) {
        Object fragment = super.instantiateItem(container, position);
        fragments.set(position, (MyTasksFragment) fragment);
        return fragment;
    }

    public void addCardFragment(MyTasksFragment fragment) {
        fragments.add(fragment);
    }

    @Override
    public float getPageWidth(final int position) {
        if(position>0) {
            return 0.95f;
        }
        else{
            return 1;
        }
    }

    public void removeItem(int pos) {


        if (pos <= getCount()) {
            if (fragments != null && fragments.size() > 0) {
                fragments.remove(pos);
            }
        }
        notifyDataSetChanged();
    }

    @Override
    public int getItemPosition (Object object)
    {
        return POSITION_NONE;
    }

}
