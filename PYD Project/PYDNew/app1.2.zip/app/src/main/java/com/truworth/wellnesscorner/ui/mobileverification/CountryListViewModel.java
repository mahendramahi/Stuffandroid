package com.truworth.wellnesscorner.ui.mobileverification;

import android.text.Editable;
import android.text.TextWatcher;

import com.truworth.wellnesscorner.TheWellnessCornerApp;
import com.truworth.wellnesscorner.base.BaseViewModel;
import com.truworth.wellnesscorner.model.CountryData;
import com.truworth.wellnesscorner.repo.LoginRepository;
import com.truworth.wellnesscorner.repo.model.response.CountryResponse;
import com.truworth.wellnesscorner.utils.SingleLiveEvent;

import java.util.ArrayList;

import javax.inject.Inject;

import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;

public class CountryListViewModel extends BaseViewModel {
    @Inject
    LoginRepository repository;
    public ArrayList<CountryData> countryData=new ArrayList<>();
    SingleLiveEvent<Void> countryList = new SingleLiveEvent<>();
    SingleLiveEvent<CharSequence> countryFilterList = new SingleLiveEvent<CharSequence>();

    public CountryListViewModel() {
        TheWellnessCornerApp.getApp().component().inject(this);
    }

    public SingleLiveEvent<Void> getCountryList() {
        return countryList;
    }

    public ArrayList<CountryData> getCountryData() {
        return countryData;
    }

    public SingleLiveEvent<CharSequence> getCountryFilterList() {
        return countryFilterList;
    }

    public void loadCountryCode() {
        setIsLoading(true);
        repository.getCountryList().subscribe(new Observer<CountryResponse>() {

            @Override
            public void onSubscribe(Disposable d) {

            }

            @Override
            public void onNext(CountryResponse countryResponse) {
                countryData.clear();
                countryData.addAll(countryResponse.getData());
                countryList.call();
            }
            @Override
            public void onError(Throwable e) {

            }

            @Override
            public void onComplete() {
                setIsLoading(false);
            }
        });

    }

    public TextWatcher searchWatcher() {
        return new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                countryFilterList.setValue(charSequence);
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        };
    }

}
