package com.truworth.discoverlib.adapter;

import android.app.Activity;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.truworth.discoverlib.R;
import com.truworth.discoverlib.fragment.SlideshowFragment;
import com.truworth.discoverlib.model.SlideshowResponse.DataBean.RelatedSlideBean;
import com.truworth.discoverlib.utils.Constant;
import com.truworth.discoverlib.utils.Utils;

import java.util.ArrayList;

/**
 * If this code works it was written by Somesh Kumar on 11 August, 2016. If not, I don't know who wrote it.
 */
public class RelatedSlideshowAdapter extends RecyclerView.Adapter<RelatedSlideshowAdapter.ViewHolder> {
    private ArrayList<RelatedSlideBean> mRelatedSlideList;
    private Activity mContext;

    public RelatedSlideshowAdapter(Activity context, ArrayList<RelatedSlideBean> relatedSlideList) {
        this.mRelatedSlideList = relatedSlideList;
        mContext = context;
    }


    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_discover_list_small, parent, false);
        return new ViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        holder.tvDiscoverTitle.setText(mRelatedSlideList.get(position).getSlideName());
        Glide.with(mContext).load(mRelatedSlideList.get(position).getSlideImage()).into(holder.ivDiscoverImage);
    }

    @Override
    public int getItemCount() {
        /*Returning 3 because at present only three related slideshow need to show to user*/
        return (mRelatedSlideList != null) ? ((mRelatedSlideList.size() >= 3) ? 3 : mRelatedSlideList.size()) : 0;
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        TextView tvDiscoverTitle;
        ImageView ivDiscoverImage;

        public ViewHolder(View itemView) {
            super(itemView);
            tvDiscoverTitle = itemView.findViewById(R.id.tvDiscoverTitle);
            ivDiscoverImage = itemView.findViewById(R.id.ivDiscoverImage);
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            Bundle bundle = new Bundle();
            bundle.putInt(Constant.BUNDLE_KEY_SLIDESHOW_ID, mRelatedSlideList.get(getLayoutPosition()).getSlideID());
            bundle.putString(Constant.BUNDLE_KEY_SLIDESHOW_URL, mRelatedSlideList.get(getLayoutPosition()).getURL());
            Utils.replaceFragment(mContext.getFragmentManager(), SlideshowFragment.newInstance(bundle), SlideshowFragment.class.getSimpleName(), true, R.id.container);
        }
    }
}
