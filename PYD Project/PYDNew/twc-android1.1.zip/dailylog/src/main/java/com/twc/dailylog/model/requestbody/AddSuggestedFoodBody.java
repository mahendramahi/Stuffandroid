package com.twc.dailylog.model.requestbody;


public class AddSuggestedFoodBody {
    private int MemberID;
    private String SuggestedDietFood_Name;
    private String SuggestedDietFood_Description;

    public int getMemberID() {
        return MemberID;
    }

    public void setMemberID(int MemberID) {
        this.MemberID = MemberID;
    }

    public String getSuggestedDietFood_Name() {
        return SuggestedDietFood_Name;
    }

    public void setSuggestedDietFood_Name(String suggestedDietFood_Name) {
        SuggestedDietFood_Name = suggestedDietFood_Name;
    }

    public String getSuggestedDietFood_Description() {
        return SuggestedDietFood_Description;
    }

    public void setSuggestedDietFood_Description(String suggestedDietFood_Description) {
        SuggestedDietFood_Description = suggestedDietFood_Description;
    }
}
