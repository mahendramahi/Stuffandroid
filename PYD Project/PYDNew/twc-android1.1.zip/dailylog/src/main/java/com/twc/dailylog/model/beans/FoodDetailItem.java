package com.twc.dailylog.model.beans;

/**
 * Created by ManishJ1 on 7/13/2016.
 */
public class FoodDetailItem {

    private String name;
    private int quantity;
    private double calorie;
    private double fat;
    private double sodium;
    private double carbs;
    private double cholestrol;
    private double protin;
    private String standardServing;

    public String getStandardServing() {
        return standardServing;
    }

    public void setStandardServing(String standardServing) {
        this.standardServing = standardServing;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public double getCalorie() {
        return calorie;
    }

    public void setCalorie(double calorie) {
        this.calorie = calorie;
    }

    public double getFat() {
        return fat;
    }

    public void setFat(double fat) {
        this.fat = fat;
    }

    public double getSodium() {
        return sodium;
    }

    public void setSodium(double sodium) {
        this.sodium = sodium;
    }

    public double getCarbs() {
        return carbs;
    }

    public void setCarbs(double carbs) {
        this.carbs = carbs;
    }

    public double getCholestrol() {
        return cholestrol;
    }

    public void setCholestrol(double cholestrol) {
        this.cholestrol = cholestrol;
    }

    public double getProtin() {
        return protin;
    }

    public void setProtin(double protin) {
        this.protin = protin;
    }
}
