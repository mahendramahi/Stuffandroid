package com.truworth.wellnesscorner.ui.mobileverification;

/**
 * Created by rajeshs on 4/4/2018.
 */

public class MobileNumberRedirectionType {
    public static final int FROM_LOGIN = 1;
    public static final int FROM_REGISTRATION = 2;
}
