package com.truworth.wellnesscorner.ui.mainapp.circle;

import android.app.Activity;
import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.content.ContextCompat;
import android.support.v4.widget.NestedScrollView;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;

import com.truworth.discoverlib.DiscoverActivity;
import com.truworth.discoverlib.model.DiscoverUser;
import com.truworth.discoverlib.utils.DiscoverConfig;
import com.truworth.wellnesscorner.BR;
import com.truworth.wellnesscorner.R;
import com.truworth.wellnesscorner.TheWellnessCornerApp;
import com.truworth.wellnesscorner.base.BaseFragment;
import com.truworth.wellnesscorner.data.SharedPreferenceHelper;
import com.truworth.wellnesscorner.databinding.FragmentCirclesBinding;
import com.truworth.wellnesscorner.model.Article;
import com.truworth.wellnesscorner.model.Discussions;
import com.truworth.wellnesscorner.model.MyCircle;
import com.truworth.wellnesscorner.model.PopularCircle;
import com.truworth.wellnesscorner.model.PopularProduct;
import com.truworth.wellnesscorner.ui.mainapp.circledetail.CircleAboutActivity;
import com.truworth.wellnesscorner.ui.mainapp.circledetail.CircleDetailActivity;
import com.truworth.wellnesscorner.ui.mainapp.createpost.CreatePostActivity;
import com.truworth.wellnesscorner.utils.AppConstants;
import com.twc.store.StoreActivity;
import com.twc.store.StoreCategoryActivity;
import com.twc.store.StoreDetailActivity;
import com.twc.store.model.beans.StoreUser;
import com.twc.store.utils.Constant;
import com.twc.store.utils.StoreConfig;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

public class CirclesFragment extends BaseFragment<FragmentCirclesBinding, CircleViewModel> implements SwipeRefreshLayout.OnRefreshListener {
    CircleViewModel viewModel;
    ArrayList<MyCircle> circles;
    ArrayList<PopularCircle> popularCircles;
    ArrayList<PopularProduct> productList;
    ArrayList<Article> articleList;
    List<Discussions> discussionsList;
    MyCircleRecyclerAdapter adapter;
    PopularCirclesAdapter popularCirclesAdapter;
    PopularProductAdapter productAdapter;
    ArticlesAdapter articleAdapter;
    DiscussionsAdapter discussionsAdapter;
    @Inject
    SharedPreferenceHelper prefHelper;
    boolean _areDataLoaded = false;
    private int nestedScrollViewX = 0;
    private int nestedScrollViewY = 0;
    private Handler handlerCircleApi = new Handler();
    private Runnable runnable = new Runnable() {
        @Override
        public void run() {
            viewModel.loadMyCircles();
            viewModel.loadPopularCircles();
            viewModel.loadPopularProducts();
            viewModel.loadPopularArticles();
            viewModel.loadPopularDiscussions();

        }
    };

    public CirclesFragment() {
        // Required empty public constructor
        TheWellnessCornerApp.getApp().component().inject(this);
    }

    public static CirclesFragment newInstance() {
        CirclesFragment fragment = new CirclesFragment();
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        getViewDataBinding().nsView.scrollTo(nestedScrollViewX, nestedScrollViewY);
        circles = new ArrayList<>();
        popularCircles = new ArrayList<>();
        productList = new ArrayList<>();
        articleList = new ArrayList<>();
        discussionsList = new ArrayList<>();
        setUpCircleRecycler();
        setUpPopularCircleRecycler();
        setUpPopularProductRecycler();
        setUpArticleRecycler();
        setUpDiscussionsRecycler();
        setDataObserver();


        getViewDataBinding().nsView.setOnScrollChangeListener(new NestedScrollView.OnScrollChangeListener() {
            @Override
            public void onScrollChange(NestedScrollView v, int scrollX, int scrollY, int oldScrollX, int oldScrollY) {
                nestedScrollViewX = scrollX;
                nestedScrollViewY = scrollY;
                View view = getViewDataBinding().nsView.getChildAt(getViewDataBinding().nsView.getChildCount() - 1);
                int diff = (view.getBottom() - (getViewDataBinding().nsView.getHeight() + getViewDataBinding().nsView.getScrollY()));

                if (diff >= 0) {
                    if (scrollY == 0) {
                        getViewDataBinding().imgUpArrow.setVisibility(View.GONE);
                    } else {
                        getViewDataBinding().imgUpArrow.setVisibility(View.VISIBLE);
                    }
                } else {
                    getViewDataBinding().imgUpArrow.setVisibility(View.GONE);
                }
            }
        });

        navigateToPlan();
        navigateToDevices();
        navigateToSupplements();
        navigateToSpa();
        setUpArrowObserver();
        getViewDataBinding().swipeRefreshLayout.setProgressViewOffset(true,80,150);
        getViewDataBinding().swipeRefreshLayout.setColorSchemeColors(ContextCompat.getColor(getContext(),R.color.text_grey));
        getViewDataBinding().swipeRefreshLayout.setOnRefreshListener(this);
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        if (isVisibleToUser && !_areDataLoaded) {
            handlerCircleApi.postDelayed(runnable, 50);
            _areDataLoaded = true;
        }
    }

    private void navigateToDevices() {
        viewModel.getOnDeviceClick().observe(this, new Observer<Void>() {
            @Override
            public void onChanged(@Nullable Void aVoid) {
                StoreUser storeUser = new StoreUser(prefHelper.getUserName(), "9834989393", prefHelper.getEmailId(), "0", "Male", "Premium",
                        "bearer " + prefHelper.getToken());
                StoreConfig.init("Wellness", AppConstants.API_ENDPOINT, storeUser, true);

                if (!StoreConfig.APP_NAME.isEmpty() && !StoreConfig.BASE_URL.isEmpty() && StoreConfig.storeUser != null) {
                    Intent intent = new Intent(getContext(), StoreCategoryActivity.class);
                    intent.putExtra("category", Constant.HEALTH_PRODUCT);
                    intent.putExtra("categoryId", 9);
                    intent.putExtra("venderId", 2);
                    getContext().startActivity(intent);
                } else {
                }
            }
        });
    }

    private void navigateToPlan() {
        viewModel.getOnPlanClick().observe(this, new Observer<Void>() {
            @Override
            public void onChanged(@Nullable Void aVoid) {

                StoreUser storeUser = new StoreUser(prefHelper.getUserName(), "9834989393", prefHelper.getEmailId(), "0", "Male", "Premium",
                        "bearer " + prefHelper.getToken());
                StoreConfig.init("Wellness", AppConstants.API_ENDPOINT, storeUser, true);

                if (!StoreConfig.APP_NAME.isEmpty() && !StoreConfig.BASE_URL.isEmpty() && StoreConfig.storeUser != null) {
                    Intent intent = new Intent(getContext(), StoreCategoryActivity.class);
                    intent.putExtra("category", Constant.WELLNESS_PLAN);
                    intent.putExtra("categoryId", 1);
                    intent.putExtra("venderId", 1);
                    getContext().startActivity(intent);
                } else {
                }
            }
        });
    }

    private void navigateToSupplements() {
        viewModel.getOnSupplementsClick().observe(this, new Observer<Void>() {
            @Override
            public void onChanged(@Nullable Void aVoid) {
                StoreUser storeUser = new StoreUser(prefHelper.getUserName(), "9834989393", prefHelper.getEmailId(), "0", "Male", "Premium",
                        "bearer " + prefHelper.getToken());
                StoreConfig.init("Wellness", AppConstants.API_ENDPOINT, storeUser, true);

                if (!StoreConfig.APP_NAME.isEmpty() && !StoreConfig.BASE_URL.isEmpty() && StoreConfig.storeUser != null) {
                    Intent intent = new Intent(getContext(), StoreCategoryActivity.class);
                    intent.putExtra("category",  Constant.HEALTH_PRODUCT);
                    intent.putExtra("categoryId", 17);
                    intent.putExtra("venderId", 2);
                    getContext().startActivity(intent);
                } else {
                }
            }
        });
    }

    private void navigateToSpa() {
        viewModel.getOnSpaClick().observe(this, new Observer<Void>() {
            @Override
            public void onChanged(@Nullable Void aVoid) {
                StoreUser storeUser = new StoreUser(prefHelper.getUserName(), "9834989393", prefHelper.getEmailId(), "0", "Male", "Premium",
                        "bearer " + prefHelper.getToken());
                StoreConfig.init("Wellness", AppConstants.API_ENDPOINT, storeUser, true);

                if (!StoreConfig.APP_NAME.isEmpty() && !StoreConfig.BASE_URL.isEmpty() && StoreConfig.storeUser != null) {
                    Intent intent = new Intent(getContext(), StoreCategoryActivity.class);
                    intent.putExtra("category",  Constant.HEALTH_PRODUCT);
                    intent.putExtra("categoryId", 12);
                    intent.putExtra("venderId", 2);
                    getContext().startActivity(intent);
                } else {
                }
            }
        });
    }

    private void setUpCircleRecycler() {
        RecyclerView recyclerView = getViewDataBinding().circlesRecycler;
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        adapter = new MyCircleRecyclerAdapter(circles);
        recyclerView.setAdapter(adapter);
    }

    private void setUpPopularCircleRecycler() {
        RecyclerView recyclerView = getViewDataBinding().popularRecycler;
        recyclerView.setLayoutManager(new GridLayoutManager(getActivity(), 2));
        popularCirclesAdapter = new PopularCirclesAdapter(popularCircles);
        recyclerView.setAdapter(popularCirclesAdapter);
    }

    private void setUpPopularProductRecycler() {
        RecyclerView recyclerView = getViewDataBinding().storeRecycler;
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity(), LinearLayoutManager.HORIZONTAL, false));
        productAdapter = new PopularProductAdapter(productList);
        recyclerView.setAdapter(productAdapter);
    }

    private void setUpArticleRecycler() {
        RecyclerView recyclerView = getViewDataBinding().healthyLivingRecycler;
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        articleAdapter = new ArticlesAdapter(articleList);
        recyclerView.setAdapter(articleAdapter);
    }

    private void setUpDiscussionsRecycler() {
        RecyclerView recyclerView = getViewDataBinding().communityDiscussionLivingRecycler;
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        discussionsAdapter = new DiscussionsAdapter(discussionsList);
        recyclerView.setAdapter(discussionsAdapter);
    }

    private void setDataObserver() {
        viewModel.getMyCircles().observe(this, new Observer<ArrayList<MyCircle>>() {
            @Override
            public void onChanged(@Nullable ArrayList<MyCircle> myCircles) {
                circles.clear();
                circles.addAll(myCircles);
                adapter.notifyDataSetChanged();
            }
        });


        viewModel.getPopularCircles().observe(this, new Observer<ArrayList<PopularCircle>>() {
            @Override
            public void onChanged(@Nullable ArrayList<PopularCircle> circles) {
                popularCircles.clear();
                popularCircles.addAll(circles);
                popularCirclesAdapter.notifyDataSetChanged();
            }
        });
        viewModel.getProducts().observe(this, new Observer<ArrayList<PopularProduct>>() {
            @Override
            public void onChanged(@Nullable ArrayList<PopularProduct> popularProducts) {
                productList.clear();
                productList.addAll(popularProducts);
                productAdapter.notifyDataSetChanged();
            }
        });

        viewModel.getArticles().observe(this, new Observer<ArrayList<Article>>() {
            @Override
            public void onChanged(@Nullable ArrayList<Article> articles) {
                articleList.clear();
                articleList.addAll(articles);
                articleAdapter.notifyDataSetChanged();

            }
        });

        viewModel.getDiscussions().observe(this, new Observer<List<Discussions>>() {
            @Override
            public void onChanged(@Nullable List<Discussions> discussions) {
                discussionsList.clear();
                discussionsList.addAll(discussions);
                discussionsAdapter.notifyDataSetChanged();
            }
        });
    }

    /**
     * Override for set binding variable
     *
     * @return variable id
     */
    @Override
    public int getBindingVariable() {
        return BR.viewModel;
    }

    /**
     * @return layout resource id
     */
    @Override
    public int getLayoutId() {
        return R.layout.fragment_circles;
    }

    /**
     * Override for set view model
     *
     * @return view model instance
     */
    @Override
    public CircleViewModel getViewModel() {
        viewModel = ViewModelProviders.of(this).get(CircleViewModel.class);
        return viewModel;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
    }

    @Override
    public void onStop() {
        super.onStop();
        _areDataLoaded = false;
        if (handlerCircleApi != null) {
            handlerCircleApi.removeCallbacks(runnable);
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();

    }

    private void setUpArrowObserver() {
        viewModel.getUpArrow().observe(this, new Observer<Void>() {
            @Override
            public void onChanged(@Nullable Void avoid) {
                getViewDataBinding().nsView.fling(0);
                getViewDataBinding().nsView.smoothScrollTo(0, 0);
                getViewDataBinding().imgUpArrow.setVisibility(View.GONE);
            }
        });
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == CircleAboutActivity.REUEST_CODE) {
                viewModel.loadMyCircles();
                viewModel.loadPopularCircles();
            } else if (requestCode == CircleDetailActivity.REUEST_CODE) {
                viewModel.loadMyCircles();
            }
        }
    }

    @Override
    public void onRefresh() {
        viewModel.isSwipeRefresh.set(true);
        handlerCircleApi.postDelayed(runnable, 0);
    }
}
