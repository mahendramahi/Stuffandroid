package com.truworth.wellnesscorner.ui.login;

import android.arch.lifecycle.Observer;
import android.content.Intent;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.BottomSheetDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.TextView;

import com.truworth.wellnesscorner.R;
import com.truworth.wellnesscorner.databinding.ActivityLoginCategoryBinding;
import com.truworth.wellnesscorner.utils.KeyBoardUtils;

public class LoginCategoryActivity extends AppCompatActivity {

    LoginCategoryViewModel viewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ActivityLoginCategoryBinding binding = DataBindingUtil.setContentView(this, R.layout.activity_login_category);
        viewModel = new LoginCategoryViewModel();

        binding.setViewModel(viewModel);
        attachBottomSheetFBGoogleObserver();
    }

    private void attachBottomSheetFBGoogleObserver() {
        viewModel.getCallBottomSheetFB().observe(this, new Observer<Void>() {
            @Override
            public void onChanged(@Nullable Void aVoid) {

                showCorporateDialog();
            }
        });
        viewModel.getCallBottomSheetGoogle().observe(this, new Observer<Void>() {
            @Override
            public void onChanged(@Nullable Void aVoid) {
                showCorporateDialog();
            }
        });
        viewModel.getCallLoginScreen().observe(this, new Observer<Void>() {
            @Override
            public void onChanged(@Nullable Void aVoid) {
                startActivity(new Intent(LoginCategoryActivity.this, LoginActivity.class));

            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        KeyBoardUtils.hideSoftKeyboard(this);
    }

    public void showCorporateDialog() {
        BottomSheetDialog mBottomSheetDialog = new BottomSheetDialog(LoginCategoryActivity.this);
        View sheetView = LoginCategoryActivity.this.getLayoutInflater().inflate(R.layout.dialog_bottomsheet_onfacebooktap, null);

        mBottomSheetDialog.setContentView(sheetView);

        ((View) sheetView.getParent()).setBackgroundColor(LoginCategoryActivity.this.getResources().getColor(android.R.color.transparent));
        ((View) sheetView.getParent()).setPadding(40, 40, 40, 40);

        TextView tvGoBack = sheetView.findViewById(R.id.tvGoBack);
        tvGoBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mBottomSheetDialog.dismiss();
            }
        });
        mBottomSheetDialog.show();
    }
}
