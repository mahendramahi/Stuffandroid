package com.truworth.wellnesscorner.repo.model.request;

import com.google.gson.annotations.SerializedName;

public class PostTagTypeDataRequest {

    @SerializedName("TagIndex")
    private int TagIndex;
    @SerializedName("TagTypeId")
    private int TagTypeId;
    @SerializedName("TagName")
    private String TagName;
    @SerializedName("TagMapIdentity")
    private String TagMapIdentity;

    public int getTagIndex() {
        return TagIndex;
    }

    public void setTagIndex(int TagIndex) {
        this.TagIndex = TagIndex;
    }

    public int getTagTypeId() {
        return TagTypeId;
    }

    public void setTagTypeId(int TagTypeId) {
        this.TagTypeId = TagTypeId;
    }

    public String getTagName() {
        return TagName;
    }

    public void setTagName(String TagName) {
        this.TagName = TagName;
    }

    public String getTagMapIdentity() {
        return TagMapIdentity;
    }

    public void setTagMapIdentity(String TagMapIdentity) {
        this.TagMapIdentity = TagMapIdentity;
    }
}
