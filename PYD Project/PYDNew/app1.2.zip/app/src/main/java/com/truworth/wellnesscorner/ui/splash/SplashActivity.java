package com.truworth.wellnesscorner.ui.splash;

import android.arch.lifecycle.ViewModelProviders;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.truworth.wellnesscorner.R;
import com.truworth.wellnesscorner.ui.mainapp.HomeDashBoardActivity;
import com.truworth.wellnesscorner.ui.login.LoginCategoryActivity;
import com.truworth.wellnesscorner.ui.registration.RegistrationActivity;

import java.util.Timer;
import java.util.TimerTask;

public class SplashActivity extends AppCompatActivity {
    SplashViewModel viewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        viewModel = ViewModelProviders.of(this).get(SplashViewModel.class);
        TimerTask task = new TimerTask() {
            @Override
            public void run() {
                Intent intent = null;
//                if (WellnessCornerApp.getPreferenceManager().getUserId() != null && WellnessCornerApp.getPreferenceManager().getIsUserProfileCompleted() && !WellnessCornerApp.getPreferenceManager().getUserId().isEmpty()) {
//                    intent = new Intent(SplashActivity.this, HomeActivity.class);
//                }
//                else {

                //  }
                if (viewModel.isAlreadyLoggedIn() && viewModel.isProfileStepCompleted()) {
                    //TODO
                    //Open dashboard here
                    intent = new Intent(SplashActivity.this, HomeDashBoardActivity.class);
                    startActivity(intent);

                } else if (viewModel.isAlreadyLoggedIn() && !viewModel.isProfileStepCompleted()) {
                    //intent = new Intent(SplashActivity.this, RegistrationActivity.class)

                    RegistrationActivity.startRegistration(SplashActivity.this, viewModel.getEmailId());
                } else {
                intent = new Intent(SplashActivity.this, LoginCategoryActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NO_HISTORY);
                startActivity(intent);
                }

                finish();
            }
        };

        Timer timer = new Timer();
        timer.schedule(task, 3000);
    }
}
