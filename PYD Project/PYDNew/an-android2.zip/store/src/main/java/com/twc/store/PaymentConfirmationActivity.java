package com.twc.store;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import com.twc.store.views.CustomTextView;
import com.twc.store.views.ViewCustomRoundedTextView;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * Created by Someshk on 11-05-2017.
 */
public class PaymentConfirmationActivity extends AppCompatActivity {

    private static final String TRANSACTION_ID_KEY = "TRANSACTION_ID";
    private static final String TRANSACTION_RESULT_KEY = "TRANSACTION_RESULT";
    @BindView(R2.id.ivConfirmationImage)
    ImageView ivConfirmationImage;
    @BindView(R2.id.tvConfirmationTitle)
    CustomTextView tvConfirmationTitle;
    @BindView(R2.id.tvConfirmationDesc)
    CustomTextView tvConfirmationDesc;
    @BindView(R2.id.btnDone)
    Button btnDone;
    @BindView(R2.id.layoutColor)
    FrameLayout layoutColor;

    @BindView(R2.id.rlLayoutSuccess)
    RelativeLayout rlLayoutSuccess;

    @BindView(R2.id.llPaymentFailed)
    LinearLayout llPaymentFailed;

    @BindView(R2.id.btnBack)
    ViewCustomRoundedTextView btnBack;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment_confirmation);
        ButterKnife.bind(this);
        getIntentAndConfigureLayout();

    }

    private void getIntentAndConfigureLayout() {
        if (getIntent() != null) {
            String transactionKey = getIntent().getStringExtra(TRANSACTION_ID_KEY);
            TransactionResult result = (TransactionResult) getIntent().getSerializableExtra(TRANSACTION_RESULT_KEY);
            switch (result) {
                case SUCCESS:
                    llPaymentFailed.setVisibility(View.GONE);
                    rlLayoutSuccess.setVisibility(View.VISIBLE);
                    btnDone.setVisibility(View.VISIBLE);

                    int primaryColor = ContextCompat.getColor(this, R.color.colorPrimary);
                    tvConfirmationTitle.setText(R.string.payment_congrats);
                    tvConfirmationDesc.setText("Your order has been successfully placed.\nYour Order ID is  " + transactionKey + "." + "\nPlease check your email for invoice. For any queries, reach out to us on support@truworthwellness.com");
                    ivConfirmationImage.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.save_reading_icon));
                    layoutColor.setBackgroundColor(primaryColor);
                    tvConfirmationTitle.setTextColor(primaryColor);
                    btnDone.setBackgroundColor(primaryColor);
                    break;

                case FAILURE:
                    rlLayoutSuccess.setVisibility(View.GONE);
                    btnDone.setVisibility(View.GONE);
                    llPaymentFailed.setVisibility(View.VISIBLE);
                   // tvConfirmationTitle.setText(R.string.payment_failed);
                    //tvConfirmationDesc.setText(R.string.payment_failed_message);
                    //ivConfirmationImage.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.mh_cancel));
                    //layoutColor.setBackgroundColor(Color.RED);
                    //tvConfirmationTitle.setTextColor(Color.RED);
                    //btnDone.setBackgroundColor(Color.RED);
                    // ivConfirmationImage.setColorFilter(Color.RED);
                    break;
            }
        }
    }

   @OnClick(R2.id.btnDone)
    public void onViewClicked() {
        TransactionResult result = (TransactionResult) getIntent().getSerializableExtra(TRANSACTION_RESULT_KEY);
        switch (result) {
            case SUCCESS:
                callForFinish(Activity.RESULT_OK);
                break;

            case FAILURE:
                callForFinish(Activity.RESULT_CANCELED);
                break;
        }

    }

    @OnClick(R2.id.btnBack)
    public void onBack(){
        callForFinish(Activity.RESULT_CANCELED);
    }



    @Override
    public void onBackPressed() {
        super.onBackPressed();
        onViewClicked();
    }

    private void callForFinish(int resultStatus) {
        Intent intent = new Intent();
        if (resultStatus == Activity.RESULT_OK) {
            intent.putExtra("paymentStatus", Activity.RESULT_OK);
        } else {
            intent.putExtra("paymentStatus", Activity.RESULT_CANCELED);
        }
        setResult(resultStatus, intent);
        finish();
    }


    public enum TransactionResult {
        SUCCESS, FAILURE
    }

}
