package com.truworth.wellnesscorner.repo.model.request;

/**
 * Created by GurvinderS on 4/10/2018.
 */

public class SaveProfileRequest {
    String ScreenName;
    String Bio;

    public String getScreenName() {
        return ScreenName;
    }

    public void setScreenName(String screenName) {
        ScreenName = screenName;
    }

    public String getBio() {
        return Bio;
    }

    public void setBio(String bio) {
        Bio = bio;
    }

    public String getImage() {
        return Image;
    }

    public void setImage(String image) {
        Image = image;
    }

    public String getImageExtention() {
        return ImageExtention;
    }

    public void setImageExtention(String imageExtention) {
        ImageExtention = imageExtention;
    }

    String Image;
    String ImageExtention;
}
