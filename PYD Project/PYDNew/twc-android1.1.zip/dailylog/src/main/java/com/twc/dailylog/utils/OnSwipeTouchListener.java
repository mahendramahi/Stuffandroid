package com.twc.dailylog.utils;

import android.app.Activity;
import android.view.MotionEvent;
import android.view.View;

/**
 * Created by ManishJ1 on 8/12/2016.
 */
public class OnSwipeTouchListener implements View.OnTouchListener {
    private static final int MIN_DISTANCE = 150;
    Activity activity;
    private float x1, x2;
    public OnSwipeTouchListener(Activity activity) {
        this.activity = activity;
    }



    @Override
    public boolean onTouch(final View view, MotionEvent motionEvent) {
        int action = motionEvent.getActionMasked();
        switch (action) {

            case MotionEvent.ACTION_POINTER_UP :
            case MotionEvent.ACTION_CANCEL:
                Utils.printLog("ontocuh", "Action was ACTION_POINTER_UP");
                return true;

            case MotionEvent.ACTION_DOWN:
                x1 = motionEvent.getX();
                Utils.printLog("ontocuh", "Action was DOWN");
                return true;

            case MotionEvent.ACTION_MOVE:
                Utils.printLog("ontocuh", "Action was MOVE");
                return true;

            case MotionEvent.ACTION_UP:
                x2 = motionEvent.getX();
                float deltaX = x2 - x1;
                Utils.printLog("ontocuh", "Action was UP");
                if (Math.abs(deltaX) > MIN_DISTANCE)
                {
                    // Left to Right swipe action
                    if (x2 > x1)
                    {
                       // Toast.makeText(activity, "Left to Right swipe [Next]", Toast.LENGTH_SHORT).show ();
                        onSwipeLeft();
                    }

                    // Right to left swipe action
                    else
                    {
                        //Toast.makeText(activity, "Right to Left swipe [Previous]", Toast.LENGTH_SHORT).show ();
                        onSwipeRight();
                    }

                }
                else
                {
                    // consider as something else - a screen tap for example
                   // Toast.makeText(activity, "Single Tap", Toast.LENGTH_SHORT).show ();
                    onClick(view);

                }


                return true;
        }
        return false;
    }

    public void onSwipeRight()
    {

    }

    public void onSwipeLeft()
        {
    }
    public void onClick(View view)
    {
    }
}
