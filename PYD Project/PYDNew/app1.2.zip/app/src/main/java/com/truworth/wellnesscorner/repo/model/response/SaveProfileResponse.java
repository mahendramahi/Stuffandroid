package com.truworth.wellnesscorner.repo.model.response;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * Created by GurvinderS on 4/10/2018.
 */

public class SaveProfileResponse {

    /**
     * data : {"isSave":true,"isCircleJoin":false}
     * hasError : false
     * error : null
     */
    @SerializedName("data")
    @Expose
    private DataBean data;
    @SerializedName("hasError")
    @Expose
    private boolean hasError;
    @SerializedName("error")
    @Expose
    private Error error;


    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public boolean isHasError() {
        return hasError;
    }

    public void setHasError(boolean hasError) {
        this.hasError = hasError;
    }

    public Error getError() {
        return error;
    }

    public void setError(Error error) {
        this.error = error;
    }

    public static class DataBean {
        /**
         * isSave : true
         * isCircleJoin : false
         */

        private boolean isSave;
        private boolean isCircleJoin;

        public boolean isIsSave() {
            return isSave;
        }

        public void setIsSave(boolean isSave) {
            this.isSave = isSave;
        }

        public boolean isIsCircleJoin() {
            return isCircleJoin;
        }

        public void setIsCircleJoin(boolean isCircleJoin) {
            this.isCircleJoin = isCircleJoin;
        }
    }
}
