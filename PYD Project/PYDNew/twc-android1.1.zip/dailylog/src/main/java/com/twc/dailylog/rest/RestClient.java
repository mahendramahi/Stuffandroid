package com.twc.dailylog.rest;

import android.content.Context;

/**
 * Created by ManishJ1 on 6/29/2016.
 */
public class RestClient extends AbstractRestClient {

    private DailyLogService dailyLogService;
    private TrackersService trackerService;
    private WeightService weightService;
    public RestClient(Context context, String baseUrl, boolean debug) {
        super(context, baseUrl, debug);
    }

    @Override
    public void initApi() {

        dailyLogService = client.create(DailyLogService.class);
        trackerService = client.create(TrackersService.class);
        weightService = client.create(WeightService.class);
    }


    public DailyLogService getDailyLogService() {
        return dailyLogService;
    }

    public TrackersService getTrackersService() {
        return trackerService;
    }
    public WeightService getWeightService() {
        return weightService;
    }
}
