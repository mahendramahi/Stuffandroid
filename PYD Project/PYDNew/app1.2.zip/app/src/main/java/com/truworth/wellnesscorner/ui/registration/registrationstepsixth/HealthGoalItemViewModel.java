package com.truworth.wellnesscorner.ui.registration.registrationstepsixth;

import android.content.Context;
import android.databinding.BaseObservable;
import android.databinding.BindingAdapter;
import android.databinding.ObservableBoolean;
import android.databinding.ObservableField;
import android.graphics.drawable.Drawable;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.Toast;

import com.truworth.wellnesscorner.repo.model.response.HealthGoalResponse;

/**
 * Created by PalakC on 4/5/2018.
 */

public class HealthGoalItemViewModel extends BaseObservable {

    public ObservableBoolean isSelectedItem = new ObservableBoolean();
    private HealthGoalResponse.HealthGoalItem goalItems;

    public HealthGoalItemViewModel(HealthGoalResponse.HealthGoalItem goalItems) {
        this.goalItems = goalItems;

    }

    public String getGoalName() {
        return goalItems.getName();
    }


    /*public void onItemSelected(View view) {
        if (!isSelectedItem.get()) {
            view.setSelected(true);
            isSelectedItem.set(true);
        } else {
            view.setSelected(false);
            isSelectedItem.set(false);
        }
        notifyChange();
    }*/

}
