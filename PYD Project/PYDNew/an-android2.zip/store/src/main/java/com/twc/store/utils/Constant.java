package com.twc.store.utils;


public class Constant {



    public static final String WELLNESS_PLAN = "Wellness Plans";
    public static final String HEALTH_PRODUCT = "Health Products";

    public static int PAYMENT_INTEGRATION_REQUEST_CODE = 1004;
    public static int PAYMENT_CONFIRMATION_REQUEST_CODE = 1005;


    // debug enviroument for payumoney

  /*  public static String Merchant_ID = "393463";
    public static String Merchant_KEY = "LLKwG0";
    public static String Merchant_SALT = "qauKbEAJ";
    public static boolean IS_PAYUMONEY_DEBUG = true;*/

    // live enviroument
  public static String Merchant_ID = "4928526";
    public static String Merchant_KEY = "QHuD2p";
    public static String Merchant_SALT = "dQZeEri9";
    public static boolean IS_PAYUMONEY_DEBUG = false;



}
