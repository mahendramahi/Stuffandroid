package com.twc.store;

import com.bumptech.glide.Glide;
import com.bumptech.glide.Priority;
import com.bumptech.glide.RequestManager;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.RequestOptions;

/**
 * Created by GurvinderS on 3/28/2018.
 */

public class GlideConfig {
    private RequestManager requestManager;

    private static GlideConfig instance = null;
    public synchronized static GlideConfig getInstance() {
        return instance;
    }


    public void glideSetup(StoreActivity activity){
        instance=GlideConfig.this;
        setImageLoader(Glide.with(activity));
        initGlideImageConfigurations();
    }

    public void glideSetupDetail(StoreDetailActivity activity){
        instance=GlideConfig.this;
        setImageLoader(Glide.with(activity));
        initGlideImageConfigurations();
    }

    public void glideSetupCategory(StoreCategoryActivity activity){
        instance=GlideConfig.this;
        setImageLoader(Glide.with(activity));
        initGlideImageConfigurations();
    }

    public RequestManager getImageLoader() {
        return requestManager;
    }
    private void setImageLoader(RequestManager requestManager) {
        this.requestManager = requestManager;
    }
    private void initGlideImageConfigurations() {

        RequestOptions options = new RequestOptions()
                .placeholder(R.drawable.wellness_no_logo)
                .error(R.drawable.wellness_no_logo)
                .priority(Priority.HIGH)
                .diskCacheStrategy(DiskCacheStrategy.ALL);

        requestManager.setDefaultRequestOptions(options);


    }
}
