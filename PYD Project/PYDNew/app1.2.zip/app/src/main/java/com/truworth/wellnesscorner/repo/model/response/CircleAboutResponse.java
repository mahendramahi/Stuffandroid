package com.truworth.wellnesscorner.repo.model.response;

import com.truworth.wellnesscorner.model.CircleAboutBean;

import java.util.List;

public class CircleAboutResponse {
    private CircleAboutBean data;
    private boolean hasError;
    private Object error;

    public CircleAboutBean getData() {
        return data;
    }

    public void setData(CircleAboutBean data) {
        this.data = data;
    }

    public boolean isHasError() {
        return hasError;
    }

    public void setHasError(boolean hasError) {
        this.hasError = hasError;
    }

    public Object getError() {
        return error;
    }

    public void setError(Object error) {
        this.error = error;
    }

}
