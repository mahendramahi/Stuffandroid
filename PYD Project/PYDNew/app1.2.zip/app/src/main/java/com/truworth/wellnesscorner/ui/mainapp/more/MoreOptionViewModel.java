package com.truworth.wellnesscorner.ui.mainapp.more;

import android.databinding.ObservableField;

import com.truworth.wellnesscorner.TheWellnessCornerApp;
import com.truworth.wellnesscorner.base.BaseViewModel;
import com.truworth.wellnesscorner.data.SharedPreferenceHelper;
import com.truworth.wellnesscorner.utils.SingleLiveEvent;

import javax.inject.Inject;

/**
 * Created by PalakC on 4/16/2018.
 */

public class MoreOptionViewModel extends BaseViewModel {
    @Inject
    SharedPreferenceHelper prefHelper;
    public ObservableField<String> userImage=new ObservableField<>();
    public ObservableField<String> userName=new ObservableField<>();
    SingleLiveEvent<Void> onHraClick = new SingleLiveEvent<>();
    SingleLiveEvent<Void> onStoreClick = new SingleLiveEvent<>();
   // SingleLiveEvent<Void> onDisCoverClick = new SingleLiveEvent<>();
  //  SingleLiveEvent<Void> onReminderClick = new SingleLiveEvent<>();
    SingleLiveEvent<Void> onLogoutClick = new SingleLiveEvent<>();
    public MoreOptionViewModel() {
        TheWellnessCornerApp.getApp().component().inject(this);
        userImage.set(prefHelper.getUserImageUrl());
        userName.set(prefHelper.getUserName());
    }

    public SingleLiveEvent<Void> getOnHraClick() {
        return onHraClick;
    }

    public SingleLiveEvent<Void> getOnStoreClick() {
        return onStoreClick;
    }

  /*  public SingleLiveEvent<Void> getOnDisCoverClick() {
        return onDisCoverClick;
    }

    public SingleLiveEvent<Void> getOnReminderClick() {
        return onReminderClick;
    }
*/
    public SingleLiveEvent<Void> getOnLogoutClick() {
        return onLogoutClick;
    }


    public void onHraClicked() {
        onHraClick.call();
    }

    public void onStoreClicked() {
        onStoreClick.call();
    }

   /* public void onDiscoverClicked() {
        onDisCoverClick.call();
    }

    public void onReminderClicked() {
        onReminderClick.call();
    }*/

    public void onLogoutClicked() {
        onLogoutClick.call();
    }
}
