package com.twc.hramodule.interfaces;

/**
 If this code works it was written by Somesh Kumar on 15 October, 2016. If not, I don't know who wrote it.
 */
public interface OnHraDbAction {
    void onHraQuestionSave(long QuestionId, String Answer, String ScreenNo, int isSure);

}
