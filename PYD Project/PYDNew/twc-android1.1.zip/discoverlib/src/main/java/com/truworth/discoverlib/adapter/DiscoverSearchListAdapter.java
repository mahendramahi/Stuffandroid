package com.truworth.discoverlib.adapter;

import android.app.Activity;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;


import com.bumptech.glide.Glide;
import com.truworth.discoverlib.fragment.ArticleDetailFragmentNew;
import com.truworth.discoverlib.fragment.SlideshowFragment;
import com.truworth.discoverlib.utils.Constant;
import com.truworth.discoverlib.R;
import com.truworth.discoverlib.model.SearchDiscoverByKeywordResponse.DiscoverSearchBean;
import com.truworth.discoverlib.utils.Utils;

import java.util.List;



/**
 * Created by ManishJ1 on 8/12/2016.
 */

public class DiscoverSearchListAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private static final int VIEW_TYPE_SMALL = 1;
    private static final int VIEW_TYPE_PROGRESS = 2;
    private List<DiscoverSearchBean> mArticleItems;
    private Activity activity;


    public DiscoverSearchListAdapter(List<DiscoverSearchBean> articleList, Activity activity) {
        mArticleItems = articleList;
        this.activity = activity;

    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        RecyclerView.ViewHolder viewHolder = null;
        View itemView;
        switch (viewType) {
            case VIEW_TYPE_SMALL:
                itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_discover_list_small, parent, false);
                viewHolder = new ViewHolderSmall(itemView);
                break;

            case VIEW_TYPE_PROGRESS:
                itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_loading_progress, parent, false);
                viewHolder = new ViewHolderLoading(itemView);
        }
        return viewHolder;

    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        DiscoverSearchBean articleItem = mArticleItems.get(position);
        switch (holder.getItemViewType()) {

            case VIEW_TYPE_SMALL:
                ViewHolderSmall viewHolderSmall = (ViewHolderSmall) holder;
                viewHolderSmall.tvDiscoverTitle.setText(Utils.fromHtml(articleItem.getNAME()));
                Glide.with(activity).load(articleItem.getImageName()).into(viewHolderSmall.ivDiscoverImage);
                break;

            case VIEW_TYPE_PROGRESS:
                ViewHolderLoading viewHolderLoading = (ViewHolderLoading) holder;
                viewHolderLoading.mProgressBar.setIndeterminate(true);
                break;
        }

    }

    @Override
    public int getItemViewType(int position) {
        if (mArticleItems.get(position) == null) {
            return VIEW_TYPE_PROGRESS;
        } else {
            return VIEW_TYPE_SMALL;
        }
    }

    @Override
    public int getItemCount() {
        return mArticleItems != null ? mArticleItems.size() : 0;
    }


    private void showDetailScreen(int position) {
        if (mArticleItems.get(position).getType().equalsIgnoreCase(Constant.ARTICLE_TYPE_ARTICLES)) {
            Bundle bundle = new Bundle();
            bundle.putString(Constant.BUNDLE_KEY_ARTICLE_ID, mArticleItems.get(position).getURL());
            Utils.replaceFragment(activity.getFragmentManager(), ArticleDetailFragmentNew.newInstance(bundle), ArticleDetailFragmentNew.class.getSimpleName(), true, R.id.container);
        }  else if (mArticleItems.get(position).getType().equalsIgnoreCase(Constant.ARTICLE_TYPE_SLIDESHOW_SEARCH)) {
            Bundle bundle = new Bundle();
            bundle.putInt(Constant.BUNDLE_KEY_SLIDESHOW_ID, mArticleItems.get(position).getID());
            bundle.putString(Constant.BUNDLE_KEY_SLIDESHOW_URL, mArticleItems.get(position).getURL());
            Utils.replaceFragment(activity.getFragmentManager(), SlideshowFragment.newInstance(bundle), SlideshowFragment.class.getSimpleName(), true, R.id.container);
        }

    }



    public class ViewHolderSmall extends RecyclerView.ViewHolder {
        ImageView ivDiscoverImage;
        TextView tvDiscoverTitle;

        public ViewHolderSmall(View itemView) {
            super(itemView);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    showDetailScreen(getAdapterPosition());
                }
            });
            ivDiscoverImage = itemView.findViewById(R.id.ivDiscoverImage);
            tvDiscoverTitle = itemView.findViewById(R.id.tvDiscoverTitle);
        }
    }

    public class ViewHolderLoading extends RecyclerView.ViewHolder {
        ProgressBar mProgressBar;

        public ViewHolderLoading(View itemView) {
            super(itemView);
            mProgressBar = itemView.findViewById(R.id.progressBar);
        }
    }

}

