package com.truworth.discoverlib.model;

/**
 If this code works it was written by Somesh Kumar on 10 August, 2016. If not, I don't know who wrote it.
 */
public class SlideShowRequestBody {


    private String SlideID;
    private int memberid;

    public String getSlideID() {
        return SlideID;
    }

    public void setSlideID(String SlideID) {
        this.SlideID = SlideID;
    }

    public int getMemberid() {
        return memberid;
    }

    public void setMemberid(int memberid) {
        this.memberid = memberid;
    }
}
