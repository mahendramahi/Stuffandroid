package com.truworth.wellnesscorner.ui.mainapp.circledetail.members;

import com.truworth.wellnesscorner.base.BaseViewModel;
import com.truworth.wellnesscorner.model.CircleMemberListBean;
import com.truworth.wellnesscorner.utils.DateUtils;

public class CircleMemberItemViewModel extends BaseViewModel {
    CircleMemberListBean members;

    public CircleMemberItemViewModel(CircleMemberListBean members) {
        this.members = members;
    }

    public CircleMemberListBean getMembers() {
        return members;
    }

    public void setMembers(CircleMemberListBean members) {
        this.members = members;
    }

    public String getDateInFormat(String date){
        String newDateString ="";
        if(date !=null)
            newDateString = DateUtils.formatDate(date, "yyyy-MM-dd'T'HH:mm:ss", "MMMM dd, yyyy");
        return newDateString;
    }

    public String bioVisibility(){
       return (members.getMemberBio().toString());
    }
}
