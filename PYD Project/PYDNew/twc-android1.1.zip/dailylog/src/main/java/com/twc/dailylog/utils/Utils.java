package com.twc.dailylog.utils;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Fragment;
import android.content.Context;
import android.graphics.Color;
import android.os.Handler;
import android.provider.Settings.Secure;
import android.support.design.widget.Snackbar;
import android.telephony.TelephonyManager;
import android.text.InputFilter;
import android.text.Spanned;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.Calendar;
import java.util.regex.Pattern;

public class Utils {


    public static void setupTouchUI(View view, final Activity mActivity) {
        if (!(view instanceof EditText)) {
            view.setOnTouchListener(new View.OnTouchListener() {
                @SuppressLint("ClickableViewAccessibility")
                public boolean onTouch(View v, MotionEvent event) {
                    hideSoftKeyboard(mActivity);
                    return false;
                }
            });
        }
        if (view instanceof ViewGroup) {
            for (int i = 0; i < ((ViewGroup) view).getChildCount(); i++) {
                View innerView = ((ViewGroup) view).getChildAt(i);
                setupTouchUI(innerView, mActivity);
            }
        }
    }

    public static void openSoftKeyBoard(Activity activity) {
        InputMethodManager inputMethodManager = (InputMethodManager) activity.getSystemService(Context.INPUT_METHOD_SERVICE);
        if (inputMethodManager != null) {
            inputMethodManager.showSoftInput(activity.getCurrentFocus(), 0);
        }
    }

    public static void hideSoftKeyboard(Activity activity) {
        InputMethodManager inputMethodManager = (InputMethodManager) activity.getSystemService(Activity.INPUT_METHOD_SERVICE);
        if (null != activity.getCurrentFocus()) {
            inputMethodManager.hideSoftInputFromWindow(activity.getCurrentFocus().getWindowToken(), 0);
        }
    }

    public static void hideSoftKeyboardDialogDismiss(final Activity activity) {
        new Handler().postDelayed(new Runnable() {

            @Override
            public void run() {
                activity.runOnUiThread(new Runnable() {

                    @Override
                    public void run() {
                        hideSoftKeyboard(activity);
                    }
                });
            }
        }, 1);
    }

    public static boolean isEmailIdValid(String emailId) {
        boolean isValid = false;

        Pattern EMAIL_ADDRESS_PATTERN = Pattern.compile("[a-zA-Z0-9\\+\\.\\_\\%\\-\\+]{1,256}" + "\\@" + "[a-zA-Z0-9][a-zA-Z0-9\\-]{0,64}" + "(" + "\\." + "[a-zA-Z0-9][a-zA-Z0-9\\-]{0,25}" + ")+");
        if (EMAIL_ADDRESS_PATTERN.matcher(emailId).matches()) {
            isValid = true;
        }
        return isValid;
    }

    public static void showToast(final Activity activity, final String msg) {
        activity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(activity, msg, Toast.LENGTH_LONG).show();
            }
        });
    }

    public static String getIMEINo(Activity activity) {
        TelephonyManager telephonyManager = (TelephonyManager) activity.getSystemService(Context.TELEPHONY_SERVICE);
        String IMEI_NO = telephonyManager.getDeviceId();
        return IMEI_NO;
    }

    public static String getDeviceId(Activity activity) {
        String deviceID = Secure.getString(activity.getContentResolver(), Secure.ANDROID_ID);
        return deviceID;
    }


    public static boolean isAtleastOneAlphanumericValid(String character) {
        boolean isValid = false;
        Pattern Atlest_One_Alphanumaric = Pattern.compile("^(?=.*[a-zA-Z]).+$");
        if (Atlest_One_Alphanumaric.matcher(character).matches()) {
            isValid = true;
        }
        return isValid;
    }

    public static void printLog(String tag, Object msg) {

        Log.d("Wellness", tag + " " + msg);

    }

    public static boolean isPasswordValid(String character) {
        boolean isValid = false;

        if (character.length() >= 6) {
            isValid = true;
        }
        return isValid;
    }

    public static boolean isValidEmail(CharSequence target) {
        return target != null && android.util.Patterns.EMAIL_ADDRESS.matcher(target).matches();
    }

    public static void replaceFragmentWithoutAnimation(android.app.FragmentManager fragmentManager, Fragment fragment, String tag, boolean addTobackStack, int container) {

        // transaction
        android.app.FragmentTransaction ft = fragmentManager.beginTransaction();
        if (addTobackStack) {
            ft.addToBackStack(tag);
        }

        ft.replace(container, fragment, tag);
        ft.commit();
    }

    public static void replaceFragmentWithExecutePendingTransactions(android.app.FragmentManager fragmentManager, Fragment fragment, String tag, boolean addTobackStack, int container) {

        // transaction
        android.app.FragmentTransaction ft = fragmentManager.beginTransaction();
        if (addTobackStack) {
            ft.addToBackStack(tag);
        }

        ft.replace(container, fragment, tag);
        ft.commit();

    }

    public static void replaceFragment(android.app.FragmentManager fragmentManager, Fragment fragment, String tag, boolean addTobackStack, int container) {

        android.app.FragmentTransaction ft = fragmentManager.beginTransaction();
        // ft.setCustomAnimations(R.animator.enter, R.animator.exit, R.animator.pop_enter, R.animator.pop_exit);
        if (addTobackStack) {
            ft.addToBackStack(tag);
        }

        ft.replace(container, fragment, tag);
        ft.commit();
    }

    public static void replaceFragmentStateLoss(android.app.FragmentManager fragmentManager, Fragment fragment, String tag, boolean addTobackStack, int container) {

        android.app.FragmentTransaction ft = fragmentManager.beginTransaction();
        //ft.setCustomAnimations(R.animator.enter, R.animator.exit, R.animator.pop_enter, R.animator.pop_exit);
        if (addTobackStack) {
            ft.addToBackStack(tag);
        }

        ft.replace(container, fragment, tag);
        ft.commitAllowingStateLoss();
    }

    public static void replaceFragmentHraBackAnimation(android.app.FragmentManager fragmentManager, Fragment fragment, String tag, boolean addTobackStack, int container) {

        android.app.FragmentTransaction ft = fragmentManager.beginTransaction();
        //ft.setCustomAnimations(R.animator.pop_enter, R.animator.pop_exit, R.animator.enter, R.animator.exit);
        if (addTobackStack) {
            ft.addToBackStack(tag);
        }

        ft.replace(container, fragment, tag);
        ft.commit();
    }

    public static void replaceFragmentTopDown(android.app.FragmentManager fragmentManager, Fragment fragment, String tag, boolean addTobackStack, int container) {

        // transaction
        android.app.FragmentTransaction ft = fragmentManager.beginTransaction();
        // ft.setCustomAnimations(R.animator.down_up_enter, R.animator.down_up_exit, R.animator.up_down_enter, R.animator.up_down_exit);

        if (addTobackStack) {
            ft.addToBackStack(tag);
        }

        ft.replace(container, fragment, tag);
        ft.commit();
    }

    public static void addFragmentTopDown(android.app.FragmentManager fragmentManager, Fragment fragment, String tag, boolean addTobackStack, int container) {

        // transaction
        android.app.FragmentTransaction ft = fragmentManager.beginTransaction();
        //  ft.setCustomAnimations(R.animator.down_up_enter, R.animator.down_up_exit, R.animator.up_down_enter, R.animator.up_down_exit);

        if (addTobackStack) {
            ft.addToBackStack(tag);
        }

        ft.add(container, fragment, tag);
        ft.commit();
    }

    public static void replaceFragmentDownTop(android.app.FragmentManager fragmentManager, Fragment fragment, String tag, boolean addTobackStack, int container) {

        // transaction
        android.app.FragmentTransaction ft = fragmentManager.beginTransaction();
        //  ft.setCustomAnimations(R.animator.up_down_enter, R.animator.up_down_exit, R.animator.down_up_enter, R.animator.down_up_exit);

        if (addTobackStack) {
            ft.addToBackStack(tag);
        }

        ft.replace(container, fragment, tag);
        ft.commit();
    }

    public static String convertTwoDecimalPoint(double value) {

        NumberFormat nf = new DecimalFormat("#.##");

        String res = nf.format(value);

        return res;
    }

    public static String convertNumberWithCommas(String number) {
        try {
            return NumberFormat.getIntegerInstance().format(Integer.valueOf(number));
        } catch (Exception e) {
            e.printStackTrace();
            return number;
        }

    }

    public static void showSnackBarMessage(View view, String msg) {
        Snackbar snackbar = Snackbar.make(view, msg, Snackbar.LENGTH_LONG);

        View sbView = snackbar.getView();
        FrameLayout.LayoutParams params = (FrameLayout.LayoutParams) sbView.getLayoutParams();
        params.bottomMargin = 10;
        sbView.setBackgroundColor(Color.DKGRAY);
        TextView textView = sbView.findViewById(android.support.design.R.id.snackbar_text);
        textView.setTextColor(Color.WHITE);
        textView.setTextSize(20);
        snackbar.show();
    }

    /**
     * Returns a proportion (n out of a total) as a percentage, in a float.
     */
    public static double getPercentage(float n, float total) {
        if (n == 0 || total == 0) {
            return 0.0;
        }
        try {
            float proportion = n / total;
            BigDecimal bigDecimal = new BigDecimal(proportion * 100);
            bigDecimal = bigDecimal.setScale(1, RoundingMode.HALF_UP);
            return bigDecimal.doubleValue();
        } catch (ArithmeticException e) {
            e.printStackTrace();
            return 0.0;
        }

    }

    /*
    * find the age from the dob and current date
    * */
    public static String getAgeForReport(String date) {
        String[] dob = date.split("/");
        int day = Integer.parseInt(dob[0]);
        int month = Integer.parseInt(dob[1]);
        int year = Integer.parseInt(dob[2]);
        return getAgeForReport(year, month, day);
    }

    private static String getAgeForReport(int year, int month, int day) {
        Calendar dob = Calendar.getInstance();
        Calendar today = Calendar.getInstance();
        dob.set(year, month, day);
        int age = today.get(Calendar.YEAR) - dob.get(Calendar.YEAR);
        /*
         * if (today.get(Calendar.DAY_OF_YEAR) < dob.get(Calendar.DAY_OF_YEAR))
		 * { age--; }
		 */
        if (age < 0) {
            age = 0;
        }
        String ageS = String.valueOf(age);
        return ageS;
    }

    public static String numberFormatter(int digit, double value) {
        NumberFormat formatter;
        if (digit == 1) {
            formatter = new DecimalFormat("#0.0");
        } else if (digit == 2) {
            formatter = new DecimalFormat("#0.00");
        } else if (digit == 3) {
            formatter = new DecimalFormat("#0.000");
        } else {
            formatter = new DecimalFormat("#0.0000");
        }

        return formatter.format(value);
    }

    public static String doubleToString(double value) {
        try {
            DecimalFormat format = new DecimalFormat("0.##");
            return format.format(value);
        } catch (Exception e) {
            e.printStackTrace();
            return String.valueOf(value);
        }
    }


}


