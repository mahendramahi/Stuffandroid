package com.truworth.wellnesscorner.repo.model.response;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.truworth.wellnesscorner.model.TodayMyChallenge;

import java.util.List;

public class TodayMyChallengesResponse {

    @SerializedName("hasError")
    @Expose
    private boolean hasError;

    @SerializedName("error")
    @Expose
    private Error error;
    @SerializedName("data")
    @Expose
    private List<TodayMyChallenge> data;

    public boolean isHasError() {
        return hasError;
    }

    public void setHasError(boolean hasError) {
        this.hasError = hasError;
    }

    public Error getError() {
        return error;
    }

    public void setError(Error error) {
        this.error = error;
    }

    public List<TodayMyChallenge> getData() {
        return data;
    }

    public void setData(List<TodayMyChallenge> data) {
        this.data = data;
    }


}
