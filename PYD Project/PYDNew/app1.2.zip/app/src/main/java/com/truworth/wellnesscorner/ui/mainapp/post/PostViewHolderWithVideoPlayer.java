package com.truworth.wellnesscorner.ui.mainapp.post;

import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.RecyclerView;
import android.util.SparseArray;
import android.view.View;

import com.truworth.wellnesscorner.databinding.RowPostContainerBinding;
import com.truworth.wellnesscorner.model.Post;
import com.truworth.wellnesscorner.model.PostMediaList;
import com.truworth.wellnesscorner.utils.pageindicator.OverflowPagerIndicator;
import com.truworth.wellnesscorner.utils.pageindicator.SimpleSnapHelper;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import im.ene.toro.PlayerSelector;
import im.ene.toro.ToroPlayer;
import im.ene.toro.ToroUtil;
import im.ene.toro.exoplayer.ExoPlayerViewHelper;
import im.ene.toro.media.PlaybackInfo;
import im.ene.toro.widget.Container;

public class PostViewHolderWithVideoPlayer extends RecyclerView.ViewHolder implements ToroPlayer {
    //RowContentTypeMediaBinding mVideoBinding;
    RowPostContainerBinding mRowContainerBinding;
    private static final String TAG = "TimelineVideoViewHolder";
    static final int RQ_PLAYBACK_INFO = 100;
    @Nullable
    ExoPlayerViewHelper helper;

    Container container;
    OverflowPagerIndicator overflowPagerIndicator;
    private SimpleSnapHelper snapHelper;// = new PagerSnapHelper();
    private int initPosition = -1;

    PostViewHolderWithVideoPlayer(RowPostContainerBinding binding) {
        super(binding.getRoot());
        this.mRowContainerBinding = binding;
        //this.mVideoBinding = mediaBinding;
        container = mRowContainerBinding.containerHorizontal;
        overflowPagerIndicator = mRowContainerBinding.viewPagerIndicator;
        snapHelper = new SimpleSnapHelper(overflowPagerIndicator);
    }

    public RowPostContainerBinding getBinding() {
        return mRowContainerBinding;
    }

    void onDetached() {
        snapHelper.attachToRecyclerView(null);
    }

    void onAttached() {
        snapHelper.attachToRecyclerView(container);
    }


    void bind(Post post) {

        PostViewModel viewModel = new PostViewModel(post, getAdapterPosition());
        mRowContainerBinding.setViewModel(viewModel);
        viewModel.getHifiValue();
        viewModel.getCommentValue();
        mRowContainerBinding.imgFullView.setVisibility(View.GONE);
        mRowContainerBinding.containerMedia.setVisibility(View.VISIBLE);
        List<PostMediaList> mediaDataList = new ArrayList<>();
        for (int i = 0; i < post.getPostMediaList().size(); i++) {
            PostMediaList postMediaList = post.getPostMediaList().get(i);
            if (postMediaList.getPostMediaType() == PostConstants.MEDIA_TYPE_IMAGE || postMediaList.getPostMediaType() == PostConstants.MEDIA_TYPE_VIDEO) {
                mediaDataList.add(postMediaList);
            }
        }

        MediaFileRecyclerAdapter adapter = new MediaFileRecyclerAdapter(mediaDataList, new MediaFileRecyclerAdapter.ItemClickListener() {
            @Override
            void onItemClick(View view, int position, Uri media, PlaybackInfo playbackInfo) {
            }
        });
        container.setAdapter(adapter);
        overflowPagerIndicator.attachToRecyclerView(container);
        //new SimpleSnapHelper(overflowPagerIndicator).attachToRecyclerView(container);

        mRowContainerBinding.executePendingBindings();
        //  mVideoBinding.executePendingBindings();
    }


    @NonNull
    @Override
    public View getPlayerView() {
        return this.container;
    }


    @NonNull
    @Override
    public PlaybackInfo getCurrentPlaybackInfo() {
        Collection<Integer> cached = container.getSavedPlayerOrders();
        if (cached.isEmpty()) {
            return new PlaybackInfo();
        } else {
            SparseArray<PlaybackInfo> actualInfos = new SparseArray<>();
            ExtraPlaybackInfo resultInfo = new ExtraPlaybackInfo(actualInfos);

            List<ToroPlayer> activePlayers = container.filterBy(Container.Filter.PLAYING);
            for (ToroPlayer player : activePlayers) {
                actualInfos.put(player.getPlayerOrder(), player.getCurrentPlaybackInfo());
                cached.remove(player.getPlayerOrder());
            }

            for (Integer order : cached) {
                actualInfos.put(order, container.getPlaybackInfo(order));
            }

            if (activePlayers.size() >= 1) {
                resultInfo.setResumeWindow(activePlayers.get(0).getPlayerOrder());
            }

            return resultInfo;
        }
    }

    @Override
    public void initialize(@NonNull Container container, @Nullable PlaybackInfo playbackInfo) {
        this.initPosition = -1;
        if (playbackInfo != null && playbackInfo instanceof ExtraPlaybackInfo) {
            //noinspection unchecked
            SparseArray<PlaybackInfo> cache = ((ExtraPlaybackInfo) playbackInfo).actualInfo;
            if (cache != null) {
                for (int i = 0; i < cache.size(); i++) {
                    int key = cache.keyAt(i);
                    this.container.savePlaybackInfo(key, cache.get(key));
                }
            }
            this.initPosition = playbackInfo.getResumeWindow();
        }
        this.container.setPlayerSelector(PlayerSelector.NONE);
    }


    @Override
    public void play() {
        if (initPosition >= 0) this.container.scrollToPosition(initPosition);
        initPosition = -1;
        this.container.setPlayerSelector(PlayerSelector.DEFAULT);
    }


    @Override
    public void pause() {
        this.container.setPlayerSelector(PlayerSelector.NONE);
    }

    @Override
    public boolean isPlaying() {
        return this.container.filterBy(Container.Filter.PLAYING).size() > 0;
    }

    @Override
    public void release() {
        // release here
        List<ToroPlayer> managed = this.container.filterBy(Container.Filter.MANAGING);
        for (ToroPlayer player : managed) {
            if (player.isPlaying()) {
                this.container.savePlaybackInfo(player.getPlayerOrder(), player.getCurrentPlaybackInfo());
                player.pause();
            }
            player.release();
        }
        this.container.setPlayerSelector(PlayerSelector.NONE);
    }

    @Override
    public boolean wantsToPlay() {
        return ToroUtil.visibleAreaOffset(this, itemView.getParent()) >= 0.85;
    }

    @Override
    public void onSettled(Container container) {
        // Do nothing
    }

    @Override
    public int getPlayerOrder() {
        return getAdapterPosition();
    }

//    static class StateManager implements CacheManager {
//
//        final MediaList mediaList;
//
//        StateManager(MediaList mediaList) {
//            this.mediaList = mediaList;
//        }
//
//        @NonNull @Override public Object getKeyForOrder(int order) {
//            return this.mediaList.get(order);
//        }
//
//        @Nullable @Override public Integer getOrderForKey(@NonNull Object key) {
//            return key instanceof Content.Media ? this.mediaList.indexOf(key) : null;
//        }
//    }
}
