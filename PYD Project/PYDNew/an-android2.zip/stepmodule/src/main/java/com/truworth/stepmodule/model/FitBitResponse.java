package com.truworth.stepmodule.model;

import com.google.gson.annotations.SerializedName;

import java.util.List;

/**
 Created by PalakC on 7/6/2016.
 */
public class FitBitResponse {


    @SerializedName("activities-steps")
    private List<FitBitStepsItem> activitiesSteps;

    @SerializedName("activities-activityCalories")
    private List<FitBitStepsItem> activitiesCalories;

    private boolean success;
    private List<ErrorsBean> errors;

    public List<FitBitStepsItem> getActivitiesSteps() {
        return activitiesSteps;
    }

    public void setActivitiesSteps(List<FitBitStepsItem> activitiesSteps) {
        this.activitiesSteps = activitiesSteps;
    }

    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public List<ErrorsBean> getErrors() {
        return errors;
    }

    public void setErrors(List<ErrorsBean> errors) {
        this.errors = errors;
    }

    public List<FitBitStepsItem> getActivitiesCalories() {
        return activitiesCalories;
    }

    public void setActivitiesCalories(List<FitBitStepsItem> activitiesCalories) {
        this.activitiesCalories = activitiesCalories;
    }


    public static class ErrorsBean {
        private String errorType;
        private String message;

        public String getErrorType() {
            return errorType;
        }

        public void setErrorType(String errorType) {
            this.errorType = errorType;
        }

        public String getMessage() {
            return message;
        }

        public void setMessage(String message) {
            this.message = message;
        }
    }

}

