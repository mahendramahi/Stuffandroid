package com.twc.dailylog.adapter;

/**
 * Created by GurvinderS on 12/27/2017.
 */


import android.app.Activity;
import android.graphics.drawable.AnimationDrawable;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;


import com.twc.dailylog.R;
import com.twc.dailylog.fragments.WaterTrackerFragmentNew;
import com.twc.dailylog.model.beans.WaterBean;
import com.twc.dailylog.utils.Constant;

import java.util.ArrayList;
import java.util.List;


public class WaterIntakeAdapter extends RecyclerView.Adapter<WaterIntakeAdapter.AlbumViewHolder> {
    private List<WaterBean> waterIntakeList;
    private String mContainerType;
    private WaterTrackerFragmentNew twCliteDashboardFragment;
    boolean isAction=false;

    public WaterIntakeAdapter(WaterTrackerFragmentNew twCliteDashboardFragment, List<WaterBean> list, String containerType) {
        this.twCliteDashboardFragment = twCliteDashboardFragment;
        this.waterIntakeList = list;
        this.mContainerType = containerType;

    }

    @Override
    public AlbumViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_water_intake, parent, false);
        return new AlbumViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(final AlbumViewHolder holder, int position) {

        //  container is not filled nd user is adding more and then apply animate nd fill
        if (!waterIntakeList.get(position).isFill() && waterIntakeList.get(position).isAdd()) {

            holder.rlContainer.setBackgroundResource(mContainerType.equalsIgnoreCase(Constant.GLASS) ? R.drawable.animation_glass : R.drawable.animation_bottle);
            final AnimationDrawable loadingAnimation = (AnimationDrawable) holder.rlContainer.getBackground();
            holder.rlContainer.addOnAttachStateChangeListener(new View.OnAttachStateChangeListener() {
                @Override
                public void onViewAttachedToWindow(View v) {
                    loadingAnimation.stop();
                    loadingAnimation.start();
                }

                @Override
                public void onViewDetachedFromWindow(View v) {
                }
            });
            waterIntakeList.get(position).setFill(true);

        }
        //  container is  already filled nd user is removing then apply reverse animate nd unfill
        else if (waterIntakeList.get(position).isFill() && !waterIntakeList.get(position).isAdd()) {
            holder.rlContainer.setBackgroundResource(mContainerType.equalsIgnoreCase(Constant.GLASS) ? R.drawable.animation_reverse_glass : R.drawable.animation_reverse_bottle);
            final AnimationDrawable frameAnimationRev = (AnimationDrawable) holder.rlContainer.getBackground();
            holder.rlContainer.addOnAttachStateChangeListener(new View.OnAttachStateChangeListener() {
                @Override
                public void onViewAttachedToWindow(View v) {
                    frameAnimationRev.stop();
                    frameAnimationRev.start();
                }

                public void onViewDetachedFromWindow(View v) {
                }
            });
            waterIntakeList.get(position).setFill(false);


        }

        // if container is already filled nd no action
        else if (waterIntakeList.get(position).isFill()) {
            holder.rlContainer.setBackgroundResource(mContainerType.equalsIgnoreCase(Constant.GLASS) ? R.drawable.ic_glass_frame_046 : R.drawable.ic_bottle_frame_046);
        }

        // if container is not filled nd no action
        else {
            holder.rlContainer.setBackgroundResource(mContainerType.equalsIgnoreCase(Constant.GLASS) ? R.drawable.ic_glass_frame_000 : R.drawable.ic_bottle_frame_000);
        }

        // Condition for whether show or not plus icon on specific position
        holder.ivPlus.setImageResource(waterIntakeList.get(position).isShowAddIcon() ? R.drawable.ic_plus_water_tracker : 0);

        // Condition for update water intake value
        if (isAction && position == waterIntakeList.size() - 1) {

            twCliteDashboardFragment.updateCount(waterIntakeList, true);
        }

    }


    @Override
    public int getItemCount() {
        return waterIntakeList.size();
    }


    class AlbumViewHolder extends RecyclerView.ViewHolder {

        RelativeLayout rlContainer;
        ImageView ivPlus;

        AlbumViewHolder(final View view) {
            super(view);

            rlContainer = view.findViewById(R.id.rlContainer);
            ivPlus = view.findViewById(R.id.ivPlus);

            rlContainer.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    isAction=true;
                    // Condition for adding more container
                    if (getAdapterPosition() == waterIntakeList.size() - 1) {
                        WaterBean bean = new WaterBean();
                        bean.setShowAddIcon(true);
                        waterIntakeList.add(bean);
                    }
                    // end

                    // Condition for filling up nd  down container

                    if (!waterIntakeList.get(getAdapterPosition()).isFill()) {
                        for (int i = 0; i <= getAdapterPosition(); i++) {
                            waterIntakeList.get(i).setAdd(true);
                            waterIntakeList.get(i).setShowAddIcon(false);
                        }

                        waterIntakeList.get(getAdapterPosition() + 1).setShowAddIcon(true);
                        notifyDataSetChanged();
                    } else {
                        for (int i = waterIntakeList.size() - 1; i >= getAdapterPosition(); i--) {
                            waterIntakeList.get(i).setAdd(false);
                            waterIntakeList.get(i).setShowAddIcon(false);

                            int defaultSize;
                            if (mContainerType.equalsIgnoreCase(Constant.GLASS)) {
                                defaultSize = Constant.DEFAULT_SIZE_GLASS;
                            } else {
                                defaultSize = Constant.DEFAULT_SIZE_BOTTLE;
                            }
                            if (i != getAdapterPosition() && waterIntakeList.size() > defaultSize) {
                                waterIntakeList.remove(i);
                                //notifyItemRemoved(i);
                            }
                        }
                        waterIntakeList.get(getAdapterPosition()).setShowAddIcon(true);
                        notifyDataSetChanged();
                        notifyItemRangeChanged(0, waterIntakeList.size());
                    }


                    // end
                }
            });

        }
    }


    public void setContainerType(String type) {
        mContainerType = type;

    }

    public List<WaterBean> getFilledItemList() {
        ArrayList<WaterBean> newList = new ArrayList<>();
        for (WaterBean bean : waterIntakeList) {
            if (bean.isFill())
                newList.add(bean);
        }
        return newList;
    }

    public void setList(List<WaterBean> list) {
        this.waterIntakeList = list;
    }

}
