package com.truworth.wellnesscorner.model;

public class ChallengeLeaderboardBean {
    private String identity;
    private String name;
    private String image;
    private int points;
    private int rank;
    private int rankPrevious;


    public String getIdentity() {
        return identity;
    }

    public void setIdentity(String identity) {
        this.identity = identity;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public int getPoints() {
        return points;
    }

    public void setPoints(int points) {
        this.points = points;
    }

    public int getRank() {
        return rank;
    }

    public void setRank(int rank) {
        this.rank = rank;
    }

    public int getRankPrevious() {
        return rankPrevious;
    }

    public void setRankPrevious(int rankPrevious) {
        this.rankPrevious = rankPrevious;
    }
}
