package com.truworth.wellnesscorner.ui.registration.registrationstepfirst;

import android.databinding.ObservableBoolean;
import android.databinding.ObservableField;
import android.text.Editable;
import android.text.InputFilter;
import android.text.Spanned;
import android.text.TextWatcher;

import com.truworth.wellnesscorner.TheWellnessCornerApp;
import com.truworth.wellnesscorner.base.BaseViewModel;
import com.truworth.wellnesscorner.data.SharedPreferenceHelper;
import com.truworth.wellnesscorner.model.LoginData;
import com.truworth.wellnesscorner.repo.LoginRepository;
import com.truworth.wellnesscorner.repo.model.request.SaveMemberRequest;
import com.truworth.wellnesscorner.repo.model.response.SaveMemberResponse;
import com.truworth.wellnesscorner.utils.PasswordValidUtils;
import com.truworth.wellnesscorner.utils.RSAHelper;
import com.truworth.wellnesscorner.utils.SingleLiveEvent;

import javax.inject.Inject;

import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;

/**
 * Created by rajeshs on 4/3/2018.
 */

public class CreatePasswordViewModel extends BaseViewModel {


    public ObservableField<String> password = new ObservableField<>();
    public ObservableField<String> confirmPassword = new ObservableField<>();
    public ObservableBoolean isLengthMatch = new ObservableBoolean();
    public ObservableBoolean isDigitExist = new ObservableBoolean();
    public ObservableBoolean isAlphaExist = new ObservableBoolean();
    public ObservableBoolean isSpecialCharExist = new ObservableBoolean();
    public ObservableBoolean isEnableContinue = new ObservableBoolean();
    public ObservableField<String> errorMessage = new ObservableField<>();
    @Inject
    LoginRepository repository;
    @Inject
    SharedPreferenceHelper prefManager;
    SaveMemberRequest member;

    private SingleLiveEvent<Void> moveToConfirmPassWord = new SingleLiveEvent<>();
    private SingleLiveEvent<Void> moveToMobileNumber = new SingleLiveEvent<>();

    public CreatePasswordViewModel() {
        TheWellnessCornerApp.getApp().component().inject(this);
    }

    public SingleLiveEvent<Void> getMoveToConfirmPassWord() {
        return moveToConfirmPassWord;
    }

    public SingleLiveEvent<Void> getMoveToMobileNumber() {
        return moveToMobileNumber;
    }

    public void openMobileNumber() {
        moveToMobileNumber.call();
    }

    public void setMemberData(SaveMemberRequest mMemberRequest) {
        this.member = mMemberRequest;
        this.password.set(member.getPassword().trim());
    }

    public TextWatcher passwordWatcher() {
        return new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                password.set(charSequence.toString());
                isLengthMatch.set(PasswordValidUtils.isLengthMatches(password.get().trim()));
                isAlphaExist.set(PasswordValidUtils.isContainsLetters(password.get().trim()));
                isDigitExist.set(PasswordValidUtils.isContainsDigit(password.get().trim()));
                isSpecialCharExist.set(PasswordValidUtils.isContainsSpecialCharacter(password.get().trim()));

                if (isSpecialCharExist.get() && isDigitExist.get() && isAlphaExist.get() && isLengthMatch.get()) {
                    isEnableContinue.set(true);
                } else {
                    isEnableContinue.set(false);
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        };
    }

    public TextWatcher confirmPasswordWatcher() {
        return new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {


            }

            @Override
            public void afterTextChanged(Editable editable) {
                if (password.get().trim().equals(confirmPassword.get().trim())) {
                    isEnableContinue.set(true);
                } else {
                    isEnableContinue.set(false);
                }
            }
        };
    }


    public void saveMember() {
        String email = RSAHelper.Encrypt(member.getEmail());
        SaveMemberRequest request = new SaveMemberRequest();
        request.setPassword(RSAHelper.Encrypt(confirmPassword.get()));
        request.setEmail(email);
        request.setFirstName(member.getFirstName());
        request.setLastName(member.getLastName());
        request.setDateOfBirth(member.getDateOfBirth());
        request.setGender(member.getGender());

        repository.saveMember(request).subscribe(new Observer<SaveMemberResponse>() {

            @Override
            public void onSubscribe(Disposable d) {

            }


            @Override
            public void onNext(SaveMemberResponse saveMemberResponse) {
                if (!saveMemberResponse.isHasError()) {
                    LoginData data = saveMemberResponse.getData();
                    prefManager.saveUserData(data.getFirstName(), data.getLastName(), data.getScreenName(), data.getEmail(), data.getImage(), data.getProfileStep());
                    prefManager.saveTokenData(data.getToken().getValidTo(), data.getToken().getValue());
                    openMobileNumber();
                } else {
                    errorMessage.set(saveMemberResponse.getError().getMessage());
                }
            }


            @Override
            public void onError(Throwable e) {

            }


            @Override
            public void onComplete() {

            }
        });
    }

    public void OnOpenConfirmPassword() {
        moveToConfirmPassWord.call();
    }

}
