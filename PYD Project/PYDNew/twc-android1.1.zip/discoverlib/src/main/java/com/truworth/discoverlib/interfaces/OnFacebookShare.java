package com.truworth.discoverlib.interfaces;

/**
 * If this code works it was written by Somesh Kumar on 18 March, 2017. If not, I don't know who wrote it.
 */
public interface OnFacebookShare {

    void onShareSuccess(int itemId, String postId);

    void onShareError(String error);
}
