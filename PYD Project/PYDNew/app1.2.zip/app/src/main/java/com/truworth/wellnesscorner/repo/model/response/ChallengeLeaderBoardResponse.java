package com.truworth.wellnesscorner.repo.model.response;

import com.truworth.wellnesscorner.model.ChallengeLeaderboardBean;

import java.util.List;

public class ChallengeLeaderBoardResponse {

    private DataBean data;
    private boolean hasError;
    private Object error;

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public boolean isHasError() {
        return hasError;
    }

    public void setHasError(boolean hasError) {
        this.hasError = hasError;
    }

    public Object getError() {
        return error;
    }

    public void setError(Object error) {
        this.error = error;
    }

    public static class DataBean {
        private List<ChallengeLeaderboardBean> challengeLeaderboard;

        public List<ChallengeLeaderboardBean> getChallengeLeaderboard() {
            return challengeLeaderboard;
        }

        public void setChallengeLeaderboard(List<ChallengeLeaderboardBean> challengeLeaderboard) {
            this.challengeLeaderboard = challengeLeaderboard;
        }
    }
}
