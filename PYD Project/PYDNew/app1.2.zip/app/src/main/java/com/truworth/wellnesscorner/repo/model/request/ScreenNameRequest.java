package com.truworth.wellnesscorner.repo.model.request;

/**
 * Created by GurvinderS on 4/11/2018.
 */

public class ScreenNameRequest {
    public String getScreenName() {
        return ScreenName;
    }

    public void setScreenName(String screenName) {
        ScreenName = screenName;
    }

    public String ScreenName;
}
