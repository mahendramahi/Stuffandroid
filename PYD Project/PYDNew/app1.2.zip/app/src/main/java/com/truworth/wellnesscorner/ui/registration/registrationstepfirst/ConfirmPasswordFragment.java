package com.truworth.wellnesscorner.ui.registration.registrationstepfirst;

import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.text.InputFilter;
import android.text.Spanned;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

import com.truworth.wellnesscorner.BR;
import com.truworth.wellnesscorner.R;
import com.truworth.wellnesscorner.base.BaseFragment;
import com.truworth.wellnesscorner.databinding.FragmentRegistrationConfirmPasswordBinding;
import com.truworth.wellnesscorner.repo.model.request.SaveMemberRequest;
import com.truworth.wellnesscorner.ui.mobileverification.LoginWithMobileNumberFragment;
import com.truworth.wellnesscorner.ui.mobileverification.MobileNumberRedirectionType;
import com.truworth.wellnesscorner.utils.FragmentUtils;

public class ConfirmPasswordFragment extends BaseFragment<FragmentRegistrationConfirmPasswordBinding, CreatePasswordViewModel> {
    public static final String TAG = "ConfirmPasswordFragment";

    private static final String ARG_PARAM1 = "param1";
    private SaveMemberRequest memberRequest;


    CreatePasswordViewModel viewModel;

    public ConfirmPasswordFragment() {
        // Required empty public constructor
    }


    public static ConfirmPasswordFragment newInstance(SaveMemberRequest mMemberRequest) {
        ConfirmPasswordFragment fragment = new ConfirmPasswordFragment();
        Bundle args = new Bundle();
        args.putSerializable(ARG_PARAM1, mMemberRequest);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setKeyboardHideOnTapOutSide(false);
        if (getArguments() != null) {
            memberRequest = (SaveMemberRequest) getArguments().getSerializable(ARG_PARAM1);
        }
    }


    private void setUpSubscribeToNavigate() {
        viewModel.getMoveToMobileNumber().observe(this, new Observer<Void>() {
            @Override
            public void onChanged(@Nullable Void aVoid) {
                hideKeyboard();
                moveToMobileNumberFragment();
            }
        });
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        getViewDataBinding().etConfirmPassword.requestFocus();
        getViewDataBinding().etConfirmPassword.setFilters(new InputFilter[]{filter,new InputFilter.LengthFilter(20)});
        showKeyboard();
        viewModel.setMemberData(memberRequest);
        setUpSubscribeToNavigate();
    }
    InputFilter filter = new InputFilter() {
        @Override
        public CharSequence filter(CharSequence source, int start, int end, Spanned dest, int dstart, int dend) {
            for (int i = start; i < end; i++) {
                int type = Character.getType(source.charAt(i));
                if (type == Character.SURROGATE || type == Character.OTHER_SYMBOL) {
                    return "";
                }
                if (Character.isSpaceChar(source.charAt(i)) || Character.isWhitespace(source.charAt(i))) {
                    return "";
                }
            }
            return null;
        }
    };

    /**
     * Override for set binding variable
     *
     * @return variable id
     */
    @Override
    public int getBindingVariable() {
        return BR.viewModel;
    }

    /**
     * @return layout resource id
     */
    @Override
    public int getLayoutId() {
        return R.layout.fragment_registration_confirm_password;
    }

    /**
     * Override for set view model
     *
     * @return view model instance
     */
    @Override
    public CreatePasswordViewModel getViewModel() {
        viewModel = ViewModelProviders.of(this).get(CreatePasswordViewModel.class);

        return viewModel;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

    }

    @Override
    public void onDetach() {
        super.onDetach();

    }


    public void moveToMobileNumberFragment() {
       //previous steps fragments removed from stack
        FragmentUtils.removeAllFragmentFromStack((AppCompatActivity) getActivity());
        getActivity().getSupportFragmentManager()
                .beginTransaction()
                .add(R.id.registerContainer, LoginWithMobileNumberFragment.newInstance(memberRequest.getEmail(), MobileNumberRedirectionType.FROM_REGISTRATION), LoginWithMobileNumberFragment.TAG).addToBackStack(LoginWithMobileNumberFragment.TAG)
                .commit();
    }
}
