package com.twc.hramodule.fragments;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;


import com.twc.greendaolib.GreenDaoApp;
import com.twc.greendaolib.HraDBItem;
import com.twc.greendaolib.HraDBItemDao;
import com.twc.hramodule.HraActivity;
import com.twc.hramodule.R;
import com.twc.hramodule.R2;
import com.twc.hramodule.interfaces.OnHraDbAction;
import com.twc.hramodule.utils.Utils;

import java.util.Arrays;
import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;
import butterknife.OnItemSelected;

/**
 * Created by GurvinderS on 10/13/2016.
 */
public class HraQ4Fragment extends BaseFragment {
    private static final long QUESTION_ID_4 = 4;
    private static final long QUESTION_ID_5 = 5;
    private static final long QUESTION_ID_6 = 6;
    private static final long QUESTION_ID_7 = 7;
    private static final long QUESTION_ID_8 = 8;


    private static final String SCREEN_NO = "4";

    @BindView(R2.id.edSystolic)
    EditText edSystolic;

    @BindView(R2.id.edDiastolic)
    EditText edDiastolic;

    @BindView(R2.id.cbBp)
    CheckBox cbBp;

    @BindView(R2.id.edBloodGlucose)
    EditText edBloodGlucose;

    @BindView(R2.id.cbBg)
    CheckBox cbBg;

    @BindView(R2.id.rootView)
    RelativeLayout rootLayout;


    @BindView(R2.id.edTotalCholesterol)
    EditText edTotalCholesterol;

    @BindView(R2.id.cbTotalCholesterol)
    CheckBox cbTotalCholesterol;

    @BindView(R2.id.edThyroid)
    EditText edThyroid;

    @BindView(R2.id.cbThyroid)
    CheckBox cbThyroid;

    @BindView(R2.id.edWaistSize)
    EditText edWaistSize;

    //   @BindView(R2.id.cbWaistSize)
    // CheckBox cbWaistSize;
    @BindView(R2.id.tvQuestionTitle)
    TextView tvQuestionTitle;

    @BindView(R2.id.tvQuestionNo)
    TextView tvQuestionNo;

    @BindView(R2.id.tvQuestionType)
    TextView tvQuestionType;
    @BindView(R2.id.spReadingType)
    Spinner spReadingType;
    @BindView(R2.id.btnNextQuestion)
    Button btnNextQuestion;
    @BindView(R2.id.ivHRABack)
    ImageView ivHRABack;

    @BindView(R2.id.ivCancelHRA)
    ImageView ivCancelHRA;
    private int readingTypePosition = 0;
    //    private String selectReadingOption;
    private OnHraDbAction onHraDbAction;
    private String answer1stQuestion;

    public static HraQ4Fragment newInstance(Bundle bundle) {
        HraQ4Fragment fragment = new HraQ4Fragment();
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    public int getFragmentLayout() {
        return R.layout.fragment_hra_type4;
    }

    @Override
    public void onFragmentReady() {
        tvQuestionType.setText("HEALTH");
        tvQuestionNo.setText("04");
        tvQuestionTitle.setText("Now time to talk in numbers \n Do you know your readings ?");

        String[] bgArray = getResources().getStringArray(R.array.row_bg_type);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(getActivity(), R.layout.spinner_item, bgArray);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spReadingType.setAdapter(adapter);

        // get previous selected answer from database


        getAnswerOf1stQuestion();

        getPreviousSelectedAnswer();

        // selectReadingOption= bgArray[0];
    }

    private void getAnswerOf1stQuestion() {

        HraDBItemDao hraDBDao = GreenDaoApp.getInstance(getActivity()).getDaoSession(getActivity()).getHraDBItemDao();
        List<HraDBItem> answerFromDb = hraDBDao.queryBuilder().where(HraDBItemDao.Properties.QuestionId.eq("1")).list();
        for (HraDBItem hraDBItem : answerFromDb) {
            answer1stQuestion = hraDBItem.getAnswer();
        }


    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        onHraDbAction = (OnHraDbAction) context;
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        onHraDbAction = (OnHraDbAction) activity;
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        view.setFocusableInTouchMode(true);
        view.requestFocus();
        view.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (keyCode == KeyEvent.KEYCODE_BACK && event.getAction() == KeyEvent.ACTION_DOWN) {
                    onBack();
                    return true;
                }
                return false;
            }
        });
    }



    @OnItemSelected(R2.id.spReadingType)
    public void spinnerItemSelect() {
        spReadingType.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                readingTypePosition = position;
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
    }

    @OnClick({R2.id.btnNextQuestion, R2.id.ivCancelHRA, R2.id.ivHRABack, R2.id.rootView})
    public void onClick(View view) {
        int i = view.getId();
        if (i == R.id.ivHRABack) {
            onBack();

        } else if (i == R.id.rootView) {
            Utils.setupTouchUI(rootLayout, getActivity());

        } else if (i == R.id.ivCancelHRA) {
            cancelHra();

        } else if (i == R.id.btnNextQuestion) {
            int isSureBp = 0;
            int isSureBg = 0;
            int isSureTotalCholesterol = 0;
            int isSureThyroid = 0;
            int isWaistSize = 0;


            String systolicValue = edSystolic.getText().toString();

            String diastolicValue = edDiastolic.getText().toString();
            String bloodGlucoseValue = edBloodGlucose.getText().toString();
            String totalCholesterolValue = edTotalCholesterol.getText().toString();
            String thyroidValue = edThyroid.getText().toString();
            String WaistSizeValue = edWaistSize.getText().toString();
            String[] arr = answer1stQuestion.split("/");


            if (cbBp.isChecked()) {
                isSureBp = 1;
                if (Arrays.asList(arr).contains("1") && (systolicValue.isEmpty() || diastolicValue.isEmpty())) {


                    Utils.showToast(getActivity(), getString(R.string.pls_enter_tc_and_bp_as_mentioned));
                    return;

                }

                if (!systolicValue.isEmpty() && diastolicValue.isEmpty()) {
                    Utils.showToast(getActivity(), getString(R.string.pls_enter_bp));
                    return;

                }
                if (!diastolicValue.isEmpty() && systolicValue.isEmpty()) {

                    Utils.showToast(getActivity(), getString(R.string.pls_enter_bp));
                    return;
                }


            } else if (systolicValue.isEmpty() || diastolicValue.isEmpty()) {
                Utils.showToast(getActivity(), getString(R.string.pls_enter_bp));
                return;
            }

            if (!systolicValue.isEmpty() && Integer.parseInt(systolicValue) == 0) {
                Utils.showToast(getActivity(), "Please enter systolic reading");
                return;
            }
            if (!diastolicValue.isEmpty() && Integer.parseInt(diastolicValue) == 0) {
                Utils.showToast(getActivity(), "Please enter diastolic reading");
                return;
            }


            if (cbBg.isChecked()) {
                isSureBg = 1;

                if (Arrays.asList(arr).contains("3") && (bloodGlucoseValue.isEmpty() || readingTypePosition == 0)) {
                    Utils.showToast(getActivity(), getString(R.string.pls_enter_bg_as_mentioned));
                    // DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.pls_enter_bg_as_mentioned), getString(R.string.str_ok), false);
                    return;


                }

            } else if (bloodGlucoseValue.isEmpty()) {
                Utils.showToast(getActivity(), getString(R.string.pls_enter_bg));
                return;
            } else if (readingTypePosition == 0) {
                Utils.showToast(getActivity(), getString(R.string.pls_select_reading_type));
                return;
            }
            if (!bloodGlucoseValue.isEmpty() && Double.parseDouble(bloodGlucoseValue) == 0) {
                Utils.showToast(getActivity(), "Please enter Blood Glucose reading");
                return;
            }


            if (cbTotalCholesterol.isChecked()) {
                isSureTotalCholesterol = 1;

                if (Arrays.asList(arr).contains("1") && totalCholesterolValue.isEmpty()) {
                    Utils.showToast(getActivity(), getString(R.string.pls_enter_tc_and_bp_as_mentioned));
                    // DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.pls_enter_tc_and_bp_as_mentioned), getString(R.string.str_ok), false);
                    return;


                }

            } else if (totalCholesterolValue.isEmpty()) {
                Utils.showToast(getActivity(), getString(R.string.pls_enter_total_cholesterol));
                return;
            }

            if (!totalCholesterolValue.isEmpty() && Integer.parseInt(totalCholesterolValue) == 0) {
                Utils.showToast(getActivity(), "Please enter valid Total Cholesterol reading");
                return;
            }


            if (cbThyroid.isChecked()) {
                isSureThyroid = 1;

                if (Arrays.asList(arr).contains("2") && thyroidValue.isEmpty()) {

                    Utils.showToast(getActivity(), getString(R.string.pls_enter_thyroid_mentioned));
                    return;
                    // DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.pls_enter_thyroid_mentioned), getString(R.string.str_ok), false);



                }


            } else if (thyroidValue.isEmpty()) {
                Utils.showToast(getActivity(), getString(R.string.pls_enter_thyroid));
                return;
            }

            if (!thyroidValue.isEmpty() && Double.parseDouble(thyroidValue) == 0) {
                Utils.showToast(getActivity(), "Please enter Thyroid reading");
                return;
            }

            if (WaistSizeValue.isEmpty()) {
                Utils.showToast(getActivity(), getString(R.string.pls_enter_waist_size));
                return;
            }

            if (!WaistSizeValue.isEmpty() && Integer.parseInt(WaistSizeValue) == 0) {
                Utils.showToast(getActivity(), "Please enter your Waist Size");
                return;
            }


            String bpValue = "";
            if (!systolicValue.isEmpty() && !diastolicValue.isEmpty()) {

                if (systolicValue.length() > 0 && diastolicValue.length() > 0) {

                    int sysValue = Integer.parseInt(systolicValue);
                    int diaValue = Integer.parseInt(diastolicValue);

                    if (diaValue >= sysValue) {
                        Utils.showToast(getActivity(), getString(R.string.systolic_cant_less_than_diastolic));
                        return;
                    } else {
                        bpValue = systolicValue + "/" + diastolicValue;
                    }

                }


            }


            String bgValue = "";
            if (!bloodGlucoseValue.isEmpty() && readingTypePosition != 0) {
                bgValue = bloodGlucoseValue + "/" + readingTypePosition;
            }


            onHraDbAction.onHraQuestionSave(QUESTION_ID_4, bpValue, SCREEN_NO, isSureBp);

            onHraDbAction.onHraQuestionSave(QUESTION_ID_5, bgValue, SCREEN_NO, isSureBg);

            onHraDbAction.onHraQuestionSave(QUESTION_ID_6, totalCholesterolValue, SCREEN_NO, isSureTotalCholesterol);

            onHraDbAction.onHraQuestionSave(QUESTION_ID_7, thyroidValue, SCREEN_NO, isSureThyroid);

            onHraDbAction.onHraQuestionSave(QUESTION_ID_8, WaistSizeValue, SCREEN_NO, isWaistSize);


            Utils.replaceFragment(getFragmentManager(), HraQ5Fragment.newInstance(getArguments()), HraQ5Fragment.class.getSimpleName(), true, R.id.fragmentContainerHra);

        } else {
        }
    }

    private void removeLastItem(String[] arr, StringBuilder stringBuilder) {

        if (Arrays.asList(arr).contains("13")) {

            stringBuilder.delete(0, 2);

        }

    }

    private void getPreviousSelectedAnswer() {
        String answer4 = "";
        int isSure4 = 0;
        HraDBItemDao hraDBDao = GreenDaoApp.getInstance(getActivity()).getDaoSession(getActivity()).getHraDBItemDao();
        List<HraDBItem> answerFromDb4 = hraDBDao.queryBuilder().where(HraDBItemDao.Properties.QuestionId.eq(QUESTION_ID_4)).list();
        for (HraDBItem hraDBItem : answerFromDb4) {
            answer4 = hraDBItem.getAnswer();
            isSure4 = hraDBItem.getIsSure();
        }
        String[] arr4 = answer4.split("/");
        if (arr4.length > 0 && !answer4.isEmpty()) {

            edSystolic.setText(arr4[0]);
            if (arr4.length == 2) {
                edDiastolic.setText(arr4[1]);
            }
        }
        if (isSure4 == 1) {
            cbBp.setChecked(true);
        }

        String answer5 = "";
        int isSure5 = 0;
        List<HraDBItem> answerFromDb5 = hraDBDao.queryBuilder().where(HraDBItemDao.Properties.QuestionId.eq(QUESTION_ID_5)).list();
        for (HraDBItem hraDBItem : answerFromDb5) {
            answer5 = hraDBItem.getAnswer();
            isSure5 = hraDBItem.getIsSure();
        }
        String[] arr5 = answer5.split("/");
        if (arr5.length > 0 && !answer5.isEmpty()) {
            edBloodGlucose.setText(arr5[0]);
            spReadingType.setSelection(Integer.parseInt(arr5[1]));
            readingTypePosition = Integer.parseInt(arr5[1]);

        }
        if (isSure5 == 1) {
            cbBg.setChecked(true);
        }
        String answer6 = "";
        int isSure6 = 0;
        List<HraDBItem> answerFromDb6 = hraDBDao.queryBuilder().where(HraDBItemDao.Properties.QuestionId.eq(QUESTION_ID_6)).list();
        for (HraDBItem hraDBItem : answerFromDb6) {
            answer6 = hraDBItem.getAnswer();
            isSure6 = hraDBItem.getIsSure();
        }
        String[] arr6 = answer6.split("/");
        if (arr6.length > 0 && !answer6.isEmpty()) {
            edTotalCholesterol.setText(arr6[0]);
        }
        if (isSure6 == 1) {
            cbTotalCholesterol.setChecked(true);
        }
        String answer7 = "";
        int isSure7 = 0;
        List<HraDBItem> answerFromDb7 = hraDBDao.queryBuilder().where(HraDBItemDao.Properties.QuestionId.eq(QUESTION_ID_7)).list();
        for (HraDBItem hraDBItem : answerFromDb7) {
            answer7 = hraDBItem.getAnswer();
            isSure7 = hraDBItem.getIsSure();
        }
        String[] arr7 = answer7.split("/");
        if (arr7.length > 0 && !answer7.isEmpty()) {
            edThyroid.setText(arr7[0]);
        }
        if (isSure7 == 1) {
            cbThyroid.setChecked(true);
        }
        String answer8 = "";
        int isSure8 = 0;
        List<HraDBItem> answerFromDb8 = hraDBDao.queryBuilder().where(HraDBItemDao.Properties.QuestionId.eq(QUESTION_ID_8)).list();
        for (HraDBItem hraDBItem : answerFromDb8) {
            answer8 = hraDBItem.getAnswer();
            isSure8 = hraDBItem.getIsSure();
        }
        String[] arr8 = answer8.split("/");
        if (arr8.length > 0 && !answer8.isEmpty()) {
            edWaistSize.setText(arr8[0]);
        }
    }


    private void onBack() {
        Utils.replaceFragmentHraBackAnimation(getFragmentManager(), HraQ3NewFragment.newInstance(getArguments()), HraQ3NewFragment.class.getSimpleName(), true, R.id.fragmentContainerHra);
    }

    private void cancelHra() {
        // if isRetakeTest parameter is true, then user always came here from hra report
        if (getArguments().containsKey("isRetakeTest") && getArguments().getBoolean("isRetakeTest")) {
            getFragmentManager().popBackStackImmediate(HraRiskGradeFragment.class.getSimpleName(), 0);
        } else {
            getActivity().finish();
        }
    }
}
