package com.twc.remindermodule.fragments;

/**
 * Created by GurvinderS on 2/2/2018.
 */

public interface OnRetryAfterNetworkError {
    void onRetry();
}
