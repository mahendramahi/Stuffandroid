package com.truworth.wellnesscorner.model;

import java.io.Serializable;
import java.util.List;

public class MealDataBean implements Serializable {
    private String mealType;
    private List<FoodsBean> foods;

    public String getMealType() {
        return mealType;
    }

    public void setMealType(String mealType) {
        this.mealType = mealType;
    }

    public List<FoodsBean> getFoods() {
        return foods;
    }

    public void setFoods(List<FoodsBean> foods) {
        this.foods = foods;
    }
}
