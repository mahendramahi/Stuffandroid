package com.twc.dailylog.utils;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.TimeZone;

public class DateFactory {

    private static DateFactory dateFactory;
    private Locale locale;

    private DateFactory() {
        locale = Locale.US; // set locale
    }

    public static DateFactory getInstance() {
        if (dateFactory == null) {
            dateFactory = new DateFactory();
        }

        return dateFactory;
    }

    public static int NumberOfDay(String day) {
        if (day.equalsIgnoreCase("monday")) {
            return 1;
        } else if (day.equalsIgnoreCase("tuesday")) {
            return 2;
        } else if (day.equalsIgnoreCase("wednesday")) {
            return 3;
        } else if (day.equalsIgnoreCase("thursday")) {
            return 4;
        } else if (day.equalsIgnoreCase("friday")) {
            return 5;
        } else if (day.equalsIgnoreCase("saturday")) {
            return 6;
        } else if (day.equalsIgnoreCase("sunday")) {
            return 7;
        }
        return 0;
    }

    public static String CurrentDay(int exercisePlanDay_day) {
        switch (exercisePlanDay_day) {
            case 1:
                return "Monday";
            case 2:
                return "Tuesday";
            case 3:
                return "Wednesday";
            case 4:
                return "Thursday";
            case 5:
                return "Friday";
            case 6:
                return "Saturday";
            case 7:
                return "Sunday";
        }
        return "";
    }

    public Date getDate(String inputDate, String formatSrc) {
        Date myDate = null;
        try {
            SimpleDateFormat sdf = new SimpleDateFormat(formatSrc, locale);
            myDate = sdf.parse(inputDate);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return myDate;


    }

    public Date getDateForDefaultLocale(String inputDate, String formatSrc) {
        Date myDate = null;
        try {
            SimpleDateFormat sdf = new SimpleDateFormat(formatSrc, Locale.getDefault());
            myDate = sdf.parse(inputDate);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return myDate;


    }

    public long truncateForGraph(String inputDate) {
        String yyyymmdd = inputDate.substring(0, 10);
        long yyyymmddFormate = Long.parseLong(yyyymmdd.replace("-", ""));
        return yyyymmddFormate;
    }

    public String timeAgo(long time_ago) {
        long cur_time = (Calendar.getInstance().getTimeInMillis()) / 1000;
        long time_elapsed = cur_time - time_ago;
        int minutes = Math.round(time_elapsed / 60);
        int hours = Math.round(time_elapsed / 3600);
        int days = Math.round(time_elapsed / 86400);
        int weeks = Math.round(time_elapsed / 604800);
        int months = Math.round(time_elapsed / 2600640);
        int years = Math.round(time_elapsed / 31207680);

        // Seconds
        if (time_elapsed <= 30) {
            return "just now";
        } else if (time_elapsed <= 60) {
            return time_elapsed + " seconds ago";
        }
        //Minutes
        else if (minutes <= 60) {
            if (minutes == 1) {
                return "one minute ago";
            } else {
                return minutes + " minutes ago";
            }
        }
        //Hours
        else if (hours <= 24) {
            if (hours == 1) {
                return "an hour ago";
            } else {
                return hours + " hours ago";
            }
        }
        //Days
        else if (days <= 7) {
            if (days == 1) {
                return "yesterday";
            } else {
                return days + " days ago";
            }
        }
        //Weeks
        else if (weeks <= 4.3) {
            if (weeks == 1) {
                return "a week ago";
            } else {
                return weeks + " weeks ago";
            }
        }
        //Months
        else if (months <= 12) {
            if (months == 1) {
                return "a month ago";
            } else {
                return months + " months ago";
            }
        }
        //Years
        else {
            if (years == 1) {
                return "one year ago";
            } else {
                if (months % 12 <= 6) {
                    return years + " years ago";
                } else {
                    return years + 1 + " years ago";
                }
            }
        }
    }

    public String formatTime(String formatSrc, String formatDest, String time) {
        String time1 = time.replace("AM", "am").replace("PM", "pm");
        String str = null;

        SimpleDateFormat sdf = new SimpleDateFormat(formatSrc, locale);
        try {
            Date myDate = sdf.parse(time1);
            str = new SimpleDateFormat(formatDest, locale).format(myDate);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        if (str != null) {
            str = str.replace("am", "AM").replace("pm", "PM");
        }
        return str;
    }

    public String getTodayDate(String outputFormat) {
        SimpleDateFormat sdf = new SimpleDateFormat(outputFormat, locale);
        return sdf.format(Calendar.getInstance().getTime());
    }

    public String formatDate(String formatSrc, String formatDest, String date) {
        String str;
        SimpleDateFormat sdf = new SimpleDateFormat(formatSrc, locale);
        try {
            Date myDate = sdf.parse(date);
            str = new SimpleDateFormat(formatDest, locale).format(myDate);
        } catch (ParseException e) {
            e.printStackTrace();
            return "";
        }
        return str;
    }

    public String getDateFromDateFormat(Date inputDate, String formatDest) {
        SimpleDateFormat sdf = new SimpleDateFormat(formatDest, locale);
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(inputDate);
        Date d = calendar.getTime();
        return sdf.format(d);
    }

    public String getPreviousDate(String dateString, int numOfDays, String format) {
        SimpleDateFormat sdf = new SimpleDateFormat(format, locale);
        Date myDate = null;
        try {
            myDate = sdf.parse(dateString);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(myDate);
        calendar.add(Calendar.DAY_OF_YEAR, -numOfDays);
        Date previousDate = calendar.getTime();
        return sdf.format(previousDate);
    }

    public String getPreviousMonth(String dateString, String format) {
        SimpleDateFormat sdf = new SimpleDateFormat(format, locale);
        Date myDate = null;
        try {
            myDate = sdf.parse(dateString);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(myDate);
        calendar.add(Calendar.MONTH, -1);
        Date previousDate = calendar.getTime();
        return sdf.format(previousDate);
    }

    public String getNextMonth(String dateString, String format) {
        SimpleDateFormat sdf = new SimpleDateFormat(format, locale);
        Date myDate = null;
        try {
            myDate = sdf.parse(dateString);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(myDate);
        calendar.add(Calendar.MONTH, +1);
        Date previousDate = calendar.getTime();
        return sdf.format(previousDate);
    }

    /*public String getCustomRelativeTime(String formatSource, String stringDate) {
        Date serverDate = null;
        try {
            serverDate = new SimpleDateFormat(formatSource, locale).parse(stringDate);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        long milliseconds = serverDate != null ? serverDate.getTime() : 0;

        Date curDate = currentDate();
        long now = curDate.getTime();
        if (milliseconds > now || milliseconds <= 0) {
            return "Unknown time";
        }

        int timeDIM = getTimeDistanceInMinutes(milliseconds);

        String timeAgo;

        if (timeDIM == 0) {
            timeAgo = "less than a minute";
        } else if (timeDIM == 1) {
            return "One minute";
        } else if (timeDIM >= 2 && timeDIM <= 44) {
            timeAgo = timeDIM + " minutes";
        } else if (timeDIM >= 45 && timeDIM <= 89) {
            timeAgo = "about an hour";
        } else if (timeDIM >= 90 && timeDIM <= 1439) {
            timeAgo = "about " + (Math.round(timeDIM / 60)) + " hours";
        } else if (timeDIM >= 1440 && timeDIM <= 2519) {
            timeAgo = "1 day";
        } else if (timeDIM >= 2520 && timeDIM <= 43199) {
            timeAgo = (Math.round(timeDIM / 1440)) + " days";
        } else if (timeDIM >= 43200 && timeDIM <= 86399) {
            timeAgo = "about a month";
        } else if (timeDIM >= 86400 && timeDIM <= 525599) {
            timeAgo = (Math.round(timeDIM / 43200)) + " months";
        } else if (timeDIM >= 525600 && timeDIM <= 655199) {
            timeAgo = "about a year";
        } else if (timeDIM >= 655200 && timeDIM <= 914399) {
            timeAgo = "over a year";
        } else if (timeDIM >= 914400 && timeDIM <= 1051199) {
            timeAgo = "almost 2 years";
        } else {
            timeAgo = "about " + (Math.round(timeDIM / 525600)) + " years";
        }

        return timeAgo + " ago";
    }

    public String getRelativeTime(String formatSource, String stringDate) {
        try {
            long now = System.currentTimeMillis();
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat(formatSource, locale);
            simpleDateFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
            Date convertedDate = simpleDateFormat.parse(stringDate);
            Utils.printLog("TAG", "Server :" + convertedDate.getTime() + " Now :" + now);
            CharSequence relativeTimeSpanString = DateUtils.getRelativeTimeSpanString(convertedDate.getTime(), now, DateUtils.SECOND_IN_MILLIS);
            return relativeTimeSpanString.toString();

        } catch (ParseException e) {
            e.printStackTrace();
            return "";
        }
    }

    public Date currentDate() {
        Calendar calendar = Calendar.getInstance();
        return calendar.getTime();
    }

    public int getTimeDistanceInMinutes(long time) {
        long timeDistance = currentDate().getTime() - time;
        return Math.round((Math.abs(timeDistance) / 1000) / 60);
    }*/

    public String getNextDate(String dateString, int noOfDays, String format) {
        SimpleDateFormat sdf = new SimpleDateFormat(format, locale);
        Date myDate = null;
        try {
            myDate = sdf.parse(dateString);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(myDate);
        calendar.add(Calendar.DAY_OF_YEAR, +noOfDays);
        Date previousDate = calendar.getTime();
        return sdf.format(previousDate);
    }

    public String getCurrentTime(String format) {
        SimpleDateFormat sdf = new SimpleDateFormat(format, locale);
        return sdf.format(Calendar.getInstance().getTime());
    }

    public String truncateMilliseconds(String date) {
        String truncatedDate;
        truncatedDate = date.contains(".") ? date.substring(0, date.indexOf(".")) : date;
        return truncatedDate;

    }

    /**
     * ---Added by pankaj on 2016-09-02
     */
    public String GetWeekSlot(String date, int numOfDays) {

        SimpleDateFormat sdf = new SimpleDateFormat("dd MMM yyyy", locale);
        Date myDate = null;
        try {
            myDate = sdf.parse(date);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(myDate);
        calendar.add(Calendar.DAY_OF_YEAR, numOfDays);
        Date newDate = calendar.getTime();

    /*    Calendar first = (Calendar) calendar.clone();
        first.add(Calendar.DAY_OF_WEEK, first.getFirstDayOfWeek() - first.get(Calendar.DAY_OF_WEEK));

        Calendar last = (Calendar) first.clone();
        last.add(Calendar.DAY_OF_YEAR, 6);

        Date firstdate = first.getTime();
        Date seconddate = last.getTime();
        return sdf.format(firstdate) + "-" + sdf.format(seconddate);*/
        return sdf.format(newDate) + "-" + sdf.format(myDate);
    }

    public String GetMonthSlot(int option, String inputDate) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd MMM yyyy", locale);
        Date myDate = null;
        try {
            myDate = sdf.parse(inputDate);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(myDate);

        calendar.add(Calendar.MONTH, option);
        calendar.set(Calendar.DATE, calendar.getActualMinimum(Calendar.DAY_OF_MONTH));
        Date MonthFirstDay = calendar.getTime();
        calendar.set(Calendar.DATE, calendar.getActualMaximum(Calendar.DAY_OF_MONTH));
        Date MonthLastDay = calendar.getTime();

        return sdf.format(MonthFirstDay) + "-" + sdf.format(MonthLastDay);
    }

    public String getMonthsFromCurrentMonth(int option, String inputDate) {
        SimpleDateFormat sdf = new SimpleDateFormat("MM/yyyy", locale);
        Date myDate = null;
        try {
            myDate = sdf.parse(inputDate);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(myDate);
        calendar.add(Calendar.MONTH, option);
        Date monthYear = calendar.getTime();
        return sdf.format(monthYear);
    }

    public long getEpochFromStringDate(String inputDate, String inputFormate) {
        Date date;
        long millisecondsFromNow = 0;
        try {
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat(inputFormate, Locale.getDefault());
            //simpleDateFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
            date = simpleDateFormat.parse(inputDate);
            millisecondsFromNow = date.getTime();

        } catch (ParseException e) {
            e.printStackTrace();
        }
        return millisecondsFromNow;
    }

    public long getMillisFromStringDate(String inputDate, String inputFormate) {
        Date date;
        long millisecondsFromNow = 0;
        try {
            date = new SimpleDateFormat(inputFormate, locale).parse(inputDate);
            millisecondsFromNow = date.getTime();

        } catch (ParseException e) {
            e.printStackTrace();
        }
        return millisecondsFromNow;
    }

    public long getMillisFromStringUTCDate(String inputDate, String inputFormate) {
        Date date;
        long millisecondsFromNow = 0;
        try {
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat(inputFormate, locale);
            simpleDateFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
            date = simpleDateFormat.parse(inputDate);
            millisecondsFromNow = date.getTime();

        } catch (ParseException e) {
            e.printStackTrace();
        }
        return millisecondsFromNow;
    }

    public String GetYearSlot(int option, String inputDate) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd MMM yyyy", locale);
        Date myDate = null;
        try {
            myDate = sdf.parse(inputDate);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(myDate);

        calendar.add(Calendar.YEAR, option);
        calendar.set(Calendar.DAY_OF_YEAR, 1);
        Date YearFirstDay = calendar.getTime();
        calendar.set(Calendar.MONTH, 11);
        calendar.set(Calendar.DAY_OF_MONTH, 31);
        Date YearLastDay = calendar.getTime();

        return sdf.format(YearFirstDay) + "-" + sdf.format(YearLastDay);
    }

    public String getDateFromMillis(long milliSeconds, String dateFormat) {
        // Create a DateFormatter object for displaying date in specified format.
        DateFormat formatter = new SimpleDateFormat(dateFormat, locale);

        // Create a calendar object that will convert the date and time value in milliseconds to date.
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(milliSeconds);
        return formatter.format(calendar.getTime());
    }

    public String getUTCDateFromMillis(long milliSeconds, String dateFormat) {
        // Create a DateFormatter object for displaying date in specified format.
        DateFormat formatter = new SimpleDateFormat(dateFormat);

        // Create a calendar object that will convert the date and time value in milliseconds to date.
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeZone(TimeZone.getTimeZone("UTC"));
        calendar.setTimeInMillis(milliSeconds);
        return formatter.format(calendar.getTime());
    }

    public long getStartTimeOfTodayInMillis() {
        Calendar today = Calendar.getInstance();
        today.setTimeZone(TimeZone.getTimeZone("UTC"));
        today.set(Calendar.HOUR_OF_DAY, 0);
        today.set(Calendar.MINUTE, 0);
        today.set(Calendar.SECOND, 0);
        today.set(Calendar.MILLISECOND, 0);

        return today.getTimeInMillis();
    }

    public String getTodayStartTimeInFormat(String format) {
        SimpleDateFormat sdf = new SimpleDateFormat(format, locale);
        Calendar today = Calendar.getInstance();
        today.set(Calendar.HOUR_OF_DAY, 0);
        today.set(Calendar.MINUTE, 0);
        today.set(Calendar.SECOND, 0);
        today.set(Calendar.MILLISECOND, 0);
        Date date = today.getTime();

        return sdf.format(date);
    }


    public long getStartTimeOfGivenDay(long millis) {
        Calendar day = Calendar.getInstance();
        day.setTimeInMillis(millis);
        day.set(Calendar.HOUR_OF_DAY, 0);
        day.set(Calendar.MINUTE, 0);
        day.set(Calendar.SECOND, 0);
        day.set(Calendar.MILLISECOND, 0);

        return day.getTimeInMillis();
    }

    public long getEndTimeOfTodayInMillis() {
        Calendar todayEnd = Calendar.getInstance();
        todayEnd.set(Calendar.HOUR_OF_DAY, 23);
        todayEnd.set(Calendar.MINUTE, 59);
        todayEnd.set(Calendar.SECOND, 59);
        todayEnd.set(Calendar.MILLISECOND, 999);
        return todayEnd.getTimeInMillis();
    }

    public long getEndTimeOfGivenDay(long millis) {
        Calendar todayEnd = Calendar.getInstance();
        todayEnd.setTimeInMillis(millis);
        todayEnd.set(Calendar.HOUR_OF_DAY, 23);
        todayEnd.set(Calendar.MINUTE, 59);
        todayEnd.set(Calendar.SECOND, 59);
        todayEnd.set(Calendar.MILLISECOND, 999);
        return todayEnd.getTimeInMillis();
    }

    public long getCurrentTimeInMillis() {
        Calendar today = Calendar.getInstance();
        today.setTimeInMillis(System.currentTimeMillis());
        return today.getTimeInMillis();
    }

    public long getUTCCurrentTimeInMillis() {
        Calendar today = Calendar.getInstance();
        today.setTimeZone(TimeZone.getTimeZone("UTC"));
        today.setTimeInMillis(System.currentTimeMillis());
        return today.getTimeInMillis();
    }

    public long getDaysDifference(String firstDate, String nextDate, String format) {
        long days = 0;
        SimpleDateFormat sdf = new SimpleDateFormat(format, locale);

        try {
            Date date1 = sdf.parse(firstDate);
            Date date2 = sdf.parse(nextDate);
            long diff = date2.getTime() - date1.getTime();
            days = diff / (24 * 60 * 60 * 1000);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return days;
    }
    public long getHourDifference(String firstDate, String nextDate, String format) {
        long Hours = 0;
        SimpleDateFormat sdf = new SimpleDateFormat(format, locale);
        try {
            Date date1 = sdf.parse(firstDate);
            Date date2 = sdf.parse(nextDate);
            long diff = date2.getTime() - date1.getTime();
            Hours = diff / (60 * 60 * 1000) % 24;

        } catch (Exception e) {
            e.printStackTrace();
        }
        return Hours;
    }
    public long getMinuteDifference(String firstDate, String nextDate, String format) {
        long Minute = 0;
        SimpleDateFormat sdf = new SimpleDateFormat(format, locale);
        try {
            Date date1 = sdf.parse(firstDate);
            Date date2 = sdf.parse(nextDate);
            long diff = date2.getTime() - date1.getTime();
            Minute = diff / (60 * 1000) % 60;

        } catch (Exception e) {
            e.printStackTrace();
        }
        return Minute;
    }
    public String currentDay(String outputFormat) {
        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat format = new SimpleDateFormat(outputFormat, locale);
        return format.format(calendar.getTime());
    }

    public LinkedHashMap<String, String> getSpecificWeekArray(String inputDefault, String outputFormat, long timeInMillis, int totalDays) {
        LinkedHashMap<String, String> hashMap = new LinkedHashMap<>();
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(timeInMillis);
        SimpleDateFormat format = new SimpleDateFormat(outputFormat, locale);
        for (int i = 0; i < totalDays; i++) {
            String dateOfWeek = format.format(calendar.getTime());
            hashMap.put(dateOfWeek, inputDefault);
            calendar.add(Calendar.DAY_OF_WEEK, -1);
        }
        return hashMap;
    }

    public String appServerFormatDate(String date) {
        if (date != null && date.length() > 0) {
            return formatDate("yyyy-MM-dd'T'HH:mm:ss", "MMM dd, yyyy", truncateMilliseconds(date));
        } else {
            return "";
        }
    }

    public String getTime(String date) {
        if (date != null && date.length() > 0) {
            return formatDate("yyyy-MM-dd'T'HH:mm:ss", "HH:mm", truncateMilliseconds(date));
        } else {
            return "";
        }
    }

    public String showDateTimeUsingServerFormatDate(String date) {
        if (date != null && date.length() > 0) {
            String currentDateTime = getTodayStartTimeInFormat(Constant.SERVER_DATE_FORMAT_WITH_MILLISECONDS);
            String getDateInStartOFDay = DateFactory.getInstance().getDateFromMillis(DateFactory.getInstance().getStartTimeOfGivenDay(DateFactory.getInstance().getMillisFromStringDate(date, Constant.SERVER_DATE_FORMAT_WITH_MILLISECONDS)), Constant.SERVER_DATE_FORMAT_WITH_MILLISECONDS);
            long syncDaysDifference = getDaysDifference(getDateInStartOFDay, currentDateTime, Constant.SERVER_DATE_FORMAT_WITH_MILLISECONDS);
            if (syncDaysDifference == 0)
                return "Today at " + formatDate("yyyy-MM-dd'T'HH:mm:ss", "hh:mm a", truncateMilliseconds(date));
            else {
                if (truncateMilliseconds(date).contains("T00:00:00"))
                    return formatDate("yyyy-MM-dd'T'HH:mm:ss", "MMM dd, yyyy", truncateMilliseconds(date));
                else
                    return formatDate("yyyy-MM-dd'T'HH:mm:ss", "MMM dd, yyyy hh:mm a", truncateMilliseconds(date));
            }
        } else {
            return "";
        }
    }

    public boolean isFutureDate(int dayToCheck, int monthToCheck, int yearToCheck) {
        Date currantDate = new Date();
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.DAY_OF_MONTH, dayToCheck);
        calendar.set(Calendar.MONTH, monthToCheck);
        calendar.set(Calendar.YEAR, yearToCheck);
        Date selectedDate = calendar.getTime();
        return selectedDate.after(currantDate);
    }

    public boolean isDateFromCurrentsMonth(Calendar calendar) {
        Calendar currentMonthCal = Calendar.getInstance();

        if (currentMonthCal.get(Calendar.YEAR) == calendar.get(Calendar.YEAR)) {
            if (currentMonthCal.get(Calendar.MONTH) == calendar.get(Calendar.MONTH)) {
                return true;
            }
        }
        return false;
    }

    public SimpleDateFormat getSimpleDateFormatInstance(String format) {
        return new SimpleDateFormat(format, locale);
    }

    public String getMonthSlotInMillis(long millisOfMonth, int addOrRemove) {
        // Rest Hour, Minute and Second to ZERO
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(millisOfMonth);
        calendar.set(Calendar.HOUR_OF_DAY, 0);
        if (addOrRemove != 0) {
            calendar.add(Calendar.MONTH, addOrRemove);
        }
        calendar.set(Calendar.DATE, calendar.getActualMinimum(Calendar.DAY_OF_MONTH));
        long monthFirstDayMillis = calendar.getTime().getTime();
        calendar.set(Calendar.DATE, calendar.getActualMaximum(Calendar.DAY_OF_MONTH));
        long monthLastDayMillis = calendar.getTime().getTime();

        return monthFirstDayMillis + "-" + monthLastDayMillis;
    }
}
