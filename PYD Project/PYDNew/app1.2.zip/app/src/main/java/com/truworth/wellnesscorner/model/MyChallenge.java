package com.truworth.wellnesscorner.model;

public class MyChallenge {

}
