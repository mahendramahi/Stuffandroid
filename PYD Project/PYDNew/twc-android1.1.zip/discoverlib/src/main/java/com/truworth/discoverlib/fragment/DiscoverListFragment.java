package com.truworth.discoverlib.fragment;

import android.os.Bundle;
import android.os.Handler;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ProgressBar;

import com.truworth.discoverlib.DiscoverActivity;
import com.truworth.discoverlib.R;
import com.truworth.discoverlib.R2;
import com.truworth.discoverlib.adapter.DiscoverListAdapter;
import com.truworth.discoverlib.interfaces.OnDiscoverCategoryChangeListener;
import com.truworth.discoverlib.interfaces.OnLoadMoreListener;
import com.truworth.discoverlib.interfaces.OnRetryAfterNetworkError;
import com.truworth.discoverlib.model.ArticleItem;
import com.truworth.discoverlib.model.GetRandomArticleResponse;
import com.truworth.discoverlib.model.RandomArticleBody;
import com.truworth.discoverlib.rest.RestClient;
import com.truworth.discoverlib.utils.DialogFactory;
import com.truworth.discoverlib.utils.DiscoverConfig;
import com.truworth.discoverlib.utils.NetworkErrorDialog;
import com.truworth.discoverlib.utils.NetworkFactory;
import com.truworth.discoverlib.utils.NoDataView;
import com.truworth.discoverlib.utils.Utils;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * If this code works it was written by Somesh Kumar on 06 August, 2016. If not, I don't know who wrote it.
 */
@SuppressWarnings({"ConstantConditions", "NullableProblems"})
public class DiscoverListFragment extends BaseFragment implements OnDiscoverCategoryChangeListener, OnRetryAfterNetworkError {


    private final int visibleThreshold = 5;
    @BindView(R2.id.rvDiscoverList)
    RecyclerView rvDiscoverList;

    @BindView(R2.id.rootView)
    View rootView;

    @BindView(R2.id.progressBar)
    ProgressBar progressBar;

    @BindView((R2.id.noDataView))
    NoDataView noDataView;
    boolean isLoadMore = false;
    private int page = 1;
    private String articleCategory = "All";
    private String articleLastFilter = "";
    private DiscoverListAdapter mDiscoverListAdapter;
    private List<ArticleItem> mArticleList;
    private int lastVisibleItem, totalItemCount;
    private boolean loading;
    private OnLoadMoreListener onLoadMoreListener;
    private boolean isLastResult = false;

    public static DiscoverListFragment newInstance() {
        return new DiscoverListFragment();
    }

    @Override
    public int getFragmentLayout() {
        return R.layout.fragment_discover_list;
    }

    @Override
    public void onFragmentReady() {
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getActivity());
        rvDiscoverList.setLayoutManager(linearLayoutManager);
        rvDiscoverList.setHasFixedSize(true);

        if (mDiscoverListAdapter != null) {
            progressBar.setVisibility(View.GONE);
            rvDiscoverList.setAdapter(mDiscoverListAdapter);
            mDiscoverListAdapter.notifyDataSetChanged();

        } else {
            progressBar.setVisibility(View.VISIBLE);
            // llNoRecentData.setVisibility(View.GONE);
            noDataView.setVisibility(View.GONE);
        }
        setOnLoadMoreListener(linearLayoutManager);

    }

    @Override
    public void onResume() {
        super.onResume();
        ((DiscoverActivity) getActivity()).showHomeAsUpEnableToolbar();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (mArticleList != null) {
            mArticleList.clear();
            mDiscoverListAdapter.notifyDataSetChanged();
            mDiscoverListAdapter = null;
            mArticleList = null;
        }
    }

    @Override
    public void setUserVisibleHint(final boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                if (isVisibleToUser && mDiscoverListAdapter != null && mDiscoverListAdapter.getItemCount() == 0) {
                    page = 1;
                    if (rvDiscoverList != null) {
                        rvDiscoverList.setAdapter(mDiscoverListAdapter);
                    }
                    if (progressBar != null) {
                        progressBar.setVisibility(View.VISIBLE);
                    }
                    isLoadMore = false;
                    getRandomArticle(String.valueOf(page), articleCategory, isLoadMore);
                }
            }
        }, 150);
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mArticleList = new ArrayList<>();
        mDiscoverListAdapter = new DiscoverListAdapter(mArticleList, getActivity());
    }

    private void getRandomArticle(final String page, String articleCurrentFilter, final boolean isLoadMore) {
        if (NetworkFactory.getInstance().isNetworkAvailable(getActivity())) {
            if (isAdded() && getActivity() != null) {
                if (isLoadMore || !articleCurrentFilter.equalsIgnoreCase(articleLastFilter)) {

                    if (!isLoadMore) {
                        setProgressTextVisibility(true, false);
                        mArticleList.clear();
                        mDiscoverListAdapter.notifyDataSetChanged();
                    }
                    articleLastFilter = articleCurrentFilter;

                    String articleType = ((DiscoverFragment) getParentFragment()).getArticleTypeForAPI();
                    RandomArticleBody randomArticleBody = new RandomArticleBody();
                    randomArticleBody.setPageIndex(page);
                    randomArticleBody.setCategory(articleCurrentFilter);
                    randomArticleBody.setType(articleType);
                    RestClient restClient = new RestClient(getActivity(), DiscoverConfig.BASE_URL, DiscoverConfig.DEBUG);
                    restClient.getDiscoverService().getRandomArticle(randomArticleBody).enqueue(
                            new Callback<GetRandomArticleResponse>() {
                                @Override
                                public void onResponse(Call<GetRandomArticleResponse> call, Response<GetRandomArticleResponse> response) {
                                    if (isAdded() && getActivity() != null) {
                                        Utils.hideSoftKeyboard(getActivity());
                                        removeProgressLoading();
                                        loading = false;
                                        if (response != null && response.body() != null) {
                                            if (response.body().getStatus() == 0) {
                                                if (response.body().getData() != null && response.body().getData().size() > 0) {
                                                    setProgressTextVisibility(false, false);
                                                    mArticleList.addAll(response.body().getData());
                                                    mDiscoverListAdapter.notifyDataSetChanged();
                                                }

                                                else {
                                                    isLastResult = true;
                                                    setProgressTextVisibility(false, !isLoadMore);
                                                }
                                            } else if (response.body().getStatus() == -1) {
                                                isLastResult = true;
                                                setProgressTextVisibility(false, !isLoadMore);
                                            }
                                        } else {
                                            setProgressTextVisibility(false, page.equalsIgnoreCase("1"));
                                            DialogFactory.getInstance().showAlertDialog(getActivity(), null, 0, getString(R.string.msg_api_response_null), getString(R.string.str_ok), true);
                                        }
                                    }
                                }

                                @Override
                                public void onFailure(Call<GetRandomArticleResponse> call, Throwable t) {
                                    if (isAdded() && getActivity() != null) {
                                        Utils.hideSoftKeyboard(getActivity());
                                        removeProgressLoading();
                                        setProgressTextVisibility(false, false);
                                        DialogFactory.getInstance().showAlertDialog(getActivity(), null, 0, getString(R.string.msg_api_failure), getString(R.string.str_ok), true);
                                    }
                                }
                            }

                    );
                } else {
                    setProgressTextVisibility(false, mArticleList.size() == 0);
                }
            }
        } else {
            removeProgressLoading();
            setProgressTextVisibility(false, false);
            // Utils.showSnackBarMessage(rootView, getString(R.string.internet_not_available));
            showNetWorkDialog();
        }
    }

    private void showNetWorkDialog() {
        NetworkErrorDialog networkErrorDialog = new NetworkErrorDialog(getActivity(), getActivity(), DiscoverListFragment.this);
        networkErrorDialog.show();
        Window window = networkErrorDialog.getWindow();
        window.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);
    }

    private void setOnLoadMoreListener(final LinearLayoutManager linearLayoutManager) {
        onLoadMoreListener = new OnLoadMoreListener() {
            @Override
            public void onLoadMore() {
                if (!isLastResult) {
                    if (mArticleList.size() > 5) {
                        isLoadMore = true;
                        if (NetworkFactory.getInstance().isNetworkAvailable(getActivity())) {
                            mArticleList.add(null);
                            mDiscoverListAdapter.notifyItemInserted(mArticleList.size() - 1);
                            new Handler().postDelayed(new Runnable() {
                                @Override
                                public void run() {

                                    page = page + 1;
                                    getRandomArticle(String.valueOf(page), articleCategory, isLoadMore);
                                }

                            }, 500);
                        } else {
                            showNetWorkDialog();
                        }
                    }

                }
            }
        };

        rvDiscoverList.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                totalItemCount = linearLayoutManager.getItemCount();
                lastVisibleItem = linearLayoutManager.findLastVisibleItemPosition();
                if (!loading && totalItemCount <= (lastVisibleItem + visibleThreshold)) {
                    onLoadMoreListener.onLoadMore();
                    loading = true;
                }
            }
        });
    }

    private void setProgressTextVisibility(boolean progressVisibility, boolean noDataVisibility) {
        if (progressBar != null) {
            progressBar.setVisibility(progressVisibility ? View.VISIBLE : View.GONE);
        }
        if (noDataView != null) {
            noDataView.setVisibility(noDataVisibility ? View.VISIBLE : View.GONE);
        }
    }

    private void removeProgressLoading() {
        if (mArticleList != null && mArticleList.size() > 0 && mArticleList.get(mArticleList.size() - 1) == null) {
            mArticleList.remove(mArticleList.size() - 1);
            mDiscoverListAdapter.notifyDataSetChanged();
        }
    }

    @Override
    public void OnDiscoverFilterCategoryChange(String filterCategory) {
        articleCategory = filterCategory;
        isLastResult = false;
        page = 1;

        isLoadMore = false;
        getRandomArticle(String.valueOf(page), articleCategory, isLoadMore);

    }

    @Override
    public void onRetry() {
        if (!isLoadMore) {
            getRandomArticle(String.valueOf(page), articleCategory, isLoadMore);
        } else {
            loading = false;
        }
    }
}
