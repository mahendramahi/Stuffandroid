package com.truworth.wellnesscorner.repo.model.request;

/**
 * If this code works it was written by Somesh Kumar on 26 September, 2017. If not, I don't know who wrote it.
 */
public class DeviceStepRequest {
    private int MemberID;
    private String Date; // Format 2017-09-20T00:00:00
    private String DeviceType;

    public int getMemberID() {
        return MemberID;
    }

    public void setMemberID(int MemberID) {
        this.MemberID = MemberID;
    }

    public String getDate() {
        return Date;
    }

    public void setDate(String Date) {
        this.Date = Date;
    }

    public String getDeviceType() {
        return DeviceType;
    }

    public void setDeviceType(String DeviceType) {
        this.DeviceType = DeviceType;
    }
}
