#HRA Module Documentation
This file to include all the documentation and logics for HRA Module including the structure, dependencies, fragments, and activity details.