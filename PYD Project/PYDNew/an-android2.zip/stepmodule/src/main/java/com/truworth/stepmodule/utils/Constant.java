package com.truworth.stepmodule.utils;


public class Constant {


    public static final String S_HEALTH = "Samsung Health";
    public static final String FITBIT = "Fitbit";
    public static final String GOOGLE_FIT = "Google Fit";
    public static final String E_FIT = "E Fit";
    public static final String MISFIT = "MisFit";



}
