package com.twc.dailylog.model.beans;

/**
 * Created by PankajS on 8/5/2016.
 */
public class NutritionDataItem
{
    private String nutritionMealType;
    private int nutritionMemberID;
    private int nutritionID;
    private int fOODID;
    private String nutritionFoodItem;
    private double nutritionQuantity;
    private double nutritionCalorie;
    private double calorie;
    private double nutritionCarbs;
    private double nutritionFat;
    private double nutritionSodium;
    private double nutritionProtien;
    private String nutritionDate;
    private String nutritionTime;
    private String nutritionStandardServing;
    private double totalCal;

    public String getNutritionMealType() {
        return nutritionMealType;
    }

    public void setNutritionMealType(String nutritionMealType) {
        this.nutritionMealType = nutritionMealType;
    }

    public int getNutritionMemberID() {
        return nutritionMemberID;
    }

    public void setNutritionMemberID(int nutritionMemberID) {
        this.nutritionMemberID = nutritionMemberID;
    }

    public int getNutritionID() {
        return nutritionID;
    }

    public void setNutritionID(int nutritionID) {
        this.nutritionID = nutritionID;
    }

    public int getFOODID() {
        return fOODID;
    }

    public void setFOODID(int fOODID) {
        this.fOODID = fOODID;
    }

    public String getNutritionFoodItem() {
        return nutritionFoodItem;
    }

    public void setNutritionFoodItem(String nutritionFoodItem) {
        this.nutritionFoodItem = nutritionFoodItem;
    }

    public double getNutritionQuantity() {
        return nutritionQuantity;
    }

    public void setNutritionQuantity(double nutritionQuantity) {
        this.nutritionQuantity = nutritionQuantity;
    }

    public double getNutritionCalorie() {
        return nutritionCalorie;
    }

    public void setNutritionCalorie(double nutritionCalorie) {
        this.nutritionCalorie = nutritionCalorie;
    }

    public double getCalorie() {
        return calorie;
    }

    public void setCalorie(double calorie) {
        this.calorie = calorie;
    }

    public double getNutritionCarbs() {
        return nutritionCarbs;
    }

    public void setNutritionCarbs(double nutritionCarbs) {
        this.nutritionCarbs = nutritionCarbs;
    }

    public double getNutritionFat() {
        return nutritionFat;
    }

    public void setNutritionFat(int nutritionFat) {
        this.nutritionFat = nutritionFat;
    }

    public double getNutritionSodium() {
        return nutritionSodium;
    }

    public void setNutritionSodium(int nutritionSodium) {
        this.nutritionSodium = nutritionSodium;
    }

    public double getNutritionProtien() {
        return nutritionProtien;
    }

    public void setNutritionProtien(int nutritionProtien) {
        this.nutritionProtien = nutritionProtien;
    }

    public String getNutritionDate() {
        return nutritionDate;
    }

    public void setNutritionDate(String nutritionDate) {
        this.nutritionDate = nutritionDate;
    }

    public String getNutritionTime() {
        return nutritionTime;
    }

    public void setNutritionTime(String nutritionTime) {
        this.nutritionTime = nutritionTime;
    }

    public String getNutritionStandardServing() {
        return nutritionStandardServing;
    }

    public void setNutritionStandardServing(String nutritionStandardServing) {
        this.nutritionStandardServing = nutritionStandardServing;
    }

    public double getTotalCal() {
        return totalCal;
    }

    public void setTotalCal(double totalCal) {
        this.totalCal = totalCal;
    }
}
