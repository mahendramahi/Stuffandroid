package com.twc.store.fragments;

import android.content.DialogInterface;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.content.ContextCompat;
import android.support.v4.widget.NestedScrollView;
import android.support.v7.widget.CardView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import com.twc.store.R;
import com.twc.store.R2;
import com.twc.store.StoreActivity;
import com.twc.store.StoreCategoryActivity;
import com.twc.store.StoreDetailActivity;
import com.twc.store.adapter.StoreMyCartListAdapter;
import com.twc.store.dialog.ApiErrorDialog;
import com.twc.store.dialog.NetworkErrorDialog;
import com.twc.store.interfaces.OnRetryAfterNetworkError;
import com.twc.store.model.beans.CartListItem;
import com.twc.store.model.beans.CartOrderDetailObject;
import com.twc.store.model.beans.CouponBean;
import com.twc.store.model.beans.CouponItem;
import com.twc.store.model.beans.DataStoreCartItem;
import com.twc.store.model.requestbody.ApplyCouponBody;
import com.twc.store.model.requestbody.BaseMemberIdBody;
import com.twc.store.model.requestbody.DeleteCartItemBody;
import com.twc.store.model.requestbody.UpdateCartQuantityBody;
import com.twc.store.model.response.ApplyCouponResponse;
import com.twc.store.model.response.DeleteCartItemResponse;
import com.twc.store.model.response.GetCartItemsResponse;
import com.twc.store.model.response.UpdateCartQuantityResponse;
import com.twc.store.rest.RestClient;
import com.twc.store.utils.DialogFactory;
import com.twc.store.utils.NetworkFactory;
import com.twc.store.utils.StoreConfig;
import com.twc.store.utils.Utils;
import com.twc.store.views.CustomEditTextView;
import com.twc.store.views.CustomProgressDialog;
import com.twc.store.views.CustomTextView;
import com.twc.store.views.NoDataView;

import java.util.ArrayList;
import java.util.Iterator;

import butterknife.BindView;
import butterknife.OnClick;
import butterknife.OnTextChanged;
import butterknife.OnTouch;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static butterknife.OnTextChanged.Callback.AFTER_TEXT_CHANGED;

/**
 * Created by PalakC on 9/6/2017.
 */
// Last Updated on 06/02/2018 by richas implemented Error screens
public class StoreMyCartFragment extends BaseFragment implements OnRetryAfterNetworkError {

    // private final int wellcashPercent = 20;
    @BindView(R2.id.rvProductList)
    RecyclerView rvProductList;
    @BindView(R2.id.tvCouponApply)
    CustomTextView tvCouponApply;
    // @BindView(R.id.tvWellCashApply)
    // CustomTextView tvWellCashApply;
    @BindView(R2.id.tvPrice)
    CustomTextView tvPrice;
    @BindView(R2.id.tvTax)
    CustomTextView tvTax;
    // @BindView(R.id.tvWellCashDiscount)
    // CustomTextView tvWellCashDiscount;
    @BindView(R2.id.tvPriceTotal)
    CustomTextView tvPriceTotal;
    @BindView(R2.id.tvGrandPrice)
    CustomTextView tvGrandPrice;
    @BindView(R2.id.tvProceedToPay)
    CustomTextView tvProceedToPay;
    // @BindView(R.id.etPayByCash)
    //  CustomEditTextView etPayByCash;
    @BindView(R2.id.nestedScrollView)
    NestedScrollView nestedScrollView;
    @BindView(R2.id.bottomLayout)
    RelativeLayout bottomLayout;
    @BindView(R2.id.noDataView)
    NoDataView noDataView;
    @BindView(R2.id.etCouponCode)
    CustomEditTextView etCoupon;
    @BindView(R2.id.couponListLayout)
    LinearLayout couponListLayout;
    @BindView(R2.id.tvPriceWithCartCount)
    CustomTextView tvPriceWithCartCount;
    // @BindView(R.id.tvWellCashPrice)
    // CustomTextView tvWellCashPrice;
    @BindView(R2.id.tvCoupon)
    CustomTextView tvCoupon;
    @BindView(R2.id.tvContinueShopping)
    CustomTextView tvContinueShopping;
    @BindView(R2.id.ivCouponClose)
    ImageView ivCouponClose;
    @BindView(R2.id.rlNoData)
    RelativeLayout rlNoData;
    @BindView(R2.id.rlStoreData)
    RelativeLayout rlStoreData;
    // @BindView(R.id.discountLayout)
    //  LinearLayout discountLayout;
    @BindView(R2.id.priceCouponLayout)
    LinearLayout priceCouponLayout;
    @BindView(R2.id.wellcashSeparator)
    View wellcashSeparator;
    @BindView(R2.id.viewCouponSeparator)
    View viewCouponSeparator;
    // @BindView(R.id.ivWellCashCancel)
    // ImageView ivWellCashCancel;
    @BindView(R2.id.rootView)
    RelativeLayout rootView;
    @BindView(R2.id.couponCard)
    CardView couponCard;
    @BindView(R2.id.priceCard)
    CardView priceCard;
    //  @BindView(R.id.tvWellCashPercent)
    //  CustomTextView tvWellCashPercent;
    //  private double wellCashMain;
    private ArrayList<CartListItem> cartListItems;
    private StoreMyCartListAdapter cartAdapter;
    private ArrayList<CouponBean> couponList;
    private CartOrderDetailObject cartOrderDetailObject;

    public static StoreMyCartFragment newInstance() {
        return new StoreMyCartFragment();
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        cartListItems = new ArrayList<>();
        couponList = new ArrayList<>();
        cartAdapter = new StoreMyCartListAdapter(getActivity(), cartListItems, StoreMyCartFragment.this);


    }

    @Override
    public void onResume() {
        super.onResume();
        if (getActivity() instanceof StoreActivity) {
            ((StoreActivity) getActivity()).showHomeAsUpEnableToolbar();
            ((StoreActivity) getActivity()).setToolBarTitle("My Cart");
        } else if (getActivity() instanceof StoreDetailActivity) {
            ((StoreDetailActivity) getActivity()).showHomeAsUpEnableToolbar();
            ((StoreDetailActivity) getActivity()).setToolBarTitle("My Cart");
        }else if (getActivity() instanceof StoreCategoryActivity) {
            ((StoreCategoryActivity) getActivity()).showHomeAsUpEnableToolbar();
            ((StoreCategoryActivity) getActivity()).setToolBarTitle("My Cart");
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();

    }

    @Override
    public int getFragmentLayout() {
        return R.layout.fragment_store_mycart;
    }

    @Override
    public void onFragmentReady() {
        getActivity().getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN | WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        couponList.clear();
        cartListItems.clear();


        // initialize default values in cartOrderDetailObject
        cartOrderDetailObject = new CartOrderDetailObject();
        cartOrderDetailObject.setCartListItems(cartListItems);
        cartOrderDetailObject.setCouponList(couponList);
        cartOrderDetailObject.setCartItemsSize(cartListItems.size());
        cartOrderDetailObject.setCartIds(getCommaSeparatedString(cartListItems));
        cartOrderDetailObject.setCouponIds(getCommaSeparatedString(couponList));
        cartOrderDetailObject.setCouponDiscount(0.0);
        cartOrderDetailObject.setGrandTotalAmount(0.0);
        cartOrderDetailObject.setTotalAmount(0.0);
        cartOrderDetailObject.setTotalTax(0.0);
        cartOrderDetailObject.setTotalWellCashDiscount(0.0);


        //tvWellCashPercent.setText("Note: Maximum WellCash use is " + wellcashPercent + "% of the base price");
        noDataView.setTitleView("You don’t have any items available in your cart");
        Utils.setupTouchUI(rootView, getActivity());

        LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity());
        rvProductList.setLayoutManager(layoutManager);
        rvProductList.setAdapter(cartAdapter);
        setListener();

        myCartApiCall();
    }

    private void hideKeyBoard(View v) {
        Utils.hideSoftKeyboard(getActivity());
    }

    private void setListener() {
        etCoupon.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if (charSequence.toString().equalsIgnoreCase("")) {
                    ivCouponClose.setVisibility(View.GONE);
                } else {
                    ivCouponClose.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
    }


    @OnTextChanged(value = R2.id.etCouponCode, callback = AFTER_TEXT_CHANGED)
    public void afterCouponCode(Editable editable) {
        if (editable.length() > 0) {
            tvCouponApply.setTextColor(Color.WHITE);
            tvCouponApply.setBackground(ContextCompat.getDrawable(getActivity(), R.drawable.custom_store_button));
        } else {
            tvCouponApply.setTextColor(ContextCompat.getColor(getActivity(), R.color.color_cc000000));
            tvCouponApply.setBackground(null);
        }
    }

    @OnClick({R2.id.tvProceedToPay, R2.id.tvCouponApply, R2.id.tvContinueShopping, R2.id.ivCouponClose})
    public void onClick(View view) {


        if (view.getId() == R.id.tvProceedToPay) {
            Utils.replaceFragment(getActivity().getFragmentManager(), StoreConfirmOrderFragment.newInstance(cartOrderDetailObject), StoreConfirmOrderFragment.class.getSimpleName(), true, R.id.fragmentContainer);
        } else if (view.getId() == R.id.tvCouponApply) {
            Utils.hideSoftKeyboard(getActivity());
            callApplyCoupon();
        } else if (view.getId() == R.id.tvContinueShopping) {
            if (getFragmentManager().findFragmentByTag(StoreHomeFragment.class.getSimpleName()) != null)
                getActivity().getFragmentManager().popBackStackImmediate(StoreHomeFragment.class.getSimpleName(), 0);
            else {
                Utils.replaceFragment(getActivity().getFragmentManager(), StoreHomeFragment.newInstance(), StoreHomeFragment.class.getSimpleName(), true, R.id.fragmentContainer);
            }
        } else if (view.getId() == R.id.ivCouponClose) {
            etCoupon.setText("");
        }


    }

    @OnTouch({R2.id.etCouponCode, R2.id.rootView, R2.id.couponCard, R2.id.priceCard, R2.id.rvProductList})
    public boolean onTouch(View view, MotionEvent event) {

        if (view.getId() == R.id.rootView) {
            hideKeyBoard(view);
        } else if (view.getId() == R.id.couponCard) {
            hideKeyBoard(view);
        } else if (view.getId() == R.id.priceCard) {
            hideKeyBoard(view);
        } else if (view.getId() == R.id.rvProductList) {
            hideKeyBoard(view);
        }


        return false;
    }

    private void myCartApiCall() {
        if (NetworkFactory.getInstance().isNetworkAvailable(getActivity())) {
            final CustomProgressDialog pb;
            pb = new CustomProgressDialog(getActivity(), R.style.custom_progress_style, false);
            pb.show();
            //body
            BaseMemberIdBody baseMemberIdBody = new BaseMemberIdBody();
            baseMemberIdBody.setMemberID(StoreConfig.storeUser.getMemberId());
            RestClient restClient = new RestClient(getActivity(), StoreConfig.BASE_URL, StoreConfig.mdebug);

            restClient.getStoreService().getCartItems(baseMemberIdBody).enqueue(new Callback<GetCartItemsResponse>() {
                @Override
                public void onResponse(Call<GetCartItemsResponse> call, Response<GetCartItemsResponse> response) {

                    if (isAdded() && getActivity() != null) {
                        if (pb.isShowing()) {
                            pb.dismiss();
                        }

                        if (response != null && response.body() != null && response.body().getData() != null) {
                            if (response.body().getStatus() == 0) {
                                if (response.body().getData().getCartList().size() > 0) {
                                    rlNoData.setVisibility(View.GONE);
                                    rlStoreData.setVisibility(View.VISIBLE);
                                    cartListItems.clear();
                                    cartListItems.addAll(response.body().getData().getCartList());
                                    cartAdapter.notifyDataSetChanged();
                                } else {
                                    rlNoData.setVisibility(View.VISIBLE);
                                    rlStoreData.setVisibility(View.GONE);
                                }
                                // wellCashMain = response.body().getData().getWellcashDiscount();
                                setData(response.body().getData());
                            } else {
                                rlNoData.setVisibility(View.VISIBLE);
                                rlStoreData.setVisibility(View.GONE);
                                DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_response_failure), getString(R.string.str_ok), false);
                            }
                        } else {
                            //rlNoData.setVisibility(View.VISIBLE);
                            //rlStoreData.setVisibility(View.GONE);
                            //DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_response_null), getString(R.string.str_ok), false);
                            showApiErrorDialog();
                        }
                    }
                }

                @Override
                public void onFailure(Call<GetCartItemsResponse> call, Throwable t) {
                    if (isAdded() && getActivity() != null) {
                        if (pb.isShowing()) {
                            pb.dismiss();
                        }
                        //DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_failure), getString(R.string.str_ok), false);
                        showApiErrorDialog();
                    }
                }
            });
        } else {
            // show Network Error Screen Dialog
            NetworkErrorDialog networkErrorDialog = new NetworkErrorDialog(getActivity(), getActivity(), StoreMyCartFragment.this);
            networkErrorDialog.show();
            Window window = networkErrorDialog.getWindow();
            window.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);
        }
    }

    // method to show Api Error Screen Dialog
    private void showApiErrorDialog() {
        ApiErrorDialog apiErrorDialog = new ApiErrorDialog(getActivity(), getActivity(), StoreMyCartFragment.this);
        apiErrorDialog.show();
        Window window = apiErrorDialog.getWindow();
        window.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);
    }

    private void setData(DataStoreCartItem data) {
        if (data != null) {
            //Add like web as discuss with manish sir

            changeCartItemSize();

            priceCalculation();

            //priceCalculation();
           /* if (wellCashMain == 0.0) {
                discountLayout.setVisibility(View.GONE);
                wellcashSeparator.setVisibility(View.GONE);
            }*/
        }
    }


    private void changeCartItemSize() {
        if (cartListItems != null && cartListItems.size() > 0) {
            if (cartListItems.size() == 1) {
                tvPriceWithCartCount.setText(getString(R.string.price) + " (" + cartListItems.size() + " item)");
            } else if (cartListItems.size() > 1) {
                tvPriceWithCartCount.setText(getString(R.string.price) + " (" + cartListItems.size() + " items)");
            }
            if (getActivity() instanceof StoreActivity)
                ((StoreActivity) getActivity()).setToolBarTitle("My Cart (" + cartListItems.size() + ")");
            else if (getActivity() instanceof StoreDetailActivity)
                ((StoreDetailActivity) getActivity()).setToolBarTitle("My Cart (" + cartListItems.size() + ")");
            else if (getActivity() instanceof StoreCategoryActivity)
                ((StoreCategoryActivity) getActivity()).setToolBarTitle("My Cart (" + cartListItems.size() + ")");
        } else {
            if (getActivity() instanceof StoreActivity)
                ((StoreActivity) getActivity()).setToolBarTitle("My Cart");
            else if (getActivity() instanceof StoreDetailActivity)
                ((StoreDetailActivity) getActivity()).setToolBarTitle("My Cart");
            else if (getActivity() instanceof StoreCategoryActivity)
                ((StoreCategoryActivity) getActivity()).setToolBarTitle("My Cart");
            tvPriceWithCartCount.setText(getString(R.string.price));
        }
    }

    private void priceCalculation() {
        changeCartItemSize();
        if (cartListItems != null && cartListItems.size() > 0) {

            if (cartListItems.size() == 1) {
                tvPriceWithCartCount.setText(getString(R.string.price) + " (" + cartListItems.size() + " item)");
            } else if (cartListItems.size() > 1) {
                tvPriceWithCartCount.setText(getString(R.string.price) + " (" + cartListItems.size() + " items)");
            }
            double totalTax = 0.0;
            double price = 0.0;
            double couponDiscount = 0.0;

            for (CartListItem cartListItem : cartListItems) {
                int quantity = cartListItem.getSCart_Quantity();
                totalTax += cartListItem.getSCart_TaxAmount() * quantity;
                price += cartListItem.getSCart_TotalAmount() * quantity;
            }
            if (couponList != null && couponList.size() > 0) {
                for (CouponBean couponBean : couponList) {
                    couponDiscount += couponBean.getCouponDiscount();
                }
            } //else {
            priceCouponLayout.setVisibility(View.GONE);
            viewCouponSeparator.setVisibility(View.GONE);
            //}
            tvTax.setText(getString(R.string.rupee_symbol) + " " + Utils.getFormattedAmountManageZero(totalTax));
            tvPrice.setText(getString(R.string.rupee_symbol) + " " + Utils.getFormattedAmount(price));
            // tvWellCashDiscount.setText(getString(R.string.rupee_symbol) + " " + Utils.getFormattedAmountManageZero(wellCash));
            tvCoupon.setText(getString(R.string.rupee_symbol) + " -" + Utils.getFormattedAmount(couponDiscount));
            double totalAmount = (price + totalTax) - (couponDiscount);

            // if user wellcash amount is greater than total amount of price, tax, coupon discount
           /* if (wellCash > (price + totalTax - couponDiscount)) {
                wellCash = price + totalTax - couponDiscount;
                tvWellCashDiscount.setText(getString(R.string.rupee_symbol) + " " + Utils.getFormattedAmountManageZero(wellCash));
                etPayByCash.setText(String.valueOf(wellCash));
                totalAmount = 0;
            }*/

            tvPriceTotal.setText(getString(R.string.rupee_symbol) + " " + Utils.getFormattedAmount(totalAmount));
            tvGrandPrice.setText(getString(R.string.rupee_symbol) + " " + Utils.getFormattedAmount(totalAmount));

            cartOrderDetailObject.setCartListItems(cartListItems);
            cartOrderDetailObject.setCouponList(couponList);
            cartOrderDetailObject.setCartItemsSize(cartListItems.size());
            cartOrderDetailObject.setCartIds(getCommaSeparatedString(cartListItems));
            cartOrderDetailObject.setCouponIds(getCommaSeparatedString(couponList));
            cartOrderDetailObject.setCouponDiscount(couponDiscount);
            cartOrderDetailObject.setGrandTotalAmount(totalAmount);
            cartOrderDetailObject.setTotalAmount(price);
            cartOrderDetailObject.setTotalTax(totalTax);
            cartOrderDetailObject.setTotalWellCashDiscount(0);

        }
    }


    /************ Update Cart Item API ************/

    public void UpdateQuantity(final int position, final int productId, final int quantity, final int cartId, final int vendorId, final boolean isPlus) {

        if (couponList != null && couponList.size() > 0 && cartOrderDetailObject != null && cartOrderDetailObject.getTotalWellCashDiscount() > 0) {
            DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, "Update quantity for the item will remove the coupon and WellCash. Are you sure want to update?", getString(R.string.str_yes), new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    dialogInterface.dismiss();
                    updateCartQuantityApiCall(position, productId, quantity, cartId, vendorId, isPlus);

                }
            }, "No", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    dialogInterface.dismiss();
                }
            }, false);
        } else if (couponList != null && couponList.size() > 0) {
            DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, "Update quantity for the item will remove the applied coupons. Are you sure want to update?", getString(R.string.str_yes), new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    dialogInterface.dismiss();
                    updateCartQuantityApiCall(position, productId, quantity, cartId, vendorId, isPlus);

                }
            }, "No", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    dialogInterface.dismiss();
                }
            }, false);
        } else if (cartOrderDetailObject != null && cartOrderDetailObject.getTotalWellCashDiscount() > 0) {
            DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, "Update quantity for the item will make the applied WellCash to be 0. Are you sure want to update?", getString(R.string.str_yes), new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    dialogInterface.dismiss();
                    updateCartQuantityApiCall(position, productId, quantity, cartId, vendorId, isPlus);

                }
            }, "No", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    dialogInterface.dismiss();
                }
            }, false);
        } else {
            updateCartQuantityApiCall(position, productId, quantity, cartId, vendorId, isPlus);
        }

    }

    private void updateCartQuantityApiCall(final int position, int productId, final int quantity, int cartId, int vendorId, final boolean isPlus) {
        final CustomProgressDialog pb;
        pb = new CustomProgressDialog(getActivity(), R.style.custom_progress_style, false);
        pb.show();

        //body
        UpdateCartQuantityBody updateCartQuantityBody = new UpdateCartQuantityBody();
        updateCartQuantityBody.setProductId(productId);
        updateCartQuantityBody.setQuantity(quantity);
        updateCartQuantityBody.setCartId(cartId);
        updateCartQuantityBody.setProductVendorID(vendorId);
        RestClient restClient = new RestClient(getActivity(), StoreConfig.BASE_URL, StoreConfig.mdebug);

        restClient.getStoreService().getUpdateCartQuantity(updateCartQuantityBody).enqueue(new Callback<UpdateCartQuantityResponse>() {
            @Override
            public void onResponse(Call<UpdateCartQuantityResponse> call, Response<UpdateCartQuantityResponse> response) {

                if (isAdded() && getActivity() != null) {
                    if (pb.isShowing()) {
                        pb.dismiss();
                    }
                    if (response != null && response.body() != null) {
                        if (response.body().getStatus() == 0 && response.body().getData() != null) {
                            couponList.clear();
                            setCouponList();

                            quantityUpdated(response.body().getData().getQuantity(), position);
                            priceCalculation();
                        } else if (response.body().getStatus() == -2) {
                            DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, "Product quantity is not available", getString(R.string.str_ok), false);
                        } else {
                            DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_response_failure), getString(R.string.str_ok), false);
                        }
                    } else {
                        DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_response_failure), getString(R.string.str_ok), false);
                    }
                }
            }

            @Override
            public void onFailure(Call<UpdateCartQuantityResponse> call, Throwable t) {
                if (isAdded() && getActivity() != null) {
                    if (pb.isShowing()) {
                        pb.dismiss();
                    }
                    DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_failure), getString(R.string.str_ok), false);
                }
            }
        });
    }

    private void quantityUpdated(int quantity, int position) {
        cartListItems.get(position).setSCart_Quantity(quantity);
        cartAdapter.notifyItemChanged(position);
    }

    public void deleteCartItem(final int position, final int cartId) {
        if (couponList != null && couponList.size() > 0 && cartOrderDetailObject != null && cartOrderDetailObject.getTotalWellCashDiscount() > 0) {
            DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, "Deleting item will remove the coupon and WellCash. Are you sure want to delete?", getString(R.string.str_yes), new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    dialogInterface.dismiss();
                    deleteCartApiCall(position, cartId);

                }
            }, "No", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    dialogInterface.dismiss();
                }
            }, false);
        } else if (couponList != null && couponList.size() > 0) {
            DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, "Deleting item will remove the applied coupons. Are you sure want to delete?", getString(R.string.str_yes), new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    dialogInterface.dismiss();
                    deleteCartApiCall(position, cartId);

                }
            }, "No", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    dialogInterface.dismiss();
                }
            }, false);
        } else if (cartOrderDetailObject != null && cartOrderDetailObject.getTotalWellCashDiscount() > 0) {
            DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, "Deleting item will make the applied WellCash to be 0. Are you sure want to delete?", getString(R.string.str_yes), new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    dialogInterface.dismiss();
                    deleteCartApiCall(position, cartId);

                }
            }, "No", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    dialogInterface.dismiss();
                }
            }, false);
        } else {
            DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, "Are you sure to remove this item from the cart?", getString(R.string.yes), new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    dialogInterface.cancel();
                    deleteCartApiCall(position, cartId);

                }
            }, getString(R.string.no), false);

        }
    }

    /************ Delete Cart Item API ************/

    private void deleteCartApiCall(final int position, int cartId) {

        final CustomProgressDialog pb;
        pb = new CustomProgressDialog(getActivity(), R.style.custom_progress_style, false);
        pb.show();

        //body
        DeleteCartItemBody deleteCartItemBody = new DeleteCartItemBody();
        deleteCartItemBody.setCartID(cartId);
        RestClient restClient = new RestClient(getActivity(), StoreConfig.BASE_URL, StoreConfig.mdebug);

        restClient.getStoreService().getDeleteCartItem(deleteCartItemBody).enqueue(new Callback<DeleteCartItemResponse>() {
            @Override
            public void onResponse(Call<DeleteCartItemResponse> call, Response<DeleteCartItemResponse> response) {

                if (isAdded() && getActivity() != null) {
                    if (pb.isShowing()) {
                        pb.dismiss();
                    }
                    if (response != null && response.body() != null) {
                        if (response.body().getStatus() == 0 && response.body().getData() != null) {
                            couponList.clear();
                            setCouponList();

                            cartListItems.remove(position);
                            cartAdapter.notifyDataSetChanged();
                            priceCalculation();
                            if (cartListItems.size() == 0) {
                                rlNoData.setVisibility(View.VISIBLE);
                                rlStoreData.setVisibility(View.GONE);
                            } else {
                                rlNoData.setVisibility(View.GONE);
                                rlStoreData.setVisibility(View.VISIBLE);
                            }
                        } else {
                            DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_response_failure), getString(R.string.str_ok), false);
                        }
                    } else {
                        DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_response_null), getString(R.string.str_ok), false);
                    }
                }
            }

            @Override
            public void onFailure(Call<DeleteCartItemResponse> call, Throwable t) {
                if (isAdded() && getActivity() != null) {
                    if (pb.isShowing()) {
                        pb.dismiss();
                    }
                    DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_failure), getString(R.string.str_ok), false);
                }
            }
        });
    }


    /**
     * Coupon related APIs & Methods
     */

    private void callApplyCoupon() {
        final String couponCode = etCoupon.getText().toString().trim();
        if (couponCode.isEmpty()) {
            return;
        }
        if (cartOrderDetailObject.getGrandTotalAmount() == 0) {
            Utils.showToast(getActivity(), "Coupon does not apply on your cart because grand total already 0");
            return;
        }
        for (CouponBean couponBean : couponList) {
            if (couponBean.getCouponCode().equalsIgnoreCase(couponCode)) {
                Utils.showToast(getActivity(), couponCode + " is already applied.");
                return;
            }
        }
        final CustomProgressDialog pd;
        pd = new CustomProgressDialog(getActivity(), R.style.custom_progress_style, false);
        pd.show();
        ApplyCouponBody applyCouponBody = new ApplyCouponBody();
        applyCouponBody.setCouponCode(couponCode);
        applyCouponBody.setMemberId(Integer.parseInt(StoreConfig.storeUser.getMemberId()));
        applyCouponBody.setCartIds(getCommaSeparatedString(cartListItems));
        applyCouponBody.setCouponIds(getCommaSeparatedString(couponList));
        RestClient restClient = new RestClient(getActivity(), StoreConfig.BASE_URL, StoreConfig.mdebug);

        restClient.getStoreService().applyCoupon(applyCouponBody).enqueue(new Callback<ApplyCouponResponse>() {
            @Override
            public void onResponse(Call<ApplyCouponResponse> call, final Response<ApplyCouponResponse> response) {

                if (isAdded() && getActivity() != null) {
                    if (pd.isShowing()) {
                        pd.dismiss();
                    }
                    if (response != null && response.body() != null) {
                        if (response.body().getStatus() == 0) {
                            etCoupon.setText("");
                            if (response.body().getCoupon().getCouponStatus() == 1) {  // Case where coupon is successfully applied, with clashes
                                CouponItem couponItem = response.body().getCoupon();
                                CouponBean couponBean = new CouponBean();
                                couponBean.setCouponCode(couponCode);
                                couponBean.setCouponDiscount(couponItem.getCouponDiscount());
                                couponBean.setCouponId(couponItem.getCouponID());
                                couponList.add(couponBean);
                                setCouponList();
                                Utils.showToast(getActivity(), response.body().getCoupon().getMessage());
                                priceCalculation();
                            } else if (response.body().getCoupon().getCouponStatus() == -1) {  // Case where coupon clashes with one or more coupon
                                String message = response.body().getCoupon().getMessage();

                                final StringBuilder stringBuilder = new StringBuilder("Coupon " + couponCode);
                                stringBuilder.append(" clash with coupon ");
                                final ArrayList<CouponItem.ClashCouponItem> clashCouponList = (ArrayList<CouponItem.ClashCouponItem>) response.body().getCoupon().getClashCoupon();

                                // find all the clashes coupon code and appends them into a string to show it to user
                                for (CouponItem.ClashCouponItem clashCouponItem : clashCouponList) {
                                    stringBuilder.append(clashCouponItem.getCode()).append(",");
                                }

                                if (stringBuilder.lastIndexOf(",") != -1) {
                                    stringBuilder.deleteCharAt(stringBuilder.lastIndexOf(","));
                                }
                                stringBuilder.append(". Do you want to replace coupon ?");

                                // If user agrees to remove existing coupon then remove it from our list, as well as layout
                                DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, stringBuilder.toString(), getString(R.string.str_replace), new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        Iterator<CouponBean> iterator = couponList.iterator();
                                        while (iterator.hasNext()) {
                                            CouponBean couponBean = iterator.next();
                                            for (CouponItem.ClashCouponItem clashCouponItem : clashCouponList) {
                                                if (clashCouponItem.getCouponID() == couponBean.getCouponId()) {
                                                    // Remove all coupon that clashes
                                                    iterator.remove();
                                                }
                                            }
                                        }

                                        // Add new coupon after removing all coupon that clashes with it
                                        CouponItem couponItem = response.body().getCoupon();
                                        CouponBean newCouponBean = new CouponBean();
                                        newCouponBean.setCouponCode(couponCode);
                                        newCouponBean.setCouponDiscount(couponItem.getCouponDiscount());
                                        newCouponBean.setCouponId(couponItem.getCouponID());
                                        couponList.add(newCouponBean);
                                        setCouponList();
                                        priceCalculation();
                                    }
                                }, getString(R.string.str_cancel), false);
                            } else if (response.body().getCoupon().getCouponStatus() == 0) {
                                String message = response.body().getCoupon().getMessage();
                                DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, message, getString(R.string.str_ok), false);
                            }
                        } else {
                            DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_response_failure), getString(R.string.str_ok), false);
                        }
                    }
                }
            }

            @Override
            public void onFailure(Call<ApplyCouponResponse> call, Throwable t) {
                if (getActivity() != null && isAdded()) {
                    pd.dismiss();
                    DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_failure), getString(R.string.str_ok), false);
                }
            }
        });
    }

    private void setCouponList() {
        couponListLayout.removeAllViews();
        for (int i = 0; i < couponList.size(); i++) {
            View view = getActivity().getLayoutInflater().inflate(R.layout.row_store_coupon_list, null);
            final CustomTextView etCouponName = view.findViewById(R.id.etCouponName);
            CustomTextView tvCouponPrice = view.findViewById(R.id.tvCouponPrice);
            ImageView ivCouponCancel = view.findViewById(R.id.ivCouponCancel);
            ivCouponCancel.setTag(i);
            etCouponName.setText(couponList.get(i).getCouponCode());
            tvCouponPrice.setText(getString(R.string.rupee_symbol) + " -" + Utils.getFormattedAmount(couponList.get(i).getCouponDiscount()));

            ivCouponCancel.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(final View view) {
                    DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, "Are you sure to remove " + etCouponName.getText().toString() + " coupon?", getString(R.string.yes), new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            dialogInterface.cancel();
                            couponList.remove(Integer.parseInt(view.getTag().toString()));
                            setCouponList();
                            priceCalculation();
                        }
                    }, getString(R.string.no), false);

                }
            });
            couponListLayout.addView(view);
        }
        if (couponListLayout.getChildCount() == 0) {
            priceCouponLayout.setVisibility(View.GONE);
            viewCouponSeparator.setVisibility(View.GONE);
        } /*else {
            priceCouponLayout.setVisibility(View.VISIBLE);
            viewCouponSeparator.setVisibility(View.VISIBLE);
        }*/
    }

    private String getCommaSeparatedString(ArrayList<?> listOfObjects) {
        StringBuilder sb = new StringBuilder();
        for (Object o : listOfObjects) {
            if (o instanceof CouponBean) {
                sb.append(((CouponBean) o).getCouponId()).append(",");
            } else if (o instanceof CartListItem) {
                sb.append(((CartListItem) o).getSCart_Id()).append(",");
            }
        }
        if (sb.lastIndexOf(",") != -1) {
            sb.deleteCharAt(sb.lastIndexOf(","));
        }

        return sb.toString();
    }

    @Override
    public void onRetry() {
        myCartApiCall();
    }
}
