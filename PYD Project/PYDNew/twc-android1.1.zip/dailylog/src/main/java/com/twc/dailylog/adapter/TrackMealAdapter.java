package com.twc.dailylog.adapter;

import android.app.Activity;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;


import com.twc.dailylog.R;
import com.twc.dailylog.fragments.AddFoodFragment;
import com.twc.dailylog.model.beans.FoodItem;
import com.twc.dailylog.utils.Utils;

import java.util.ArrayList;

/**
 * Created by ManishJ1 on 7/5/2016.
 */
public class TrackMealAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private ArrayList<FoodItem> mFoodItemArrayList;
    private Activity activity;

    public TrackMealAdapter(ArrayList<FoodItem> mFoodItemArrayList, Activity activity) {
        this.mFoodItemArrayList = mFoodItemArrayList;
        this.activity = activity;
    }


    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.row_trackmeal_diet_paln, parent, false);

        return new ItemViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        ItemViewHolder itemViewHolder = (ItemViewHolder) holder;
        itemViewHolder.tvFoodName.setText(mFoodItemArrayList.get(position).getFoodName());
        itemViewHolder.tvFoodData.setText(String.format("%s %s %s Calories", mFoodItemArrayList.get(position).getQuantity(), mFoodItemArrayList.get(position).getStandardServing(), Math.round(mFoodItemArrayList.get(position).getCalories())));
    }

    @Override
    public int getItemCount() {
        return mFoodItemArrayList.size();
    }

    // ItemViewHolder Class for Items in each Section
    public class ItemViewHolder extends RecyclerView.ViewHolder {

        final TextView tvFoodName;
        final TextView tvFoodData;

        public ItemViewHolder(View itemView) {
            super(itemView);
            tvFoodName = itemView.findViewById(R.id.tvFoodName);
            tvFoodData = itemView.findViewById(R.id.tvFoodData);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Bundle bundle = new Bundle();
                    bundle.putInt("foodId",mFoodItemArrayList.get(getLayoutPosition()).getFoodID());
                    bundle.putInt("nutritionId",0);
                    double quantity ;
                    try {
                        quantity = Double.parseDouble(mFoodItemArrayList.get(getLayoutPosition()).getQuantity());
                    }
                    catch (ArithmeticException e){
                        quantity = 0.0;
                    }
                    bundle.putDouble("quantity",quantity);

                    Utils.replaceFragment(activity.getFragmentManager(), AddFoodFragment.newInstance(bundle),AddFoodFragment.class.getSimpleName(),true,R.id.fragmentContainerMeal);
                }
            });
        }
    }
}
