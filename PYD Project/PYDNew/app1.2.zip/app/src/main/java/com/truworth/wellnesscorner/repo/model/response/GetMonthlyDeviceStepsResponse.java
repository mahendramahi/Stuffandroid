package com.truworth.wellnesscorner.repo.model.response;

import com.google.gson.annotations.SerializedName;
import com.truworth.wellnesscorner.ui.step.DeviceStepsItem;

import java.util.List;

/**
 * If this code works it was written by Somesh Kumar on 26 September, 2017. If not, I don't know who wrote it.
 */
public class GetMonthlyDeviceStepsResponse {

    private int status;
    @SerializedName("Data")
    private List<DeviceStepsItem> StepData;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public List<DeviceStepsItem> getStepData() {
        return StepData;
    }

    public void setStepData(List<DeviceStepsItem> StepData) {
        this.StepData = StepData;
    }


}
