package com.truworth.wellnesscorner.model;

import java.util.List;

public class EventCheckInData {
    private EventDataItem eventData;
    private int status;
    private String message;

    public EventDataItem getEventData() {
        return eventData;
    }

    public void setEventData(EventDataItem eventData) {
        this.eventData = eventData;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
