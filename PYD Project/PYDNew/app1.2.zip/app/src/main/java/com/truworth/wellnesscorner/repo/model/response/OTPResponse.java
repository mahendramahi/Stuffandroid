package com.truworth.wellnesscorner.repo.model.response;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.truworth.wellnesscorner.model.LoginData;
import com.truworth.wellnesscorner.model.OTPData;

/**
 * Created by rajeshs on 4/2/2018.
 */

public class OTPResponse {

   // {"data":{"otpSessionId":"QziUgLhDsMCveUEqieXbNjfm2rwsF75TrNsqgks0ys6iJifzth6W+aFRtqFLYqB7UQdaNPLvKYfGvEUSH/YV006RiL442YTr0hgm8JLcB9uf7n2a2TV7efSymGXI3518GwRnpjO4ELQ0dMdDQ7bH72uomlJGCZt2QR6NG4va3rA="},"hasError":false,"error":null}


    @SerializedName("data")
    @Expose
    private OTPData data;
    @SerializedName("hasError")
    @Expose
    private boolean hasError;

    @SerializedName("message")
    @Expose
    private String message;

    @SerializedName("error")
    @Expose
    private Error error;

    public OTPData getData() {
        return data;
    }

    public void setData(OTPData data) {
        this.data = data;
    }

    public boolean isHasError() {
        return hasError;
    }

    public void setHasError(boolean hasError) {
        this.hasError = hasError;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Error getError() {
        return error;
    }

    public void setError(Error error) {
        this.error = error;
    }



}
