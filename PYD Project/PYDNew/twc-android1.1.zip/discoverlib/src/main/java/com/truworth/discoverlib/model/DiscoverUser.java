package com.truworth.discoverlib.model;

/**
 * Created by ManishJ1 on 3/20/2018.
 */

public class DiscoverUser {

    private String userID;
    private String accessToken;

    public DiscoverUser() {

    }

    public DiscoverUser(String userID,   String accessToken) {
        this.userID = userID;
        this.accessToken = accessToken;
    }

    public String getAccessToken() {
        return accessToken;
    }

    public void setAccessToken(String accessToken) {
        this.accessToken = accessToken;
    }

    public String getUserID() {
        return userID;
    }

    public void setUserID(String userID) {
        this.userID = userID;
    }
}
