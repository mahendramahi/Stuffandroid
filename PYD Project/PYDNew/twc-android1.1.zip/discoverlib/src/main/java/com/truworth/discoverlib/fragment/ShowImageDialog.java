package com.truworth.discoverlib.fragment;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.view.Window;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.bumptech.glide.request.target.BitmapImageViewTarget;
import com.bumptech.glide.request.transition.Transition;
import com.truworth.discoverlib.R;
import com.truworth.discoverlib.R2;
import com.truworth.discoverlib.utils.ZoomableImageView;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * Created by GurvinderS on 8/9/2016.
 */
public class ShowImageDialog extends Dialog  {

    @BindView(R2.id.pb)
    ProgressBar pb;
  /*  @BindView(R.id.mainLayout)
    RelativeLayout mainLayout;*/

    @BindView(R2.id.imgShow)
    ZoomableImageView imgShow;

    private Context context;
    private String imageURL;
    private String mFilePath;


    public ShowImageDialog(Context context, String url, String filePath) {

        super(context, R.style.image_dialog_theme);

        this.context = context;

        this.imageURL = url;
        this.mFilePath=filePath;

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.dialog_show_image);
        ButterKnife.bind(this);
        //mainLayout.setBackgroundColor(ContextCompat.getColor(getContext(),R.color.colorPrimary));

        if(!mFilePath.isEmpty()){
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inPreferredConfig = Bitmap.Config.ARGB_8888;
            Bitmap bitmapTemp = BitmapFactory.decodeFile(mFilePath, options);
            if(bitmapTemp!=null)
                imgShow.setImageBitmap(bitmapTemp);
        }
        else {
            /*WellnessCornerApp.getInstance().getImageLoader().load(imageURL).listener(new RequestListener<String, GlideDrawable>() {
                @Override
                public boolean onException(Exception e, String model, Target<GlideDrawable> target, boolean isFirstResource) {
                    if(e instanceof UnknownHostException)
                        pb.setVisibility(View.VISIBLE);
                    return false;
                }

                @Override
                public boolean onResourceReady(GlideDrawable resource, String model, Target<GlideDrawable> target, boolean isFromMemoryCache, boolean isFirstResource) {
                    pb.setVisibility(View.GONE);
                    return false;
                }
            }).asBitmap().into(imgShow);*/

            // set image height width to show the large images
            /*WellnessCornerApp.getInstance().getImageLoader().load(imageURL).asBitmap().override(600, 400).into(new BitmapImageViewTarget(imgShow) {
                @Override
                public void onLoadFailed(Exception e, Drawable errorDrawable) {
                    super.onLoadFailed(e, errorDrawable);
                    pb.setVisibility(View.VISIBLE);
                }

                @Override
                public void onResourceReady(Bitmap drawable, GlideAnimation anim) {
                    super.onResourceReady(drawable, anim);
                    pb.setVisibility(View.GONE);
                }
            });*/
            Glide.with(context).asBitmap().load(imageURL).apply(new RequestOptions().override(600, 400)).into(new BitmapImageViewTarget(imgShow) {
                @Override
                public void onLoadFailed(@Nullable Drawable errorDrawable) {
                    super.onLoadFailed(errorDrawable);
                    //pb.setVisibility(View.VISIBLE);
                    Toast.makeText(context,"Image not found!", Toast.LENGTH_SHORT ).show();
                }

                @Override
                public void onResourceReady(Bitmap resource, @Nullable Transition<? super Bitmap> transition) {
                    super.onResourceReady(resource, transition);
                    pb.setVisibility(View.GONE);
                }
            });
        }

    }

    @OnClick(R2.id.ivBack)
    public void backClick()
    {
        onBackPressed();
    }
}