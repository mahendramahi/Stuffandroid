package com.truworth.wellnesscorner.ui.mainapp.more;

import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.View;

import com.truworth.discoverlib.DiscoverActivity;
import com.truworth.discoverlib.model.DiscoverUser;
import com.truworth.discoverlib.utils.DiscoverConfig;
import com.truworth.wellnesscorner.BR;
import com.truworth.wellnesscorner.R;
import com.truworth.wellnesscorner.TheWellnessCornerApp;
import com.truworth.wellnesscorner.base.BaseFragment;
import com.truworth.wellnesscorner.data.SharedPreferenceHelper;
import com.truworth.wellnesscorner.databinding.FragmentMoreOptionsBinding;
import com.truworth.wellnesscorner.ui.login.LoginCategoryActivity;
import com.truworth.wellnesscorner.ui.login.LoginCategoryViewModel;
import com.truworth.wellnesscorner.ui.login.LoginEmailFragment;
import com.truworth.wellnesscorner.utils.AppConstants;
import com.twc.hramodule.HraActivity;
import com.twc.hramodule.model.beans.HraUser;
import com.twc.hramodule.utils.HraConfig;
import com.twc.store.StoreActivity;
import com.twc.store.model.beans.StoreUser;
import com.twc.store.utils.StoreConfig;

import javax.inject.Inject;


/**
 * Created by PalakC on 4/16/2018.
 */

public class MoreOptionsFragment extends BaseFragment<FragmentMoreOptionsBinding, MoreOptionViewModel> {
    public static final String TAG = "moreOptions";
    FragmentMoreOptionsBinding binding;
    MoreOptionViewModel viewModel;
    @Inject
    SharedPreferenceHelper prefHelper;

    public MoreOptionsFragment() {
        TheWellnessCornerApp.getApp().component().inject(this);
    }


    @Override
    public int getBindingVariable() {
        return BR.viewModel;
    }

    @Override
    public int getLayoutId() {
        return R.layout.fragment_more_options;
    }

    @Override
    public MoreOptionViewModel getViewModel() {
        viewModel = ViewModelProviders.of(this).get(MoreOptionViewModel.class);
        return viewModel;
    }

    @Override
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        binding = getViewDataBinding();
        setDataObserver();
    }

    private void setDataObserver() {
        viewModel.getOnHraClick().observe(this, new Observer<Void>() {
            @Override
            public void onChanged(@Nullable Void aVoid) {
                HraUser hraUser = new HraUser("0", "Male", "Premium",
                        "bearer " + prefHelper.getToken());
                HraConfig.init("Wellness", AppConstants.API_ENDPOINT, hraUser, false);

                startHra(getActivity());
            }
        });

        viewModel.getOnStoreClick().observe(this, new Observer<Void>() {
            @Override
            public void onChanged(@Nullable Void aVoid) {

                StoreUser storeUser = new StoreUser(prefHelper.getUserName(), "9834989393", prefHelper.getEmailId(), "0", "Male", "Premium",
                        "bearer " + prefHelper.getToken());
                StoreConfig.init("Wellness", AppConstants.API_ENDPOINT, storeUser, true);

                if (!StoreConfig.APP_NAME.isEmpty() && !StoreConfig.BASE_URL.isEmpty() && StoreConfig.storeUser != null) {
                    Intent intent = new Intent(getActivity(), StoreActivity.class);
                    startActivity(intent);
                } else {
                }
            }
        });

        viewModel.getOnLogoutClick().observe(this, new Observer<Void>() {
            @Override
            public void onChanged(@Nullable Void aVoid) {

                prefHelper.clearPrefData();
                Intent intent = new Intent(getActivity(), LoginCategoryActivity.class);
                startActivity(intent);
                getActivity().finish();

            }
        });
        /*        viewModel.getOnReminderClick().observe(this, new Observer<Void>() {
            @Override
            public void onChanged(@Nullable Void aVoid) {
                ReminderUser reminderUser = new ReminderUser("0", true, "bearer " + prefHelper.getToken());
                ReminderConfig.init("Wellness", AppConstants.API_ENDPOINT, reminderUser, false);

                if (!ReminderConfig.APP_NAME.isEmpty() && !ReminderConfig.BASE_URL.isEmpty() && ReminderConfig.reminderUser != null) {
                    Intent intent = new Intent(getActivity(), ReminderActivity.class);
                    startActivity(intent);
                } else {
                    Log.d("reminderlib", "reminderlib: not initialised in right way.");
                }
            }
        });*/
        /* viewModel.getOnDisCoverClick().observe(this, new Observer<Void>() {
            @Override
            public void onChanged(@Nullable Void aVoid) {
                DiscoverUser discoverUser = new DiscoverUser("0", "bearer " + prefHelper.getToken());
                DiscoverConfig.init("Wellness", AppConstants.API_ENDPOINT, discoverUser, false);

                if (!DiscoverConfig.APP_NAME.isEmpty() && !DiscoverConfig.BASE_URL.isEmpty() && DiscoverConfig.discoverUser != null) {
                    Intent intent = new Intent(getActivity(), DiscoverActivity.class);
                    startActivity(intent);
                } else {
                    Log.d("discoverlib", "discoverlib: not initialised in right way.");
                }
            }
        });*/
    }
    public void startHra(Context activity) {
        if (!HraConfig.APP_NAME.isEmpty() && !HraConfig.BASE_URL.isEmpty() && HraConfig.hraUser != null) {
            Intent intent = new Intent(activity, HraActivity.class);
            activity.startActivity(intent);
        } else {
            Log.d("Hra", "hralib: not initialised in right way.");
        }
    }

}
