package com.truworth.wellnesscorner.ui.mainapp.createpost.shareexercise;

import com.truworth.wellnesscorner.TheWellnessCornerApp;
import com.truworth.wellnesscorner.base.BaseViewModel;
import com.truworth.wellnesscorner.model.ShareExerciseBean;
import com.truworth.wellnesscorner.repo.CreatePostRepository;
import com.truworth.wellnesscorner.repo.model.request.ShareMealRequest;
import com.truworth.wellnesscorner.repo.model.response.ShareExerciseResponse;
import com.truworth.wellnesscorner.utils.SingleLiveEvent;

import java.util.List;

import javax.inject.Inject;

import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;

public class ShareExerciseListViewModel extends BaseViewModel {
    public boolean loading;
    public boolean isLastResult = false;
    public SingleLiveEvent<Void> removeLoading = new SingleLiveEvent<>();
    public SingleLiveEvent<List<ShareExerciseBean>> headerList = new SingleLiveEvent<>();
    @Inject
    CreatePostRepository createPostRepository;

    public ShareExerciseListViewModel() {
        TheWellnessCornerApp.getApp().component().inject(this);
    }

    public SingleLiveEvent<Void> getRemoveLoading() {
        return removeLoading;
    }

    public SingleLiveEvent<List<ShareExerciseBean>> getHeaderList() {
        return headerList;
    }
    SingleLiveEvent<Void> trackTodayExercise = new SingleLiveEvent<Void>();

    public SingleLiveEvent<Void> getTrackTodayExercise() {
        return trackTodayExercise;
    }

    public void loadMealPostData(int pageIndex) {
        ShareMealRequest shareMealRequest = new ShareMealRequest();
        shareMealRequest.setPageIndex(pageIndex);

        createPostRepository.getPostExercise(shareMealRequest).subscribe(new Observer<ShareExerciseResponse>() {
            @Override
            public void onSubscribe(Disposable d) {

            }

            @Override
            public void onNext(ShareExerciseResponse response) {
                setIsLoading(false);
                removeLoading.call();
                loading = false;

                if (!response.isHasError()) {
                    headerList.setValue(response.getData());

                } else {

                }
            }

            @Override
            public void onError(Throwable e) {
                removeLoading.call();
            }

            @Override
            public void onComplete() {

            }
        });
    }

    public void trackTodayExerciseBtn(){
        trackTodayExercise.call();
    }
}
