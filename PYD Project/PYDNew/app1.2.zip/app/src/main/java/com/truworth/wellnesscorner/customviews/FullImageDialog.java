package com.truworth.wellnesscorner.customviews;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.view.Window;
import android.widget.ImageView;
import android.widget.ProgressBar;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.bumptech.glide.request.target.BitmapImageViewTarget;
import com.bumptech.glide.request.transition.Transition;
import com.truworth.wellnesscorner.R;
import com.truworth.wellnesscorner.utils.ZoomableImageView;

public class FullImageDialog extends Dialog {

    private Context context;
    private String imageURL;
    private String mFilePath;

    public FullImageDialog(Context context, String url,String filePath) {

        super(context, R.style.image_dialog_theme);

        this.context = context;
        this.imageURL = url;
        this.mFilePath=filePath;
        }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.dialog_image);
        ZoomableImageView imgShow=(ZoomableImageView)findViewById(R.id.imgShow);
        ProgressBar pb=(ProgressBar)findViewById(R.id.pb);
        ImageView ivBack=(ImageView)findViewById(R.id.ivBack);

        if(!mFilePath.isEmpty()){
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inPreferredConfig = Bitmap.Config.ARGB_8888;
            Bitmap bitmapTemp = BitmapFactory.decodeFile(mFilePath, options);
            if(bitmapTemp!=null)
                imgShow.setImageBitmap(bitmapTemp);
        } else {
          Glide.with(context).asBitmap().load(imageURL).apply(new RequestOptions().override(600, 400)).into(new BitmapImageViewTarget(imgShow) {
                @Override
                public void onLoadFailed(@Nullable Drawable errorDrawable) {
                    super.onLoadFailed(errorDrawable);
                    pb.setVisibility(View.VISIBLE);
                }

                @Override
                public void onResourceReady(Bitmap resource, @Nullable Transition<? super Bitmap> transition) {
                    super.onResourceReady(resource, transition);
                    pb.setVisibility(View.GONE);
                }
            });
        }

        ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
    }
}
