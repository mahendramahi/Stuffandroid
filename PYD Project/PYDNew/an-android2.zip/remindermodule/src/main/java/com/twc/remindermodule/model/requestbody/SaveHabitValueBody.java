package com.twc.remindermodule.model.requestbody;

/**
 * Created by GurvinderS on 11/17/2017.
 */

public class SaveHabitValueBody {

    public boolean isValue() {
        return value;
    }

    public void setValue(boolean value) {
        this.value = value;
    }

    public boolean value;


    public int getHabitID() {
        return HabitID;
    }

    public void setHabitID(int habitID) {
        HabitID = habitID;
    }

    public int HabitID;
    private String MemberID;

    public String getMemberID() {
        return MemberID;
    }

    public void setMemberID(String MemberID) {
        this.MemberID = MemberID;
    }
}
