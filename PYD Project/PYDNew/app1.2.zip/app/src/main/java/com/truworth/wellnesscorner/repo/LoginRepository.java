package com.truworth.wellnesscorner.repo;

import com.truworth.wellnesscorner.network.ApiServices;
import com.truworth.wellnesscorner.repo.model.request.EmailRequest;
import com.truworth.wellnesscorner.repo.model.request.GetCountryStateByCityNameRequest;
import com.truworth.wellnesscorner.repo.model.request.CityIdRequest;
import com.truworth.wellnesscorner.repo.model.request.LoginRequest;
import com.truworth.wellnesscorner.repo.model.request.OTPRequest;
import com.truworth.wellnesscorner.repo.model.request.SaveCityRequest;
import com.truworth.wellnesscorner.repo.model.request.SaveMemberRequest;
import com.truworth.wellnesscorner.repo.model.request.VerifyOtpRequest;
import com.truworth.wellnesscorner.repo.model.response.CountryResponse;
import com.truworth.wellnesscorner.repo.model.response.EmailExistResponse;
import com.truworth.wellnesscorner.repo.model.response.GetCountryStateByCityNameResponse;
import com.truworth.wellnesscorner.repo.model.response.LoginResponse;
import com.truworth.wellnesscorner.repo.model.response.OTPResponse;
import com.truworth.wellnesscorner.repo.model.response.RegisterOtpResponse;
import com.truworth.wellnesscorner.repo.model.response.RegisterOtpVerifyResponse;
import com.truworth.wellnesscorner.repo.model.response.ResetPasswordResponse;
import com.truworth.wellnesscorner.repo.model.response.SaveCityResponse;
import com.truworth.wellnesscorner.repo.model.response.StateByCountryResponse;
import com.truworth.wellnesscorner.repo.model.response.SaveMemberResponse;
import com.truworth.wellnesscorner.repo.model.response.VerifyOtpResponse;

import javax.inject.Inject;
import javax.inject.Singleton;

import io.reactivex.Observable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.annotations.NonNull;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;

/**
 * Created by rajeshs on 3/29/2018.
 */
@Singleton
public class LoginRepository {
    private final ApiServices apiService;

    @Inject
    public LoginRepository(ApiServices apiService) {

        this.apiService = apiService;
    }


    public Observable<EmailExistResponse> checkEmailExist(EmailRequest emailId) {
        return apiService.isEmailExist(emailId)
                .subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread())
                .doOnNext(new Consumer<EmailExistResponse>() {
                    @Override
                    public void accept(@NonNull EmailExistResponse products) throws Exception {

                    }
                });
    }

    public Observable<LoginResponse> login(LoginRequest loginRequest) {
        return apiService.login(loginRequest)
                .subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread())
                .doOnNext(new Consumer<LoginResponse>() {
                    @Override
                    public void accept(@NonNull LoginResponse loginResponse) throws Exception {

                    }
                });
    }

    public Observable<ResetPasswordResponse> resetPassword(EmailRequest emailRequest) {
        return apiService.resetPassword(emailRequest)
                .subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread());

    }

    public Observable<CountryResponse> getCountryList() {
        return apiService.getCountryList()
                .subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread());
    }

    public Observable<StateByCountryResponse> getStateList(CityIdRequest idRequest) {
        return apiService.getStateList(idRequest)
                .subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread());
    }

    public Observable<GetCountryStateByCityNameResponse> getCountryStateList(GetCountryStateByCityNameRequest getCountryStateByCityNameRequest) {
        return apiService.getCountryStateList(getCountryStateByCityNameRequest)
                .subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread());
    }

    public Observable<SaveCityResponse> saveMembeCity(SaveCityRequest saveCityRequest) {
        return apiService.saveMembeCity(saveCityRequest)
                .subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread());
    }
    public Observable<StateByCountryResponse> getCityList(CityIdRequest idRequest) {
        return apiService.getCityList(idRequest)
                .subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread());
    }

    public Observable<OTPResponse> sendOTP(OTPRequest otpRequest) {
        return apiService.sendOtp(otpRequest)
                .subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread());
    }

    public Observable<RegisterOtpResponse> sendOTPForRegistration(OTPRequest otpRequest) {
        return apiService.sendOtpForRegistration(otpRequest)
                .subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread());
    }

    public Observable<VerifyOtpResponse> verifyOTP(VerifyOtpRequest otpRequest) {
        return apiService.getVerifyOtp(otpRequest)
                .subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread());
    }

    public Observable<RegisterOtpVerifyResponse> verifyOTPRegistration(VerifyOtpRequest otpRequest) {
        return apiService.getVerifyOtpRegister(otpRequest)
                .subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread());
    }

    public Observable<SaveMemberResponse> saveMember(SaveMemberRequest request) {
        return apiService.saveMemberRegistration(request).subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread());
    }


}
