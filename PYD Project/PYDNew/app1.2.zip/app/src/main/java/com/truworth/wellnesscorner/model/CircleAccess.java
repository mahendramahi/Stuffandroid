package com.truworth.wellnesscorner.model;

public class CircleAccess {
    private boolean isOpen;
    private boolean isContentVisibleToAll;

    public boolean isOpen() {
        return isOpen;
    }

    public void setOpen(boolean open) {
        isOpen = open;
    }

    public boolean isContentVisibleToAll() {
        return isContentVisibleToAll;
    }

    public void setContentVisibleToAll(boolean contentVisibleToAll) {
        isContentVisibleToAll = contentVisibleToAll;
    }
}
