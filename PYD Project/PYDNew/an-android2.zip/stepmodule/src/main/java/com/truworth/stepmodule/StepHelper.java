package com.truworth.stepmodule;

import android.content.Context;
import android.database.Cursor;
import android.support.annotation.NonNull;

import com.samsung.android.sdk.healthdata.HealthConnectionErrorResult;
import com.samsung.android.sdk.healthdata.HealthConstants;
import com.samsung.android.sdk.healthdata.HealthDataObserver;
import com.samsung.android.sdk.healthdata.HealthDataResolver;
import com.samsung.android.sdk.healthdata.HealthDataService;
import com.samsung.android.sdk.healthdata.HealthDataStore;
import com.samsung.android.sdk.healthdata.HealthResultHolder;
import com.truworth.stepmodule.inteface.OnRangeStepsFound;
import com.truworth.stepmodule.inteface.OnTodayStepsFound;
import com.truworth.stepmodule.model.FitBitResponse;
import com.truworth.stepmodule.model.FitBitStepsItem;
import com.truworth.stepmodule.model.GetMisFitResponse;
import com.truworth.stepmodule.model.StepItem;
import com.truworth.stepmodule.rest.FitBitRestClient;
import com.truworth.stepmodule.utils.Constant;
import com.truworth.stepmodule.utils.FitBitConfig;
import com.truworth.stepmodule.utils.NetworkFactory;
import com.truworth.stepmodule.utils.Utils;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * If this code works, it was written by Somesh Kumar  on 26 April, 2018. If not, I don't know who wrote it.
 */
public class StepHelper {
    private static final String SAMSUNG_DIGITAL_HEALTH_CUSTOM_DATA_TYPE = "com.samsung.shealth.step_daily_trend";
    private static final String SAMSUNG_DIGITAL_HEALTH_DATE_KEY = "day_time"; // Do not modify
    private static final String SAMSUNG_DIGITAL_HEALTH_SOURCE_KEY = "source_type"; // Do not modify
    private static final String DATE_FORMAT_YYYY_MM_DD = "yyyy-MM-dd"; // Modify only if you know what you are you doing
    private static final int STEPS_FROM_LOCAL_DEVICES = 0;
    public static final String DATE_FORMAT_MM_DD_YYYY_HHMM_FORWARD_SLASH = "MM/dd/yyyy HH:mm:ss.SSS";
    private String token;
    private Context context;
    private OnTodayStepsFound onTodayStepsFound;
    private long fromMillis;
    private long toMillis;
    private OnRangeStepsFound onRangeStepsFound;
    private HealthDataStore samsungHealthDataStore;
    private HealthDataObserver sHealthMonthlyObserver;
    private HealthDataObserver sHealthTodayObserver;
    private HealthResultHolder.ResultListener<HealthDataResolver.ReadResult> sHealthMonthlyResultCallback;
    private ArrayList<StepItem> foundStepList;
    private HealthResultHolder.ResultListener<HealthDataResolver.ReadResult> sHealthTodayResultCallback;

    public StepHelper() {
        throw new Error("Can't use default constructor");
    }

    public StepHelper(Context context, String token) {
        this.context = context;
        this.token = token;
    }

    /**
     * Google
     */

    public void getStepsFromGoogle(long fromMillis, long toMillis, OnRangeStepsFound onRangeStepsFound) {
        new ReadGoogleFitStep(context, fromMillis, toMillis, onRangeStepsFound).execute();
    }


    public void getTodayStepsFromGoogle(OnTodayStepsFound onTodayStepsFound) {
        new ReadGoogleTodaySteps(context, onTodayStepsFound).execute();
    }


    /**
     * SAMSUNG
     */
    public void getStepsFromSamsung(long fromMillis, long toMillis, OnRangeStepsFound onRangeStepsFound) {
        this.fromMillis = fromMillis;
        this.toMillis = toMillis;
        this.onRangeStepsFound = onRangeStepsFound;
        setupDataStore(false);
    }

    private void setupDataStore(boolean isToday) {
        HealthDataService healthDataService = new HealthDataService();
        try {
            healthDataService.initialize(context);
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (samsungHealthDataStore == null) {
            samsungHealthDataStore = new HealthDataStore(this.context, new HealthDataStore.ConnectionListener() {
                @Override
                public void onConnected() {
                    //    Toast.makeText(context, "connected", Toast.LENGTH_SHORT).show();
                    if (isToday) {
                        setupTodaySHealthAndGetSteps();
                    } else {
                        setupSHealthAndGetSteps();
                    }
                }

                @Override
                public void onConnectionFailed(HealthConnectionErrorResult healthConnectionErrorResult) {

                }

                @Override
                public void onDisconnected() {

                }
            });
        }
        samsungHealthDataStore.connectService();
    }


    public void getTodayStepsFromSamsung(OnTodayStepsFound onTodayStepsFound) {
        this.onTodayStepsFound = onTodayStepsFound;
        setupDataStore(true);
    }


    private void setupSHealthAndGetSteps() {
        setStepChangedListener();
        setStepResultsListener();
        HealthDataObserver.addObserver(samsungHealthDataStore, SAMSUNG_DIGITAL_HEALTH_CUSTOM_DATA_TYPE, sHealthMonthlyObserver);
        sHealthReadMonthlyStep();
    }

    private void setupTodaySHealthAndGetSteps() {
        setTodayStepChangedListener();
        setStepTodayResultsListener();
        HealthDataObserver.addObserver(samsungHealthDataStore, HealthConstants.StepCount.HEALTH_DATA_TYPE, sHealthTodayObserver);
        sHealthReadTodayStep();
    }


    private void setStepResultsListener() {
        sHealthMonthlyResultCallback = readResult -> {
            int count;
            int calories;
            Cursor cursor = null;
            try {

                HashMap<String, StepItem> hashMap = new HashMap<>();
                Calendar fromCalendar = Calendar.getInstance();
                fromCalendar.setTimeInMillis(fromMillis);

                Calendar toCalendar = Calendar.getInstance();
                toCalendar.setTimeInMillis(toMillis);
                String dateFromMillis = Utils.getInstance().getDateFromMillis(fromMillis, DATE_FORMAT_YYYY_MM_DD);
                System.out.println("steps dateFromMillis====" + dateFromMillis);
                StepItem stepItemEmpty = new StepItem();
                stepItemEmpty.setStepTime(dateFromMillis);
                stepItemEmpty.setCalories(0);
                stepItemEmpty.setStepCount("0");
                hashMap.put(dateFromMillis, stepItemEmpty);

                String dateToMillis = Utils.getInstance().getDateFromMillis(toMillis, DATE_FORMAT_YYYY_MM_DD);
                System.out.println("steps dateToMillis====" + dateToMillis);
                stepItemEmpty = new StepItem();
                stepItemEmpty.setStepTime(dateToMillis);
                stepItemEmpty.setCalories(0);
                stepItemEmpty.setStepCount("0");
                hashMap.put(dateToMillis, stepItemEmpty);

                if (!dateFromMillis.equalsIgnoreCase(dateToMillis)) {
                    while (!dateFromMillis.equalsIgnoreCase(dateToMillis)) {
                        fromCalendar.add(Calendar.DATE, 1);
                        String dateMillis = Utils.getInstance().getDateFromMillis(fromCalendar.getTimeInMillis(), DATE_FORMAT_YYYY_MM_DD);
                        dateFromMillis = dateMillis;
                        stepItemEmpty = new StepItem();
                        stepItemEmpty.setStepTime(dateMillis);
                        stepItemEmpty.setCalories(0);
                        stepItemEmpty.setStepCount("0");
                        System.out.println("steps dateMillis====" + dateMillis);
                        hashMap.put(dateMillis, stepItemEmpty);
                    }
                }

                cursor = readResult.getResultCursor();
                if (cursor != null) {
                    if (cursor.getCount() > 0) {
                        foundStepList = new ArrayList<>();

                        while (cursor.moveToNext()) {
                            count = cursor.getInt(cursor.getColumnIndex(HealthConstants.StepCount.COUNT));
                            calories = cursor.getInt(cursor.getColumnIndex(HealthConstants.StepCount.CALORIE));
                            long dayTime = cursor.getLong(cursor.getColumnIndex(SAMSUNG_DIGITAL_HEALTH_DATE_KEY));
                            String date = Utils.getInstance().getDateFromMillis(dayTime, DATE_FORMAT_YYYY_MM_DD);
                            StepItem stepItem = new StepItem();
                            stepItem.setStepCount(String.valueOf(count));
                            stepItem.setStepTime(date);
                            stepItem.setCalories(calories);
                            hashMap.put(date, stepItem);
                            //foundStepList.add(stepItem);
                        }

                       /* for (Map.Entry<String, StepItem> entry : hashMap.entrySet()) {
                            String key = entry.getKey();
                            StepItem stepItem = entry.getValue();
                            foundStepList.add(stepItem);
                        }*/
                        for (Map.Entry<String, StepItem> entry : hashMap.entrySet()) {
                            System.out.println(entry.getKey() + " : " + entry.getValue());
                            StepItem stepsHashMapBean = entry.getValue();

                            StepItem stepsBean = new StepItem();
                            stepsBean.setCalories(stepsHashMapBean.getCalories());
                            stepsBean.setStepCount(stepsHashMapBean.getStepCount());

                            String date = Utils.getInstance().formatDate(DATE_FORMAT_YYYY_MM_DD, DATE_FORMAT_MM_DD_YYYY_HHMM_FORWARD_SLASH,
                                    stepsHashMapBean.getStepTime());
                            stepsBean.setStepTime(date);
                            foundStepList.add(stepsBean);
                        }
                        hashMap.clear();

                    } else if (cursor.getCount() == 0) {
                        foundStepList = new ArrayList<>();
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                if (cursor != null) {
                    if (onRangeStepsFound != null) {
                        onRangeStepsFound.onRangeStepsFound(foundStepList);
                    }
                    cursor.close();
                }
            }
        };
    }

    private void setStepTodayResultsListener() {
        sHealthTodayResultCallback = readResult -> {
            if (context != null) {
                int totalTodayStepCount = 0;
                int totalTodayCalories = 0;
                Cursor cursor = null;
                try {
                    cursor = readResult.getResultCursor();
                    if (cursor != null) {
                        while (cursor.moveToNext()) {
                            int todayStepCount = cursor.getInt(cursor.getColumnIndex(HealthConstants.StepCount.COUNT));
                            totalTodayStepCount += todayStepCount;
                            int calories = cursor.getInt(cursor.getColumnIndex(HealthConstants.StepCount.CALORIE));
                            totalTodayCalories += calories;
                        }
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                    onTodayStepsFound.onTodayStepsError(e.getLocalizedMessage());
                } finally {
                    if (cursor != null) {
                        cursor.close();
                        if (onTodayStepsFound != null) {
                            String dateMillis = Utils.getInstance().getDateFromMillis(Utils.getInstance().getStartTimeOfTodayInMillis(), DATE_FORMAT_MM_DD_YYYY_HHMM_FORWARD_SLASH);
                            StepItem stepItem = new StepItem();
                            stepItem.setStepTime(dateMillis);
                            stepItem.setCalories(totalTodayCalories);
                            stepItem.setStepCount(String.valueOf(totalTodayStepCount));
                            ArrayList<StepItem> foundStepList = new ArrayList<>();
                            foundStepList.add(stepItem);
                            onTodayStepsFound.onTodayStepsFound(foundStepList);
                        }
                    }
                }
            }
        };
    }

    private void setStepChangedListener() {
        sHealthMonthlyObserver = new HealthDataObserver(null) {
            @Override
            public void onChange(String s) {
                if (context != null) { //noinspection StatementWithEmptyBody
                    if (onRangeStepsFound != null) {
                        // sHealthReadMonthlyStep();
                    }
                }
            }
        };
    }

    private void setTodayStepChangedListener() {
        sHealthTodayObserver = new HealthDataObserver(null) {
            @Override
            public void onChange(String s) {
                if (context != null) {
                    if (onTodayStepsFound != null) {
                        //  sHealthReadTodayStep();
                    }
                }
            }
        };

    }

    private void sHealthReadMonthlyStep() {
        HealthDataResolver resolver = new HealthDataResolver(samsungHealthDataStore, null);
        HealthDataResolver.Filter filter = HealthDataResolver.Filter.and(HealthDataResolver.Filter.greaterThanEquals(SAMSUNG_DIGITAL_HEALTH_DATE_KEY, fromMillis), HealthDataResolver.Filter
                .lessThanEquals(SAMSUNG_DIGITAL_HEALTH_DATE_KEY, toMillis), HealthDataResolver.Filter.eq
                (SAMSUNG_DIGITAL_HEALTH_SOURCE_KEY, STEPS_FROM_LOCAL_DEVICES));
        HealthDataResolver.ReadRequest request = new HealthDataResolver.ReadRequest.Builder().setDataType(SAMSUNG_DIGITAL_HEALTH_CUSTOM_DATA_TYPE).setFilter(filter).build();
        try {
            resolver.read(request).setResultListener(sHealthMonthlyResultCallback);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void sHealthReadTodayStep() {
        HealthDataResolver resolver = new HealthDataResolver(samsungHealthDataStore, null);
        long todayStartTimeMillis = Utils.getInstance().getStartTimeOfTodayInMillis();
        long CurrantTimeMillis = Utils.getInstance().getEndTimeOfTodayInMillis();

        HealthDataResolver.ReadRequest request = new HealthDataResolver.ReadRequest.Builder().setDataType(HealthConstants.StepCount.HEALTH_DATA_TYPE).setProperties(new String[]{HealthConstants
                .StepCount.COUNT, HealthConstants.StepCount.CALORIE}).setFilter(HealthDataResolver.Filter.and
                (HealthDataResolver.Filter.greaterThanEquals(HealthConstants.SessionMeasurement.START_TIME, todayStartTimeMillis), HealthDataResolver.Filter.
                        lessThanEquals(HealthConstants.SessionMeasurement.END_TIME, CurrantTimeMillis))).build();
        try {
            if (sHealthTodayResultCallback != null) {
                resolver.read(request).setResultListener(sHealthTodayResultCallback);
            }
        } catch (Exception e) {
            e.printStackTrace();

        }
    }


    /**
     * FITBIT
     */

    public void getStepsFromFitbit(long startDate, long endDate, OnRangeStepsFound onRangeStepsFound) {
        this.onRangeStepsFound = onRangeStepsFound;

        final String fromDateForSync = Utils.getInstance().getDateFromMillis(startDate, DATE_FORMAT_YYYY_MM_DD);
        final String toDateForSync = Utils.getInstance().getDateFromMillis(endDate, DATE_FORMAT_YYYY_MM_DD);

        HashMap<String, StepItem> hashMap = new HashMap<>();
        Calendar fromCalendar = Calendar.getInstance();
        fromCalendar.setTimeInMillis(startDate);

        Calendar toCalendar = Calendar.getInstance();
        toCalendar.setTimeInMillis(endDate);
        String dateFromMillis = Utils.getInstance().getDateFromMillis(startDate, DATE_FORMAT_YYYY_MM_DD);
        System.out.println("steps dateFromMillis====" + dateFromMillis);
        StepItem stepItemEmpty = new StepItem();
        stepItemEmpty.setStepTime(dateFromMillis);
        stepItemEmpty.setCalories(0);
        stepItemEmpty.setStepCount("0");
        hashMap.put(dateFromMillis, stepItemEmpty);

        String dateToMillis = Utils.getInstance().getDateFromMillis(endDate, DATE_FORMAT_YYYY_MM_DD);
        System.out.println("steps dateToMillis====" + dateToMillis);
        stepItemEmpty = new StepItem();
        stepItemEmpty.setStepTime(dateToMillis);
        stepItemEmpty.setCalories(0);
        stepItemEmpty.setStepCount("0");
        hashMap.put(dateToMillis, stepItemEmpty);
        if (!dateFromMillis.equalsIgnoreCase(dateToMillis)) {
            while (!dateFromMillis.equalsIgnoreCase(dateToMillis)) {
                fromCalendar.add(Calendar.DATE, 1);
                String dateMillis = Utils.getInstance().getDateFromMillis(fromCalendar.getTimeInMillis(), DATE_FORMAT_YYYY_MM_DD);
                dateFromMillis = dateMillis;
                stepItemEmpty = new StepItem();
                stepItemEmpty.setStepTime(dateMillis);
                stepItemEmpty.setCalories(0);
                stepItemEmpty.setStepCount("0");
                System.out.println("steps dateMillis====" + dateMillis);
                hashMap.put(dateMillis, stepItemEmpty);
            }
        }

        final FitBitRestClient restClient = new FitBitRestClient(Constant.FITBIT, token, context.getApplicationContext(), FitBitConfig.BASE_URL, false);
        if (NetworkFactory.getInstance().isNetworkAvailable(context)) {
            restClient.getFitBitStepsService().getUserStepsMonthly(fromDateForSync, toDateForSync).enqueue(new Callback<FitBitResponse>() {
                @Override
                public void onResponse(@NonNull Call<FitBitResponse> call, @NonNull Response<FitBitResponse> response) {

                    if (response.body() != null) {
                        if (response.code() == 200) {
                            FitBitResponse fitBitResponse = response.body();
                            if (fitBitResponse != null && fitBitResponse.getActivitiesSteps() != null && fitBitResponse.getActivitiesSteps().size() > 0) {
                                List<FitBitStepsItem> mStepsList = fitBitResponse.getActivitiesSteps();


                                for (FitBitStepsItem fitBitStepsItem : mStepsList) {
                                    String steps = fitBitStepsItem.getValue();
                                    StepItem stepsBean = new StepItem();
                                    stepsBean.setStepCount(steps);
                                    stepsBean.setStepTime(fitBitStepsItem.getDateTime());
                                    hashMap.put(fitBitStepsItem.getDateTime(), stepsBean);
                                }
                                // sync calories
                                restClient.getFitBitStepsService().getUserCaloriesMonthly(fromDateForSync, toDateForSync).enqueue(new Callback<FitBitResponse>() {
                                    @Override
                                    public void onResponse(@NonNull Call<FitBitResponse> call, @NonNull Response<FitBitResponse> response) {

                                        if (response.body() != null) {
                                            if (response.code() == 200) {
                                                FitBitResponse fitBitResponse = response.body();
                                                if (fitBitResponse != null && fitBitResponse.getActivitiesCalories() != null && fitBitResponse.getActivitiesCalories().size() > 0) {
                                                    List<FitBitStepsItem> mStepsList = fitBitResponse.getActivitiesCalories();
                                                    foundStepList = new ArrayList<>();
                                                    for (FitBitStepsItem fitBitStepsItem : mStepsList) {
                                                        if (fitBitStepsItem.getDateTime().equals(hashMap.get(fitBitStepsItem.getDateTime()).getStepTime())) {
                                                            StepItem stepsHashMapBean = hashMap.get(fitBitStepsItem.getDateTime());

                                                            StepItem stepsBean = new StepItem();
                                                            stepsBean.setCalories(Integer.parseInt(fitBitStepsItem.getValue()));
                                                            stepsBean.setStepCount(stepsHashMapBean.getStepCount());

                                                            String date = Utils.getInstance().formatDate(DATE_FORMAT_YYYY_MM_DD, DATE_FORMAT_MM_DD_YYYY_HHMM_FORWARD_SLASH,
                                                                    stepsHashMapBean.getStepTime());
                                                            stepsBean.setStepTime(date);
                                                            foundStepList.add(stepsBean);
                                                        }
                                                    }
                                                    hashMap.clear();
                                                    if (onRangeStepsFound != null) {
                                                        onRangeStepsFound.onRangeStepsFound(foundStepList);
                                                    }
                                                }
                                            }
                                        } else {
                                            if (onRangeStepsFound != null) {
                                                onRangeStepsFound.onStepsFoundError("An error occured");
                                            }
                                        }
                                    }

                                    @Override
                                    public void onFailure(Call<FitBitResponse> call, Throwable t) {
                                        if (onRangeStepsFound != null) {
                                            onRangeStepsFound.onStepsFoundError(t.getLocalizedMessage());
                                        }
                                    }
                                });

                            }
                        } else if (response.code() == 400 || response.code() == 401 || response.code() == 403) {
                                  /*  Intent fitBitIntent = new Intent(activity, FitBitActivity.class);
                                    startActivityForResult(fitBitIntent, ConnectDeviceDetailFragment.FITBIT_REQUEST);
                                    Utils.showToast(activity, "Please login to Fitbit");*/
                            if (onRangeStepsFound != null) {
                                onRangeStepsFound.onStepsFoundError("Please login to Fitbit");
                            }
                        }
                    } else {
                        if (onRangeStepsFound != null) {
                            onRangeStepsFound.onStepsFoundError("An error occurred while syncing your steps to server. Please try to connect your device again.");
                        }
                        //    Utils.showToast(activity, "An error occurred while syncing your steps to server. Please try to connect your device again.");
                    }

                }

                @Override
                public void onFailure(@NonNull Call<FitBitResponse> call, @NonNull Throwable t) {
                    if (onRangeStepsFound != null) {
                        onRangeStepsFound.onStepsFoundError(t.getLocalizedMessage());
                    }
                    //    Utils.showToast(activity, "An error occurred while syncing your steps to server. Please try to connect your device again.");

                }
            });
        }

    }

    public void getTodayStepsFromFitbit(OnTodayStepsFound onTodayStepsFound) {
        this.onTodayStepsFound = onTodayStepsFound;
        final FitBitRestClient restClient = new FitBitRestClient(Constant.FITBIT, token, context, FitBitConfig.BASE_URL, false);
        restClient.getFitBitStepsService().getUserTodaySteps().enqueue(new Callback<FitBitResponse>() {
            @Override
            public void onResponse(@NonNull Call<FitBitResponse> call, @NonNull Response<FitBitResponse> response) {

                if (response.body() != null && response.body().getActivitiesSteps() != null && response.body().getActivitiesSteps().size() > 0) {
                    final String fitbitSteps = response.body().getActivitiesSteps().get(0).getValue();

                    restClient.getFitBitStepsService().getUserTodayCalories().enqueue(new Callback<FitBitResponse>() {
                        @Override
                        public void onResponse(@NonNull Call<FitBitResponse> call, @NonNull Response<FitBitResponse> response) {

                            if (response.body().getActivitiesCalories() != null && response.body().getActivitiesCalories().size() > 0) {
                                String fitbitCalories = response.body().getActivitiesCalories().get(0).getValue();
                                if (onTodayStepsFound != null) {
                                    String dateMillis = Utils.getInstance().getDateFromMillis(Utils.getInstance().getStartTimeOfTodayInMillis(), DATE_FORMAT_MM_DD_YYYY_HHMM_FORWARD_SLASH);
                                    StepItem stepItem = new StepItem();
                                    stepItem.setStepTime(dateMillis);
                                    stepItem.setCalories(Integer.parseInt(fitbitCalories));
                                    stepItem.setStepCount(String.valueOf(fitbitSteps));
                                    ArrayList<StepItem> foundStepList = new ArrayList<>();
                                    foundStepList.add(stepItem);
                                    onTodayStepsFound.onTodayStepsFound(foundStepList);
                                }
                            }

                        }

                        @Override
                        public void onFailure(@NonNull Call<FitBitResponse> call, @NonNull Throwable t) {
                            if (onTodayStepsFound != null) {
                                onTodayStepsFound.onTodayStepsError(t.getLocalizedMessage());
                            }
                            Utils.printLog("Steps", t.getLocalizedMessage());

                        }
                    });
                }

            }

            @Override
            public void onFailure(Call<FitBitResponse> call, Throwable t) {
                if (onTodayStepsFound != null) {
                    onTodayStepsFound.onTodayStepsError(t.getLocalizedMessage());
                }
            }
        });


    }


    /**
     * MISFIT
     */

    public void getStepsFromMisfit(long startDate, long endDate, OnRangeStepsFound onRangeStepsFound) {
        this.onRangeStepsFound = onRangeStepsFound;

        if (NetworkFactory.getInstance().isNetworkAvailable(context)) {
                /*String startDate = "2017-10-18";
                String endDate = "2017-11-16";*/
            final String fromDateForSync = Utils.getInstance().getDateFromMillis(startDate, DATE_FORMAT_YYYY_MM_DD);
            final String toDateForSync = Utils.getInstance().getDateFromMillis(endDate, DATE_FORMAT_YYYY_MM_DD);

            HashMap<String, StepItem> hashMap = new HashMap<>();
            Calendar fromCalendar = Calendar.getInstance();
            fromCalendar.setTimeInMillis(startDate);

            Calendar toCalendar = Calendar.getInstance();
            toCalendar.setTimeInMillis(endDate);
            String dateFromMillis = Utils.getInstance().getDateFromMillis(startDate, DATE_FORMAT_YYYY_MM_DD);
            System.out.println("steps dateFromMillis====" + dateFromMillis);
            StepItem stepItemEmpty = new StepItem();
            stepItemEmpty.setStepTime(dateFromMillis);
            stepItemEmpty.setCalories(0);
            stepItemEmpty.setStepCount("0");
            hashMap.put(dateFromMillis, stepItemEmpty);

            String dateToMillis = Utils.getInstance().getDateFromMillis(endDate, DATE_FORMAT_YYYY_MM_DD);
            System.out.println("steps dateToMillis====" + dateToMillis);
            stepItemEmpty = new StepItem();
            stepItemEmpty.setStepTime(dateToMillis);
            stepItemEmpty.setCalories(0);
            stepItemEmpty.setStepCount("0");
            hashMap.put(dateToMillis, stepItemEmpty);

            if (!dateFromMillis.equalsIgnoreCase(dateToMillis)) {
                while (!dateFromMillis.equalsIgnoreCase(dateToMillis)) {
                    fromCalendar.add(Calendar.DATE, 1);
                    String dateMillis = Utils.getInstance().getDateFromMillis(fromCalendar.getTimeInMillis(), DATE_FORMAT_YYYY_MM_DD);
                    dateFromMillis = dateMillis;
                    stepItemEmpty = new StepItem();
                    stepItemEmpty.setStepTime(dateMillis);
                    stepItemEmpty.setCalories(0);
                    stepItemEmpty.setStepCount("0");
                    System.out.println("steps dateMillis====" + dateMillis);
                    hashMap.put(dateMillis, stepItemEmpty);
                }
            }

            FitBitRestClient restClient = new FitBitRestClient(Constant.MISFIT, token, context, FitBitConfig.MISFIT_BASE_URL, false);
            restClient.getFitBitStepsService().getUserSummary(fromDateForSync, toDateForSync, true).enqueue(new Callback<GetMisFitResponse>() {
                @Override
                public void onResponse(Call<GetMisFitResponse> call, Response<GetMisFitResponse> response) {

                    if (response != null && response.body() != null) {
                        if (response.code() == 200) {
                            if (response.body().getSummary() != null && response.body().getSummary().size() > 0) {
                                List<FitBitStepsItem> stepsItemList = response.body().getSummary();
                                if (stepsItemList != null && stepsItemList.size() > 0) {

                                    for (FitBitStepsItem fitBitStepsItem : stepsItemList) {

                                        StepItem stepsBean = new StepItem();
                                        stepsBean.setStepCount(fitBitStepsItem.getValue());
                                        stepsBean.setStepTime(fitBitStepsItem.getDateTime());
                                        stepsBean.setCalories((int) fitBitStepsItem.getCalory());
                                        hashMap.put(fitBitStepsItem.getDateTime(), stepsBean);
                                    }
                                    foundStepList = new ArrayList<>();

                                    for (Map.Entry<String, StepItem> entry : hashMap.entrySet()) {
                                        System.out.println(entry.getKey() + " : " + entry.getValue());
                                        StepItem stepsHashMapBean = entry.getValue();

                                        StepItem stepsBean = new StepItem();
                                        stepsBean.setCalories(stepsHashMapBean.getCalories());
                                        stepsBean.setStepCount(stepsHashMapBean.getStepCount());

                                        String date = Utils.getInstance().formatDate(DATE_FORMAT_YYYY_MM_DD, DATE_FORMAT_MM_DD_YYYY_HHMM_FORWARD_SLASH,
                                                stepsHashMapBean.getStepTime());
                                        stepsBean.setStepTime(date);
                                        foundStepList.add(stepsBean);
                                    }

                                    if (onRangeStepsFound != null) {
                                        onRangeStepsFound.onRangeStepsFound(foundStepList);
                                    }
                                }
                            } else {
                                // if no data available in range and
                                // last device at server and local device is different then we need to sync today step

                            }
                        } else {
                            if (onRangeStepsFound != null) {
                                onRangeStepsFound.onStepsFoundError(response.body().getError_message());
                            }
                            // DialogFactory.getInstance().showAlertDialog(activity, null, 0, response.body().getError_message(), getString(R.string.str_ok), true);
                        }
                    } else {
                        if (onRangeStepsFound != null) {
                            onRangeStepsFound.onStepsFoundError("An error occurred while syncing your steps to server. Please try to connect your device again.");
                        }
                        //   Utils.showToast(activity, "An error occurred while syncing your steps to server. Please try to connect your device again.");
                    }

                }

                @Override
                public void onFailure(Call<GetMisFitResponse> call, Throwable t) {
                    if (onRangeStepsFound != null) {
                        onRangeStepsFound.onStepsFoundError(t.getLocalizedMessage());
                    }
                    // DialogFactory.getInstance().showAlertDialog(activity, null, 0, getString(R.string.msg_api_failure), getString(R.string.str_ok), true);

                }
            });
        }

    }

    public void getTodayStepsMisfit(OnTodayStepsFound onTodayStepsFound) {
        this.onTodayStepsFound = onTodayStepsFound;

        final String todayDateForSync = Utils.getInstance().getTodayDate(DATE_FORMAT_YYYY_MM_DD);

        FitBitRestClient restClient = new FitBitRestClient(Constant.MISFIT,token, context, FitBitConfig.MISFIT_BASE_URL, false);
        restClient.getFitBitStepsService().getUserSummary(todayDateForSync, todayDateForSync, false).enqueue(new Callback<GetMisFitResponse>() {
            @SuppressWarnings("ConstantConditions")
            @Override
            public void onResponse(@NonNull Call<GetMisFitResponse> call, @NonNull Response<GetMisFitResponse> response) {
                if (response.body() != null) {
                    if (response.code() == 200) {
                        if (onTodayStepsFound != null) {
                            String dateMillis = Utils.getInstance().getDateFromMillis(Utils.getInstance().getStartTimeOfTodayInMillis(), DATE_FORMAT_MM_DD_YYYY_HHMM_FORWARD_SLASH);
                            StepItem stepItem = new StepItem();
                            stepItem.setStepTime(dateMillis);
                            stepItem.setCalories((int) response.body().getCalories());
                            stepItem.setStepCount(String.valueOf(response.body().getSteps()));
                            ArrayList<StepItem> foundStepList = new ArrayList<>();
                            foundStepList.add(stepItem);
                            onTodayStepsFound.onTodayStepsFound(foundStepList);
                        }
                    } else {
                        if (onRangeStepsFound != null) {
                            onRangeStepsFound.onStepsFoundError(response.body().getError_message());
                        }
                        // DialogFactory.getInstance().showAlertDialog(activity, null, 0, response.body().getError_message(), getString(R.string.str_ok), true);
                    }
                } else {
                    if (onRangeStepsFound != null) {
                        onRangeStepsFound.onStepsFoundError("An error occurred while syncing your steps to server. Please try to connect your device again.");
                    }
                    //      Utils.showToast(activity, "An error occurred while syncing your steps to server. Please try to connect your device again.");
                }

            }

            @Override
            public void onFailure(@NonNull Call<GetMisFitResponse> call, @NonNull Throwable t) {
                t.printStackTrace();
                if (onRangeStepsFound != null) {
                    onRangeStepsFound.onStepsFoundError(t.getLocalizedMessage());
                }
            }
        });
    }
}
