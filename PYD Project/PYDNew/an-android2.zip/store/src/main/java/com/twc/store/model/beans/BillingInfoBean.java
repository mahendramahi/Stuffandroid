package com.twc.store.model.beans;

/**
 * Created by GurvinderS on 9/18/2017.
 */

public class BillingInfoBean {

    private int MemberBilling_ID;
    private String Name;
    private String PhoneNo;
    private String Address1;
    private String Address2;
    private String City;
    private String State;
    private String Country;
    private String Pincode;

    public int getMemberBilling_ID() {
        return MemberBilling_ID;
    }

    public void setMemberBilling_ID(int MemberBilling_ID) {
        this.MemberBilling_ID = MemberBilling_ID;
    }

    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public String getPhoneNo() {
        return PhoneNo;
    }

    public void setPhoneNo(String PhoneNo) {
        this.PhoneNo = PhoneNo;
    }

    public String getAddress1() {
        return Address1;
    }

    public void setAddress1(String Address1) {
        this.Address1 = Address1;
    }

    public String getAddress2() {
        return Address2;
    }

    public void setAddress2(String Address2) {
        this.Address2 = Address2;
    }

    public String getCity() {
        return City;
    }

    public void setCity(String City) {
        this.City = City;
    }

    public String getState() {
        return State;
    }

    public void setState(String State) {
        this.State = State;
    }

    public String getCountry() {
        return Country;
    }

    public void setCountry(String Country) {
        this.Country = Country;
    }

    public String getPincode() {
        return Pincode;
    }

    public void setPincode(String Pincode) {
        this.Pincode = Pincode;
    }
}
