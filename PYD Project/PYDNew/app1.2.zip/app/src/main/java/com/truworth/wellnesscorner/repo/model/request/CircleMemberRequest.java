package com.truworth.wellnesscorner.repo.model.request;

import com.google.gson.annotations.SerializedName;

public class CircleMemberRequest extends BaseRequest{


    private String SearchTerm;
    private int pageIndex;



    public String getSearchTerm() {
        return SearchTerm;
    }

    public void setSearchTerm(String searchTerm) {
        SearchTerm = searchTerm;
    }

    public int getPageIndex() {
        return pageIndex;
    }

    public void setPageIndex(int pageIndex) {
        this.pageIndex = pageIndex;
    }
}
