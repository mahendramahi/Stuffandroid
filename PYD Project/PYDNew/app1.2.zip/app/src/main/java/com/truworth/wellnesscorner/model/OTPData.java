package com.truworth.wellnesscorner.model;

/**
 * Created by rajeshs on 4/2/2018.
 */

public class OTPData {
    String otpSessionId;

    public String getOtpSessionId() {
        return otpSessionId;
    }

    public void setOtpSessionId(String otpSessionId) {
        this.otpSessionId = otpSessionId;
    }
}
