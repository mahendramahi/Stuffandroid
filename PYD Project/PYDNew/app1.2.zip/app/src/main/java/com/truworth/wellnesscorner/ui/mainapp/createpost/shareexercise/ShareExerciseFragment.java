package com.truworth.wellnesscorner.ui.mainapp.createpost.shareexercise;

import android.app.Activity;
import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.View;

import com.truworth.wellnesscorner.BR;
import com.truworth.wellnesscorner.R;
import com.truworth.wellnesscorner.base.BaseFragment;
import com.truworth.wellnesscorner.databinding.FragmentShareExerciseBinding;
import com.truworth.wellnesscorner.model.ExerciseData;
import com.truworth.wellnesscorner.ui.mainapp.createpost.ShareActivity;
import com.truworth.wellnesscorner.ui.registration.registrationstepfifth.CropActivity;
import com.truworth.wellnesscorner.utils.AppConstants;
import com.truworth.wellnesscorner.utils.CameraGalleryUtil;
import com.truworth.wellnesscorner.utils.CompressImage;
import com.truworth.wellnesscorner.utils.Utils;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;

public class ShareExerciseFragment extends BaseFragment<FragmentShareExerciseBinding, ShareExerciseViewModel> {
    private ShareExerciseViewModel viewModel;
    private FragmentShareExerciseBinding binding;
    private ExerciseData exerciseData;
    private String date;
    private CameraGalleryUtil cameraGalleryUtil;
    private String filePath;
    boolean isCameraSelected;
    private Bitmap finalBitmap;
    private Bitmap cameraBitmap;

    public static ShareExerciseFragment newInstance(ExerciseData exerciseData, String date) {
        Bundle args = new Bundle();
        args.putSerializable("arg1", exerciseData);
        args.putString("date", date);
        ShareExerciseFragment fragment = new ShareExerciseFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        cameraGalleryUtil = new CameraGalleryUtil(getActivity(), ShareExerciseFragment.this);
        if (getArguments() != null) {
            exerciseData = (ExerciseData) getArguments().getSerializable("arg1");
            date = getArguments().getString("date");
        }
    }

    @Override
    public int getBindingVariable() {
        return BR.viewModel;
    }


    @Override
    public int getLayoutId() {
        return R.layout.fragment_share_exercise;
    }

    @Override
    public ShareExerciseViewModel getViewModel() {
        viewModel = ViewModelProviders.of(this).get(ShareExerciseViewModel.class);
        return viewModel;
    }

    @Override
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        binding = getViewDataBinding();
        viewModel.getData(exerciseData, date);
        setClickObserver();
        setDefault();
    }

    private void setClickObserver() {
        viewModel.getDefaultImgClick().observe(this, new Observer<Void>() {
            @Override
            public void onChanged(@Nullable Void avoid) {
                isCameraSelected = false;
                setSelection(0, R.drawable.template_select_white);

                binding.llDefaultView.setVisibility(View.VISIBLE);
                binding.cameraImageLayout.setVisibility(View.GONE);

                setDefault();
            }
        });

        viewModel.getCameraBtnClick().observe(this, new Observer<Void>() {
            @Override
            public void onChanged(@Nullable Void avoid) {
                if (filePath != null) {
                    setSelection(R.drawable.template_select_white, R.drawable.rounded_grey_light_border);
                    setData(filePath);
                    if (isCameraSelected) {
                        Utils.checkForCameraPermissions(getActivity(), cameraGalleryUtil);
                    }
                } else {
                    Utils.checkForCameraPermissions(getActivity(), cameraGalleryUtil);
                }
                isCameraSelected = true;
            }
        });

        viewModel.getShareBtnClick().observe(this, new Observer<Void>() {
            @Override
            public void onChanged(@Nullable Void avoid) {
                if (finalBitmap != null) {
                    String path = Utils.getImageUri(getContext(), finalBitmap);
                    Intent returnIntent = new Intent();
                    returnIntent.putExtra("result", path);
                    getActivity().setResult(Activity.RESULT_OK, returnIntent);
                    getActivity().finish();

                }
            }
        });


    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode == Activity.RESULT_OK) {
            Uri selectedImage;
            setSelection(R.drawable.template_select_white, R.drawable.rounded_grey_light_border);
            if (requestCode == AppConstants.CAMERA_REQUEST) {
                if (cameraGalleryUtil.getCameraFilePath() != null) {

                    File file = new File(cameraGalleryUtil.getCameraFilePath());
                    Uri myuri = Uri.fromFile(file);
                    filePath = cameraGalleryUtil.getPath(getActivity(), myuri);
                    cameraBitmap = null;
                    setData(filePath);
                }
            }
        } else {

        }
    }


    public void setData(String filePath) {
        if (filePath != null) {
            binding.llDefaultView.setVisibility(View.GONE);
            binding.cameraImageLayout.setVisibility(View.VISIBLE);
            binding.ivSetCameraImage.setVisibility(View.VISIBLE);

            if (cameraBitmap != null) {
                binding.ivSetCameraImage.setImageBitmap(cameraBitmap);
            } else {
                cameraBitmap = cameraGalleryUtil.getBitmap(filePath, binding.ivSetCameraImage.getWidth(), binding.ivSetCameraImage.getHeight());
                binding.ivSetCameraImage.setImageBitmap(cameraBitmap);
            }

            Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {

                    Bitmap bm = Utils.layoutToImage(binding.cameraImageLayout);
                    ByteArrayOutputStream bytes = new ByteArrayOutputStream();
                    bm.compress(Bitmap.CompressFormat.JPEG, 100, bytes);
                    binding.ivCamera.setImageBitmap(bm);
                    finalBitmap = bm;
                    //setSelection(R.drawable.template_select_white, 0);
                    try {
                        bytes.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }, 500);


        }
    }

    public void setDefault() {

        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {

                Bitmap bm = Utils.layoutToImage(binding.llDefaultView);
                ByteArrayOutputStream bytes = new ByteArrayOutputStream();
                bm.compress(Bitmap.CompressFormat.JPEG, 100, bytes);
                finalBitmap = bm;
            }
        }, 500);

    }

    public void setSelection(int i1, int i2) {
        binding.llCameraBorder.setBackgroundResource(i1);
        binding.llDefaultImageBorder.setBackgroundResource(i2);
    }
    @Override
    public void onDestroy() {
        super.onDestroy();
        if(finalBitmap!=null){
            finalBitmap.recycle();
            finalBitmap=null;
        }
        if(cameraBitmap!=null){
            cameraBitmap.recycle();
            cameraBitmap=null;
        }

    }
}
