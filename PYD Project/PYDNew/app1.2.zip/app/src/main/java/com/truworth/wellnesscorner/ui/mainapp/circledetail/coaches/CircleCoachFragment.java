package com.truworth.wellnesscorner.ui.mainapp.circledetail.coaches;

import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import com.truworth.wellnesscorner.BR;
import com.truworth.wellnesscorner.R;
import com.truworth.wellnesscorner.base.BaseFragment;
import com.truworth.wellnesscorner.databinding.FragmentCircleCoachBinding;
import com.truworth.wellnesscorner.model.CircleCoach;

import java.util.ArrayList;
import java.util.List;

public class CircleCoachFragment extends BaseFragment<FragmentCircleCoachBinding, CircleCoachViewModel> {
    public static final String TAG = "CircleCoachFragment";
    CircleCoachViewModel viewModel;
    List<CircleCoach> coachList;
    CircleCoachAdapter circleCoachAdapter;
    private static final String CIRCLE_IDENTITY = "circleIdentity";
    String CircleIdentity="";
    public CircleCoachFragment() {
        // Required empty public constructor
    }
    private Handler handlerCircleCoachApi = new Handler();
    private Runnable runnable = new Runnable() {
        @Override
        public void run() {

            viewModel.loadCoaches(CircleIdentity);
        }
    };

    public static CircleCoachFragment newInstance(String circleIdentity) {
        CircleCoachFragment fragment = new CircleCoachFragment();
        Bundle args = new Bundle();
        args.putString(CIRCLE_IDENTITY, circleIdentity);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            CircleIdentity = getArguments().getString(CIRCLE_IDENTITY);
        }
    }

    @Override
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        coachList = new ArrayList<>();
        setUpCoachRecycler();


        getViewDataBinding().rvCircleCoaches.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);

                if(dy<0)
                    getViewDataBinding().imgUpArrow.setVisibility(View.GONE);
                else
                    getViewDataBinding().imgUpArrow.setVisibility(View.VISIBLE);
            }
        });


        setCoachObserver();
        setUpArrowObserver();
    }

    @Override
    public int getBindingVariable() {
        return BR.viewModel;
    }

    @Override
    public int getLayoutId() {
        return R.layout.fragment_circle_coach;
    }

    @Override
    public CircleCoachViewModel getViewModel() {
        viewModel = ViewModelProviders.of(this).get(CircleCoachViewModel.class);
        return viewModel;
    }
    boolean _areDataLoaded = false;
    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        if (isVisibleToUser && !_areDataLoaded ) {
            handlerCircleCoachApi.postDelayed(runnable,50);
            _areDataLoaded = true;
        }
    }

    private void setUpCoachRecycler() {
        RecyclerView recyclerView = getViewDataBinding().rvCircleCoaches;
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false));
        circleCoachAdapter = new CircleCoachAdapter(coachList);
        recyclerView.setAdapter(circleCoachAdapter);
    }

     private void setCoachObserver(){
        viewModel.getCoaches().observe(this, new Observer<List<CircleCoach>>() {
             @Override
             public void onChanged(@Nullable List<CircleCoach> coaches){
                 coachList.clear();
                 coachList.addAll(coaches);
                 circleCoachAdapter.notifyDataSetChanged();
             }
         });
     }

    private void setUpArrowObserver() {
        viewModel.getUpArrow().observe(this, new Observer<Void>() {
            @Override
            public void onChanged(@Nullable Void avoid) {
                getViewDataBinding().rvCircleCoaches.smoothScrollToPosition(0);
                new Handler().postDelayed(() -> getViewDataBinding().imgUpArrow.setVisibility(View.GONE),500);
            }
        });
    }

    @Override
    public void onStop() {
        super.onStop();

       if(handlerCircleCoachApi!=null) {
            handlerCircleCoachApi.removeCallbacks(runnable);
        }
    }
}
