/*
 *  Copyright (C) 2017 MINDORKS NEXTGEN PRIVATE LIMITED
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      https://mindorks.com/license/apache-v2
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License
 */

package com.truworth.wellnesscorner.utils;

import android.content.Context;
import android.databinding.BindingAdapter;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.webkit.WebView;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.truworth.wellnesscorner.R;
import com.truworth.wellnesscorner.utils.imageloader.GlideApp;


public final class BindingUtils {

    private BindingUtils() {
        // This class is not publicly instantiable
    }


    @BindingAdapter({"loadData"})
    public static void loadUrl(WebView view, String url) {
        view.loadData(url, "text/html", "UTF-8");
    }


    @BindingAdapter("imageUrl")
    public static void setImageUrl(ImageView imageView, String url) {

        //  Glide.with(context).load(url).into(imageView);
        GlideApp.with(imageView.getContext())
                .load(url)
                .placeholder(R.color.colorPrimary)
                .error(R.color.colorPrimary)
                .fitCenter()
                .into(imageView);
    }

    @BindingAdapter(value ={"imageUrlWithLetter","name"}, requireAll = false)
    public static void setImageUrlWithLetter(ImageView imageView, String url,String name) {
        Context context = imageView.getContext();

        GlideApp.with(context)
                .load(url)
                .placeholder(Utils.getFirstLetterDrawable(name, imageView,imageView.getContext()))
                        .error(Utils.getFirstLetterDrawable(name, imageView,imageView.getContext()))
                .into(imageView);
    }

    @BindingAdapter(value = {"android:pagerAdapter"}, requireAll = false)
    public static void setViewPager(ViewPager viewPager, FragmentPagerAdapter adapter) {
        viewPager.setAdapter(adapter);
    }
}
