package com.truworth.stepmodule.utils;

import android.util.Log;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

/**
 * If this code works it was written by Somesh Kumar on 05 September, 2017. If not, I don't know who wrote it.
 */

public class Utils {
    private static final int LAST_HOUR = 23;
    private static final int LAST_MINUTE = 59;
    private static final int LAST_SECOND = 59;
    private static final int LAST_MILLIS = 999;
    private static final int ZERO = 0;
    private static Utils utils;
    private final Locale locale;

    private Utils() {
        this.locale = Locale.getDefault();
    }

    public static Utils getInstance() {
        if (utils == null) {
            utils = new Utils();
        }
        return utils;
    }

    public static void printLog(String tag, Object msg) {
        Log.d("Log", tag + " " + msg);
    }

    public String getDateFromMillis(long milliSeconds, String dateFormat) {
        DateFormat formatter = new SimpleDateFormat(dateFormat, this.locale);

        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(milliSeconds);
        return formatter.format(calendar.getTime());
    }

    public long getStartTimeOfTodayInMillis() {
        Calendar today = Calendar.getInstance();
        today.setTimeZone(TimeZone.getTimeZone("UTC"));
        today.set(Calendar.HOUR_OF_DAY, ZERO);
        today.set(Calendar.MINUTE, ZERO);
        today.set(Calendar.SECOND, ZERO);
        today.set(Calendar.MILLISECOND, ZERO);

        return today.getTimeInMillis();
    }  public String getTodayDate(String outputFormat) {
        SimpleDateFormat sdf = new SimpleDateFormat(outputFormat, locale);
        return sdf.format(Calendar.getInstance().getTime());
    }

    public String formatDate(String formatSrc, String formatDest, String date) {
        String str;
        SimpleDateFormat sdf = new SimpleDateFormat(formatSrc, locale);
        try {
            Date myDate = sdf.parse(date);
            str = new SimpleDateFormat(formatDest, locale).format(myDate);
        } catch (ParseException e) {
            e.printStackTrace();
            return "";
        }
        return str;
    }
    public long getEndTimeOfTodayInMillis() {
        Calendar todayEnd = Calendar.getInstance();
        todayEnd.setTimeZone(TimeZone.getTimeZone("UTC"));
        todayEnd.set(Calendar.HOUR_OF_DAY, LAST_HOUR);
        todayEnd.set(Calendar.MINUTE, LAST_MINUTE);
        todayEnd.set(Calendar.SECOND, LAST_SECOND);
        todayEnd.set(Calendar.MILLISECOND, LAST_MILLIS);
        return todayEnd.getTimeInMillis();
    }
}
