package com.twc.remindermodule.model.beans;

import java.util.List;

/**
 * Created by GurvinderS on 9/21/2017.
 */

public class HabitReminderBean {

    private int HabitID;
    private String ReminderName;
  private String ReminderText;
    private List<HabitReminderItem> HabitReminder;

    public int getHabitID() {
        return HabitID;
    }

    public void setHabitID(int HabitID) {
        this.HabitID = HabitID;
    }

    public String getReminderName() {
        return ReminderName;
    }

    public void setReminderName(String ReminderName) {
        this.ReminderName = ReminderName;
    }
    public String getReminderText() {
        return ReminderText;
    }

    public void setReminderText(String reminderText) {
        ReminderText = reminderText;
    }

    public List<HabitReminderItem> getHabitReminder() {
        return HabitReminder;
    }

    public void setHabitReminder(List<HabitReminderItem> HabitReminder) {
        this.HabitReminder = HabitReminder;
    }

    public static class HabitReminderItem {


        private String ReminderName;
        private String ReminderText;
        private String Time;
        private boolean IsDisabled;
        private String LastUpdated;
        private boolean isLocallyAdded = false;
        private int IsRemoved;

        public boolean isLocallyAdded() {
            return isLocallyAdded;
        }

        public void setLocallyAdded(boolean locallyAdded) {
            isLocallyAdded = locallyAdded;
        }

        public String getReminderName() {
            return ReminderName;
        }

        public void setReminderName(String ReminderName) {
            this.ReminderName = ReminderName;
        }

        public String getReminderText() {
            return ReminderText;
        }

        public void setReminderText(String ReminderText) {
            this.ReminderText = ReminderText;
        }

        public String getTime() {
            return Time;
        }

        public void setTime(String Time) {
            this.Time = Time;
        }

        public boolean isIsDisabled() {
            return IsDisabled;
        }

        public void setIsDisabled(boolean IsDisabled) {
            this.IsDisabled = IsDisabled;
        }

        public String getLastUpdated() {
            return LastUpdated;
        }

        public void setLastUpdated(String LastUpdated) {
            this.LastUpdated = LastUpdated;
        }

        public int isRemoved() {
            return IsRemoved;
        }

        public void setRemoved(int removed) {
            IsRemoved = removed;
        }
    }

}
