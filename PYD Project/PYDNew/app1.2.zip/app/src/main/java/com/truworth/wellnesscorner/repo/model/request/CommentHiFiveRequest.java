package com.truworth.wellnesscorner.repo.model.request;

public class CommentHiFiveRequest {

    private String CommentIdentity;
    public String getCommentIdentity() {
        return CommentIdentity;
    }

    public void setCommentIdentity(String CommentIdentity) {
        this.CommentIdentity = CommentIdentity;
    }

}
