package com.twc.dailylog.model.response;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.twc.dailylog.model.beans.FoodSearchItem;
import com.twc.dailylog.model.beans.FoodSearchTypeItem;

import java.util.ArrayList;
import java.util.List;

public class GetFoodSearchResponse {

	@SerializedName("Result1")
	@Expose
	private List<FoodSearchItem> mFoodSearchList = new ArrayList<>();
	@SerializedName("Result2")
	@Expose
	private List<FoodSearchTypeItem> mFoodSearchTypeList = new ArrayList<>();

	@SerializedName("status")
	@Expose
	private int status;

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	/**
	 *
	 * @return
	 * The mFoodSearchItem
	 */
	public List<FoodSearchItem> getFoodSearchList() {
		return mFoodSearchList;
	}

	/**
	 *
	 * @param foodSearchItem
	 * The FoodSearchItem
	 */
	public void setFoodSearchList(List<FoodSearchItem> foodSearchItem) {
		this.mFoodSearchList = foodSearchItem;
	}

	/**
	 *
	 * @return
	 * The mFoodSearchTypeItem
	 */
	public List<FoodSearchTypeItem> getFoodSearchTypeList() {
		return mFoodSearchTypeList;
	}

	/**
	 *
	 * @param foodSearchTypeItem
	 * The FoodSearchTypeItem
	 */
	public void setFoodSearchTypeList(List<FoodSearchTypeItem> foodSearchTypeItem) {
		this.mFoodSearchTypeList = foodSearchTypeItem;
	}

}
