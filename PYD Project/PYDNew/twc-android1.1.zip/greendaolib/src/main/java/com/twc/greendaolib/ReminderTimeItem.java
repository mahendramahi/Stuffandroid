package com.twc.greendaolib;

import org.greenrobot.greendao.annotation.Entity;
import org.greenrobot.greendao.annotation.Id;
import org.greenrobot.greendao.annotation.Generated;

/**
 * Created by ManishJ1 on 11/15/2016.
 */
@Entity
public class ReminderTimeItem {
    public Long reminderId;
    public String userId;
    public String reminderType;
    public String reminderTime;
    public boolean isActive;
    public boolean isCustom;
    @Id(autoincrement = true)
    private Long id;

    @Generated(hash = 531153039)
    public ReminderTimeItem(Long reminderId, String userId, String reminderType,
            String reminderTime, boolean isActive, boolean isCustom, Long id) {
        this.reminderId = reminderId;
        this.userId = userId;
        this.reminderType = reminderType;
        this.reminderTime = reminderTime;
        this.isActive = isActive;
        this.isCustom = isCustom;
        this.id = id;
    }

    @Generated(hash = 520016547)
    public ReminderTimeItem() {
    }

    public boolean getIsCustom() {
        return this.isCustom;
    }

    public void setIsCustom(boolean isCustom) {
        this.isCustom = isCustom;
    }

    public boolean getIsActive() {
        return this.isActive;
    }

    public void setIsActive(boolean isActive) {
        this.isActive = isActive;
    }

    public String getReminderTime() {
        return this.reminderTime;
    }

    public void setReminderTime(String reminderTime) {
        this.reminderTime = reminderTime;
    }

    public String getReminderType() {
        return this.reminderType;
    }

    public void setReminderType(String reminderType) {
        this.reminderType = reminderType;
    }

    public String getUserId() {
        return this.userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public Long getReminderId() {
        return this.reminderId;
    }

    public void setReminderId(Long reminderId) {
        this.reminderId = reminderId;
    }

    public Long getId() {
        return this.id;
    }

    public void setId(Long id) {
        this.id = id;
    }


}
