package com.twc.hramodule.utils;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Fragment;
import android.graphics.Color;
import android.support.design.widget.Snackbar;
import android.support.v4.content.ContextCompat;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.style.ForegroundColorSpan;
import android.text.style.RelativeSizeSpan;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.twc.hramodule.R;

import java.util.Locale;

public class Utils {


    public static void setupTouchUI(View view, final Activity mActivity) {
        if (!(view instanceof EditText)) {
            view.setOnTouchListener(new View.OnTouchListener() {
                @SuppressLint("ClickableViewAccessibility")
                public boolean onTouch(View v, MotionEvent event) {
                    hideSoftKeyboard(mActivity);
                    return false;
                }
            });
        }
        if (view instanceof ViewGroup) {
            for (int i = 0; i < ((ViewGroup) view).getChildCount(); i++) {
                View innerView = ((ViewGroup) view).getChildAt(i);
                setupTouchUI(innerView, mActivity);
            }
        }
    }

    public static void hideSoftKeyboard(Activity activity) {
        InputMethodManager inputMethodManager = (InputMethodManager) activity.getSystemService(Activity.INPUT_METHOD_SERVICE);
        if (null != activity.getCurrentFocus()) {
            inputMethodManager.hideSoftInputFromWindow(activity.getCurrentFocus().getWindowToken(), 0);
        }
    }

    public static void showToast(final Activity activity, final String msg) {
        activity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(activity, msg, Toast.LENGTH_LONG).show();
            }
        });
    }

    public static void showSnackBarMessage(View view, String msg) {
        Snackbar snackbar = Snackbar.make(view, msg, Snackbar.LENGTH_LONG);

        View sbView = snackbar.getView();
        FrameLayout.LayoutParams params = (FrameLayout.LayoutParams) sbView.getLayoutParams();
        params.bottomMargin = 10;
        sbView.setBackgroundColor(Color.DKGRAY);
        TextView textView = sbView.findViewById(android.support.design.R.id.snackbar_text);
        textView.setTextColor(Color.WHITE);
        textView.setTextSize(20);
        snackbar.show();
    }



    public static void replaceFragmentWithoutAnimation(android.app.FragmentManager fragmentManager, Fragment fragment, String tag, boolean addTobackStack, int container) {

        // transaction
        android.app.FragmentTransaction ft = fragmentManager.beginTransaction();
        if (addTobackStack) {
            ft.addToBackStack(tag);
        }

        ft.replace(container, fragment, tag);
        ft.commit();
    }

    public static void replaceFragment(android.app.FragmentManager fragmentManager, Fragment fragment, String tag, boolean addTobackStack, int container) {

        android.app.FragmentTransaction ft = fragmentManager.beginTransaction();
        // ft.setCustomAnimations(R.animator.enter, R.animator.exit, R.animator.pop_enter, R.animator.pop_exit);
        if (addTobackStack) {
            ft.addToBackStack(tag);
        }

        ft.replace(container, fragment, tag);
        ft.commit();
    }

    public static void replaceFragmentHraBackAnimation(android.app.FragmentManager fragmentManager, Fragment fragment, String tag, boolean addTobackStack, int container) {

        android.app.FragmentTransaction ft = fragmentManager.beginTransaction();
        //ft.setCustomAnimations(R.animator.pop_enter, R.animator.pop_exit, R.animator.enter, R.animator.exit);
        if (addTobackStack) {
            ft.addToBackStack(tag);
        }

        ft.replace(container, fragment, tag);
        ft.commit();
    }

    public static SpannableStringBuilder makeSpecificTextSmall(Activity activity, String fullText, String textToBold) {
        SpannableStringBuilder builder = new SpannableStringBuilder();

        if (textToBold.length() > 0 && !textToBold.trim().equals("")) {

            //for counting start/end indexes
            String testText = fullText.toLowerCase(Locale.US);
            String testTextToBold = textToBold.toLowerCase(Locale.US);
            int startingIndex = testText.indexOf(testTextToBold);
            int endingIndex = startingIndex + testTextToBold.length();
            //for counting start/end indexes

            if (startingIndex < 0 || endingIndex < 0) {
                return builder.append(fullText);
            } else if (startingIndex >= 0 && endingIndex >= 0) {

                builder.append(fullText);
                builder.setSpan(new RelativeSizeSpan(0.9f), startingIndex, endingIndex, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
                builder.setSpan(new ForegroundColorSpan(ContextCompat.getColor(activity, R.color.color_838383)), startingIndex, endingIndex, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            }
        } else {
            return builder.append(fullText);
        }

        return builder;
    }


}


