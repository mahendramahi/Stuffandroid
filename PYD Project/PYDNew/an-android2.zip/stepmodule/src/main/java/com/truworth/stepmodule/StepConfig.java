package com.truworth.stepmodule;

import android.util.Log;

/**
 * If this code works, it was written by Somesh Kumar  on 01 May, 2018. If not, I don't know who wrote it.
 */
public class StepConfig {

    public static String accessToken;

    private StepConfig() {

    }

    public StepConfig(String accessToken) {
        StepConfig.accessToken = accessToken;
    }



}