package com.twc.dailylog.model.requestbody;

/**
 * Created by ManishJ1 on 6/30/2016.
 */
public class BaseBody {

    private String accessToken;

    public String getAccessToken() {
        return accessToken;
    }

    public void setAccessToken(String accessToken) {
        this.accessToken = accessToken;
    }
}
