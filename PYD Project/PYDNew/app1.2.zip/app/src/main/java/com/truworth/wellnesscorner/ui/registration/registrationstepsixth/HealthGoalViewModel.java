package com.truworth.wellnesscorner.ui.registration.registrationstepsixth;

import android.databinding.ObservableArrayList;
import android.databinding.ObservableBoolean;
import android.databinding.ObservableField;

import com.truworth.wellnesscorner.TheWellnessCornerApp;
import com.truworth.wellnesscorner.base.BaseViewModel;
import com.truworth.wellnesscorner.data.SharedPreferenceHelper;
import com.truworth.wellnesscorner.repo.RegistrationRepository;
import com.truworth.wellnesscorner.repo.model.request.SaveMemberHealthGoalsRequest;
import com.truworth.wellnesscorner.repo.model.response.HealthGoalResponse;
import com.truworth.wellnesscorner.repo.model.response.SaveMemberHealthGoalsResponse;
import com.truworth.wellnesscorner.utils.SingleLiveEvent;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;


/**
 * Created by PalakC on 4/5/2018.
 */

public class HealthGoalViewModel extends BaseViewModel {
    public ObservableField<String> errorMessage = new ObservableField<>();
    public ObservableBoolean isEnableContinue = new ObservableBoolean();
    SingleLiveEvent<List<HealthGoalResponse.HealthGoalItem>> healthGoalItem = new SingleLiveEvent<>();
    SingleLiveEvent<Void> onSaveGoals = new SingleLiveEvent<>();
    @Inject
    RegistrationRepository healthRepository;
    @Inject
    SharedPreferenceHelper preferenceHelper;
    private ArrayList<Integer> healthGoalsIds = new ArrayList<>();

    public HealthGoalViewModel() {
        isEnableContinue.set(false);
        TheWellnessCornerApp.getApp().component().inject(this);
    }

    public SingleLiveEvent<List<HealthGoalResponse.HealthGoalItem>> getOnHealthGoal() {
        return healthGoalItem;
    }

    public SingleLiveEvent<Void> getOnSaveGoals() {
        return onSaveGoals;
    }

    public void healthGoalItem() {

        healthRepository.healthGoal().subscribe(new Observer<HealthGoalResponse>() {
            @Override
            public void onSubscribe(Disposable d) {

            }

            @Override
            public void onNext(HealthGoalResponse healthGoalResponse) {
                if (!healthGoalResponse.isHasError()) {
                    healthGoalItem.setValue(healthGoalResponse.getData());
                    //   Log.d(TAG, "onNext: Successful!"+healthGoalResponse.getData());

                } else {
                    errorMessage.set(healthGoalResponse.getError().getMessage());
                }
            }

            @Override
            public void onError(Throwable e) {

            }

            @Override
            public void onComplete() {

            }
        });

    }

    public void setSelectedGoalId(ArrayList<Integer> healthIds) {
        this.healthGoalsIds = (healthIds);
        if (healthIds.size() > 0)
            isEnableContinue.set(true);
        else
            isEnableContinue.set(false);
    }

    public void saveHealthGoalItem() {

        SaveMemberHealthGoalsRequest goalsRequest = new SaveMemberHealthGoalsRequest();
        goalsRequest.setHealthGoalIds(healthGoalsIds);

        healthRepository.saveGoals(goalsRequest).subscribe(new Observer<SaveMemberHealthGoalsResponse>() {
            @Override
            public void onSubscribe(Disposable d) {

            }

            @Override
            public void onNext(SaveMemberHealthGoalsResponse saveMemberHealthGoalsResponse) {
                if (!saveMemberHealthGoalsResponse.isHasError()) {
                    //   Log.d(TAG, "onNext: Successful!"+healthGoalResponse.getData());
                    if (saveMemberHealthGoalsResponse.getData() != null && saveMemberHealthGoalsResponse.getData().isIsSave())
                        preferenceHelper.saveProfileStepNumber(7);
                    clickOnContinue();
                } else {
                    errorMessage.set(saveMemberHealthGoalsResponse.getError().getMessage());
                }
            }

            @Override
            public void onError(Throwable e) {

            }

            @Override
            public void onComplete() {

            }
        });

    }

    private void clickOnContinue() {
        onSaveGoals.call();
    }

}
