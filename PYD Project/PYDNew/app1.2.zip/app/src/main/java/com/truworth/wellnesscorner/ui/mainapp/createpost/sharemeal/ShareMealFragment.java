package com.truworth.wellnesscorner.ui.mainapp.createpost.sharemeal;

import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import com.truworth.discoverlib.interfaces.OnLoadMoreListener;
import com.truworth.discoverlib.utils.NetworkFactory;
import com.truworth.wellnesscorner.BR;
import com.truworth.wellnesscorner.R;
import com.truworth.wellnesscorner.base.BaseFragment;
import com.truworth.wellnesscorner.databinding.FragmentShareMealBinding;
import com.truworth.wellnesscorner.model.ShareMealBean;
import com.truworth.wellnesscorner.ui.mainapp.createpost.ShareActivity;
import com.truworth.wellnesscorner.utils.AppConstants;
import com.twc.dailylog.MealActivity;
import com.twc.dailylog.model.beans.DailyLogUser;
import com.twc.dailylog.utils.DailyLogConfig;

import java.util.ArrayList;
import java.util.List;

public class ShareMealFragment extends BaseFragment<FragmentShareMealBinding, ShareMealViewModel> {
    public static final String TAG = "ShareMealFragment";
    ShareMealViewModel viewModel;
    List<ShareMealBean> headerList;
    android.support.v4.app.FragmentManager fragmentManager;
    ShareMealAdapter shareMealAdapter;
    RecyclerView recyclerView;
    private final int visibleThreshold = 5;
    boolean isLoadMore = false;

    private int page = 1;
    private int lastVisibleItem, totalItemCount;
    private OnLoadMoreListener onLoadMoreListener;
    private Handler handler = new Handler();
    private Runnable runnableApiCall = new Runnable() {
        @Override
        public void run() {
            viewModel.isLastResult = false;
            viewModel.loading = false;
            if (page == 1) {
                headerList.clear();
            }
            shareMealAdapter.notifyDataSetChanged();
            viewModel.loadMealPostData(page, false);
        }
    };

    public ShareMealFragment() {
        // Required empty public constructor
    }

    public static ShareMealFragment newInstance() {
        ShareMealFragment fragment = new ShareMealFragment();

        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        headerList = new ArrayList<>();
        fragmentManager = getFragmentManager();
        shareMealAdapter = new ShareMealAdapter(getActivity(), headerList, fragmentManager, viewModel.memberName, viewModel.memberImageUrl);

        headerList.clear();
        handler.postDelayed(runnableApiCall, 100);
    }

    @Override
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        recyclerView = getViewDataBinding().rvShareMeal;
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false);
        recyclerView.setLayoutManager(linearLayoutManager);
        recyclerView.setAdapter(shareMealAdapter);

        setOnLoadMoreListener(linearLayoutManager);

        //if(headerList.isEmpty())
         /* headerList.clear();
        handler.postDelayed(runnableApiCall, 100);*/

        setHeaderDataObserver();
        attachRemoveLoadingObserver();
        trackTodayMealObserver();

    }
    @Override
    public void onDestroy() {
        super.onDestroy();
        if (headerList != null) {
            headerList.clear();
            shareMealAdapter.notifyDataSetChanged();
            shareMealAdapter = null;
            headerList = null;
        }
    }

    //    @Override
    //    public void setUserVisibleHint(final boolean isVisibleToUser) {
    //        super.setUserVisibleHint(isVisibleToUser);
    //        new Handler().postDelayed(new Runnable() {
    //            @Override
    //            public void run() {
    //                if (isVisibleToUser && shareMealAdapter != null && shareMealAdapter.getItemCount() == 0) {
    //                    page = 1;
    //                    if (recyclerView != null) {
    //                        recyclerView.setAdapter(shareMealAdapter);
    //                    }
    //                    isLoadMore = false;
    //                }
    //            }
    //        }, 150);
    //    }
    @Override
    public int getBindingVariable() {
        return BR.viewModel;
    }

    @Override
    public int getLayoutId() {
        return R.layout.fragment_share_meal;
    }

    @Override
    public ShareMealViewModel getViewModel() {
        viewModel = ViewModelProviders.of(this).get(ShareMealViewModel.class);
        return viewModel;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
    }

    @Override
    public void onDetach() {
        super.onDetach();
    }

    private void setOnLoadMoreListener(final LinearLayoutManager linearLayoutManager) {
        onLoadMoreListener = new OnLoadMoreListener() {
            @Override
            public void onLoadMore() {
                if (!viewModel.isLastResult) {
                    if (headerList.size() > 5) {
                        isLoadMore = true;
                        if (NetworkFactory.getInstance().isNetworkAvailable(getActivity())) {
                            headerList.add(null);
                            shareMealAdapter.notifyItemInserted(headerList.size() - 1);
                            new Handler().postDelayed(new Runnable() {
                                @Override
                                public void run() {

                                    page = page + 1;
                                    handler.postDelayed(runnableApiCall, 100);
                                }

                            }, 500);
                        } else {
                            //showNetWorkDialog();
                        }
                    }

                }
            }
        };

        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                totalItemCount = linearLayoutManager.getItemCount();
                lastVisibleItem = linearLayoutManager.findLastVisibleItemPosition();
                if (!viewModel.loading && totalItemCount <= (lastVisibleItem + visibleThreshold)) {
                    onLoadMoreListener.onLoadMore();
                    viewModel.loading = true;
                }

               /* if(dy<0)
                    getViewDataBinding().imgUpArrow.setVisibility(View.GONE);
                else
                    getViewDataBinding().imgUpArrow.setVisibility(View.VISIBLE);*/
            }
        });
    }

    private void setHeaderDataObserver() {
        viewModel.getHeaderList().observe(this, new Observer<List<ShareMealBean>>() {
            @Override
            public void onChanged(@Nullable List<ShareMealBean> headerData) {
                headerList.clear();
                headerList.addAll(headerData);
                shareMealAdapter.setMember(viewModel.memberName, viewModel.memberImageUrl);
                shareMealAdapter.notifyDataSetChanged();
            }
        });
    }


    private void attachRemoveLoadingObserver() {
        viewModel.getRemoveLoading().observe(this, new Observer<Void>() {
            @Override
            public void onChanged(@Nullable Void aVoid) {
                //Success, update UI
                removeProgressLoading();
            }
        });
    }

    private void removeProgressLoading() {
        if (headerList.size() > 0 && headerList.get(headerList.size() - 1) == null) {
            headerList.remove(headerList.size() - 1);
            shareMealAdapter.notifyDataSetChanged();
        }
    }

    private void trackTodayMealObserver() {
        viewModel.getTrackTodayMeal().observe(this, new Observer<Void>() {
            @Override
            public void onChanged(@Nullable Void aVoid) {
                //Success, update UI
                DailyLogConfig.dailyLogUser.setType("Meal");
                DailyLogConfig.dailyLogUser.setMealType("Breakfast");
                Intent intent = new Intent(getActivity(), MealActivity.class);
                //startActivity(intent);
                startActivityForResult(intent, AppConstants.ADD_FOOD_DAILY_LOG);
            }
        });
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        viewModel.loadMealPostData(1, true);
    }
}
