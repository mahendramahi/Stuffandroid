package com.twc.remindermodule.fragments;

import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.RelativeLayout;

import com.twc.remindermodule.R;
import com.twc.remindermodule.R2;
import com.twc.remindermodule.ReminderActivity;
import com.twc.remindermodule.adapter.SleepLogSectionAdapter;
import com.twc.remindermodule.dialog.ApiErrorDialog;
import com.twc.remindermodule.dialog.NetworkErrorDialog;
import com.twc.remindermodule.model.beans.SectionSleepLogItem;
import com.twc.remindermodule.model.requestbody.GetSleepLogBody;
import com.twc.remindermodule.model.response.GetSleepLogResponse;
import com.twc.remindermodule.model.response.SaveSleepLogResponse;
import com.twc.remindermodule.rest.ReminderConfig;
import com.twc.remindermodule.rest.RestClient;
import com.twc.remindermodule.utils.Constant;
import com.twc.remindermodule.utils.DateFactory;
import com.twc.remindermodule.utils.NetworkFactory;
import com.twc.remindermodule.utils.Utils;
import com.twc.remindermodule.views.CustomProgressDialog;
import com.twc.remindermodule.views.CustomTextView;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;

import butterknife.BindView;
import butterknife.OnClick;
import butterknife.Unbinder;
import retrofit2.Call;
import retrofit2.Callback;

/**
 * Created by richas on 1/18/2018.
 */
// Last Updated on 07/02/2018 by richas implemented Error screens
public class SleepTrackerLogsFragment extends BaseFragment implements OnRetryAfterNetworkError {
    private final int visibleThreshold = 5;
    @BindView(R2.id.tvBack)
    CustomTextView tvBack;
    @BindView(R2.id.rvSleepLogs)
    RecyclerView rvSleepLogs;
    @BindView(R2.id.rootView)
    RelativeLayout rootView;
    @BindView(R2.id.fabAddSleepLog)
    FloatingActionButton fabAddSleepLog;
    @BindView(R2.id.tvNoDataAvaiable)
    CustomTextView tvNoDataAvaiable;
    Unbinder unbinder;
    SleepLogSectionAdapter sleepLogSectionAdapter;
    ArrayList<SectionSleepLogItem> sectionItemsList;
    ArrayList<GetSleepLogResponse.DataSleepLogItem> sleepLogList;
    private int pageIndex = 1;
    private int lastVisibleItem, totalItemCount;
    private boolean loading;
    private OnLoadMoreListener onLoadMoreListener;
    private boolean isLastResult = false;
    private LinkedHashMap<String, ArrayList<GetSleepLogResponse.DataSleepLogItem>> hashMapDateList;
    private OnTrackerReadingSave onTrackerReadingSave;

    private Handler handler = new Handler();
    private Runnable runnable = new Runnable() {
        @Override
        public void run() {
            tvNoDataAvaiable.setVisibility(View.GONE);
            rvSleepLogs.setVisibility(View.VISIBLE);
            isLastResult = false;
            pageIndex = 1;
            loading = false;
            sleepLogList.clear();
            hashMapDateList.clear();
            sectionItemsList.clear();
            sleepLogSectionAdapter.notifyDataSetChanged();
            getSleepLogApiCall(false);
            rvSleepLogs.scrollToPosition(0);
        }
    };

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        sleepLogList = new ArrayList<>();
        sectionItemsList = new ArrayList<>();
        hashMapDateList = new LinkedHashMap<>();
        sleepLogSectionAdapter = new SleepLogSectionAdapter(sectionItemsList, getActivity());
    }

    @Override
    protected int getFragmentLayout() {
        return R.layout.fragment_sleep_tracker_logs;
    }

    @Override
    protected void onFragmentReady() {

        rvSleepLogs.setHasFixedSize(true);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getActivity());
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        rvSleepLogs.setLayoutManager(linearLayoutManager);
        rvSleepLogs.setAdapter(sleepLogSectionAdapter);
        handler.postDelayed(runnable, 50);
        setOnLoadMoreListener(linearLayoutManager);

        rvSleepLogs.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);

                if (dy >0) {
                    // Scroll Down
                    if (fabAddSleepLog.isShown()) {
                        fabAddSleepLog.hide();
                    }
                } else if (dy <0) {
                    // Scroll Up
                    if (!fabAddSleepLog.isShown()) {
                        fabAddSleepLog.show();
                    }
                }
            }
        });
    }

    private void setOnLoadMoreListener(final LinearLayoutManager linearLayoutManager) {
        onLoadMoreListener = new OnLoadMoreListener() {
            @Override
            public void onLoadMore() {
                if (!isLastResult) {
                    if (sleepLogList.size() > 5) {
                        // create this obj to show loading in bottom by paging
                        SectionSleepLogItem logItem = new SectionSleepLogItem();
                        logItem.setMonthName("null");
                        ArrayList<GetSleepLogResponse.DataSleepLogItem> items = new ArrayList<>();
                        GetSleepLogResponse.DataSleepLogItem sleepLogItem = new GetSleepLogResponse.DataSleepLogItem();
                        sleepLogItem.setSleepLog_Remarks("null");
                        items.add(sleepLogItem);
                        logItem.setmSleepLogArrayList(items);
                        sectionItemsList.add(logItem);

                        sleepLogSectionAdapter.notifyItemInserted(sectionItemsList.size() - 1);
                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                pageIndex = pageIndex + 1;
                                getSleepLogApiCall(true);
                            }
                        }, 500);
                    }
                }
            }
        };

        rvSleepLogs.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                totalItemCount = linearLayoutManager.getItemCount();
                lastVisibleItem = linearLayoutManager.findLastVisibleItemPosition();
                if (!loading && totalItemCount <= (lastVisibleItem + visibleThreshold)) {
                    onLoadMoreListener.onLoadMore();
                    loading = true;
                }
            }
        });
    }

    @Override
    public void onResume() {
        super.onResume();
      //  ((ReminderActivity) getActivity()).hideToolbar();
    }

    private void getSleepLogApiCall(boolean isLoadMore) {
        if (NetworkFactory.getInstance().isNetworkAvailable(getActivity())) {
            final CustomProgressDialog pd = new CustomProgressDialog(getActivity(), R.style.custom_progress_style, true);
            if (!isLoadMore) {
                pd.show();
            }
            GetSleepLogBody getSleepLogBody = new GetSleepLogBody();
            getSleepLogBody.setMemberID(ReminderConfig.reminderUser.getUserID());
            getSleepLogBody.setPageIndex(String.valueOf(pageIndex));
            getSleepLogBody.setPageSize("10");

            RestClient restClient = new RestClient(getActivity(), ReminderConfig.BASE_URL, ReminderConfig.DEBUG);
            restClient.getRecommendedService().getSleepLogTracker(getSleepLogBody).enqueue(new Callback<GetSleepLogResponse>() {
                @Override
                public void onResponse(Call<GetSleepLogResponse> call, retrofit2.Response<GetSleepLogResponse> response) {
                    if (isAdded() && getActivity() != null) {
                        if (pd != null && pd.isShowing()) {
                            pd.dismiss();
                        }
                        removeProgressLoading();
                        loading = false;
                        if (response != null && response.body() != null) {
                            if (response.body().getStatus() == 0) {
                                tvNoDataAvaiable.setVisibility(View.GONE);
                                rvSleepLogs.setVisibility(View.VISIBLE);
                                if (response.body().getData() != null && response.body().getData().size() > 0) {
                                    sectionItemsList.clear();
                                    sleepLogList.addAll(response.body().getData());
                                    for (GetSleepLogResponse.DataSleepLogItem sleepLogItem : response.body().getData()) {

                                        String dateString = DateFactory.getInstance().truncateMilliseconds(sleepLogItem.getSleepLog_DateTime());
                                        String date = DateFactory.getInstance().formatDate(Constant.SERVER_DATE_FORMAT_WITH_MILLISECONDS, "MMMM yyyy", dateString);

                                        if (hashMapDateList.containsKey(date)) {
                                            hashMapDateList.get(date).add(sleepLogItem);
                                        } else {
                                            ArrayList<GetSleepLogResponse.DataSleepLogItem> dataSleepLogItems = new ArrayList<>();
                                            dataSleepLogItems.add(sleepLogItem);
                                            hashMapDateList.put(date, dataSleepLogItems);
                                        }
                                    }
                                    for (Map.Entry<String, ArrayList<GetSleepLogResponse.DataSleepLogItem>> entry : hashMapDateList.entrySet()) {
                                        SectionSleepLogItem logItem = new SectionSleepLogItem();
                                        logItem.setMonthName(entry.getKey());
                                        logItem.setmSleepLogArrayList(entry.getValue());
                                        sectionItemsList.add(logItem);
                                    }
                                    sleepLogSectionAdapter.notifyDataSetChanged();
                                } else {
                                    isLastResult = true;
                                    if (sleepLogList.size() <= 0) {
                                        tvNoDataAvaiable.setVisibility(View.VISIBLE);
                                        rvSleepLogs.setVisibility(View.INVISIBLE);
                                    }
                                }

                            } else if (response.body().getStatus() == -1) {
                                //DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_response_failure), getString(R.string.str_ok), false);
                                showApiErrorDialog();
                            }
                        } else {
                            isLastResult = true;
                            //DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_response_null), getString(R.string.str_ok), false);
                            showApiErrorDialog();
                        }
                    }
                }

                @Override
                public void onFailure(Call<GetSleepLogResponse> call, Throwable t) {
                    if (isAdded() && getActivity() != null) {
                        removeProgressLoading();
                        isLastResult = true;
                        if (pd != null && pd.isShowing()) {
                            pd.dismiss();
                        }
                        showApiErrorDialog();
                        //DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_failure), getString(R.string.str_ok), false);
                    }
                }
            });
        } else {
            removeProgressLoading();
            //Utils.showSnackBarMessage(rootView, getString(R.string.internet_not_available));
            // show Network Error Screen Dialog
            NetworkErrorDialog networkErrorDialog = new NetworkErrorDialog(getActivity(), getActivity(), SleepTrackerLogsFragment.this);
            networkErrorDialog.show();
            Window window = networkErrorDialog.getWindow();
            window.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);
        }
    }
    // method to show Api Error Screen Dialog
    private void showApiErrorDialog() {
        ApiErrorDialog apiErrorDialog = new ApiErrorDialog(getActivity(), getActivity(), SleepTrackerLogsFragment.this);
        apiErrorDialog.show();
        Window window = apiErrorDialog.getWindow();
        window.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);
    }
    private void removeProgressLoading() {
        if (sectionItemsList != null && sectionItemsList.size() > 0) {
            sectionItemsList.remove(sectionItemsList.size() - 1);
            sleepLogSectionAdapter.notifyDataSetChanged();
        }
    }

    @OnClick({R2.id.tvBack, R2.id.fabAddSleepLog})
    public void onClick(View view) {
        int i = view.getId();
        if (i == R.id.tvBack) {
            getFragmentManager().popBackStackImmediate();

        } else if (i == R.id.fabAddSleepLog) {
            Utils.replaceFragment(getFragmentManager(), new SleepTrackerFragment(), SleepTrackerFragment.class.getSimpleName(), true, R.id.fragmentContainerReminder);

        }
    }

    @Override
    public void onRetry() {
        getSleepLogApiCall(false);
    }

    public void setTrackerReadingCallback(OnTrackerReadingSave onTrackerReadingSave) {
        this.onTrackerReadingSave=onTrackerReadingSave;
    }
}
