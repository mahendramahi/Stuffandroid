package com.truworth.wellnesscorner.ui.mainapp.circledetail.members;

import android.databinding.ObservableBoolean;
import android.databinding.ObservableField;
import android.databinding.ObservableInt;
import android.text.Editable;
import android.text.TextWatcher;

import com.truworth.wellnesscorner.TheWellnessCornerApp;
import com.truworth.wellnesscorner.base.BaseViewModel;
import com.truworth.wellnesscorner.model.CircleMemberListBean;
import com.truworth.wellnesscorner.repo.DashboardRepository;
import com.truworth.wellnesscorner.repo.model.request.CircleMemberRequest;
import com.truworth.wellnesscorner.repo.model.response.CircleMembersResponse;
import com.truworth.wellnesscorner.utils.SingleLiveEvent;

import java.util.List;

import javax.inject.Inject;

import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;

public class CircleMemberViewModel extends BaseViewModel {

    public boolean isSearch = false;
    public ObservableInt memberCount = new ObservableInt();
    public ObservableField<String> circleIdentity = new ObservableField<>();
    int pageIndex = 1;
    public ObservableBoolean showNoData = new ObservableBoolean();

    public ObservableBoolean showMemberCount = new ObservableBoolean();

    public int getPageIndex() {
        return pageIndex;
    }

    public void setPageIndex(int pageIndex) {
        this.pageIndex = pageIndex;
    }

    public SingleLiveEvent<List<CircleMemberListBean>> members = new SingleLiveEvent<>();

    public SingleLiveEvent<List<CircleMemberListBean>> getMembers() {
        return members;
    }

    public ObservableField<String> search = new ObservableField<>();

    public SingleLiveEvent<Void> notifySearch = new SingleLiveEvent<>();

    public SingleLiveEvent<Void> getNotifySearch() {
        return notifySearch;
    }

    public SingleLiveEvent<Void> removeLoading = new SingleLiveEvent<>();

    public SingleLiveEvent<Void> getRemoveLoading() {
        return removeLoading;
    }

    SingleLiveEvent<Void> upArrow = new SingleLiveEvent<>();

    public SingleLiveEvent<Void> getUpArrow() {
        return upArrow;
    }

    public void setCircleIdentity(String circleIdentity) {
        this.circleIdentity.set(circleIdentity);
    }

    public boolean loading;

    public boolean isLastResult = false;

    @Inject
    DashboardRepository dashboardRepository;

    public CircleMemberViewModel() {
        TheWellnessCornerApp.getApp().component().inject(this);
    }

    public void loadMembers(String circleIdentity, int pageIndex) {

        CircleMemberRequest circleMemberRequest = new CircleMemberRequest();
        circleMemberRequest.setId(circleIdentity);
        circleMemberRequest.setPageIndex(pageIndex);
        circleMemberRequest.setSearchTerm(search.get());


        dashboardRepository.getCircleMembers(circleMemberRequest).subscribe(new Observer<CircleMembersResponse>() {
            @Override
            public void onSubscribe(Disposable d) {

            }

            @Override
            public void onNext(CircleMembersResponse circleMembersResponse) {
                removeLoading.call();
                loading = false;
                showMemberCount.set(true);
                if (!circleMembersResponse.isHasError()) {
                    isLastResult = false;
                    members.setValue(circleMembersResponse.getData().getCircleMemberList());
                    memberCount.set(circleMembersResponse.getData().getTotalMembers());
                    showNoData.set(false);
                } else {
                    removeLoading.call();
                    if (isSearch) {
                        notifySearch.call();
                    } else {
                        isLastResult = true;
                            if (pageIndex == 1) {
                            showNoData.set(true);
                        }
                    }
                }
            }

            @Override
            public void onError(Throwable e) {
                removeLoading.call();
            }

            @Override
            public void onComplete() {

            }
        });

    }

    public TextWatcher searchTextWatcher() {
        return new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

                search.set(charSequence.toString());

                if(search.get().isEmpty())
                    isSearch = false;
                else
                    isSearch = true;

                pageIndex = 1;
                loadMembers(circleIdentity.get(), pageIndex);
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        };
    }

    public void upArrowClick() {
        upArrow.call();
    }
}
