package com.truworth.wellnesscorner.repo.model.request;

public class PostHiFiRequest {

    private String PostIdentity;

    public String getPostIdentity() {
        return PostIdentity;
    }

    public void setPostIdentity(String PostIdentity) {
        this.PostIdentity = PostIdentity;
    }
}
