package com.twc.store.restservice;



import com.twc.store.model.requestbody.CheckProductAvailableBody;
import com.twc.store.model.requestbody.SaveMemberBillingDetailsBody;
import com.twc.store.model.requestbody.StoreProductDetailBody;
import com.twc.store.model.requestbody.StoreProductsBody;
import com.twc.store.model.requestbody.UpdateProductTransactionBody;
import com.twc.store.model.response.CheckProductAvailbilityResponse;
import com.twc.store.model.response.SaveMemberBillingDetailsResponse;
import com.twc.store.model.response.StoreProductDetailResponse;
import com.twc.store.model.response.StoreProductResponse;
import com.twc.store.model.response.UpdateProductTransactionResponse;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

/**
 * If this code works it was written by Somesh Kumar on 04 May, 2017. If not, I don't know who wrote it.
 */
public interface WellnessStoreService {

    @POST("Member/Product/GetProductList")
    Call<StoreProductResponse> getProducts(@Body StoreProductsBody ProductsBody);

    @POST("Member/Product/GetProductDetail")
    Call<StoreProductDetailResponse> getProductDetail(@Body StoreProductDetailBody ProductsBody);

    @POST("Member/Product/CheckProductIsAvailable")
    Call<CheckProductAvailbilityResponse> checkProductIsAvailable(@Body CheckProductAvailableBody Body);

    @POST("Member/Product/SaveMemberBillingDetails")
    Call<SaveMemberBillingDetailsResponse> saveMemberBillingDetails(@Body SaveMemberBillingDetailsBody saveMemberBillingDetailsBody);

    @POST("Member/Product/UpdateMemberProductOrderTransaction")
    Call<UpdateProductTransactionResponse> updateProductOrderTransaction(@Body UpdateProductTransactionBody updateProductTransactionBody);

}
