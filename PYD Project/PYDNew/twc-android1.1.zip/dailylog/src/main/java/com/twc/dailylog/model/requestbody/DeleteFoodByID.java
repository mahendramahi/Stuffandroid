package com.twc.dailylog.model.requestbody;

/**
 * Created by PankajS on 8/17/2016.
 */
public class DeleteFoodByID
    {
    private int NutritionID;

    public int getNutritionID()
        {
        return NutritionID;
        }

    public void setNutritionID(int nutritionID)
        {
        NutritionID = nutritionID;
        }
    }
