package com.twc.remindermodule.model.response;

/**
 * If this code works it was written by Somesh Kumar on 09 October, 2017. If not, I don't know who wrote it.
 */
public class BaseResponse {
    private int status;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }
}
