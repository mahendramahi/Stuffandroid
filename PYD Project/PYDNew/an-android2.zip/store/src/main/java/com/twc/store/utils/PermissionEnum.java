package com.twc.store.utils;

/**
 * If this code works it was written by Somesh Kumar on 20 March, 2017. If not, I don't know who wrote it.
 */
public enum PermissionEnum {
    CALENDAR, CAMERA, CONTACTS, LOCATION, MICROPHONE, PHONE, SENSORS, SMS, STORAGE
}
