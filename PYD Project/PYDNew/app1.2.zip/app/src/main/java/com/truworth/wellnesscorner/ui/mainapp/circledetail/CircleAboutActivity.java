package com.truworth.wellnesscorner.ui.mainapp.circledetail;

import android.app.Activity;
import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Context;
import android.content.Intent;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import com.truworth.discoverlib.fragment.ShowImageDialog;
import com.truworth.wellnesscorner.R;
import com.truworth.wellnesscorner.databinding.FragmentCircleAboutBinding;
import com.truworth.wellnesscorner.model.CircleCategoryDataBean;

import java.util.ArrayList;
import java.util.List;

public class CircleAboutActivity extends AppCompatActivity {
    public static final String CIRCLE_IDENTITY = "circleIdentity";
    public static int REUEST_CODE = 101;
    FragmentCircleAboutBinding binding;
    CircleAboutViewModel viewModel;
    List<CircleCategoryDataBean> categoryList;
    CircleAboutCategoryAdapter circleAboutCategoryAdapter;
    private String CircleIdentity = "";

    public static void start(Activity context, String circleIdentity) {
        Intent intent = new Intent(context, CircleAboutActivity.class);
        intent.putExtra(CircleAboutActivity.CIRCLE_IDENTITY, circleIdentity);
        context.startActivityForResult(intent,REUEST_CODE);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = DataBindingUtil.setContentView(this, R.layout.fragment_circle_about);
        viewModel = ViewModelProviders.of(this).get(CircleAboutViewModel.class);
        binding.setViewModel(viewModel);
        Toolbar toolbar = binding.circleAboutToolbar;
        setupToolbar(toolbar);

        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            CircleIdentity = extras.getString(CIRCLE_IDENTITY);
        }

        categoryList = new ArrayList<>();
        circleAboutCategoryAdapter = new CircleAboutCategoryAdapter(categoryList);
        viewModel.loadAboutDetails(CircleIdentity);
        setUpMemberRecycler();
        setDataObserver();


    }

    private void setupToolbar(Toolbar toolbar) {
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
            getSupportActionBar().setDisplayShowTitleEnabled(false);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_activity_circle_detail, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void setUpMemberRecycler() {
        RecyclerView recyclerView = binding.rvCategoryType;
        recyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));
        recyclerView.setAdapter(circleAboutCategoryAdapter);
    }

    private void setDataObserver() {
        viewModel.getCategory().observe(this, new Observer<List<CircleCategoryDataBean>>() {
            @Override
            public void onChanged(@Nullable List<CircleCategoryDataBean> categoryData) {

                if (categoryData != null) {
                    categoryList.clear();
                    categoryList.addAll(categoryData);
                    circleAboutCategoryAdapter.notifyDataSetChanged();

                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            if (binding.tvAboutDetail.getText().length() > 0 && binding.tvAboutDetail.getLineCount() > 1) {
                                viewModel.showSeeMore.set(true);
                                viewModel.isExpanded.set(true);
                            } else {
                                viewModel.showSeeMore.set(false);
                                viewModel.isExpanded.set(false);
                            }
                        }
                    }, 200);

                }
            }
        });

        viewModel.getZoomImage().observe(this, new Observer<String>() {
            @Override
            public void onChanged(@Nullable String imagePath) {

                ShowImageDialog sd = new ShowImageDialog(CircleAboutActivity.this, imagePath, "");
                sd.show();
            }
        });

        viewModel.getExpandData().observe(this, new Observer<Void>() {
            @Override
            public void onChanged(@Nullable Void aVoid) {
                //Success, update UI
                if (viewModel.isExpanded.get()) {
                    binding.tvAboutDetail.collapse();
                    binding.tvSeeMore.setText("SEE MORE");
                } else {
                    binding.tvAboutDetail.expand();
                    binding.tvSeeMore.setText("SEE LESS");
                }
            }
        });
        viewModel.getOnJoinNow().observe(this, new Observer<String>() {
            @Override
            public void onChanged(@Nullable String message) {
               // Toast.makeText(CircleAboutActivity.this, message, Toast.LENGTH_SHORT).show();
                Intent returnIntent = new Intent();
                setResult(Activity.RESULT_OK, returnIntent);
                finish();
            }
        });
    }
}
