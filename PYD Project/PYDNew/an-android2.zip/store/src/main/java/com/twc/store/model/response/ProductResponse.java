package com.twc.store.model.response;

import com.twc.store.model.beans.StoreDataBeanItem;

import java.util.List;

public class ProductResponse {

    private int status;
    private List<StoreDataBeanItem> Products;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public List<StoreDataBeanItem> getProducts() {
        return Products;
    }

    public void setProducts(List<StoreDataBeanItem> Products) {
        this.Products = Products;
    }
}
