package com.twc.store.model.response;


import com.twc.store.model.beans.ProductItem;
import com.twc.store.model.requestbody.SaveMemberBillingDetailsBody;

/**
 * Created by GurvinderS on 5/9/2017.
 */

public class StoreProductDetailResponse {


    private DataBean Data;
    private int status;

    public DataBean getData() {
        return Data;
    }

    public void setData(DataBean Data) {
        this.Data = Data;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public static class DataBean {
        private ProductItem Products;
        private SaveMemberBillingDetailsBody MemberBillingDetails;

        public ProductItem getProducts() {
            return Products;
        }

        public void setProducts(ProductItem Products) {
            this.Products = Products;
        }

        public SaveMemberBillingDetailsBody getMemberBillingDetails() {
            return MemberBillingDetails;
        }

        public void setMemberBillingDetails(SaveMemberBillingDetailsBody memberBillingDetails) {
            MemberBillingDetails = memberBillingDetails;
        }
    }
}
