package com.truworth.wellnesscorner.ui.mainapp.circledetail.challenges;

import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Context;
import android.content.Intent;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import com.truworth.wellnesscorner.R;
import com.truworth.wellnesscorner.databinding.ActivityCircleDetailChallengeBinding;
import com.truworth.wellnesscorner.interfaces.OnLoadMoreListener;
import com.truworth.wellnesscorner.model.Post;
import com.truworth.wellnesscorner.ui.mainapp.createpost.CreatePostActivity;
import com.truworth.wellnesscorner.ui.mainapp.post.PostRecyclerAdapter;
import com.truworth.wellnesscorner.ui.mainapp.post.IPostListItem;
import com.truworth.wellnesscorner.ui.mainapp.post.postcomment.PostCommentActivity;

import java.util.ArrayList;
import java.util.List;

import im.ene.toro.PlayerSelector;
import im.ene.toro.exoplayer.ToroExo;
import im.ene.toro.widget.Container;

public class ChallengeDetailActivity extends AppCompatActivity {


    public static final String CIRCLE_IDENTITY = "circleIdentity";
    public static final String CHALLENGE_IDENTITY = "challengeIdentity";
    public static final String CHALLENGE_TYPE_ID = "challengeTypeId";
    ChallengeDetailViewModel viewModel;
    ActivityCircleDetailChallengeBinding binding;
    Container recyclerView;
    LinearLayoutManager linearLayoutManager;
    List<IPostListItem> postList;
    PostRecyclerAdapter adapter;
    PlayerSelector selector = PlayerSelector.DEFAULT; // visible to user by default.
    private String ChallengeIdentity = "";
    private int ChallengeTypeId;
    private String CircleIdentity = "";
    // CircleResponse response;
    private int nestedScrollViewX = 0;
    private int nestedScrollViewY = 0;
    private final int visibleThreshold = 5;
    boolean isLoadMore = false;
    private int page = 1;
    private OnLoadMoreListener onLoadMoreListener;
    private int lastVisibleItem, totalItemCount;
    private Handler handlerCircleHomeApi = new Handler();
    private Runnable runnable = new Runnable() {
        @Override
        public void run() {

            page = 1;
            viewModel.loadCirclesPosts(CircleIdentity, ChallengeIdentity,page);
        }
    };

    public static void start(Context context, String challengeIdentity, String circleIdentity, int challengeTypeId) {

        Intent intent = new Intent(context, ChallengeDetailActivity.class);
        intent.putExtra(ChallengeLeaderBoardActivity.CHALLENGE_IDENTITY, challengeIdentity);
        intent.putExtra(ChallengeDetailActivity.CIRCLE_IDENTITY, circleIdentity);
        intent.putExtra(ChallengeDetailActivity.CHALLENGE_TYPE_ID, challengeTypeId);
        context.startActivity(intent);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = DataBindingUtil.setContentView(this, R.layout.activity_circle_detail_challenge);
        viewModel = ViewModelProviders.of(this).get(ChallengeDetailViewModel.class);

        Toolbar toolbar = binding.circleDetailToolbar;
        setupToolbar(toolbar);
        toolbar.setTitle("Challenge");

        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            ChallengeIdentity = extras.getString(CHALLENGE_IDENTITY);
            CircleIdentity = extras.getString(CIRCLE_IDENTITY);
            ChallengeTypeId = extras.getInt(CHALLENGE_TYPE_ID);
        }
        // response = new Gson().fromJson(Utils.loadJSONFromAsset(this), CircleResponse.class);
        binding.setViewModel(viewModel);

        //binding.rvChallengeDetailPosts.scrollTo(0, 0);

        binding.rvChallengeDetailPosts.smoothScrollToPosition(0);
        linearLayoutManager = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);
        ToroExo.with(this).getDefaultCreator();
        postList = new ArrayList<>();
        //viewModel.loadCirclesPosts(CircleIdentity, ChallengeIdentity);
        handlerCircleHomeApi.postDelayed(runnable, 50);
        // viewModel.setPostList(response);

        binding.rvChallengeDetailPosts.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);

                if (dy < 0) {
                    binding.imgUpArrow.setVisibility(View.GONE);
                } else {
                    binding.imgUpArrow.setVisibility(View.VISIBLE);
                }

            }
        });

        setUpRecyclerView();
        setDataObserver();
        setUpArrowObserver();
        setScoreBoardObserver();
        attachRemoveLoadingObserver();

    }

    private void setupToolbar(Toolbar toolbar) {
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
            getSupportActionBar().setDisplayShowTitleEnabled(false);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_activity_circle_detail, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void setUpRecyclerView() {
        recyclerView = binding.rvChallengeDetailPosts;
        recyclerView.setLayoutManager(linearLayoutManager);
        linearLayoutManager.setItemPrefetchEnabled(true);
        // postList.add(0, new Post());
        adapter = new PostRecyclerAdapter(this, postList, CircleIdentity, "");
        recyclerView.setAdapter(adapter);
        recyclerView.setCacheManager(adapter);
        setOnLoadMoreListener(linearLayoutManager);
        // FIXME Only use the following workaround when using this Fragment in ViewPager.
        boolean viewPagerMode = true;
        if (viewPagerMode) {
            recyclerView.setPlayerSelector(null);
            // Using TabLayout has a downside: once we click to a tab to change page, there will be no animation,
            // which will cause our setup doesn't work well. We need a delay to make things work.
            new Handler().postDelayed(() -> {
                if (recyclerView != null) {
                    recyclerView.setPlayerSelector(selector);
                }
            }, 200);
        } else {
            recyclerView.setPlayerSelector(selector);
        }

    }

    private void setOnLoadMoreListener(final LinearLayoutManager linearLayoutManager) {
        onLoadMoreListener = new OnLoadMoreListener() {
            @Override
            public void onLoadMore() {
                if (!viewModel.isLastResult) {
                    if (postList != null && postList.size() > 5) {
                        postList.add(null);
                        adapter.notifyItemInserted(postList.size() - 1);
                        recyclerView.getLayoutManager().scrollToPosition(postList.size());
                        page = page + 1;
                        isLoadMore = true;
                        viewModel.loadCirclesPosts(CircleIdentity, ChallengeIdentity,page);
                    }
                }
            }
        };


        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                totalItemCount = linearLayoutManager.getItemCount();
                lastVisibleItem = linearLayoutManager.findLastVisibleItemPosition();
                if (!viewModel.loading && totalItemCount <= (lastVisibleItem + visibleThreshold)) {

                    onLoadMoreListener.onLoadMore();
                    viewModel.loading = true;
                }


            }
        });

    }
    private void attachRemoveLoadingObserver() {
        viewModel.getRemoveLoading().observe(this, new Observer<Void>() {
            @Override
            public void onChanged(@Nullable Void aVoid) {
                //Success, update UI
                if (postList.size() > 0 && postList.get(postList.size() - 1) == null) {
                    postList.remove(postList.size() - 1);
                    adapter.notifyDataSetChanged();
                }

            }
        });
    }
    private void setDataObserver() {
        viewModel.getPostsList().observe(this, new Observer<List<Post>>() {
            @Override
            public void onChanged(@Nullable List<Post> posts) {
                postList.clear();
                postList.addAll(posts);
                adapter.notifyDataSetChanged();
            }
        });
    }

    private void setUpArrowObserver() {
        viewModel.getUpArrow().observe(this, new Observer<Void>() {
            @Override
            public void onChanged(@Nullable Void avoid) {

                binding.rvChallengeDetailPosts.smoothScrollToPosition(0);
                new Handler().postDelayed(() -> binding.imgUpArrow.setVisibility(View.GONE), 500);

            }
        });
    }

    private void setScoreBoardObserver() {
        viewModel.getShowScoreboard().observe(this, new Observer<Void>() {
            @Override
            public void onChanged(@Nullable Void avoid) {

              /*  Intent intent = new Intent(ChallengeDetailActivity.this, ChallengeLeaderBoardActivity.class);
                intent.putExtra(ChallengeLeaderBoardActivity.CHALLENGE_IDENTITY, ChallengeIdentity);
                startActivity(intent);*/

                ChallengeLeaderBoardActivity.start(ChallengeDetailActivity.this, ChallengeIdentity, ChallengeTypeId);
            }
        });
    }
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PostCommentActivity.REQUEST_CODE) {
            int position= data.getIntExtra("index", 0);
            Post post = (Post) data.getSerializableExtra(PostCommentActivity.POST);
            postList.remove(position);
            postList.add(position, post);
            adapter.notifyItemChanged(position);
        }else if (requestCode == CreatePostActivity.REQUEST_CODE) {
            viewModel.loadCirclesPosts(CircleIdentity, ChallengeIdentity,1);
        }
    }

}
