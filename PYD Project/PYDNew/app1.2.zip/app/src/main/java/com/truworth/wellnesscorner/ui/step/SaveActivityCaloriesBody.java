package com.truworth.wellnesscorner.ui.step;

/**
 * If this code works it was written by Somesh Kumar on 31 March, 2017. If not, I don't know who wrote it.
 */
public class SaveActivityCaloriesBody {
    private int ActivityMemberID;
    private String ActivityName;
    private double ActivityCalorie;

    public int getActivityMemberID() {
        return ActivityMemberID;
    }

    public void setActivityMemberID(int ActivityMemberID) {
        this.ActivityMemberID = ActivityMemberID;
    }

    public String getActivityName() {
        return ActivityName;
    }

    public void setActivityName(String ActivityName) {
        this.ActivityName = ActivityName;
    }

    public double getActivityCalorie() {
        return ActivityCalorie;
    }

    public void setActivityCalorie(double ActivityCalorie) {
        this.ActivityCalorie = ActivityCalorie;
    }
}
