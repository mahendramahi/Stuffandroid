package com.twc.dailylog.utils;


public class Constant {

    /*KEYS FOR REGISTRATION,PROFILE, HEIGHT AND AREA OF INTEREST MODULE*/
    public static final String DEVICE_TYPE_ANDROID = "A";
    public static final String INTENT_KEY_SCREEN_NAME = "SCREEN_NAME";
    public static final String INTENT_KEY_BLOOD_GROUP = "BLOOD_GROUP";
    public static final String INTENT_KEY_EXERCISE_LEVEL = "EXERCISE_LEVEL";
    public static final String INTENT_KEY_WEIGHT_GOAL = "WEIGHT_GOAL";
    public static final String INTENT_KEY_HOW_ACTIVE = "HOW_ACTIVE";
    public static final String INTENT_KEY_MARITAL_STATUS = "MARITAL_STATUS";
    public static final String INTENT_KEY_TARGET_WEIGHT = "TARGET_WEIGHT";
    public static final String INTENT_KEY_BMI = "BMI";
    public static final String INTENT_KEY_LOCATION = "LOCATION";
    public static final String INTENT_KEY_COUNTRY = "COUNTRY";
    public static final String INTENT_KEY_HEIGHT_FEET = "HEIGHT_FEET";
    public static final String INTENT_KEY_HEIGHT_INCH = "HEIGHT_INCH";
    public static final String INTENT_KEY_WEIGHT = "WEIGHT";
    public static final String INTENT_REGISTRATION_STEP_RESPONSE = "RegistrationStepResponse";

    /*KEYS FOR DISCOVER MODULE */
    public static final String ARTICLE_TYPE_ALL = "ALL";
    public static final String ARTICLE_TYPE_SLIDESHOW = "SLIDESHOWS";
    public static final String ARTICLE_TYPE_SLIDESHOW_SEARCH = "slides"; // one extra key because key is different for article in slideshow
    public static final String ARTICLE_TYPE_PROGRAMS = "PROGRAMS";
    public static final String ARTICLE_TYPE_CHALLENGES = "CHALLENGES";
    public static final String ARTICLE_TYPE_TEAMCHALLENGES = "TEAMCHALLENGES";//added on 2017-04-07 team challenge add in discover challange list
    public static final String ARTICLE_TYPE_ARTICLES = "ARTICLES";

    public static final String DISCOVER_FILTER_ALL = "All";
    public static final String DISCOVER_FILTER_GET_FIT = "Get Fit";
    public static final String DISCOVER_FILTER_EAT_RIGHT = "Eat Right";
    public static final String DISCOVER_FILTER_STAY_HAPPY = "Stay Happy";
    public static final String DISCOVER_FILTER_LOOK_BETTER = "Look Better";
    public static final String DISCOVER_FILTER_BE_HEALTHY = "Be Healthy";
    public static final String DISCOVER_FILTER_OTHER = "Others";

    public static final String BUNDLE_KEY_ARTICLE_ID = "ARTICLE_ID";
    public static final String BUNDLE_KEY_SLIDESHOW_ID = "SLIDESHOW_ID";


    public static final String ARTICLE = "ARTICLE";
    public static final String TASK = "TASK";
    public static final String VitalsTracker = "VitalsTracker";
    public static final String CHAT = "Chat";
    public static final String EXERCISE = "Exercise";

    public static final String BUNDLE_KEY_CHALLENGE_ID = "CHALLENGE_ID";
    public static final String BUNDLE_KEY_CHALLENGE_CATEGORY = "CHALLENGE_CATEGORY";
    public static final String BUNDLE_KEY_PROGRAM_ID = "PROGRAM_ID";
    public static final String RATING_TYPE_SLIDESHOW = "Slideshow";
    public static final String RATING_TYPE_ARTICLE = "Article";
    public static final String MY_FAV_TYPE_ARTICLE = "Article";
    public static final String MY_FAV_TYPE_SLIDESHOW = "Slide";

    public static final String BROADCAST_RECEIVER_ONLINE = "broadcast_online";
    public static final String BROADCAST_RECEIVER_LAST_MESSAGE_WITH_EXPERT = "broadcast_last_message_with_expert";
    public static final String BROADCAST_RECEIVER_TYPING = "broadcast_last_typing";
    public static final String BROADCAST_RECEIVER_CHAT = "broadcast_chat";
    public static final String BROADCAST_RECEIVER_MESSAGE_RECEIVE = "broadcast_receive_new_msg";
    public static final String BROADCAST_RECEIVER_FRAGMENT_UNBIND = "broadcast_receive_fragment_unbind";
    public static final String BROADCAST_RECEIVER_UNBIND = "broadcast_receive_unbind_connection";
    public static final String BROADCAST_RECEIVER_BIND = "broadcast_receive_bind_success";
    public static final String BROADCAST_RECEIVER_EXPERT_CONNECT_DISCONNECT = "broadcast_receive_expert_status";
    public static final String BROADCAST_RECEIVER_EXPERT_CLOSE_CHAT = "broadcast_receive_expert_close_chat";
    public static final String BROADCAST_RECEIVER_COMMUNITY_FEEDS = "broadcast_community_feeds";
    public static final String BROADCAST_RECEIVER_COMMUNITY_SAVED_FEEDS = "broadcast_community_saved_feeds";
    public static final String BROADCAST_RECEIVER_COMMUNITY_RECENT_QUESTION = "broadcast_community_recent_question";
    public static final String BROADCAST_RECEIVER_AUTHORIZATION_FAILURE = "broadcast_authorization_failure";
    //public static final String BROADCAST_RECEIVER_SOCIAL_FEEDS = "broadcast_social_feeds";
    public static final String BROADCAST_OTP_REGISTRATION = "broadcast_otp_registration";

    //Added by Pankaj sharma for handle Social Pending friend request
    public static final String BROADCAST_RECEIVER_SOCIAL_FIND_FRIEND = "broadcast_social_find_friend";

    //Added by palak Chawla for handle Team Create Detail
    public static final String BROADCAST_RECEIVER_TEAM_MEMBER_DETAIL = "broadcast_team_member_detail";
    public static final String BROADCAST_RECEIVER_GYMPIK_FILTER = "broadcast_gympi_fliter";
// gympik
public static final String BROADCAST_RECEIVER_ABOUT_RESPONSE = "broadcast_about_response";
    public static final String BROADCAST_RECEIVER_PASSES_RESPONSE = "broadcast_passes_response";
    public static final String BROADCAST_RECEIVER_GALLERY_RESPONSE = "broadcast_gallery_response";
    public static final String BROADCAST_RECEIVER_REVIEWS_RESPONSE = "broadcast_review_response";

    //Runkeeper
    public static final String BROADCAST_RECEIVER_PRE_START_USER_LOCATION = "broadcast_pre_start_activity";
    public static final String BROADCAST_RECEIVER_SINGLE_USER = "broadcast_single_user";
    public static final String BROADCAST_RECEIVER_USER_INVITATION = "broadcast_user_invitation";
    public static final String BROADCAST_RECEIVER_USER_REQUEST = "broadcast_user_request";
    public static final String BROADCAST_RECEIVER_WAITING_LIST = "broadcast_waiting_list";
    public static final String BROADCAST_RECEIVER_ACTIVITY_STARTED = "broadcast_activity_started";
    public static final String BROADCAST_RECEIVER_UPDATE_USERS = "broadcast_update_users";
    public static final String BROADCAST_RECEIVER_STOP_ACTIVITY = "broadcast_stop_activity";
    public static final String BROADCAST_RECEIVER_COUNT_USERS = "broadcast_count_waiting_users";
    public static final String BROADCAST_RECEIVER_GET_COMPLETE_LIST = "broadcast_get_complete_list";
    public static final String BROADCAST_RECEIVER_GET_CURRENT_MEMBERS_LIST = "broadcast_get_current_list";
    public static final String BROADCAST_RECEIVER_ADMIN_STOP = "broadcast_admin_stop";
    public static final String BROADCAST_RECEIVER_ACTIVITY_STOP_AFTER_RECONNECT = "broadcast_activity_stop_after_reconnect";
    public static final String BROADCAST_RECEIVER_REMOVED_FROM_ACTIVITY = "broadcast_removed_activity";

    public static final String BROADCAST_RECEIVER_REMINDER = "receiver_reminder";
    public static final String BROADCAST_RECEIVER_TWCLITE_STEPS_SYNC = "broadcast_sync_steps";
    public static final String DISMISS_COUPON_PEPS_CONVERT_DIALOG = "couponpeps_convert_dialog";
    public static final String EXPERT_TYPE_COUNSELOR = "Counsellor";
    public static final String EXPERT_TYPE_DIETITIAN = "Dietitian";
    public static final String EXPERT_TYPE_DOCTOR = "Doctor";
    public static final String EXPERT_TYPE_SERVER_DOCTOR = "R";
    public static final String EXPERT_TYPE_SERVER_COUNSELOR = "C";
    public static final String EXPERT_TYPE_SERVER_DIETITIAN = "D";
    public static final String BUNDLE_KEY_EXPERT_STATUS = "dOnlineStatus";
    public static final String BUNDLE_KEY_EXPERT_TYPE = "dType";
    public static final String BUNDLE_KEY_EXPERT_SHORT_NAME = "dShort";
    public static final String INTENT_KEY_PREVIOUS_CHAT_HISTORY_BY_DATE = "previousDateChatHistoryHandler";
    public static final String INTENT_KEY_EXPERT_STATUS = "expert_status";
    public static final String INTENT_KEY_TYPING_STATUS = "typing_status";
    public static final String BROADCAST_RECEIVER_MESSAGE_BY_DATE = "MESSAGE_BY_DATE";
    public static final int API_POST_DELAYED_TIME = 500;
    public static final String SERVER_DATE_FORMAT_WITH_MILLISECONDS = "yyyy-MM-dd'T'HH:mm:ss";
    public static final String BUNDLE_KEY_dateTime = "dateTime";
    public static final String BUNDLE_KEY_appoitmentDate = "appoitmentDate";
    public static final String BUNDLE_KEY_trackerType = "trackerType";
    public static final String BUNDLE_KEY_currentType = "currentType";
    public static final String Lab_Report = "Lab Report";
    public static final String Prescription = "Prescription";
    public static final String Other = "Other";
    public static final String BUNDLE_KEY_DEVICE_NAME = "deviceName";
    public static final String BUNDLE_KEY_DEVICE_TYPE = "deviceType";
    public static final String SAMSUNG_DIGITAL_HEALTH_CUSTOM_DATA_TYPE = "com.samsung.shealth.step_daily_trend";
    public static final String SAMSUNG_DIGITAL_HEALTH_DATE_KEY = "day_time";
    public static final String SAMSUNG_DIGITAL_HEALTH_SOURCE_KEY = "source_type";

    public static final String INTENT_KEY_SHOULD_OPEN_AREA_OF_INTEREST = "SHOULD_OPEN_AREA_OF_INTEREST";
    public static final String BUNDLE_GRADE_HRA = "GRADE";
    public static final String BUNDLE_SCORE_HRA = "SCORE";
    public static final String BUNDLE_KEY_PRESELECTED_ANSWER = "PRE_SELECTED_ANSWER";
    public static final String BUNDLE_KEY_REMINDER_TYPE = "REMINDER_TYPE";
    public static final String BUNDLE_KEY_WORKOUT_PLAN_ID = "WORKOUT_PLAN_ID";
    public static final String WELLNESS_MY_PLANS="PLANS";

    public static final String DATE_FORMAT_EEE = "EEE";
    public static final String DATE_FORMAT_DD = "dd";
    public static final String DATE_FORMAT_MMM = "MMM";
    public static final String DATE_FORMAT_YYYY_MM_DD = "yyyy-MM-dd";
    public static final String DATE_FORMAT_MMMM = "MMMM";
    public static final String DATE_FORMAT_DD_MMM_YYYY = "dd MMM yyyy";
    public static final String DATE_FORMAT_DD_MM = "dd-MM";
    public static final String DATE_FORMAT_DD_MM_FORWARD_SLASH = "dd/MMM";
    public static final String DATE_FORMAT_YYYYMMDD = "yyyyMMdd";
    public static final String DD_MM_YYYY_FORWARD_SLASH = "dd/MM/yyyy";
    public static final String DATE_FORMAT_MMMM_DD_YYYY = "MMMM dd, yyyy";
    public static final String DATE_FORMAT_24_HOUR = "MMMM dd, yyyy hh:mm:ss a";
    public static final String BUNDLE_KEY_EXERCISE_ID = "EXERCISE_ID";
    public static final String BUNDLE_KEY_WEEKLY_WORKOUT_DATA = "WEEKLY_WORKOUT_DATA";
    public static final String BUNDLE_KEY_OPENED_FROM_WEEKDAYS = "OPENED_FROM_WEEKDAYS";
    public static final String BUNDLE_KEY_DAY = "WORKOUT_DAY";
    public static final int REMINDER_TYPE_DRINK_GREEN_TEA = 2;
    public static final int REMINDER_TYPE_WATER = 3;
    public static final int REMINDER_TYPE_EXERCISE = 4;
    public static final int REMINDER_TYPE_CAFFEINE = 5;

    public static int DEFAULT_SIZE_GLASS=8;
    public static int DEFAULT_SIZE_BOTTLE=4;
    public static String GLASS="glass";
    public static String BOTTLE="bottle";


}
