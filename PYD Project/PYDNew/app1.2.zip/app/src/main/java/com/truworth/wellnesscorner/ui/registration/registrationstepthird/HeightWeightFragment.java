package com.truworth.wellnesscorner.ui.registration.registrationstepthird;

import android.app.ProgressDialog;
import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.ViewTreeObserver;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.truworth.wellnesscorner.BR;
import com.truworth.wellnesscorner.R;
import com.truworth.wellnesscorner.base.BaseFragment;
import com.truworth.wellnesscorner.customviews.CustomTextView;
import com.truworth.wellnesscorner.customviews.HeightScrollView;
import com.truworth.wellnesscorner.customviews.WeightHorizontalScrollView;
import com.truworth.wellnesscorner.databinding.FragmentHeightWeightBinding;

import java.text.DecimalFormat;
import java.text.NumberFormat;


public class HeightWeightFragment extends BaseFragment<FragmentHeightWeightBinding, HeightWeightViewModel> {
    public static final String TAG = "HeightWeightFragment";
    HeightWeightViewModel viewModel;
    FragmentHeightWeightBinding binding;
    private View scaleWeightLineWidth, scaleHeightLineWidth;
    private int scaleWeightWidth, scaleHeightWidth = 0;
    private int displayWidth;
    private int selectedWeight = 0;
    private int selectedHeight = 0;
    private int onePartOfDisplayWidthWeight;
    private int scrollToPositionWeight = 0;
    private int onePartOfDisplayWidthHeight;
    private int scrollToPositionHeight = 0;
    private int userHeight, userWeight = 0;
    private int selectedHeightFeet;
    private int selectedHeightInch;
    private int mHeightFt;
    private int mHeightInch;
    private double bmi;
    private String memeberID;
    private ProgressDialog progressDialog;
    private LinearLayout rootLayout;
    private CustomTextView tvWeightValue;
    private WeightHorizontalScrollView hsWeight;
    private LinearLayout llWeight;
    private View divider;
    private CustomTextView tvheading2;
    private CustomTextView tvHeightFtValue;
    private CustomTextView tvHeightInchValue;
    private HeightScrollView svHeight;
    private LinearLayout llHeight;

    public static HeightWeightFragment newInstance() {
        HeightWeightFragment fragment = new HeightWeightFragment();
        return fragment;
    }


    private void createWeightScale() {
        int startWeight = 0;
        int totalWeightCount = 30;

        for (int i = 0; i < totalWeightCount; i++) {
            View view = getActivity().getLayoutInflater().inflate(R.layout.weight_scale_interval, null);
            view.setLayoutParams(new LinearLayout.LayoutParams(displayWidth / 5, LinearLayout.LayoutParams.WRAP_CONTENT));
            TextView txtWeight = view.findViewById(R.id.txtWeight);
            scaleWeightLineWidth = view.findViewById(R.id.scale_line_width);

            txtWeight.setText("" + startWeight);
            view.setTag(startWeight);
            startWeight = startWeight + 10;


            llWeight.addView(view);
        }
    }

    private void createHeightScale() {
        int startHeight = 8;
        int totalHeightCount = 8;

        for (int i = totalHeightCount - 1; i >= 0; i--) {

            View view = getActivity().getLayoutInflater().inflate(R.layout.height_scale_interval, null);
            view.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));
            TextView txtHeight = view.findViewById(R.id.txtHeight);
            scaleHeightLineWidth = view.findViewById(R.id.scale_line_width);
            txtHeight.setText("" + startHeight);
            view.setTag(startHeight - 1);
            startHeight = startHeight - 1;
            llHeight.addView(view);
        }
    }

    private int calculateScrollForHeight(int height) {
        String ft = "" + (height * 0.032808);
        String arrft[] = ft.split("\\.");
        int mHeightFt = Integer.parseInt(arrft[0].toString());
        String inch = "." + arrft[1].toString().substring(0, 2);
        inch = "" + (Double.parseDouble(inch) * 12);
        int mHeightInch = (int) Math.round(Double.parseDouble(inch));


        if(mHeightInch>0){
            mHeightInch=1-mHeightInch;
        }
             int scroll = (onePartOfDisplayWidthHeight * (8 - mHeightFt)) + (mHeightInch * (onePartOfDisplayWidthHeight / 11));


        if (onePartOfDisplayWidthHeight > 420) {
            scroll = scroll - 40;
        } else if (onePartOfDisplayWidthHeight > 350 && onePartOfDisplayWidthHeight < 420) {
            scroll = scroll - 35;
        } else
            scroll = scroll - 28;
        return (scroll);
    }

    /**
     * Override for set binding variable
     *
     * @return variable id
     */
    @Override
    public int getBindingVariable() {
        return BR.viewModel;
    }

    /**
     * @return layout resource id
     */
    @Override
    public int getLayoutId() {
        return R.layout.fragment_height_weight;
    }

    /**
     * Override for set view model
     *
     * @return view model instance
     */
    @Override
    public HeightWeightViewModel getViewModel() {
        viewModel = ViewModelProviders.of(this).get(HeightWeightViewModel.class);
        return viewModel;
    }


    private void setObserverToOpenBmiScreen() {
        viewModel.getOnClickContinue().observe(this, new Observer<Void>() {
            @Override
            public void onChanged(@Nullable Void aVoid) {
                openBMIAndIBWFragment();
            }
        });
    }


    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getActivity().getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING | WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        hideKeyboard();
        userWeight = 50;
        userHeight = 153;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        scaleWeightWidth = 0;
        scaleHeightWidth = 0;
        displayWidth = 0;
        selectedWeight = 0;
        selectedHeight = 0;
        onePartOfDisplayWidthWeight = 0;
        scrollToPositionWeight = 0;
        onePartOfDisplayWidthHeight = 0;
        scrollToPositionHeight = 0;

        selectedHeightFeet = 0;
        selectedHeightInch = 0;
        llHeight = null;
        svHeight = null;

        initView(view);
        onFragmentReady();
        setObserverToOpenBmiScreen();
    }


    public void onFragmentReady() {

        DisplayMetrics displaymetrics = new DisplayMetrics();
        getActivity().getWindowManager().getDefaultDisplay().getMetrics(displaymetrics);

        displayWidth = displaymetrics.widthPixels;
        onePartOfDisplayWidthWeight = displayWidth / 5;


        if (userWeight > 0) {
            int diffWeight = userWeight / 10;
            scrollToPositionWeight = onePartOfDisplayWidthWeight * diffWeight + (userWeight % 10) * (onePartOfDisplayWidthWeight / 10);
        }

        if (userHeight > 0) {
            LinearLayout heightView = (LinearLayout) getActivity().getLayoutInflater().inflate(R.layout.height_scale_interval, null);
            if (heightView != null && heightView.getChildCount() > 0) {
                onePartOfDisplayWidthHeight = heightView.getChildAt(1).getLayoutParams().height;
                scrollToPositionHeight = calculateScrollForHeight(userHeight);
            }
        }
        svHeight.setFadingEdgeLength(300);
        svHeight.getViewTreeObserver().addOnPreDrawListener(new ViewTreeObserver.OnPreDrawListener() {

            @Override
            public boolean onPreDraw() {
                svHeight.getViewTreeObserver().removeOnPreDrawListener(this);
                LinearLayout child = (LinearLayout) svHeight.getChildAt(0);
                LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(displayWidth / 2, svHeight.getHeight() / 2);

                View leftSpacer = new View(getActivity());
                leftSpacer.setLayoutParams(p);
                child.addView(leftSpacer, 0);

                View rightSpacer = new View(getActivity());
                rightSpacer.setLayoutParams(p);
                child.addView(rightSpacer);

                return false;
            }
        });

        svHeight.setOnScrollViewListener(new HeightScrollView.OnScrollViewListener() {
            @Override
            public void onScrollChanged(HeightScrollView v, int l, int t, int oldl, int oldt) {
                int scrollWidthX = t;
                scrollWidthX = scrollWidthX + llHeight.getChildAt(0).getHeight() + scaleHeightWidth / 2;

                for (int i = 0; i < llHeight.getChildCount(); i++) {
                    float child_pos = llHeight.getChildAt(i).getY();
                    int childpos = Math.round(child_pos);
                    int width1 = llHeight.getChildAt(i).getHeight();

                    if (scrollWidthX > childpos && scrollWidthX < childpos + width1) {
                        if (llHeight.getChildAt(i).getTag() != null) {
                            String i1 = llHeight.getChildAt(i).getTag().toString();
                            LinearLayout linear_children1 = (LinearLayout) llHeight.getChildAt(i);
                            LinearLayout linear_children2 = (LinearLayout) linear_children1.getChildAt(1);

                            int linear2Count = linear_children2.getChildCount();
                            abc:
                            for (int j = 0; j < linear2Count; j++) {
                                View view_children3 = linear_children2.getChildAt(j);
                                if (view_children3.getTag() != null && !view_children3.getTag().toString().equalsIgnoreCase("-1")) {
                                    int width2 = linear_children2.getChildAt(j).getHeight();

                                    float view3_child_X_pos = linear_children2.getChildAt(j).getY();
                                    int view3_child_X = Math.round(view3_child_X_pos);

                                    view3_child_X = childpos + view3_child_X;


                                    if (view3_child_X + scaleHeightWidth / 4 < scrollWidthX &&
                                            view3_child_X + width2 + scaleHeightWidth / 4 > scrollWidthX) {
                                        String i2 = Integer.parseInt(i1) + Integer.parseInt(view_children3.getTag().toString()) + "";

                                        selectedHeightFeet = Integer.parseInt(i1);
                                        selectedHeightInch = Integer.parseInt(view_children3.getTag().toString());
                                        selectedHeight = Integer.parseInt(i2);
                                        userHeight = getHeightIntoCentimeter(selectedHeightFeet, selectedHeightInch);
                                        viewModel.getHeight().set(getHeightIntoCentimeter(selectedHeightFeet, selectedHeightInch));
                                        //scrollToPositionKM = l;
                                        tvHeightFtValue.setText(String.valueOf(selectedHeightFeet));
                                        tvHeightInchValue.setText(String.valueOf(selectedHeightInch));

                                        break abc;
                                    }
                                }
                            }
                        }
                    } else {

                        if (t == 0) {
                            selectedHeightFeet = 7;
                            selectedHeightInch = 11;
                            selectedHeight = 7;
                            viewModel.getHeight().set(getHeightIntoCentimeter(selectedHeightFeet, selectedHeightInch));
                            tvHeightFtValue.setText(selectedHeight + "");
                            tvHeightInchValue.setText(selectedHeightInch + "");
                        } else if ((llHeight.getHeight() - svHeight.getHeight()) == t) {
                            selectedHeightFeet = 0;
                            selectedHeightInch = 0;
                            selectedHeight = 0;
                            viewModel.getHeight().set(getHeightIntoCentimeter(selectedHeightFeet, selectedHeightInch));
                            tvHeightFtValue.setText(selectedHeight + "");
                            tvHeightInchValue.setText(selectedHeightInch + "");
                        }
                    }
                }
            }
        });


        llHeight.removeAllViews();
        createHeightScale();

        hsWeight.getViewTreeObserver().addOnPreDrawListener(new ViewTreeObserver.OnPreDrawListener() {

            @Override
            public boolean onPreDraw() {

                hsWeight.getViewTreeObserver().removeOnPreDrawListener(this);
                LinearLayout child = (LinearLayout) hsWeight.getChildAt(0);
                LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(displayWidth / 2, 300);

                View leftSpacer = new View(getActivity());
                leftSpacer.setLayoutParams(p);
                child.addView(leftSpacer, 0);

                View rightSpacer = new View(getActivity());
                rightSpacer.setLayoutParams(p);
                child.addView(rightSpacer);

                return false;
            }
        });

        hsWeight.setOnScrollViewListener(new WeightHorizontalScrollView.OnScrollViewListener() {

            @Override
            public void onScrollChanged(WeightHorizontalScrollView v, int l, int t, int oldl, int oldt) {

                // TODO Code here to calculate value of weight
                int scrollwidthX = l;
                scrollwidthX = scrollwidthX + displayWidth / 2;
                pqr:
                for (int i = 0; i < llWeight.getChildCount(); i++) {
                    float child_pos = llWeight.getChildAt(i).getX();
                    int childpos = Math.round(child_pos);
                    int width1 = llWeight.getChildAt(i).getWidth();

                    if (scrollwidthX > childpos && scrollwidthX < childpos + width1) {
                        if (llWeight.getChildAt(i).getTag() != null) {
                            String i1 = llWeight.getChildAt(i).getTag().toString();
                            LinearLayout linear_children1 = (LinearLayout) llWeight.getChildAt(i);
                            LinearLayout linear_children2 = (LinearLayout) linear_children1.getChildAt(0);

                            int linear2Count = linear_children2.getChildCount();
                            abc:
                            for (int j = 0; j < linear2Count; j++) {
                                View view_children3 = linear_children2.getChildAt(j);
                                if (view_children3.getTag() != null && !view_children3.getTag().toString().equalsIgnoreCase("-1")) {
                                    int width2 = linear_children2.getChildAt(j).getWidth();
                                    float view3_child_X_pos = linear_children2.getChildAt(j).getX();
                                    int view3_child_X = Math.round(view3_child_X_pos);
                                    view3_child_X = childpos + view3_child_X;
                                    if (view3_child_X + scaleWeightWidth / 2 < scrollwidthX &&
                                            view3_child_X + width2 + scaleWeightWidth / 2 > scrollwidthX) {
                                        String i2 = Integer.parseInt(i1) + Integer.parseInt(view_children3.getTag().toString()) + "";

                                        selectedWeight = Integer.parseInt(i2);
                                        userWeight = selectedWeight;
                                        viewModel.getWeight().set(selectedWeight);
                                        //scrollToPositionKM = l;
                                        tvWeightValue.setText(i2 + "");
                                        break abc;
                                    }
                                }
                            }
                        }
                    } else {
                        if (l == 0) {
                            selectedWeight = 0;
                            viewModel.getWeight().set(selectedWeight);
                            tvWeightValue.setText(selectedWeight + "");
                        } else if (llWeight.getWidth() - displayWidth / 2 * 2 == l) {
                            selectedWeight = 300;
                            viewModel.getWeight().set(selectedWeight);
                            tvWeightValue.setText(selectedWeight + "");
                        }
                    }
                }
            }
        });
        llWeight.removeAllViews();
        createWeightScale();


        rootLayout.postDelayed(new Runnable() {
            @Override
            public void run() {
                scaleWeightWidth = scaleWeightLineWidth.getWidth();
                hsWeight.smoothScrollTo(scrollToPositionWeight, 0);
                scaleHeightWidth = scaleHeightLineWidth.getHeight();
                svHeight.smoothScrollTo(0, scrollToPositionHeight);
                // svHeight.fullScroll(View.FOCUS_DOWN);
            }
        }, 400);

    }

    private String BmiCalculate() {

        int mHeight = (int) ((selectedHeightFeet / 3.2808) * 100 + (selectedHeightInch * 2.54));
        int mWeight = selectedWeight;
        if (mHeight == 0 || mWeight == 0) {
            //   DialogFactory.getInstance().showAlertDialog(getActivity(), null, 0, getString(R.string.msg_height_not_zero), getString(R.string.str_ok), false);
            return null;
        } else {
            int mHeightFt = selectedHeightFeet;
            int mHeightInch = selectedHeightInch;

            double heightMeter = (((mHeightFt * 12) + mHeightInch) * 0.0254);
            bmi = (mWeight / (heightMeter * heightMeter));
            NumberFormat formatter = new DecimalFormat("#0.00");
            return formatter.format(bmi);
        }

        //createPostRequest();
    }

    private int getHeightIntoCentimeter(int selectedHeightFeet1, int selectedHeightInch2) {
        return (int) ((selectedHeightFeet1 / 3.2808) * 100 + (selectedHeightInch2 * 2.54));
    }

    private void initView(View view) {
        rootLayout = view.findViewById(R.id.rootLayout);
        tvWeightValue = view.findViewById(R.id.tvWeightValue);
        hsWeight = view.findViewById(R.id.hsWeight);
        llWeight = view.findViewById(R.id.llWeight);
        divider = view.findViewById(R.id.divider);
        tvheading2 = view.findViewById(R.id.tvheading2);
        tvHeightFtValue = view.findViewById(R.id.tvHeightFtValue);
        tvHeightInchValue = view.findViewById(R.id.tvHeightInchValue);
        svHeight = view.findViewById(R.id.svHeight);
        llHeight = view.findViewById(R.id.llHeight);
    }

    private void openBMIAndIBWFragment() {
            getActivity().getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.registerContainer, BMICalculatingFragment.newInstance(viewModel.height.get(), viewModel.getWeight().get()), BMICalculatingFragment.TAG).addToBackStack(BMIFragment.TAG)
                    .commit();
    }

    @Override
    public void onDetach() {
        getActivity().getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE | WindowManager.LayoutParams.SOFT_INPUT_STATE_UNSPECIFIED);

        super.onDetach();
    }
}
