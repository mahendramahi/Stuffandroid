package com.truworth.wellnesscorner.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.truworth.wellnesscorner.ui.mainapp.post.IPostListItem;
import com.truworth.wellnesscorner.ui.mainapp.post.PostConstants;

import java.util.ArrayList;
import java.util.List;

public class Post implements IPostListItem  {

    public List<PostMediaData> imageMediaData = new ArrayList<>();
    public List<PostMediaData> urlMediaData = new ArrayList<>();
    public List<PostMediaData> videoMediaData = new ArrayList<>();

    @SerializedName("postIdentity")
    @Expose
    private String postIdentity;
    @SerializedName("postMapIdentity")
    @Expose
    private String postMapIdentity;
    @SerializedName("postContentIdentity")
    @Expose
    private String postContentIdentity;
    @SerializedName("postCreatedByIdentity")
    @Expose
    private String postCreatedByIdentity;
    @SerializedName("postMapName")
    @Expose
    private String postMapName;
    @SerializedName("postText")
    @Expose
    private String postText;
    @SerializedName("postCreatedByName")
    @Expose
    private String postCreatedByName;
    @SerializedName("postCreatedByImage")
    @Expose
    private String postCreatedByImage;
    @SerializedName("postContentTypeId")
    @Expose
    private int postContentTypeId;

    private Object contentData;
    @SerializedName("postIsHasMedia")
    @Expose
    private boolean postIsHasMedia;
    @SerializedName("postMediaList")
    @Expose
    private List<PostMediaList> postMediaList = null;
    @SerializedName("postIsHasTags")
    @Expose
    private boolean postIsHasTags;
    @SerializedName("postTagList")
    @Expose
    private List<PostTag> postTagList = null;
    @SerializedName("postTotalHiFives")
    @Expose
    private int postTotalHiFives;
    @SerializedName("postTotalComments")
    @Expose
    private int postTotalComments;
    @SerializedName("postCreatedOn")
    @Expose
    private String postCreatedOn;
    @SerializedName("postMemberIsHi5")
    @Expose
    private boolean postMemberIsHi5;
    @SerializedName("postIsCoach")
    @Expose
    private boolean postIsCoach;

    public String getPostIdentity() {
        return postIdentity;
    }

    public void setPostIdentity(String postIdentity) {
        this.postIdentity = postIdentity;
    }

    public String getPostMapIdentity() {
        return postMapIdentity;
    }

    public void setPostMapIdentity(String postMapIdentity) {
        this.postMapIdentity = postMapIdentity;
    }

    public String getPostContentIdentity() {
        return postContentIdentity;
    }

    public void setPostContentIdentity(String postContentIdentity) {
        this.postContentIdentity = postContentIdentity;
    }

    public String getPostCreatedByIdentity() {
        return postCreatedByIdentity;
    }

    public void setPostCreatedByIdentity(String postCreatedByIdentity) {
        this.postCreatedByIdentity = postCreatedByIdentity;
    }

    public String getPostMapName() {
        return postMapName;
    }

    public void setPostMapName(String postMapName) {
        this.postMapName = postMapName;
    }

    public String getPostText() {
        return postText;
    }

    public void setPostText(String postText) {
        this.postText = postText;
    }

    public String getPostCreatedByName() {
        return postCreatedByName;
    }

    public void setPostCreatedByName(String postCreatedByName) {
        this.postCreatedByName = postCreatedByName;
    }

    public String getPostCreatedByImage() {
        return postCreatedByImage;
    }

    public void setPostCreatedByImage(String postCreatedByImage) {
        this.postCreatedByImage = postCreatedByImage;
    }

    public int getPostContentTypeId() {
        return postContentTypeId;
    }

    public void setPostContentTypeId(int postContentTypeId) {
        this.postContentTypeId = postContentTypeId;
    }

    public Object getContentData() {
        return contentData;
    }

    public void setContentData(Object contentData) {
        this.contentData = contentData;
    }

    public boolean getPostIsHasMedia() {
        return postIsHasMedia;
    }

    public void setPostIsHasMedia(boolean postIsHasMedia) {
        this.postIsHasMedia = postIsHasMedia;
    }

    public List<PostMediaList> getPostMediaList() {
        return postMediaList;
    }

    public void setPostMediaList(List<PostMediaList> postMediaList) {
        this.postMediaList = postMediaList;
    }

    public boolean getPostIsHasTags() {
        return postIsHasTags;
    }

    public void setPostIsHasTags(boolean postIsHasTags) {
        this.postIsHasTags = postIsHasTags;
    }

    public List<PostTag> getPostTagList() {
        return postTagList;
    }

    public void setPostTagList(List<PostTag> postTagList) {
        this.postTagList = postTagList;
    }

    public int getPostTotalHiFives() {
        return postTotalHiFives;
    }

    public void setPostTotalHiFives(int postTotalHiFives) {
        this.postTotalHiFives = postTotalHiFives;
    }

    public int getPostTotalComments() {
        return postTotalComments;
    }

    public void setPostTotalComments(int postTotalComments) {
        this.postTotalComments = postTotalComments;
    }

    public String getPostCreatedOn() {
        return postCreatedOn;
    }

    public void setPostCreatedOn(String postCreatedOn) {
        this.postCreatedOn = postCreatedOn;
    }

    public boolean getPostMemberIsHi5() {
        return postMemberIsHi5;
    }

    public void setPostMemberIsHi5(boolean postMemberIsHi5) {
        this.postMemberIsHi5 = postMemberIsHi5;
    }

    public boolean getPostIsCoach() {
        return postIsCoach;
    }

    public void setPostIsCoach(boolean postIsCoach) {
        this.postIsCoach = postIsCoach;
    }

    @Override
    public int getPostListItemType() {
        return IPostListItem.TYPE_POST;
    }

    public  void extractMediaData() {

        for (int i = 0; i < getPostMediaList().size(); i++) {
            PostMediaList mediaList = getPostMediaList().get(i);
            if (mediaList.getPostMediaType() == PostConstants.MEDIA_TYPE_IMAGE) {
                imageMediaData.add(mediaList.getPostMediaData().get(0));
            } else if (mediaList.getPostMediaType() == PostConstants.MEDIA_TYPE_URL) {
                urlMediaData.add(mediaList.getPostMediaData().get(0));
            } else if (mediaList.getPostMediaType() == PostConstants.MEDIA_TYPE_VIDEO) {
                videoMediaData.add(mediaList.getPostMediaData().get(0));
            }
        }
    }
}


