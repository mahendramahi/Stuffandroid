package com.truworth.wellnesscorner.repo.model.request;

/**
 * Created by rajeshs on 4/2/2018.
 */

public class OTPRequest {
    String Email;
    String Phone;

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }

    public String getPhone() {
        return Phone;
    }

    public void setPhone(String phone) {
        Phone = phone;
    }
}
