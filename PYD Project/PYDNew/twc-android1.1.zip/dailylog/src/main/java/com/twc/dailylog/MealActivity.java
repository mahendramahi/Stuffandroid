package com.twc.dailylog;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.TextView;

import com.twc.dailylog.fragments.AddWeightFragment;
import com.twc.dailylog.fragments.TrackExerciseFragment;
import com.twc.dailylog.fragments.TrackMealFragment;
import com.twc.dailylog.fragments.WeightTrackerFragment;
import com.twc.dailylog.interfaces.OnTrackerReadingSave;
import com.twc.dailylog.utils.DailyLogConfig;
import com.twc.dailylog.utils.Utils;


public class MealActivity extends AppCompatActivity {

    public Toolbar mToolbar;
    public String mealType = "";
    private TextView tvToolbarTitle;
    private double currentWeight;
    private double firstWeight;
    private double targetWeight;
    private OnTrackerReadingSave onTrackerReadingSave;

    public MealActivity(OnTrackerReadingSave onTrackerReadingSave) {
        this.onTrackerReadingSave = onTrackerReadingSave;
    }

    public MealActivity() {
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_meal);
        setupToolbar();
        Intent intent = getIntent();
        if (null != intent) { //Null Checking
            currentWeight = intent.getDoubleExtra("CURRENT_WEIGHT", 0);
            firstWeight = intent.getDoubleExtra("FIRST_WEIGHT", 0);
            targetWeight = intent.getDoubleExtra("TARGET_WEIGHT", 0);
        }

        if (DailyLogConfig.dailyLogUser.getType().equals("Exercise")) {

            Utils.replaceFragment(getFragmentManager(), TrackExerciseFragment.newInstance(null), TrackExerciseFragment.class.getSimpleName(), true, R.id.fragmentContainerMeal);

        } else if (DailyLogConfig.dailyLogUser.getType().equals("Weight")) {

            Utils.replaceFragment(getFragmentManager(), WeightTrackerFragment.newInstance(currentWeight, firstWeight, targetWeight), WeightTrackerFragment.class.getSimpleName(), true, R.id.fragmentContainerMeal);
        } else if (DailyLogConfig.dailyLogUser.getType().equals("Meal")) {
            Bundle bundle = new Bundle();
            bundle.putString("trackMealType", getString(R.string.breakfast));
            if (DailyLogConfig.dailyLogUser.getMealType() != null && DailyLogConfig.dailyLogUser.getMealType().length() > 0) {
                bundle.putString("trackMealType", DailyLogConfig.dailyLogUser.getMealType());
            }
            Utils.replaceFragment(getFragmentManager(), TrackMealFragment.newInstance(bundle), TrackMealFragment.class.getSimpleName(), true, R.id.fragmentContainerMeal);
        } else if (DailyLogConfig.dailyLogUser.getType().equals("TaskExercise")) {
            Intent exerciseIntent = getIntent();
            Bundle bundle = exerciseIntent.getExtras();
            TrackExerciseFragment trackExerciseFragment = TrackExerciseFragment.newInstance(bundle);
            trackExerciseFragment.setTrackerReadingCallback(onTrackerReadingSave);
            Utils.replaceFragment(getFragmentManager(), trackExerciseFragment, TrackExerciseFragment.class.getSimpleName(), true, R.id.fragmentContainerMeal);

        }else if (DailyLogConfig.dailyLogUser.getType().equals("TaskWeight")) {
            Intent exerciseIntent = getIntent();
            Bundle bundle = exerciseIntent.getExtras();
            AddWeightFragment addWeightFragment = AddWeightFragment.newInstance(bundle);
            addWeightFragment.setTrackerReadingCallback(onTrackerReadingSave);
            Utils.replaceFragment(getFragmentManager(), addWeightFragment, AddWeightFragment.class.getSimpleName(), true, R.id.fragmentContainerMeal);

        }
    }

    @Override
    public void onBackPressed() {
        Utils.hideSoftKeyboard(this);
        int count = getFragmentManager().getBackStackEntryCount();
        if (count == 1) {
            setResult(Activity.RESULT_OK);
            finish();
        } else {
            super.onBackPressed();
        }
    }

    private void setupToolbar() {
        mToolbar = findViewById(R.id.toolbar);
        tvToolbarTitle = findViewById(R.id.tbTitle);
        setSupportActionBar(mToolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        mToolbar.setNavigationIcon(R.drawable.ic_arrow_left_white_24dp);
    }

    public void setToolBarTitle(String toolBarTitle) {
        tvToolbarTitle.setText(toolBarTitle);
        assert getSupportActionBar() != null;
        getSupportActionBar().show();
    }

    public void showHomeAsUpEnableToolbar() {
        mToolbar.setNavigationIcon(R.drawable.ic_arrow_left_white_24dp);
        mToolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }
    }

    public String getMealType() {
        return mealType;
    }

    public void setMealType(String mealType) {
        this.mealType = mealType;
    }

}
