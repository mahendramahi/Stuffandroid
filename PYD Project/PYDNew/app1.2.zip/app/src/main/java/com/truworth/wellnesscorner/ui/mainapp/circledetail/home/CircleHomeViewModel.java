package com.truworth.wellnesscorner.ui.mainapp.circledetail.home;

import android.databinding.ObservableBoolean;

import com.truworth.wellnesscorner.TheWellnessCornerApp;
import com.truworth.wellnesscorner.base.BaseViewModel;
import com.truworth.wellnesscorner.model.Post;
import com.truworth.wellnesscorner.repo.DashboardRepository;
import com.truworth.wellnesscorner.repo.model.request.CirclePostsRequest;
import com.truworth.wellnesscorner.repo.model.response.PostResponse;
import com.truworth.wellnesscorner.utils.SingleLiveEvent;

import java.util.List;

import javax.inject.Inject;

import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;

public class CircleHomeViewModel extends BaseViewModel {
    public SingleLiveEvent<List<Post>> postsList = new SingleLiveEvent<>();
    public boolean isLastResult = false;
    public boolean loading;
    //    public void setPostList(CircleResponse circleResponse) {
//        postsList.setValue(circleResponse.getData().getSocialPost());
//    }
    public SingleLiveEvent<Void> removeLoading = new SingleLiveEvent<>();
    @Inject
    DashboardRepository dashboardRepository;
    String circleIdentity;
    SingleLiveEvent<Void> upArrow = new SingleLiveEvent<>();

    public CircleHomeViewModel() {
        TheWellnessCornerApp.getApp().component().inject(this);
    }

    public SingleLiveEvent<List<Post>> getPostsList() {
        return postsList;
    }

    public SingleLiveEvent<Void> getUpArrow() {
        return upArrow;
    }

    public SingleLiveEvent<Void> getRemoveLoading() {
        return removeLoading;
    }
    public ObservableBoolean isSwipeRefresh =new ObservableBoolean();


    public void setCircleIdentity(String circleIdentity) {
        this.circleIdentity = circleIdentity;
    }

    public void upArrowClick() {

        upArrow.call();
    }

    public void getCirclePosts(int page) {

        CirclePostsRequest circlePostsRequest = new CirclePostsRequest();
        circlePostsRequest.setId(circleIdentity);
        circlePostsRequest.setPageIndex(page);
        circlePostsRequest.setPageSize(10);
        dashboardRepository.getCirclePosts(circlePostsRequest).subscribe(new Observer<PostResponse>() {
            @Override
            public void onSubscribe(Disposable d) {

            }

            @Override
            public void onNext(PostResponse postResponse) {
                removeLoading.call();
                loading = false;

                if (!postResponse.isHasError()) {
                    if (postResponse.getData() != null && postResponse.getData().size() > 0) {
                        postsList.setValue(postResponse.getData());
                    }
                    else {
                        isLastResult = true;
                        removeLoading.call();
                    }
                }else {
                    removeLoading.call();
                    isLastResult = true;
                }
            }

            @Override
            public void onError(Throwable e) {
                isSwipeRefresh.set(false);
                removeLoading.call();
            }

            @Override
            public void onComplete() {
                isSwipeRefresh.set(false);
            }
        });
    }

}
