package com.truworth.wellnesscorner.di;

import android.app.Application;
import android.content.Context;
import android.content.SharedPreferences;

import com.truworth.wellnesscorner.TheWellnessCornerApp;
import com.truworth.wellnesscorner.network.InternetConnectionListener;
import com.truworth.wellnesscorner.network.NetworkModule;

import javax.inject.Singleton;

import dagger.Module;
import dagger.Provides;
import io.reactivex.annotations.Nullable;


@Singleton
@Module(includes = {NetworkModule.class})
//, PersistenceModule.class, UtilModule.class
public class AppModule {
    private static final String PREF_NAME = "thewellnesscorner";
    private Application app;

    public AppModule(Application app) {
        this.app = app;
    }

    @Provides
    @Singleton
    Application providesApplication() {
        return app;
    }

    @Provides
    @Singleton
    @AppContext
    Context providesContext() {
        return app;
    }

    @Provides
    SharedPreferences provideSharedPreferences() {
        return app.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
    }

    @Nullable
    @Provides
    InternetConnectionListener provideInternetConnectionListener() {
        return ((TheWellnessCornerApp) app).getInternetConnectionListener();
    }

}
