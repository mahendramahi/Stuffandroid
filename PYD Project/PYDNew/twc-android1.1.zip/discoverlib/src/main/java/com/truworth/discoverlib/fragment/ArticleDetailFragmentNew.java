package com.truworth.discoverlib.fragment;


import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnKeyListener;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.Toast;

import com.facebook.CallbackManager;
import com.truworth.discoverlib.ArticleDetailActivity;
import com.truworth.discoverlib.DiscoverActivity;
import com.truworth.discoverlib.R;
import com.truworth.discoverlib.R2;
import com.truworth.discoverlib.interfaces.OnFacebookShare;
import com.truworth.discoverlib.model.AddToFavoriteBody;
import com.truworth.discoverlib.model.AddToFavouritResponse;
import com.truworth.discoverlib.model.RateDiscoverBody;
import com.truworth.discoverlib.model.RateDiscoverResponse;
import com.truworth.discoverlib.model.RemoveFromFavoriteBody;
import com.truworth.discoverlib.model.RemoveFromFavouriteResponse;
import com.truworth.discoverlib.model.SharedConfirmationBody;
import com.truworth.discoverlib.model.SharedConfirmationResponse;
import com.truworth.discoverlib.rest.RestClient;
import com.truworth.discoverlib.utils.Constant;
import com.truworth.discoverlib.utils.CustomProgressDialog;
import com.truworth.discoverlib.utils.DialogFactory;
import com.truworth.discoverlib.utils.DiscoverConfig;
import com.truworth.discoverlib.utils.FacebookShareUtil;
import com.truworth.discoverlib.utils.NetworkFactory;
import com.truworth.discoverlib.utils.Utils;

import java.util.HashMap;
import java.util.Map;

import butterknife.BindView;
import butterknife.OnClick;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * If this code works it was written by Somesh Kumar on 09 August, 2016. If not, I don't know who wrote it.
 */
public class ArticleDetailFragmentNew extends BaseFragment implements OnFacebookShare, RatingBar.OnRatingBarChangeListener {

    @BindView(R2.id.rootLayout)
    LinearLayout rootLayout;

    @BindView(R2.id.llBottomSheet)
    LinearLayout llBottomSheet;

    @BindView(R2.id.wvArticle)
    WebView wvArticle;

    @BindView(R2.id.ivFavorite)
    ImageView ivFavorite;

    @BindView(R2.id.rbUserRating)
    RatingBar rbUserRating;

    private ProgressDialog progressDialog;
    private CustomProgressDialog customProgressDialog;
    private Map<String, String> extraHeaders = new HashMap<>();
    private String articleUrl = "";
    private int favorite;
    private int articleId = -1;
    private float x, y;

    private CallbackManager shareDialogCallbackManager;

    @SuppressLint("HandlerLeak")
    private Handler handler = new Handler() {
        @Override
        public void handleMessage(Message message) {
            switch (message.what) {
                case 1: {
                    webViewGoBack();
                }
                break;
            }
        }
    };

    public static ArticleDetailFragmentNew newInstance(Bundle bundle) {
        ArticleDetailFragmentNew articleDetailFragment = new ArticleDetailFragmentNew();
        articleDetailFragment.setArguments(bundle);
        return articleDetailFragment;
    }

    @Override
    public int getFragmentLayout() {
        return R.layout.fragment_article_detail_new;
    }

    @SuppressLint({"SetJavaScriptEnabled", "ClickableViewAccessibility"})
    @Override
    public void onFragmentReady() {

        rbUserRating.setOnRatingBarChangeListener(this);

        //  wvArticle.getSettings().setDomStorageEnabled(true);
        wvArticle.getSettings().setJavaScriptEnabled(true);
        wvArticle.setWebViewClient(getWebViewClient());
        wvArticle.addJavascriptInterface(new MyJavaScriptInterface(getActivity()), "Android");
        wvArticle.loadUrl(articleUrl, extraHeaders);
        wvArticle.setVisibility(View.INVISIBLE);

        wvArticle.setOnKeyListener(new OnKeyListener() {

            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (keyCode == KeyEvent.KEYCODE_BACK
                        && event.getAction() == MotionEvent.ACTION_UP
                        && wvArticle.canGoBack()) {
                    handler.sendEmptyMessage(1);
                    return true;
                }

                return false;
            }

        });

        wvArticle.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                //In response to the picture on the web click event by wenview touch
                float density = getResources().getDisplayMetrics().density; //Screen density
                float touchX = motionEvent.getX() / density;  //Must be divided by the density of the screen
                float touchY = motionEvent.getY() / density;
                if (motionEvent.getAction() == MotionEvent.ACTION_DOWN) {
                    x = touchX;
                    y = touchY;
                }

                if (motionEvent.getAction() == MotionEvent.ACTION_UP) {
                    float dx = Math.abs(touchX - x);
                    float dy = Math.abs(touchY - y);
                    if (dx < 10.0 / density && dy < 10.0 / density) {
                        clickImage(touchX, touchY);
                    }
                }
                return false;
            }
        });


    }

    private void clickImage(float touchX, float touchY) {
        //Through the touch position to get a picture of URL


        wvArticle.evaluateJavascript(
                "(function() { var  obj=document.elementFromPoint(" + touchX + "," + touchY + ");" +
                        "if(obj.alt=='false'){return false;}else{if(obj.src!=null){ Android.zoomImage(obj.src);}}" +
                        "})();",
                null);

    }

    private void webViewGoBack() {
        wvArticle.goBack();
    }

    private WebViewClient getWebViewClient() {
        return new WebViewClient() {

            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
                if (isAdded() && getActivity() != null) {
                    articleUrl = url;
                    favorite = 0;
                    ivFavorite.setImageResource(R.drawable.ic_article_fav_empty);
                    rbUserRating.setRating(0);

                    customProgressDialog = new CustomProgressDialog(getActivity(), R.style.custom_progress_style, true);
                    customProgressDialog.show();
                }
            }

            @Override
            public void onPageFinished(WebView view, String url) {

                wvArticle.evaluateJavascript(
                        "hidecontent();",
                        null);

                wvArticle.evaluateJavascript(
                        "(function() { return (document.getElementById('hdnArticleId').value); })();",
                        new ValueCallback<String>() {
                            @Override
                            public void onReceiveValue(String html) {
                                try {

                                    String article = html.replace("\"", "");
                                    if (article != null && !article.contains("null")) {
                                        articleId = Integer.parseInt(article);
                                    }
                                } catch (NumberFormatException e) {
                                    e.printStackTrace();
                                }
                            }
                        });

                wvArticle.evaluateJavascript(
                        "(function() { return (document.getElementById('hdnArticleRating').value); })();",
                        new ValueCallback<String>() {
                            @Override
                            public void onReceiveValue(String html) {
                                try {

                                    String article = html.replace("\"", "");
                                } catch (NumberFormatException e) {
                                    e.printStackTrace();
                                }
                            }
                        });

                wvArticle.evaluateJavascript(
                        "(function() { return (document.getElementById('hdnArticleUserRating').value); })();",
                        new ValueCallback<String>() {
                            @Override
                            public void onReceiveValue(String html) {
                                int value = 0;
                                try {

                                    String articleRatingValue = html.replace("\"", "");
                                    if (articleRatingValue != null && !articleRatingValue.contains("null") && !articleRatingValue.equals("")) {
                                        value = Integer.parseInt(articleRatingValue);
                                    }
                                } catch (NumberFormatException e) {
                                    e.printStackTrace();
                                    value = 0;
                                }
                                if (isAdded() && getActivity() != null) {
                                    rbUserRating.setRating(value);
                                }
                            }
                        });

                wvArticle.evaluateJavascript(
                        "(function() { return (document.getElementById('hdnIsUsersFav').value); })();",
                        new ValueCallback<String>() {
                            @Override
                            public void onReceiveValue(String html) {
                                try {

                                    String articleFavValue = html.replace("\"", "");
                                    if (isAdded() && getActivity() != null) {
                                        if (articleFavValue != null || !articleFavValue.contains("null")) {
                                            if (articleFavValue.equalsIgnoreCase("true")) {
                                                ivFavorite.setImageResource(R.drawable.ic_article_fav_fill);
                                                favorite = 0;
                                            } else {
                                                ivFavorite.setImageResource(R.drawable.ic_article_fav_empty);
                                                favorite = 1;
                                            }
                                        } else {
                                            ivFavorite.setImageResource(R.drawable.ic_article_fav_empty);
                                        }
                                    }
                                } catch (NumberFormatException e) {
                                    e.printStackTrace();
                                }
                            }
                        });


                if (isAdded() && getActivity() != null) {
                    if (customProgressDialog != null && customProgressDialog.isShowing()) {
                        customProgressDialog.dismiss();
                    }
                    llBottomSheet.setVisibility(View.VISIBLE);
                }


            }

            @Override
            public void onLoadResource(WebView view, String url) {
                super.onLoadResource(view, url);
                wvArticle.evaluateJavascript("hidecontent();", null);
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {

                        wvArticle.setVisibility(View.VISIBLE);
                    }
                }, 3000);
            }
        };

    }

    @Override
    public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
        int i = ratingBar.getId();
        if (i == R.id.rbUserRating) {
            if (NetworkFactory.getInstance().isNetworkAvailable(getActivity())) {
                if (fromUser) {
                    rateDiscover(rating);
                }
            } else {
                Utils.showSnackBarMessage(rootLayout, getString(R.string.internet_not_available));
            }

        }
    }

    private void addToFavorite() {
        progressDialog = new ProgressDialog(getActivity());
        progressDialog.setMessage(getString(R.string.msg_please_wait));
        progressDialog.show();

        AddToFavoriteBody addToFavoriteBody = new AddToFavoriteBody();
        addToFavoriteBody.setID(articleId);
        addToFavoriteBody.setType(Constant.RATING_TYPE_ARTICLE);
        addToFavoriteBody.setMemberID(Integer.parseInt(DiscoverConfig.discoverUser.getUserID()));

        RestClient restClient = new RestClient(getActivity(), DiscoverConfig.BASE_URL, DiscoverConfig.DEBUG);
        restClient.getDiscoverService().addToFavourite(addToFavoriteBody).enqueue(new Callback<AddToFavouritResponse>() {
            @Override
            public void onResponse(Call<AddToFavouritResponse> call, Response<AddToFavouritResponse> response) {
                if (isAdded() && getActivity() != null) {
                    if (progressDialog.isShowing()) {
                        progressDialog.dismiss();
                    }
                    if (response != null && response.body() != null) {

                        if (response.body().getStatus() == 0) {
                            ivFavorite.setImageResource(R.drawable.ic_article_fav_fill);
                            favorite = 0;

                        } else {
                            DialogFactory.getInstance().showAlertDialog(getActivity(), null, 0, getString(R.string.msg_api_response_failure), getString(R.string.str_ok), true);
                            //   Toast.makeText(getActivity(), getString(R.string.msg_api_response_failure), Toast.LENGTH_SHORT).show();
                        }

                    } else {
                        DialogFactory.getInstance().showAlertDialog(getActivity(), null, 0, getString(R.string.msg_api_response_null), getString(R.string.str_ok), true);
                        // Toast.makeText(getActivity(), getString(R.string.msg_api_response_null), Toast.LENGTH_SHORT).show();
                    }
                }
            }

            @Override
            public void onFailure(Call<AddToFavouritResponse> call, Throwable t) {
                if (isAdded() && getActivity() != null) {
                    if (progressDialog.isShowing()) {
                        progressDialog.dismiss();
                    }
                    DialogFactory.getInstance().showAlertDialog(getActivity(), null, 0, getString(R.string.msg_api_failure), getString(R.string.str_ok), true);
                    //  Toast.makeText(getActivity(), getString(R.string.msg_api_failure), Toast.LENGTH_SHORT).show();
                }
            }
        });

    }

    private void callRemoveFromFavorite() {
        progressDialog = new ProgressDialog(getActivity());
        progressDialog.setMessage(getString(R.string.msg_please_wait));
        progressDialog.show();

        RemoveFromFavoriteBody removeFromFavoriteBody = new RemoveFromFavoriteBody();
        removeFromFavoriteBody.setID(articleId);
        removeFromFavoriteBody.setType(Constant.RATING_TYPE_ARTICLE);
        removeFromFavoriteBody.setMemberID(Integer.parseInt(DiscoverConfig.discoverUser.getUserID()));
        RestClient restClient = new RestClient(getActivity(), DiscoverConfig.BASE_URL, DiscoverConfig.DEBUG);
        restClient.getDiscoverService().removeFromFavourite(removeFromFavoriteBody).enqueue(new Callback<RemoveFromFavouriteResponse>() {
            @Override
            public void onResponse(Call<RemoveFromFavouriteResponse> call, Response<RemoveFromFavouriteResponse> response) {
                if (isAdded() && getActivity() != null) {
                    if (progressDialog.isShowing()) {
                        progressDialog.dismiss();
                    }

                    if (response != null && response.body() != null) {

                        if (response.body().getStatus() == 0) {
                            ivFavorite.setImageResource(R.drawable.ic_article_fav_empty);
                            favorite = 1;

                        } else {
                            DialogFactory.getInstance().showAlertDialog(getActivity(), null, 0, getString(R.string.msg_api_response_failure), getString(R.string.str_ok), true);
                            //  Toast.makeText(getActivity(), getString(R.string.msg_api_response_failure), Toast.LENGTH_SHORT).show();
                        }

                    } else {
                        DialogFactory.getInstance().showAlertDialog(getActivity(), null, 0, getString(R.string.msg_api_response_null), getString(R.string.str_ok), true);

                        //   Toast.makeText(getActivity(), getString(R.string.msg_api_response_null), Toast.LENGTH_SHORT).show();
                    }
                }
            }

            @Override
            public void onFailure(Call<RemoveFromFavouriteResponse> call, Throwable t) {
                if (isAdded() && getActivity() != null) {
                    if (progressDialog.isShowing()) {
                        progressDialog.dismiss();
                    }
                    DialogFactory.getInstance().showAlertDialog(getActivity(), null, 0, getString(R.string.msg_api_failure), getString(R.string.str_ok), true);
                    //   Toast.makeText(getActivity(), getString(R.string.msg_api_failure), Toast.LENGTH_SHORT).show();
                }
            }
        });


    }

    @OnClick({R2.id.ivFavorite})
    public void onClick(View view) {
        int i = view.getId();
        if (i == R.id.ivFavorite) {
            if (NetworkFactory.getInstance().isNetworkAvailable(getActivity())) {
                switch (favorite) {
                    case 0:
                        callRemoveFromFavorite();

                        break;
                    case 1:

                        addToFavorite();
                        break;
                }
            } else {
                Utils.showSnackBarMessage(rootLayout, getString(R.string.internet_not_available));
            }


        }
    }

    private void rateDiscover(float rating) {
        progressDialog = new ProgressDialog(getActivity());
        progressDialog.setMessage(getString(R.string.msg_please_wait));
        progressDialog.show();

        RateDiscoverBody rateDiscoverBody = new RateDiscoverBody();
        rateDiscoverBody.setMemberID(Integer.parseInt(DiscoverConfig.discoverUser.getUserID()));
        rateDiscoverBody.setID(articleId);
        rateDiscoverBody.setRating((int) rating);
        rateDiscoverBody.setType(Constant.RATING_TYPE_ARTICLE);
        RestClient restClient = new RestClient(getActivity(), DiscoverConfig.BASE_URL, DiscoverConfig.DEBUG);

        Call<RateDiscoverResponse> call = restClient.getDiscoverService().rateDiscover(rateDiscoverBody);
        call.enqueue(new Callback<RateDiscoverResponse>() {
            @Override
            public void onResponse(Call<RateDiscoverResponse> call, Response<RateDiscoverResponse> response) {
                if (isAdded() && getActivity() != null) {
                    if (progressDialog.isShowing()) {
                        progressDialog.dismiss();
                    }
                    if (response != null && response.body() != null) {
                        //noinspection StatementWithEmptyBody
                        if (response.body().getStatus() == 0) {
                            //Success
                        } else if (response.body().getStatus() == -1) {
                            DialogFactory.getInstance().showAlertDialog(getActivity(), null, 0, getString(R.string.msg_api_response_failure), getString(R.string.str_ok), true);
                            // Toast.makeText(getActivity(), getString(R.string.msg_api_response_failure), Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        DialogFactory.getInstance().showAlertDialog(getActivity(), null, 0, getString(R.string.msg_api_response_null), getString(R.string.str_ok), true);
                        //  Toast.makeText(getActivity(), getString(R.string.msg_api_response_null), Toast.LENGTH_SHORT).show();
                    }
                }
            }

            @Override
            public void onFailure(Call<RateDiscoverResponse> call, Throwable t) {
                if (isAdded() && getActivity() != null) {
                    if (progressDialog.isShowing()) {
                        progressDialog.dismiss();
                    }
                    DialogFactory.getInstance().showAlertDialog(getActivity(), null, 0, getString(R.string.msg_api_failure), getString(R.string.str_ok), true);
                    //  Toast.makeText(getActivity(), getString(R.string.msg_api_failure), Toast.LENGTH_SHORT).show();
                }
            }
        });

    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        shareDialogCallbackManager.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
        extraHeaders.put("id", "android");
        extraHeaders.put("MemberId", DiscoverConfig.discoverUser.getUserID());
        //   WellnessCornerApp.getInstance().setArticleIdGetFromGcmNotification("");
        if (getArguments() != null) {
            articleUrl = getArguments().getString(Constant.BUNDLE_KEY_ARTICLE_ID);
        }

    }

    @Override
    public void onResume() {
        super.onResume();
        if (getActivity() != null) {
            if (getActivity() instanceof DiscoverActivity) {
                ((DiscoverActivity) getActivity()).showHomeAsUpEnableToolbar();
                ((DiscoverActivity) getActivity()).setToolBarTitle("");
            } else if (getActivity() instanceof ArticleDetailActivity) {
                ((ArticleDetailActivity) getActivity()).showHomeAsUpEnableToolbar();
                ((ArticleDetailActivity) getActivity()).setToolBarTitle("");
            }

        }
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        getActivity().getMenuInflater().inflate(R.menu.menu_share, menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int i = item.getItemId();
        if (i == R.id.share) {
            shareDialogCallbackManager = CallbackManager.Factory.create();
            FacebookShareUtil facebookShareUtil = new FacebookShareUtil(this, shareDialogCallbackManager, this);
            facebookShareUtil.share(articleId, "", "", articleUrl, "");
            return true;
        } else {
            return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void onShareSuccess(int itemId, String postId) {
        // Post successfully shared
        SharedConfirmationBody sharedConfirmationBody = new SharedConfirmationBody();
        sharedConfirmationBody.setItemID(itemId);
        sharedConfirmationBody.setItemType("ARTICLE");
        sharedConfirmationBody.setMemberID(Integer.parseInt(DiscoverConfig.discoverUser.getUserID()));
        sharedConfirmationBody.setShareThrough("FB");

        RestClient restClient = new RestClient(getActivity(), DiscoverConfig.BASE_URL, DiscoverConfig.DEBUG);
        restClient.getDiscoverService().sharedItemConfirmation(sharedConfirmationBody).enqueue(new Callback<SharedConfirmationResponse>() {
            @Override
            public void onResponse(Call<SharedConfirmationResponse> call, Response<SharedConfirmationResponse> response) {
                if (response != null && response.body() != null && response.body().getStatus() == 0) {
                }
            }

            @Override
            public void onFailure(Call<SharedConfirmationResponse> call, Throwable t) {
                Utils.printLog(ArticleDetailFragmentNew.class.getSimpleName(), t.getLocalizedMessage());
            }
        });

    }

    @Override
    public void onShareError(String error) {
        // Error occurred after showing share dialog
        // DialogFactory.getInstance().showAlertDialog(getActivity(), null, 0, error, getString(R.string.str_ok), true);
        Toast.makeText(getActivity(), error, Toast.LENGTH_SHORT).show();
    }

    public class MyJavaScriptInterface {

        private Context ctx;

        public MyJavaScriptInterface(Context ctx) {
            this.ctx = ctx;
        }

        @JavascriptInterface
        public void loadUrl(final String url) {

            wvArticle.post(new Runnable() {
                @Override
                public void run() {
                    wvArticle.loadUrl(url, extraHeaders);
                }
            });

        }

        @JavascriptInterface
        public void zoomImage(final String imagePath) {
            getActivity().runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    ShowImageDialog sd = new ShowImageDialog(getActivity(), imagePath, "");
                    sd.show();
                }
            });

        }

    }

}
