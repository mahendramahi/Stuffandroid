package com.twc.hramodule.utils;


public class Constant {

    public static final String BUNDLE_GRADE_HRA = "GRADE";
    public static final String BUNDLE_SCORE_HRA = "SCORE";
    public static final String BUNDLE_KEY_PRESELECTED_ANSWER = "PRE_SELECTED_ANSWER";

}
