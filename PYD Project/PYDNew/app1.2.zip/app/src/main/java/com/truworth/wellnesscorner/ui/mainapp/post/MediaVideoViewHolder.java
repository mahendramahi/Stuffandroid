package com.truworth.wellnesscorner.ui.mainapp.post;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Point;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityOptionsCompat;
import android.support.v4.view.ViewCompat;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.CompoundButton;

import com.google.android.exoplayer2.Format;
import com.google.android.exoplayer2.Player;
import com.google.android.exoplayer2.SimpleExoPlayer;
import com.google.android.exoplayer2.ui.PlaybackControlView;
import com.google.android.exoplayer2.ui.PlayerView;
import com.truworth.wellnesscorner.R;
import com.truworth.wellnesscorner.databinding.RowVideoPlayerBinding;
import com.truworth.wellnesscorner.model.PostMediaData;

import im.ene.toro.ToroPlayer;
import im.ene.toro.ToroUtil;
import im.ene.toro.exoplayer.ExoPlayerViewHelper;
import im.ene.toro.media.PlaybackInfo;
import im.ene.toro.widget.Container;

import static com.truworth.wellnesscorner.ui.videoplayer.SinglePlayerActivity.createIntent;

public class MediaVideoViewHolder extends RecyclerView.ViewHolder implements ToroPlayer {
    static final int RQ_PLAYBACK_INFO = 100;
    ExoPlayerViewHelper helper;
    Uri mediaUri;

    PlayerView playerView;

    RowVideoPlayerBinding rowVideoPlayerBinding;
    View.OnClickListener clickListener;

    public void setClickListener(View.OnClickListener clickListener) {
        this.clickListener = clickListener;
        itemView.setOnClickListener(clickListener);
        playerView.setOnClickListener(clickListener);
    }

    public MediaVideoViewHolder(RowVideoPlayerBinding rowVideoPlayerBinding) {
        super(rowVideoPlayerBinding.getRoot());
        this.rowVideoPlayerBinding = rowVideoPlayerBinding;
        playerView = rowVideoPlayerBinding.fbVideoPlayer;
    }

    public void bind(@NonNull PostMediaData postMediaData) {
        this.mediaUri = Uri.parse(postMediaData.getFileName());
        rowVideoPlayerBinding.togVolumeOnOff.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (b) {
                    helper.setVolume(1f);
                } else {
                    helper.setVolume(0f);
                }
            }
        });

        initFullscreenButton(postMediaData.getFileName());
        rowVideoPlayerBinding.executePendingBindings();
    }


    private void initFullscreenButton(String videoUrl) {
        PlaybackControlView controlView = playerView.findViewById(R.id.exo_controller);
        //  mFullScreenIcon = controlView.findViewById(R.id.exo_fullscreen_icon);
        controlView.findViewById(R.id.exo_fullscreen_button).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                ViewCompat.setTransitionName(playerView,
                        "single player");

                Point viewSize = new Point(playerView.getWidth(), playerView.getHeight());
                Point videoSize = new Point(playerView.getWidth(), playerView.getHeight());
                if (playerView instanceof PlayerView && playerView.getPlayer() != null) {
                    Player player = playerView.getPlayer();
                    Format videoFormat =  //
                            player instanceof SimpleExoPlayer ? ((SimpleExoPlayer) player).getVideoFormat()
                                    : null;
                    if (videoFormat != null
                            && videoFormat.width != Format.NO_VALUE
                            && videoFormat.height != Format.NO_VALUE) {
                        videoSize.set(videoFormat.width, videoFormat.height);
                    }
                }

                Intent intent = createIntent(playerView.getContext(), getAdapterPosition(), Uri.parse(videoUrl),
                        "", getCurrentPlaybackInfo(), viewSize, videoSize, true);
                ActivityOptionsCompat options = ActivityOptionsCompat.
                        makeSceneTransitionAnimation((Activity) playerView.getContext(), playerView, ViewCompat.getTransitionName(playerView));
                ((Activity) playerView.getContext()).startActivityForResult(intent, RQ_PLAYBACK_INFO, options.toBundle());


            }
        });
        ;
        //mFullScreenButton
    }

    @NonNull
    @Override
    public View getPlayerView() {
        return playerView;
    }

    @NonNull
    @Override
    public PlaybackInfo getCurrentPlaybackInfo() {
        return helper != null ? helper.getLatestPlaybackInfo() : new PlaybackInfo();
    }

    @Override
    public void initialize(@NonNull Container container, @Nullable PlaybackInfo playbackInfo) {
        if (helper == null) {
            helper = new ExoPlayerViewHelper(this, mediaUri);
        }
        helper.initialize(container, playbackInfo);
    }

    @Override
    public void play() {
        if (helper != null) helper.play();
    }

    @Override
    public void pause() {
        if (helper != null) helper.pause();
    }

    @Override
    public boolean isPlaying() {
        return helper != null && helper.isPlaying();
    }

    @Override
    public void release() {
        if (helper != null) {
            helper.release();
            helper = null;
        }
    }

    @Override
    public boolean wantsToPlay() {
        return ToroUtil.visibleAreaOffset(this, itemView.getParent()) >= 0.85;
    }

    @Override
    public void onSettled(Container container) {
        // Do nothing
    }

    @Override
    public int getPlayerOrder() {
        return getAdapterPosition();
    }

    @Override
    public String toString() {
        return "ExoPlayer{" + hashCode() + " " + getAdapterPosition() + "}";
    }
}
