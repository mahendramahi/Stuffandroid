package com.twc.store.model.requestbody;

/**
 * Created by PalakC on 9/14/2017.
 */

public class DeleteCartItemBody {
    private int CartID;

    public int getCartID() {
        return CartID;
    }

    public void setCartID(int cartID) {
        CartID = cartID;
    }
}
