**Member Registration profile Steps**

1. Registration 
2. Mobile OTP 
3. BMI 
4. Location 
5. Bio
6. Health Goal

In UI section we have files only for First, Third, Fourth and Fifh steps. Second and Sixth are missing. Please eleborate reason for the same.