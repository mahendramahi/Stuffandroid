package com.truworth.wellnesscorner.ui.mainapp.createpost.sharemeal;

import android.content.Context;

import com.truworth.wellnesscorner.base.BaseViewModel;
import com.truworth.wellnesscorner.model.MealDataBean;

public class ShareMealItemViewModel extends BaseViewModel {

    public MealDataBean getMealDataBean() {
        return mealDataBean;
    }

    public void setMealDataBean(MealDataBean mealDataBean) {
        this.mealDataBean = mealDataBean;
    }

    public MealDataBean mealDataBean;
    private Context context;
    public ShareMealItemViewModel(MealDataBean mealDataBean, Context context) {

        this.mealDataBean = mealDataBean;
        this.context = context;
    }


}
