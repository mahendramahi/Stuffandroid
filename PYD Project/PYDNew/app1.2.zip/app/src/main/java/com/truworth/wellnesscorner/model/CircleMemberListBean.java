package com.truworth.wellnesscorner.model;

public class CircleMemberListBean {

    private String memberIdentity;
    private String memberName;
    private String joiningDate;
    private String memberImage;
    private Object memberBio;

    public String getMemberIdentity() {
        return memberIdentity;
    }

    public void setMemberIdentity(String memberIdentity) {
        this.memberIdentity = memberIdentity;
    }

    public String getMemberName() {
        return memberName.trim().toString();
    }

    public void setMemberName(String memberName) {
        this.memberName = memberName;
    }

    public String getJoiningDate() {
        return joiningDate;
    }

    public void setJoiningDate(String joiningDate) {
        this.joiningDate = joiningDate;
    }

    public String getMemberImage() {
        return memberImage;
    }

    public void setMemberImage(String memberImage) {
        this.memberImage = memberImage;
    }

    public Object getMemberBio() {
        return memberBio.toString().trim();
    }

    public void setMemberBio(Object memberBio) {
        this.memberBio = memberBio;
    }
}
