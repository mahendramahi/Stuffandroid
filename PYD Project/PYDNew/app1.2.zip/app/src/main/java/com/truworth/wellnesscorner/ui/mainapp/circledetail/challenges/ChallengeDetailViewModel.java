package com.truworth.wellnesscorner.ui.mainapp.circledetail.challenges;

import com.truworth.wellnesscorner.TheWellnessCornerApp;
import com.truworth.wellnesscorner.base.BaseViewModel;
import com.truworth.wellnesscorner.model.Post;
import com.truworth.wellnesscorner.repo.DashboardRepository;
import com.truworth.wellnesscorner.repo.model.request.CircleDetailPostRequest;
import com.truworth.wellnesscorner.repo.model.response.CircleResponse;
import com.truworth.wellnesscorner.repo.model.response.PostResponse;
import com.truworth.wellnesscorner.utils.SingleLiveEvent;

import java.util.List;

import javax.inject.Inject;

import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;

public class ChallengeDetailViewModel extends BaseViewModel {
    @Inject
    DashboardRepository dashboardRepository;
    public boolean isLastResult = false;
    public boolean loading;
    public SingleLiveEvent<Void> removeLoading = new SingleLiveEvent<>();
    public SingleLiveEvent<Void> getRemoveLoading() {
        return removeLoading;
    }

    public SingleLiveEvent<List<Post>> getPostsList() {
        return postsList;
    }

    public SingleLiveEvent<List<Post>> postsList = new SingleLiveEvent<>();

    SingleLiveEvent<Void> upArrow = new SingleLiveEvent<>();

    public SingleLiveEvent<Void> getUpArrow() {
        return upArrow;
    }

    SingleLiveEvent<Void> showScoreboard = new SingleLiveEvent<>();

    public SingleLiveEvent<Void> getShowScoreboard() {
        return showScoreboard;
    }

    public ChallengeDetailViewModel() {
        TheWellnessCornerApp.getApp().component().inject(this);
    }


    public void setPostList(CircleResponse circleResponse) {
        postsList.setValue(circleResponse.getData().getSocialPost());
    }

    public void loadCirclesPosts(String circleIdentity, String challengeIdentity,int page) {

        CircleDetailPostRequest circleDetailPostRequest = new CircleDetailPostRequest();
        circleDetailPostRequest.setId(circleIdentity); //zxC9hnB2GgQ=
        circleDetailPostRequest.setPostContentIdentity(challengeIdentity);//GV9V50azX6M=
        circleDetailPostRequest.setPageIndex(page);
        circleDetailPostRequest.setPageSize(10);
        circleDetailPostRequest.setPostContentTypeId("3");


        dashboardRepository.getCirclePostWithPaging(circleDetailPostRequest).subscribe(new Observer<PostResponse>() {
            @Override
            public void onSubscribe(Disposable d) {

            }

            @Override
            public void onNext(PostResponse circleResponse) {
                if (!circleResponse.isHasError()) {
                    removeLoading.call();
                    loading = false;
                    if (circleResponse.getData() != null && circleResponse.getData().size() > 0) {
                        postsList.setValue(circleResponse.getData());
                    }else {
                        isLastResult = true;
                        removeLoading.call();
                    }
                }else {
                    isLastResult = true;
                }
            }

            @Override
            public void onError(Throwable e) {
                removeLoading.call();
            }

            @Override
            public void onComplete() {

            }
        });
    }

    public void upArrowClick() {
        upArrow.call();
    }

    public void showScoreboardData() {
        showScoreboard.call();
    }

}
