package com.truworth.stepmodule.model;

import com.google.gson.annotations.SerializedName;

import java.util.List;

/**
 * If this code works it was written by Somesh Kumar on 13 January, 2017. If not, I don't know who wrote it.
 */
public class EFitMonthStepsResponse {

    private String Success;
    private String Msg;
    @SerializedName("steps_data")
    private List<FitBitStepsItem> stepsData;

    public String getSuccess() {
        return Success;
    }

    public void setSuccess(String Success) {
        this.Success = Success;
    }

    public String getMsg() {
        return Msg;
    }

    public void setMsg(String Msg) {
        this.Msg = Msg;
    }

    public List<FitBitStepsItem> getStepsData() {
        return stepsData;
    }

    public void setStepsData(List<FitBitStepsItem> stepsData) {
        this.stepsData = stepsData;
    }
/*
    public static class StepsDataBean {
        private int steps;
        private String date;

        public int getSteps() {
            return steps;
        }

        public void setSteps(int steps) {
            this.steps = steps;
        }

        public String getDate() {
            return date;
        }

        public void setDate(String date) {
            this.date = date;
        }
    }*/
}
