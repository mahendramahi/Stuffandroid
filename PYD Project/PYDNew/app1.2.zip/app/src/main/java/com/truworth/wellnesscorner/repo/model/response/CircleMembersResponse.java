package com.truworth.wellnesscorner.repo.model.response;

import com.truworth.wellnesscorner.model.CircleMemberListBean;

import java.util.List;

public class CircleMembersResponse {
    private DataBean data;
    private boolean hasError;
    private Object error;

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public boolean isHasError() {
        return hasError;
    }

    public void setHasError(boolean hasError) {
        this.hasError = hasError;
    }

    public Object getError() {
        return error;
    }

    public void setError(Object error) {
        this.error = error;
    }

    public static class DataBean {
        private int totalMembers;
        private List<CircleMemberListBean> circleMemberList;

        public int getTotalMembers() {
            return totalMembers;
        }

        public void setTotalMembers(int totalMembers) {
            this.totalMembers = totalMembers;
        }

        public List<CircleMemberListBean> getCircleMemberList() {
            return circleMemberList;
        }

        public void setCircleMemberList(List<CircleMemberListBean> circleMemberList) {
            this.circleMemberList = circleMemberList;
        }
    }
}
