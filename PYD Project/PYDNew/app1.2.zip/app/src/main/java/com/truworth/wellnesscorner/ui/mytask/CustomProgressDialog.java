package com.truworth.wellnesscorner.ui.mytask;

import android.app.ProgressDialog;
import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;

import com.truworth.wellnesscorner.R;
import com.wang.avi.AVLoadingIndicatorView;

/**
 * Created by ManishJ1 on 8/22/2016.
 */
public class CustomProgressDialog extends ProgressDialog {

    //private SlackLoadingView mLoadingView;
    private AVLoadingIndicatorView mLoadingView;
    private int indicatorColor = 0;

    public CustomProgressDialog(Context context) {
        super(context);
    }

    public CustomProgressDialog(Context context, int theme) {
        super(context, theme);
    }

    public CustomProgressDialog(Context context, int theme, boolean isCancellable) {
        super(context, theme);
        setIndeterminate(true);
        setCancelable(isCancellable);
        indicatorColor = Color.WHITE;
    }

    public CustomProgressDialog(Context context, int theme, boolean isCancellable, int indicatorColor) {
        super(context, theme);
        setIndeterminate(true);
        setCancelable(isCancellable);
        this.indicatorColor = indicatorColor;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.custom_progress_dialog);
        //mLoadingView = (SlackLoadingView) findViewById(R.id.loading_view);
        mLoadingView = findViewById(R.id.loading_view);
        mLoadingView.setBackgroundColor(Color.TRANSPARENT);
        mLoadingView.setIndicatorColor(indicatorColor);
    }

    @Override
    public void show() {
        super.show();
        mLoadingView.smoothToShow();
    }

    @Override
    public void dismiss() {
        super.dismiss();
        mLoadingView.smoothToHide();
    }

    @Override
    public void cancel() {
        super.cancel();
        mLoadingView.smoothToHide();
    }

}
