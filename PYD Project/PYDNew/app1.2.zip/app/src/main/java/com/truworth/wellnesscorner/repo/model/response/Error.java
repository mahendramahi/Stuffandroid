package com.truworth.wellnesscorner.repo.model.response;

/**
 * Created by rajeshs on 3/29/2018.
 */

public class Error {
    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    int code;
    String message;
}
