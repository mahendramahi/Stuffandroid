package com.truworth.wellnesscorner.ui.mainapp.circledetail;

import android.app.Activity;
import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Context;
import android.content.Intent;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;

import com.truworth.wellnesscorner.R;
import com.truworth.wellnesscorner.databinding.ActivityCircleDetailBinding;
import com.truworth.wellnesscorner.repo.model.response.CircleResponseData;
import com.truworth.wellnesscorner.ui.mainapp.circledetail.challenges.CircleChallengeFragment;
import com.truworth.wellnesscorner.ui.mainapp.circledetail.coaches.CircleCoachFragment;
import com.truworth.wellnesscorner.ui.mainapp.circledetail.home.CircleHomeFragment;
import com.truworth.wellnesscorner.ui.mainapp.circledetail.members.CircleMemberFragment;
import com.truworth.wellnesscorner.ui.mainapp.createpost.CreatePostActivity;

public class CircleDetailActivity extends AppCompatActivity {
    public static final String CIRCLE_IDENTITY = "circleIdentity";
    public static int REUEST_CODE = 101;
    boolean isUpdate;
    ActivityCircleDetailBinding binding;
    CircleDetailViewModel viewModel;
    CircleHomeFragment circleHomeFragment;
    private CircleDetailViewPagerAdapter mSectionsPagerAdapter;
    //private ViewPager mViewPager;
    private String CircleIdentity = "";

    public static void start(Activity context, String circleIdentity) {
        Intent intent = new Intent(context, CircleDetailActivity.class);
        intent.putExtra(CircleDetailActivity.CIRCLE_IDENTITY, circleIdentity);
        context.startActivityForResult(intent, REUEST_CODE);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_circle_detail);
        viewModel = ViewModelProviders.of(this).get(CircleDetailViewModel.class);
        // binding.setViewModel();
        Toolbar toolbar = binding.circleDetailToolbar;
        setupToolbar(toolbar);


        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            CircleIdentity = extras.getString(CIRCLE_IDENTITY);
        }

        // Create the adapter that will return a fragment for each of the three
        // primary sections of the activity.
        circleHomeFragment = CircleHomeFragment.newInstance(CircleIdentity);
        mSectionsPagerAdapter = new CircleDetailViewPagerAdapter(getSupportFragmentManager());
        mSectionsPagerAdapter.addFrag(circleHomeFragment, "Home");
        mSectionsPagerAdapter.addFrag(CircleCoachFragment.newInstance(CircleIdentity), "Coaches");
        mSectionsPagerAdapter.addFrag(CircleMemberFragment.newInstance(CircleIdentity), "Members");
        mSectionsPagerAdapter.addFrag(CircleChallengeFragment.newInstance(CircleIdentity), "Challenges");
        //mSectionsPagerAdapter.addFrag(CircleAboutFragment.newInstance(CircleIdentity), "About");
        binding.setViewModel(viewModel);
        binding.setPagerAdapter(mSectionsPagerAdapter);
        binding.container.setOffscreenPageLimit(4);
        binding.tabLayout.setupWithViewPager(binding.container);
        attachCircleImageClickObserver();
        setUpDataObserver();
        viewModel.loadCircleDetail(CircleIdentity);
    }

    private void setUpDataObserver() {
        viewModel.getCircleResponseData().observe(this, new Observer<CircleResponseData>() {
            @Override
            public void onChanged(@Nullable CircleResponseData circleResponseData) {
                circleHomeFragment.updateData(circleResponseData.getSocialPost(), circleResponseData.getCircleName());
                getSupportActionBar().setTitle(circleResponseData.getCircleName());
            }
        });
    }

    private void setupToolbar(Toolbar toolbar) {
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
            getSupportActionBar().setDisplayShowTitleEnabled(true);
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void attachCircleImageClickObserver() {
        viewModel.getImageClick().observe(this, new Observer<Void>() {
            @Override
            public void onChanged(@Nullable Void aVoid) {
                //Success, update UI
                CircleAboutActivity.start(CircleDetailActivity.this, CircleIdentity);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == CreatePostActivity.REQUEST_CODE && resultCode == Activity.RESULT_OK) {
            isUpdate = true;
        }
        for (Fragment fragment : getSupportFragmentManager().getFragments()) {
            fragment.onActivityResult(requestCode, resultCode, data);
        }
    }

    @Override
    public void onBackPressed() {
        if (isUpdate) {
            Intent returnIntent = new Intent();
            setResult(RESULT_OK, returnIntent);
        }
        super.onBackPressed();
    }
}
