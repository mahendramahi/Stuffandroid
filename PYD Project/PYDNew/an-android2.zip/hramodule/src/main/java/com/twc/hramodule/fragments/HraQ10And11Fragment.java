package com.twc.hramodule.fragments;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;


import com.twc.greendaolib.GreenDaoApp;
import com.twc.greendaolib.HraDBItem;
import com.twc.greendaolib.HraDBItemDao;
import com.twc.hramodule.HraActivity;
import com.twc.hramodule.R;
import com.twc.hramodule.R2;
import com.twc.hramodule.interfaces.OnHraDbAction;
import com.twc.hramodule.model.beans.HraItem;
import com.twc.hramodule.utils.Utils;
import com.twc.hramodule.views.CustomTextView;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;

/**
 If this code works it was written by Somesh Kumar on 13 October, 2016. If not, I don't know who wrote it.
 */
public class HraQ10And11Fragment extends BaseFragment {

    private static final int QUESTION_ID_FIRST = 14;
    private static final int QUESTION_ID_SECOND = 15;
    private static final String SCREEN_NO = "9";
    @BindView(R2.id.tvQuestionTitleFirst)
    CustomTextView tvQuestionTitleFirst;

    @BindView(R2.id.tvQuestionNoFirst)
    CustomTextView tvQuestionNoFirst;

    @BindView(R2.id.tvQuestionTypeFirst)
    CustomTextView tvQuestionTypeFirst;

    @BindView(R2.id.ivHraImageFirst)
    ImageView ivHraImageFirst;

    @BindView(R2.id.ivSubtractFirst)
    ImageView ivSubtractFirst;

    @BindView(R2.id.tvCountFirst)
    CustomTextView tvCountFirst;

    @BindView(R2.id.ivAddFirst)
    ImageView ivAddFirst;

    @BindView(R2.id.tvQuestionTitleSecond)
    CustomTextView tvQuestionTitleSecond;

    @BindView(R2.id.tvQuestionNoSecond)
    CustomTextView tvQuestionNoSecond;

    @BindView(R2.id.tvQuestionTypeSecond)
    CustomTextView tvQuestionTypeSecond;

    @BindView(R2.id.ivHraImageSecond)
    ImageView ivHraImageSecond;

    @BindView(R2.id.ivSubtractSecond)
    ImageView ivSubtractSecond;

    @BindView(R2.id.tvCountSecond)
    CustomTextView tvCountSecond;

    @BindView(R2.id.ivAddSecond)
    ImageView ivAddSecond;

    @BindView(R2.id.btnNextQuestion)
    Button btnNextQuestion;
    @BindView(R2.id.ivHRABack)
    ImageView ivHRABack;

    @BindView(R2.id.ivCancelHRA)
    ImageView ivCancelHRA;
    private int firstCount = 0, secondCount = 0;
    private List<HraItem> firstAnswerList, secondAnswerList;
    private OnHraDbAction onHraDbAction;

    public static HraQ10And11Fragment newInstance(Bundle bundle) {
        HraQ10And11Fragment fragment = new HraQ10And11Fragment();
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    public int getFragmentLayout() {
        return R.layout.fragment_hra_type3;
    }

    @Override
    public void onFragmentReady() {
        firstAnswerList = new ArrayList<>();
        secondAnswerList = new ArrayList<>();
        tvCountFirst.setText(String.valueOf(firstCount));
        tvCountSecond.setText(String.valueOf(secondCount));
        setFirstQuestion();
        setSecondQuestion();
        // get previous selected answer from database
        String answer;
        HraDBItemDao hraDBDao = GreenDaoApp.getInstance(getActivity()).getDaoSession(getActivity()).getHraDBItemDao();
        List<HraDBItem> answerFirstFromDb = hraDBDao.queryBuilder().where(HraDBItemDao.Properties.QuestionId.eq(QUESTION_ID_FIRST)).list();
        List<HraDBItem> answerSecondFromDb = hraDBDao.queryBuilder().where(HraDBItemDao.Properties.QuestionId.eq(QUESTION_ID_SECOND)).list();
        for (HraDBItem hraDBItem : answerFirstFromDb) {
            answer = hraDBItem.getAnswer();
            tvCountFirst.setText(answer);
            if (answer != null && !answer.equalsIgnoreCase("")) {
                firstCount = Integer.parseInt(answer);
            }
        }
        for (HraDBItem hraDBItem : answerSecondFromDb) {
            answer = hraDBItem.getAnswer();
            tvCountSecond.setText(answer);
            if (answer != null && !answer.equalsIgnoreCase("")) {
                secondCount = Integer.parseInt(answer);
            }
        }


    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        onHraDbAction = (OnHraDbAction) context;
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        onHraDbAction = (OnHraDbAction) activity;
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        view.setFocusableInTouchMode(true);
        view.requestFocus();
        view.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (keyCode == KeyEvent.KEYCODE_BACK && event.getAction() == KeyEvent.ACTION_DOWN) {
                    onBack();
                    return true;
                }
                return false;
            }
        });
    }



    private void setFirstQuestion() {
        String[] hraQuestion = getActivity().getResources().getStringArray(R.array.hra_questions);
        String[] hraAnswer = getActivity().getResources().getStringArray(R.array.hra_que14_row);
        setFirstHraQuestion(hraQuestion[13], hraAnswer);
    }


    private void setSecondQuestion() {
        String[] hraQuestion = getActivity().getResources().getStringArray(R.array.hra_questions);
        String[] hraAnswer = getActivity().getResources().getStringArray(R.array.hra_que15_row);
        setSecondHraQuestion(hraQuestion[14], hraAnswer);
    }


    private void setFirstHraQuestion(String question, String[] hraAnswer) {
        tvQuestionTypeFirst.setText("DIET");
        tvQuestionNoFirst.setText("10");
        tvQuestionTitleFirst.setText(question);
        ivHraImageFirst.setImageResource(R.drawable.image_q_10);

        for (String ans : hraAnswer) {
            String[] splitArray = ans.split("~");
            String id = splitArray[0];
            String name = splitArray[1];
            HraItem item = new HraItem();
            item.setQuestionID(QUESTION_ID_FIRST);
            item.setAnswerID(id);
            item.setAnswer(name);
            item.setScreenNo(SCREEN_NO);
            firstAnswerList.add(item);
        }
    }


    private void setSecondHraQuestion(String question, String[] hraAnswer) {
        tvQuestionTypeSecond.setText("DIET");
        tvQuestionNoSecond.setText("11");
        tvQuestionTitleSecond.setText(question);
        ivHraImageSecond.setImageResource(R.drawable.image_q_11);

        for (String ans : hraAnswer) {
            String[] splitArray = ans.split("~");
            String id = splitArray[0];
            String name = splitArray[1];
            HraItem item = new HraItem();
            item.setQuestionID(QUESTION_ID_SECOND);
            item.setAnswerID(id);
            item.setAnswer(name);
            item.setScreenNo(SCREEN_NO);
            secondAnswerList.add(item);
        }
    }


    @OnClick({R2.id.btnNextQuestion, R2.id.ivAddFirst, R2.id.ivAddSecond, R2.id.ivSubtractFirst, R2.id.ivSubtractSecond, R2.id.ivCancelHRA, R2.id.ivHRABack})
    public void onClick(View view) {
        int i = view.getId();
        if (i == R.id.ivHRABack) {
            onBack();

        } else if (i == R.id.ivCancelHRA) {
            cancelHra();

        } else if (i == R.id.btnNextQuestion) {
            String answerFirst, answerSecond;
                /*Answer to first question*/
            answerFirst = tvCountFirst.getText().toString().trim();

                /*Answer to second question*/
            answerSecond = tvCountSecond.getText().toString().trim();

            onHraDbAction.onHraQuestionSave(QUESTION_ID_FIRST, answerFirst, SCREEN_NO, 0);
            onHraDbAction.onHraQuestionSave(QUESTION_ID_SECOND, answerSecond, SCREEN_NO, 0);
            Utils.replaceFragment(getFragmentManager(), HraQ12Fragment.newInstance(getArguments()), HraQ12Fragment.class.getSimpleName(), true, R.id.fragmentContainerHra);

        } else if (i == R.id.ivAddFirst) {
            if (firstCount >= 0) {
                firstCount++;
                tvCountFirst.setText(String.valueOf(firstCount));
            }

        } else if (i == R.id.ivAddSecond) {
            if (secondCount >= 0) {
                secondCount++;
                tvCountSecond.setText(String.valueOf(secondCount));
            }

        } else if (i == R.id.ivSubtractFirst) {
            if (firstCount > 0) {
                firstCount--;
                tvCountFirst.setText(String.valueOf(firstCount));
            }

        } else if (i == R.id.ivSubtractSecond) {
            if (secondCount > 0) {
                secondCount--;
                tvCountSecond.setText(String.valueOf(secondCount));
            }

        }
    }

    private void onBack() {
        Utils.replaceFragmentHraBackAnimation(getFragmentManager(), HraQ8And9Fragment.newInstance(getArguments()), HraQ8And9Fragment.class.getSimpleName(), true, R.id.fragmentContainerHra);
    }

    private void cancelHra() {
        // if isRetakeTest parameter is true, then user always came here from hra report
        if (getArguments().containsKey("isRetakeTest") && getArguments().getBoolean("isRetakeTest")) {
            getFragmentManager().popBackStackImmediate(HraRiskGradeFragment.class.getSimpleName(), 0);
        } else {
            getActivity().finish();
        }
    }
}
