package com.truworth.wellnesscorner.ui.mainapp.circledetail.members;

import android.databinding.DataBindingUtil;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import com.truworth.wellnesscorner.R;
import com.truworth.wellnesscorner.databinding.RowLoadingProgressBinding;
import com.truworth.wellnesscorner.databinding.RowMembersBinding;
import com.truworth.wellnesscorner.model.CircleMemberListBean;

import java.util.List;

public class CircleMemberAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder>{
    private static final int VIEW_TYPE_ITEM = 1;
    private static final int VIEW_TYPE_PROGRESS = 2;
    private List<CircleMemberListBean> members;

    public CircleMemberAdapter(List<CircleMemberListBean> members) {
        this.members = members;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        RecyclerView.ViewHolder viewHolder = null;
        if(viewType == VIEW_TYPE_ITEM) {

            RowMembersBinding binding = DataBindingUtil.inflate(LayoutInflater.from(parent.getContext()), R.layout.row_members, parent, false);
            viewHolder= new ViewHolder(binding);
        }
        else {
            RowLoadingProgressBinding rowLoadingProgressBinding = DataBindingUtil.inflate(LayoutInflater.from(parent.getContext()), R.layout.row_loading_progress, parent, false);
            viewHolder= new ViewHolderLoading(rowLoadingProgressBinding);
        }
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        if(holder.getItemViewType()==VIEW_TYPE_PROGRESS){
            ViewHolderLoading viewHolderLoading = (ViewHolderLoading) holder;
            viewHolderLoading.rowLoadingProgressBinding.progressBar.setIndeterminate(true);
          }
        else{
            ViewHolder viewHolder = (ViewHolder) holder;
            viewHolder.bind(members.get(position));
        }

    }
    @Override
    public int getItemViewType(int position) {
        if (members.get(position) == null) {
            return VIEW_TYPE_PROGRESS;
        }
        return VIEW_TYPE_ITEM;
    }

    @Override
    public int getItemCount() {
        return (null != members ? members.size() : 0);
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private RowMembersBinding mBinding;

        public ViewHolder(RowMembersBinding binding) {
            super(binding.getRoot());
            mBinding = binding;
        }

        public void bind(@NonNull CircleMemberListBean members) {
            CircleMemberItemViewModel viewModel = new CircleMemberItemViewModel(members);

            mBinding.setViewModel(viewModel);
            mBinding.executePendingBindings();
        }
    }

    public class ViewHolderLoading extends RecyclerView.ViewHolder {
        private RowLoadingProgressBinding rowLoadingProgressBinding;

        public ViewHolderLoading(RowLoadingProgressBinding binding) {
            super(binding.getRoot());
            rowLoadingProgressBinding = binding;
        }
    }
}

