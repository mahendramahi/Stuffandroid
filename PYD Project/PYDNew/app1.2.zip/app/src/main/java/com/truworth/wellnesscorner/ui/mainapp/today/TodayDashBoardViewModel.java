package com.truworth.wellnesscorner.ui.mainapp.today;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.databinding.ObservableBoolean;
import android.databinding.ObservableField;
import android.databinding.ObservableInt;
import android.os.Handler;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;

import com.truworth.stepmodule.StepHelper;
import com.truworth.stepmodule.inteface.OnRangeStepsFound;
import com.truworth.stepmodule.inteface.OnTodayStepsFound;
import com.truworth.stepmodule.model.EFitMonthStepsBody;
import com.truworth.stepmodule.model.EFitMonthStepsResponse;
import com.truworth.stepmodule.model.FitBitStepsItem;
import com.truworth.stepmodule.model.StepItem;
import com.truworth.stepmodule.rest.FitBitRestClient;
import com.truworth.stepmodule.utils.FitBitConfig;
import com.truworth.wellnesscorner.R;
import com.truworth.wellnesscorner.TheWellnessCornerApp;
import com.truworth.wellnesscorner.base.BaseViewModel;
import com.truworth.wellnesscorner.data.SharedPreferenceHelper;
import com.truworth.wellnesscorner.interfaces.OnClickRefreshStep;
import com.truworth.wellnesscorner.model.HabitStatus;
import com.truworth.wellnesscorner.model.MyTask;
import com.truworth.wellnesscorner.model.Post;
import com.truworth.wellnesscorner.model.TodayDashBoardBean;
import com.truworth.wellnesscorner.model.TodayMyChallenge;
import com.truworth.wellnesscorner.model.TodayTrackerValue;
import com.truworth.wellnesscorner.repo.DashboardRepository;
import com.truworth.wellnesscorner.repo.StepRepository;
import com.truworth.wellnesscorner.repo.model.request.SaveDeviceStepsBody;
import com.truworth.wellnesscorner.repo.model.request.TodayChallengeRequest;
import com.truworth.wellnesscorner.repo.model.request.TodayPostsRequest;
import com.truworth.wellnesscorner.repo.model.request.TodayTrackerRequest;
import com.truworth.wellnesscorner.repo.model.response.PostResponse;
import com.truworth.wellnesscorner.repo.model.response.SaveStepsResponse;
import com.truworth.wellnesscorner.repo.model.response.TodayMyChallengesResponse;
import com.truworth.wellnesscorner.repo.model.response.TodayTrackerResponse;
import com.truworth.wellnesscorner.ui.mytask.MyTaskActivty;
import com.truworth.wellnesscorner.ui.mytask.MyTaskConfig;
import com.truworth.wellnesscorner.ui.mytask.MyTaskUser;
import com.truworth.wellnesscorner.ui.step.NetworkFactory;
import com.truworth.wellnesscorner.ui.step.StepActivity;
import com.truworth.wellnesscorner.ui.step.StepServerResponse;
import com.truworth.wellnesscorner.ui.step.StepsBean;
import com.truworth.wellnesscorner.utils.AppConstants;
import com.truworth.wellnesscorner.utils.CommonUtils;
import com.truworth.wellnesscorner.utils.DateUtils;
import com.truworth.wellnesscorner.utils.SingleLiveEvent;
import com.truworth.wellnesscorner.utils.Utils;
import com.twc.dailylog.MealActivity;
import com.twc.dailylog.WaterActivity;
import com.twc.dailylog.model.beans.DailyLogUser;
import com.twc.dailylog.utils.DailyLogConfig;
import com.twc.dailylog.utils.WaterConfig;
import com.twc.remindermodule.ReminderActivity;
import com.twc.remindermodule.model.beans.ReminderUser;
import com.twc.remindermodule.rest.ReminderConfig;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class TodayDashBoardViewModel extends BaseViewModel {

    private OnClickRefreshStep onClickRefresh;
    @Inject
    SharedPreferenceHelper prefHelper;
    StepHelper stepHelper;
    Context context;
    public int page = 1;
    public boolean isLastResult = false;
    public boolean loading;
    public SingleLiveEvent<List<Post>> todayPost = new SingleLiveEvent<>();
    public SingleLiveEvent<List<TodayMyChallenge>> todayMyChallenge = new SingleLiveEvent<>();
    public ObservableBoolean isSwipeRefresh = new ObservableBoolean();

    public ObservableBoolean isProgressVisible = new ObservableBoolean();
    private Animation rotateSync;


    public SingleLiveEvent<TodayTrackerResponse> getTodayTrackerResponse() {
        return todayTrackerResponseData;
    }

    public SingleLiveEvent<TodayTrackerResponse> todayTrackerResponseData = new SingleLiveEvent<>();

    public SingleLiveEvent<List<Post>> getTodayPosts() {
        return todayPost;
    }

    public SingleLiveEvent<List<TodayMyChallenge>> getTodayMyChallenge() {
        return todayMyChallenge;
    }

    public SingleLiveEvent<Void> getRemoveLoading() {
        return removeLoading;
    }


    SingleLiveEvent<Void> upArrow = new SingleLiveEvent<>();
    public SingleLiveEvent<Void> onRefresh = new SingleLiveEvent<>();

    public SingleLiveEvent<Void> removeLoading = new SingleLiveEvent<>();

    public TodayDashBoardViewModel() {
        isSwipeRefresh.set(false);
        TheWellnessCornerApp.getApp().component().inject(this);

    }

    public void setRefreshIconVisibility(boolean res) {
        isDeviceConnected.set(res);
    }

    @Inject
    StepRepository repository;
    @Inject
    DashboardRepository dashboardRepository;

    private int totalHabits;
    private double currentWeight = 0;
    private double firstWeight = 0;
    private double targetWeight = 0;
    private int habitValue;


    private TodayDashBoardBean todayDashBoardBean;

    public ObservableField<String> foodVal = new ObservableField<>();
    public ObservableField<String> exerciseVal = new ObservableField<>();
    public ObservableField<String> waterVal = new ObservableField<>();
    public ObservableField<String> weightVal = new ObservableField<>();
    public ObservableField<String> weightDate = new ObservableField<>();
    public ObservableField<String> stepVal = new ObservableField<>();
    public ObservableField<String> habitVal = new ObservableField<>();
    public ObservableField<String> taskVal = new ObservableField<>();
    public ObservableBoolean isDeviceConnected = new ObservableBoolean();
    public ObservableInt stepPb = new ObservableInt();

    public View refreshView;
    public ObservableBoolean connectDevice = new ObservableBoolean();
    public SingleLiveEvent<List<TodayTrackerValue>> todayHabitList = new SingleLiveEvent<>();
    public SingleLiveEvent<HabitStatus> habitStatus = new SingleLiveEvent<>();
    public SingleLiveEvent<MyTask> taskStatus = new SingleLiveEvent<>();


    public SingleLiveEvent<Void> getUpArrow() {
        return upArrow;
    }

    public void getOnRefresh(View view) {
        refreshView = view;
        if (prefHelper.getPrefKeyDeviceConnected() != null && prefHelper.getPrefKeyDeviceConnected().length() > 0) {
            setupAnimation(view);
            onClickRefresh.onClickRefresh();
        } else {
            onStepClicked(view);

        }
    }

    private void stopAnimation() {
        if (rotateSync != null)
            rotateSync.cancel();
    }


    private void setupAnimation(View view) {
        Activity activity = (Activity) view.getContext();
        rotateSync = AnimationUtils.loadAnimation(activity, R.anim.rotator);
        rotateSync.setDuration(1000);
        view.startAnimation(rotateSync);
        final Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                stopAnimation();
            }
        }, 2000);

    }

    public void onFoodClicked(View view) {
        Activity activity = (Activity) view.getContext();

        DailyLogConfig.dailyLogUser.setType("Meal");
        DailyLogConfig.dailyLogUser.setMealType("Breakfast");


        Intent intent = new Intent(activity, MealActivity.class);
        activity.startActivityForResult(intent, AppConstants.CALL_MODULE_REQUEST);
    }

    public void onExerciseClicked(View view) {
        Activity activity = (Activity) view.getContext();

        DailyLogConfig.dailyLogUser.setType("Exercise");
        DailyLogConfig.dailyLogUser.setMealType("");

        Intent intent = new Intent(activity, MealActivity.class);
        activity.startActivityForResult(intent, AppConstants.CALL_MODULE_REQUEST);

    }

    public void onWaterClicked(View view) {
        Activity activity = (Activity) view.getContext();

        DailyLogConfig.dailyLogUser.setType("");
        DailyLogConfig.dailyLogUser.setMealType("");

        Intent intent = new Intent(activity, WaterActivity.class);
        intent.putExtra("waterIntake", waterVal.get());
        //activity.startActivity(intent);
        activity.startActivityForResult(intent, AppConstants.CALL_MODULE_REQUEST);
    }

    //Healthy habits call
    public void onReminderClicked(View view) {
        Activity activity = (Activity) view.getContext();

        if (!ReminderConfig.APP_NAME.isEmpty() && !ReminderConfig.BASE_URL.isEmpty() && ReminderConfig.reminderUser != null) {
            Intent intent = new Intent(activity, ReminderActivity.class);
            intent.putExtra("totalHabits", habitValue);
            intent.putExtra("token", prefHelper.getToken());
            intent.putExtra("waterIntake", waterVal.get());
            intent.putExtra("connectedDevice", prefHelper.getPrefKeyDeviceConnected());
            activity.startActivityForResult(intent, AppConstants.CALL_MODULE_REQUEST);
        } else {
            // Log.d("reminderlib", "reminderlib: not initialised in right way.");
        }
    }

    public void navigateMyTask(View view) {
        Activity activity = (Activity) view.getContext();

        if (!MyTaskConfig.APP_NAME.isEmpty() && !MyTaskConfig.BASE_URL.isEmpty() && MyTaskConfig.myTaskUser != null) {
            Intent intent = new Intent(activity, MyTaskActivty.class);
            activity.startActivityForResult(intent, AppConstants.CALL_MODULE_REQUEST);
        }
    }

    public void onWeightClicked(View view) {
        Activity activity = (Activity) view.getContext();


        DailyLogConfig.dailyLogUser.setType("Weight");
        DailyLogConfig.dailyLogUser.setMealType("");

        Intent intent = new Intent(activity, MealActivity.class);
        intent.putExtra("CURRENT_WEIGHT", currentWeight);
        intent.putExtra("FIRST_WEIGHT", firstWeight);
        intent.putExtra("TARGET_WEIGHT", targetWeight);
        activity.startActivityForResult(intent, AppConstants.CALL_MODULE_REQUEST);
    }

    public void onStepClicked(View view) {
        Activity activity = (Activity) view.getContext();
        Intent intent = new Intent(activity, StepActivity.class);
        intent.putExtra("connectedDevice", prefHelper.getPrefKeyDeviceConnected());
        activity.startActivityForResult(intent, AppConstants.CALL_MODULE_REQUEST);
    }


    public TodayDashBoardViewModel(TodayDashBoardBean todayDashBoardBean, OnClickRefreshStep refreshListener) {
        connectDevice.set(false);
        TheWellnessCornerApp.getApp().component().inject(this);
        this.todayDashBoardBean = todayDashBoardBean;
        this.onClickRefresh = refreshListener;
        saprateTrackerData(todayDashBoardBean);
    }

    private void saprateTrackerData(TodayDashBoardBean todayDashBoardBean) {
        if (todayDashBoardBean.getHabitStatus() != null) {
            habitVal.set(todayDashBoardBean.getHabitStatus().getCompletedHabits() + "/" + todayDashBoardBean.getHabitStatus().getTotalHabits());
            habitValue = todayDashBoardBean.getHabitStatus().getTotalHabits();
        }
        if (todayDashBoardBean.getMyTask() != null) {
            taskVal.set(todayDashBoardBean.getMyTask().getCompletedTask() + "/" + todayDashBoardBean.getMyTask().getTotalTask());
        }
        if (todayDashBoardBean.getTodayTrackerValues() != null) {


            for (TodayTrackerValue todayTrackerValue : todayDashBoardBean.getTodayTrackerValues()) {

                if (todayTrackerValue.getTrackerName().equalsIgnoreCase(AppConstants.FOOD_TRACKER)) {
                    foodVal.set(String.format("%d", (int) todayTrackerValue.getTrackerData().getValue()));
                } else if (todayTrackerValue.getTrackerName().equalsIgnoreCase(AppConstants.EXCERCISE_TRACKER)) {
                    exerciseVal.set(String.format("%d", (int) todayTrackerValue.getTrackerData().getValue()));
                } else if (todayTrackerValue.getTrackerName().equalsIgnoreCase(AppConstants.GLASS_TRACKER)) {
                    waterVal.set(String.format("%d", (int) todayTrackerValue.getTrackerData().getValue()));
                } else if (todayTrackerValue.getTrackerName().equalsIgnoreCase(AppConstants.WEIGHT_TRACKER)) {
                    currentWeight = todayTrackerValue.getTrackerData().getCurrentWeight();
                    firstWeight = todayTrackerValue.getTrackerData().getFirstWeight();
                    targetWeight = todayTrackerValue.getTrackerData().getTargetWeight();
                    weightVal.set("- " + (int) todayTrackerValue.getTrackerData().getCurrentWeight() + " kgs");
                    weightDate.set("(as of " + DateUtils.formatDate(todayTrackerValue.getTrackerData().getLastTrackedDate(), DateUtils.SERVER_DATE, "MMM dd,yyyy") + ")");

                } else if (todayTrackerValue.getTrackerName().equalsIgnoreCase(AppConstants.STEPS_TRACKER)) {
                    StepServerResponse response = new StepServerResponse();
                    StepServerResponse.DataBean bean = new StepServerResponse.DataBean();
                    bean.setFirstStepSyncDate(todayTrackerValue.getTrackerData().getFirstStepSyncDate());
                    bean.setLastConnectedDevice(todayTrackerValue.getTrackerData().getLastConnectedDevice());
                    bean.setLastStepSyncDate(todayTrackerValue.getTrackerData().getLastStepSyncDate());
                    bean.setLastStepUpdatedDate(todayTrackerValue.getTrackerData().getLastUpdatedDate());
                    response.setData(bean);
                    TheWellnessCornerApp.getInstance().setStepServerResponse(response);

                    String steps = (int) todayTrackerValue.getTrackerData().getValue() + "";


                    // Spanned htmlText = Utils.fromHtml("<font size=\"2\" color=\"#545454\">" + a1 + "</font></big><font size=\"6\" color=\"#000000\">" + Utils.convertNumberWithCommas(steps) + "</font></big><font size=\"2\" color=\"#545454\">" + a2 + "</font>");

                    if (prefHelper.getPrefKeyDeviceConnected().length() < 1) {
                        //mBinding.tvUserConnectDevice.setVisibility(View.VISIBLE);
                        connectDevice.set(true);
                        stepVal.set(Utils.convertNumberWithCommas(steps));

                    } else if (response != null && response.getData() != null
                            && response.getData().getLastConnectedDevice() != null
                            && response.getData().getLastConnectedDevice().equalsIgnoreCase(prefHelper.getPrefKeyDeviceConnected())) {
                        // mBinding.tvUserConnectDevice.setVisibility(View.GONE);
                        stepVal.set(Utils.convertNumberWithCommas(steps));
                        connectDevice.set(false);
                        // mBinding.tvStep.setVisibility(View.VISIBLE);
                    } else if (prefHelper.getPrefKeyDeviceConnected().length() > 0) {
                        // mBinding.tvUserConnectDevice.setVisibility(View.GONE);
                        connectDevice.set(false);
                        stepVal.set(Utils.convertNumberWithCommas(steps));
                        // mBinding.tvStep.setVisibility(View.VISIBLE);
                    }

                    int steps1 = (int) todayTrackerValue.getTrackerData().getValue();
                    if (steps1 > 8000) {
                        steps1 = 8000;
                    }

                    stepPb.set(steps1);


                }

            }


        }


    }


    public TodayDashBoardBean getTodayDashBoardBean() {
        return todayDashBoardBean;
    }

    public void getTodayTrackerValues(boolean shouldWholeListUpdate) {
        isRefresh(isSwipeRefresh.get());
        //  isProgressVisible.set(true);
        TodayTrackerRequest todayTrackerRequest = new TodayTrackerRequest();
        String date = DateUtils.getInstance().getTodayDate("yyyy-MM-dd'T'HH:mm:ss");
        todayTrackerRequest.setDeviceDate(date);

        dashboardRepository.getTodayTracker(todayTrackerRequest).subscribe(new Observer<TodayTrackerResponse>() {
            @Override
            public void onSubscribe(Disposable d) {

            }

            @Override
            public void onNext(TodayTrackerResponse todayTrackerResponse) {
                stopAnimation();
                isProgressVisible.set(false);
                if (!todayTrackerResponse.isHasError()) {

//                    todayHabitList.setValue(todayTrackerResponse.getData().getTrackers());
//                    habitStatus.setValue(todayTrackerResponse.getData().getHabitStatus());
//                    taskStatus.setValue(todayTrackerResponse.getData().getMyTask());

                    todayTrackerResponseData.setValue(todayTrackerResponse);

                }
                if (shouldWholeListUpdate) {
                    getTodayMyChallenges();
                }

            }

            @Override
            public void onError(Throwable e) {
                stopAnimation();
                isProgressVisible.set(false);
                isSwipeRefresh.set(false);
            }

            @Override
            public void onComplete() {
                stopAnimation();
                isProgressVisible.set(false);
                isSwipeRefresh.set(false);
            }
        });
    }


    public void getTodayMyChallenges() {
        isRefresh(isSwipeRefresh.get());
        // isProgressVisible.set(true);
        TodayChallengeRequest todayChallengeRequest = new TodayChallengeRequest();
        todayChallengeRequest.setPageIndex(1);
        dashboardRepository.getTodayMyChallenges(todayChallengeRequest).subscribe(new Observer<TodayMyChallengesResponse>() {
            @Override
            public void onSubscribe(Disposable d) {

            }

            @Override
            public void onNext(TodayMyChallengesResponse todayMyChallengesResponse) {
                isProgressVisible.set(false);
                //  if (!todayMyChallengesResponse.isHasError()) {
                todayMyChallenge.setValue(todayMyChallengesResponse.getData());
//                }else{
//
//                }
                page = 1;
                getTodayPost();
            }

            @Override
            public void onError(Throwable e) {
                isProgressVisible.set(false);
            }

            @Override
            public void onComplete() {
                isProgressVisible.set(false);
            }
        });

    }


    public void getTodayPost() {
        TodayPostsRequest todayPostsRequest = new TodayPostsRequest();
        todayPostsRequest.setPageIndex(page);
        todayPostsRequest.setPageSize(10);
        dashboardRepository.getTodayPosts(todayPostsRequest).subscribe(new Observer<PostResponse>() {
            @Override
            public void onSubscribe(Disposable d) {

            }

            @Override
            public void onNext(PostResponse postResponse) {
                removeLoading.call();
                loading = false;


                if (!postResponse.isHasError()) {
                    if (postResponse.getData() != null && postResponse.getData().size() > 0) {
                        todayPost.setValue(postResponse.getData());
                    } else {
                        isLastResult = true;
                        removeLoading.call();
                    }
                } else {
                    isLastResult = true;
                }
            }

            @Override
            public void onError(Throwable e) {

                removeLoading.call();
            }

            @Override
            public void onComplete() {

            }
        });
    }

    public void fetchDeviceStepsData(Context mContext, StepHelper mStepHelper) {
        context = mContext;
        stepHelper = mStepHelper;
        isSwipeRefresh.set(false);
        StepServerResponse homeDashboardResponse = TheWellnessCornerApp.getInstance().getStepServerResponse();
        if (homeDashboardResponse != null && homeDashboardResponse.getData() != null
                && homeDashboardResponse.getData().getLastStepSyncDate() != null
                && homeDashboardResponse.getData().getLastStepSyncDate().length() > 0) {

            String connectedDevice = prefHelper.getPrefKeyDeviceConnected();
            if (connectedDevice != null && connectedDevice.length() > 0) {
                String lastStepSyncDate = homeDashboardResponse.getData().getLastStepSyncDate();
                String lastDateInStartOfDay = DateUtils.getInstance().getDateFromMillis(DateUtils.getInstance().getStartTimeOfGivenDay(DateUtils.getInstance().getMillisFromStringDate(lastStepSyncDate, AppConstants.SERVER_DATE_FORMAT_WITH_MILLISECONDS)), AppConstants.SERVER_DATE_FORMAT_WITH_MILLISECONDS);
                String currentDateTime = DateUtils.getInstance().getTodayStartTimeInFormat(AppConstants.SERVER_DATE_FORMAT_WITH_MILLISECONDS);

                long syncDaysDifference = DateUtils.getInstance().getDaysDifferenceStep(lastDateInStartOfDay, currentDateTime, AppConstants.SERVER_DATE_FORMAT_WITH_MILLISECONDS);
                // In case there is difference in negative it means sync date is future date..
                if (syncDaysDifference < 0) {
                } else if (syncDaysDifference == 0) {
                    if (NetworkFactory.getInstance().isNetworkAvailable(context)) {
                        syncTodaySteps();
                    }
                } else {
                    syncMultipleDaysSteps(lastStepSyncDate, currentDateTime);
                }
            }
        } else if (prefHelper.getPrefKeyDeviceConnected().length() > 0) {
            // sync steps from the first step sync date
            if (homeDashboardResponse != null
                    && homeDashboardResponse.getData() != null
                    && homeDashboardResponse.getData().getFirstStepSyncDate() != null) {
                String firstStepSyncDate = DateUtils.getInstance().truncateMilliseconds(homeDashboardResponse.getData().getFirstStepSyncDate());
                String currentDateTime = DateUtils.getInstance().getTodayStartTimeInFormat(AppConstants.SERVER_DATE_FORMAT_WITH_MILLISECONDS);
                syncMultipleDaysSteps(firstStepSyncDate, currentDateTime);

            } else {
                // here we have to sync today steps
                if (NetworkFactory.getInstance().isNetworkAvailable(context)) {
                    syncTodaySteps();
                }
            }
        }
    }

    private void syncTodaySteps() {
        String connectedDeviceType = prefHelper.getPrefKeyDeviceConnected();
        if (connectedDeviceType != null && connectedDeviceType.length() > 0) {
            if (connectedDeviceType.equalsIgnoreCase(AppConstants.FITBIT)) {
                stepHelper.getTodayStepsFromFitbit(new OnTodayStepsFound() {
                    @Override
                    public void onTodayStepsFound(ArrayList<StepItem> foundStepList) {

                        saveTodayStepsToServer(foundStepList.get(0).getStepCount(), foundStepList.get(0).getCalories(), AppConstants.FITBIT);

                    }

                    @Override
                    public void onTodayStepsError(String error) {

                    }
                });
            } else if (connectedDeviceType.equalsIgnoreCase(AppConstants.S_HEALTH)) {
                stepHelper.getTodayStepsFromSamsung(new OnTodayStepsFound() {
                    @Override
                    public void onTodayStepsFound(ArrayList<StepItem> foundStepList) {
                        prefHelper.setPrefKeyDeviceConnected(connectedDeviceType);
                        prefHelper.clearDeviceConnectTokenPreferences();

                        saveTodayStepsToServer((foundStepList.get(0).getStepCount()), foundStepList.get(0).getCalories(), AppConstants.S_HEALTH);


                    }

                    @Override
                    public void onTodayStepsError(String error) {

                    }
                });
            } else if (connectedDeviceType.equalsIgnoreCase(AppConstants.GOOGLE_FIT)) {
                stepHelper.getTodayStepsFromGoogle(new OnTodayStepsFound() {
                    @Override
                    public void onTodayStepsFound(ArrayList<StepItem> foundStepList) {
                        prefHelper.setPrefKeyDeviceConnected(connectedDeviceType);
                        prefHelper.clearDeviceConnectTokenPreferences();
                        saveTodayStepsToServer((foundStepList.get(0).getStepCount()), foundStepList.get(0).getCalories(), AppConstants.GOOGLE_FIT);

                    }

                    @Override
                    public void onTodayStepsError(String error) {

                    }
                });
            } else if (connectedDeviceType.equalsIgnoreCase(AppConstants.E_FIT)) {
                getEFitTodaySteps();
            } else if (connectedDeviceType.equalsIgnoreCase(AppConstants.MISFIT)) {
                stepHelper.getTodayStepsMisfit(new OnTodayStepsFound() {
                    @Override
                    public void onTodayStepsFound(ArrayList<StepItem> foundStepList) {

                        saveTodayStepsToServer((foundStepList.get(0).getStepCount()), foundStepList.get(0).getCalories(), AppConstants.MISFIT);

                    }

                    @Override
                    public void onTodayStepsError(String error) {

                    }
                });
            } else if (connectedDeviceType.equalsIgnoreCase(AppConstants.GARMIN)) {
                //fetchGarminTodayStepsData();
            }
        }
    }

    private void saveTodayStepsToServer(final String steps, final int calories, String connectedDevice) {
        isProgressVisible.set(true);
        String date = DateUtils.getTodayDate(AppConstants.DATE_FORMAT_MM_DD_YYYY_HHMM_FORWARD_SLASH);

        StepsBean stepsBean = new StepsBean();
        stepsBean.setSteps(Integer.parseInt(steps));
        stepsBean.setCalories(calories);
        stepsBean.setStepsDate(date);
        ArrayList<StepsBean> stepsBeanList = new ArrayList<>();
        stepsBeanList.add(stepsBean);

        SaveDeviceStepsBody saveDeviceStepsBody = new SaveDeviceStepsBody();
        saveDeviceStepsBody.setDevice(connectedDevice);
        // saveDeviceStepsBody.setMemberID(Integer.parseInt(WellnessCornerApp.getPreferenceManager().getUserId()));
        saveDeviceStepsBody.setSteps(stepsBeanList);


        repository.saveDeviceSteps(saveDeviceStepsBody).subscribe(new io.reactivex.Observer<SaveStepsResponse>() {
            @Override
            public void onSubscribe(Disposable d) {

            }

            @Override
            public void onNext(SaveStepsResponse response) {
                isProgressVisible.set(false);
                if (context != null) {
                    if (response != null) {
                        if (response.getStatus() == 0) {
                            getTodayTrackerValues(true);

                        }
                    }
                }
            }

            @Override
            public void onError(Throwable e) {
                isProgressVisible.set(false);
            }

            @Override
            public void onComplete() {
                isProgressVisible.set(false);
            }
        });


    }

    private void syncMultipleDaysSteps(String lastStepSyncDate, String currentDateTime) {

        String connectedDeviceType = prefHelper.getPrefKeyDeviceConnected();
        if (connectedDeviceType != null && connectedDeviceType.length() > 0) {
            long startDate = DateUtils.getMillisFromStringDate(lastStepSyncDate, AppConstants.SERVER_DATE_FORMAT_WITH_MILLISECONDS);
            long mStartDate = DateUtils.getStartTimeOfGivenDay(startDate);

            long endDate = DateUtils.getMillisFromStringDate(currentDateTime, AppConstants.SERVER_DATE_FORMAT_WITH_MILLISECONDS);
            long mEndDate = DateUtils.getStartTimeOfGivenDay(endDate);

            if (connectedDeviceType.equalsIgnoreCase(AppConstants.GOOGLE_FIT)) {

                stepHelper.getStepsFromGoogle(mStartDate, mEndDate, new OnRangeStepsFound() {
                    @Override
                    public void onRangeStepsFound(ArrayList<StepItem> foundStepList) {

                        prefHelper.setPrefKeyDeviceConnected(AppConstants.GOOGLE_FIT);
                        prefHelper.clearDeviceConnectTokenPreferences();
                        ArrayList<StepsBean> stepsBeanList = new ArrayList<>();
                        for (StepItem stepItem : foundStepList) {
                            // String date = DateUtils.formatDateStep(AppConstants.DATE_FORMAT_YYYY_MM_DD, AppConstants.DATE_FORMAT_MM_DD_YYYY_HHMM_FORWARD_SLASH, stepItem.getStepTime());
                            StepsBean stepsBean = new StepsBean();
                            stepsBean.setSteps(Integer.parseInt(stepItem.getStepCount()));
                            stepsBean.setStepsDate(stepItem.getStepTime());
                            stepsBean.setCalories(stepItem.getCalories());
                            stepsBean.setActivityDate(stepItem.getStepTime());
                            stepsBeanList.add(stepsBean);
                        }

                        saveStepsToServer(AppConstants.GOOGLE_FIT, stepsBeanList, stepsBeanList);
                    }

                    @Override
                    public void onStepsFoundError(String error) {

                    }
                });
            } else if (connectedDeviceType.equalsIgnoreCase(AppConstants.E_FIT)) {
                getEFitStepsForSync(mStartDate, mEndDate);
            } else if (connectedDeviceType.equalsIgnoreCase(AppConstants.S_HEALTH)) {
                stepHelper.getStepsFromSamsung(mStartDate, mEndDate, new OnRangeStepsFound() {
                    @Override
                    public void onRangeStepsFound(ArrayList<StepItem> foundStepList) {
                        prefHelper.setPrefKeyDeviceConnected(AppConstants.S_HEALTH);
                        prefHelper.clearDeviceConnectTokenPreferences();
                        ArrayList<StepsBean> stepsBeanList = new ArrayList<>();
                        for (StepItem stepItem : foundStepList) {
                            //String date = DateUtils.formatDateStep(AppConstants.DATE_FORMAT_YYYY_MM_DD, AppConstants.DATE_FORMAT_MM_DD_YYYY_HHMM_FORWARD_SLASH, stepItem.getStepTime());
                            StepsBean stepsBean = new StepsBean();
                            stepsBean.setSteps(Integer.parseInt(stepItem.getStepCount()));
                            stepsBean.setStepsDate(stepItem.getStepTime());
                            stepsBean.setCalories(stepItem.getCalories());
                            stepsBean.setActivityDate(stepItem.getStepTime());
                            stepsBeanList.add(stepsBean);
                        }

                        saveStepsToServer(AppConstants.S_HEALTH, stepsBeanList, stepsBeanList);
                    }

                    @Override
                    public void onStepsFoundError(String error) {

                    }
                });
            } else if (connectedDeviceType.equalsIgnoreCase(AppConstants.FITBIT)) {
                stepHelper.getStepsFromFitbit(mStartDate, mEndDate, new OnRangeStepsFound() {
                    @Override
                    public void onRangeStepsFound(ArrayList<StepItem> foundStepList) {
                        final ArrayList<StepsBean> stepsBeanList = new ArrayList<>();
                        for (StepItem stepItem : foundStepList) {
                            StepsBean stepsBean = new StepsBean();
                            stepsBean.setCalories(stepItem.getCalories());
                            stepsBean.setSteps(Integer.parseInt(stepItem.getStepCount()));

                            //String date = DateUtils.formatDateStep(AppConstants.DATE_FORMAT_MM_DD_YYYY_HHMM_FORWARD_SLASH, AppConstants.DATE_FORMAT_MM_DD_YYYY_HHMM_FORWARD_SLASH, stepItem.getStepTime());
                            stepsBean.setStepsDate(stepItem.getStepTime());
                            stepsBean.setActivityDate(stepItem.getStepTime());
                            stepsBeanList.add(stepsBean);
                        }


                        saveStepsToServer(AppConstants.FITBIT, stepsBeanList, stepsBeanList);
                    }

                    @Override
                    public void onStepsFoundError(String error) {

                    }
                });

            } else if (connectedDeviceType.equalsIgnoreCase(AppConstants.MISFIT)) {

                stepHelper.getStepsFromMisfit(mStartDate, mEndDate, new OnRangeStepsFound() {
                    @Override
                    public void onRangeStepsFound(ArrayList<StepItem> foundStepList) {

                        final ArrayList<StepsBean> stepsBeanList = new ArrayList<>();
                        for (StepItem stepItem : foundStepList) {
                            StepsBean stepsBean = new StepsBean();
                            stepsBean.setCalories(stepItem.getCalories());
                            stepsBean.setSteps(Integer.parseInt(stepItem.getStepCount()));

                            //String date = DateUtils.formatDateStep(AppConstants.DATE_FORMAT_YYYY_MM_DD, AppConstants.DATE_FORMAT_MM_DD_YYYY_HHMM_FORWARD_SLASH, stepItem.getStepTime());
                            stepsBean.setStepsDate(stepItem.getStepTime());
                            stepsBean.setActivityDate(stepItem.getStepTime());
                            stepsBeanList.add(stepsBean);
                        }


                        saveStepsToServer(AppConstants.MISFIT, stepsBeanList, stepsBeanList);

                    }

                    @Override
                    public void onStepsFoundError(String error) {

                    }
                });

            } else if (connectedDeviceType.equalsIgnoreCase(AppConstants.GARMIN)) {
                // long startTime = DateFactory.getInstance().getEpochFromStringDate(DateFactory.getInstance().formatDate(Constant.SERVER_DATE_FORMAT_WITH_MILLISECONDS, "yyyy-MM-dd HH:mm:ss.SSS zzz", lastStepSyncDate), "yyyy-MM-dd HH:mm:ss.SSS zzz") / 1000L;
                // fetchGarminStepsData(startTime);
            }
        }
    }

    private void saveStepsToServer(String connectedDevice, ArrayList<StepsBean> stepsBeanList, ArrayList<StepsBean> caloriesBeanList) {
        isProgressVisible.set(true);
        SaveDeviceStepsBody saveDeviceStepsBody = new SaveDeviceStepsBody();
        saveDeviceStepsBody.setDevice(connectedDevice);
        //saveDeviceStepsBody.setMemberID(Integer.parseInt(WellnessCornerApp.getPreferenceManager().getUserId()));
        saveDeviceStepsBody.setSteps(stepsBeanList);
        if (caloriesBeanList != null && caloriesBeanList.size() > 0)
            saveDeviceStepsBody.setCalories(caloriesBeanList);

        repository.saveDeviceSteps(saveDeviceStepsBody).subscribe(new io.reactivex.Observer<SaveStepsResponse>() {
            @Override
            public void onSubscribe(Disposable d) {

            }

            @Override
            public void onNext(SaveStepsResponse response) {
                isProgressVisible.set(false);
                if (context != null) {
                    if (response != null) {
                        if (response.getStatus() == 0) {
                            if (TheWellnessCornerApp.getInstance().getStepServerResponse() != null
                                    && TheWellnessCornerApp.getInstance().getStepServerResponse().getData() != null) {
                                TheWellnessCornerApp.getInstance().getStepServerResponse().getData().setLastConnectedDevice(response.getLastConnectedDevice());
                                TheWellnessCornerApp.getInstance().getStepServerResponse().getData().setLastStepSyncDate(response.getLastStepsTrackerDate());
                            }
                            syncTodaySteps();
                        }
                    }
                }
            }

            @Override
            public void onError(Throwable e) {
                isProgressVisible.set(false);
            }

            @Override
            public void onComplete() {
                isProgressVisible.set(false);
            }
        });


    }

    private void getEFitTodaySteps() {
        String fromDateEFit = DateUtils.getInstance().getTodayDate("yyyy MM dd");
        String toDateEFit = DateUtils.getInstance().getTodayDate("yyyy MM dd");
        EFitMonthStepsBody eFitMonthStepsBody = new EFitMonthStepsBody();
        eFitMonthStepsBody.setMemberId(prefHelper.getEFitUserId());
        eFitMonthStepsBody.setStartDate(fromDateEFit);
        eFitMonthStepsBody.setEndDate(toDateEFit);

        FitBitRestClient restClient = new FitBitRestClient("EFit", "", context, FitBitConfig.E_FIT_BASE_URL, false);
        restClient.getFitBitStepsService().getEFitMonthSteps(eFitMonthStepsBody).enqueue(new Callback<EFitMonthStepsResponse>() {
            @SuppressWarnings("StatementWithEmptyBody")
            @Override
            public void onResponse(Call<EFitMonthStepsResponse> call, Response<EFitMonthStepsResponse> response) {
                if (context != null) {

                    if (response != null) {
                        EFitMonthStepsResponse eFitMonthStepsResponse = response.body();
                        if (eFitMonthStepsResponse != null) {
                            if (eFitMonthStepsResponse.getSuccess().equalsIgnoreCase("1")) {
                                List<FitBitStepsItem> stepsItemList = eFitMonthStepsResponse.getStepsData();
                                if (stepsItemList != null && stepsItemList.size() > 0) {
                                    saveTodayStepsToServer(stepsItemList.get(0).getValue(), (int) stepsItemList.get(0).getCalory(), AppConstants.E_FIT);

                                } else {
                                }
                            } else if (eFitMonthStepsResponse.getSuccess().equalsIgnoreCase("2")) {
                                // no steps available
                                saveTodayStepsToServer("0", 0, AppConstants.E_FIT);


                            } else {
                                CommonUtils.showAlertDialog(context, context.getString(R.string.app_name), 0, context.getString(R.string.msg_api_response_failure), context.getString(R.string.str_ok), false);
                            }
                        } else {
                            CommonUtils.showAlertDialog(context, context.getString(R.string.app_name), 0, context.getString(R.string.msg_api_response_null), context.getString(R.string.str_ok), false);
                        }
                    } else {
                        CommonUtils.showAlertDialog(context, context.getString(R.string.app_name), 0, context.getString(R.string.msg_api_response_null), context.getString(R.string.str_ok), false);
                    }
                }
            }

            @Override
            public void onFailure(Call<EFitMonthStepsResponse> call, Throwable t) {
                if (context != null) {

                    CommonUtils.showAlertDialog(context, context.getString(R.string.app_name), 0, context.getString(R.string.msg_api_failure), context.getString(R.string.str_ok), false);
                }
            }
        });
    }

    private void getEFitStepsForSync(long startDate, long endDate) {
        String fromDateEFit = DateUtils.getInstance().getDateFromMillis(startDate, AppConstants.DATE_FORMAT_YYYY_MM_DD);
        String toDateEFit = DateUtils.getInstance().getDateFromMillis(endDate, AppConstants.DATE_FORMAT_YYYY_MM_DD);

        EFitMonthStepsBody eFitMonthStepsBody = new EFitMonthStepsBody();
        eFitMonthStepsBody.setMemberId(prefHelper.getEFitUserId());
        eFitMonthStepsBody.setStartDate(fromDateEFit);
        eFitMonthStepsBody.setEndDate(toDateEFit);

        FitBitRestClient restClient = new FitBitRestClient("EFit", "", context, FitBitConfig.E_FIT_BASE_URL, false);
        restClient.getFitBitStepsService().getEFitMonthSteps(eFitMonthStepsBody).enqueue(new Callback<EFitMonthStepsResponse>() {
            @SuppressWarnings("StatementWithEmptyBody")
            @Override
            public void onResponse(Call<EFitMonthStepsResponse> call, Response<EFitMonthStepsResponse> response) {
                if (context != null) {

                    if (response != null) {
                        EFitMonthStepsResponse eFitMonthStepsResponse = response.body();
                        if (eFitMonthStepsResponse != null) {
                            if (eFitMonthStepsResponse.getSuccess().equalsIgnoreCase("1")) {
                                List<FitBitStepsItem> stepsItemList = eFitMonthStepsResponse.getStepsData();
                                if (stepsItemList != null && stepsItemList.size() > 0) {

                                    HashMap<String, FitBitStepsItem> hashMap = new HashMap<>();
                                    Calendar fromCalendar = Calendar.getInstance();
                                    fromCalendar.setTimeInMillis(startDate);

                                    Calendar toCalendar = Calendar.getInstance();
                                    toCalendar.setTimeInMillis(endDate);
                                    String dateFromMillis = DateUtils.getInstance().getDateFromMillis(startDate, AppConstants.DATE_FORMAT_YYYY_MM_DD);
                                    System.out.println("steps dateFromMillis====" + dateFromMillis);
                                    FitBitStepsItem stepItemEmpty = new FitBitStepsItem();
                                    stepItemEmpty.setDateTime(dateFromMillis);
                                    stepItemEmpty.setCalory(0);
                                    stepItemEmpty.setValue("0");
                                    hashMap.put(dateFromMillis, stepItemEmpty);

                                    String dateToMillis = DateUtils.getInstance().getDateFromMillis(endDate, AppConstants.DATE_FORMAT_YYYY_MM_DD);
                                    System.out.println("steps dateToMillis====" + dateToMillis);
                                    stepItemEmpty = new FitBitStepsItem();
                                    stepItemEmpty.setDateTime(dateToMillis);
                                    stepItemEmpty.setCalory(0);
                                    stepItemEmpty.setValue("0");
                                    hashMap.put(dateToMillis, stepItemEmpty);

                                    if (!dateFromMillis.equalsIgnoreCase(dateToMillis)) {
                                        while (!dateFromMillis.equalsIgnoreCase(dateToMillis)) {
                                            fromCalendar.add(Calendar.DATE, 1);
                                            String dateMillis = DateUtils.getInstance().getDateFromMillis(fromCalendar.getTimeInMillis(), AppConstants.DATE_FORMAT_YYYY_MM_DD);
                                            dateFromMillis = dateMillis;
                                            stepItemEmpty = new FitBitStepsItem();
                                            stepItemEmpty.setDateTime(dateMillis);
                                            stepItemEmpty.setCalory(0);
                                            stepItemEmpty.setValue("0");
                                            System.out.println("steps dateMillis====" + dateMillis);
                                            hashMap.put(dateMillis, stepItemEmpty);
                                        }
                                    }
                                    for (FitBitStepsItem fitBitStepsItem : stepsItemList) {
                                        hashMap.put(fitBitStepsItem.getDateTime(), fitBitStepsItem);
                                    }

                                    ArrayList<StepsBean> stepsBeanList = new ArrayList<>();

                                    for (Map.Entry<String, FitBitStepsItem> entry : hashMap.entrySet()) {
                                        String key = entry.getKey();
                                        FitBitStepsItem fitBitStepsItem = entry.getValue();

                                        String date = DateUtils.getInstance().formatDateStep(AppConstants.DATE_FORMAT_YYYY_MM_DD, AppConstants.DATE_FORMAT_MM_DD_YYYY_HHMM_FORWARD_SLASH, fitBitStepsItem.getDateTime());
                                        String steps = fitBitStepsItem.getValue();
                                        StepsBean stepsBean = new StepsBean();
                                        stepsBean.setSteps(Integer.parseInt(steps));
                                        stepsBean.setStepsDate(date);
                                        stepsBean.setActivityDate(date);
                                        stepsBean.setCalories((int) fitBitStepsItem.getCalory());
                                        stepsBeanList.add(stepsBean);

                                    }
                                    // As discussed with Rohit  and Testing Team zeros won't be included at the time of showing data
                                    // Steps will be shown as it is. 1/7/2017
                                    // ArrayList<StepsBean> stepListToSync = addAbsentDayWithZeroSteps(stepsBeanList, finalLastSyncedMillis);
                                    saveStepsToServer(AppConstants.E_FIT, stepsBeanList, stepsBeanList);
                                }

                            } else if (eFitMonthStepsResponse.getSuccess().equalsIgnoreCase("2")) {
                                // no steps available
                                HashMap<String, FitBitStepsItem> hashMap = new HashMap<>();
                                Calendar fromCalendar = Calendar.getInstance();
                                fromCalendar.setTimeInMillis(startDate);

                                Calendar toCalendar = Calendar.getInstance();
                                toCalendar.setTimeInMillis(endDate);
                                String dateFromMillis = DateUtils.getInstance().getDateFromMillis(startDate, AppConstants.DATE_FORMAT_YYYY_MM_DD);
                                System.out.println("steps dateFromMillis====" + dateFromMillis);
                                FitBitStepsItem stepItemEmpty = new FitBitStepsItem();
                                stepItemEmpty.setDateTime(dateFromMillis);
                                stepItemEmpty.setCalory(0);
                                stepItemEmpty.setValue("0");
                                hashMap.put(dateFromMillis, stepItemEmpty);

                                String dateToMillis = DateUtils.getInstance().getDateFromMillis(endDate, AppConstants.DATE_FORMAT_YYYY_MM_DD);
                                System.out.println("steps dateToMillis====" + dateToMillis);
                                stepItemEmpty = new FitBitStepsItem();
                                stepItemEmpty.setDateTime(dateToMillis);
                                stepItemEmpty.setCalory(0);
                                stepItemEmpty.setValue("0");
                                hashMap.put(dateToMillis, stepItemEmpty);

                                if (!dateFromMillis.equalsIgnoreCase(dateToMillis)) {
                                    while (!dateFromMillis.equalsIgnoreCase(dateToMillis)) {
                                        fromCalendar.add(Calendar.DATE, 1);
                                        String dateMillis = DateUtils.getInstance().getDateFromMillis(fromCalendar.getTimeInMillis(), AppConstants.DATE_FORMAT_YYYY_MM_DD);
                                        dateFromMillis = dateMillis;
                                        stepItemEmpty = new FitBitStepsItem();
                                        stepItemEmpty.setDateTime(dateMillis);
                                        stepItemEmpty.setCalory(0);
                                        stepItemEmpty.setValue("0");
                                        System.out.println("steps dateMillis====" + dateMillis);
                                        hashMap.put(dateMillis, stepItemEmpty);
                                    }
                                }
                                ArrayList<StepsBean> stepsBeanList = new ArrayList<>();

                                for (Map.Entry<String, FitBitStepsItem> entry : hashMap.entrySet()) {
                                    String key = entry.getKey();
                                    FitBitStepsItem fitBitStepsItem = entry.getValue();

                                    String date = DateUtils.getInstance().formatDateStep(AppConstants.DATE_FORMAT_YYYY_MM_DD, AppConstants.DATE_FORMAT_MM_DD_YYYY_HHMM_FORWARD_SLASH, fitBitStepsItem.getDateTime());
                                    String steps = fitBitStepsItem.getValue();
                                    StepsBean stepsBean = new StepsBean();
                                    stepsBean.setSteps(Integer.parseInt(steps));
                                    stepsBean.setStepsDate(date);
                                    stepsBean.setActivityDate(date);
                                    stepsBean.setCalories((int) fitBitStepsItem.getCalory());
                                    stepsBeanList.add(stepsBean);

                                }
                                saveStepsToServer(AppConstants.E_FIT, stepsBeanList, stepsBeanList);
                            } else {
                                Utils.showToast((Activity) context, "An error occurred while syncing your steps to server. Please try to connect your device again.");
                            }
                        } else {
                            Utils.showToast((Activity) context, "An error occurred while syncing your steps to server. Please try to connect your device again.");
                        }
                    } else {
                        Utils.showToast((Activity) context, "An error occurred while syncing your steps to server. Please try to connect your device again.");
                    }
                }
            }

            @Override
            public void onFailure(Call<EFitMonthStepsResponse> call, Throwable t) {
                if (context != null) {

                    Utils.showToast((Activity) context, "An error occurred while syncing your steps to server. Please try to connect your device again.");
                    CommonUtils.showAlertDialog(context, null, 0, context.getString(R.string.msg_api_failure), context.getString(R.string.str_ok), true);
                }
            }
        });
    }

    public void upArrowClick() {
        upArrow.call();
    }

    public void isRefresh(boolean isShowLoading) {
        if (isShowLoading)
            isProgressVisible.set(false);
        else
            isProgressVisible.set(true);
    }


}
