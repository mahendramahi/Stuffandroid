package com.truworth.wellnesscorner.repo.model.response;

import com.truworth.wellnesscorner.model.ShareDashboardBean;

public class ShareDashboardResponse {


    private ShareDashboardBean data;
    private boolean hasError;
    private Error error;

    public ShareDashboardBean getData() {
        return data;
    }

    public void setData(ShareDashboardBean data) {
        this.data = data;
    }

    public boolean isHasError() {
        return hasError;
    }

    public void setHasError(boolean hasError) {
        this.hasError = hasError;
    }

    public Error getError() {
        return error;
    }

    public void setError(Error error) {
        this.error = error;
    }

}
