package com.truworth.wellnesscorner.customviews;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.HorizontalScrollView;

public class WeightHorizontalScrollView extends HorizontalScrollView {

    private OnScrollViewListener mOnScrollViewListener;

    public WeightHorizontalScrollView(Context context) {
        super(context);
    }

    public WeightHorizontalScrollView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public WeightHorizontalScrollView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
    }

    public void setOnScrollViewListener(OnScrollViewListener l) {
        this.mOnScrollViewListener = l;
    }

    protected void onScrollChanged(int l, int t, int oldl, int oldt) {
        if (mOnScrollViewListener != null) {
            mOnScrollViewListener.onScrollChanged(this, l, t, oldl, oldt);
        }
        super.onScrollChanged(l, t, oldl, oldt);
    }

    public interface OnScrollViewListener {
        void onScrollChanged(WeightHorizontalScrollView v, int l, int t, int oldl, int oldt);
    }

}
