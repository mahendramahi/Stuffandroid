package com.truworth.wellnesscorner.model;

/**
 * Created by ameen on 30/11/17.
 * Happy Coding
 */

public class TagPerson {


    String postTagName;
    int postTagType;
    String postTagTypeName;
    String postTagMapIdentity;


    public String getFormattedValue() {
        return "@[" + postTagName + "](" + postTagMapIdentity + ")";
    }

    public TagPerson() {
    }

    public String getPostTagName() {
        return postTagName;
    }

    public void setPostTagName(String postTagName) {
        this.postTagName = postTagName;
    }

    public int getPostTagType() {
        return postTagType;
    }

    public void setPostTagType(int postTagType) {
        this.postTagType = postTagType;
    }

    public String getPostTagTypeName() {
        return postTagTypeName;
    }

    public void setPostTagTypeName(String postTagTypeName) {
        this.postTagTypeName = postTagTypeName;
    }

    public String getPostTagMapIdentity() {
        return postTagMapIdentity;
    }

    public void setPostTagMapIdentity(String postTagMapIdentity) {
        this.postTagMapIdentity = postTagMapIdentity;
    }

    @Override
    public String toString() {
        return postTagName;
    }
}
