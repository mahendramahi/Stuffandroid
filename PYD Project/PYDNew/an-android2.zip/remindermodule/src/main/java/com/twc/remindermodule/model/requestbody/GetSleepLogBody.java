package com.twc.remindermodule.model.requestbody;

/**
 * Created by PalakC on 1/19/2018.
 */

public class GetSleepLogBody {
    private String MemberID;
    private String PageIndex;
    private String PageSize;

    public String getMemberID() {
        return MemberID;
    }

    public void setMemberID(String MemberID) {
        this.MemberID = MemberID;
    }

    public String getPageIndex() {
        return PageIndex;
    }

    public void setPageIndex(String PageIndex) {
        this.PageIndex = PageIndex;
    }

    public String getPageSize() {
        return PageSize;
    }

    public void setPageSize(String PageSize) {
        this.PageSize = PageSize;
    }
}
