package com.truworth.wellnesscorner.ui.mainapp.createpost.sharedashboard;

import android.databinding.ObservableBoolean;
import android.databinding.ObservableDouble;
import android.databinding.ObservableField;
import android.text.SpannableStringBuilder;
import com.truworth.wellnesscorner.TheWellnessCornerApp;
import com.truworth.wellnesscorner.base.BaseViewModel;
import com.truworth.wellnesscorner.repo.DashboardRepository;
import com.truworth.wellnesscorner.repo.model.request.ShareDashboardRequest;
import com.truworth.wellnesscorner.repo.model.response.ShareDashboardResponse;
import com.truworth.wellnesscorner.utils.DateUtils;
import com.truworth.wellnesscorner.utils.SingleLiveEvent;
import com.truworth.wellnesscorner.utils.Utils;

import javax.inject.Inject;

import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;

public class ShareDashboardViewModel extends BaseViewModel {

    public ObservableField<String> memberName = new ObservableField<>();
    public ObservableField<String> memberImageUrl = new ObservableField<>();
    public ObservableField<String> date = new ObservableField<>();
    public ObservableField<SpannableStringBuilder> stepCount = new ObservableField<>();
    public ObservableField<SpannableStringBuilder> glassCount = new ObservableField<>();
    public ObservableField<SpannableStringBuilder> calorieBurned = new ObservableField<>();
    public ObservableField<SpannableStringBuilder> calorieConsumed = new ObservableField<>();
    public ObservableDouble stepsProgress = new ObservableDouble();
    public ObservableDouble calorieConsumedProgress = new ObservableDouble();
    public ObservableDouble calorieBurnedProgress = new ObservableDouble();
    public ObservableDouble glassProgress = new ObservableDouble();
    SingleLiveEvent<Void> shareBtnClick = new SingleLiveEvent<>();
    public SingleLiveEvent<Void> getShareBtnClick() {
        return shareBtnClick;
    }
    public SingleLiveEvent<Void> getHasDataLoaded() {
        return hasDataLoaded;
    }

    public ObservableBoolean isDataLoaded = new ObservableBoolean();

    SingleLiveEvent<Void> hasDataLoaded = new SingleLiveEvent<>();

    SingleLiveEvent<String> themeColorChange = new SingleLiveEvent<>();

    public SingleLiveEvent<String> getThemeColorChange() {
        return themeColorChange;
    }

    @Inject
    DashboardRepository dashboardRepository;

    public ShareDashboardViewModel() {
        TheWellnessCornerApp.getApp().component().inject(this);
    }

    public void loadDashboardPost() {
        setIsLoading(true);
        ShareDashboardRequest shareDashboardRequest = new ShareDashboardRequest();
        shareDashboardRequest.setDeviceDate(DateUtils.getTodayDate("yyyy-MM-dd"));

        dashboardRepository.getPostDashboard(shareDashboardRequest).subscribe(new Observer<ShareDashboardResponse>() {
            @Override
            public void onSubscribe(Disposable d) {

            }

            @Override
            public void onNext(ShareDashboardResponse response) {
                setIsLoading(false);
                if (!response.isHasError()) {
                    if(response.getData().getMemberName()!=null)
                     memberName.set(response.getData().getMemberName()+ "'s Stats");

                    memberImageUrl.set(response.getData().getMemberImage());
                    date.set(DateUtils.formatDate(response.getData().getDate(), DateUtils.SERVER_DATE, "MMMM dd, yyyy"));

                    String steps = Utils.roundOffDouble(response.getData().getSteps());
                    String glasses = Utils.roundOffDouble(response.getData().getGlasses());
                    String calsConsumed = Utils.roundOffDouble(response.getData().getCalsConsumed());
                    String calsBurned = Utils.roundOffDouble(response.getData().getCalsBurned());

                    stepCount.set(Utils.makeSpecificTextSize(steps +" steps \n  ", steps,1.5f));
                    glassCount.set(Utils.makeSpecificTextSize(glasses +" glasses \n water", glasses,1.5f));
                    calorieConsumed.set(Utils.makeSpecificTextSize(calsConsumed +" cals \n consumed", calsConsumed,1.5f));
                    calorieBurned.set(Utils.makeSpecificTextSize(calsBurned +" cals \n burned", calsBurned,1.5f));

                    stepsProgress.set((int) response.getData().getStepsCompliance());
                    calorieConsumedProgress.set((int) response.getData().getCalsConsumedCompliance());
                    calorieBurnedProgress.set((int)response.getData().getCalsBurnedCompliance());
                    glassProgress.set((int)response.getData().getGlassesCompliance());
                    hasDataLoaded.call();
                    isDataLoaded.set(true);
                }
            }

            @Override
            public void onError(Throwable e) {
                e.printStackTrace();
                setIsLoading(false);
                isDataLoaded.set(false);
            }

            @Override
            public void onComplete() {
                setIsLoading(false);
            }
        });
    }
    public void onShareClicked() {
        shareBtnClick.call();
    }
    public void changeTheme(String color) {
        themeColorChange.setValue(color);
    }

    public int getIntFromDouble (Double progress){
        int progressInt=0;
        if(progress!=null)
            progressInt = Integer.valueOf(progress.intValue());

        return progressInt;
    }
}
