package com.twc.store.model.response;


import com.twc.store.model.beans.DataSaveCartItem;

/**
 * Created by PalakC on 9/18/2017.
 */

public class StoreSaveCartResponse {


    private int status;
    private DataSaveCartItem Data;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public DataSaveCartItem getData() {
        return Data;
    }

    public void setData(DataSaveCartItem Data) {
        this.Data = Data;
    }


}
