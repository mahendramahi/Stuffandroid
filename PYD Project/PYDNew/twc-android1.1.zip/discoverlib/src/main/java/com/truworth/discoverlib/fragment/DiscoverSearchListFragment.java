package com.truworth.discoverlib.fragment;

import android.os.Bundle;
import android.os.Handler;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ProgressBar;

import com.truworth.discoverlib.DiscoverActivity;
import com.truworth.discoverlib.R;
import com.truworth.discoverlib.R2;
import com.truworth.discoverlib.adapter.DiscoverSearchListAdapter;
import com.truworth.discoverlib.interfaces.OnDiscoverSearchContentChangeListener;
import com.truworth.discoverlib.model.SearchDiscoverByKeywordBody;
import com.truworth.discoverlib.model.SearchDiscoverByKeywordResponse;
import com.truworth.discoverlib.model.SearchDiscoverByKeywordResponse.DiscoverSearchBean;
import com.truworth.discoverlib.rest.RestClient;
import com.truworth.discoverlib.utils.Constant;
import com.truworth.discoverlib.utils.DialogFactory;
import com.truworth.discoverlib.utils.DiscoverConfig;
import com.truworth.discoverlib.utils.NetworkFactory;
import com.truworth.discoverlib.utils.NoDataView;
import com.truworth.discoverlib.utils.Utils;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * If this code works it was written by Somesh Kumar on 08 August, 2016. If not, I don't know who wrote it.
 */
public class DiscoverSearchListFragment extends BaseFragment implements OnDiscoverSearchContentChangeListener {

    @BindView(R2.id.rvDiscoverList)
    RecyclerView rvDiscoverList;
    @BindView(R2.id.progressBar)
    ProgressBar progressBar;

    @BindView(R2.id.rootView)
    View rootView;

    @BindView((R2.id.noDataView))
    NoDataView noDataView;

    private DiscoverSearchListAdapter mDiscoverSearchListAdapter;
    private List<DiscoverSearchBean> mArticleList;
    private String mLastQuery = "";
    // Variables for Pagination
    /*private boolean mIsLastResult = false;
    private int lastVisibleItem, totalItemCount;
    private int visibleThreshold = 5;
    private boolean loading;
    private OnLoadMoreListener onLoadMoreListener;*/

    public static DiscoverSearchListFragment newInstance() {
        return new DiscoverSearchListFragment();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mArticleList = new ArrayList<>();
    }

    @Override
    public int getFragmentLayout() {
        return R.layout.fragment_discover_list;
    }

    @Override
    public void onFragmentReady() {
        final LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getActivity());
        rvDiscoverList.setLayoutManager(linearLayoutManager);
        rvDiscoverList.setHasFixedSize(true);
        progressBar.setVisibility(View.GONE);

        /*If adapter is NULL then we call API otherwise we set previous data*/
        if (mDiscoverSearchListAdapter != null) {
            rvDiscoverList.setAdapter(mDiscoverSearchListAdapter);
            mDiscoverSearchListAdapter.notifyDataSetChanged();
        } else {
            //  llNoRecentData.setVisibility(View.VISIBLE);
            mDiscoverSearchListAdapter = new DiscoverSearchListAdapter(mArticleList, getActivity());
            rvDiscoverList.setAdapter(mDiscoverSearchListAdapter);
        }

    }


    @Override
    public void onDiscoverSearchContentChange(final String query, final boolean isUserSubmitted) {
        final String articleSearchType = ((DiscoverSearchFragment) getParentFragment()).getArticleTypeForAPI();
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                /*if user submitted the query and query in not blank when user swipe through screen then we load data*/
                if (isUserSubmitted && !query.equalsIgnoreCase(""))
                    /*if query is not same as previous one only then we load data..*/ {
                    if (!mLastQuery.equalsIgnoreCase(query)) {
                        searchDiscoverByKeywordAPI(query, articleSearchType);
                    }
                }
            }
        }, Constant.API_POST_DELAYED_TIME);
    }


    /**
     * API call method for searching Discover (Articles, Challenges,Programs,Sideshows) on server
     *
     * @param query             Keyword to search
     * @param articleSearchType Type ( Article/Sideshows/.. etc)
     */
    private void searchDiscoverByKeywordAPI(final String query, String articleSearchType) {
        if (NetworkFactory.getInstance().isNetworkAvailable(getActivity())) {
            setProgressTextVisibility(true, false);
            this.mLastQuery = query;
            /*If searching is for first time then remove all the previous result show to user*/
            //noinspection CollectionAddedToSelf
            mArticleList.removeAll(mArticleList);
            mDiscoverSearchListAdapter.notifyDataSetChanged();

            SearchDiscoverByKeywordBody discoverByKeywordBody = new SearchDiscoverByKeywordBody();
            discoverByKeywordBody.setMemberID(Integer.parseInt(DiscoverConfig.discoverUser.getUserID()));
            discoverByKeywordBody.setKeyword(query);
            discoverByKeywordBody.setPageIndex(1);
            discoverByKeywordBody.setType(articleSearchType);
            RestClient restClient = new RestClient(getActivity(), DiscoverConfig.BASE_URL, DiscoverConfig.DEBUG);
            restClient.getDiscoverService().getDiscoverSearchByKeyword(discoverByKeywordBody).enqueue(new Callback<SearchDiscoverByKeywordResponse>() {
                @Override
                public void onResponse(Call<SearchDiscoverByKeywordResponse> call, Response<SearchDiscoverByKeywordResponse> response) {
                    //check if there is a progressbar at the end of the list
                    //   removeProgressLoading();
                    //loading = false;
                    if (isAdded() && getActivity() != null) {
                        Utils.hideSoftKeyboard(getActivity());
                        if (response != null && response.body() != null) {
                            if (response.body().getStatus() == 0) {
                                setProgressTextVisibility(false, false);
                                int lastPosition = mArticleList.size() - 1;
                                mArticleList.addAll(response.body().getData());
                                mDiscoverSearchListAdapter.notifyDataSetChanged();
                                rvDiscoverList.smoothScrollToPosition(lastPosition + 1);
                            }
                            // Return -2 when we have 0 result for the given article type
                            else if (response.body().getStatus() == -2) {
                                mDiscoverSearchListAdapter.notifyDataSetChanged();
                                // make mIsLastResult true so we don't call api if there is no data available for given result
                                //  mIsLastResult = true;
                            }

                        } else {
                            setProgressTextVisibility(false, false);
                            DialogFactory.getInstance().showAlertDialog(getActivity(), null, 0, getString(R.string.msg_api_response_failure), getString(R.string.str_ok), true);
                            //   Toast.makeText(getActivity(), getString(R.string.msg_api_response_failure), Toast.LENGTH_SHORT).show();
                        }

                        if (mArticleList.size() == 0) {
                            setProgressTextVisibility(false, true);  //If size is 0 then we show No data text
                        }
                    }
                }

                @Override
                public void onFailure(Call<SearchDiscoverByKeywordResponse> call, Throwable t) {
                    if (isAdded() && getActivity() != null) {
                        Utils.hideSoftKeyboard(getActivity());
                        DialogFactory.getInstance().showAlertDialog(getActivity(), null, 0, getString(R.string.msg_api_failure), getString(R.string.str_ok), true);
                        // Toast.makeText(getActivity(), getString(R.string.msg_api_failure), Toast.LENGTH_SHORT).show();
                        setProgressTextVisibility(false, true);
                        // removeProgressLoading();
                    }
                }
            });
        } else {
            setProgressTextVisibility(false, false);
            // removeProgressLoading();
            Utils.showSnackBarMessage(rootView, getString(R.string.internet_not_available));
        }
    }

    private void setProgressTextVisibility(boolean progressVisibility, boolean noDataVisibility) {
        progressBar.setVisibility(progressVisibility ? View.VISIBLE : View.GONE);
        //llNoRecentData.setVisibility(noDataVisibility ? View.VISIBLE : View.GONE);
        noDataView.setVisibility(noDataVisibility ? View.VISIBLE : View.GONE);
    }

    @SuppressWarnings("unused")
    private void removeProgressLoading() {
        if (mArticleList.size() > 0 && mArticleList.get(mArticleList.size() - 1) == null) {
            mArticleList.remove(mArticleList.size() - 1);
            mDiscoverSearchListAdapter.notifyDataSetChanged();
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        ((DiscoverActivity) getActivity()).showHomeAsUpEnableToolbar();
    }
}
