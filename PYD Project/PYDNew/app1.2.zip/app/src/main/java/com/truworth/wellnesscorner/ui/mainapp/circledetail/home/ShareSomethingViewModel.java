package com.truworth.wellnesscorner.ui.mainapp.circledetail.home;

import android.app.Activity;
import android.content.Intent;
import android.databinding.ObservableField;
import android.view.View;

import com.truworth.wellnesscorner.base.BaseViewModel;
import com.truworth.wellnesscorner.ui.mainapp.createpost.CreatePostActivity;
import com.truworth.wellnesscorner.ui.mainapp.post.postcomment.PostCommentActivity;

public class ShareSomethingViewModel extends BaseViewModel {
    public ObservableField<String> getUserName() {
        return userName;
    }

    public ObservableField<String> userName = new ObservableField<>();

    public ObservableField<String> getUserImageUrl() {
        return userImageUrl;
    }

    public void setUserImageUrl(ObservableField<String> userImageUrl) {
        this.userImageUrl = userImageUrl;
    }

    public ObservableField<String> userImageUrl = new ObservableField<>();

    private String circleIdentity,circleName;

    public void setNavigation(View view) {
        CreatePostActivity.start(((Activity) view.getContext()), circleName, circleIdentity, false,null);
    }

    public void getCircleId(String circleIdentity,String circleName) {
        this.circleIdentity=circleIdentity;
        this.circleName=circleName;
    }
}
