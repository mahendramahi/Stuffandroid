package com.truworth.wellnesscorner.ui.registration.registrationstepfirst;

import android.app.DatePickerDialog;
import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.View;
import android.view.WindowManager;
import android.widget.DatePicker;
import android.widget.TextView;
import android.widget.Toast;

import com.truworth.wellnesscorner.BR;
import com.truworth.wellnesscorner.R;
import com.truworth.wellnesscorner.base.BaseFragment;
import com.truworth.wellnesscorner.databinding.FragmentRegistration1Binding;
import com.truworth.wellnesscorner.repo.model.request.SaveMemberRequest;
import com.truworth.wellnesscorner.utils.CommonUtils;
import com.truworth.wellnesscorner.utils.DateUtils;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;


/**
 * If this code works, it was written by Somesh Kumar  on 03 April, 2018. If not, I don't know who wrote it.
 */
public class RegistrationPersonalFragment extends BaseFragment<FragmentRegistration1Binding, RegistrationPersonalViewModel> {
    public static final String TAG = "RegistrationPersonalFra";
    private static final String ARG_PARAM1 = "param1";
    String emailID;
    TextView tvMale;
    TextView tvFemale;
    private FragmentRegistration1Binding fragmentRegistration1Binding;
    private RegistrationPersonalViewModel viewModel;

    public static Fragment newInstance(String email) {

        RegistrationPersonalFragment fragment = new RegistrationPersonalFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, email);
        fragment.setArguments(args);
        return fragment;
    }

    /**
     * Override for set binding variable
     *
     * @return variable id
     */
    @Override
    public int getBindingVariable() {
        return BR.registrationViewModel;
    }

    /**
     * @return layout resource id
     */
    @Override
    public int getLayoutId() {
        return R.layout.fragment_registration_1;
    }

    /**
     * Override for set view model
     *
     * @return view model instance
     */
    @Override
    public RegistrationPersonalViewModel getViewModel() {
        viewModel = ViewModelProviders.of(this).get(RegistrationPersonalViewModel.class);
        return viewModel;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (getArguments() != null) {
            emailID = getArguments().getString(ARG_PARAM1);

        }
    }


    @Override
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        getViewDataBinding().etFirstName.requestFocus();
        showKeyboard();
        fragmentRegistration1Binding = getViewDataBinding();
        fragmentRegistration1Binding.setFragment(this);
        viewModel.getEmail().set(emailID);
        tvMale = fragmentRegistration1Binding.getRoot().findViewById(R.id.tvMale);
        tvFemale = fragmentRegistration1Binding.getRoot().findViewById(R.id.tvFemale);
        setupClickListener();
        setSubscribeForNavigation();
    }

    @Override
    public void onResume() {
        super.onResume();
        getActivity().getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING);
        if (viewModel.getGender().get() != null) {
            if (viewModel.getGender().get().equalsIgnoreCase("m")) {
                tvMale.setSelected(true);
                tvFemale.setSelected(false);
            } else if (viewModel.getGender().get().equalsIgnoreCase("f")) {
                tvMale.setSelected(false);
                tvFemale.setSelected(true);
            }
        }
    }

    private void setupClickListener() {
        tvFemale.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                viewModel.getGender().set("F");
                view.setSelected(true);
                tvMale.setSelected(false);
            }
        });
        tvMale.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                viewModel.getGender().set("M");
                tvFemale.setSelected(false);
                view.setSelected(true);

            }
        });
    }


    public void setSubscribeForNavigation() {
        viewModel.getMoveToOpenPassword().observe(this, new Observer<Void>() {
            @Override
            public void onChanged(@Nullable Void aVoid) {
                moveToPasswordFragment();
            }
        });

        viewModel.getOpenDateDialog().observe(this, new Observer<Void>() {
            @Override
            public void onChanged(@Nullable Void aVoid) {
                openDobDialog();
            }
        });
    }

    public void moveToPasswordFragment() {
        SaveMemberRequest request = new SaveMemberRequest();
        request.setEmail(emailID);
        request.setFirstName(viewModel.getFirstName().get());
        request.setLastName(viewModel.getLastName().get());
        request.setGender(viewModel.getGender().get());
        request.setDateOfBirth(DateUtils.formatDate(viewModel.getDob().get(), "dd MMM yyyy", DateUtils.yyyy_MM_dd));
        getActivity().getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.registerContainer, CreatePasswordFragment.newInstance(request), CreatePasswordFragment.TAG).addToBackStack(CreatePasswordFragment.TAG)
                .commit();
    }


    public void openDobDialog() {

        String dobString;
        if (viewModel.getDob().get() != null && viewModel.getDob().get().trim().length() != 0) {
            dobString = viewModel.getDob().get();
            dobString = DateUtils.getInstance().formatDate(dobString, "dd MMM yyyy", DateUtils.dd_MM_yyyy);
        } else {
            dobString = DateUtils.getTodayDate(DateUtils.dd_MM_yyyy);
        }

        String dobSplit[] = dobString.split("/");
        Calendar calendar = Calendar.getInstance(Locale.US);

        calendar.set(Integer.parseInt(dobSplit[2]), Integer.parseInt(dobSplit[1]), Integer.parseInt(dobSplit[0]));
        int iDay, iMonth, iYear;
        if (viewModel.getDob().get() != null && viewModel.getDob().get().trim().length() != 0) {
            iDay = calendar.get(Calendar.DATE);
            iMonth = calendar.get(Calendar.MONTH) - 1;
            iYear = calendar.get(Calendar.YEAR);
        } else {
            iDay = 1;
            iMonth = 0;
            iYear = calendar.get(Calendar.YEAR) - 16;
        }


        DatePickerDialog dbDialog = new DatePickerDialog(getActivity(), new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                Date currantDate = new Date();
                Calendar calendar = Calendar.getInstance();
                calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                calendar.set(Calendar.MONTH, monthOfYear);
                calendar.set(Calendar.YEAR, year);
                Date selectedDate = calendar.getTime();
                if (selectedDate.after(currantDate)) {
                    Toast.makeText(getActivity(), "You can't select future date as date of birth", Toast.LENGTH_SHORT).show();
                } else if (DateUtils.getInstance().getDiffYears(selectedDate, currantDate) < 16) {
                    Toast.makeText(getActivity(), "You need to be at least 16 years old to register on The Wellness Corner", Toast.LENGTH_SHORT).show();
                } else {
                    StringBuilder date = new StringBuilder();
                    monthOfYear = monthOfYear + 1;
                    String dayDate = "";
                    if (dayOfMonth < 10) {
                        dayDate += "0" + dayOfMonth;
                    } else {
                        dayDate = "" + dayOfMonth;
                    }

                    if (monthOfYear < 10) {
                        date.append(dayDate).append("/").append("0").append(monthOfYear);
                    } else {
                        date.append(dayDate).append("/").append(monthOfYear);
                    }
                    date.append("/").append(year);
                    viewModel.getDob().set(DateUtils.getInstance().formatDate(date.toString(), DateUtils.dd_MM_yyyy, "dd MMM yyyy"));
                }
            }
        }, iYear, iMonth, iDay);
        //dbDialog.getDatePicker().setDescendantFocusability(DatePicker.FOCUS_BLOCK_DESCENDANTS);
        dbDialog.getDatePicker().setMaxDate(Calendar.getInstance().getTimeInMillis());
        Calendar minCal = new GregorianCalendar(1920, Calendar.JANUARY, 1);
        dbDialog.getDatePicker().setMinDate(minCal.getTimeInMillis());
        dbDialog.show();
    }


}
