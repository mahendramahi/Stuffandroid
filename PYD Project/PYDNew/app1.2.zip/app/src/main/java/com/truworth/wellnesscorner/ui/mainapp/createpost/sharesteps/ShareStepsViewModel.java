package com.truworth.wellnesscorner.ui.mainapp.createpost.sharesteps;

import android.databinding.ObservableBoolean;
import android.databinding.ObservableDouble;
import android.databinding.ObservableField;
import android.databinding.ObservableInt;

import com.truworth.wellnesscorner.TheWellnessCornerApp;
import com.truworth.wellnesscorner.base.BaseViewModel;
import com.truworth.wellnesscorner.repo.DashboardRepository;
import com.truworth.wellnesscorner.repo.model.request.ShareDashboardRequest;
import com.truworth.wellnesscorner.repo.model.response.ShareStepsResponse;
import com.truworth.wellnesscorner.utils.DateUtils;
import com.truworth.wellnesscorner.utils.SingleLiveEvent;

import javax.inject.Inject;

import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;

public class ShareStepsViewModel extends BaseViewModel {

    public ObservableField<String> date = new ObservableField<>();
    public ObservableField<String> memberName = new ObservableField<>();
    public ObservableField<String> memberImageUrl = new ObservableField<>();
    public ObservableDouble estimatedDistance = new ObservableDouble();
    public ObservableInt stepCount = new ObservableInt();
    public ObservableInt stepsProgress = new ObservableInt();
    public ObservableBoolean isDataLoaded = new ObservableBoolean();

    public String filePath;


    public boolean myLayoutVisible = false;
    SingleLiveEvent<Void> defaultImgClick = new SingleLiveEvent<>();
    SingleLiveEvent<Void> cameraBtnClick = new SingleLiveEvent<>();
    SingleLiveEvent<Void> shareBtnClick = new SingleLiveEvent<>();

    public SingleLiveEvent<Void> getHasDataLoaded() {
        return hasDataLoaded;
    }

    SingleLiveEvent<Void> hasDataLoaded = new SingleLiveEvent<>();


    public SingleLiveEvent<Void> getDefaultImgClick() {
        return defaultImgClick;
    }

    public SingleLiveEvent<Void> getShareBtnClick() {
        return shareBtnClick;
    }

    public SingleLiveEvent<Void> getCameraBtnClick() {
        return cameraBtnClick;
    }
    @Inject
    DashboardRepository dashboardRepository;

    public ShareStepsViewModel() {
        TheWellnessCornerApp.getApp().component().inject(this);
    }

    public void loadStepsPost() {
        setIsLoading(true);
        ShareDashboardRequest shareDashboardRequest = new ShareDashboardRequest();
        shareDashboardRequest.setDeviceDate(DateUtils.getTodayDate("yyyy-MM-dd hh:mm:ss.SSS"));

        dashboardRepository.getPostSteps(shareDashboardRequest).subscribe(new Observer<ShareStepsResponse>() {
            @Override
            public void onSubscribe(Disposable d) {

            }

            @Override
            public void onNext(ShareStepsResponse response) {
                setIsLoading(false);
                if (!response.isHasError()) {
                    if(response.getData().getMemberName()!=null)
                        memberName.set(response.getData().getMemberName()+"'s Steps");
                    memberImageUrl.set(response.getData().getMemberImage());
                    estimatedDistance.set(response.getData().getEstimatedDistance());
                    stepCount.set(response.getData().getSteps());
                    stepsProgress.set((int) response.getData().getStepsCompliance());
                    date.set(DateUtils.getTodayDate("MMM dd,yyyy"));
                    hasDataLoaded.call();
                    isDataLoaded.set(true);
                }
            }

            @Override
            public void onError(Throwable e) {
                isDataLoaded.set(false);
                setIsLoading(false);
            }

            @Override
            public void onComplete() {
                setIsLoading(false);
            }
        });
    }


    public void cameraBtnClick(){

        cameraBtnClick.call();
    }

    public void stepDefaultImageClick() {
        myLayoutVisible = false;
        defaultImgClick.call();
    }
    public void onShareClicked() {
        shareBtnClick.call();
    }

}

