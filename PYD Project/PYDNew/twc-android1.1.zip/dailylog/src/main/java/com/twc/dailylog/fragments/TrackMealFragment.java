package com.twc.dailylog.fragments;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.os.Handler;
import android.speech.RecognizerIntent;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.twc.dailylog.MealActivity;
import com.twc.dailylog.R;
import com.twc.dailylog.R2;
import com.twc.dailylog.adapter.TrackMealAdapter;
import com.twc.dailylog.adapter.TrackMealSectionAdapter;
import com.twc.dailylog.dialog.AddSuggestedFoodDialog;
import com.twc.dailylog.model.beans.FoodItem;
import com.twc.dailylog.model.beans.SectionItem;
import com.twc.dailylog.model.requestbody.HomeBody;
import com.twc.dailylog.model.response.GetDietPlanResponse;
import com.twc.dailylog.rest.RestClient;
import com.twc.dailylog.utils.AnimationFactory;
import com.twc.dailylog.utils.Constant;
import com.twc.dailylog.utils.DailyLogConfig;
import com.twc.dailylog.utils.DateFactory;
import com.twc.dailylog.utils.DialogFactory;
import com.twc.dailylog.utils.NetworkFactory;
import com.twc.dailylog.utils.OnSwipeTouchListener;
import com.twc.dailylog.utils.Utils;
import com.twc.dailylog.views.NoDataView;
import com.twc.greendaolib.FoodItemDao;
import com.twc.greendaolib.GreenDaoApp;

import org.greenrobot.greendao.query.Query;
import org.greenrobot.greendao.query.WhereCondition;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import butterknife.BindView;
import butterknife.OnClick;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static android.app.Activity.RESULT_OK;

/**
 * Created by ManishJ1 on 7/1/2016.
 */
public class TrackMealFragment extends BaseFragment
{
    private final int REQ_CODE_SPEECH_INPUT = 100;
    @BindView(R2.id.rootView)
    LinearLayout rootView;
    @BindView(R2.id.llTrackMealTypes)
    LinearLayout llTrackMealTypes;
    @BindView(R2.id.tvTrackMealType)
    TextView tvTrackMealType;
    @BindView(R2.id.rvTackMeal)
    RecyclerView rvTackMeal;
    @BindView(R2.id.transparentView)
    View transparentView;
    @BindView(R2.id.noDataView)
    NoDataView noDataView;
    @BindView(R2.id.etSearchView)
    EditText etSearchView;
    @BindView(R2.id.imgLeftArrow)
    ImageView imgLeftArrow;
    @BindView(R2.id.imgRightArrow)
    ImageView imgRightArrow;
    @BindView(R2.id.tvMealTypeName)
    TextView tvMealTypeName;
    @BindView(R2.id.scrollChildLayout)
    RelativeLayout scrollChildLayout;
    private String[] trackMealArray = null;
    private String mealType = "";
    private int selectedPosition = -1;
    private boolean isDietPLanViewVisible = true;
    private boolean flagCollapseOrExpand = false;
    private TrackMealSectionAdapter trackMealSectionAdapter;
    private TrackMealAdapter trackMealAdapter;
    private String speakSearchString = "";
    private Handler handler = new Handler();
    private Runnable runnable = new Runnable() {
        @Override
        public void run() {
            getDietPlanApiCall();
        }
    };

    public static TrackMealFragment newInstance(Bundle bundle) {
        TrackMealFragment trackMealFragment = new TrackMealFragment();
        trackMealFragment.setArguments(bundle);

        return trackMealFragment;
    }

    private void setMealTypeData(String mealTypeData)
    {
        if (mealTypeData.equalsIgnoreCase("lunch"))
            trackMealArray[0] = "Recent " + mealTypeData + "es";
        else if (!mealTypeData.equalsIgnoreCase("snacks"))
            trackMealArray[0] = "Recent " + mealTypeData + "s";
        else
            trackMealArray[0] = "Recent " + mealTypeData;

        trackMealArray[1] = mealTypeData + " Diet Plan";
        trackMealArray[2] = "Frequently Tracked Foods";
        trackMealArray[3] = "All Recent Foods";
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        handler.removeCallbacks(runnable);
    }

    @Override
    public int getFragmentLayout() {
        return R.layout.fragment_trackmeal;
    }

    @Override
    public void onFragmentReady() {
        tvMealTypeName.setText(mealType);

        setListeners();

        speakSearchString = "";

        noDataView.setTitleView(getString(R.string.no_meals_tracked_yet));
        noDataView.setSubTitleView(getString(R.string.recent_appears));
        noDataView.setImageIcon(ContextCompat.getDrawable(getActivity(),R.drawable.no_food_icon));

        rvTackMeal.setHasFixedSize(true);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getActivity());
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        rvTackMeal.setLayoutManager(linearLayoutManager);

        callApiAndSetAdapter();

    }

    private void callApiAndSetAdapter()
    {
        tvTrackMealType.setText(trackMealArray[1]);
        llTrackMealTypes.removeAllViews();
        for (int i = 0; i < trackMealArray.length; i++) {
            addViewsToTrackMealLayout(trackMealArray[i], i);
        }


        if (selectedPosition == -1) {
            if (trackMealArray.length > 0) {
                selectedPosition = 1;
                AnimationFactory.collapse(llTrackMealTypes);
                handler.postDelayed(runnable, Constant.API_POST_DELAYED_TIME);

            }
        } else {

            if (!isDietPLanViewVisible)
                llTrackMealTypes.getChildAt(1).setVisibility(View.GONE);

            tvTrackMealType.setText(trackMealArray[selectedPosition]);
            AnimationFactory.collapse(llTrackMealTypes);
            if (selectedPosition == 0 || selectedPosition == 1) {
                rvTackMeal.setAdapter(trackMealSectionAdapter);
                if (trackMealSectionAdapter != null)
                    trackMealSectionAdapter.notifyDataSetChanged();
            } else {
                rvTackMeal.setAdapter(trackMealAdapter);
                if (trackMealAdapter != null)
                    trackMealAdapter.notifyDataSetChanged();
            }
        }

    }


    private void setLeftArrowData()
    {
        rvTackMeal.setAdapter(null);
        selectedPosition= -1;
        imgRightArrow.setVisibility(View.VISIBLE);
        imgLeftArrow.setVisibility(View.VISIBLE);

        if(tvMealTypeName.getText().toString().equalsIgnoreCase(getString(R.string.breakfast))) {
            mealType=getString(R.string.snacks);
            tvMealTypeName.setText(mealType);

        }else
        if(tvMealTypeName.getText().toString().equalsIgnoreCase(getString(R.string.lunch))) {
            mealType=getString(R.string.breakfast);
            tvMealTypeName.setText(mealType);
            // imgLeftArrow.setVisibility(View.INVISIBLE);

        }
        else if(tvMealTypeName.getText().toString().equalsIgnoreCase(getString(R.string.dinner))) {
            mealType=getString(R.string.lunch);
            tvMealTypeName.setText(mealType);

        }
        else if(tvMealTypeName.getText().toString().equalsIgnoreCase(getString(R.string.snacks))) {
            mealType=getString(R.string.dinner);
            tvMealTypeName.setText(mealType);

        }
        ((MealActivity) getActivity()).setToolBarTitle("Add " + tvMealTypeName.getText().toString());
        ((MealActivity) getActivity()).setMealType(tvMealTypeName.getText().toString());
        setMealTypeData(mealType);
        callApiAndSetAdapter();
    }

    private void setRightArrowData()
    {
        rvTackMeal.setAdapter(null);
        selectedPosition=-1;
        imgLeftArrow.setVisibility(View.VISIBLE);
        imgRightArrow.setVisibility(View.VISIBLE);

        if(tvMealTypeName.getText().toString().equalsIgnoreCase(getString(R.string.breakfast))) {
            mealType=getString(R.string.lunch);
            tvMealTypeName.setText(mealType);

        }
        else if(tvMealTypeName.getText().toString().equalsIgnoreCase(getString(R.string.lunch))) {
            mealType=getString(R.string.dinner);
            tvMealTypeName.setText(mealType);

        }
        else if(tvMealTypeName.getText().toString().equalsIgnoreCase(getString(R.string.dinner))) {
            mealType=getString(R.string.snacks);
            tvMealTypeName.setText(mealType);
            // imgRightArrow.setVisibility(View.INVISIBLE);

        }
        else if(tvMealTypeName.getText().toString().equalsIgnoreCase(getString(R.string.snacks))) {
            mealType=getString(R.string.breakfast);
            tvMealTypeName.setText(mealType);

        }

        ((MealActivity) getActivity()).setToolBarTitle("Add " + tvMealTypeName.getText().toString());
        ((MealActivity) getActivity()).setMealType(tvMealTypeName.getText().toString());
        setMealTypeData(mealType);
        callApiAndSetAdapter();
    }


    private void setListeners()
    {
        scrollChildLayout.setOnTouchListener(new OnSwipeTouchListener(getActivity())
        {

            public void onSwipeRight()
            {
                //  if(!tvMealTypeName.getText().toString().equalsIgnoreCase(getString(R.string.snacks)))
                //setLeftArrowData();
                setRightArrowData();
            }

            public void onSwipeLeft()
            {
                // if(!tvMealTypeName.getText().toString().equalsIgnoreCase(getString(R.string.breakfast)))
                //setRightArrowData();
                setLeftArrowData();
            }

            @Override
            public void onClick(View view)
            {
            }
        });
    }

    @OnClick(R2.id.imgLeftArrow)
    public void LeftArrowClick()
    {
        setLeftArrowData();
    }

    @OnClick(R2.id.imgRightArrow)
    public void RightArrowClick()
    {
        setRightArrowData();
    }

    private void addViewsToTrackMealLayout(String value, final int position) {
        View layout2 = View.inflate(getActivity(), R.layout.row_track_meal_spinner_item, null);
        layout2.setTag(position + "");
        TextView tvMealType = layout2.findViewById(R.id.tvMealType);
        tvMealType.setText(value);

        layout2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                selectedPosition = position;
                tvTrackMealType.setText(trackMealArray[position]);
                expandOrCollapse();
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if (position == 0) {
                            getRecentFoodOf30DaysCall();
                        } else if (position == 1) {
                            getDietPlanApiCall();
                        } else if (position == 2) {
                            getFrequentlyFoodApiCall();
                        } else if (position == 3) {
                            getAllRecentFood();
                        }
                    }
                }, 200);


            }
        });

        llTrackMealTypes.addView(layout2);
    }

    @OnClick(R2.id.tvTrackMealType)
    public void expandOrCollapse() {
        flagCollapseOrExpand = !flagCollapseOrExpand;
        if (flagCollapseOrExpand) {
            AnimationFactory.expand(llTrackMealTypes);
            transparentView.setVisibility(View.VISIBLE);

        } else {
            AnimationFactory.collapse(llTrackMealTypes);
            transparentView.setVisibility(View.GONE);
        }
    }

    @OnClick(R2.id.transparentView)
    public void hideTransparentView() {
        expandOrCollapse();
    }

    private void getDietPlanApiCall() {
        noDataView.setTitleView(getString(R.string.no_meals_tracked_yet));
        //tvNoSubtitle.setVisibility(View.VISIBLE);
        if (NetworkFactory.getInstance().isNetworkAvailable(getActivity())) {

            HomeBody homeBody = new HomeBody();
            homeBody.setMemberID(DailyLogConfig.dailyLogUser.getUserID());
            RestClient restClient = new RestClient(getActivity(), DailyLogConfig.BASE_URL, DailyLogConfig.DEBUG);
            restClient.getDailyLogService().getDietPlan(homeBody).enqueue(new Callback<GetDietPlanResponse>() {
                @Override
                public void onResponse(Call<GetDietPlanResponse> call, Response<GetDietPlanResponse> response) {
                    if (isAdded() && getActivity() != null) {

                        noDataView.setVisibility(View.GONE);
                        if (response != null && response.body() != null) {

                            if (response.body().getStatus() == 0 && response.body().getData() != null) {

                                if (response.body().getData().size() > 0) {

                                    ArrayList<SectionItem> sectionItemsList = new ArrayList<>();
                                    for (int i = 0; i < 7; i++) {
                                        SectionItem sectionItem = new SectionItem();
                                        sectionItem.setSectionName("Option" + (i + 1));
                                        ArrayList<FoodItem> sectionFoodItems = new ArrayList<>();
                                        sectionItem.setFoodItemArrayList(sectionFoodItems);
                                        sectionItemsList.add(sectionItem);
                                    }


                                    List<FoodItem> foodItemList = response.body().getData();
                                    int count = 0;
                                    for (FoodItem foodItem : foodItemList) {
                                        if (mealType.equalsIgnoreCase("Breakfast") ||
                                                mealType.equalsIgnoreCase("Lunch") ||
                                                mealType.equalsIgnoreCase("Dinner")) {

                                            if (foodItem.getMealType().equalsIgnoreCase(mealType)) {
                                                count++;
                                                if (foodItem.getDays().equalsIgnoreCase("MON")) {
                                                    sectionItemsList.get(0).getFoodItemArrayList().add(foodItem);
                                                } else if (foodItem.getDays().equalsIgnoreCase("TUE")) {
                                                    sectionItemsList.get(1).getFoodItemArrayList().add(foodItem);
                                                } else if (foodItem.getDays().equalsIgnoreCase("WED")) {
                                                    sectionItemsList.get(2).getFoodItemArrayList().add(foodItem);
                                                } else if (foodItem.getDays().equalsIgnoreCase("THU")) {
                                                    sectionItemsList.get(3).getFoodItemArrayList().add(foodItem);
                                                } else if (foodItem.getDays().equalsIgnoreCase("FRI")) {
                                                    sectionItemsList.get(4).getFoodItemArrayList().add(foodItem);
                                                } else if (foodItem.getDays().equalsIgnoreCase("SAT")) {
                                                    sectionItemsList.get(5).getFoodItemArrayList().add(foodItem);
                                                } else if (foodItem.getDays().equalsIgnoreCase("SUN")) {
                                                    sectionItemsList.get(6).getFoodItemArrayList().add(foodItem);
                                                }
                                            }

                                        } else if (mealType.equalsIgnoreCase("snacks")) {
                                            if (foodItem.getMealType().contains("Snack")) {
                                                count++;
                                                if (foodItem.getDays().equalsIgnoreCase("MON")) {
                                                    sectionItemsList.get(0).getFoodItemArrayList().add(foodItem);
                                                } else if (foodItem.getDays().equalsIgnoreCase("TUE")) {
                                                    sectionItemsList.get(1).getFoodItemArrayList().add(foodItem);
                                                } else if (foodItem.getDays().equalsIgnoreCase("WED")) {
                                                    sectionItemsList.get(2).getFoodItemArrayList().add(foodItem);
                                                } else if (foodItem.getDays().equalsIgnoreCase("THU")) {
                                                    sectionItemsList.get(3).getFoodItemArrayList().add(foodItem);
                                                } else if (foodItem.getDays().equalsIgnoreCase("FRI")) {
                                                    sectionItemsList.get(4).getFoodItemArrayList().add(foodItem);
                                                } else if (foodItem.getDays().equalsIgnoreCase("SAT")) {
                                                    sectionItemsList.get(5).getFoodItemArrayList().add(foodItem);
                                                } else if (foodItem.getDays().equalsIgnoreCase("SUN")) {
                                                    sectionItemsList.get(6).getFoodItemArrayList().add(foodItem);
                                                }
                                            }
                                        }
                                    }

                                    if (count > 0) {
                                        trackMealSectionAdapter = new TrackMealSectionAdapter(sectionItemsList, getActivity());
                                        rvTackMeal.setAdapter(trackMealSectionAdapter);
                                        rvTackMeal.setVisibility(View.VISIBLE);
                                        llTrackMealTypes.setVisibility(View.GONE);
                                    } else {
                                        isDietPLanViewVisible = false;
                                        selectedPosition = 0;
                                        llTrackMealTypes.getChildAt(1).setVisibility(View.GONE);
                                        tvTrackMealType.setText(trackMealArray[0]);
                                        getRecentFoodOf30DaysCall();
                                    }
                                } else {

                                    isDietPLanViewVisible = false;
                                    selectedPosition = 0;
                                    llTrackMealTypes.getChildAt(1).setVisibility(View.GONE);
                                    tvTrackMealType.setText(trackMealArray[0]);
                                    getRecentFoodOf30DaysCall();
                                }

                            }

                            else if (response.body().getStatus() == -1 || response.body().getStatus() == -2) {
                                isDietPLanViewVisible = false;
                                selectedPosition = 0;
                                llTrackMealTypes.getChildAt(1).setVisibility(View.GONE);
                                tvTrackMealType.setText(trackMealArray[0]);
                                getRecentFoodOf30DaysCall();

                            }
                        }
                    }

                }

                @Override
                public void onFailure(Call<GetDietPlanResponse> call, Throwable t) {
                    t.printStackTrace();
                    if (isAdded() && getActivity() != null) {

                            DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.network_error), getString(R.string.str_ok), false);

                    }
                }
            });
        } else {
            Utils.showSnackBarMessage(rootView, getString(R.string.internet_not_available));
        }
    }

    private void getRecentFoodOf30DaysCall() {
        noDataView.setTitleView(getString(R.string.no_meals_tracked_yet));
       // tvNoSubtitle.setVisibility(View.VISIBLE);
        Date today = new Date();
        Calendar cal = Calendar.getInstance();
        cal.setTime(today);
        cal.add(Calendar.DAY_OF_MONTH, -30);

        String currentTime = DateFactory.getInstance().getTodayDate("yyyyMMdd");

        /*SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd", Locale.getDefault());
        String previous30Days = sdf.format(cal.getTime());*/
        String previous30Days = DateFactory.getInstance().getDateFromDateFormat(cal.getTime(),"yyyyMMdd");

        FoodItemDao foodItemDao = GreenDaoApp.getInstance(getActivity()).getDaoSession(getActivity()).getFoodItemDao();
        //Query query = foodItemDao.queryBuilder().where(FoodItemDao.Properties.MealType.eq(mealType), FoodItemDao.Properties.DateTime.between(previous30Days, currentTime)).build();
        Query query = foodItemDao.queryBuilder().where(
                new WhereCondition.StringCondition("MEAL_TYPE='"+mealType+"' and " +
                        "DATE_TIME between '"+previous30Days+"' and '"+currentTime+"' " +
                        "group by NAME ")
        ).build();

        List<com.twc.greendaolib.FoodItem> foodItems = query.list();
        Utils.printLog("total list", foodItems.size() + "");

        /* convert database food item object to trackmeal food item object*/
        ArrayList<FoodItem> foodItemArrayList = new ArrayList<>();
        for (com.twc.greendaolib.FoodItem foodItem : foodItems) {
            FoodItem mFoodItem = new FoodItem();
            mFoodItem.setCalories(Double.parseDouble(foodItem.getCalories()));
            mFoodItem.setFoodID(foodItem.getFoodId());
            mFoodItem.setFoodName(foodItem.getName());
            mFoodItem.setStandardServing(foodItem.getStandardServing());
            mFoodItem.setQuantity(foodItem.getQuantity());
            mFoodItem.setMealType(foodItem.getMealType());
            mFoodItem.setMealTime(foodItem.getDateTime());
            mFoodItem.setNutritionId(Integer.parseInt(foodItem.getServerId()));
            foodItemArrayList.add(mFoodItem);
        }

        Cursor cursor = GreenDaoApp.getInstance(getActivity()).getDaoSession(getActivity()).getDatabase().rawQuery("SELECT distinct " + FoodItemDao.Properties.DateTime.columnName + " FROM FOOD_ITEM WHERE " + FoodItemDao.Properties.MealType.columnName + "='" + mealType + "' AND " + FoodItemDao.Properties.DateTime.columnName + " between '" + previous30Days + "' AND '" + currentTime + "'", null);
        Utils.printLog("total list2", cursor.getCount() + "");

        /* create sections arrayList of date using cursor*/
        ArrayList<SectionItem> sectionItemsList = new ArrayList<>();
        if (cursor.moveToFirst()) {
            do {
                SectionItem sectionItem = new SectionItem();
                sectionItem.setSectionName(cursor.getString(0));
                ArrayList<FoodItem> sectionFoodItems = new ArrayList<>();
                sectionItem.setFoodItemArrayList(sectionFoodItems);
                sectionItemsList.add(sectionItem);
            } while (cursor.moveToNext());
        }
        if (!cursor.isClosed()) {
            cursor.close();
        }
        if (sectionItemsList.size() > 0) {
            for (int i = 0; i < sectionItemsList.size(); i++) {
                for (int k = 0; k < foodItemArrayList.size(); k++) {
                    if (sectionItemsList.get(i).getSectionName().contains(foodItemArrayList.get(k).getMealTime())) {
                        sectionItemsList.get(i).getFoodItemArrayList().add(foodItemArrayList.get(k));
                    }
                }
            }

            trackMealSectionAdapter = new TrackMealSectionAdapter(sectionItemsList, getActivity());
            rvTackMeal.setAdapter(trackMealSectionAdapter);
            rvTackMeal.setVisibility(View.VISIBLE);
            llTrackMealTypes.setVisibility(View.GONE);
            noDataView.setVisibility(View.GONE);

        } else {
            transparentView.setVisibility(View.GONE);
            rvTackMeal.setVisibility(View.GONE);
            llTrackMealTypes.setVisibility(View.GONE);
            noDataView.setVisibility(View.VISIBLE);
        }


    }

    private void getAllRecentFood() {
        noDataView.setTitleView(getString(R.string.no_meals_tracked_yet));
       // tvNoSubtitle.setVisibility(View.VISIBLE);
        FoodItemDao foodItemDao = GreenDaoApp.getInstance(getActivity()).getDaoSession(getActivity()).getFoodItemDao();
      //  Query query = foodItemDao.queryBuilder()./*where(FoodItemDao.Properties.MealType.eq(mealType)).*/build();

        Query query = foodItemDao.queryBuilder().where(
                new WhereCondition.StringCondition("MEAL_TYPE='"+mealType+"' group by NAME ")
        ).build();

        List<com.twc.greendaolib.FoodItem> foodItems = query.list();
        Utils.printLog("total list", foodItems.size() + "");

        /* convert database food item object to trackmeal food item object*/
        ArrayList<FoodItem> foodItemArrayList = new ArrayList<>();
        for (com.twc.greendaolib.FoodItem foodItem : foodItems) {
            FoodItem mFoodItem = new FoodItem();
            mFoodItem.setCalories(Double.parseDouble(foodItem.getCalories()));
            mFoodItem.setFoodID(foodItem.getFoodId());
            mFoodItem.setFoodName(foodItem.getName());
            mFoodItem.setStandardServing(foodItem.getStandardServing());
            mFoodItem.setQuantity(foodItem.getQuantity());
            mFoodItem.setMealType(foodItem.getMealType());
            mFoodItem.setMealTime(foodItem.getDateTime());
            mFoodItem.setNutritionId(Integer.parseInt(foodItem.getServerId()));
            foodItemArrayList.add(mFoodItem);
        }

        if (foodItemArrayList.size() > 0) {

            trackMealAdapter = new TrackMealAdapter(foodItemArrayList, getActivity());
            rvTackMeal.setAdapter(trackMealAdapter);
            rvTackMeal.setVisibility(View.VISIBLE);
            llTrackMealTypes.setVisibility(View.GONE);
            noDataView.setVisibility(View.GONE);
        } else {
            transparentView.setVisibility(View.GONE);
            rvTackMeal.setVisibility(View.GONE);
            llTrackMealTypes.setVisibility(View.GONE);
            noDataView.setVisibility(View.VISIBLE);
        }

    }

    private void getFrequentlyFoodApiCall() {
        noDataView.setTitleView(getString(R.string.no_meals_frequently));
        noDataView.setSubTitleView("");
        if (NetworkFactory.getInstance().isNetworkAvailable(getActivity())) {
          /*  final ProgressDialog pd;
            pd = ProgressDialog.show(getActivity(), "", ""
                    + getString(R.string.app_name));*/



            HomeBody homeBody = new HomeBody();
            homeBody.setMemberID(DailyLogConfig.dailyLogUser.getUserID());

            RestClient restClient = new RestClient(getActivity(), DailyLogConfig.BASE_URL, DailyLogConfig.DEBUG);
            restClient.getDailyLogService().getFreqentlyFood(homeBody).enqueue(new Callback<GetDietPlanResponse>() {
                @Override
                public void onResponse(Call<GetDietPlanResponse> call, Response<GetDietPlanResponse> response) {
                    if (isAdded() && getActivity() != null) {

                        noDataView.setVisibility(View.GONE);
                        if (response != null && response.body() != null) {
                            if (response.body().getStatus() == 0 && response.body().getData() != null & response.body().getData().size() > 0) {
                                ArrayList<FoodItem> foodItemList = (ArrayList<FoodItem>) response.body().getData();
                                trackMealAdapter = new TrackMealAdapter(foodItemList, getActivity());
                                rvTackMeal.setAdapter(trackMealAdapter);
                                llTrackMealTypes.setVisibility(View.GONE);
                                rvTackMeal.setVisibility(View.VISIBLE);
                                noDataView.setVisibility(View.GONE);
                            } else {

                                rvTackMeal.setVisibility(View.GONE);
                                llTrackMealTypes.setVisibility(View.GONE);
                                noDataView.setVisibility(View.VISIBLE);
                            }
                        }
                    }

                }

                @Override
                public void onFailure(Call<GetDietPlanResponse> call, Throwable t) {
                    t.printStackTrace();
                    if (isAdded() && getActivity() != null) {

                            DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.network_error), getString(R.string.str_ok), false);

                    }
                }
            });
        } else {
            Utils.showSnackBarMessage(rootView, getString(R.string.internet_not_available));
        }
    }

    /**
     * Showing google speech input dialog
     * */
    @OnClick(R2.id.btnSpeak)
    public void promptSpeechInput() {
        speakSearchString = "";
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT,
                getString(R.string.speech_prompt));
        try {
            startActivityForResult(intent, REQ_CODE_SPEECH_INPUT);
        } catch (ActivityNotFoundException a) {
            Utils.showToast(getActivity(),
                    getString(R.string.speech_not_supported));
        }
    }

    @OnClick(R2.id.etSearchView)
    public void navigateToFoodSearch() {
        Bundle bundle = new Bundle();
        bundle.putString("searchString",speakSearchString);
        Utils.replaceFragment(getFragmentManager(), FoodSearchFragment.newInstance(bundle), FoodSearchFragment.class.getSimpleName(), true, R.id.fragmentContainerMeal);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {
            case REQ_CODE_SPEECH_INPUT: {
                if (resultCode == RESULT_OK && null != data) {

                    ArrayList<String> result = data
                            .getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                    speakSearchString = result.get(0);

                    Bundle bundle = new Bundle();
                    bundle.putString("searchString",speakSearchString);
                    Utils.replaceFragment(getFragmentManager(), FoodSearchFragment.newInstance(bundle), FoodSearchFragment.class.getSimpleName(), true, R.id.fragmentContainerMeal);
                }
                break;
            }
        }
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
        trackMealArray = new String[4];
        if (getArguments() != null) {
            mealType = getArguments().getString("trackMealType");
            ((MealActivity)getActivity()).setMealType(mealType);
            trackMealArray = new String[4];

            setMealTypeData(mealType);
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        ((MealActivity) getActivity()).setToolBarTitle("Add " + mealType);
        ((MealActivity) getActivity()).showHomeAsUpEnableToolbar();
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.menu_option_menu, menu);
        MenuItem optionMenu = menu.findItem(R.id.action_option_menu);
        MenuItem menu1 = menu.findItem(R.id.action_menu1);
        MenuItem menu2 = menu.findItem(R.id.action_menu2);
        MenuItem menu3 = menu.findItem(R.id.action_menu3);
        optionMenu.setVisible(true);
        menu1.setVisible(false);
        menu2.setTitle(R.string.add_suggested_food);
        menu3.setVisible(false);
        super.onCreateOptionsMenu(menu, inflater);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        if (item.getTitle().equals(getString(R.string.add_suggested_food))) {
            AddSuggestedFoodDialog addSuggestedFoodDialog = new AddSuggestedFoodDialog(getActivity(),null);
            addSuggestedFoodDialog.show();
        }
        return super.onOptionsItemSelected(item);
    }
}
