package com.truworth.discoverlib.fragment;

import android.app.FragmentTransaction;
import android.app.SearchManager;
import android.content.Context;
import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.SearchView;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

import com.truworth.discoverlib.DiscoverActivity;
import com.truworth.discoverlib.R;
import com.truworth.discoverlib.R2;
import com.truworth.discoverlib.adapter.TabsViewPagerAdapter;
import com.truworth.discoverlib.interfaces.OnDiscoverCategoryChangeListener;
import com.truworth.discoverlib.utils.AnimationFactory;
import com.truworth.discoverlib.utils.Constant;
import com.truworth.discoverlib.utils.Utils;

import java.util.ArrayList;

import butterknife.BindView;
import butterknife.OnClick;

/**
 * If this code works it was written by Somesh Kumar on 05 August, 2016. If not, I don't know who wrote it.
 */
public class DiscoverFragment extends BaseFragment {

    @BindView(R2.id.tabLayout)
    TabLayout mTabLayout;

    @BindView(R2.id.viewPager)
    ViewPager mViewPager;

    @BindView(R2.id.llCategoryAll)
    LinearLayout mLlCategoryAll;

    @BindView(R2.id.llCategoryGetFit)
    LinearLayout mLlCategoryGetFit;

    @BindView(R2.id.llCategoryEatRight)
    LinearLayout mLlCategoryEatRight;

    @BindView(R2.id.llCategoryStayHappy)
    LinearLayout mLlCategoryStayHappy;

    @BindView(R2.id.llCategoryLookBetter)
    LinearLayout mLlCategoryLookBetter;

    @BindView(R2.id.llCategoryBeHealthy)
    LinearLayout mLlCategoryBeHealthy;

    @BindView(R2.id.llCategoryOthers)
    LinearLayout mLlCategoryOthers;

    @BindView(R2.id.llFilterDiscover)
    LinearLayout mLayoutFilterDiscover;

    @BindView(R2.id.frameLayoutBlank)
    FrameLayout mFrameLayout;

    private TabsViewPagerAdapter mTabsViewPagerAdapter;
    private String mFilterCategory = "All";
    private String mArticleType;
    private SearchView mSearchView;
    private OnDiscoverCategoryChangeListener mArticleSearchResultCallback, mSlideshowSearchResultCallback;
    private int mFinalRadius;
    private int mCx;
    private int mCy;
    private LinearLayout mSelectedLayout = null;
    private ArrayList<LinearLayout> views;

    public static DiscoverFragment newInstance(Bundle bundle) {
        DiscoverFragment fragment = new DiscoverFragment();
        fragment.setArguments(bundle);
        return fragment;
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
        setupViewPager();
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.menu_discover_list, menu);
        final MenuItem searchItem = menu.findItem(R.id.action_search);
        SearchManager searchManager = (SearchManager) getActivity().getSystemService(Context.SEARCH_SERVICE);

        if (searchItem != null) {
            mSearchView = (SearchView) searchItem.getActionView();
        }
        if (mSearchView != null) {
            assert searchManager != null;
            mSearchView.setSearchableInfo(searchManager.getSearchableInfo(getActivity().getComponentName()));
            mSearchView.setIconified(true);
            mSearchView.setOnSearchClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    ((DiscoverActivity) getActivity()).hideToolbarTitle();
                    Utils.replaceFragment(getFragmentManager(), DiscoverSearchFragment.newInstance(), DiscoverSearchFragment.class.getSimpleName(), true, R.id.container);

                }
            });
            mSearchView.setQueryHint("Search");
            super.onCreateOptionsMenu(menu, inflater);
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int i = item.getItemId();
        if (i == R.id.action_filter) {
            mCx = mLayoutFilterDiscover.getLeft() + mLayoutFilterDiscover.getRight();
            mCy = mLayoutFilterDiscover.getTop();
            mFinalRadius = Math.max(mLayoutFilterDiscover.getWidth(), mLayoutFilterDiscover.getHeight());
            if (mLayoutFilterDiscover.getVisibility() == View.INVISIBLE) {
                AnimationFactory.circularReveal(mLayoutFilterDiscover, true, mCx, mCy, mFinalRadius);
            } else {
                AnimationFactory.circularReveal(mLayoutFilterDiscover, false, mCx, mCy, mFinalRadius);
            }

        }
        return super.onOptionsItemSelected(item);
    }


    @Override
    public void onDestroy() {
        super.onDestroy();
        if (mTabsViewPagerAdapter != null) {
            mTabsViewPagerAdapter.notifyDataSetChanged();
            mTabsViewPagerAdapter = null;
        }
        if (views != null) {
            views.clear();
            views = null;
        }

        mArticleSearchResultCallback = null;
        mSlideshowSearchResultCallback = null;
        mSelectedLayout = null;
    }

    @Override
    public int getFragmentLayout() {
        return R.layout.fragment_discover;
    }

    @Override
    public void onFragmentReady() {
        ((DiscoverActivity) getActivity()).setToolBarTitle("Discover");
        ((DiscoverActivity) getActivity()).showActionDrawerToggleToolbar();
        mViewPager.setAdapter(mTabsViewPagerAdapter);
        mTabLayout.setupWithViewPager(mViewPager);
        mViewPager.setOffscreenPageLimit(5);

        mViewPager.addOnPageChangeListener(new ViewPager.SimpleOnPageChangeListener() {
            @Override
            public void onPageSelected(int position) {
                super.onPageSelected(position);
                filterCategory(position, mFilterCategory);
            }
        });
        setFilterOnResume();

    }

    private void setFilterOnResume() {
        if (mSelectedLayout != null) {
            int i = mSelectedLayout.getId();
            if (i == R.id.llCategoryAll) {
                setSelectionOnFilter(mLlCategoryAll);

            } else if (i == R.id.llCategoryBeHealthy) {
                setSelectionOnFilter(mLlCategoryBeHealthy);

            } else if (i == R.id.llCategoryEatRight) {
                setSelectionOnFilter(mLlCategoryEatRight);

            } else if (i == R.id.llCategoryGetFit) {
                setSelectionOnFilter(mLlCategoryGetFit);

            } else if (i == R.id.llCategoryLookBetter) {
                setSelectionOnFilter(mLlCategoryGetFit);

            } else if (i == R.id.llCategoryOthers) {
                setSelectionOnFilter(mLlCategoryGetFit);

            } else if (i == R.id.llCategoryStayHappy) {
                setSelectionOnFilter(mLlCategoryGetFit);

            } else {
                setSelectionOnFilter(mLlCategoryAll);

            }
        } else {
            setSelectionOnFilter(mLlCategoryAll);
        }
    }

    private void setupViewPager() {
        mTabsViewPagerAdapter = new TabsViewPagerAdapter(getChildFragmentManager());


        DiscoverListFragment discoverArticlesFragment = DiscoverListFragment.newInstance();
        mArticleSearchResultCallback = discoverArticlesFragment;

        DiscoverListFragment discoverSlideshowFragment = DiscoverListFragment.newInstance();
        mSlideshowSearchResultCallback = discoverSlideshowFragment;

        mTabsViewPagerAdapter.addFragment(discoverArticlesFragment, "ARTICLES");
        mTabsViewPagerAdapter.addFragment(discoverSlideshowFragment, "SLIDESHOW");
    }

    @OnClick({R2.id.llCategoryAll, R2.id.frameLayoutBlank, R2.id.llCategoryGetFit, R2.id.llCategoryLookBetter, R2.id.llCategoryBeHealthy, R2.id.llCategoryEatRight, R2.id.llCategoryStayHappy, R2.id
            .llCategoryOthers})
    public void onClick(View view) {
        int i = view.getId();
        if (i == R.id.llCategoryAll) {
            mSelectedLayout = mLlCategoryAll;
            setSelectionOnFilter(mLlCategoryAll);
            AnimationFactory.circularReveal(mLayoutFilterDiscover, false, mCx, mCy, mFinalRadius);
            filterCategory(getCurrentTab(), Constant.DISCOVER_FILTER_ALL);

        } else if (i == R.id.llCategoryGetFit) {
            mSelectedLayout = mLlCategoryGetFit;
            setSelectionOnFilter(mLlCategoryGetFit);
            AnimationFactory.circularReveal(mLayoutFilterDiscover, false, mCx, mCy, mFinalRadius);
            filterCategory(getCurrentTab(), Constant.DISCOVER_FILTER_GET_FIT);

        } else if (i == R.id.llCategoryEatRight) {
            mSelectedLayout = mLlCategoryEatRight;
            setSelectionOnFilter(mLlCategoryEatRight);
            AnimationFactory.circularReveal(mLayoutFilterDiscover, false, mCx, mCy, mFinalRadius);
            filterCategory(getCurrentTab(), Constant.DISCOVER_FILTER_EAT_RIGHT);

        } else if (i == R.id.llCategoryStayHappy) {
            mSelectedLayout = mLlCategoryStayHappy;
            setSelectionOnFilter(mLlCategoryStayHappy);
            AnimationFactory.circularReveal(mLayoutFilterDiscover, false, mCx, mCy, mFinalRadius);
            filterCategory(getCurrentTab(), Constant.DISCOVER_FILTER_STAY_HAPPY);

        } else if (i == R.id.llCategoryLookBetter) {
            mSelectedLayout = mLlCategoryLookBetter;
            setSelectionOnFilter(mLlCategoryLookBetter);
            AnimationFactory.circularReveal(mLayoutFilterDiscover, false, mCx, mCy, mFinalRadius);
            filterCategory(getCurrentTab(), Constant.DISCOVER_FILTER_LOOK_BETTER);

        } else if (i == R.id.llCategoryBeHealthy) {
            mSelectedLayout = mLlCategoryBeHealthy;
            setSelectionOnFilter(mLlCategoryBeHealthy);
            AnimationFactory.circularReveal(mLayoutFilterDiscover, false, mCx, mCy, mFinalRadius);
            filterCategory(getCurrentTab(), Constant.DISCOVER_FILTER_BE_HEALTHY);

        } else if (i == R.id.llCategoryOthers) {
            mSelectedLayout = mLlCategoryOthers;
            setSelectionOnFilter(mLlCategoryOthers);
            AnimationFactory.circularReveal(mLayoutFilterDiscover, false, mCx, mCy, mFinalRadius);
            filterCategory(getCurrentTab(), Constant.DISCOVER_FILTER_OTHER);

        } else if (i == R.id.frameLayoutBlank) {
            AnimationFactory.circularReveal(mLayoutFilterDiscover, false, mCx, mCy, mFinalRadius);

        }
    }

    private void setSelectionOnFilter(LinearLayout layout) {
        views = new ArrayList<>();
        views.add(mLlCategoryAll);
        views.add(mLlCategoryOthers);
        views.add(mLlCategoryBeHealthy);
        views.add(mLlCategoryEatRight);
        views.add(mLlCategoryStayHappy);
        views.add(mLlCategoryLookBetter);
        views.add(mLlCategoryGetFit);
        views.remove(layout);
        for (int index = 0; index < views.size(); index++) {
            views.get(index).setSelected(false);
        }
        layout.setSelected(true);

    }

    private void filterCategory(int currentTab, String filterCategory) {
        mFilterCategory = filterCategory;
        if (currentTab == 0) {
            if (mArticleSearchResultCallback != null) {
                mArticleSearchResultCallback.OnDiscoverFilterCategoryChange(mFilterCategory);
            }
        } else if (currentTab == 1) {
            if (mSlideshowSearchResultCallback != null) {
                mSlideshowSearchResultCallback.OnDiscoverFilterCategoryChange(mFilterCategory);
            }
        }
    }

    private int getCurrentTab() {
        return mViewPager.getCurrentItem();
    }

    public String getArticleTypeForAPI() {
        int currantTab = mTabLayout.getSelectedTabPosition();
        switch (currantTab) {
            case 0:
                mArticleType = Constant.ARTICLE_TYPE_ARTICLES;
                break;
            case 1:
                mArticleType = Constant.ARTICLE_TYPE_SLIDESHOW;
                break;
        }
        return mArticleType;
    }
}

