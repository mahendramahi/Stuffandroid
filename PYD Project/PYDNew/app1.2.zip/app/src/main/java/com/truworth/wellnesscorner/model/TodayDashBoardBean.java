package com.truworth.wellnesscorner.model;

import com.truworth.wellnesscorner.ui.mainapp.post.IPostListItem;

import java.util.List;

public class TodayDashBoardBean implements IPostListItem {



    HabitStatus HabitStatus;
    MyTask MyTask;
    public HabitStatus getHabitStatus() {
        return HabitStatus;
    }

    public void setHabitStatus(HabitStatus habitStatus) {
        HabitStatus = habitStatus;
    }

    public MyTask getMyTask() {
        return MyTask;
    }

    public void setMyTask(MyTask myTask) {
        MyTask = myTask;
    }
    public List<TodayTrackerValue> getTodayTrackerValues() {
        return todayTrackerValues;
    }

    public void setTodayTrackerValues(List<TodayTrackerValue> todayTrackerValues) {
        this.todayTrackerValues = todayTrackerValues;
    }

    List<TodayTrackerValue> todayTrackerValues;

    public List<TodayMyChallenge> getListTodayMyChallenge() {
        return listTodayMyChallenge;
    }

    public void setListTodayMyChallenge(List<TodayMyChallenge> listTodayMyChallenge) {
        this.listTodayMyChallenge = listTodayMyChallenge;
    }

    List<TodayMyChallenge> listTodayMyChallenge;

    @Override
    public int getPostListItemType() {
        return IPostListItem.TYPE_TODAY_DASHBOARD;
    }
}
