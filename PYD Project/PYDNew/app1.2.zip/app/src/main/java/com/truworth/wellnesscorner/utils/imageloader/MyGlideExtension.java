package com.truworth.wellnesscorner.utils.imageloader;

import com.bumptech.glide.annotation.GlideExtension;
import com.bumptech.glide.annotation.GlideOption;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.RequestOptions;
import com.truworth.wellnesscorner.R;


/**
 * If this code works, it was written by Somesh Kumar  on 01 December, 2017. If not, I don't know who wrote it.
 */
@GlideExtension
public class MyGlideExtension {
    private MyGlideExtension() {
    }

    @GlideOption
    public static RequestOptions profilePhoto(RequestOptions options) {
        return options
                .circleCrop()
                .diskCacheStrategy(DiskCacheStrategy.AUTOMATIC)
                .placeholder(R.drawable.image_hra_almost_done_image)
                .error(R.drawable.image_hra_almost_done_image);

    }

    @GlideOption
    public static RequestOptions largePhoto(RequestOptions options) {
        return options
                .fitCenter()
                .diskCacheStrategy(DiskCacheStrategy.AUTOMATIC)
                .placeholder(R.drawable.image_hra_almost_done_image)
                .error(R.drawable.image_hra_almost_done_image);
    }
}
