package com.twc.dailylog.model.response;

public class WaterTrackerDataResponse {


    private int status;
    private DataBean data;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public static class DataBean {
        private String NoOfWaterGlass;


        public String getNoOfWaterGlass() {
            return NoOfWaterGlass;
        }

        public void setNoOfWaterGlass(String noOfWaterGlass) {
            this.NoOfWaterGlass = noOfWaterGlass;
        }
    }
}
