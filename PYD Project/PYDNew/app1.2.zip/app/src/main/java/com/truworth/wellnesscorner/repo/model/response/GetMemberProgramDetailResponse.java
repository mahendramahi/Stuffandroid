package com.truworth.wellnesscorner.repo.model.response;

import com.truworth.wellnesscorner.model.MemberProgramdetailItem;

/**
 * Created by PalakC on 2/20/2018.
 */

public class GetMemberProgramDetailResponse {

  private int status;
    private MemberProgramdetailItem Data;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public MemberProgramdetailItem getData() {
        return Data;
    }

    public void setData(MemberProgramdetailItem Data) {
        this.Data = Data;
    }
}
