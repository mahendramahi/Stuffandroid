package com.truworth.wellnesscorner.ui.registration.registrationstepfourth;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import com.truworth.wellnesscorner.R;
import com.truworth.wellnesscorner.model.CountryData;

import java.util.ArrayList;

/**
 * Created by richas on 4/10/2018.
 */

public class ConfirmLocationAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private ArrayList<CountryData> locationItems;
    Context context;
    MyAdapterListener myAdapterListener;

    public ConfirmLocationAdapter(ArrayList<CountryData> locationItems, Context context, MyAdapterListener myAdapterListener) {

        this.locationItems = locationItems;
        this.context = context;
        this.myAdapterListener = myAdapterListener;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_bottom_sheet, parent, false);
        return new ViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        ViewHolder itemViewHolder = (ViewHolder) holder;

        itemViewHolder.tvItemName.setText(locationItems.get(position).getName());
    }

    @Override
    public int getItemCount() {
        return locationItems != null ? locationItems.size() : 0;
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        TextView tvItemName;

        public ViewHolder(View itemView) {
            super(itemView);
            tvItemName = itemView.findViewById(R.id.tvItemName);
            itemView.setOnClickListener(this);

        }
        @Override
        public void onClick(View view) {
            if (myAdapterListener != null) {
                myAdapterListener.onContainerClick(getAdapterPosition());
            }
        }
    }

}
