package com.twc.store.model.requestbody;

/**
 * Created by GurvinderS on 5/9/2017.
 */

public class CheckProductAvailableBody {

    private int Quantity;
    private String SKU;

    public int getQuantity() {
        return Quantity;
    }

    public void setQuantity(int quantity) {
        Quantity = quantity;
    }

    public String getSKU() {
        return SKU;
    }

    public void setSKU(String SKU) {
        this.SKU = SKU;
    }

}
