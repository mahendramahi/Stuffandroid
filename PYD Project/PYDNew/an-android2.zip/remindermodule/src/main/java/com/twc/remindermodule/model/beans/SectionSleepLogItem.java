package com.twc.remindermodule.model.beans;

import com.twc.remindermodule.model.response.GetSleepLogResponse;

import java.util.ArrayList;

/**
 * Created by richas on 1/18/2018.
 */

public class SectionSleepLogItem {

    private String monthName;
    private int nightsCount;
    private int averagePercent;
    private ArrayList<GetSleepLogResponse.DataSleepLogItem> mSleepLogArrayList;

    public String getMonthName() {
        return monthName;
    }

    public void setMonthName(String monthName) {
        this.monthName = monthName;
    }

    public int getNightsCount() {
        return nightsCount;
    }

    public void setNightsCount(int nightsCount) {
        this.nightsCount = nightsCount;
    }

    public int getAveragePercent() {
        return averagePercent;
    }

    public void setAveragePercent(int averagePercent) {
        this.averagePercent = averagePercent;
    }

    public ArrayList<GetSleepLogResponse.DataSleepLogItem> getmSleepLogArrayList() {
        return mSleepLogArrayList;
    }

    public void setmSleepLogArrayList(ArrayList<GetSleepLogResponse.DataSleepLogItem> mSleepLogArrayList) {
        this.mSleepLogArrayList = mSleepLogArrayList;
    }
}
