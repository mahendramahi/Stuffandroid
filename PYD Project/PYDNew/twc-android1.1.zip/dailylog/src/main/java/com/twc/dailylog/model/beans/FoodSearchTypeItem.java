package com.twc.dailylog.model.beans;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * Created by ManishJ1 on 5/27/2016.
 */
public class FoodSearchTypeItem {
    @SerializedName("FOODTYPE")
    @Expose
    private String foodType;
    @SerializedName("TOTALCOUNT")
    @Expose
    private Integer totalCount;

    public String getFoodType() {
        return foodType;
    }
    public void setFoodType(String foodType) {
        this.foodType = foodType;
    }

    public Integer getTotalCount() {
        return totalCount;
    }

    public void setTotalCount(Integer totalCount) {
        this.totalCount = totalCount;
    }
}
