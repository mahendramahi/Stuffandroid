package com.truworth.wellnesscorner.repo.model.request;

/**
 * Created by rajeshs on 4/9/2018.
 */

public class BMIRequest {
    String Weight;

    public String getHeight() {
        return Height;
    }

    public void setHeight(String height) {
        Height = height;
    }

    String Height;

    public String getWeight() {
        return Weight;
    }

    public void setWeight(String weight) {
        Weight = weight;
    }
}
