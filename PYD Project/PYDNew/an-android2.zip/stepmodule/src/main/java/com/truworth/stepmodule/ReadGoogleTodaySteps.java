package com.truworth.stepmodule;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.AsyncTask;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.fitness.Fitness;
import com.google.android.gms.fitness.FitnessActivities;
import com.google.android.gms.fitness.data.Bucket;
import com.google.android.gms.fitness.data.DataPoint;
import com.google.android.gms.fitness.data.DataSet;
import com.google.android.gms.fitness.data.DataType;
import com.google.android.gms.fitness.data.Field;
import com.google.android.gms.fitness.request.DataReadRequest;
import com.google.android.gms.fitness.result.DataReadResponse;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.Tasks;
import com.truworth.stepmodule.inteface.OnTodayStepsFound;
import com.truworth.stepmodule.model.StepItem;
import com.truworth.stepmodule.utils.Utils;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import static java.util.concurrent.TimeUnit.SECONDS;

/**
 * If this code works, it was written by Somesh Kumar  on 26 April, 2018. If not, I don't know who wrote it.
 */

@SuppressWarnings("ConstantConditions")
@SuppressLint("StaticFieldLeak")
public class ReadGoogleTodaySteps extends AsyncTask<Object, Object, ArrayList<StepItem>> {
    private static final String DATE_FORMAT_MM_DD_YYYY_HHMM_FORWARD_SLASH = "MM/dd/yyyy HH:mm:ss.SSS";
    private int totalSteps = 0;
    private int totalCalories = 0;
    private Context context;
    private OnTodayStepsFound onTodayStepsFound;
    private static final String DATE_FORMAT_YYYY_MM_DD = "yyyy-MM-dd";

    public ReadGoogleTodaySteps(Context context, OnTodayStepsFound onTodayStepsFound) {
        this.context = context;
        this.onTodayStepsFound = onTodayStepsFound;
    }

    protected ArrayList<StepItem> doInBackground(Object... params) {
        Task<DataSet> result = Fitness.getHistoryClient(context, GoogleSignIn.getLastSignedInAccount(context)).readDailyTotal(DataType.TYPE_STEP_COUNT_DELTA);
        // PendingResult<DailyTotalResult> caloriesResult = Fitness.HistoryApi.readDailyTotal(mGoogleApiClient, DataType.TYPE_CALORIES_EXPENDED);

        DataSet totalSet = null;
        try {
            totalSet = Tasks.await(result, 30, SECONDS);
            if (totalSet != null) {
                if (totalSet.isEmpty()) {
                    totalSteps = 0;
                } else {
                    List<DataPoint> dataPoints = totalSet.getDataPoints();
                    for (int i = 0; i < dataPoints.size(); i++) {
                        DataPoint dataPoint = dataPoints.get(i);
                        totalSteps = dataPoint.getValue(Field.FIELD_STEPS).asInt();
                    }
                }
            }

        } catch (ExecutionException | InterruptedException | TimeoutException e) {
            e.printStackTrace();
            if (onTodayStepsFound != null) {
                onTodayStepsFound.onTodayStepsError(e.getLocalizedMessage());
            }
        }

        // this code give today totalCalories
            /*DailyTotalResult caloriesTotalResult = caloriesResult.await(1L, TimeUnit.MINUTES);
            if (caloriesTotalResult.getStatus().isSuccess()) {
                DataSet totalSet = caloriesTotalResult.getTotal();
                if (totalSet != null) {
                    if (totalSet.isEmpty()) {
                        totalCalories = 0;
                    } else {
                        List<DataPoint> dataPoints = totalSet.getDataPoints();
                        for (int i = 0; i < dataPoints.size(); i++) {
                            DataPoint dataPoint = dataPoints.get(i);
                            totalCalories = Math.round(dataPoint.getValue(Field.FIELD_CALORIES).asFloat());
                        }
                    }
                }
            }*/

        // this code give today activeCalories
        Calendar cal = Calendar.getInstance();
        Date now = new Date();
        cal.setTime(now);
        long toMillisToday = cal.getTimeInMillis();
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        long fromMillisToday = cal.getTimeInMillis();
        DataReadRequest readCaloriesRequest = new DataReadRequest.Builder()
                .aggregate(DataType.TYPE_CALORIES_EXPENDED, DataType.AGGREGATE_CALORIES_EXPENDED)
                .bucketByActivitySegment(1, TimeUnit.MILLISECONDS)
                .setTimeRange(fromMillisToday, toMillisToday, TimeUnit.MILLISECONDS)
                .build();

        Task<DataReadResponse> dataReadCaloriesResult = Fitness.getHistoryClient(context, GoogleSignIn.getLastSignedInAccount(context)).readData(readCaloriesRequest);
        try {
            DataReadResponse dataReadResult = Tasks.await(dataReadCaloriesResult, 30, SECONDS);

            if (dataReadResult.getBuckets().size() > 0) {
                for (Bucket bucket : dataReadResult.getBuckets()) {
                    // System.out.println("bucket.getActivity====" + bucket.getActivity());
                    if (bucket.getActivity().contains(FitnessActivities.WALKING) || bucket.getActivity().contains(FitnessActivities.RUNNING) || bucket.getActivity().contains(FitnessActivities
                            .ON_FOOT)) {
                        List<DataSet> dataSets = bucket.getDataSets();
                        for (DataSet dataSet : dataSets) {
                            for (DataPoint dataPoint : dataSet.getDataPoints()) {
                                for (Field field : dataPoint.getDataType().getFields()) {
                                    if (field.getName().equalsIgnoreCase(Field.FIELD_CALORIES.getName())) {
                                        long startTime = dataPoint.getStartTime(TimeUnit.MILLISECONDS);
                                        long endTime = dataPoint.getEndTime(TimeUnit.MILLISECONDS);
                                        String startDate = Utils.getInstance().getDateFromMillis(startTime, DATE_FORMAT_YYYY_MM_DD);
                                        String endDate = Utils.getInstance().getDateFromMillis(endTime, DATE_FORMAT_YYYY_MM_DD);
                                        System.out.println("Start Date====" + startDate);
                                        System.out.println("End Date====" + endDate);
                                        System.out.println("Calories====" + String.valueOf(dataPoint.getValue(Field.FIELD_CALORIES)));
                                        // if line is commented, if we want to sync calories only if we get steps then we have to uncomment it
                                        //if(hashMap.get(startDate)!=null && hashMap.get(startDate).getStepTime().equals(startDate)) {
                                        String calories = String.valueOf(dataPoint.getValue(Field.FIELD_CALORIES));
                                        totalCalories += (int) Math.round(Double.parseDouble(calories));
                                    }

                                }
                            }
                        }
                    }
                }
            }
        } catch (ExecutionException | InterruptedException | TimeoutException e) {
            e.printStackTrace();
            if (onTodayStepsFound != null) {
                onTodayStepsFound.onTodayStepsError(e.getLocalizedMessage());
            }
        }
        String dateMillis = Utils.getInstance().getDateFromMillis(fromMillisToday, DATE_FORMAT_MM_DD_YYYY_HHMM_FORWARD_SLASH);

        StepItem stepItem = new StepItem();
        stepItem.setStepTime(dateMillis);
        stepItem.setCalories(totalCalories);
        stepItem.setStepCount(String.valueOf(totalSteps));
        ArrayList<StepItem> stepItemArrayList = new ArrayList<>();
        stepItemArrayList.add(stepItem);
        return stepItemArrayList;
    }

    public void onPostExecute(ArrayList<StepItem> stepItemArrayList) {
        super.onPostExecute(stepItemArrayList);
        if (onTodayStepsFound != null) {
            onTodayStepsFound.onTodayStepsFound(stepItemArrayList);
        }
    }
}