package com.truworth.wellnesscorner.repo.model.response;

import com.truworth.wellnesscorner.model.OnGoingChallengesBean;
import com.truworth.wellnesscorner.model.PreviousChallengesBean;

import java.util.List;

public class CircleChallengeResponse {

    private DataBean data;
    private boolean hasError;
    private Error error;

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public boolean isHasError() {
        return hasError;
    }

    public void setHasError(boolean hasError) {
        this.hasError = hasError;
    }

    public Object getError() {
        return error;
    }

    public void setError(Error error) {
        this.error = error;
    }

    public static class DataBean {
        private List<OnGoingChallengesBean> onGoingChallenges;
        private List<PreviousChallengesBean> previousChallenges;

        public List<OnGoingChallengesBean> getOnGoingChallenges() {
            return onGoingChallenges;
        }

        public void setOnGoingChallenges(List<OnGoingChallengesBean> onGoingChallenges) {
            this.onGoingChallenges = onGoingChallenges;
        }

        public List<PreviousChallengesBean> getPreviousChallenges() {
            return previousChallenges;
        }

        public void setPreviousChallenges(List<PreviousChallengesBean> previousChallenges) {
            this.previousChallenges = previousChallenges;
        }
    }
}
