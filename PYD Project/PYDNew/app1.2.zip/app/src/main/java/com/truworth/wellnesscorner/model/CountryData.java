package com.truworth.wellnesscorner.model;

/**
 * Created by rajeshs on 4/2/2018.
 */

public class CountryData {
    String id;
    String name;
    String phoneCode;
    String countryCode;
    public String getId() {
        return id;
    }

    public String getPhoneCode() {
        return "+"+phoneCode;
    }

    public void setPhoneCode(String phoneCode) {
        this.phoneCode = phoneCode;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    @Override
    public String toString() {
        return "+"+phoneCode;
    }
}
