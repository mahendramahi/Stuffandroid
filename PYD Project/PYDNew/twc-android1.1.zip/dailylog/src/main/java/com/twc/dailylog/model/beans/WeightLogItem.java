package com.twc.dailylog.model.beans;

public class WeightLogItem {

    public String getDate() {
        return Date;
    }

    public void setDate(String date) {
        Date = date;
    }

    public double getReading() {
        return Reading;
    }

    public void setReading(double reading) {
        Reading = reading;
    }

    public String getWeightUnit() {
        return WeightUnit;
    }

    public void setWeightUnit(String weightUnit) {
        WeightUnit = weightUnit;
    }

    private String Date;
    private double Reading;
    private String WeightUnit;


}
