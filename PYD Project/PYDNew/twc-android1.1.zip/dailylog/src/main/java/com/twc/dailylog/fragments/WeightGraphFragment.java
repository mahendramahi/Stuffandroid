package com.twc.dailylog.fragments;


import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.text.format.DateUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.github.mikephil.charting.animation.Easing;
import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.Description;
import com.github.mikephil.charting.components.LimitLine;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;

import com.twc.dailylog.R;
import com.twc.dailylog.R2;
import com.twc.dailylog.model.beans.WeightLogItem;
import com.twc.dailylog.model.requestbody.BaseMemberIdBody;
import com.twc.dailylog.model.response.WeightLogResponse;
import com.twc.dailylog.rest.RestClient;
import com.twc.dailylog.utils.DailyLogConfig;
import com.twc.dailylog.utils.DateFactory;
import com.twc.dailylog.utils.DialogFactory;
import com.twc.dailylog.utils.NetworkFactory;
import com.twc.dailylog.utils.Utils;
import com.twc.dailylog.views.LineChartMarkerView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class WeightGraphFragment extends BaseFragment {


    @BindView(R2.id.mLineChart)
    LineChart lineChart;

    @BindView(R2.id.rootView)
    LinearLayout rootView;

    @BindView(R2.id.tvYourWeight)
    TextView tvYourWeight;

    @BindView(R2.id.tvYourTargetWeight)
    TextView tvYourTargetWeight;

    @BindView(R2.id.tvWeightMaxValue)
    TextView tvWeightMaxValue;

    @BindView(R2.id.tvWeightMinValue)
    TextView tvWeightMinValue;

    @BindView(R2.id.tvWeightAvrgeValue)
    TextView tvWeightAverageValue;

    @BindView(R2.id.tvStartDate)
    TextView tvStartDate;

    @BindView(R2.id.tvEndDate)
    TextView tvEndDate;

    @BindView(R2.id.tvNoDataAvaiable)
    TextView tvNoDataAvailable;

    private ArrayList<WeightLogItem> weightItems;

    public static WeightGraphFragment newInstance(Bundle bundle) {
        WeightGraphFragment fragment = new WeightGraphFragment();
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        weightItems = new ArrayList<>();
    }

    @Override
    protected int getFragmentLayout() {
        return R.layout.fragment_weight_graph;
    }

    @Override
    protected void onFragmentReady() {

    }

    @Override
    public void onResume() {
    super.onResume();
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                weightLogApiCall();
            }
        },500);
    }


    private void setUpLineChart(List<WeightLogItem> data) {
        float totalWeight = 0;
        lineChart.setBackgroundColor(ContextCompat.getColor(getActivity(), R.color.color_FFFFFF));

        Description description = new Description();
        description.setEnabled(false);
        lineChart.setDescription(description);
        lineChart.setNoDataText("No data for the moment");
        lineChart.setTouchEnabled(true);
        lineChart.setDragEnabled(false);
        lineChart.setScaleEnabled(false);
        lineChart.setDrawGridBackground(false);
        lineChart.setPinchZoom(false);
        lineChart.getAxisLeft().setGridColor(ContextCompat.getColor(getActivity(), R.color.color_E3E6EA));
        lineChart.getAxisRight().setGridColor(ContextCompat.getColor(getActivity(), R.color.color_E3E6EA));
        lineChart.getAxisRight().setDrawAxisLine(false);
        lineChart.getAxisLeft().setDrawAxisLine(false);
        lineChart.getAxisRight().setDrawLabels(false);
        lineChart.getXAxis().setDrawGridLines(false);
        lineChart.getXAxis().setEnabled(false);
        LineChartMarkerView lineChartMarkerView = new LineChartMarkerView(getActivity(), R.layout.view_line_chart);
        lineChart.setMarker(lineChartMarkerView);

        /*if (WellnessCornerApp.getInstance().getMyDashboardResponse() != null && WellnessCornerApp.getInstance().getMyDashboardResponse().getData() != null && WellnessCornerApp.getInstance().getMyDashboardResponse().getData().getMemberInfo() != null) {
            float targetWeight = (float) WellnessCornerApp.getInstance().getMyDashboardResponse().getData().getMemberInfo().getMemberTargetWeight();
            LimitLine limitLine = new LimitLine(targetWeight);
            limitLine.setLineColor(ContextCompat.getColor(getActivity(), R.color.color_000000));
            limitLine.setLineWidth(0.5f);
            lineChart.getAxisLeft().addLimitLine(limitLine);
        }*/


        ArrayList<Entry> yAxisValues = new ArrayList<>();
        Collections.reverse(data);

        for (int index = 0; index < data.size(); index++) {
            double weight = data.get(index).getReading();
            String dateString = DateFactory.getInstance().truncateMilliseconds(data.get(index).getDate());
            String date = DateFactory.getInstance().formatDate("yyyy-MM-dd'T'HH:mm:ss", "MMM dd, yyyy", dateString);
            yAxisValues.add(new Entry(index, (float) weight, date));
            totalWeight += weight;
        }

        float averageWeight = totalWeight / (data.size());

        LineDataSet lineDataSet = new LineDataSet(yAxisValues, "Weight");
        lineDataSet.setLineWidth(1.2f);
        lineDataSet.setCircleRadius(4f);
        lineDataSet.setCircleHoleRadius(2.5f);
        lineDataSet.setColor(ContextCompat.getColor(getActivity(), R.color.color_45C4BA));
        lineDataSet.setCircleColor(ContextCompat.getColor(getActivity(), R.color.color_45C4BA));
        lineDataSet.setHighLightColor(ContextCompat.getColor(getActivity(), R.color.color_45C4BA));
        lineDataSet.setDrawValues(true);

        tvWeightMaxValue.setText(((int) lineDataSet.getYMax()) + " kg");
        tvWeightMinValue.setText(((int) (lineDataSet.getYMin())) + " kg");
        tvWeightAverageValue.setText(((int) averageWeight) + " kg");

        LineData lineData = new LineData(lineDataSet);
        lineData.setValueTextColor(ContextCompat.getColor(getActivity(), R.color.color_FFFFFF));

        lineChart.setData(lineData);
        lineChart.animateXY(1000, 500, Easing.EasingOption.EaseInExpo, Easing.EasingOption.EaseInExpo);

    }


    private void weightLogApiCall() {
        if (NetworkFactory.getInstance().isNetworkAvailable(getActivity())) {
            BaseMemberIdBody weightLogBody = new BaseMemberIdBody();
            //weightLogBody.setMemberID(WellnessCornerApp.getPreferenceManager().getUserId());

            RestClient restClient = new RestClient(getActivity(), DailyLogConfig.BASE_URL, DailyLogConfig.DEBUG);
            restClient.getWeightService().getWeight(weightLogBody).enqueue(new Callback<WeightLogResponse>() {
                @Override
                public void onResponse(Call<WeightLogResponse> call, Response<WeightLogResponse> response) {
                    if (isAdded() && getActivity() != null) {
                        if (response != null && response.body() != null) {
                            if (response.body().getStatus() == 0) {
                                if (response.body().getData() != null && response.body().getData().size() > 0) {
                                    setUpLineChart(response.body().getData());
                                    weightItems.clear();
                                    weightItems.addAll(response.body().getData());
                                    String startDate = (response.body().getData().get(weightItems.size() - 1).getDate());
                                    String formattedStartDate = DateFactory.getInstance().formatDate("yyyy-MM-dd", "dd/MM", startDate);
                                    String endDate = (response.body().getData().get(0).getDate());
                                    String formattedEndDate = DateFactory.getInstance().formatDate("yyyy-MM-dd", "dd/MM", endDate);
                                    tvStartDate.setText(formattedStartDate);
                                    tvEndDate.setText(formattedEndDate);
                                }
                            } else if (response.body().getStatus() == -1) {
                                DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_response_failure), getString(R.string.str_ok), false);
                            }
                        } else {
                            DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_response_null), getString(R.string.str_ok), false);
                        }
                    }
                }

                @Override
                public void onFailure(Call<WeightLogResponse> call, Throwable t) {
                    if (isAdded() && getActivity() != null) {
                        DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_failure), getString(R.string.str_ok), false);
                    }
                }
            });

        } else {
            Utils.showSnackBarMessage(rootView, getString(R.string.internet_not_available));
        }
    }

}

