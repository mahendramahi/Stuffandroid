package com.twc.dailylog.interfaces;

/**
 * Created by richas on 1/8/2018.
 */

public interface IContainerType {
    public void onChange();
}
