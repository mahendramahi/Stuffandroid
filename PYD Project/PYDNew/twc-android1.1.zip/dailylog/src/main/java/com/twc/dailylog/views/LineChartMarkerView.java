package com.twc.dailylog.views;

import android.content.Context;
import android.widget.TextView;

import com.github.mikephil.charting.components.MarkerView;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.highlight.Highlight;
import com.github.mikephil.charting.utils.MPPointF;
import com.twc.dailylog.R;

public class LineChartMarkerView extends MarkerView {
    private final TextView graphDate;
    private final TextView graphWeight;

    /**
     Constructor. Sets up the MarkerView with a custom layout resource.

     @param layoutResource the layout resource to use for the MarkerView
     */
    public LineChartMarkerView(Context context, int layoutResource) {
        super(context, layoutResource);
        graphDate = findViewById(R.id.graphDate);
        graphWeight = findViewById(R.id.graphWeight);
    }

    @Override
    public MPPointF getOffset() {
        return new MPPointF(-(getWidth() / 2), -getHeight());
    }

    @Override
    public void refreshContent(Entry e, Highlight highlight) {
        graphDate.setText(String.valueOf(e.getData().toString()));
        graphWeight.setText("(" + String.valueOf(e.getY()) + ")");
    }

}