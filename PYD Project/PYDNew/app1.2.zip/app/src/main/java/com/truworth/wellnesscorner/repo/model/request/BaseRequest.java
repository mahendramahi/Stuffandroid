package com.truworth.wellnesscorner.repo.model.request;

public class BaseRequest {

    private String Id;

    public String getId() {
        return Id;
    }

    public void setId(String Id) {
        this.Id = Id;
    }

}
