package com.twc.store.model.beans;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by PalakC on 9/13/2017.
 */

public class CartListItem implements Parcelable {

    public static final Creator<CartListItem> CREATOR = new Creator<CartListItem>() {
        @Override
        public CartListItem createFromParcel(Parcel source) {
            return new CartListItem(source);
        }

        @Override
        public CartListItem[] newArray(int size) {
            return new CartListItem[size];
        }
    };
    private int SCart_Id;
    private int SCart_MemberID;
    private int SCart_ProductCategoryID;
    private int SCart_ProductID;
    private String SCart_ProductName;
    private String SCart_ProductImage;
    private double SCart_TotalAmount;
    private double SCart_TaxAmount;
    private int SCart_Quantity;
    private boolean SCart_IsInStock;

    public int getSCart_ProductVendorID() {
        return SCart_ProductVendorID;
    }

    public void setSCart_ProductVendorID(int SCart_ProductVendorID) {
        this.SCart_ProductVendorID = SCart_ProductVendorID;
    }

    private int SCart_ProductVendorID;


    public CartListItem() {
    }

    protected CartListItem(Parcel in) {
        this.SCart_Id = in.readInt();
        this.SCart_MemberID = in.readInt();
        this.SCart_ProductCategoryID = in.readInt();
        this.SCart_ProductID = in.readInt();
        this.SCart_ProductName = in.readString();
        this.SCart_ProductImage = in.readString();
        this.SCart_TotalAmount = in.readDouble();
        this.SCart_TaxAmount = in.readDouble();
        this.SCart_Quantity = in.readInt();
        this.SCart_IsInStock = in.readByte() != 0;
        this.SCart_ProductVendorID = in.readInt();
    }

    public int getSCart_Id() {
        return SCart_Id;
    }

    public void setSCart_Id(int SCart_Id) {
        this.SCart_Id = SCart_Id;
    }

    public int getSCart_MemberID() {
        return SCart_MemberID;
    }

    public void setSCart_MemberID(int SCart_MemberID) {
        this.SCart_MemberID = SCart_MemberID;
    }

    public int getSCart_ProductCategoryID() {
        return SCart_ProductCategoryID;
    }

    public void setSCart_ProductCategoryID(int SCart_ProductCategoryID) {
        this.SCart_ProductCategoryID = SCart_ProductCategoryID;
    }

    public int getSCart_ProductID() {
        return SCart_ProductID;
    }

    public void setSCart_ProductID(int SCart_ProductID) {
        this.SCart_ProductID = SCart_ProductID;
    }

    public String getSCart_ProductName() {
        return SCart_ProductName;
    }

    public void setSCart_ProductName(String SCart_ProductName) {
        this.SCart_ProductName = SCart_ProductName;
    }

    public String getSCart_ProductImage() {
        return SCart_ProductImage;
    }

    public void setSCart_ProductImage(String SCart_ProductImage) {
        this.SCart_ProductImage = SCart_ProductImage;
    }

    public double getSCart_TotalAmount() {
        return SCart_TotalAmount;
    }

    public void setSCart_TotalAmount(double SCart_BasicPrice) {
        this.SCart_TotalAmount = SCart_BasicPrice;
    }

    public double getSCart_TaxAmount() {
        return SCart_TaxAmount;
    }

    public void setSCart_TaxAmount(double SCart_TaxAmount) {
        this.SCart_TaxAmount = SCart_TaxAmount;
    }

    public int getSCart_Quantity() {
        return SCart_Quantity;
    }

    public void setSCart_Quantity(int SCart_Quantity) {
        this.SCart_Quantity = SCart_Quantity;
    }

    public boolean isSCart_IsInStock() {
        return SCart_IsInStock;
    }

    public void setSCart_IsInStock(boolean SCart_IsInStock) {
        this.SCart_IsInStock = SCart_IsInStock;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(this.SCart_Id);
        dest.writeInt(this.SCart_MemberID);
        dest.writeInt(this.SCart_ProductCategoryID);
        dest.writeInt(this.SCart_ProductID);
        dest.writeString(this.SCart_ProductName);
        dest.writeString(this.SCart_ProductImage);
        dest.writeDouble(this.SCart_TotalAmount);
        dest.writeDouble(this.SCart_TaxAmount);
        dest.writeInt(this.SCart_Quantity);
        dest.writeByte(this.SCart_IsInStock ? (byte) 1 : (byte) 0);
        dest.writeInt(this.SCart_ProductVendorID);
    }
}
