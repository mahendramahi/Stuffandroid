package com.twc.store.adapter;

/**
 * Created by GurvinderS on 5/3/2017.
 */


import android.app.Activity;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.twc.store.GlideConfig;

import com.twc.store.R;
import com.twc.store.R2;
import com.twc.store.fragments.StoreProductDetailFragment;
import com.twc.store.model.beans.ProductItem;
import com.twc.store.utils.Utils;
import com.twc.store.views.CustomTextView;

import java.util.ArrayList;

import butterknife.BindView;
import butterknife.ButterKnife;

import static com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions.withCrossFade;


/**
 * Created by Gurvinder on 7/5/2016.
 */
public class WellnessProductListingAdapter extends RecyclerView.Adapter<WellnessProductListingAdapter.ItemViewHolder> {
    private final ArrayList<ProductItem> productList;
    private final String fromFragmentTitle;
    String tabName;
    private Activity context;

    public WellnessProductListingAdapter(Activity activity, ArrayList<ProductItem> productList, String fromFragmentTitle) {
        this.fromFragmentTitle = fromFragmentTitle;
        this.context = activity;
        this.productList = productList;
    }


    @Override
    public ItemViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_wellness_plans, parent, false);
        return new ItemViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(ItemViewHolder holder, int position) {
        ProductItem productItem = productList.get(position);
        holder.tvPlanName.setText(productItem.getName());
        holder.tvPlanDesc.setText(Utils.fromHtml(productItem.getDescription()));
        if(productItem.getSpecialPrice()==0.0){
            holder.tvBestPrice.setVisibility(View.INVISIBLE);
            holder.tvPrice.setText(Utils.getFormattedAmountManageZero(productItem.getPrice()));
        }
        else{
            holder.tvBestPrice.setVisibility(View.VISIBLE);
            holder.tvPrice.setText(Utils.getFormattedAmountManageZero(productItem.getSpecialPrice()));
        }

        holder.tvRating.setText(String.format("%s", productItem.getProductRating()));

        GlideConfig.getInstance().getImageLoader().load(productItem.getImage()).transition(withCrossFade()).into(holder.ivPlanImage);
    }


    @Override
    public int getItemCount() {
        return productList == null ? 0 : productList.size();
    }

    public class ItemViewHolder extends RecyclerView.ViewHolder {
        @BindView(R2.id.ivPlanImage)
        ImageView ivPlanImage;
        @BindView(R2.id.tvPlanName)
        CustomTextView tvPlanName;
        @BindView(R2.id.tvPlanDesc)
        CustomTextView tvPlanDesc;
        @BindView(R2.id.tvRating)
        CustomTextView tvRating;
        @BindView(R2.id.tvPrice)
        CustomTextView tvPrice;
        @BindView(R2.id.tvBuyNow)
        CustomTextView tvBuyNow;
        @BindView(R2.id.tvBestPrice)
        CustomTextView tvBestPrice;


        public ItemViewHolder(View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int productId=productList.get(getAdapterPosition()).getProductID();
                    String sku=productList.get(getAdapterPosition()).getSku();
                    Utils.replaceFragment(context.getFragmentManager(), StoreProductDetailFragment.newInstance(productId, sku,fromFragmentTitle), StoreProductDetailFragment.class.getSimpleName(), true, R.id.fragmentContainer);
                }
            });
        }
    }
}

