package com.truworth.wellnesscorner.ui.mainapp.circledetail.challenges;

import android.databinding.ObservableField;

import com.truworth.wellnesscorner.base.BaseViewModel;

public class ChallengeLeaderBoardViewModel extends BaseViewModel {
    ObservableField<String> imageUrl = new ObservableField<>();


}
