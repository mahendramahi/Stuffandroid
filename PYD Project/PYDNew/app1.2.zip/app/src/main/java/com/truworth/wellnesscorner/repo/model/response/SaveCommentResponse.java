package com.truworth.wellnesscorner.repo.model.response;

import com.truworth.wellnesscorner.model.SaveCommentData;

import java.lang.Error;

public class SaveCommentResponse {

    private SaveCommentData data;
    private boolean hasError;
    private Error error;

    public SaveCommentData getData() {
        return data;
    }

    public void setData(SaveCommentData data) {
        this.data = data;
    }

    public boolean isHasError() {
        return hasError;
    }

    public void setHasError(boolean hasError) {
        this.hasError = hasError;
    }

    public Error getError() {
        return error;
    }

    public void setError(Error error) {
        this.error = error;
    }


}
