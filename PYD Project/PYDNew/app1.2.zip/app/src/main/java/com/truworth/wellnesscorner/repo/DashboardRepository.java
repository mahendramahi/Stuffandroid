package com.truworth.wellnesscorner.repo;

import com.truworth.wellnesscorner.network.ApiServices;
import com.truworth.wellnesscorner.repo.model.request.ChallengeLeaderBoardRequest;
import com.truworth.wellnesscorner.repo.model.request.CircleChallengeRequest;
import com.truworth.wellnesscorner.repo.model.request.BaseRequest;
import com.truworth.wellnesscorner.repo.model.request.CircleDetailPostRequest;
import com.truworth.wellnesscorner.repo.model.request.CircleMemberRequest;
import com.truworth.wellnesscorner.repo.model.request.CirclePostsRequest;
import com.truworth.wellnesscorner.repo.model.request.CommentHiFiveRequest;
import com.truworth.wellnesscorner.repo.model.request.CommentRequest;
import com.truworth.wellnesscorner.repo.model.request.EventCheckInRequest;
import com.truworth.wellnesscorner.repo.model.request.GetCommentsListRequest;
import com.truworth.wellnesscorner.repo.model.request.MyRankRequest;
import com.truworth.wellnesscorner.repo.model.request.PostHiFiRequest;
import com.truworth.wellnesscorner.repo.model.request.ShareDashboardRequest;
import com.truworth.wellnesscorner.repo.model.request.ShareMealRequest;
import com.truworth.wellnesscorner.repo.model.request.TodayChallengeRequest;
import com.truworth.wellnesscorner.repo.model.request.TodayPostsRequest;
import com.truworth.wellnesscorner.repo.model.request.TodayTrackerRequest;
import com.truworth.wellnesscorner.repo.model.response.ChallengeLeaderBoardResponse;
import com.truworth.wellnesscorner.repo.model.response.CircleAboutResponse;
import com.truworth.wellnesscorner.repo.model.response.CircleChallengeResponse;
import com.truworth.wellnesscorner.repo.model.response.CircleCoachResponse;
import com.truworth.wellnesscorner.repo.model.response.CircleMembersResponse;
import com.truworth.wellnesscorner.repo.model.response.CircleResponse;
import com.truworth.wellnesscorner.repo.model.response.EventCheckInResponse;
import com.truworth.wellnesscorner.repo.model.response.GetCommentsListResponse;
import com.truworth.wellnesscorner.repo.model.response.GetJoinCircleResponse;
import com.truworth.wellnesscorner.repo.model.response.MyCirclesResponse;
import com.truworth.wellnesscorner.repo.model.response.MyRankResponse;
import com.truworth.wellnesscorner.repo.model.response.PopularArticlesResponse;
import com.truworth.wellnesscorner.repo.model.response.PopularCircleResponse;
import com.truworth.wellnesscorner.repo.model.response.PopularDiscussionsResponse;
import com.truworth.wellnesscorner.repo.model.response.PopularProductResponse;
import com.truworth.wellnesscorner.repo.model.response.PostHiFiResponse;
import com.truworth.wellnesscorner.repo.model.response.PostResponse;
import com.truworth.wellnesscorner.repo.model.response.SaveCommentResponse;
import com.truworth.wellnesscorner.repo.model.response.ShareDashboardResponse;
import com.truworth.wellnesscorner.repo.model.response.ShareMealNewResponse;
import com.truworth.wellnesscorner.repo.model.response.ShareMealResponse;
import com.truworth.wellnesscorner.repo.model.response.ShareStepsResponse;
import com.truworth.wellnesscorner.repo.model.response.TodayMyChallengesResponse;
import com.truworth.wellnesscorner.repo.model.response.TodayTrackerResponse;

import javax.inject.Inject;
import javax.inject.Singleton;

import io.reactivex.Observable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.schedulers.Schedulers;

/**
 * Created by rajeshs on 4/13/2018.
 */
@Singleton
public class DashboardRepository {
    private final ApiServices apiService;

    @Inject
    public DashboardRepository(ApiServices apiService) {
        this.apiService = apiService;
    }

    public Observable<MyCirclesResponse> getMyCircles() {
        return apiService.getMyCircles()
                .subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread());
    }

    public Observable<PopularCircleResponse> getPopularCircles() {
        return apiService.getPopularCircles()
                .subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread());
    }

    public Observable<PopularProductResponse> getPopularProducts() {
        return apiService.getPopularProducts()
                .subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread());
    }

    public Observable<PopularArticlesResponse> getPopularArticles() {
        return apiService.getPopularArticles()
                .subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread());
    }

    public Observable<PopularDiscussionsResponse> getPopularDiscussions() {
        return apiService.getPopularDiscussions()
                .subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread());
    }

    public Observable<CircleCoachResponse> getCircleCoaches(BaseRequest circleCoachRequest) {
        return apiService.getCircleCoaches(circleCoachRequest)
                .subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread());
    }

    public Observable<CircleMembersResponse> getCircleMembers(CircleMemberRequest circleMemberRequest) {
        return apiService.getCircleMembers(circleMemberRequest)
                .subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread());
    }

    public Observable<TodayTrackerResponse> getTodayTracker(TodayTrackerRequest todayTrackerRequest) {
        return apiService.getTodayTracker(todayTrackerRequest)
                .subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread());
    }

    public Observable<TodayMyChallengesResponse> getTodayMyChallenges(TodayChallengeRequest todayChallengeRequest) {
        return apiService.getTodayMyChallenges(todayChallengeRequest)
                .subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread());
    }


    public Observable<PostResponse> getTodayPosts(TodayPostsRequest todayPostsRequest) {
        return apiService.getTodayPost(todayPostsRequest)
                .subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread());
    }

    public Observable<PostResponse> getCirclePosts(CirclePostsRequest circlePostRequest) {
        return apiService.getCirclePosts(circlePostRequest)
                .subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread());
    }

    public Observable<CircleResponse> getCirclePosts(BaseRequest circleCoachRequest) {
        return apiService.getCircleDetail(circleCoachRequest)
                .subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread());
    }

    public Observable<CircleChallengeResponse> getCircleChallenges(CircleChallengeRequest circleChallengeRequest) {
        return apiService.getCircleChallenges(circleChallengeRequest)
                .subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread());
    }

    public Observable<CircleAboutResponse> getCircleAboutDetails(BaseRequest circleCoachRequest) {
        return apiService.getCircleAboutDetails(circleCoachRequest)
                .subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread());
    }

    public Observable<PostHiFiResponse> getPostHiFi(BaseRequest postHiFiRequest) {
        return apiService.getPostHiFi(postHiFiRequest)
                .subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread());
    }

    public Observable<ChallengeLeaderBoardResponse> getLeaderBoardData(ChallengeLeaderBoardRequest challengeLeaderBoardRequest) {
        return apiService.getLeaderBoardData(challengeLeaderBoardRequest)
                .subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread());
    }

    public Observable<EventCheckInResponse> getEventCheckIn(EventCheckInRequest checkInRequest) {
        return apiService.getEventCheckIn(checkInRequest)
                .subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread());
    }

    public Observable<SaveCommentResponse> saveComment(CommentRequest commentRequest) {
        return apiService.saveComment(commentRequest)
                .subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread());
    }

    public Observable<GetCommentsListResponse> getComments(GetCommentsListRequest getCommentsListRequest) {
        return apiService.getCommentsList(getCommentsListRequest)
                .subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread());
    }

    public Observable<PostHiFiResponse> getCommentHiFi(BaseRequest hiFiveRequest) {
        return apiService.getCommentHiFi(hiFiveRequest)
                .subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread());
    }

    public Observable<PostResponse> getCirclePostWithPaging(CircleDetailPostRequest circleDetailPostRequest) {
        return apiService.getCirclePostsWithPaging(circleDetailPostRequest)
                .subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread());
    }

    public Observable<MyRankResponse> getMyRank(MyRankRequest myRankRequest) {
        return apiService.getMyRank(myRankRequest)
                .subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread());
    }

    public Observable<ShareDashboardResponse> getPostDashboard(ShareDashboardRequest shareDashboardRequest) {
        return apiService.getPostDashboard(shareDashboardRequest)
                .subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread());
    }

    public Observable<ShareStepsResponse> getPostSteps(ShareDashboardRequest shareDashboardRequest) {
        return apiService.getPostSteps(shareDashboardRequest)
                .subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread());
    }

    public Observable<ShareMealNewResponse> getPostMeal(ShareMealRequest shareMealRequest) {
        return apiService.getPostMeal(shareMealRequest)
                .subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread());
    }

    public Observable<GetJoinCircleResponse> getJoinCircle(BaseRequest baseRequest) {
        return apiService.getJoinCircle(baseRequest)
                .subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread());
    }
}
