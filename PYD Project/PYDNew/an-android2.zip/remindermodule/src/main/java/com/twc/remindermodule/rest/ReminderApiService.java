package com.twc.remindermodule.rest;



import com.twc.remindermodule.model.requestbody.BaseMemberIdBody;
import com.twc.remindermodule.model.requestbody.GetSleepLogBody;
import com.twc.remindermodule.model.requestbody.HealthyHabitBody;
import com.twc.remindermodule.model.requestbody.SaveHabitReminderBody;
import com.twc.remindermodule.model.requestbody.SaveHabitValueBody;
import com.twc.remindermodule.model.requestbody.SaveMemberHabitBody;
import com.twc.remindermodule.model.requestbody.SaveSleepLogBody;
import com.twc.remindermodule.model.response.BaseResponse;
import com.twc.remindermodule.model.response.GetSleepLogResponse;
import com.twc.remindermodule.model.response.HabitReminderResponse;
import com.twc.remindermodule.model.response.HealthyHabitResponse;
import com.twc.remindermodule.model.response.MyHabitResponse;
import com.twc.remindermodule.model.response.SaveHabitReminderResponse;
import com.twc.remindermodule.model.response.SaveMemberHabitResponse;
import com.twc.remindermodule.model.response.SaveSleepLogResponse;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;


public interface ReminderApiService {

    @POST("member/Habit/GetMemberGoalHabit")
    Call<HealthyHabitResponse> getMemberGoalHabit(@Body HealthyHabitBody healthyHabitBody);

    @POST("member/Habit/GetHabitReminder")
    Call<HabitReminderResponse> getHabitReminder(@Body BaseMemberIdBody baseMemberIdBody);

    @POST("member/Habit/SaveMemberHabitReminder")
    Call<SaveHabitReminderResponse> saveHabitReminder(@Body SaveHabitReminderBody baseMemberIdBody);

    @POST("member/Habit/SaveMemberHabit")
    Call<SaveMemberHabitResponse> saveMemberHabit(@Body SaveMemberHabitBody saveMemberHabitBody);

    @POST("member/Habit/GetMemberHabitWeeklyStatus")
    Call<MyHabitResponse> getMemberHabitWeeklyStatus(@Body HealthyHabitBody healthyHabitBody);

    @POST("member/Habit/SaveMemberHabitValue")
    Call<BaseResponse> saveMemberHabitValue(@Body SaveHabitValueBody saveHabitValueBody);

    // sleep service
    @POST("member/tracker/SaveSleepLog")
    Call<SaveSleepLogResponse> saveSleepLogTracker(@Body SaveSleepLogBody saveSleepLogBody);

    @POST("member/tracker/GetSleepLog")
    Call<GetSleepLogResponse> getSleepLogTracker(@Body GetSleepLogBody getSleepLogBody);

}
