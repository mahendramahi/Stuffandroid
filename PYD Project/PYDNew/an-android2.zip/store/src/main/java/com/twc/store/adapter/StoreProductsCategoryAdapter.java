package com.twc.store.adapter;

import android.app.Activity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;


import com.twc.store.R;
import com.twc.store.R2;
import com.twc.store.fragments.StoreProductListingFragment;
import com.twc.store.model.beans.ProductItem;
import com.twc.store.model.beans.StoreDataBeanItem;
import com.twc.store.utils.Utils;
import com.twc.store.views.CustomTextView;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * Created by PalakC on 7/10/2017.
 */

public class StoreProductsCategoryAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private final int VIEW_TYPE_CATEGORY = 0;
    private final int VIEW_TYPE_PLAN_TYPE = 1;
    private ArrayList<StoreDataBeanItem> storeDataBeanItems;
    private Activity mActivity;

    public StoreProductsCategoryAdapter(ArrayList<StoreDataBeanItem> storeDataBeanItems, Activity mActivity) {
        this.storeDataBeanItems = storeDataBeanItems;
        this.mActivity = mActivity;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        RecyclerView.ViewHolder viewHolder = null;
        View itemView;
        switch (viewType) {
            case VIEW_TYPE_CATEGORY:
                itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_store_all_category, parent, false);
                viewHolder = new ItemViewHolder(itemView);
                break;
            case VIEW_TYPE_PLAN_TYPE:
                itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_store_all_category, parent, false);
                viewHolder = new ItemViewHolder(itemView);
                break;
        }
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, final int position) {
        final ItemViewHolder itemViewHolder = (ItemViewHolder) holder;
        switch (holder.getItemViewType()) {
            case VIEW_TYPE_CATEGORY:
                itemViewHolder.tvCategoryName.setText(storeDataBeanItems.get(position).getCategoryName());

                List<ProductItem> list = storeDataBeanItems.get(position).getProduct();
                if (storeDataBeanItems.get(position).getCategoryId() != 1) {
                    StoreHealthProductAdapter healthProductAdapter = new StoreHealthProductAdapter(mActivity, list);
                    RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(mActivity, LinearLayoutManager.HORIZONTAL, false);
                    itemViewHolder.rvCategoryProducts.setLayoutManager(layoutManager);
                    itemViewHolder.rvCategoryProducts.setAdapter(healthProductAdapter);
                } else {
                    StoreWellnessPlanAdapter wellnessPlanAdapter = new StoreWellnessPlanAdapter(mActivity, list);
                    RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(mActivity);
                    itemViewHolder.rvCategoryProducts.setLayoutManager(layoutManager);
                    itemViewHolder.rvCategoryProducts.setAdapter(wellnessPlanAdapter);
                }
                break;
            case VIEW_TYPE_PLAN_TYPE:
                    itemViewHolder.tvCategoryName.setVisibility(View.GONE);
                    itemViewHolder.tvViewAll.setVisibility(View.GONE);

                    List<Integer> planTypeImageList = new ArrayList<>();
                    planTypeImageList.add(R.drawable.ic_store_healthy_plans);
                    planTypeImageList.add(R.drawable.ic_store_gym_membership);

                    StorePlanTypesAdapter storePlanTypesAdapter = new StorePlanTypesAdapter(mActivity, planTypeImageList);
                    RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(mActivity, LinearLayoutManager.HORIZONTAL, false);
                    itemViewHolder.rvCategoryProducts.setLayoutManager(layoutManager);
                    itemViewHolder.rvCategoryProducts.setAdapter(storePlanTypesAdapter);
                break;
        }

    }

    @Override
    public int getItemViewType(int position) {
        if (storeDataBeanItems.get(position).getCategoryId() !=-1)
            return VIEW_TYPE_CATEGORY;
        else
            return VIEW_TYPE_PLAN_TYPE;
    }

    @Override
    public int getItemCount() {
        return (null != storeDataBeanItems ? storeDataBeanItems.size() : 0);
    }

    public class ItemViewHolder extends RecyclerView.ViewHolder {

        @BindView(R2.id.tvCategoryName)
        CustomTextView tvCategoryName;
        @BindView(R2.id.rvCategoryProducts)
        RecyclerView rvCategoryProducts;
        @BindView(R2.id.tvViewAll)
        CustomTextView tvViewAll;


        public ItemViewHolder(View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);

            tvViewAll.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                 Utils.replaceFragment(mActivity.getFragmentManager(), StoreProductListingFragment.newInstance(storeDataBeanItems.get(getAdapterPosition()).getCategoryName(), (ArrayList<ProductItem>) storeDataBeanItems.get(getAdapterPosition()).getProduct()), StoreProductListingFragment.class.getSimpleName(), true, R.id.fragmentContainer);
                }
            });
        }
    }
}
