package com.truworth.wellnesscorner.ui.mainapp.circle;

import android.databinding.ObservableBoolean;
import android.databinding.ObservableField;

import com.truworth.wellnesscorner.base.BaseViewModel;
import com.truworth.wellnesscorner.model.Article;

/**
 * Created by rajeshs on 4/17/2018.
 */

public class ArticleItemViewModel extends BaseViewModel {
    Article article;
    public ArticleListener articleListener;
    public ObservableBoolean isRating = new ObservableBoolean();
    public ObservableField<String> ratingValue = new ObservableField<>();

    public ArticleItemViewModel(Article article,ArticleListener articleListener) {
        this.article = article;
        this.articleListener=articleListener;
    }

    public Article getArticle() {
        return article;
    }

    public void onItemClick() {
        articleListener.onItemClick();
    }

    public interface ArticleListener {
        void onItemClick();
    }
    public void getRating() {
        if (article.getRating() > 0) {
            ratingValue.set(String.valueOf(article.getRating()));
            isRating.set(true);
        } else
            isRating.set(false);
    }

}
