package com.truworth.wellnesscorner.ui.registration.registrationstepfifth;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.content.DialogInterface;
import android.content.Intent;
import android.databinding.DataBindingUtil;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;

import com.karumi.dexter.Dexter;
import com.karumi.dexter.MultiplePermissionsReport;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.multi.MultiplePermissionsListener;
import com.transloadit.sdk.async.AssemblyProgressListener;
import com.transloadit.sdk.response.AssemblyResponse;
import com.truworth.wellnesscorner.R;
import com.truworth.wellnesscorner.customviews.CircularImageView;
import com.truworth.wellnesscorner.databinding.FragmentEditProfileBinding;
import com.truworth.wellnesscorner.ui.registration.registrationstepsixth.HealthGoalFragment;
import com.truworth.wellnesscorner.utils.AppConstants;
import com.truworth.wellnesscorner.utils.CameraGalleryChooser;
import com.truworth.wellnesscorner.utils.CameraGalleryUtil;
import com.truworth.wellnesscorner.utils.CompressImage;
import com.truworth.wellnesscorner.utils.DateUtils;
import com.truworth.wellnesscorner.utils.Utils;
import com.truworth.wellnesscorner.utils.fileuploader.FileUploader;

import java.io.File;
import java.util.List;

/**
 * Created by GurvinderS on 4/9/2018.
 */

public class EditProfileFragment extends Fragment implements AssemblyProgressListener {

    public static final String TAG = "EditProfileFragment";

    EditProfileViewModel viewModel;
    private CameraGalleryUtil cameraGalleryUtil;
    static Fragment mfragment;
    private CircularImageView ivUserImage;
    private FragmentEditProfileBinding binding;
    private FileUploader fileUploader;
    private String todayDate, ext;
    private Uri profileImageUri;

    public static EditProfileFragment newInstance() {
        EditProfileFragment fragment = new EditProfileFragment();
        mfragment = (Fragment) fragment;
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getActivity().getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE | WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        cameraGalleryUtil = new CameraGalleryUtil(getActivity(), mfragment);
        fileUploader = new FileUploader(getActivity(), (AssemblyProgressListener) this);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        binding = DataBindingUtil.inflate(inflater, R.layout.fragment_edit_profile, container, false);
        viewModel = ViewModelProviders.of(this).get(EditProfileViewModel.class);
        ivUserImage = binding.getRoot().findViewById(R.id.ivUserImage);
        binding.setViewModel(viewModel);
        attachFileChooserObserver();
        attachBioCharCountObserver();
        return binding.getRoot();
    }

    private void attachFileChooserObserver() {
        viewModel.getcallDialogChooser().observe(this, new Observer<Void>() {
            @Override
            public void onChanged(@Nullable Void aVoid) {

                CameraGalleryChooser.selectImageProfile(getActivity(), cameraGalleryUtil);
            }
        });
        viewModel.getOnContinue().observe(this, new Observer<Void>() {
            @Override
            public void onChanged(@Nullable Void aVoid) {
                openHealthGoals();
            }
        });

        viewModel.getContinueClick().observe(this, new Observer<Void>() {
            @Override
            public void onChanged(@Nullable Void aVoid) {
                if(profileImageUri!=null){
                    viewModel.isProgress.set(true);
                    fileUploader.submitAssembly(profileImageUri, todayDate, ext, true);
                }else{
                    viewModel.saveProfileData();
                }
            }
        });
    }


    @Override
    public void onResume() {
        super.onResume();
        if(profileImageUri!=null)
            ivUserImage.setImageURI(profileImageUri);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode == Activity.RESULT_OK) {
            todayDate = DateUtils.getTodayDate("yyyyMMddHHmmss");
            Uri selectedImage;
            if (requestCode == AppConstants.CAMERA_REQUEST) {
                if (cameraGalleryUtil.getCameraFilePath() != null) {

                    File file = new File(cameraGalleryUtil.getCameraFilePath());
                    Uri myuri = Uri.fromFile(file);
                    CallCropActivityIntent(myuri);
                }
            } else if (requestCode == AppConstants.GALLERY_REQUEST && data != null && data.getData() != null) {
                selectedImage = data.getData();
                CallCropActivityIntent(selectedImage);
            } else if (requestCode == AppConstants.CROPPED_IMAGE_REQUEST && data != null && data.getData() != null) {
                Uri cropped_image_uri = data.getData();
                ivUserImage.setImageURI(cropped_image_uri);
                String filePath = cameraGalleryUtil.getPath(getActivity(), cropped_image_uri);
                CompressImage.compress(filePath);
                profileImageUri = Uri.fromFile(new File(filePath));
              // setData(filePath);
                 ext = filePath.substring(filePath.lastIndexOf(".") + 1);


            }
        } else {
            // Image not selected
            // Utils.showToast(getActivity(), "File Not Select");
        }
    }

    private void CallCropActivityIntent(Uri myuri) {
        Intent imageCrop = new Intent(getActivity(), CropActivity.class);
        imageCrop.putExtra("Image", myuri.toString());
        imageCrop.putExtra("CropShape", "CIRCLE");
        startActivityForResult(imageCrop, AppConstants.CROPPED_IMAGE_REQUEST);
    }

    public void setData(String filePath) {
        String imgBytes = cameraGalleryUtil.getByteString(filePath);
        String ext = filePath.substring(filePath.lastIndexOf(".") + 1);
        viewModel.setImage(imgBytes);
        viewModel.setImageExtension(ext);
    }

    private void attachBioCharCountObserver() {
        viewModel.getSetBioCharCount().observe(this, new Observer<Void>() {
            @Override
            public void onChanged(@Nullable Void aVoid) {
                binding.tvLetterCount.setText(viewModel.bioCharCount + "/150");
            }
        });
    }

    public void openHealthGoals() {
        //FragmentUtils.removeAllFragmentFromStack((AppCompatActivity) getActivity());
        getActivity().getSupportFragmentManager().beginTransaction().replace(R.id.registerContainer, new HealthGoalFragment(), HealthGoalFragment.TAG).addToBackStack(HealthGoalFragment.TAG).commit();
    }

    @Override
    public void onUploadFinished() {

    }

    @Override
    public void onUploadPogress(long uploadedBytes, long totalBytes) {

    }

    @Override
    public void onAssemblyFinished(AssemblyResponse response) {
        if (response != null && response.isCompleted()) {
            viewModel.isProgress.set(false);
            viewModel.setImage(todayDate +"."+ ext);
            viewModel.saveProfileData();
        }
    }

    @Override
    public void onUploadFailed(Exception exception) {
        viewModel.isProgress.set(false);
        viewModel.setImage("");
        viewModel.setImageExtension("");
    }

    @Override
    public void onAssemblyStatusUpdateFailed(Exception exception) {

    }
}
