package com.twc.dailylog.model.requestbody;

/**
 * Created by PalakC on 8/9/2016.
 */
public class SaveTargetWeightBody {

    //private String MemberID;
    private String Reading;

   /* public String getMemberID() {
        return MemberID;
    }

    public void setMemberID(String memberID) {
        MemberID = memberID;
    }*/

    public String getReading() {
        return Reading;
    }

    public void setReading(String reading) {
        Reading = reading;
    }


}
