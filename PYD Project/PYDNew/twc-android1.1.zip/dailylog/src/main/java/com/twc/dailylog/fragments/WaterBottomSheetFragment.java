package com.twc.dailylog.fragments;

import android.os.Bundle;
import android.os.Handler;
import android.support.design.widget.BottomSheetDialogFragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;


import com.twc.dailylog.R;
import com.twc.dailylog.R2;
import com.twc.dailylog.interfaces.IContainerType;
import com.twc.dailylog.utils.Constant;
import com.twc.dailylog.utils.WaterConfig;
import com.twc.dailylog.views.CustomTextView;


import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import butterknife.Unbinder;

/**
 * Created by richas on 1/8/2018.
 */

public class WaterBottomSheetFragment extends BottomSheetDialogFragment {

  private Unbinder unbinder;
    private IContainerType iContainerType;
    @BindView(R2.id.rlGlass)
    RelativeLayout rlGlass;
    @BindView(R2.id.rlBottle)
    RelativeLayout rlBottle;
    @BindView(R2.id.ivCheckBottle)
    ImageView ivCheckBottle;
    @BindView(R2.id.ivCheckGlass)
    ImageView ivCheckGlass;
    @BindView(R2.id.tvGlassTxt)
    CustomTextView tvGlassTxt;
    @BindView(R2.id.tvGlassMeasure)
    CustomTextView tvGlassMeasure;
    @BindView(R2.id.tvBottleTxt)
    CustomTextView tvBottleTxt;
    @BindView(R2.id.tvBottleMeasure)
    CustomTextView tvBottleMeasure;

    public WaterBottomSheetFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.water_bottom_sheet_fragment, container, false);
        unbinder = ButterKnife.bind(this, view);
        return view;
    }

    @Override
    public void onResume() {
        super.onResume();

        if (WaterConfig.containerType.equalsIgnoreCase(Constant.GLASS)) {
            ivCheckGlass.setVisibility(View.VISIBLE);
            tvGlassTxt.setTextColor(getActivity().getResources().getColor(R.color.color_000000));
            tvGlassMeasure.setTextColor(getActivity().getResources().getColor(R.color.color_000000));
            ivCheckBottle.setVisibility(View.INVISIBLE);
            tvBottleTxt.setTextColor(getActivity().getResources().getColor(R.color.color_d4d4d4));
            tvBottleMeasure.setTextColor(getActivity().getResources().getColor(R.color.color_d4d4d4));
        } else {
            ivCheckBottle.setVisibility(View.VISIBLE);
            tvBottleTxt.setTextColor(getActivity().getResources().getColor(R.color.color_000000));
            tvBottleMeasure.setTextColor(getActivity().getResources().getColor(R.color.color_000000));
            ivCheckGlass.setVisibility(View.INVISIBLE);
            tvGlassTxt.setTextColor(getActivity().getResources().getColor(R.color.color_d4d4d4));
            tvGlassMeasure.setTextColor(getActivity().getResources().getColor(R.color.color_d4d4d4));
        }
    }

    @OnClick({R2.id.rlGlass, R2.id.rlBottle})
    public void onClick(View view) {
        if(view.getId()==R.id.rlGlass) {

            ivCheckGlass.setVisibility(View.VISIBLE);
            tvGlassTxt.setTextColor(getActivity().getResources().getColor(R.color.color_000000));
            tvGlassMeasure.setTextColor(getActivity().getResources().getColor(R.color.color_000000));
            ivCheckBottle.setVisibility(View.INVISIBLE);
            tvBottleTxt.setTextColor(getActivity().getResources().getColor(R.color.color_d4d4d4));
            tvBottleMeasure.setTextColor(getActivity().getResources().getColor(R.color.color_d4d4d4));


            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {

                    if (!WaterConfig.containerType.equalsIgnoreCase(Constant.GLASS)) {
                       // WellnessCornerApp.getPreferenceManager().setWaterContainer(Constant.GLASS);
                        WaterConfig.containerType=Constant.GLASS;
                        iContainerType.onChange();
                    }
                    dismiss();

                }
            }, 500);
        }
        else if(view.getId()==R.id.rlBottle) {
            ivCheckBottle.setVisibility(View.VISIBLE);
            tvBottleTxt.setTextColor(getActivity().getResources().getColor(R.color.color_000000));
            tvBottleMeasure.setTextColor(getActivity().getResources().getColor(R.color.color_000000));
            ivCheckGlass.setVisibility(View.INVISIBLE);
            tvGlassTxt.setTextColor(getActivity().getResources().getColor(R.color.color_d4d4d4));
            tvGlassMeasure.setTextColor(getActivity().getResources().getColor(R.color.color_d4d4d4));

            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (!WaterConfig.containerType.equalsIgnoreCase(Constant.BOTTLE)) {
                      //  WellnessCornerApp.getPreferenceManager().setWaterContainer(Constant.BOTTLE);
                        WaterConfig.containerType=Constant.BOTTLE;
                        iContainerType.onChange();
                    }
                    dismiss();

                }
            }, 500);
        }


    }

    public void setCallBack(IContainerType containerType) {
        iContainerType = containerType;
    }

}
