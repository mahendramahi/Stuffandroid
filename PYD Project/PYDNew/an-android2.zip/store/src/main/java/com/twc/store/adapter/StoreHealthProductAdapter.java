package com.twc.store.adapter;

import android.app.Activity;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.twc.store.GlideConfig;

import com.twc.store.R;
import com.twc.store.R2;
import com.twc.store.fragments.StoreProductDetailFragment;
import com.twc.store.model.beans.ProductItem;
import com.twc.store.utils.Constant;
import com.twc.store.utils.Utils;
import com.twc.store.views.CustomTextView;

import java.text.MessageFormat;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

import static com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions.withCrossFade;


public class StoreHealthProductAdapter extends RecyclerView.Adapter<StoreHealthProductAdapter.HealthProductHolder> {

    private final List<ProductItem> healthProductList;
    private final Activity context;

    public StoreHealthProductAdapter(Activity activity, List<ProductItem> healthProductList) {
        this.healthProductList = healthProductList;
        this.context = activity;
    }

    @Override
    public HealthProductHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_store_health_products, parent, false);
        return new HealthProductHolder(itemView);
    }

    @Override
    public void onBindViewHolder(HealthProductHolder holder, int position) {
        holder.tvHealthProductTitle.setText(healthProductList.get(position).getName());
        holder.tvRating.setText(String.valueOf(healthProductList.get(position).getProductRating()));
        if (healthProductList.get(position).getSpecialPrice() == 0.0) {
            holder.tvHealthProductBestPrice.setText(MessageFormat.format("{0}{1}", context.getString(R.string.rupee_symbol), Utils.getFormattedAmountManageZero(healthProductList.get(position).getPrice())));
            holder.lblBestPrice.setVisibility(View.INVISIBLE);
            holder.ivBestPrice.setVisibility(View.INVISIBLE);
        }
        else {
            holder.tvHealthProductBestPrice.setText(MessageFormat.format("{0}{1}", context.getString(R.string.rupee_symbol), Utils.getFormattedAmountManageZero(healthProductList.get(position).getSpecialPrice())));
        }
     GlideConfig.getInstance().getImageLoader().load(healthProductList.get(position).getImage()) .transition(withCrossFade()).into(holder.ivHealthProduct);

    }


    @Override
    public int getItemCount() {
        if (healthProductList == null) {
            return 0;
        }
        else {
            return healthProductList.size() > 0 && healthProductList.size() < 4 ? healthProductList.size() : 4;
        }
    }


    class HealthProductHolder extends RecyclerView.ViewHolder {
        @BindView(R2.id.ivHealthProduct)
        ImageView ivHealthProduct;
        @BindView(R2.id.tvRating)
        CustomTextView tvRating;
        @BindView(R2.id.tvHealthProductTitle)
        CustomTextView tvHealthProductTitle;
        @BindView(R2.id.tvHealthProductBestPrice)
        CustomTextView tvHealthProductBestPrice;
        @BindView(R2.id.lblBestPrice)
        CustomTextView lblBestPrice;
        @BindView(R2.id.ivBestPrice)
        ImageView ivBestPrice;

        HealthProductHolder(View view) {
            super(view);
            ButterKnife.bind(this, view);
            view.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int productId = healthProductList.get(getAdapterPosition()).getProductID();
                    String sku = healthProductList.get(getAdapterPosition()).getSku();
                    Utils.replaceFragment(context.getFragmentManager(), StoreProductDetailFragment.newInstance(productId, sku, Constant.HEALTH_PRODUCT), StoreProductDetailFragment.class.getSimpleName(), true, R.id.fragmentContainer);
                }
            });
        }
    }
}
