package com.twc.dailylog.adapter;

import android.app.Activity;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.afollestad.sectionedrecyclerview.SectionedRecyclerViewAdapter;
import com.twc.dailylog.R;
import com.twc.dailylog.fragments.AddFoodFragment;
import com.twc.dailylog.model.beans.FoodItem;
import com.twc.dailylog.model.beans.SectionItem;
import com.twc.dailylog.utils.DateFactory;
import com.twc.dailylog.utils.Utils;

import java.util.ArrayList;

/**
 * Created by ManishJ1 on 7/5/2016.
 */
public class TrackMealSectionAdapter extends SectionedRecyclerViewAdapter<RecyclerView.ViewHolder> {

    private ArrayList<SectionItem> sectionItems;
    private Activity activity;

    public TrackMealSectionAdapter(ArrayList<SectionItem> sectionItems,Activity activity) {
        this.sectionItems = sectionItems;
        this.activity = activity;
    }

    @Override
    public int getSectionCount() {
        return sectionItems.size();
    }

    @Override
    public int getItemCount(int section) {
        return sectionItems.get(section).getFoodItemArrayList().size();
    }

    @Override
    public void onBindHeaderViewHolder(RecyclerView.ViewHolder holder, int section) {
        String sectionName = sectionItems.get(section).getSectionName();
        SectionViewHolder sectionViewHolder = (SectionViewHolder) holder;

        // recent food header
        if(!sectionName.contains("Option"))
            sectionViewHolder.tvFoodHeader.setText(DateFactory.getInstance().formatDate("yyyyMMdd","MM/dd/yyyy",sectionName)+"");
        else //diet plan header
            sectionViewHolder.tvFoodHeader.setText(sectionName);


    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int section, int relativePosition, int absolutePosition) {
        ArrayList<FoodItem> foodItems = sectionItems.get(section).getFoodItemArrayList();

        ItemViewHolder itemViewHolder = (ItemViewHolder) holder;
        itemViewHolder.tvFoodName.setText(foodItems.get(relativePosition).getFoodName());
        itemViewHolder.tvFoodData.setText(foodItems.get(relativePosition).getQuantity() + " " + foodItems.get(relativePosition).getStandardServing() + " "+foodItems.get(relativePosition).getCalories()+" Calories");
        itemViewHolder.tvFoodName.setTag(section);
        itemViewHolder.tvFoodData.setTag(relativePosition);
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View v;
        if (viewType == VIEW_TYPE_HEADER) {
            v = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.row_trackmeal_diet_plan_header, parent, false);
            return new SectionViewHolder(v);
        } else {
            v = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.row_trackmeal_diet_paln, parent, false);
            return new ItemViewHolder(v);
        }
    }

    // SectionViewHolder Class for Sections
    public class SectionViewHolder extends RecyclerView.ViewHolder {


        final TextView tvFoodHeader;

        public SectionViewHolder(View itemView) {
            super(itemView);
            tvFoodHeader = itemView.findViewById(R.id.tvFoodHeader);
        }
    }

    // ItemViewHolder Class for Items in each Section
    public class ItemViewHolder extends RecyclerView.ViewHolder {

        final TextView tvFoodName;
        final TextView tvFoodData;

        public ItemViewHolder(View itemView) {
            super(itemView);
            tvFoodName = itemView.findViewById(R.id.tvFoodName);
            tvFoodData = itemView.findViewById(R.id.tvFoodData);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int section = Integer.parseInt(tvFoodName.getTag().toString());
                    int relativePosition = Integer.parseInt(tvFoodData.getTag().toString());
                    FoodItem foodItem = sectionItems.get(section).getFoodItemArrayList().get(relativePosition);
                    Bundle bundle = new Bundle();
                    bundle.putInt("foodId",foodItem.getFoodID());
                    //bundle.putInt("nutritionId",foodItem.getNutritionId());
                    bundle.putInt("nutritionId",0);
                    double quantity = 0.0;
                    try {
                        quantity = Double.parseDouble(foodItem.getQuantity());
                    }
                    catch (ArithmeticException e){
                        quantity = 0.0;
                    }
                    bundle.putDouble("quantity",quantity);
                    Utils.replaceFragment(activity.getFragmentManager(), AddFoodFragment.newInstance(bundle),AddFoodFragment.class.getSimpleName(),true,R.id.fragmentContainerMeal);
                }
            });
        }
    }
}
