package com.truworth.wellnesscorner.ui.step;

/**
 * Created by ManishJ1 on 2/23/2017.
 */

public class StepsBean {

    private String StepsDate;
    private String ActivityDate;
    private int Calories;
    private int Steps;

    public String getStepsDate() {
        return StepsDate;
    }

    public void setStepsDate(String StepsDate) {
        this.StepsDate = StepsDate;
    }

    public int getSteps() {
        return Steps;
    }

    public void setSteps(int Steps) {
        this.Steps = Steps;
    }

    public int getCalories() {
        return Calories;
    }

    public void setCalories(int calories) {
        Calories = calories;
    }

    public String getActivityDate() {
        return ActivityDate;
    }

    public void setActivityDate(String activityDate) {
        ActivityDate = activityDate;
    }
}
