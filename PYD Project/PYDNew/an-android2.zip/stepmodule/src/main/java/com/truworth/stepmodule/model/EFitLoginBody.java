package com.truworth.stepmodule.model;

import com.google.gson.annotations.SerializedName;

/**
 * If this code works it was written by Somesh Kumar on 13 January, 2017. If not, I don't know who wrote it.
 */
public class EFitLoginBody {
    @SerializedName("loginid")
    private String loginId;
    private String password;

    public String getLoginId() {
        return loginId;
    }

    public void setLoginId(String loginId) {
        this.loginId = loginId;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
