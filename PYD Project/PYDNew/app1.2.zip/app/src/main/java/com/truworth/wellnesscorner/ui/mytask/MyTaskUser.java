package com.truworth.wellnesscorner.ui.mytask;

public class MyTaskUser {
    private String userID;
    private String accessToken;

    public MyTaskUser() {

    }
    public MyTaskUser(String userID, String accessToken) {
        this.userID = userID;
        this.accessToken = accessToken;
    }
    public String getAccessToken() {
        return accessToken;
    }

    public void setAccessToken(String accessToken) {
        this.accessToken = accessToken;
    }

    public String getUserID() {
        return userID;
    }

    public void setUserID(String userID) {
        this.userID = userID;
    }
}
