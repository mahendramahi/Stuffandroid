package com.twc.remindermodule.model.response;


import com.twc.remindermodule.model.beans.HabitReminderBean;

import java.util.List;

/**
 * Created by GurvinderS on 9/21/2017.
 */

public class HabitReminderResponse {

    private int status;
    private List<HabitReminderBean> Data;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public List<HabitReminderBean> getData() {
        return Data;
    }

    public void setData(List<HabitReminderBean> Data) {
        this.Data = Data;
    }


}
