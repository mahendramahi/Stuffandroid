package com.twc.store.model.beans;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.List;

/**
 * If this code works it was written by Somesh Kumar on 04 May, 2017. If not, I don't know who wrote it.
 */
public class ProductItem implements Parcelable {


    public static final Creator<ProductItem> CREATOR = new Creator<ProductItem>() {
        @Override
        public ProductItem createFromParcel(Parcel source) {
            return new ProductItem(source);
        }

        @Override
        public ProductItem[] newArray(int size) {
            return new ProductItem[size];
        }
    };
    /**
     * ProductID : 4
     * Name : Truworth Diamond Prima Glucometer with 25 Strips (Red)
     * Duration : 0
     * Description : Truworth Diamond Prima is a world class blood sugar testing device, with all the International Certifications Truworth Diamond Prima is at par with all the International Brands.
     * LongDescription : Truworth Diamond Prima is a world class blood sugar testing device, with all the International Certifications Truworth Diamond Prima is at par with all the International Brands.
     * ProductRating : 4.0
     * Price : 2099.0
     * SpecialPrice : 0.0
     * SpecialFromDate :
     * SpecialToDate :
     * InStock : 1
     * Images : [{"url":"https://healthybenefits.in/media/catalog/product/4/1/41_gxsoyrnl.jpg"}]
     * VendorName : MegentoHealthStore
     * ApiStoreName :
     * Sku : 003
     * APIStoreID : 0
     * IsPurchased : false
     * Category : HEALTHPRODUCT
     */

    private int ProductID;
    private String Name;
    private int Duration;
    private String Description;
    private String LongDescription;
    private double ProductRating;
    private double Price;

    private String SpecialFromDate;
    private String SpecialToDate;
    private boolean InStock;
    private List<ImagesBean> Images;
    private String VendorName;
    private String ApiStoreName;
    private String Sku;
    private String Image;
    private int APIStoreID;
    private boolean IsPurchased;
    private String Category;
    private String CategoryId;
    private double TaxAmount;


    private int VendorId;
    //private double TotalPrice;
    private double SpecialPrice;

    public ProductItem() {
    }

    protected ProductItem(Parcel in) {
        this.ProductID = in.readInt();
        this.Name = in.readString();
        this.Duration = in.readInt();
        this.Description = in.readString();
        this.LongDescription = in.readString();
        this.ProductRating = in.readDouble();
        this.Price = in.readDouble();
        this.SpecialPrice = in.readDouble();
        this.SpecialFromDate = in.readString();
        this.SpecialToDate = in.readString();
        this.InStock = in.readByte() != 0;
        this.Images = in.createTypedArrayList(ImagesBean.CREATOR);
        this.VendorName = in.readString();
        this.ApiStoreName = in.readString();
        this.Sku = in.readString();
        this.Image = in.readString();
        this.APIStoreID = in.readInt();
        this.IsPurchased = in.readByte() != 0;
        this.Category = in.readString();
        this.CategoryId = in.readString();
        this.TaxAmount = in.readDouble();
       // this.TotalPrice = in.readDouble();
        this.SpecialPrice = in.readDouble();
        this.VendorId = in.readInt();

    }

    public int getProductID() {
        return ProductID;
    }

    public void setProductID(int ProductID) {
        this.ProductID = ProductID;
    }

    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public int getDuration() {
        return Duration;
    }

    public void setDuration(int Duration) {
        this.Duration = Duration;
    }

    public String getDescription() {
        return Description;
    }

    public void setDescription(String Description) {
        this.Description = Description;
    }

    public String getLongDescription() {
        return LongDescription;
    }

    public void setLongDescription(String LongDescription) {
        this.LongDescription = LongDescription;
    }

    public double getProductRating() {
        return ProductRating;
    }

    public void setProductRating(double ProductRating) {
        this.ProductRating = ProductRating;
    }

    public double getPrice() {
        return Price;
    }

    public void setPrice(double Price) {
        this.Price = Price;
    }

    public double getSpecialPrice() {
        return SpecialPrice;
    }

    public void setSpecialPrice(double SpecialPrice) {
        this.SpecialPrice = SpecialPrice;
    }

    public String getSpecialFromDate() {
        return SpecialFromDate;
    }

    public void setSpecialFromDate(String SpecialFromDate) {
        this.SpecialFromDate = SpecialFromDate;
    }

    public String getSpecialToDate() {
        return SpecialToDate;
    }

    public void setSpecialToDate(String SpecialToDate) {
        this.SpecialToDate = SpecialToDate;
    }

    public boolean getInStock() {
        return InStock;
    }

    public void setInStock(boolean InStock) {
        this.InStock = InStock;
    }

    public String getVendorName() {
        return VendorName;
    }

    public void setVendorName(String VendorName) {
        this.VendorName = VendorName;
    }

    public String getApiStoreName() {
        return ApiStoreName;
    }

    public void setApiStoreName(String ApiStoreName) {
        this.ApiStoreName = ApiStoreName;
    }

    public String getSku() {
        return Sku;
    }

    public void setSku(String Sku) {
        this.Sku = Sku;
    }

    public int getAPIStoreID() {
        return APIStoreID;
    }

    public void setAPIStoreID(int APIStoreID) {
        this.APIStoreID = APIStoreID;
    }

    public boolean isIsPurchased() {
        return IsPurchased;
    }

    public void setIsPurchased(boolean IsPurchased) {
        this.IsPurchased = IsPurchased;
    }

    public String getCategory() {
        return Category;
    }

    public void setCategory(String Category) {
        this.Category = Category;
    }

    public List<ImagesBean> getImages() {
        return Images;
    }

    public void setImages(List<ImagesBean> Images) {
        this.Images = Images;
    }

    public String getImage() {
        return Image;
    }

    public void setImage(String image) {
        Image = image;
    }

    public double getTaxAmount() {
        return TaxAmount;
    }

    public void setTaxAmount(double taxAmount) {
        TaxAmount = taxAmount;
    }
    public int getVendorId() {
        return VendorId;
    }

    public void setVendorId(int vendorId) {
        VendorId = vendorId;
    }

    public String getCategoryId() {
        return CategoryId;
    }
  /*  public double getTotalPrice() {
        return TotalPrice;
    }

    public void setTotalPrice(double totalPrice) {
        TotalPrice = totalPrice;
    }*/


    @Override
    public int describeContents() {
        return 0;
    }

    public void setCategoryId(String categoryId) {
        CategoryId = categoryId;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(this.ProductID);
        dest.writeString(this.Name);
        dest.writeInt(this.Duration);
        dest.writeString(this.Description);
        dest.writeString(this.LongDescription);
        dest.writeDouble(this.ProductRating);
        dest.writeDouble(this.Price);
        dest.writeDouble(this.SpecialPrice);
        dest.writeString(this.SpecialFromDate);
        dest.writeString(this.SpecialToDate);
        dest.writeByte(this.InStock ? (byte) 1 : (byte) 0);
        dest.writeTypedList(this.Images);
        dest.writeString(this.VendorName);
        dest.writeString(this.ApiStoreName);
        dest.writeString(this.Sku);
        dest.writeString(this.Image);
        dest.writeInt(this.APIStoreID);
        dest.writeByte(this.IsPurchased ? (byte) 1 : (byte) 0);
        dest.writeString(this.Category);
        dest.writeString(this.CategoryId);
        dest.writeDouble(this.TaxAmount);
        dest.writeInt(this.VendorId);
       // dest.writeDouble(this.TotalPrice);

    }

    public static class ImagesBean implements Parcelable {
        public static final Creator<ImagesBean> CREATOR = new Creator<ImagesBean>() {
            @Override
            public ImagesBean createFromParcel(Parcel source) {
                return new ImagesBean(source);
            }

            @Override
            public ImagesBean[] newArray(int size) {
                return new ImagesBean[size];
            }
        };
        /**
         * url : https://healthybenefits.in/media/catalog/product/4/1/41_gxsoyrnl.jpg
         */

        private String url;

        public ImagesBean() {
        }

        protected ImagesBean(Parcel in) {
            this.url = in.readString();
        }

        public String getUrl() {
            return url;
        }

        @Override
        public void writeToParcel(Parcel dest, int flags) {
            dest.writeString(this.url);
        }

        public void setUrl(String url) {
            this.url = url;
        }

        @Override
        public int describeContents() {
            return 0;
        }


    }


}