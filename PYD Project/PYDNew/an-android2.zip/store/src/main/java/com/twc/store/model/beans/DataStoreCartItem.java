package com.twc.store.model.beans;

import java.util.List;

/**
 * Created by PalakC on 9/13/2017.
 */

public class DataStoreCartItem {


        private double Wellcash;
        private List<CartListItem> CartList;

        public double getWellcashDiscount() {
            return Wellcash;
        }

        public void setWellcashDiscount(double WellcashDiscount) {
            this.Wellcash = WellcashDiscount;
        }

        public List<CartListItem> getCartList() {
            return CartList;
        }

        public void setCartList(List<CartListItem> CartList) {
            this.CartList = CartList;
        }



}
