package com.truworth.wellnesscorner.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * Created by rajeshs on 3/29/2018.
 */

public class Token {

    @SerializedName("validTo")
    @Expose
    private String validTo;
    @SerializedName("value")
    @Expose
    private String value;

    public String getValidTo() {
        return validTo;
    }

    public void setValidTo(String validTo) {
        this.validTo = validTo;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

}
