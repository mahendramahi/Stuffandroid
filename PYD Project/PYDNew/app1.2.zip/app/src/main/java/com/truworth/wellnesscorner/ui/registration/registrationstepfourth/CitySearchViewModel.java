package com.truworth.wellnesscorner.ui.registration.registrationstepfourth;

import android.databinding.ObservableField;
import android.text.Editable;
import android.text.TextWatcher;

import com.truworth.wellnesscorner.TheWellnessCornerApp;
import com.truworth.wellnesscorner.base.BaseViewModel;
import com.truworth.wellnesscorner.model.CityStateCountryData;
import com.truworth.wellnesscorner.repo.LoginRepository;
import com.truworth.wellnesscorner.repo.model.request.GetCountryStateByCityNameRequest;
import com.truworth.wellnesscorner.repo.model.response.GetCountryStateByCityNameResponse;
import com.truworth.wellnesscorner.utils.SingleLiveEvent;

import java.util.ArrayList;

import javax.inject.Inject;

import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;

/**
 * Created by richas on 4/12/2018.
 */

public class CitySearchViewModel extends BaseViewModel {

    public ObservableField<String> city = new ObservableField<>();
    public final ArrayList<CityStateCountryData> addressData = new ArrayList<>();
    SingleLiveEvent<Void> showCityStateCountryList = new SingleLiveEvent<>();

    public CitySearchViewModel() {
        TheWellnessCornerApp.getApp().component().inject(this);
    }

    public void setCity(String city) {
        this.city.set(city);
    }

    @Inject
    LoginRepository repository;

    private void loadSearchCitiesData(String cityName) {
        //setIsLoading(true);
        GetCountryStateByCityNameRequest getCountryStateByCityNameRequest = new GetCountryStateByCityNameRequest();
        getCountryStateByCityNameRequest.setName(cityName);

        repository.getCountryStateList(getCountryStateByCityNameRequest).subscribe(new Observer<GetCountryStateByCityNameResponse>() {

            @Override
            public void onSubscribe(Disposable d) {

            }

            @Override
            public void onNext(GetCountryStateByCityNameResponse getCountryStateByCityNameResponse) {
                if (!getCountryStateByCityNameResponse.isHasError()) {
                    addressData.clear();
                    addressData.addAll(getCountryStateByCityNameResponse.getData());
                    showCityStateCountryList.call();
                }
            }

            @Override
            public void onError(Throwable e) {

            }

            @Override
            public void onComplete() {
                //setIsLoading(false);
            }
        });
    }

    public ArrayList<CityStateCountryData> getAddressData() {
        return addressData;
    }

    public SingleLiveEvent<Void> getCityStateCountryList() {
        return showCityStateCountryList;
    }


    public TextWatcher cityWatcher() {
        return new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if (charSequence.length() >= 3) {
                    loadSearchCitiesData(charSequence.toString());
                }else if(charSequence.length() == 0) {
                    addressData.clear();
                    showCityStateCountryList.call();
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        };
    }

    SingleLiveEvent<Void> onBackPressed = new SingleLiveEvent<>();

    public SingleLiveEvent<Void> getOnBackPressed() {
        return onBackPressed;
    }

    public void onBack() {
        onBackPressed.call();
    }

}
