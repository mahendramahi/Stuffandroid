package com.twc.hramodule.utils;


import android.util.Log;

import com.twc.hramodule.model.beans.HraUser;

/**
 * If this code works, it was written by Somesh Kumar  on 27 November, 2017. If not, I don't know who wrote it.
 */

public class HraConfig {
    public static String BASE_URL = "http://192.168.1.91:9003/twcapi/";// default testing url
    public static String APP_NAME = ""; //
    public static boolean DEBUG;
    public static HraUser hraUser = new HraUser();

    /**
     * @param appName
     * @param apiBaseUrl
     * @param user
     */
    public static void init(String appName, String apiBaseUrl, HraUser user,boolean debug) {
        if (!appName.isEmpty() && !apiBaseUrl.isEmpty() && user != null) {
            BASE_URL = apiBaseUrl;
            APP_NAME = appName;
            hraUser = user;
            DEBUG = debug;
        } else {
            Log.d("HRA", "init: " + apiBaseUrl);
            Log.d("HRA", "init: failed hralib. Please all fields of init.");
        }
    }

}
