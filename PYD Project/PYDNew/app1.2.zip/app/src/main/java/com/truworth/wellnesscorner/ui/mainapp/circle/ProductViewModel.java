package com.truworth.wellnesscorner.ui.mainapp.circle;

import android.databinding.ObservableBoolean;
import android.databinding.ObservableField;

import com.truworth.wellnesscorner.base.BaseViewModel;
import com.truworth.wellnesscorner.model.PopularProduct;

/**
 * Created by rajeshs on 4/16/2018.
 */

public class ProductViewModel extends BaseViewModel {
    public ProductListener productListener;
    public ObservableBoolean isRating = new ObservableBoolean();
    public ObservableField<String> ratingValue = new ObservableField<>();
    PopularProduct product;

    public ProductViewModel(PopularProduct product, ProductListener productListener) {
        this.product = product;
        this.productListener = productListener;
    }

    public PopularProduct getProduct() {
        return product;
    }

    public void setProduct(PopularProduct product) {
        this.product = product;
    }

    public void onItemClick() {
        productListener.onItemClick();
    }

    public void getRating() {
        if (product.getProductRating() > 0) {
            ratingValue.set(String.valueOf(product.getProductRating()));
            isRating.set(true);
        } else
            isRating.set(false);
    }

    public long getPrice() {
        return Math.round(product.getPrice());
    }

    public interface ProductListener {
        void onItemClick();
    }
}
