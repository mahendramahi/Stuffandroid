package com.truworth.wellnesscorner.ui.mainapp.createpost.shareexercise;

import android.databinding.ObservableField;
import android.text.SpannableStringBuilder;

import com.truworth.wellnesscorner.TheWellnessCornerApp;
import com.truworth.wellnesscorner.base.BaseViewModel;
import com.truworth.wellnesscorner.data.SharedPreferenceHelper;
import com.truworth.wellnesscorner.model.ExerciseData;
import com.truworth.wellnesscorner.utils.SingleLiveEvent;
import com.truworth.wellnesscorner.utils.Utils;

import javax.inject.Inject;

public class ShareExerciseViewModel extends BaseViewModel {
    public ObservableField<String> userName = new ObservableField<>();
    public ObservableField<String> userImage = new ObservableField<>();
    public ObservableField<String> date = new ObservableField<>();
    public ObservableField<String> exerciseName = new ObservableField<>();
    public ObservableField<SpannableStringBuilder> duration = new ObservableField<>();
    public ObservableField<SpannableStringBuilder> calories = new ObservableField<>();
    public ObservableField<SpannableStringBuilder> imageLables = new ObservableField<>();
    SingleLiveEvent<Void> cameraBtnClick = new SingleLiveEvent<>();
    SingleLiveEvent<Void> defaultImgClick = new SingleLiveEvent<>();
    SingleLiveEvent<Void> shareBtnClick = new SingleLiveEvent<>();
    @Inject
    SharedPreferenceHelper prefHelper;
    ExerciseData exerciseData;
    private String dateString;

    public ShareExerciseViewModel() {
        TheWellnessCornerApp.getApp().component().inject(this);
    }

    public SingleLiveEvent<Void> getCameraBtnClick() {
        return cameraBtnClick;
    }

    public SingleLiveEvent<Void> getDefaultImgClick() {
        return defaultImgClick;
    }

    public SingleLiveEvent<Void> getShareBtnClick() {
        return shareBtnClick;
    }

    public void getData(ExerciseData exerciseData, String dateString) {
        this.exerciseData = exerciseData;
        this.dateString = dateString;
        setData();
    }

    public void setData() {
        if (prefHelper.getFirstName() != null)
            userName.set(prefHelper.getFirstName() + "'s Workout");
        userImage.set(prefHelper.getPrefKeyImageUrl());
        exerciseName.set(exerciseData.getName());
        date.set(dateString);
        SpannableStringBuilder calValue = Utils.makeSpecificTextBoldSize((String.valueOf((int) exerciseData.getCalorie()) + "\ncals burned"), String.valueOf((int) exerciseData.getCalorie()), 2f);
        calories.set(calValue);

        SpannableStringBuilder durationValue = Utils.makeSpecificTextBoldSize((String.valueOf((int) exerciseData.getDuration()) + " minutes"), String.valueOf((int) exerciseData.getDuration()), 2f);
        duration.set(durationValue);

        SpannableStringBuilder value = Utils.makeSpecificTextBoldSize(("Duration - " + (String.valueOf((int) exerciseData.getDuration())) + " mins,  Calories Burned - " + (String.valueOf((int) exerciseData.getCalorie()))+" kcal"), ("Duration - " + ",  Calories Burned - "),1f);
        imageLables.set(value);
    }


    public void cameraBtnClick() {

        cameraBtnClick.call();
    }

    public void defaultImageClick() {

        defaultImgClick.call();
    }

    public void onShareClicked() {
        shareBtnClick.call();
    }
}
