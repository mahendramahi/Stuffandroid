package com.truworth.wellnesscorner.ui.mobileverification;

import android.app.Activity;
import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Intent;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;

import com.truworth.wellnesscorner.R;
import com.truworth.wellnesscorner.databinding.FragmentCountrycodeListBinding;
import com.truworth.wellnesscorner.ui.registration.registrationstepfourth.MyAdapterListener;

public class CountryCodeListActivity extends AppCompatActivity {
    public static final String TAG = "CountryCodeList";
    CountryListViewModel viewModel;
    FragmentCountrycodeListBinding binding;
    private CountryListAdapter adapter;
    private MyAdapterListener addressListener = new MyAdapterListener() {
        @Override
        public void onContainerClick(int position) {
            String selectedPhoneCode = viewModel.countryData.get(position).getPhoneCode();
            String selectedCountryCode = viewModel.countryData.get(position).getCountryCode();

            Intent returnIntent = new Intent();
            returnIntent.putExtra("phoneCode", selectedPhoneCode);
            returnIntent.putExtra("countryCode", selectedCountryCode);
            setResult(Activity.RESULT_OK, returnIntent);
            finish();
        }
    };

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        String city = getIntent().getStringExtra("CITY");

        binding = DataBindingUtil.setContentView(this, R.layout.fragment_countrycode_list);
        viewModel = ViewModelProviders.of(this).get(CountryListViewModel.class);
        binding.setViewModel(viewModel);
        adapter = new CountryListAdapter(viewModel.getCountryData(),addressListener);
        binding.rvCountryList.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));
        binding.rvCountryList.setAdapter(adapter);

        viewModel.loadCountryCode();
        setCountryList();
        setCountryFilterList();

    }
    private void setCountryList() {
        viewModel.getCountryList().observe(this, new Observer<Void>() {
            @Override
            public void onChanged(@Nullable Void aVoid) {
                adapter.notifyDataSetChanged();
            }
        });
    }

    private void setCountryFilterList() {
        viewModel.getCountryFilterList().observe(this, new Observer<CharSequence>() {
            @Override
            public void onChanged(@Nullable CharSequence charSequence) {
                adapter.getFilter().filter(charSequence.toString());
            }
        });
    }

}
