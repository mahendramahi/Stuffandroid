package com.truworth.wellnesscorner.repo.model.request;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.truworth.wellnesscorner.model.MobileInfo;

import java.io.Serializable;

/**
 * Created by rajeshs on 4/3/2018.
 */

public class SaveMemberRequest implements Serializable {
//
//    "FirstName":"Sunil",
//            "LastName":"Kumar",
//            "Email":"bNzNMccPoSCwO3ZTF8N9SDyAiz/HaU0t2cGj4SoTAf830eK8JXwl/NqNlHwFpdV+JRrPTLCN16VLjVeTK1I73dEwJ9b4mLCPj21JmfQFZrT9/0M3FxSpbai10tEkdydW0JxZ9i4owvP1a4QSuVABWG2TB4XXOMnvJLJdNIWR3I8=",
//            "Gender":"M",
//            "Password":"e+e3rYRt80Vruf+Q1JINc3s46Na7U6Mt9KFFD7T73jYoEbzIF89Z4j1ZluuQAqZSl9T97IXHGZttfys5rz07utLEAxF/r10zWBhY033w/FeVt174Gi/oZz1aHwrfGJumLUmaj+y9pUev2IOooHDdU3SagEgyUrnw6x6DMxzalwk=",
//            "DateOfBirth":"1990-01-09 15:05:29.117"

    String FirstName;
    String LastName;
    String Email;
    String Gender;
    String Password;
    String DateOfBirth;

    public MobileInfo getMobileInfo() {
        return mobileInfo;
    }

    public void setMobileInfo(MobileInfo mobileInfo) {
        this.mobileInfo = mobileInfo;
    }

    @SerializedName("MobileInfo")
    @Expose
    MobileInfo mobileInfo;

    public String getFirstName() {
        return FirstName;
    }

    public void setFirstName(String firstName) {
        FirstName = firstName;
    }

    public String getLastName() {
        return LastName;
    }

    public void setLastName(String lastName) {
        LastName = lastName;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }

    public String getGender() {
        return Gender;
    }

    public void setGender(String gender) {
        Gender = gender;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String password) {
        Password = password;
    }

    public String getDateOfBirth() {
        return DateOfBirth;
    }

    public void setDateOfBirth(String dateOfBirth) {
        DateOfBirth = dateOfBirth;
    }


}
