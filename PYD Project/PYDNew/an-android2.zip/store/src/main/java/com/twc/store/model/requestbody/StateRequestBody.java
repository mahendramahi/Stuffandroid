package com.twc.store.model.requestbody;

/**
 * Created by GurvinderS on 5/15/2017.
 */

public class StateRequestBody {

    private int CountryID;

    public int getCounryID() {
        return CountryID;
    }

    public void setCounryID(int counryID) {
        CountryID = counryID;
    }
}
