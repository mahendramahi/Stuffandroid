package com.twc.store.views;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.util.AttributeSet;

import com.twc.store.R;


/**
 * Created by ManishJ1 on 3/27/2017.
 */

public class ViewCustomRoundedTextView extends android.support.v7.widget.AppCompatTextView {

    private String mFontName;
    private Context mContext;

    public ViewCustomRoundedTextView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        mContext = context;
        init(attrs);
    }

    public ViewCustomRoundedTextView(Context context, AttributeSet attrs) {
        super(context, attrs);
        mContext = context;
        init(attrs);
    }

    public ViewCustomRoundedTextView(Context context) {
        super(context);
        mContext = context;
        init(null);
    }

    private void init(AttributeSet attrs) {

        if (attrs != null) {
            TypedArray a = getContext().obtainStyledAttributes(attrs, R.styleable.ViewCustomRoundedTextView);
            mFontName = a.getString(R.styleable.ViewCustomRoundedTextView_btnFontName);
            int colorValue = a.getColor(R.styleable.ViewCustomRoundedTextView_btnColorValue, Color.WHITE);
            int strokeColor = a.getColor(R.styleable.ViewCustomRoundedTextView_btnStrokeColor, Color.TRANSPARENT);
            int strokeWidth = a.getColor(R.styleable.ViewCustomRoundedTextView_btnStrokeWidth, 1);
            if (mFontName != null) {
                setFontAccordingToAttrs();
            }
            GradientDrawable bgShape = (GradientDrawable) getBackground().mutate();
            bgShape.setColor(colorValue);
            bgShape.setStroke(strokeWidth,strokeColor);
            bgShape.invalidateSelf();
            a.recycle();
        }
    }

    private void setFontAccordingToAttrs() {
        if (mFontName.equalsIgnoreCase(getResources().getString(R.string.fnt_cabin_bold))) {
            setTypeface(Typeface.createFromAsset(mContext.getAssets(), "fonts/Cabin-Bold.ttf"));
        }
        else if (mFontName.equalsIgnoreCase(getResources().getString(R.string.fnt_cabin_bold_italic))) {
            setTypeface(Typeface.createFromAsset(mContext.getAssets(), "fonts/Cabin-BoldItalic.ttf"));
        }
        else if (mFontName.equalsIgnoreCase(getResources().getString(R.string.fnt_cabin_italic))) {
            setTypeface(Typeface.createFromAsset(mContext.getAssets(), "fonts/Cabin-Italic.ttf"));
        }
        else if (mFontName.equalsIgnoreCase(getResources().getString(R.string.fnt_cabin_medium))) {
            setTypeface(Typeface.createFromAsset(mContext.getAssets(), "fonts/Cabin-Medium.ttf"));
        }
        else if (mFontName.equalsIgnoreCase(getResources().getString(R.string.fnt_cabin_medium_italic))) {
            setTypeface(Typeface.createFromAsset(mContext.getAssets(), "fonts/Cabin-MediumItalic.ttf"));
        }
        else if (mFontName.equalsIgnoreCase(getResources().getString(R.string.fnt_cabin_regular))) {
            setTypeface(Typeface.createFromAsset(mContext.getAssets(), "fonts/Cabin-Regular.ttf"));
        }
        else if (mFontName.equalsIgnoreCase(getResources().getString(R.string.fnt_cabin_semibold))) {
            setTypeface(Typeface.createFromAsset(mContext.getAssets(), "fonts/Cabin-SemiBold.ttf"));
        }
        else if (mFontName.equalsIgnoreCase(getResources().getString(R.string.fnt_cabin_semibold_italic))) {
            setTypeface(Typeface.createFromAsset(mContext.getAssets(), "fonts/Cabin-SemiBoldItalic.ttf"));
        }
        /*new font added by pankaj sharma 2017-03-24*/
        else if (mFontName.equalsIgnoreCase(getResources().getString(R.string.fnt_roboto_black))) {
            setTypeface(Typeface.createFromAsset(mContext.getAssets(), "fonts/Roboto-Black.ttf"));
        }
        else if (mFontName.equalsIgnoreCase(getResources().getString(R.string.fnt_roboto_light))) {
            setTypeface(Typeface.createFromAsset(mContext.getAssets(), "fonts/Roboto-Light.ttf"));
        }

        else if (mFontName.equalsIgnoreCase(getResources().getString(R.string.fnt_roboto_Bold))) {
            setTypeface(Typeface.createFromAsset(mContext.getAssets(), "fonts/Roboto-Bold.ttf"));
        }

        else if (mFontName.equalsIgnoreCase(getResources().getString(R.string.fnt_roboto_regular))) {
            setTypeface(Typeface.createFromAsset(mContext.getAssets(), "fonts/Roboto-Regular.ttf"));
        }

        else if (mFontName.equalsIgnoreCase(getResources().getString(R.string.fnt_roboto_italic))) {
            setTypeface(Typeface.createFromAsset(mContext.getAssets(), "fonts/Roboto-Italic.ttf"));
        }

        else if (mFontName.equalsIgnoreCase(getResources().getString(R.string.fnt_roboto_medium_italic))) {
            setTypeface(Typeface.createFromAsset(mContext.getAssets(), "fonts/Roboto-MediumItalic.ttf"));
        }

        else if (mFontName.equalsIgnoreCase(getResources().getString(R.string.fnt_roboto_medium))) {
            setTypeface(Typeface.createFromAsset(mContext.getAssets(), "fonts/Roboto-Medium.ttf"));
        }

        else {
            setTypeface(Typeface.createFromAsset(mContext.getAssets(), "fonts/Cabin-Regular.ttf"));
        }
    }


}
