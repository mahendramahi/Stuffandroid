package com.truworth.wellnesscorner.repo.model.response;

import com.truworth.wellnesscorner.model.DataMemberProgramItem;

import java.util.List;

/**
 * Created by PalakC on 2/20/2018.
 */

public class GetMemberProgramResponse {
    private int status;
    private List<DataMemberProgramItem> Data;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public List<DataMemberProgramItem> getData() {
        return Data;
    }

    public void setData(List<DataMemberProgramItem> Data) {
        this.Data = Data;
    }
}
