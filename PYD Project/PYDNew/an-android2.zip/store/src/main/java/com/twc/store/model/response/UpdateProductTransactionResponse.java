package com.twc.store.model.response;

/**
 * Created by ManishJ1 on 8/5/2016.
 */
public class UpdateProductTransactionResponse {



    private int status;


    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }


}
