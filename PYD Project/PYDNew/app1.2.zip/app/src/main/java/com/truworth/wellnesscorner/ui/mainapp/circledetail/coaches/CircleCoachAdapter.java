package com.truworth.wellnesscorner.ui.mainapp.circledetail.coaches;

import android.databinding.DataBindingUtil;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import com.truworth.wellnesscorner.R;
import com.truworth.wellnesscorner.databinding.RowCoachesBinding;
import com.truworth.wellnesscorner.model.CircleCoach;

import java.util.List;

public class CircleCoachAdapter extends RecyclerView.Adapter<CircleCoachAdapter.ViewHolder> {
    List<CircleCoach> coaches;

    public CircleCoachAdapter(List<CircleCoach> coaches) {
        this.coaches = coaches;

    }

    @NonNull
    @Override
    public CircleCoachAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        RowCoachesBinding binding = DataBindingUtil.inflate(LayoutInflater.from(parent.getContext()), R.layout.row_coaches, parent, false);
        return new ViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.bind(coaches.get(position));
    }

    @Override
    public int getItemCount() {
        return coaches.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private RowCoachesBinding mBinding;

        public ViewHolder(RowCoachesBinding binding) {
            super(binding.getRoot());
            mBinding = binding;
        }

        public void bind(@NonNull CircleCoach coach) {
            CoachItemViewModel viewModel = new CoachItemViewModel(coach);

            mBinding.setViewModel(viewModel);
            mBinding.executePendingBindings();
        }
    }

}
