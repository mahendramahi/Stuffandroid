package com.twc.store.adapter;

import android.app.Activity;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;

import com.twc.store.R;
import com.twc.store.R2;
import com.twc.store.fragments.StoreMyCartFragment;
import com.twc.store.model.beans.CartListItem;
import com.twc.store.utils.DialogFactory;
import com.twc.store.utils.Utils;
import com.twc.store.views.CustomTextView;

import java.util.ArrayList;
import java.util.Locale;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * Created by PalakC on 7/10/2017.
 */

public class StoreMyCartListAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private ArrayList<CartListItem> cartListItems;
    private Activity mActivity;
    private StoreMyCartFragment mStoreMyCartFragment;
    private boolean isPlus = false;
    private int PROGRAM_CONSTANT = 1;

    public StoreMyCartListAdapter(Activity mActivity, ArrayList<CartListItem> cartListItems, StoreMyCartFragment fragment) {
        this.cartListItems = cartListItems;
        this.mActivity = mActivity;
        this.mStoreMyCartFragment = fragment;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_mycart_store, parent, false);
        return new ItemViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, final int position) {
        final ItemViewHolder itemViewHolder = (ItemViewHolder) holder;

        itemViewHolder.tvProductTitle.setText(cartListItems.get(position).getSCart_ProductName());

        Glide.with(mActivity).load(cartListItems.get(position).getSCart_ProductImage()).apply(new RequestOptions().dontAnimate().dontTransform().placeholder(R.drawable.wellness_no_logo).error(R.drawable.wellness_no_logo)).into(itemViewHolder.ivProductImage);
        final int quantity = cartListItems.get(position).getSCart_Quantity();
        itemViewHolder.tvProductCount.setText(String.format(Locale.getDefault(), "%d", quantity));
        itemViewHolder.tvPrice.setText(mActivity.getString(R.string.rupee_symbol) + " " + Utils.getFormattedAmountManageZero(cartListItems.get(position).getSCart_TotalAmount() * quantity));
        final int categoryID = cartListItems.get(position).getSCart_ProductCategoryID();

        if (categoryID == PROGRAM_CONSTANT) {
            itemViewHolder.ivMins.setVisibility(View.GONE);
            itemViewHolder.ivPlus.setVisibility(View.GONE);
            itemViewHolder.tvProductCount.setVisibility(View.GONE);
        }
        else{
            itemViewHolder.ivMins.setVisibility(View.VISIBLE);
            itemViewHolder.ivPlus.setVisibility(View.VISIBLE);
            itemViewHolder.tvProductCount.setVisibility(View.VISIBLE);
        }
        itemViewHolder.ivMins.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (quantity > 1) {
                    isPlus = false;
                    int updateQuantity = cartListItems.get(position).getSCart_Quantity();
                    updateQuantity--;
                    mStoreMyCartFragment.UpdateQuantity(position, cartListItems.get(position).getSCart_ProductID(), updateQuantity, cartListItems.get(position).getSCart_Id(), cartListItems.get(position).getSCart_ProductVendorID() ,isPlus);
                }
            }
        });
        itemViewHolder.ivPlus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (categoryID == PROGRAM_CONSTANT) {
                    DialogFactory.getInstance().showAlertDialog(mActivity, mActivity.getString(R.string.app_name), 0, mActivity.getString(R.string.msg_add_failure), mActivity.getString(R.string.str_ok), false);
                } else {
                    if (cartListItems.get(position).isSCart_IsInStock()) {
                        isPlus = true;
                        int updateQuantity = cartListItems.get(position).getSCart_Quantity();
                        updateQuantity++;
                        mStoreMyCartFragment.UpdateQuantity(position, cartListItems.get(position).getSCart_ProductID(), updateQuantity, cartListItems.get(position).getSCart_Id(), cartListItems.get(position).getSCart_ProductVendorID(),isPlus);
                    } else {
                        Utils.showToast(mActivity, "The item is out of stock");
                    }
                }
            }
        });
        itemViewHolder.tvRemove.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                  mStoreMyCartFragment.deleteCartItem(position, cartListItems.get(position).getSCart_Id());
            }
        });
    }

    @Override
    public int getItemCount() {
        return (null != cartListItems ? cartListItems.size() : 0);
    }

    public class ItemViewHolder extends RecyclerView.ViewHolder {
        @BindView(R2.id.ivProductImage)
        ImageView ivProductImage;
        @BindView(R2.id.tvProductTitle)
        CustomTextView tvProductTitle;
        @BindView(R2.id.tvPrice)
        CustomTextView tvPrice;
        @BindView(R2.id.ivMins)
        ImageView ivMins;
        @BindView(R2.id.tvProductCount)
        CustomTextView tvProductCount;
        @BindView(R2.id.ivPlus)
        ImageView ivPlus;
        @BindView(R2.id.tvRemove)
        CustomTextView tvRemove;

        @BindView(R2.id.rlBottom)
        RelativeLayout rlBottom;

        public ItemViewHolder(View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);

            // redirection is hide bcz its create like looping as discuss
            /*
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    int productId;
                    String sku;
                    if(cartListItems.get(getAdapterPosition()).getSCart_ProductCategoryID()==1)
                    {
                        productId=cartListItems.get(getAdapterPosition()).getSCart_ProductID();
                        sku="";
                    }else
                    {
                        productId=cartListItems.get(getAdapterPosition()).getSCart_ProductID();
                        sku= String.valueOf(cartListItems.get(getAdapterPosition()).getSCart_ProductID());
                    }

                    Utils.replaceFragment(mActivity.getFragmentManager(), StoreProductDetailFragment.newInstance(productId, sku,""), StoreProductDetailFragment.class.getSimpleName(), true, R.id.fragmentContainer);
                }
            });*/
        }
    }

}
