package com.truworth.wellnesscorner.ui.step;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.truworth.wellnesscorner.R;
;
import com.truworth.wellnesscorner.utils.AppConstants;
import com.truworth.wellnesscorner.utils.DateUtils;
import com.truworth.wellnesscorner.utils.Utils;

import java.util.ArrayList;


public class StepsTrackerAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private static final int VIEW_TYPE_STEPS_MONTH = 0;
    private static final int VIEW_TYPE_STEPS_COUNT = 1;
    private static final int VIEW_TYPE_PROGRESS = 2;
    private final ArrayList<DeviceStepsItem> countArrayList;

    public StepsTrackerAdapter(ArrayList<DeviceStepsItem> countArrayList) {
        this.countArrayList = countArrayList;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        RecyclerView.ViewHolder viewHolder = null;
        View itemView;
        switch (viewType) {
            case VIEW_TYPE_STEPS_COUNT:
                itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_daily_steps_count, parent, false);
                viewHolder = new StepsCountViewHolder(itemView);
                break;

            case VIEW_TYPE_STEPS_MONTH:
                itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_steps_month_view, parent, false);
                viewHolder = new StepsMonthViewHolder(itemView);
                break;

            case VIEW_TYPE_PROGRESS:
                itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_loading_progress, parent, false);
                viewHolder = new ProgressViewHolder(itemView);
                break;

        }
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        switch (holder.getItemViewType()) {
            case VIEW_TYPE_STEPS_COUNT:
                StepsCountViewHolder stepsCountViewHolder = (StepsCountViewHolder) holder;
                stepsCountViewHolder.tvDailyCount.setText(countArrayList.get(position).getValue());
                String date = countArrayList.get(position).getDate();
                date = DateUtils.formatDateStep("yyyy-MM-dd", "E  dd-MM", date);
                stepsCountViewHolder.tvStepsDate.setText(date);
                int progress = (int) Utils.getPercentage(Float.parseFloat(countArrayList.get(position).getValue()), 8000f);
                stepsCountViewHolder.pbSteps.setProgress(progress);
                int deviceIcon = -1;
                if (countArrayList.get(position).getDevice().contains("Apple"))
                    deviceIcon = R.drawable.ic_apple_health_icon;
                else if (countArrayList.get(position).getDevice().equalsIgnoreCase(AppConstants.FITBIT))
                    deviceIcon = R.drawable.fitbit_logo;
                else if (countArrayList.get(position).getDevice().equalsIgnoreCase(AppConstants.S_HEALTH))
                    deviceIcon = R.drawable.ic_samsung_health;
                else if (countArrayList.get(position).getDevice().equalsIgnoreCase(AppConstants.GOOGLE_FIT))
                    deviceIcon = R.drawable.ic_google_fit;
                else if (countArrayList.get(position).getDevice().equalsIgnoreCase(AppConstants.E_FIT))
                    deviceIcon = R.drawable.ic_efit;
                else if (countArrayList.get(position).getDevice().equalsIgnoreCase(AppConstants.MISFIT))
                    deviceIcon = R.drawable.ic_misfit_logo;
                else if (countArrayList.get(position).getDevice().equalsIgnoreCase(AppConstants.GARMIN))
                    deviceIcon = R.drawable.ic_misfit_logo;
                if (deviceIcon != -1)
                    stepsCountViewHolder.ivDeviceIcon.setImageResource(deviceIcon);
                break;

            case VIEW_TYPE_STEPS_MONTH:
                StepsMonthViewHolder stepsMonthViewHolder = (StepsMonthViewHolder) holder;
                stepsMonthViewHolder.tvStepsMonth.setText(countArrayList.get(position).getDate());
                stepsMonthViewHolder.tvMonthStepsTotal.setText(countArrayList.get(position).getValue());
                break;
        }
    }

    @Override
    public int getItemViewType(int position) {
        if (countArrayList.get(position) == null) {
            return VIEW_TYPE_PROGRESS;
        } else if (countArrayList.get(position).getIsMonth()) {
            return VIEW_TYPE_STEPS_MONTH;
        } else {
            return VIEW_TYPE_STEPS_COUNT;
        }
    }

    @Override
    public int getItemCount() {
        return countArrayList == null ? 0 : countArrayList.size();
    }

    public class StepsCountViewHolder extends RecyclerView.ViewHolder {
        TextView tvDailyCount, tvStepsDate;
        ProgressBar pbSteps;
        ImageView ivDeviceIcon;

        public StepsCountViewHolder(View itemView) {
            super(itemView);
            tvDailyCount = itemView.findViewById(R.id.tvDailyCount);
            tvStepsDate = itemView.findViewById(R.id.tvStepsDate);
            pbSteps = itemView.findViewById(R.id.pbSteps);
            ivDeviceIcon = itemView.findViewById(R.id.ivDeviceIcon);
        }
    }

    public class StepsMonthViewHolder extends RecyclerView.ViewHolder {
        TextView tvStepsMonth, tvMonthStepsTotal;

        public StepsMonthViewHolder(View itemView) {
            super(itemView);
            tvStepsMonth = itemView.findViewById(R.id.tvStepsMonth);
            tvMonthStepsTotal = itemView.findViewById(R.id.tvMonthStepsTotal);
        }
    }

    public class ProgressViewHolder extends RecyclerView.ViewHolder {
        ProgressBar mProgressBar;

        public ProgressViewHolder(View itemView) {
            super(itemView);
            mProgressBar = itemView.findViewById(R.id.progressBar);
            mProgressBar.setIndeterminate(true);
        }
    }
}
