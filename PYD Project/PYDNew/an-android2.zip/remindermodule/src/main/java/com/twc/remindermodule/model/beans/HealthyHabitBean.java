package com.twc.remindermodule.model.beans;

/**
 * Created by richas on 9/21/2017.
 */

public class HealthyHabitBean {

    private int ID;
    private String Title;
    private boolean IsSelected;

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getTitle() {
        return Title;
    }

    public void setTitle(String Title) {
        this.Title = Title;
    }

    public boolean isIsSelected() {
        return IsSelected;
    }

    public void setIsSelected(boolean IsSelected) {
        this.IsSelected = IsSelected;
    }
}
