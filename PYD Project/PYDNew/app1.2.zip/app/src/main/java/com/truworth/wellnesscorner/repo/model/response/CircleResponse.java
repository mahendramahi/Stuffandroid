package com.truworth.wellnesscorner.repo.model.response;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class CircleResponse {

    @SerializedName("data")
    @Expose
    private CircleResponseData data;
    @SerializedName("hasError")
    @Expose
    private Boolean hasError;
    @SerializedName("error")
    @Expose
    private Error error;

    public CircleResponseData getData() {
        return data;
    }

    public void setData(CircleResponseData data) {
        this.data = data;
    }

    public Boolean getHasError() {
        return hasError;
    }

    public void setHasError(Boolean hasError) {
        this.hasError = hasError;
    }

    public Error getError() {
        return error;
    }

    public void setError(Error error) {
        this.error = error;
    }

}
