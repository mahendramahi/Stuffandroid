package com.twc.dailylog.utils;

public class WaterConfig {
    public static String containerType=Constant.GLASS;

    public static String BASE_URL = "http://192.168.1.91:9003/twcapi/";// default testing url
    public static String APP_NAME = ""; //
    public static boolean DEBUG;

    public static void init(String appName, String apiBaseUrl,boolean debug) {
        if (!appName.isEmpty() && !apiBaseUrl.isEmpty() ) {
            BASE_URL = apiBaseUrl;
            APP_NAME = appName;

            DEBUG = debug;
        } else {

        }
    }
}
