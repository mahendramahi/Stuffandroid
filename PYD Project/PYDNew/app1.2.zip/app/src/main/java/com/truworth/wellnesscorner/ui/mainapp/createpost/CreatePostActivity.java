package com.truworth.wellnesscorner.ui.mainapp.createpost;

import android.Manifest;
import android.app.Activity;
import android.app.ProgressDialog;
import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.databinding.DataBindingUtil;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import com.google.android.exoplayer2.ExoPlayerFactory;
import com.google.android.exoplayer2.SimpleExoPlayer;
import com.google.android.exoplayer2.extractor.DefaultExtractorsFactory;
import com.google.android.exoplayer2.source.ExtractorMediaSource;
import com.google.android.exoplayer2.source.MediaSource;
import com.google.android.exoplayer2.trackselection.AdaptiveTrackSelection;
import com.google.android.exoplayer2.trackselection.DefaultTrackSelector;
import com.google.android.exoplayer2.trackselection.TrackSelection;
import com.google.android.exoplayer2.ui.PlayerView;
import com.google.android.exoplayer2.upstream.DataSource;
import com.google.android.exoplayer2.upstream.DefaultBandwidthMeter;
import com.google.android.exoplayer2.upstream.DefaultDataSourceFactory;
import com.google.android.exoplayer2.upstream.TransferListener;
import com.google.android.exoplayer2.util.Util;
import com.karumi.dexter.Dexter;
import com.karumi.dexter.MultiplePermissionsReport;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.multi.MultiplePermissionsListener;
import com.transloadit.sdk.async.AssemblyProgressListener;
import com.transloadit.sdk.response.AssemblyResponse;
import com.truworth.wellnesscorner.R;
import com.truworth.wellnesscorner.databinding.ActivityCreatePostBinding;
import com.truworth.wellnesscorner.model.OnGoingChallengesBean;
import com.truworth.wellnesscorner.model.PostMediaData;
import com.truworth.wellnesscorner.ui.mainapp.circledetail.challenges.OngoingChallengeAdapter;
import com.truworth.wellnesscorner.utils.AppConstants;
import com.truworth.wellnesscorner.utils.CameraGalleryChooser;
import com.truworth.wellnesscorner.utils.CameraGalleryUtil;
import com.truworth.wellnesscorner.utils.CommonUtils;
import com.truworth.wellnesscorner.utils.CompressImage;
import com.truworth.wellnesscorner.utils.DateUtils;
import com.truworth.wellnesscorner.utils.Utils;
import com.truworth.wellnesscorner.utils.fileuploader.FileUploader;
import com.yovenny.videocompress.MediaController;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

//import android.widget.MediaController;
//import com.iceteck.silicompressorr.SiliCompressor;

public class CreatePostActivity extends AppCompatActivity implements AssemblyProgressListener {
    public static final String APP_DIR = "VideoCompressor";

    public static final String COMPRESSED_VIDEOS_DIR = "/Compressed Videos/";

    public static int REQUEST_CODE = 2;
    ActivityCreatePostBinding binding;
    OngoingChallengeAdapter circleOngoingChallengeAdapter;
    List<OnGoingChallengesBean> onGoingChallengeList;
    ProgressDialog progressDialog;
    private CreatePostViewModel viewModel;
    private CameraGalleryUtil cameraGalleryUtil;
    private String coachName, circleIdentity;
    private boolean isCheckIn;
    private OnGoingChallengesBean onGoingChallengesBean;
    private FileUploader fileUploader;
    private String todayDate, ext;
    private Uri uri;
    private int mediaType;


    public static void start(Activity mActivity, String circleName, String circleIdentity, boolean isCheckIn, OnGoingChallengesBean onGoingChallenge) {
        Intent intent = new Intent(mActivity, CreatePostActivity.class);
        intent.putExtra("coachName", circleName);
        intent.putExtra("circleIdentity", circleIdentity);
        intent.putExtra("checkIn", isCheckIn);
        intent.putExtra("onGoingChallenge", onGoingChallenge);
        mActivity.startActivityForResult(intent, REQUEST_CODE);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getIntent() != null) {
            coachName = getIntent().getStringExtra("coachName");
            circleIdentity = getIntent().getStringExtra("circleIdentity");
            onGoingChallengesBean = (OnGoingChallengesBean) getIntent().getSerializableExtra("onGoingChallenge");
            isCheckIn = getIntent().getBooleanExtra("checkIn", false);
        }
        fileUploader = new FileUploader(this, this);
        onGoingChallengeList = new ArrayList<>();
        //setUpOngoingChallengesRecycler();
        cameraGalleryUtil = new CameraGalleryUtil(this, null);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_create_post);
        viewModel = ViewModelProviders.of(this).get(CreatePostViewModel.class);
        binding.setViewModel(viewModel);
        Toolbar toolbar = binding.toolbar;
        setupToolbar(toolbar);
        toolbar.setTitle("Create a Post");
        attachFileChooserObserver();
        viewModel.setIntentValue(coachName, circleIdentity, isCheckIn, onGoingChallengesBean);
        setUpOngoingChallengesRecycler();

    }

    private void setUpOngoingChallengesRecycler() {
        binding.checkInView.setLayoutManager(new LinearLayoutManager(this));
        circleOngoingChallengeAdapter = new OngoingChallengeAdapter(onGoingChallengeList, circleIdentity);
        binding.checkInView.setAdapter(circleOngoingChallengeAdapter);
    }

    private void setupToolbar(Toolbar toolbar) {
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
            getSupportActionBar().setDisplayShowTitleEnabled(false);
        }
    }

    private void attachFileChooserObserver() {
        viewModel.getcallDialogChooser().observe(this, new Observer<Void>() {
            @Override
            public void onChanged(@Nullable Void aVoid) {
                CameraGalleryChooser.selectImageForPost(CreatePostActivity.this,cameraGalleryUtil);
            }
        });

        viewModel.getOnSavePost().observe(this, new Observer<Void>() {
            @Override
            public void onChanged(@Nullable Void aVoid) {
                Intent returnIntent = new Intent();
                setResult(RESULT_OK, returnIntent);
                Utils.hideSoftKeyboard(CreatePostActivity.this);
                finish();
            }
        });
        viewModel.getNavigateOnShare().observe(this, new Observer<Integer>() {
            @Override
            public void onChanged(@Nullable Integer tag) {

                checkForStoragePermissions(tag);
            }
        });

        viewModel.getOngoingChallenges().observe(this, new Observer<List<OnGoingChallengesBean>>() {
            @Override
            public void onChanged(@Nullable List<OnGoingChallengesBean> onGoingChallenge) {

                if (onGoingChallenge != null) {
                    onGoingChallengeList.clear();
                    onGoingChallengeList.addAll(onGoingChallenge);
                    circleOngoingChallengeAdapter.notifyDataSetChanged();
                }
            }
        });

        viewModel.getCheckTagList().observe(this, new Observer<Void>() {
            @Override
            public void onChanged(@Nullable Void aVoid) {
                if (binding.etPost.getObjects() != null && binding.etPost.getObjects().size() > 0)
                    viewModel.setTags(binding.etPost.getObjects());

            }
        });
        viewModel.getCheckMediaList().observe(this, new Observer<Void>() {
            @Override
            public void onChanged(@Nullable Void aVoid) {
                if (binding.ivImage.getVisibility() == View.VISIBLE ) {
                    if (uri != null) {
                        viewModel.setMediaType(true);
                        fileUploader.submitAssembly(uri, todayDate, ext, false);
                    }
                }
                else if(binding.videoView.getVisibility() == View.VISIBLE){
                    if (uri != null) {
                        viewModel.setMediaType(true);
                        compressAndSaveVideo();
                    }
                }

                else {
                    viewModel.setMediaType(false);
                }
            }
        });

        viewModel.getIsLoading().observe(this, new Observer() {
            @Override
            public void onChanged(@Nullable Object o) {
                if (((Boolean) o)) {
                    progressDialog = CommonUtils.showUploadFileProgressBar(CreatePostActivity.this);
                } else {
                    if (progressDialog != null && progressDialog.isShowing()) {
                        progressDialog.cancel();
                    }
                }
            }
        });

        viewModel.getUrlPreviewData().observe(this, new Observer<PostMediaData>() {
            @Override
            public void onChanged(@Nullable PostMediaData postMediaData) {
                if(postMediaData != null) {
                    PostUrlViewModel urlViewModel = new PostUrlViewModel(postMediaData, true);
                    binding.setPostUrlViewModel(urlViewModel);
                }
            }
        });
    }



    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode == Activity.RESULT_OK) {
            Uri dataUri;
            todayDate = DateUtils.getTodayDate("yyyyMMddHHmmss");
            if (requestCode == AppConstants.SHARE_DATA_REQUEST) {
                if (resultCode == Activity.RESULT_OK) {
                    String result = data.getStringExtra("result");
                    setImageFromShare(result);
                }
                if (resultCode == Activity.RESULT_CANCELED) {

                }
            } else if (requestCode == AppConstants.CAMERA_REQUEST) {
                if (cameraGalleryUtil.getCameraFilePath() != null) {
                    File file = new File(cameraGalleryUtil.getCameraFilePath());
                    Uri myuri = Uri.fromFile(file);
                    setImage(myuri);
                }
            } else if (requestCode == AppConstants.VIDEO_DATA_REQUEST && data != null && data.getData() != null) {
                dataUri = data.getData();
                String path = cameraGalleryUtil.getPath(CreatePostActivity.this, dataUri);
                setExoPlayer(binding.videoView, path);
                viewModel.setVisiblityVideoView();
                ext = path.substring(path.lastIndexOf(".") + 1);
                uri = dataUri;
                mediaType = AppConstants.MEDIA_TYPE_VIDEO;
            } else if (requestCode == AppConstants.GALLERY_REQUEST && data != null && data.getData() != null) {
                dataUri = data.getData();
                ContentResolver cr = getContentResolver();
                String mime = cr.getType(dataUri);
                if (mime.toLowerCase().contains("video")) {
                    String path = cameraGalleryUtil.getPath(CreatePostActivity.this, dataUri);
                    setExoPlayer(binding.videoView, path);
                    viewModel.setVisiblityVideoView();
                    ext = path.substring(path.lastIndexOf(".") + 1);
                    uri = dataUri;
                    mediaType = AppConstants.MEDIA_TYPE_VIDEO;
                } else if (mime.toLowerCase().contains("image")) {
                    setImage(dataUri);
                }
            }
        } else {

        }
    }


    public void setExoPlayer(PlayerView videoView, String path) {
        //videoView.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_FILL);
        //videoView.setVideoScalingMode(C.VIDEO_SCALING_MODE_SCALE_TO_FIT_WITH_CROPPING);
        DefaultBandwidthMeter bandwidthMeter = new DefaultBandwidthMeter();
        DefaultDataSourceFactory mediaDataSourceFactory = new DefaultDataSourceFactory(this, Util.getUserAgent(this, "mediaPlayerSample"), (TransferListener<? super DataSource>) bandwidthMeter);
        TrackSelection.Factory videoTrackSelectionFactory =
                new AdaptiveTrackSelection.Factory(bandwidthMeter);
        DefaultTrackSelector trackSelector = new DefaultTrackSelector(videoTrackSelectionFactory);

        SimpleExoPlayer player = ExoPlayerFactory.newSimpleInstance(this, trackSelector);

        videoView.setPlayer(player);

        player.setPlayWhenReady(false);

        DefaultExtractorsFactory extractorsFactory = new DefaultExtractorsFactory();

        MediaSource mediaSource = new ExtractorMediaSource(Uri.parse(path),
                mediaDataSourceFactory, extractorsFactory, null, null);
        player.prepare(mediaSource);

    }

    private void setImage(Uri cropped_image_uri) {
        binding.ivImage.setImageURI(cropped_image_uri);
        String filePath = cameraGalleryUtil.getPath(this, cropped_image_uri);
        Bitmap bitmap = cameraGalleryUtil.getBitmap(filePath, binding.ivImage.getWidth(), binding.ivImage.getHeight());
        binding.ivImage.setImageBitmap(bitmap);
        CompressImage.compress(filePath);
        ext = filePath.substring(filePath.lastIndexOf(".") + 1);
        uri = cropped_image_uri;
        viewModel.setVisiblityImage();
        mediaType = AppConstants.MEDIA_TYPE_IMAGE;

    }

    private void setImageFromShare(String filePath) {
        Uri newUri = Uri.parse(filePath);
        binding.ivImage.setImageURI(newUri);
        String fullPath = cameraGalleryUtil.getPath(this, newUri);
        CompressImage.compress(fullPath);
        ext = fullPath.substring(fullPath.lastIndexOf(".") + 1);
        uri = newUri;
        viewModel.setVisiblityImage();
        mediaType = AppConstants.MEDIA_TYPE_IMAGE;
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_activity_circle_detail, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void onUploadFinished() {

    }

    @Override
    public void onUploadPogress(long uploadedBytes, long totalBytes) {

        if (progressDialog != null && progressDialog.isShowing()) {
            int totalProgressPercent = (int) ((uploadedBytes * 100) / totalBytes);
            progressDialog.setProgress(totalProgressPercent);
        }
    }

    @Override
    public void onAssemblyFinished(AssemblyResponse response) {
        if (response != null && response.isCompleted()) {
            viewModel.setMediaData(todayDate, ext, mediaType,binding.ivImage.getWidth(),binding.ivImage.getHeight());
        }
    }

    @Override
    public void onUploadFailed(Exception exception) {
        viewModel.setMediaData("", "", 0,0,0);
    }

    @Override
    public void onAssemblyStatusUpdateFailed(Exception exception) {

    }

    public void checkForStoragePermissions(int openFor) {

        Dexter.withActivity(CreatePostActivity.this)
                .withPermissions(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                .withListener(new MultiplePermissionsListener() {
                    @Override
                    public void onPermissionsChecked(MultiplePermissionsReport report) {
                        if (report.areAllPermissionsGranted()) {
                            ShareActivity.start(CreatePostActivity.this, openFor);
                        }
                    }

                    @Override
                    public void onPermissionRationaleShouldBeShown(List<PermissionRequest> permissions, PermissionToken token) {
                        token.continuePermissionRequest();
                    }


                }).check();
    }

    public void compressAndSaveVideo(){
        try2CreateCompressDir();
        String outPath=Environment.getExternalStorageDirectory()
                + File.separator
                + APP_DIR
                + COMPRESSED_VIDEOS_DIR
                +"VIDEO_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date()) + "."+ext;
        String inPath = cameraGalleryUtil.getPath(CreatePostActivity.this, uri);
        new VideoCompressAsyncTask(this).execute(inPath, outPath);
    }


    class VideoCompressAsyncTask extends AsyncTask<String, String, String> {

        Context mContext;

        public VideoCompressAsyncTask(Context context){
            mContext = context;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();

        }

        @Override
        protected String doInBackground(String... paths) {
            String filePath = paths[1];
           try {
               MediaController.getInstance().convertVideo(paths[0],paths[1]);
               // filePath = SiliCompressor.with(mContext).compressVideo(Uri.parse(paths[0]), paths[1]);

            } catch (Exception e) {
                e.printStackTrace();
            }
            return  filePath;

        }


        @Override
        protected void onPostExecute(String compressedFilePath) {
            super.onPostExecute(compressedFilePath);
            File imageFile = new File(compressedFilePath);

            ext = compressedFilePath.substring(compressedFilePath.lastIndexOf(".") + 1);
            uri = Uri.fromFile(imageFile);

            fileUploader.submitAssembly(uri, todayDate, ext, false);

        }
    }
    public static void try2CreateCompressDir() {
        File f = new File(Environment.getExternalStorageDirectory(), File.separator + APP_DIR);
        f.mkdirs();
        f = new File(Environment.getExternalStorageDirectory(), File.separator + APP_DIR + COMPRESSED_VIDEOS_DIR);
        f.mkdirs();

    }
}
