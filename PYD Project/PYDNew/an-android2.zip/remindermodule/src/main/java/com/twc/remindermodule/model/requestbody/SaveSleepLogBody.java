package com.twc.remindermodule.model.requestbody;

/**
 * Created by PalakC on 1/19/2018.
 */

public class SaveSleepLogBody {

    private int SleepLog_MemberID;
    private int SleepLogID;
    private String SleepLog_DateTime;
    private String SleepLog_WakeUpTime;
    private int SleepLog_Duration;
    private String SleepLog_Remarks;
    private boolean SleepLog_IsActive;
    private int SleepLog_Feel;

    public int getSleepLog_MemberID() {
        return SleepLog_MemberID;
    }

    public void setSleepLog_MemberID(int SleepLog_MemberID) {
        this.SleepLog_MemberID = SleepLog_MemberID;
    }

    public int getSleepLogID() {
        return SleepLogID;
    }

    public void setSleepLogID(int SleepLogID) {
        this.SleepLogID = SleepLogID;
    }

    public String getSleepLog_DateTime() {
        return SleepLog_DateTime;
    }

    public void setSleepLog_DateTime(String SleepLog_DateTime) {
        this.SleepLog_DateTime = SleepLog_DateTime;
    }

    public String getSleepLog_WakeUpTime() {
        return SleepLog_WakeUpTime;
    }

    public void setSleepLog_WakeUpTime(String SleepLog_WakeUpTime) {
        this.SleepLog_WakeUpTime = SleepLog_WakeUpTime;
    }

    public int getSleepLog_Duration() {
        return SleepLog_Duration;
    }

    public void setSleepLog_Duration(int SleepLog_Duration) {
        this.SleepLog_Duration = SleepLog_Duration;
    }

    public String getSleepLog_Remarks() {
        return SleepLog_Remarks;
    }

    public void setSleepLog_Remarks(String SleepLog_Remarks) {
        this.SleepLog_Remarks = SleepLog_Remarks;
    }

    public boolean isSleepLog_IsActive() {
        return SleepLog_IsActive;
    }

    public void setSleepLog_IsActive(boolean SleepLog_IsActive) {
        this.SleepLog_IsActive = SleepLog_IsActive;
    }

    public int getSleepLog_Feel() {
        return SleepLog_Feel;
    }

    public void setSleepLog_Feel(int SleepLog_Feel) {
        this.SleepLog_Feel = SleepLog_Feel;
    }
}
