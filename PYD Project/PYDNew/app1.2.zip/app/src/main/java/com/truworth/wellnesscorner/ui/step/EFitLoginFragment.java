package com.truworth.wellnesscorner.ui.step;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Fragment;
import android.app.FragmentManager;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.TextInputLayout;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v4.widget.NestedScrollView;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.LinearLayout;

import com.truworth.stepmodule.model.EFitLoginBody;
import com.truworth.stepmodule.model.EFitLoginResponse;
import com.truworth.stepmodule.rest.FitBitRestClient;
import com.truworth.stepmodule.utils.FitBitConfig;
import com.truworth.wellnesscorner.R;
import com.truworth.wellnesscorner.TheWellnessCornerApp;
import com.truworth.wellnesscorner.customviews.CustomEditTextView;
import com.truworth.wellnesscorner.customviews.CustomProgressDialog;
import com.truworth.wellnesscorner.data.SharedPreferenceHelper;
import com.truworth.wellnesscorner.utils.AppConstants;
import com.truworth.wellnesscorner.utils.CommonUtils;
import com.truworth.wellnesscorner.utils.Utils;


import javax.inject.Inject;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class EFitLoginFragment extends Fragment {
    private static final String E_FIT_LOGIN_SUCCESS = "1";
    private static final String E_FIT_LOGIN_ERROR = "0";
    @BindView(R.id.etUsername)
    CustomEditTextView etUsername;
    @BindView(R.id.etPassword)
    CustomEditTextView etPassword;
    @BindView(R.id.fbEfitLogin)
    FloatingActionButton fbEfitLogin;
    @BindView(R.id.inputLayoutEmail)
    TextInputLayout inputLayoutEmail;
    @BindView(R.id.inputLayoutPassword)
    TextInputLayout inputLayoutPassword;
    @BindView(R.id.rootView)
    NestedScrollView rootLayout;
    private String TAG = "_DeviceConnect";
    private boolean isRedirectFromRecommendation;

    private boolean isRedirectFromStepTrackerSetting;

    @Inject
    SharedPreferenceHelper prefHelper;
    public EFitLoginFragment() {
        TheWellnessCornerApp.getApp().component().inject(this);
    }
    public static EFitLoginFragment newInstance(Bundle bundle) {
        EFitLoginFragment fragment = new EFitLoginFragment();
        fragment.setArguments(bundle);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.e_fit_layout, container, false);
        ButterKnife.bind(this, rootView);
        getActivity().getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        if (getArguments() != null) {
            isRedirectFromRecommendation = getArguments().getBoolean("isRedirectFromRecommendation");
            isRedirectFromStepTrackerSetting = getArguments().getBoolean("isRedirectFromStepTrackerSetting");
        }

        etUsername.addTextChangedListener(new LoginTextWatcher(etUsername));
        etPassword.addTextChangedListener(new LoginTextWatcher(etPassword));
        return rootView;


    }


    @OnClick(R.id.fbEfitLogin)
    public void callValidationWithApi() {
        if (validation()) {
            loginOnEFitServer(etUsername.getText().toString().trim(), etPassword.getText().toString().trim());
        }

    }

    private void loginOnEFitServer(String username, String password) {

        final CustomProgressDialog customProgressDialog = new CustomProgressDialog(getActivity(), R.style.custom_progress_style, false);
        customProgressDialog.show();
        EFitLoginBody eFitLoginBody = new EFitLoginBody();
        eFitLoginBody.setLoginId(username);
        eFitLoginBody.setPassword(password);

        FitBitRestClient restClient = new FitBitRestClient("efit", "",getActivity(), FitBitConfig.E_FIT_BASE_URL, false);
        restClient.getFitBitStepsService().loginToEFit(eFitLoginBody).enqueue(new Callback<EFitLoginResponse>() {
            @Override
            public void onResponse(Call<EFitLoginResponse> call, Response<EFitLoginResponse> response) {
                if (getActivity() != null && isAdded()) {
                    customProgressDialog.dismiss();
                    if (response != null && response.body() != null) {
                        if (response.body().getSuccess().equalsIgnoreCase(E_FIT_LOGIN_SUCCESS)) {
                            prefHelper.setEFitUserId(String.valueOf(response.body().getUserID()));
                            prefHelper.setPrefKeyDeviceConnected(AppConstants.E_FIT);
                            prefHelper.clearDeviceConnectTokenPreferences();
                            if (isRedirectFromStepTrackerSetting) {
                                StepsTrackerFragment stepsTrackerFragment = (StepsTrackerFragment) getActivity().getFragmentManager().findFragmentByTag(StepsTrackerFragment.class.getSimpleName());
                                if (stepsTrackerFragment != null) {
                                    stepsTrackerFragment.setConnectedDeviceType(AppConstants.E_FIT);
                                }
                                getFragmentManager().popBackStackImmediate();
                            } else {
                                StepsTrackerFragment stepsTrackerFragment = (StepsTrackerFragment) getActivity().getFragmentManager().findFragmentByTag(StepsTrackerFragment.class.getSimpleName());
                                if (stepsTrackerFragment == null) {
                                    stepsTrackerFragment = StepsTrackerFragment.newInstance();
                                }
                                stepsTrackerFragment.setConnectedDeviceType(AppConstants.E_FIT);
                                Utils.replaceFragment(getActivity().getFragmentManager(), stepsTrackerFragment, StepsTrackerFragment.class.getSimpleName(), true, R.id.fragmentContainer);
                            }
                        } else if (response.body().getSuccess().equalsIgnoreCase(E_FIT_LOGIN_ERROR)) {
                            CommonUtils.showAlertDialog(getActivity(), null, 0, response.body().getMsg(), getString(R.string.str_ok), true);
                        } else {
                            CommonUtils.showAlertDialog(getActivity(), null, 0, "An error occurred while connecting E-Fit", getString(R.string.str_ok), true);
                        }

                    } else {
                        CommonUtils.showAlertDialog(getActivity(), null, 0, getString(R.string.msg_api_response_null), getString(R.string.str_ok), true);
                    }
                }
            }


            @Override
            public void onFailure(Call<EFitLoginResponse> call, Throwable t) {
                customProgressDialog.dismiss();
                CommonUtils.showAlertDialog(getActivity(), null, 0, getString(R.string.msg_api_failure), getString(R.string.str_ok), true);

            }
        });


    }

    private boolean validation() {
        boolean isValid = true;
        if (!validateEmail()) {
            isValid = false;
        }
        if (!validatePwd()) {
            isValid = false;
        }
        return isValid;
    }

    private boolean validatePwd() {
        String password = etPassword.getText().toString().trim();
        if (password.isEmpty()) {
            inputLayoutPassword.setError(getString(R.string.password_error));
            requestFocus(etPassword);
            return false;
        }
        if (!Utils.isPasswordValid(password)) {
            inputLayoutPassword.setError(getString(R.string.password_lenght_error));
            requestFocus(etPassword);
            return false;
        } else {
            inputLayoutPassword.setErrorEnabled(false);
        }

        return true;
    }

    private boolean validateEmail() {
        String username = etUsername.getText().toString().trim();
        if (username.isEmpty() || !Utils.isEmailIdValid(username)) {
            inputLayoutEmail.setError(getString(R.string.email_error));
            requestFocus(etUsername);
            return false;
        } else {
            inputLayoutEmail.setErrorEnabled(false);
        }
        return true;
    }

    private void requestFocus(CustomEditTextView view) {
        if (view.requestFocus()) {
            getActivity().getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
        }
    }

    @OnClick(R.id.rootView)
    public void rootclick() {
        Utils.setupTouchUI(rootLayout, getActivity());
    }


    private class LoginTextWatcher implements TextWatcher {
        private final View view;

        LoginTextWatcher(View view) {
            this.view = view;
        }

        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {

        }

        @Override
        public void afterTextChanged(Editable s) {
            switch (view.getId()) {
                case R.id.etUsername:
                    validateEmail();
                    break;
                case R.id.etPassword:
                    validatePwd();
                    break;
            }
        }
    }

}
