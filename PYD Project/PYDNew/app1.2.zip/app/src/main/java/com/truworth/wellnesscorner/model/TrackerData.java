package com.truworth.wellnesscorner.model;

public class TrackerData {
    private String date;
    private double value;
    private String lastStepSyncDate;

    public String getLastStepSyncDate() {
        return lastStepSyncDate;
    }

    public void setLastStepSyncDate(String lStepSyncDate) {
        lastStepSyncDate = lStepSyncDate;
    }

    public String getLastConnectedDevice() {
        return lastConnectedDevice;
    }

    public void setLastConnectedDevice(String lConnectedDevice) {
        lastConnectedDevice = lConnectedDevice;
    }

    public String getLastUpdatedDate() {
        return lastStepUpdatedDate;
    }

    public void setLastUpdatedDate(String lastUpdatedDate) {
        lastStepUpdatedDate = lastUpdatedDate;
    }

    public String getFirstStepSyncDate() {
        return firstStepSyncDate;
    }

    public void setFirstStepSyncDate(String fStepSyncDate) {
        firstStepSyncDate = fStepSyncDate;
    }

    private String lastConnectedDevice;
    private String lastStepUpdatedDate;
    private String firstStepSyncDate;
    private boolean isShow;

    public String getLastStepUpdatedDate() {
        return lastStepUpdatedDate;
    }

    public void setLastStepUpdatedDate(String lastStepUpdatedDate) {
        this.lastStepUpdatedDate = lastStepUpdatedDate;
    }

    public boolean isShow() {
        return isShow;
    }

    public void setShow(boolean show) {
        isShow = show;
    }

    public double getCurrentWeight() {
        return currentWeight;
    }

    public void setCurrentWeight(double currentWeight) {
        this.currentWeight = currentWeight;
    }

    public String getLastTrackedDate() {
        return lastTrackedDate;
    }

    public void setLastTrackedDate(String lastTrackedDate) {
        this.lastTrackedDate = lastTrackedDate;
    }

    public double getFirstWeight() {
        return firstWeight;
    }

    public void setFirstWeight(double firstWeight) {
        this.firstWeight = firstWeight;
    }

    public double getTargetWeight() {
        return targetWeight;
    }

    public void setTargetWeight(double targetWeight) {
        this.targetWeight = targetWeight;
    }

    private double currentWeight;
    private String lastTrackedDate;
    private double firstWeight;
    private double targetWeight;


    public double getValue() {
        return value;
    }

    public void setValue(double value) {
        this.value = value;
    }
    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
}
