package com.truworth.discoverlib;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.TextView;

import com.truworth.discoverlib.fragment.ArticleDetailFragmentNew;
import com.truworth.discoverlib.utils.Utils;

public class ArticleDetailActivity extends AppCompatActivity {
    private Toolbar mToolbar;
    private TextView tvToolbarTitle;
    
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_discover);
        setupToolbar();
        
        Bundle bundle = getIntent().getExtras();

        Utils.replaceFragment(getFragmentManager(), ArticleDetailFragmentNew.newInstance(bundle), ArticleDetailFragmentNew.class.getSimpleName(), true, R.id.container);
    }
    private void setupToolbar() {
        mToolbar = findViewById(R.id.toolbar);
        tvToolbarTitle = findViewById(R.id.tbTitle);
        setSupportActionBar(mToolbar);
        mToolbar.setNavigationIcon(R.drawable.ic_arrow_left_white_24dp);
        mToolbar.setNavigationOnClickListener((View view) -> onBackPressed());
    }

    public void hideToolbarTitle() {
        assert getSupportActionBar() != null;
        tvToolbarTitle.setText("");
    }

    public void setToolBarTitle(String toolBarTitle) {
        tvToolbarTitle.setText(toolBarTitle);
        assert getSupportActionBar() != null;
        getSupportActionBar().show();
    }

    public void showHomeAsUpEnableToolbar() {
        mToolbar.setNavigationIcon(R.drawable.ic_arrow_left_white_24dp);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
            getSupportActionBar().setDisplayShowTitleEnabled(false);
        }
    }
    @Override
    public void onBackPressed() {
        int count = getFragmentManager().getBackStackEntryCount();
        //1 == HomeFragment
        if (count == 1) {
            finish();
        } else {
            super.onBackPressed();
        }
    }
}
