package com.truworth.wellnesscorner.repo.model.response;

import com.truworth.wellnesscorner.model.CityStateCountryData;

import java.util.List;

/**
 * Created by richas on 4/12/2018.
 */

public class GetCountryStateByCityNameResponse {

    private boolean hasError;
    private Object error;
    private List<CityStateCountryData> data;

    public boolean isHasError() {
        return hasError;
    }

    public void setHasError(boolean hasError) {
        this.hasError = hasError;
    }

    public Object getError() {
        return error;
    }

    public void setError(Object error) {
        this.error = error;
    }

    public List<CityStateCountryData> getData() {
        return data;
    }

    public void setData(List<CityStateCountryData> data) {
        this.data = data;
    }
}
