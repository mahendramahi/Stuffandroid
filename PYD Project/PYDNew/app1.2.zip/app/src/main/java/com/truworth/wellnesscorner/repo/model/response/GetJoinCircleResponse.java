package com.truworth.wellnesscorner.repo.model.response;

import java.lang.Error;

public class GetJoinCircleResponse {

    private GetJoinCircleData data;
    private boolean hasError;
    private Error error;

    public GetJoinCircleData getData() {
        return data;
    }

    public void setData(GetJoinCircleData data) {
        this.data = data;
    }

    public boolean isHasError() {
        return hasError;
    }

    public void setHasError(boolean hasError) {
        this.hasError = hasError;
    }

    public Error getError() {
        return error;
    }

    public void setError(Error error) {
        this.error = error;
    }

    public static class GetJoinCircleData {
        private boolean data;
        private int status;
        private String message;

        public boolean isData() {
            return data;
        }

        public void setData(boolean data) {
            this.data = data;
        }

        public int getStatus() {
            return status;
        }

        public void setStatus(int status) {
            this.status = status;
        }

        public String getMessage() {
            return message;
        }

        public void setMessage(String message) {
            this.message = message;
        }
    }
}
