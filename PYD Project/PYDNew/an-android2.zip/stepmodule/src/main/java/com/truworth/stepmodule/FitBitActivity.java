package com.truworth.stepmodule;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.customtabs.CustomTabsClient;
import android.support.customtabs.CustomTabsIntent;
import android.support.customtabs.CustomTabsServiceConnection;
import android.support.customtabs.CustomTabsSession;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;


import com.truworth.stepmodule.utils.Constant;
import com.truworth.stepmodule.utils.FitBitConfig;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;


public class FitBitActivity extends AppCompatActivity {

    private static final String CUSTOM_TAB_PACKAGE_NAME = "com.android.chrome";
    private static final String TAG = "FitBitActivity";
    private CustomTabsClient mClient;
    private CustomTabsSession mCustomTabsSession;
    private CustomTabsServiceConnection mCustomTabsServiceConnection;
    private CustomTabsIntent customTabsIntent;
    private boolean firstTime;

    private static String getQueryString(String url, String tag) {
        String[] params = url.split("&");
        Map<String, String> map = new HashMap<>();
        for (String param : params) {
            String name = param.split("=")[0];
            String value = param.split("=")[1];
            map.put(name, value);
        }

        Set<String> keys = map.keySet();
        for (String key : keys) {
            if (key.equals(tag)) {
                return map.get(key);
            }

        }
        return "";
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fitbit_authentication);

        speedUpChromeTabs();

        CustomTabsClient.bindCustomTabsService(this, CUSTOM_TAB_PACKAGE_NAME, mCustomTabsServiceConnection);

        customTabsIntent = new CustomTabsIntent.Builder(mCustomTabsSession)
                .setToolbarColor(ContextCompat.getColor(this, R.color.colorPrimary))
                .setShowTitle(true)
                .build();

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        unbindCustomTabsService();
    }

    private void speedUpChromeTabs() {
        mCustomTabsServiceConnection = new CustomTabsServiceConnection() {
            @Override
            public void onCustomTabsServiceConnected(ComponentName componentName, CustomTabsClient customTabsClient) {
                //Pre-warming
                mClient = customTabsClient;
                mClient.warmup(0L);
                mCustomTabsSession = mClient.newSession(null);
                customTabsIntent.launchUrl(FitBitActivity.this, Uri.parse(FitBitConfig.AUTHORIZATION_URL));
            }

            @Override
            public void onServiceDisconnected(ComponentName name) {
                mClient = null;
            }
        };
    }

    private void unbindCustomTabsService() {
        if (mCustomTabsServiceConnection == null) {
            return;
        }
        unbindService(mCustomTabsServiceConnection);

        mClient = null;
        mCustomTabsSession = null;
        mCustomTabsServiceConnection = null;
    }



    @Override
    protected void onNewIntent(Intent intent) {
        String response = intent.getDataString();
        Intent resultIntent = new Intent();

        if (response.contains("wellness://#")) {
            String replaceString = response.replace("wellness://#access_token", "access_token");
            String access_token = getQueryString(replaceString, "access_token");
            String user_id = getQueryString(replaceString, "user_id");
            String token_type = getQueryString(replaceString, "token_type");
  //          WellnessCornerApp.getPreferenceManager().clearDeviceConnectTokenPreferences();
  //          WellnessCornerApp.getPreferenceManager().setPrefKeyFitBitAccessToken(token_type + " " + access_token);
            //WellnessCornerApp.getPreferenceManager().setPrefKeyFitBitTokenType();
            //WellnessCornerApp.getPreferenceManager().setPrefKeyFitBitUserId(user_id);
  //          WellnessCornerApp.getPreferenceManager().setPrefKeyDeviceConnected(Constant.FITBIT);

            resultIntent.putExtra("fitBitStatus", "success");
            resultIntent.putExtra("device_type", Constant.FITBIT);
            resultIntent.putExtra("token", token_type + " " + access_token);
            setResult(Activity.RESULT_OK, resultIntent);
        } else {
            resultIntent.putExtra("fitBitStatus", "failure");
            setResult(-2, resultIntent);
        }
        finish();

    }

    @Override
    protected void onResume() {
        super.onResume();
        if (firstTime) {
            if (getIntent().getDataString() == null) {
                finish();
            }
        }
        if (!firstTime) {
            firstTime = !firstTime;
        }
    }
}
