package com.twc.remindermodule;

import android.app.Activity;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.twc.greendaolib.DaoSession;
import com.twc.greendaolib.GreenDaoApp;
import com.twc.greendaolib.ReminderItemDao;
import com.twc.greendaolib.ReminderTimeItem;
import com.twc.greendaolib.ReminderTimeItemDao;
import com.twc.remindermodule.fragments.RecommendedHealthyHabitsFragment;
import com.twc.remindermodule.fragments.RecommendedMyHabitsFragment;
import com.twc.remindermodule.fragments.SleepTrackerLogsFragment;
import com.twc.remindermodule.model.beans.HabitReminderBean;
import com.twc.remindermodule.model.requestbody.BaseMemberIdBody;
import com.twc.remindermodule.model.response.HabitReminderResponse;
import com.twc.remindermodule.rest.ReminderConfig;
import com.twc.remindermodule.rest.RestClient;
import com.twc.remindermodule.service.RemindersService;
import com.twc.remindermodule.utils.DialogFactory;
import com.twc.remindermodule.utils.RemindersDefault;
import com.twc.remindermodule.utils.Utils;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ReminderActivity extends AppCompatActivity {

    private int totalHabits;
    private String token;
    private String waterIntake,sleep="";
    private ArrayList<HabitReminderBean> habitReminderList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reminder);
        new GlideConfig().glideSetup(this);
        Intent intent = getIntent();
        sleep= intent.getStringExtra("sleep");
        totalHabits = intent.getIntExtra("totalHabits", 0);
        token= intent.getStringExtra("token");
        waterIntake = intent.getStringExtra("waterIntake");
       if(sleep != null && sleep.equalsIgnoreCase("sleep")){
           Utils.replaceFragment(getFragmentManager(), new SleepTrackerLogsFragment(), SleepTrackerLogsFragment.class.getSimpleName(), true, R.id.fragmentContainerReminder);
       }else {
           Bundle bundle = intent.getExtras();
           if (totalHabits <= 0) {
               Utils.replaceFragment(getFragmentManager(), RecommendedHealthyHabitsFragment.newInstance(bundle), RecommendedHealthyHabitsFragment.class.getSimpleName(), true, R.id.fragmentContainerReminder);
           } else {
               Utils.replaceFragment(getFragmentManager(), RecommendedMyHabitsFragment.newInstance(bundle), RecommendedMyHabitsFragment.class.getSimpleName(), true, R.id.fragmentContainerReminder);
           }
       }
    }

    @Override
    public void onBackPressed() {
        Utils.hideSoftKeyboard(this);
        int count = getFragmentManager().getBackStackEntryCount();
        if (count == 1) {
            setResult(Activity.RESULT_OK);
            finish();
        } else {
            super.onBackPressed();
        }
    }


}
