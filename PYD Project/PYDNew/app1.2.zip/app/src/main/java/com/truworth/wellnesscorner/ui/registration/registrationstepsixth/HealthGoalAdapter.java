package com.truworth.wellnesscorner.ui.registration.registrationstepsixth;

import android.databinding.DataBindingUtil;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.truworth.wellnesscorner.R;
import com.truworth.wellnesscorner.databinding.RowHealthGoalBinding;
import com.truworth.wellnesscorner.repo.model.response.HealthGoalResponse;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by PalakC on 4/5/2018.
 */

public class HealthGoalAdapter extends RecyclerView.Adapter<HealthGoalAdapter.ViewHolder> {

    private List<HealthGoalResponse.HealthGoalItem> goalItems;
    private HealthGoalItemListener listener;
    private ImageView selectedGoal = null;
    private int selectedPosition = -1;
    private ArrayList<Integer> healthIds=new ArrayList<>();

    public HealthGoalAdapter(List<HealthGoalResponse.HealthGoalItem> goalItems, HealthGoalItemListener listener) {
        this.goalItems = goalItems;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        RowHealthGoalBinding goalBinding =
                DataBindingUtil.inflate(LayoutInflater.from(parent.getContext()), R.layout.row_health_goal, parent, false);
        return new ViewHolder(goalBinding);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.bindItems(goalItems.get(position));
    }

    @Override
    public int getItemCount() {
        return goalItems.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        RowHealthGoalBinding binding;

        public ViewHolder(RowHealthGoalBinding itemView) {
            super(itemView.goalItemLayout);
            this.binding = itemView;

            binding.goalItemLayout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    if (getAdapterPosition() == 0 || getAdapterPosition() == 1) {
                        if (selectedGoal != null) {
                            selectedGoal.setSelected(false);
                            goalItems.get(selectedPosition).setIsSelected(false);
                         //   healthIds.remove(Integer.valueOf(goalItems.get(selectedPosition).getId()));

                        }
                        if (selectedPosition != getAdapterPosition()) {
                            if(selectedPosition >= 0)
                                healthIds.remove(Integer.valueOf(goalItems.get(selectedPosition).getId()));
                            binding.ivGoalImage.setSelected(true);
                            selectedGoal = binding.ivGoalImage;
                            selectedPosition = getAdapterPosition();
                            goalItems.get(getAdapterPosition()).setIsSelected(true);
                        } else{
                            selectedPosition=-1;
                            selectedGoal=null;
                        }
                    } else {
                        if (!(goalItems.get(getAdapterPosition()).isIsSelected())) {
                            view.setSelected(true);
                            goalItems.get(getAdapterPosition()).setIsSelected(true);
                        } else {
                            view.setSelected(false);
                            goalItems.get(getAdapterPosition()).setIsSelected(false);
                        }
                    }

                    if (goalItems.get(getAdapterPosition()).isIsSelected()) {
                        healthIds.add(goalItems.get(getAdapterPosition()).getId());
                    } else {
                        healthIds.remove(Integer.valueOf(goalItems.get(getAdapterPosition()).getId()));
                    }
                    listener.onItemSeleced(healthIds);
                }
            });

        }

        public void bindItems(HealthGoalResponse.HealthGoalItem goalItem) {
            HealthGoalItemViewModel viewModel = new HealthGoalItemViewModel(goalItem);

            binding.setViewModle(viewModel);

            if (goalItems.get(getAdapterPosition()).getId() == 1)
                binding.ivGoalImage.setImageResource(R.drawable.loose_weight_selector);
            else if (goalItems.get(getAdapterPosition()).getId() == 2)
                binding.ivGoalImage.setImageResource(R.drawable.selector_gain_weight);
            else if (goalItems.get(getAdapterPosition()).getId() == 3)
                binding.ivGoalImage.setImageResource(R.drawable.selector_get_in_shape);
            else if (goalItems.get(getAdapterPosition()).getId() == 4)
                binding.ivGoalImage.setImageResource(R.drawable.selector_build_muscle);
            else if (goalItems.get(getAdapterPosition()).getId() == 5)
                binding.ivGoalImage.setImageResource(R.drawable.selector_eat_better);
            else if (goalItems.get(getAdapterPosition()).getId() == 6)
                binding.ivGoalImage.setImageResource(R.drawable.selector_sleep_better);
            else if (goalItems.get(getAdapterPosition()).getId() == 7)
                binding.ivGoalImage.setImageResource(R.drawable.selector_lose_bp);
            else if (goalItems.get(getAdapterPosition()).getId() == 8)
                binding.ivGoalImage.setImageResource(R.drawable.selector_lose_sugar);
            else if (goalItems.get(getAdapterPosition()).getId() == 9)
                binding.ivGoalImage.setImageResource(R.drawable.selector_lower_stress);

        }

    }


}
