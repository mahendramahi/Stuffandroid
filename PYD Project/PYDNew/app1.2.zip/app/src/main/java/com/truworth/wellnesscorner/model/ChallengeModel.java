package com.truworth.wellnesscorner.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class ChallengeModel {

    @SerializedName("challengeIdentity")
    @Expose
    private String challengeIdentity;
    @SerializedName("challengeName")
    @Expose
    private String challengeName;
    @SerializedName("challengeStartDate")
    @Expose
    private String challengeStartDate;
    @SerializedName("challengeEndDate")
    @Expose
    private String challengeEndDate;
    @SerializedName("challengeEarnPeps")
    @Expose
    private int challengeEarnPeps;
    @SerializedName("challengeTypeId")
    @Expose
    private int challengeTypeId;
    @SerializedName("memberIsCheckIn")
    @Expose
    private int memberIsCheckIn;

    public String getChallengeIdentity() {
        return challengeIdentity;
    }

    public void setChallengeIdentity(String challengeIdentity) {
        this.challengeIdentity = challengeIdentity;
    }

    public String getChallengeName() {
        return challengeName;
    }

    public void setChallengeName(String challengeName) {
        this.challengeName = challengeName;
    }

    public String getChallengeStartDate() {
        return challengeStartDate;
    }

    public void setChallengeStartDate(String challengeStartDate) {
        this.challengeStartDate = challengeStartDate;
    }

    public String getChallengeEndDate() {
        return challengeEndDate;
    }

    public void setChallengeEndDate(String challengeEndDate) {
        this.challengeEndDate = challengeEndDate;
    }

    public int getChallengeEarnPeps() {
        return challengeEarnPeps;
    }

    public void setChallengeEarnPeps(int challengeEarnPeps) {
        this.challengeEarnPeps = challengeEarnPeps;
    }

    public int getChallengeTypeId() {
        return challengeTypeId;
    }

    public void setChallengeTypeId(int challengeTypeId) {
        this.challengeTypeId = challengeTypeId;
    }

    public int getMemberIsCheckIn() {
        return memberIsCheckIn;
    }

    public void setMemberIsCheckIn(int memberIsCheckIn) {
        this.memberIsCheckIn = memberIsCheckIn;
    }
}
