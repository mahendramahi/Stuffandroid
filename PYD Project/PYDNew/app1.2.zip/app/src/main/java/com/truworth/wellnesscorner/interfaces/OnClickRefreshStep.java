package com.truworth.wellnesscorner.interfaces;

public interface OnClickRefreshStep {
    void onClickRefresh();
}
