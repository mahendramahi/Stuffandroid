package com.truworth.wellnesscorner.repo.model.request;

public class CircleDetailPostRequest extends BaseRequest {


    private int PageIndex;
    private int PageSize;
    private String PostContentIdentity;
    private String PostContentTypeId;



    public int getPageIndex() {
        return PageIndex;
    }

    public void setPageIndex(int PageIndex) {
        this.PageIndex = PageIndex;
    }

    public int getPageSize() {
        return PageSize;
    }

    public void setPageSize(int PageSize) {
        this.PageSize = PageSize;
    }

    public String getPostContentIdentity() {
        return PostContentIdentity;
    }

    public void setPostContentIdentity(String PostContentIdentity) {
        this.PostContentIdentity = PostContentIdentity;
    }

    public String getPostContentTypeId() {
        return PostContentTypeId;
    }

    public void setPostContentTypeId(String PostContentTypeId) {
        this.PostContentTypeId = PostContentTypeId;
    }
}
