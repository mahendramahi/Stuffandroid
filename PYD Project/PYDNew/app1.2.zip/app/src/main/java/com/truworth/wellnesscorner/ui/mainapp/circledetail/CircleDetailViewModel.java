package com.truworth.wellnesscorner.ui.mainapp.circledetail;

import android.databinding.ObservableField;

import com.truworth.wellnesscorner.TheWellnessCornerApp;
import com.truworth.wellnesscorner.base.BaseViewModel;
import com.truworth.wellnesscorner.repo.DashboardRepository;
import com.truworth.wellnesscorner.repo.model.request.BaseRequest;
import com.truworth.wellnesscorner.repo.model.response.CircleResponse;
import com.truworth.wellnesscorner.repo.model.response.CircleResponseData;
import com.truworth.wellnesscorner.utils.SingleLiveEvent;

import javax.inject.Inject;

import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;

public class CircleDetailViewModel extends BaseViewModel {
    @Inject
    DashboardRepository dashboardRepository;

    public SingleLiveEvent<CircleResponseData> getCircleResponseData() {
        return circleResponseData;
    }

    public SingleLiveEvent<CircleResponseData> circleResponseData = new SingleLiveEvent<>();
   public  ObservableField<String> circleImageUrl = new ObservableField<>();
    public  ObservableField<String> circleName = new ObservableField<>();

    public CircleDetailViewModel() {
        TheWellnessCornerApp.getApp().component().inject(this);
    }

    ObservableField<String> imageUrl = new ObservableField<>();

    SingleLiveEvent<Void> imageClick = new SingleLiveEvent();

    public SingleLiveEvent<Void> getImageClick() {
        return imageClick;
    }

    public void circleImageClick() {
        imageClick.call();
    }

    public void loadCircleDetail(String circleIdentity) {
        BaseRequest circleCoachRequest = new BaseRequest();
        circleCoachRequest.setId(circleIdentity);
        dashboardRepository.getCirclePosts(circleCoachRequest).subscribe(new Observer<CircleResponse>() {
            @Override
            public void onSubscribe(Disposable d) {

            }

            @Override
            public void onNext(CircleResponse circleResponse) {
                if (!circleResponse.getHasError()) {
                    circleResponseData.setValue(circleResponse.getData());
                    circleImageUrl.set(circleResponse.getData().getCircleImage());
                    circleName.set(circleResponse.getData().getCircleName());
                }
            }

            @Override
            public void onError(Throwable e) {

            }

            @Override
            public void onComplete() {

            }
        });
    }


}
