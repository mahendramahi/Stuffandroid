package com.twc.dailylog.model.requestbody;

public class WaterTrackerDataRequest {


    private String Date;

    public String getDate() {
        return Date;
    }

    public void setDate(String Date) {
        this.Date = Date;
    }
}
