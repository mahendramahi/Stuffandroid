package com.twc.hramodule.views;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Typeface;
import android.util.AttributeSet;

import com.twc.hramodule.R;


public class CustomEditTextView extends android.support.v7.widget.AppCompatEditText
{

    private String mFontName;
    private Context mContext;

    public CustomEditTextView(Context context, AttributeSet attrs, int defStyle)
    {
        super(context, attrs, defStyle);
        mContext = context;
        init(attrs);
    }

    public CustomEditTextView(Context context, AttributeSet attrs)
    {
        super(context, attrs);
        mContext = context;
        init(attrs);
    }

    public CustomEditTextView(Context context)
    {
        super(context);
        mContext = context;
        init(null);
    }

    private void init(AttributeSet attrs)
    {
        if(attrs != null)
        {
            TypedArray a = getContext().obtainStyledAttributes(attrs, R.styleable.CustomTextView);
            mFontName = a.getString(R.styleable.CustomTextView_fontName);
            if(mFontName != null)
            {
                setFontAccordingToAttrs();
            }

            a.recycle();
        }
    }

    private void setFontAccordingToAttrs()
    {
        if(mFontName.equalsIgnoreCase(getResources().getString(R.string.fnt_cabin_bold)))
        {
            setTypeface(Typeface.createFromAsset(mContext.getAssets(), "fonts/Cabin-Bold.ttf"));
        }
        else if(mFontName.equalsIgnoreCase(getResources().getString(R.string.fnt_cabin_bold_italic)))
        {
            setTypeface(Typeface.createFromAsset(mContext.getAssets(), "fonts/Cabin-BoldItalic.ttf"));
        }
        else if(mFontName.equalsIgnoreCase(getResources().getString(R.string.fnt_cabin_italic)))
        {
            setTypeface(Typeface.createFromAsset(mContext.getAssets(), "fonts/Cabin-Italic.ttf"));
        }
        else if(mFontName.equalsIgnoreCase(getResources().getString(R.string.fnt_cabin_medium)))
        {
            setTypeface(Typeface.createFromAsset(mContext.getAssets(), "fonts/Cabin-Medium.ttf"));
        }
        else if(mFontName.equalsIgnoreCase(getResources().getString(R.string.fnt_cabin_medium_italic)))
        {
            setTypeface(Typeface.createFromAsset(mContext.getAssets(), "fonts/Cabin-MediumItalic.ttf"));
        }
        else if(mFontName.equalsIgnoreCase(getResources().getString(R.string.fnt_cabin_regular)))
        {
            setTypeface(Typeface.createFromAsset(mContext.getAssets(), "fonts/Cabin-Regular.ttf"));
        }
        else if(mFontName.equalsIgnoreCase(getResources().getString(R.string.fnt_cabin_semibold)))
        {
            setTypeface(Typeface.createFromAsset(mContext.getAssets(), "fonts/Cabin-SemiBold.ttf"));
        }
        else if(mFontName.equalsIgnoreCase(getResources().getString(R.string.fnt_cabin_semibold_italic)))
        {
            setTypeface(Typeface.createFromAsset(mContext.getAssets(), "fonts/Cabin-SemiBoldItalic.ttf"));
        }
         /*new font added by pankaj sharma 2017-03-24*/
        else if(mFontName.equalsIgnoreCase(getResources().getString(R.string.fnt_roboto_black)))
        {
            setTypeface(Typeface.createFromAsset(mContext.getAssets(), "fonts/Roboto-Black.ttf"));
        }
        else if(mFontName.equalsIgnoreCase(getResources().getString(R.string.fnt_roboto_light)))
        {
            setTypeface(Typeface.createFromAsset(mContext.getAssets(), "fonts/Roboto-Light.ttf"));
        }
        else
        {
            setTypeface(Typeface.createFromAsset(mContext.getAssets(), "fonts/Cabin-Regular.ttf"));
        }
    }

  /*  @Override
    public boolean onFilterTouchEventForSecurity(MotionEvent event) {
        return (event.getFlags() & MotionEvent.FLAG_WINDOW_IS_OBSCURED) == 0;
    }*/
}
