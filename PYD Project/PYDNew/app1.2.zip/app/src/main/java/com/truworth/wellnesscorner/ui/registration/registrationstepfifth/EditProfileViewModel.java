package com.truworth.wellnesscorner.ui.registration.registrationstepfifth;

import android.databinding.ObservableBoolean;
import android.databinding.ObservableField;
import android.text.Editable;
import android.text.TextWatcher;

import com.truworth.wellnesscorner.TheWellnessCornerApp;
import com.truworth.wellnesscorner.base.BaseViewModel;
import com.truworth.wellnesscorner.repo.RegistrationRepository;
import com.truworth.wellnesscorner.repo.model.request.PostMediaTypeDataRequest;
import com.truworth.wellnesscorner.repo.model.request.SaveProfileRequest;
import com.truworth.wellnesscorner.repo.model.request.ScreenNameRequest;
import com.truworth.wellnesscorner.repo.model.response.SaveProfileResponse;
import com.truworth.wellnesscorner.repo.model.response.ScreenNameResponse;
import com.truworth.wellnesscorner.utils.AppConstants;
import com.truworth.wellnesscorner.utils.SingleLiveEvent;

import javax.inject.Inject;

import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;

/**
 * Created by GurvinderS on 4/9/2018.
 */

public class EditProfileViewModel extends BaseViewModel {

    @Inject
    RegistrationRepository repository;
    //public ObservableBoolean isBioHintVisible = new ObservableBoolean();
    public ObservableBoolean isScreenNameVisible = new ObservableBoolean();
    public ObservableBoolean isValidScreenName = new ObservableBoolean();
    public ObservableField<String> screenName = new ObservableField<>();
    public ObservableField<String> bio = new ObservableField<>();
    public ObservableField<String> imageExtension = new ObservableField<>();
    public ObservableField<String> image = new ObservableField<>();

    public ObservableBoolean isProgress = new ObservableBoolean();

    public int bioCharCount = 0;

    public SingleLiveEvent<Void> continueClick = new SingleLiveEvent<>();

    public SingleLiveEvent<Void> getContinueClick() {
        return continueClick;
    }

    private final SingleLiveEvent<Void> setBioCharCount = new SingleLiveEvent<>();

    public SingleLiveEvent<Void> getSetBioCharCount() {
        return setBioCharCount;
    }

    public ObservableField<String> errorMessage = new ObservableField<>();
    private final SingleLiveEvent<Void> callDialogChooser = new SingleLiveEvent<>();

    public SingleLiveEvent<Void> getOnContinue() {
        return onContinue;
    }

    private final SingleLiveEvent<Void> onContinue = new SingleLiveEvent<>();

    public SingleLiveEvent<Void> getcallDialogChooser() {
        return callDialogChooser;
    }

    public EditProfileViewModel() {
        TheWellnessCornerApp.getApp().component().inject(this);
        isScreenNameVisible.set(false);
       // isBioHintVisible.set(true);
    }

    public void openChooserDialog() {

        callDialogChooser.call();
    }

    public void setImageExtension(String extension) {
        imageExtension.set(extension);
    }

    public void setImage(String img) {
        image.set(img);
    }

    public void saveProfileData() {

        SaveProfileRequest request = new SaveProfileRequest();
        request.setScreenName(screenName.get());
        if(bio.get()!=null)
            request.setBio(bio.get().toString().trim());
        else
            request.setBio("");

        request.setImageExtention(imageExtension.get());
        request.setImage(image.get());


        repository.saveProfile(request).subscribe(new Observer<SaveProfileResponse>() {

            @Override
            public void onSubscribe(Disposable d) {

            }


            @Override
            public void onNext(SaveProfileResponse saveProfileResponse) {
                if (!saveProfileResponse.isHasError()) {
                    if (saveProfileResponse.getData().isIsSave()) {
                        onContinue.call();
                    }
                } else {
                    errorMessage.set(saveProfileResponse.getError().getMessage());
                }
            }


            @Override
            public void onError(Throwable e) {

            }


            @Override
            public void onComplete() {

            }
        });
    }
    public TextWatcher screenNameWatcher() {
        return new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                //setEmail(charSequence.toString());
                //emailError.set(checkEmailValid(email));
                if (charSequence.length() > 0) {
                    CheckScreenName();
                    isScreenNameVisible.set(true);
                } else {
                    isScreenNameVisible.set(false);
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        };
    }

    public void CheckScreenName() {

        ScreenNameRequest request = new ScreenNameRequest();
        request.setScreenName(screenName.get());


        repository.checkScreenName(request).subscribe(new Observer<ScreenNameResponse>() {

            @Override
            public void onSubscribe(Disposable d) {

            }


            @Override
            public void onNext(ScreenNameResponse response) {
                if (!response.isHasError()) {
                    if (response.getData().isIsScreenNameExist()) {
                        // screen name already exist
                        errorMessage.set("Screen name already exist!");
                        isValidScreenName.set(false);
                    }
                } else {

                    if (response.getError().getCode() == 2) {
                        errorMessage.set(null);
                        isValidScreenName.set(true);
                    }

                }
            }


            @Override
            public void onError(Throwable e) {

            }


            @Override
            public void onComplete() {

            }
        });
    }

    public TextWatcher bioTextWatcher() {
        return new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

                bioCharCount = charSequence.length();
                setBioCharCount.call();
                /*if(charSequence.length()>0)
                   isBioHintVisible.set(false);
               else
                   isBioHintVisible.set(true);*/
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        };
    }

    public void continueBtnClick(){
        continueClick.call();
    }
}
