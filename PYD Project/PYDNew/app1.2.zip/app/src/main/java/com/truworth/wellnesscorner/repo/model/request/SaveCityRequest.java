package com.truworth.wellnesscorner.repo.model.request;

/**
 * Created by richas on 4/16/2018.
 */

public class SaveCityRequest {

    private String CityId;

    public String getCityId() {
        return CityId;
    }

    public void setCityId(String CityId) {
        this.CityId = CityId;
    }
}
