package com.twc.dailylog.model.beans;


import java.util.ArrayList;

/**
 * Created by ManishJ1 on 7/5/2016.
 */
public class ExerciseSectionItem {
    private String sectionName;
    private ArrayList<com.twc.greendaolib.ExerciseItem> mExerciseItemsList;

    public String getSectionName() {
        return sectionName;
    }

    public void setSectionName(String sectionName) {
        this.sectionName = sectionName;
    }

    public ArrayList<com.twc.greendaolib.ExerciseItem> getmExerciseItemsList() {
        return mExerciseItemsList;
    }

    public void setmExerciseItemsList(ArrayList<com.twc.greendaolib.ExerciseItem> mExerciseItemsList) {
        this.mExerciseItemsList = mExerciseItemsList;
    }
}
