package com.truworth.stepmodule;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.util.Log;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.fitness.Fitness;
import com.google.android.gms.fitness.FitnessOptions;
import com.google.android.gms.fitness.data.DataType;
import com.samsung.android.sdk.healthdata.HealthConnectionErrorResult;
import com.samsung.android.sdk.healthdata.HealthConstants;
import com.samsung.android.sdk.healthdata.HealthDataService;
import com.samsung.android.sdk.healthdata.HealthDataStore;
import com.samsung.android.sdk.healthdata.HealthPermissionManager;
import com.samsung.android.sdk.healthdata.HealthResultHolder;
import com.truworth.stepmodule.inteface.OnConnectionResultInfo;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * If this code works, it was written by Somesh Kumar  on 26 April, 2018. If not, I don't know who wrote it.
 */
public class StepConnectionHelper {
    private static final String SAMSUNG_DIGITAL_HEALTH_CUSTOM_DATA_TYPE = "com.samsung.shealth.step_daily_trend";
    private int GOOGLE_FITNESS_REQUEST_CODE;
    private HealthDataStore samsungHealthDataStore;
    private Set<HealthPermissionManager.PermissionKey> samsungPermissionKeys;
    private HealthResultHolder.ResultListener<HealthPermissionManager.PermissionResult> samsungPermissionListener;
    private HealthDataStore.ConnectionListener samsungConnectionListener;
    private Context context;
    private OnConnectionResultInfo onConnectionResultInfo;
    private int GOOGLE_OAUTH_REQUEST_CODE;


    private StepConnectionHelper() {
        throw new Error("Can't use constructor");
    }

    public StepConnectionHelper(Context context, OnConnectionResultInfo onConnectionResultInfo) {
        this.context = context;
        this.onConnectionResultInfo = onConnectionResultInfo;
    }


    /********************************************
     -------------------GOOGLE-------------------
     ********************************************/
    /**
     * @param GOOGLE_OAUTH_REQUEST_CODE   NEEDED FOR ACCOUNT PERMISSION CALLBACK
     * @param GOOGLE_FITNESS_REQUEST_CODE NEEDED FOR FITNESS PERMISSION CALLBACK
     */
    public void startGoogleFitProcess(int GOOGLE_OAUTH_REQUEST_CODE, int GOOGLE_FITNESS_REQUEST_CODE) {
        this.GOOGLE_OAUTH_REQUEST_CODE = GOOGLE_OAUTH_REQUEST_CODE;
        this.GOOGLE_FITNESS_REQUEST_CODE = GOOGLE_FITNESS_REQUEST_CODE;
        GoogleSignInOptions googleSignInOptions = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail()
                .build();

        GoogleSignInClient mGoogleSignInClient = GoogleSignIn.getClient(context, googleSignInOptions);
        //  if (GoogleSignIn.getLastSignedInAccount(context) == null) {
        Intent signInIntent = mGoogleSignInClient.getSignInIntent();
        ((Activity) context).startActivityForResult(signInIntent, GOOGLE_OAUTH_REQUEST_CODE);
        //  }
        //     else {
        //        requestGoogleFitnessPermission();
        //     }
    }

    public void requestGoogleFitnessPermission() {
        FitnessOptions fitnessOptions = FitnessOptions.builder()
                .addDataType(DataType.TYPE_STEP_COUNT_DELTA, FitnessOptions.ACCESS_WRITE)
                .addDataType(DataType.AGGREGATE_STEP_COUNT_DELTA, FitnessOptions.ACCESS_WRITE)
                .build();

        if (!GoogleSignIn.hasPermissions(GoogleSignIn.getLastSignedInAccount(context), fitnessOptions)) {
            GoogleSignIn.requestPermissions((Activity) context, GOOGLE_FITNESS_REQUEST_CODE, GoogleSignIn.getLastSignedInAccount(context), fitnessOptions);
        } else {
            onGoogleFitPermissionGranted();
        }
    }

    public void onGoogleFitPermissionGranted() {
        GoogleSignInAccount account = GoogleSignIn.getLastSignedInAccount(context);
        if (onConnectionResultInfo != null) {
            onConnectionResultInfo.onResultInfo("Google fit", account.getEmail());
        }
    }

    public void disconnectGoogle() {
        if (GoogleSignIn.getLastSignedInAccount(context) != null) {
            Fitness.getConfigClient(context, GoogleSignIn.getLastSignedInAccount(context)).disableFit();
        } else {
            // No account registered
        }

    }

    /********************************************
     ----------------SAMSUNG HEALTH--------------
     ********************************************/

    public void startSamsungProcess() {
        setPermissionCallback();
        setConnectionListener();

        samsungPermissionKeys = new HashSet<>();
        samsungPermissionKeys.add(new HealthPermissionManager.PermissionKey(HealthConstants.StepCount.HEALTH_DATA_TYPE, HealthPermissionManager.PermissionType.READ));
        samsungPermissionKeys.add(new HealthPermissionManager.PermissionKey(SAMSUNG_DIGITAL_HEALTH_CUSTOM_DATA_TYPE, HealthPermissionManager.PermissionType.READ));
        HealthDataService healthDataService = new HealthDataService();
        try {
            healthDataService.initialize(context);
        } catch (Exception e) {
            e.printStackTrace();
            if (onConnectionResultInfo != null) {
                onConnectionResultInfo.onConnectionError(e.getLocalizedMessage());
            }
        }

        samsungHealthDataStore = new HealthDataStore(context, samsungConnectionListener);
        samsungHealthDataStore.connectService();

    }


    private void setPermissionCallback() {
        samsungPermissionListener = permissionResult -> {
            if (!((Activity) context).isDestroyed()) {
                Map<HealthPermissionManager.PermissionKey, Boolean> resultMap = permissionResult.getResultMap();

                if (resultMap.containsValue(Boolean.FALSE)) {
                    if (((Activity) context).isFinishing()) {
                        return;
                    }
                    if (onConnectionResultInfo != null) {
                        onConnectionResultInfo.onConnectionError("All permissions should be acquired");
                    }
                } else {
                    if (onConnectionResultInfo != null) {
                        onConnectionResultInfo.onResultInfo("samsung health", "samsung");
                    }
                }
            }
        };
    }

    private void setConnectionListener() {
        samsungConnectionListener = new HealthDataStore.ConnectionListener() {
            @Override
            public void onConnected() {
                HealthPermissionManager sHealthPermissionManager = new HealthPermissionManager(samsungHealthDataStore);
                try {
                    Map<HealthPermissionManager.PermissionKey, Boolean> resultMap = sHealthPermissionManager.isPermissionAcquired(samsungPermissionKeys);

                    if (resultMap.containsValue(Boolean.FALSE)) {
                        sHealthPermissionManager
                                .requestPermissions(samsungPermissionKeys, (Activity) context)
                                .setResultListener(samsungPermissionListener);
                    } else {
                        if (onConnectionResultInfo != null) {
                            onConnectionResultInfo.onResultInfo("samsung health", "samsung");
                        }
                    }
                } catch (Exception ignored) {
                    ignored.printStackTrace();
                }
            }

            @Override
            public void onConnectionFailed(HealthConnectionErrorResult error) {
                showConnectionFailureDialog(error);
                //    Toast.makeText(context, "onConnectionFailed", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onDisconnected() {
                if (onConnectionResultInfo != null) {
                    onConnectionResultInfo.onConnectionError("Client Disconnected");
                }
                //  Toast.makeText(context, "onDisconnected", Toast.LENGTH_SHORT).show();
            }
        };
    }

    private void showConnectionFailureDialog(HealthConnectionErrorResult error) {
        AlertDialog.Builder alert = new AlertDialog.Builder(context);
        String message = "Connection with Samsung Health is not available";

        if (error.hasResolution()) {
            switch (error.getErrorCode()) {
                case HealthConnectionErrorResult.PLATFORM_NOT_INSTALLED:
                    message = "Please install Samsung Health";
                    break;
                case HealthConnectionErrorResult.OLD_VERSION_PLATFORM:
                    message = "Please upgrade Samsung Health";
                    break;
                case HealthConnectionErrorResult.PLATFORM_DISABLED:
                    message = "Please enable Samsung Health";
                    break;
                case HealthConnectionErrorResult.USER_AGREEMENT_NEEDED:
                    message = "Please agree with Samsung Health policy";
                    break;
                default:
                    message = "Please make Samsung Health available";
                    break;
            }
        }

        alert.setMessage(message);

        alert.setPositiveButton("OK", (dialog, id) -> {
            if (error.hasResolution()) {
                error.resolve((Activity) context);
            }
        });

        if (error.hasResolution()) {
            alert.setNegativeButton("Cancel", null);
        }

        alert.show();
    }

    public void disconnectSamsung() {
        if (samsungHealthDataStore != null) {
            Log.d("Samsung", "Disconnect");
            samsungHealthDataStore.disconnectService();
            Log.d("Samsung", "Disconnect Done");
        }
    }


    /********************************************
     ----------------MISFIT--------------
     *******************************************
     * @param MISFIT_REQUEST_CODE*/

    public void startMisfitProcess(int MISFIT_REQUEST_CODE) {
        ((Activity) context).startActivityForResult((new Intent(context, MisFitActivity.class)), MISFIT_REQUEST_CODE);
    }

    public void onMisFitPermissionGranted(String deviceType, String token) {
        if (onConnectionResultInfo != null) {
            onConnectionResultInfo.onResultInfo("Misfit", token);
        }
    }

    /********************************************
     ----------------FITBIT--------------
     *******************************************
     * @param FITBIT_REQUEST_CODE*/

    public void startFitbitProcess(int FITBIT_REQUEST_CODE) {
        ((Activity) context).startActivityForResult((new Intent(context, FitBitActivity.class)), FITBIT_REQUEST_CODE);
    }


    public void onFitbitPermissionGranted(String deviceType, String token) {
        if (onConnectionResultInfo != null) {
            onConnectionResultInfo.onResultInfo("Fitbit", token);
        }
    }


}
