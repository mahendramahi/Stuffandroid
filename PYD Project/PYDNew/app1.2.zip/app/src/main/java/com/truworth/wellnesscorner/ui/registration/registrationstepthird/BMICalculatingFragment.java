package com.truworth.wellnesscorner.ui.registration.registrationstepthird;

import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.truworth.wellnesscorner.BR;
import com.truworth.wellnesscorner.R;
import com.truworth.wellnesscorner.base.BaseFragment;
import com.truworth.wellnesscorner.databinding.FragmentBmiCalculatingBinding;

/**
 * Created by PalakC on 4/11/2018.
 */

public class BMICalculatingFragment extends BaseFragment<FragmentBmiCalculatingBinding,BMICalculatingViewModel>{
    public static final String TAG = "BMICalculatingFragment";
    private static final String ARG_HEIGHT = "height";
    private static final String ARG_WEIGHT = "weight";


    BMICalculatingViewModel viewModel;
    private int mHeight;
    private int mWeight;

    public static BMICalculatingFragment newInstance(int height, int weight) {
        BMICalculatingFragment fragment = new BMICalculatingFragment();
        Bundle args = new Bundle();
        args.putInt(ARG_HEIGHT, height);
        args.putInt(ARG_WEIGHT, weight);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public int getBindingVariable() {
        return BR.viewModel;
    }

    @Override
    public int getLayoutId() {
        return R.layout.fragment_bmi_calculating;
    }

    @Override
    public BMICalculatingViewModel getViewModel() {
        viewModel = ViewModelProviders.of(this).get(BMICalculatingViewModel.class);
        return viewModel;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mHeight = getArguments().getInt(ARG_HEIGHT);
            mWeight = getArguments().getInt(ARG_WEIGHT);
        }
    }



    @Override
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        viewModel.getBMIAndIBW(mHeight, mWeight);
        setObserverToOpenBmiScreen();

    }

    private void setObserverToOpenBmiScreen() {
        viewModel.getOnClickContinue().observe(this, new Observer<Void>() {
            @Override
            public void onChanged(@Nullable Void aVoid) {
                openBMIAndIBWFragment();
            }
        });
    }
    private void openBMIAndIBWFragment() {
        getActivity().getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.registerContainer, BMIFragment.newInstance(viewModel.getBmiData()), BMIFragment.TAG).addToBackStack(BMIFragment.TAG)
                .commit();
    }
}
