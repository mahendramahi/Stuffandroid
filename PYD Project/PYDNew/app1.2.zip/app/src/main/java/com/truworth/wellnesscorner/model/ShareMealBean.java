package com.truworth.wellnesscorner.model;

import java.util.List;

public class ShareMealBean {
    private String date;
    private List<MealDataBean> mealData;

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public List<MealDataBean> getMealData() {
        return mealData;
    }

    public void setMealData(List<MealDataBean> mealData) {
        this.mealData = mealData;
    }

}
