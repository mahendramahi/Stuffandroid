package com.truworth.wellnesscorner.ui.registration.registrationstepsixth;


import android.arch.lifecycle.ViewModelProviders;
import android.content.Intent;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.GridLayoutManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.truworth.wellnesscorner.R;
import com.truworth.wellnesscorner.databinding.FragmentHealthGoal1Binding;
import com.truworth.wellnesscorner.repo.model.response.HealthGoalResponse;
import com.truworth.wellnesscorner.ui.mainapp.HomeDashBoardActivity;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by PalakC on 4/5/2018.
 */

public class HealthGoalFragment extends Fragment implements HealthGoalItemListener {
    public static final String TAG = "healthGoalFragment";
    FragmentHealthGoal1Binding binding;
    HealthGoalViewModel viewModel;
    private List<HealthGoalResponse.HealthGoalItem> goalItems;
    private HealthGoalAdapter adapter;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        goalItems = new ArrayList<>();
        adapter = new HealthGoalAdapter(goalItems, this);
    }

    private void setHealthGoal() {
        viewModel.getOnHealthGoal().observe(this, new android.arch.lifecycle.Observer<List<HealthGoalResponse.HealthGoalItem>>() {
            @Override
            public void onChanged(@Nullable List<HealthGoalResponse.HealthGoalItem> healthGoalItems) {
                if (healthGoalItems != null) {
                    goalItems.addAll(healthGoalItems);
                }
                adapter.notifyDataSetChanged();
            }
        });
    }

    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        binding = DataBindingUtil.inflate(inflater, R.layout.fragment_health_goal1, container, false);
        viewModel = ViewModelProviders.of(this).get(HealthGoalViewModel.class);
        binding.setViewModel(viewModel);

        binding.rvGoalList.setAdapter(adapter);
        binding.rvGoalList.setLayoutManager(new GridLayoutManager(getActivity(), 2));

        viewModel.healthGoalItem();
        setHealthGoal();
        onSaveGoals();
        return binding.getRoot();
    }

    private void onSaveGoals() {
        viewModel.getOnSaveGoals().observe(this, new android.arch.lifecycle.Observer<Void>() {
            @Override
            public void onChanged(@Nullable Void aVoid) {
                // call dashbaord fragment
                Intent intent = new Intent(getActivity(), HomeDashBoardActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(intent);
                getActivity().finish();
            }
        });
    }


    @Override
    public void onItemSeleced(ArrayList<Integer> healthIds) {
        viewModel.setSelectedGoalId(healthIds);
    }
}
