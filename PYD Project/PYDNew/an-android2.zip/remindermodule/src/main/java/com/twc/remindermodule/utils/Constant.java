package com.twc.remindermodule.utils;


public class Constant {


    public static final int ALARM_TO_START_SERVICE_FIRST_TIME = 121;
    public static final String NOTIFICATION_CHANNEL_ID_REMINDERS = "NOTIFICATION_CHANNEL_REMINDERS";
     public static final String NOTIFICATION_CHANNEL_NAME_REMINDERS = "Reminders";
    public static final int API_POST_DELAYED_TIME = 500;
    public static final String S_HEALTH = "Samsung Health";
    public static final String FITBIT = "Fitbit";
    public static final String GOOGLE_FIT = "Google Fit";
    public static final String E_FIT = "E Fit";
    public static final String MISFIT = "MisFit";
    public static final String GARMIN = "Garmin";
    public static final String DATE_FORMAT_MMMM_DD_YYYY = "MMMM dd, yyyy";
    public static final String DATE_FORMAT_24_HOUR = "MMMM dd, yyyy hh:mm:ss a";
    public static final String SERVER_DATE_FORMAT_WITH_MILLISECONDS = "yyyy-MM-dd'T'HH:mm:ss";
    public static final String DD_MM_YYYY_FORWARD_SLASH = "dd/MM/yyyy";

}
