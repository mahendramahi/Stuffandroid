package com.truworth.wellnesscorner.ui.mainapp.circle;

import android.databinding.ObservableBoolean;
import android.databinding.ObservableField;

import com.truworth.wellnesscorner.model.PopularCircle;

/**
 * Created by rajeshs on 4/16/2018.
 */

public class PopularCircleItemViewModel {
    public final PopularCircleListener popularCircleListener;
    public PopularCircle circle;
    public ObservableBoolean isRating = new ObservableBoolean();
    public ObservableField<String> ratingValue = new ObservableField<>();
    public ObservableBoolean isMembersVisible = new ObservableBoolean();
    public ObservableField<String> membersValue = new ObservableField<>();

    public PopularCircleItemViewModel(PopularCircle circle, PopularCircleListener popularCircleListener) {
        this.circle = circle;
        this.popularCircleListener = popularCircleListener;
    }

    public PopularCircle getCircle() {
        return circle;
    }

    public void onItemClick() {
        popularCircleListener.onItemClick(circle.getCircleAccess().isOpen(),circle.getCircleAccess().isContentVisibleToAll());
    }

    public void getRating() {
        if (circle.getCircleRating() > 0) {
            ratingValue.set(String.valueOf(circle.getCircleRating()));
            isRating.set(true);
        } else
            isRating.set(false);
    }

    public void getTotalMembers() {
        if (circle.getTotalMembers() > 1) {
            membersValue.set(String.valueOf(circle.getTotalMembers() + "  members"));
            isMembersVisible.set(true);
        } else if (circle.getTotalMembers() == 1) {
            membersValue.set(String.valueOf(circle.getTotalMembers() + "  member"));
            isMembersVisible.set(true);
        } else
            isMembersVisible.set(false);
    }

    public interface PopularCircleListener {

        void onItemClick(boolean isOpen,boolean isContentVisibleToAll);
    }
}
