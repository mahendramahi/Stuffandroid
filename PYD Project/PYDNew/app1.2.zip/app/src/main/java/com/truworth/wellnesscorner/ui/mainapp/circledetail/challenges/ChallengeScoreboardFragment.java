package com.truworth.wellnesscorner.ui.mainapp.circledetail.challenges;

import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;

import com.truworth.discoverlib.interfaces.OnLoadMoreListener;
import com.truworth.wellnesscorner.BR;
import com.truworth.wellnesscorner.R;
import com.truworth.wellnesscorner.base.BaseFragment;
import com.truworth.wellnesscorner.databinding.FragmentScoreboardAlltimeBinding;
import com.truworth.wellnesscorner.model.ChallengeLeaderboardBean;

import java.util.ArrayList;
import java.util.List;


public class ChallengeScoreboardFragment extends BaseFragment<FragmentScoreboardAlltimeBinding, ChallengeScoreboardViewModel> implements SwipeRefreshLayout.OnRefreshListener {
    public static final String TAG = "ChallengeScoreboardFragment";
    private static final String CHALLENGE_IDENTITY = "challengeIdentity";
    private static final String CHALLENGE_TYPE_ID = "challengeTypeId";
    ChallengeScoreboardViewModel viewModel;
    List<ChallengeLeaderboardBean> challengeList;
    ChallengeLeaderBoardAdapter challengeLeaderBoardAdapter;
    String challengeIdentity = "";
    int challengeTypeId;
    private int nestedScrollViewX = 0;
    private int nestedScrollViewY = 0;
    public boolean isReverse;
    private final int visibleThreshold = 5;
    boolean isLoadMore = false;
    //private int page = 1;
    private int lastVisibleItem, totalItemCount;
    private OnLoadMoreListener onLoadMoreListener;
    RecyclerView recyclerView;
    public String mTabType;
    boolean isRefresh;
    private Handler handler = new Handler();
    private Runnable runnableApiCall = new Runnable() {
        @Override
        public void run() {

            if (isRefresh) {
                viewModel.loadChallengeLeaderBoardData(challengeIdentity, viewModel.upPageIndex, mTabType);
            } else {
                viewModel.loadChallengeLeaderBoardData(challengeIdentity, viewModel.page, mTabType);
            }

        }
    };
    private OnLoadMoreListener onLoadMoreListenerUP;
    private LinearLayoutManager linearLayoutManager;
    private SwipeRefreshLayout swipeRefreshLayout;


    public ChallengeScoreboardFragment() {
        // Required empty public constructor
    }

    public static ChallengeScoreboardFragment newInstance(String challengeIdentity, int challengeTypeId, String tabType) {

        ChallengeScoreboardFragment fragment = new ChallengeScoreboardFragment();
        Bundle args = new Bundle();
        args.putString(CHALLENGE_IDENTITY, challengeIdentity);
        args.putInt(CHALLENGE_TYPE_ID, challengeTypeId);
        args.putString("TabType", tabType);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            challengeIdentity = getArguments().getString(CHALLENGE_IDENTITY);
            challengeTypeId = getArguments().getInt(CHALLENGE_TYPE_ID);
            mTabType = getArguments().getString("TabType");
        }
        // response = new Gson().fromJson(Utils.loadJSONFromAsset(getActivity()), CircleResponse.class);

        challengeList = new ArrayList<>();
        challengeLeaderBoardAdapter = new ChallengeLeaderBoardAdapter(getActivity(), challengeList, challengeIdentity, challengeTypeId, viewModel.myRank);
        viewModel.setChallengeTypeId(challengeTypeId);
    }

    @Override
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        //getViewDataBinding().nsView.scrollTo(nestedScrollViewX, nestedScrollViewY);

        swipeRefreshLayout = getViewDataBinding().swipeRefreshLayout;
        recyclerView = getViewDataBinding().rvChallengeLeaderBoard;
        linearLayoutManager = new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false);
        recyclerView.setLayoutManager(linearLayoutManager);
        recyclerView.setAdapter(challengeLeaderBoardAdapter);
        recyclerView.setNestedScrollingEnabled(false);
        setOnLoadMoreListener(linearLayoutManager);
        handler.postDelayed(runnableApiCall, 200);


        setDataObserver();
        attachRemoveLoadingObserver();
        attachRating1Observer();
        attachRating2Observer();
        attachRating3Observer();
        attachScrollPosObserver();
        setUpArrowObserver();
        //shouldShowTopBar();
        swipeRefreshLayout.setOnRefreshListener(this);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (challengeList != null) {
            challengeList.clear();
            challengeLeaderBoardAdapter.notifyDataSetChanged();
            challengeLeaderBoardAdapter = null;
            challengeList = null;
        }
    }

    private void setDataObserver() {
        viewModel.getChallengeLeaderBoard().observe(this, new Observer<List<ChallengeLeaderboardBean>>() {
            @Override
            public void onChanged(@Nullable List<ChallengeLeaderboardBean> challengeData) {
                swipeRefreshLayout.setRefreshing(false);
                if (challengeData != null) {

                    if (isReverse) {

                        for (int i = challengeData.size() - 1; i >= 0; i--) {
                            challengeList.add(0, challengeData.get(i));
                            // challengeLeaderBoardAdapter.notifyItemInserted(0);

                        }
                        challengeLeaderBoardAdapter.notifyDataSetChanged();
                        if (viewModel.page == 1) {
                            recyclerView.scrollToPosition(12);
                        } else {
                            recyclerView.scrollToPosition(15);
                        }

                        if (viewModel.upPageIndex == 1) {
                            // getViewDataBinding().llTop.setVisibility(View.VISIBLE);
                            viewModel.hideTopMembers.set(false);
                            recyclerView.scrollToPosition(0);
                        }

                    } else {
                        challengeList.addAll(challengeData);
                        challengeLeaderBoardAdapter.notifyDataSetChanged();
                    }

                }
            }
        });

        viewModel.getClearList().observe(this, new Observer<Void>() {
            @Override
            public void onChanged(@Nullable Void aVoid) {
                challengeList.clear();
            }
        });
    }


    @Override
    public int getBindingVariable() {
        return BR.viewModel;
    }

    @Override
    public int getLayoutId() {
        return R.layout.fragment_scoreboard_alltime;
    }

    @Override
    public ChallengeScoreboardViewModel getViewModel() {
        viewModel = ViewModelProviders.of(this).get(ChallengeScoreboardViewModel.class);
        return viewModel;
    }

    /**
     * Override for set binding variable
     *
     * @return variable id
     */

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
    }

    @Override
    public void onDetach() {
        super.onDetach();
    }

    private void attachRemoveLoadingObserver() {
        viewModel.getRemoveLoading().observe(this, new Observer<Void>() {
            @Override
            public void onChanged(@Nullable Void aVoid) {
                //Success, update UI
                if (challengeList.size() > 0 && challengeList.get(challengeList.size() - 1) == null) {
                    challengeList.remove(challengeList.size() - 1);
                    challengeLeaderBoardAdapter.notifyDataSetChanged();
                } else if (challengeList.size() > 0 && challengeList.get(0) == null) {
                    challengeList.remove(0);
                    challengeLeaderBoardAdapter.notifyDataSetChanged();
                }
            }
        });
    }

    /*private void shouldShowTopBar() {
        viewModel.getTopBarVisibilty().observe(this, new Observer<Void>() {
            @Override
            public void onChanged(@Nullable Void aVoid) {
                //Success, update UI
                getViewDataBinding().llTop.setVisibility(View.GONE);
            }
        });
    }*/


    private void setOnLoadMoreListener(final LinearLayoutManager linearLayoutManager) {
        onLoadMoreListener = new OnLoadMoreListener() {
            @Override
            public void onLoadMore() {
                if (!viewModel.isLastResult) {
                    if (challengeList != null && challengeList.size() > 5) {
                        challengeList.add(null);
                        challengeLeaderBoardAdapter.notifyItemInserted(challengeList.size() - 1);
                        recyclerView.getLayoutManager().scrollToPosition(challengeList.size());


                        viewModel.page = viewModel.page + 1;
                        isRefresh=false;
                        handler.postDelayed(runnableApiCall, 100);
                    }
                }
            }
        };

    /*  onLoadMoreListenerUP = new OnLoadMoreListener() {
            @Override
            public void onLoadMore() {

                if (!viewModel.isLastResult) {
                    if (challengeList != null && challengeList.size() > 5) {
                        challengeList.add(0, null);
                        challengeLeaderBoardAdapter.notifyItemInserted(0);
                        // recyclerView.getLayoutManager().scrollToPosition(0);
                        viewModel.page = viewModel.page - 1;
                        handler.postDelayed(runnableApiCall, 100);
                        Log.d("loadmore", "loadmore");
                    }
                }
            }
        };*/
        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                if (dy > 0) {
                    getViewDataBinding().imgUpArrow.setVisibility(View.VISIBLE);
                    totalItemCount = linearLayoutManager.getItemCount();
                    lastVisibleItem = linearLayoutManager.findLastVisibleItemPosition();
                    if (!viewModel.loading && totalItemCount <= (lastVisibleItem + visibleThreshold)) {
                        viewModel.loading = true;
                        isReverse = false;
                        onLoadMoreListener.onLoadMore();

                    }
                } else {
                    getViewDataBinding().imgUpArrow.setVisibility(View.GONE);
                }
            }
        });

      /*  getViewDataBinding().nsView.setOnScrollChangeListener(new NestedScrollView.OnScrollChangeListener() {
            @Override
            public void onScrollChange(NestedScrollView v, int scrollX, int scrollY, int oldScrollX, int oldScrollY) {
                nestedScrollViewX = scrollX;
                nestedScrollViewY = scrollY;
                View view = getViewDataBinding().nsView.getChildAt(getViewDataBinding().nsView.getChildCount() - 1);
                int diff = (view.getBottom() - (getViewDataBinding().nsView.getHeight() + getViewDataBinding().nsView.getScrollY()));

                if (view != null) {
                    if ((scrollY >= (v.getChildAt(v.getChildCount() - 1).getMeasuredHeight() - v.getMeasuredHeight())) && scrollY > oldScrollY && !viewModel.loading) {
                        isReverse=false;
                        onLoadMoreListener.onLoadMore();
                        viewModel.loading = true;
                        Log.d("callscroll", "callscrolldown");
                    }*//* else if (scrollY < oldScrollY && !viewModel.loading) {
                        int position = linearLayoutManager.findFirstVisibleItemPosition();
                        View view1 = linearLayoutManager.findViewByPosition(position);
                        if (view1 instanceof ConstraintLayout) {
                            TextView tv = view1.findViewById(R.id.tvMemberRank);
                             if(tv!=null){
                                 String tvText = tv.getText().toString();
                                 char[] characters = tvText.toCharArray();
                                 char lastChar = characters[characters.length - 1];
                                 String s=Character.toString(lastChar);

                                 if(s.equalsIgnoreCase("1")){
                                     isReverse = true;
                                     onLoadMoreListenerUP.onLoadMore();
                                     viewModel.loading = true;
                                     Log.d("callscroll", "callscrollUP");
                                     Log.d("position", position + "");
                                 }
                             }
                        }

                    }*//*
                }
                if (diff >= 0) {
                    if (scrollY == 0) {
                        getViewDataBinding().imgUpArrow.setVisibility(View.GONE);
                    } else {
                        getViewDataBinding().imgUpArrow.setVisibility(View.VISIBLE);
                    }


                } else {
                    getViewDataBinding().imgUpArrow.setVisibility(View.GONE);
                }
            }
        });*/
    }

    private void attachRating1Observer() {
        viewModel.getResultRating1().observe(this, new Observer<Integer>() {
            @Override
            public void onChanged(@Nullable Integer result1) {
                //Success, update UI
                setImage(getViewDataBinding().ivRating1, result1);
            }
        });
    }

    private void attachRating2Observer() {
        viewModel.getResultRating2().observe(this, new Observer<Integer>() {
            @Override
            public void onChanged(@Nullable Integer result2) {
                //Success, update UI
                setImage(getViewDataBinding().ivRating2, result2);
            }
        });
    }

    private void attachRating3Observer() {
        viewModel.getResultRating3().observe(this, new Observer<Integer>() {
            @Override
            public void onChanged(@Nullable Integer result3) {
                //Success, update UI
                setImage(getViewDataBinding().ivRating3, result3);
            }
        });
    }

    private void setImage(ImageView ivRating, Integer result) {
        if (result < 0) {
            ivRating.setImageResource(R.drawable.ic_up_icon);
        } else if (result == 0) {
            ivRating.setImageResource(R.drawable.ic_no_change_icon);
        } else {
            ivRating.setImageResource(R.drawable.ic_icon_red_traingle);
        }
    }

    private void attachScrollPosObserver() {
        viewModel.getScrollToMyPos().observe(this, new Observer<Void>() {
            @Override
            public void onChanged(@Nullable Void avoid) {

             /*   float y = getViewDataBinding().rvChallengeLeaderBoard.getY() + getViewDataBinding().rvChallengeLeaderBoard.getChildAt(0).getY();
                getViewDataBinding().nsView.fling(0);
                getViewDataBinding().nsView.scrollTo(0, (int) y);*/

                //Success, update UI
                int selectedRank = viewModel.myRank;
                challengeLeaderBoardAdapter.notifyDataSetChanged();
                challengeLeaderBoardAdapter.updateMyRank(viewModel.myRank);
                if (challengeList != null) {
                    int myPosition = 0;
                    for (int i = 0; i < challengeList.size(); i++) {
                        if (challengeList.get(i) != null && challengeList.get(i).getRank() == selectedRank) {
                            myPosition = i;
                            break;
                        } else {
                            myPosition = -1; // do not scroll if my position is unavailable
                        }
                    }
                    if (myPosition > -1) {
                        recyclerView.scrollToPosition(myPosition);
                        // float y = getViewDataBinding().rvChallengeLeaderBoard.getY() + getViewDataBinding().rvChallengeLeaderBoard.getChildAt(myPosition).getY();
                        //  getViewDataBinding().nsView.fling(0);
                        //  getViewDataBinding().nsView.smoothScrollTo(0, (int) y);

                    }

                }
            }
        });
    }

    private void setUpArrowObserver() {
        viewModel.getUpArrow().observe(this, new Observer<Void>() {
            @Override
            public void onChanged(@Nullable Void avoid) {
                //  getViewDataBinding().nsView.fling(0);
                //  getViewDataBinding().nsView.smoothScrollTo(0, 0);
                recyclerView.smoothScrollToPosition(0);//imgUpArrow.setVisibility(View.GONE);
                //getViewDataBinding().llTop.setVisibility(View.VISIBLE);
                viewModel.hideTopMembers.set(false);
            }
        });
    }

    @Override
    public void onRefresh() {
        if (viewModel.upPageIndex != (-1)) {
            isRefresh=true;
            swipeRefreshLayout.setRefreshing(true);
            isReverse = true;
            challengeList.add(0, null);
            challengeLeaderBoardAdapter.notifyItemInserted(0);
            // recyclerView.getLayoutManager().scrollToPosition(0);
            viewModel.upPageIndex = viewModel.upPageIndex - 1;

            handler.postDelayed(runnableApiCall, 100);
            //recyclerView.smoothScrollToPosition(0);


        } else {
            viewModel.hideTopMembers.set(false);
            swipeRefreshLayout.setRefreshing(false);
            //getViewDataBinding().llTop.setVisibility(View.VISIBLE);
        }
    }
}

