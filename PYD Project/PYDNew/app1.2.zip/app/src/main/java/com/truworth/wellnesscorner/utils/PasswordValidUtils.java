package com.truworth.wellnesscorner.utils;

/**
 * Created by rajeshs on 4/3/2018.
 */

public class PasswordValidUtils {
    public static boolean isContainsLetters(String s) {
        return s.matches(".*[a-zA-Z]+.*");
        //(?=.*?[a-z])
        // simpler from for
//      return s.matches("[a-Z][a-Z][a-Z]");
    }

    public static boolean isContainsDigit(String s) {
        return s.matches(".*\\d+.*");
    }

    public static boolean isContainsSpecialCharacter(String s) {
        return s.matches(".*[-@!#$%^&*_+=?<>,.]+.*");

    }

    public static boolean isLengthMatches(String s) {
        if (s.length() >= 6) {
            return true;
        }
        return false;
    }
}
