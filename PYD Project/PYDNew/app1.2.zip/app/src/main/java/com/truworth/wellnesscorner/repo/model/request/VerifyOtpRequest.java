package com.truworth.wellnesscorner.repo.model.request;

/**
 * Created by rajeshs on 4/2/2018.
 */

public class VerifyOtpRequest {
    String OtpSessionId;
    String OtpCode;

    public String getOtpCode() {
        return OtpCode;
    }

    public void setOtpCode(String otpCode) {
        OtpCode = otpCode;
    }

    public String getOtpSessionId() {

        return OtpSessionId;
    }

    public void setOtpSessionId(String otpSessionId) {
        OtpSessionId = otpSessionId;
    }
}
