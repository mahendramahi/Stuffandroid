package com.truworth.discoverlib.model;

/**
 If this code works it was written by Somesh Kumar on 09 August, 2016. If not, I don't know who wrote it.
 */
public class ArticleDetailBody {
    private int ArticleID;
    private int MemberID;

    public int getArticleID() {
        return ArticleID;
    }

    public void setArticleID(int ArticleID) {
        this.ArticleID = ArticleID;
    }

    public int getMemberID() {
        return MemberID;
    }

    public void setMemberID(int MemberID) {
        this.MemberID = MemberID;
    }
}
