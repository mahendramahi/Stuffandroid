package com.twc.store.adapter;

import android.app.Activity;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.twc.store.GlideConfig;

import com.twc.store.R;
import com.twc.store.R2;
import com.twc.store.fragments.StoreProductDetailFragment;
import com.twc.store.model.beans.ProductItem;
import com.twc.store.utils.Constant;
import com.twc.store.utils.Utils;
import com.twc.store.views.CustomTextView;

import java.text.MessageFormat;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

import static com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions.withCrossFade;


/**
 * If this code works it was written by Somesh Kumar on 04 May, 2017. If not, I don't know who wrote it.
 */
public class StoreWellnessPlanAdapter extends RecyclerView.Adapter<StoreWellnessPlanAdapter.StoreWellnessPlan> {

    private final List<ProductItem> wellnessProductList;
    private final Activity context;

    public StoreWellnessPlanAdapter(Activity activity, List<ProductItem> wellnessProductList) {
        this.context = activity;
        this.wellnessProductList = wellnessProductList;
    }

    @Override
    public StoreWellnessPlan onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_store_wellness_plan, parent, false);
        return new StoreWellnessPlan(itemView);
    }

    @Override
    public void onBindViewHolder(StoreWellnessPlan holder, int position) {
        holder.tvWellnessPlanTitle.setText(wellnessProductList.get(position).getName());
        holder.tvWellnessPlanDescription.setText(Utils.fromHtml(wellnessProductList.get(position).getDescription()));
        holder.tvRating.setText(String.valueOf(wellnessProductList.get(position).getProductRating()));
        if (wellnessProductList.get(position).getSpecialPrice() == 0.0) {
            holder.tvWellnessPlanBestPrice.setText(MessageFormat.format("{0}{1}", context.getString(R.string.rupee_symbol), Utils.getFormattedAmountManageZero(wellnessProductList.get(position).getPrice())));
            holder.lblBestPrice.setVisibility(View.INVISIBLE);
        }
        else {
            holder.tvWellnessPlanBestPrice.setText(MessageFormat.format("{0}{1}", context.getString(R.string.rupee_symbol), Utils.getFormattedAmountManageZero(wellnessProductList.get(position).getSpecialPrice())));
        }
        GlideConfig.getInstance().getImageLoader().load(wellnessProductList.get(position).getImage()).transition(withCrossFade()).into(holder.ivWellnessPlanImage);
    }

    @Override
    public int getItemCount() {
        if (wellnessProductList == null) {
            return 0;
        }
        else {
            return wellnessProductList.size() >= 0 && wellnessProductList.size() < 2 ? wellnessProductList.size() : 2;
        }
    }


    class StoreWellnessPlan extends RecyclerView.ViewHolder {
        @BindView(R2.id.ivWellnessPlanImage)
        ImageView ivWellnessPlanImage;
        @BindView(R2.id.tvWellnessPlanTitle)
        CustomTextView tvWellnessPlanTitle;
        @BindView(R2.id.tvWellnessPlanDescription)
        CustomTextView tvWellnessPlanDescription;
        @BindView(R2.id.tvWellnessPlanBestPrice)
        CustomTextView tvWellnessPlanBestPrice;
        @BindView(R2.id.tvRating)
        CustomTextView tvRating;
        @BindView(R2.id.lblBestPrice)
        CustomTextView lblBestPrice;

        StoreWellnessPlan(View view) {
            super(view);
            ButterKnife.bind(this, view);

            view.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int productId = wellnessProductList.get(getAdapterPosition()).getProductID();
                    String sku = wellnessProductList.get(getAdapterPosition()).getSku();
                  Utils.replaceFragment(context.getFragmentManager(), StoreProductDetailFragment.newInstance(productId, sku, Constant.WELLNESS_PLAN), StoreProductDetailFragment.class.getSimpleName(), true, R.id.fragmentContainer);
                }
            });
        }
    }
}
