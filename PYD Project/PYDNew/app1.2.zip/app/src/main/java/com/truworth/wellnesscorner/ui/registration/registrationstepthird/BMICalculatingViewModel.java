package com.truworth.wellnesscorner.ui.registration.registrationstepthird;

import android.databinding.ObservableBoolean;

import com.truworth.wellnesscorner.TheWellnessCornerApp;
import com.truworth.wellnesscorner.base.BaseViewModel;
import com.truworth.wellnesscorner.model.BMIData;
import com.truworth.wellnesscorner.repo.RegistrationRepository;
import com.truworth.wellnesscorner.repo.model.request.BMIRequest;
import com.truworth.wellnesscorner.repo.model.response.BMIResponse;
import com.truworth.wellnesscorner.utils.SingleLiveEvent;

import javax.inject.Inject;

import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;

/**
 * Created by PalakC on 4/11/2018.
 */

public class BMICalculatingViewModel extends BaseViewModel {

    public BMIData bmiData;
    public SingleLiveEvent<Void> getOnClickContinue() {
        return onClickContinue;
    }
    public ObservableBoolean isEnableContinue = new ObservableBoolean();
    public ObservableBoolean isProgressVisible = new ObservableBoolean();

    SingleLiveEvent<Void> onClickContinue = new SingleLiveEvent<>();

    public BMIData getBmiData() {
        return bmiData;
    }

    @Inject
    RegistrationRepository registrationRepository;

    public BMICalculatingViewModel() {
        TheWellnessCornerApp.getApp().component().inject(this);
        isProgressVisible.set(true);
    }


    public void getBMIAndIBW(int height, int weight) {
        //setIsLoading(true);
        isProgressVisible.set(true);
        BMIRequest bmiRequest = new BMIRequest();
        bmiRequest.setWeight(String.valueOf(weight));
        bmiRequest.setHeight(String.valueOf(height));
        registrationRepository.getBMIAndIBW(bmiRequest).subscribe(new Observer<BMIResponse>() {
            @Override
            public void onSubscribe(Disposable d) {

            }

            @Override
            public void onNext(BMIResponse bmiResponse) {
                if (!bmiResponse.isHasError()) {
                    isProgressVisible.set(false);
                    bmiData= bmiResponse.getData();
                    if(bmiData!=null) {
                        isEnableContinue.set(true);
                    }
                    else
                        isEnableContinue.set(false);
                }
            }

            @Override
            public void onError(Throwable e) {
                isProgressVisible.set(false);
               // setIsLoading(false);
            }

            @Override
            public void onComplete() {
                isProgressVisible.set(false);
                //setIsLoading(false);
            }
        });
    }
    public void onClickContinueCall() {
        onClickContinue.call();
    }
}
