package com.truworth.discoverlib.model;

/**
 * If this code works it was written by Somesh Kumar on 05 April, 2017. If not, I don't know who wrote it.
 */
public class SharedConfirmationBody {

    private int MemberID;
    private int ItemID;
    private String ItemType;
    private String ShareThrough;

    public int getMemberID() {
        return MemberID;
    }

    public void setMemberID(int MemberID) {
        this.MemberID = MemberID;
    }

    public int getItemID() {
        return ItemID;
    }

    public void setItemID(int ItemID) {
        this.ItemID = ItemID;
    }

    public String getItemType() {
        return ItemType;
    }

    public void setItemType(String ItemType) {
        this.ItemType = ItemType;
    }

    public String getShareThrough() {
        return ShareThrough;
    }

    public void setShareThrough(String ShareThrough) {
        this.ShareThrough = ShareThrough;
    }
}
