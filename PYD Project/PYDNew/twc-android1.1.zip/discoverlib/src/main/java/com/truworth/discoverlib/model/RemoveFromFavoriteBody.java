package com.truworth.discoverlib.model;

/**
 If this code works it was written by Somesh Kumar on 15 August, 2016. If not, I don't know who wrote it.
 */
public class RemoveFromFavoriteBody {
    private int MemberID;
    private String Type;
    private int ID;

    public int getMemberID() {
        return MemberID;
    }

    public void setMemberID(int MemberID) {
        this.MemberID = MemberID;
    }

    public String getType() {
        return Type;
    }

    public void setType(String Type) {
        this.Type = Type;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }
}
