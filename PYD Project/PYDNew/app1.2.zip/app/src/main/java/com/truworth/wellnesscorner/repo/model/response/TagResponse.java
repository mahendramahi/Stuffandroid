package com.truworth.wellnesscorner.repo.model.response;



import com.truworth.wellnesscorner.model.TagPerson;

import java.util.ArrayList;

/**
 * Created by ameen on 1/1/18.
 * Happy Coding
 */

public class TagResponse {


    boolean hasError;
    //String msg;


    public boolean isHasError() {
        return hasError;
    }

    public void setHasError(boolean hasError) {
        this.hasError = hasError;
    }

    public void setData(ArrayList<TagPerson> data) {
        this.data = data;
    }

    ArrayList<TagPerson> data;

    public ArrayList<TagPerson> getData() {
        return data;
    }
}
