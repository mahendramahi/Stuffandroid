package com.twc.hramodule;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

import com.twc.greendaolib.GreenDaoApp;
import com.twc.greendaolib.HraDBItem;
import com.twc.greendaolib.HraDBItemDao;
import com.twc.hramodule.fragments.HraRiskGradeFragment;
import com.twc.hramodule.interfaces.OnHraDbAction;
import com.twc.hramodule.model.requestbody.BaseMemberIdBody;
import com.twc.hramodule.model.response.HraSaveResponse;
import com.twc.hramodule.rest.RestClient;
import com.twc.hramodule.utils.DialogFactory;
import com.twc.hramodule.utils.HRARedirectionUtils;
import com.twc.hramodule.utils.HraConfig;
import com.twc.hramodule.utils.Utils;


import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class HraActivity extends AppCompatActivity implements OnHraDbAction {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hra);

        checkExistHraWithNavigate();
    }


    public void checkExistHraWithNavigate() {
        HraDBItemDao hraDBDao = GreenDaoApp.getInstance(getApplicationContext()).getDaoSession(this).getHraDBItemDao();
        List<HraDBItem> answerFromDb = hraDBDao.queryBuilder().orderDesc(HraDBItemDao.Properties.ScreeNo).limit(1).list();
        if (answerFromDb != null && answerFromDb.size() == 0) {
            getMemberHraScore();
        } else {
            Bundle bundle = new Bundle();
            HRARedirectionUtils.getInstance().navigateToHRAQuestionScreen(bundle, getFragmentManager(),hraDBDao);
        }
    }

    private void getMemberHraScore() {

        BaseMemberIdBody hraGetScoreBody = new BaseMemberIdBody();
        hraGetScoreBody.setMemberID(HraConfig.hraUser.getUserID());
        RestClient restClient = new RestClient(this, HraConfig.BASE_URL, HraConfig.DEBUG);
        restClient.getHraService().getHRAScore(hraGetScoreBody).enqueue(new Callback<HraSaveResponse>() {
            @Override
            public void onResponse(Call<HraSaveResponse> call, Response<HraSaveResponse> response) {

                if (response != null && response.body() != null) {
                    if (response.body().getStatus() == 0) {
                        if (response.body().isIsHraAvailable()) {
                            Bundle bundle = new Bundle();
                            bundle.putString("score", response.body().getData().getScore() + "");
                            bundle.putString("grade", response.body().getData().getGrade());
                            bundle.putString("msg", response.body().getData().getMessage());
                            Utils.replaceFragment(getFragmentManager(), HraRiskGradeFragment.newInstance(bundle), HraRiskGradeFragment.class.getSimpleName(), true, R.id.fragmentContainerHra);
                        } else {
                            Bundle bundle = new Bundle();
                            HraDBItemDao hraDBDao = GreenDaoApp.getInstance(getApplicationContext()).getDaoSession(HraActivity.this).getHraDBItemDao();
                            HRARedirectionUtils.getInstance().navigateToHRAQuestionScreen(bundle, getFragmentManager(),hraDBDao);
                        }
                    } else if (response.body().getStatus() == -1) {
                        DialogFactory.getInstance().showAlertDialog(HraActivity.this, getString(R.string.app_name), 0, getString(R.string.msg_api_response_failure), getString(R.string.str_ok), false);
                    }
                } else {
                    DialogFactory.getInstance().showAlertDialog(HraActivity.this, getString(R.string.app_name), 0, getString(R.string.msg_api_response_failure), getString(R.string.str_ok), false);
                }
            }

            @Override
            public void onFailure(Call<HraSaveResponse> call, Throwable t) {

                DialogFactory.getInstance().showAlertDialog(HraActivity.this, getString(R.string.app_name), 0, getString(R.string.msg_api_failure), getString(R.string.str_ok), false);
            }
        });
    }

    @Override
    public void onHraQuestionSave(long QuestionId, String Answer, String ScreenNo, int isSure) {
        HraDBItem hraDBItem = new HraDBItem(QuestionId, Answer, Float.parseFloat(ScreenNo), isSure);
        HraDBItemDao hraDBDao = GreenDaoApp.getInstance(getApplicationContext()).getDaoSession(this).getHraDBItemDao();
        hraDBDao.insertOrReplace(hraDBItem);
        List<HraDBItem> answerFromDBList = hraDBDao.loadAll();
        for (HraDBItem dbItem : answerFromDBList) {
            if(HraConfig.DEBUG)
                Log.d("GreenDao", "Answer :" + dbItem.getAnswer() + " Q. ID :" + String.valueOf(dbItem.getQuestionId()) + " Screen No. :" + dbItem.getScreeNo());
        }
    }
}
