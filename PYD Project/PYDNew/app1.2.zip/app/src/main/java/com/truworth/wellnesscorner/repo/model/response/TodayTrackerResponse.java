package com.truworth.wellnesscorner.repo.model.response;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.truworth.wellnesscorner.model.HabitStatus;
import com.truworth.wellnesscorner.model.MyTask;
import com.truworth.wellnesscorner.model.TodayTrackerValue;

import java.util.List;

public class TodayTrackerResponse {


    /**
     * data : {"trackers":[{"trackerName":"FOOD TRACKER","trackerData":{"value":0}},{"trackerName":"EXCERCISE TRACKER","trackerData":{"value":0}},{"trackerName":"GLASS TRACKER","trackerData":{"value":0}},{"trackerName":"WEIGHT TRACKER","trackerData":{"value":0}},{"trackerName":"STEPS TRACKER","trackerData":{"value":0}}],"habitStatus":{"completedHabits":0,"totalHabits":0}}
     * hasError : false
     * error : null
     */
    @SerializedName("data")
    @Expose
    private DataBean data;
    @SerializedName("hasError")
    @Expose
    private boolean hasError;
    @SerializedName("error")
    @Expose
    private Error error;

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public boolean isHasError() {
        return hasError;
    }

    public void setHasError(boolean hasError) {
        this.hasError = hasError;
    }

    public Object getError() {
        return error;
    }

    public void setError(Error error) {
        this.error = error;
    }

    public static class DataBean {
        /**
         * trackers : [{"trackerName":"FOOD TRACKER","trackerData":{"value":0}},{"trackerName":"EXCERCISE TRACKER","trackerData":{"value":0}},{"trackerName":"GLASS TRACKER","trackerData":{"value":0}},{"trackerName":"WEIGHT TRACKER","trackerData":{"value":0}},{"trackerName":"STEPS TRACKER","trackerData":{"value":0}}]
         * habitStatus : {"completedHabits":0,"totalHabits":0}
         */

        private HabitStatus habitStatus;
        private MyTask myTask;
        private List<TodayTrackerValue> trackers;

        public HabitStatus getHabitStatus() {
            return habitStatus;
        }

        public void setHabitStatus(HabitStatus habitStatus) {
            this.habitStatus = habitStatus;
        }

        public List<TodayTrackerValue> getTrackers() {
            return trackers;
        }

        public void setTrackers(List<TodayTrackerValue> trackers) {
            this.trackers = trackers;
        }

        public MyTask getMyTask() {
            return myTask;
        }

        public void setMyTask(MyTask myTask) {
            this.myTask = myTask;
        }
    }
}
