package com.twc.dailylog.fragments;

import android.app.Activity;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.Editable;
import android.text.InputFilter;
import android.text.Spanned;
import android.text.TextWatcher;
import android.text.method.DigitsKeyListener;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;


import com.twc.dailylog.MealActivity;
import com.twc.dailylog.R;
import com.twc.dailylog.R2;
import com.twc.dailylog.interfaces.OnTrackerReadingSave;
import com.twc.dailylog.model.requestbody.SaveCurrentWeightBody;
import com.twc.dailylog.model.requestbody.SaveTargetWeightBody;
import com.twc.dailylog.model.response.SaveCurrentWeightResponse;
import com.twc.dailylog.model.response.SaveTargetWeightResponse;
import com.twc.dailylog.rest.RestClient;
import com.twc.dailylog.utils.DailyLogConfig;
import com.twc.dailylog.utils.DateFactory;
import com.twc.dailylog.utils.DialogFactory;
import com.twc.dailylog.utils.NetworkFactory;
import com.twc.dailylog.utils.Utils;

import butterknife.BindView;
import butterknife.OnClick;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by Manish Jain on 7/5/2016.
 */
public class AddWeightFragment extends BaseFragment {

    @BindView(R2.id.etQuantity)
    EditText etQuantity;

    @BindView(R2.id.etQuantityKgs)
    EditText etQuantityKgs;

    @BindView(R2.id.tvtWeight)
    TextView tvtWeight;

    @BindView(R2.id.ivAddWeight)
    ImageView ivAddWeight;

    @BindView(R2.id.rootView)
    LinearLayout rootView;

    private String addWeight;
    private OnTrackerReadingSave onTrackerReadingSave;


    public static AddWeightFragment newInstance(Bundle bundle) {
        AddWeightFragment fragment = new AddWeightFragment();
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //getActivity().getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);

        if (getArguments() != null) {
            addWeight = getArguments().getString("AddWeight");

        }
    }

    @Override
    public void onResume() {
        super.onResume();
        ((MealActivity) getActivity()).showHomeAsUpEnableToolbar();
        if (addWeight.equalsIgnoreCase("Currentweight")) // for the current weight
        {
            ((MealActivity) getActivity()).setToolBarTitle(getString(R.string.toolbar_title_addweight));
        } else //for the target weight
        {
            ((MealActivity) getActivity()).setToolBarTitle(getString(R.string.toolbar_title_targetweight));
        }
    }

    @Override
    public int getFragmentLayout() {
        return R.layout.fragment_addweight;
    }

    @Override
    public void onFragmentReady() {

        if (addWeight.equalsIgnoreCase("Currentweight")) // for the current weight
        {
            ivAddWeight.setImageResource(R.drawable.ic_currentweight);
            tvtWeight.setText(getString(R.string.add_current_weight));
        } else //for the target weight
        {
            ivAddWeight.setImageResource(R.drawable.ic_targetweight);
            tvtWeight.setText(getString(R.string.add_target_weight));

        }


        etQuantity.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

                if (etQuantity.getText().toString().trim().length() >= 3) {
                    etQuantity.setFilters(new InputFilter[]{new DigitsKeyListener(
                            Boolean.FALSE, Boolean.TRUE) {
                        int beforeDecimal = 3, afterDecimal = 2;

                        @Override
                        public CharSequence filter(CharSequence source, int start, int end,
                                                   Spanned dest, int dstart, int dend) {
                            String etText = etQuantity.getText().toString();
                            if (etText.isEmpty()) {
                                return null;
                            }
                            String temp = etQuantity.getText() + source.toString();
                            if (temp.equals(".")) {
                                return "0.";
                            } else if (!temp.contains(".")) {
                                // no decimal point placed yet
                                if (temp.length() > beforeDecimal) {
                                    return "";
                                }
                            } else {
                                int dotPosition;
                                int cursorPositon = etQuantity.getSelectionStart();
                                if (!etText.contains(".")) {

                                    dotPosition = temp.indexOf(".");

                                } else {
                                    dotPosition = etText.indexOf(".");

                                }
                                if (cursorPositon <= dotPosition) {

                                    String beforeDot = etText.substring(0, dotPosition);
                                    if (beforeDot.length() < beforeDecimal) {
                                        return source;
                                    } else {
                                        if (source.toString().equalsIgnoreCase(".")) {
                                            return source;
                                        } else {
                                            return "";
                                        }

                                    }
                                } else {

                                    temp = temp.substring(temp.indexOf(".") + 1);
                                    if (temp.length() > afterDecimal) {
                                        return "";
                                    }
                                }
                            }

                            return super.filter(source, start, end, dest, dstart, dend);
                        }
                    }});

                }

            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
    }

    private boolean validation() {
        String quantity = etQuantity.getText().toString();
        if (quantity.trim().length() == 0) {
            etQuantity.setError("Weight can't be blank");
            return false;
        } else if (etQuantity.getText().toString().trim().equalsIgnoreCase(".")) {
            etQuantity.setError(getString(R.string.weight_error));
            return false;
        } else if (Double.parseDouble(etQuantity.getText().toString()) <= 0.0) {
            etQuantity.setError(getString(R.string.weight_error));
            return false;
        }

        return true;
    }

    @OnClick(R2.id.btnSaveWeight)
    public void saveWeightAbc() {
        if (validation()) {
            if (addWeight.equalsIgnoreCase("Currentweight"))
                saveCurrentWeight(etQuantity.getText().toString());
            else
                saveTargetWeight(etQuantity.getText().toString());
        }
    }


    private void saveTargetWeight(String quentity) {
        if (NetworkFactory.getInstance().isNetworkAvailable(getActivity())) {

            SaveTargetWeightBody saveTargetWeightBody = new SaveTargetWeightBody();
            //saveTargetWeightBody.setMemberID(WellnessCornerApp.getPreferenceManager().getUserId());
            saveTargetWeightBody.setReading(quentity);
            RestClient restClient = new RestClient(getActivity(), DailyLogConfig.BASE_URL, DailyLogConfig.DEBUG);
            restClient.getWeightService().getSaveTargetWeight(saveTargetWeightBody).enqueue(new Callback<SaveTargetWeightResponse>() {
                @Override
                public void onResponse(Call<SaveTargetWeightResponse> call, Response<SaveTargetWeightResponse> response) {
                    if (isAdded() && getActivity() != null) {

                        if (response != null && response.body() != null) {
                            if (response.body().getStatus() == 0) {
                                getActivity().setResult(Activity.RESULT_OK);
                                getActivity().finish();
                            } else if (response.body().getStatus() == -1) {
                                DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_response_failure), getString(R.string.str_ok), false);

                            }
                        } else {
                            DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_response_null), getString(R.string.str_ok), false);

                        }
                    }

                }

                @Override
                public void onFailure(Call<SaveTargetWeightResponse> call, Throwable t) {
                    if (isAdded() && getActivity() != null) {

                        DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_failure), getString(R.string.str_ok), false);

                    }
                }
            });

        } else {
            Utils.showSnackBarMessage(rootView, getString(R.string.internet_not_available));
        }
    }

    private void saveCurrentWeight(String quentity) {
        if (NetworkFactory.getInstance().isNetworkAvailable(getActivity())) {

            SaveCurrentWeightBody saveCurrentWeightBody = new SaveCurrentWeightBody();
            //saveCurrentWeightBody.setMemberID(WellnessCornerApp.getPreferenceManager().getUserId());
            saveCurrentWeightBody.setReading(quentity);
            saveCurrentWeightBody.setDate(DateFactory.getInstance().getTodayDate("MM/dd/yyyy HH:mm:ss"));
            saveCurrentWeightBody.setWeightUnit("Kg");
            RestClient restClient = new RestClient(getActivity(), DailyLogConfig.BASE_URL, DailyLogConfig.DEBUG);
            restClient.getWeightService().getSaveCurrentWeight(saveCurrentWeightBody).enqueue(new Callback<SaveCurrentWeightResponse>() {
                @Override
                public void onResponse(Call<SaveCurrentWeightResponse> call, Response<SaveCurrentWeightResponse> response) {
                    if (isAdded() && getActivity() != null) {

                        if (response != null && response.body() != null) {
                            if (response.body().getStatus() == 0) {
                                Utils.hideSoftKeyboard(getActivity());
                                if (onTrackerReadingSave != null) {
                                    onTrackerReadingSave.onTrackerReadingSuccess();
                                    getFragmentManager().popBackStackImmediate();
                                } else {
                                    getActivity().setResult(Activity.RESULT_OK);
                                    getActivity().finish();
                                }
                            } else if (response.body().getStatus() == -1) {
                                DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_response_failure), getString(R.string.str_ok), false);

                            }
                        } else {
                            DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_response_null), getString(R.string.str_ok), false);

                        }
                    }
                }

                @Override
                public void onFailure(Call<SaveCurrentWeightResponse> call, Throwable t) {
                    if (isAdded() && getActivity() != null) {

                        DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_failure), getString(R.string.str_ok), false);


                    }
                }
            });
        } else {
            Utils.showSnackBarMessage(rootView, getString(R.string.internet_not_available));
        }
    }

    public void setTrackerReadingCallback(OnTrackerReadingSave onTrackerReadingSave) {
        this.onTrackerReadingSave = onTrackerReadingSave;
    }
}

