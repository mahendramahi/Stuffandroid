package com.twc.store.model.requestbody;



import com.twc.store.model.beans.CouponBean;

import java.util.List;

/**
 * Created by richas on 9/18/2017.
 */

public class StoreSaveOrderRequestBody {


    private int MemberBilling_ID;
    private String FullName;
    private String Mobile;
    private String BillingAddress;
    private String State;
    private String City;
    private String Country;
    private String Pincode;
    private String Address2;
    private String CartIds;
    private double WellcashDiscount;
    private double TotalCartAmount;
    private int MemberId;
    private List<CouponBean> CouponList;

    public int getMemberBilling_ID() {
        return MemberBilling_ID;
    }

    public void setMemberBilling_ID(int MemberBilling_ID) {
        this.MemberBilling_ID = MemberBilling_ID;
    }

    public String getFullName() {
        return FullName;
    }

    public void setFullName(String FullName) {
        this.FullName = FullName;
    }

    public String getMobile() {
        return Mobile;
    }

    public void setMobile(String Mobile) {
        this.Mobile = Mobile;
    }

    public String getBillingAddress() {
        return BillingAddress;
    }

    public void setBillingAddress(String BillingAddress) {
        this.BillingAddress = BillingAddress;
    }

    public String getState() {
        return State;
    }

    public void setState(String State) {
        this.State = State;
    }

    public String getCity() {
        return City;
    }

    public void setCity(String City) {
        this.City = City;
    }

    public String getCountry() {
        return Country;
    }

    public void setCountry(String Country) {
        this.Country = Country;
    }

    public String getPincode() {
        return Pincode;
    }

    public void setPincode(String Pincode) {
        this.Pincode = Pincode;
    }

    public String getAddress2() {
        return Address2;
    }

    public void setAddress2(String Address2) {
        this.Address2 = Address2;
    }

    public String getCartIds() {
        return CartIds;
    }

    public void setCartIds(String CartIds) {
        this.CartIds = CartIds;
    }

    public double getWellcashDiscount() {
        return WellcashDiscount;
    }

    public void setWellcashDiscount(double WellcashDiscount) {
        this.WellcashDiscount = WellcashDiscount;
    }

    public double getTotalCartAmount() {
        return TotalCartAmount;
    }

    public void setTotalCartAmount(double TotalCartAmount) {
        this.TotalCartAmount = TotalCartAmount;
    }

    public int getMemberId() {
        return MemberId;
    }

    public void setMemberId(int MemberId) {
        this.MemberId = MemberId;
    }

    public List<CouponBean> getCouponList() {
        return CouponList;
    }

    public void setCouponList(List<CouponBean> CouponList) {
        this.CouponList = CouponList;
    }


}
