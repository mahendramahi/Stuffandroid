package com.truworth.wellnesscorner.ui.mobileverification;

import android.databinding.ObservableBoolean;
import android.databinding.ObservableField;
import android.os.CountDownTimer;
import android.text.Editable;
import android.text.TextWatcher;

import com.truworth.wellnesscorner.TheWellnessCornerApp;
import com.truworth.wellnesscorner.base.BaseViewModel;
import com.truworth.wellnesscorner.data.SharedPreferenceHelper;
import com.truworth.wellnesscorner.model.LoginData;
import com.truworth.wellnesscorner.repo.LoginRepository;
import com.truworth.wellnesscorner.repo.model.request.OTPRequest;
import com.truworth.wellnesscorner.repo.model.request.VerifyOtpRequest;
import com.truworth.wellnesscorner.repo.model.response.OTPResponse;
import com.truworth.wellnesscorner.repo.model.response.RegisterOtpResponse;
import com.truworth.wellnesscorner.repo.model.response.RegisterOtpVerifyResponse;
import com.truworth.wellnesscorner.repo.model.response.VerifyOtpResponse;
import com.truworth.wellnesscorner.utils.RSAHelper;
import com.truworth.wellnesscorner.utils.SingleLiveEvent;

import javax.inject.Inject;

import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;

/**
 * Created by rajeshs on 4/2/2018.
 */

public class OTPViewModel extends BaseViewModel {
    public ObservableBoolean isOTPWrong = new ObservableBoolean();
    public ObservableField<String> timerText = new ObservableField<>();
    public ObservableBoolean isProgress = new ObservableBoolean();
    public ObservableBoolean isTimerAcive = new ObservableBoolean();
    public ObservableBoolean isOTPEnter = new ObservableBoolean();
    public ObservableField<String> mOtpCode = new ObservableField<>();
    public ObservableField<String> mErrorMessage = new ObservableField<>();
    public ObservableBoolean resendBtn = new ObservableBoolean();
    String mEmail;
    String mOtpSessionId;
    String mMobileNumber;
    @Inject
    SharedPreferenceHelper prefHelper;
    int redirectFrom;
    @Inject
    LoginRepository repository;
    SingleLiveEvent<Void> onOtpVerify = new SingleLiveEvent<>();
    SingleLiveEvent<Void> onOtpWrong = new SingleLiveEvent<>();
    CountDownTimer cd = new CountDownTimer(60000, 1000) {
        @Override
        public void onTick(long l) {

            timerText.set(l / 1000 + " SECONDS");
        }

        @Override
        public void onFinish() {
            timerText.set("Code expired");
            resendBtn.set(true);
        }
    };

    public OTPViewModel() {
        TheWellnessCornerApp.getApp().component().inject(this);
        this.isTimerAcive.set(true);
        cd.start();
        this.isProgress.set(false);
        this.resendBtn.set(false);
    }

    public SingleLiveEvent<Void> getOnOtpVerify() {
        return onOtpVerify;
    }

    public SingleLiveEvent<Void> getOnOtpWrong() {
        return onOtpWrong;
    }

    public int getRedirectFrom() {
        return redirectFrom;
    }

    public void setRedirectFrom(int redirectFrom) {
        this.redirectFrom = redirectFrom;
    }

    public void clearOTP() {
        mOtpCode.set("");
        mErrorMessage.set("");
        isOTPWrong.set(false);
        isTimerAcive.set(true);

    }

    void setViewModelData(String email, String mobileNumber, String otpSessionId) {
        this.mEmail = email;
        this.mMobileNumber = mobileNumber;
        this.mOtpSessionId = otpSessionId;


    }

    public TextWatcher otpWatcher() {
        return new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {


            }

            @Override
            public void afterTextChanged(Editable s) {
                if (s.length() == 6) {

                    isOTPEnter.set(true);
                    isTimerAcive.set(false);
                    isOTPWrong.set(false);
                    verifyOTP();
                }
            }
        };
    }

    public void verifyOTP() {

        if (redirectFrom == MobileNumberRedirectionType.FROM_REGISTRATION) {
            verifyOTPRegistration();
        } else {
            verifyOTPForLogin();
        }
    }

    public void verifyOTPForLogin() {
        VerifyOtpRequest request = new VerifyOtpRequest();
        request.setOtpCode(mOtpCode.get());
        request.setOtpSessionId(mOtpSessionId);
        repository.verifyOTP(request).subscribe(new Observer<VerifyOtpResponse>() {

            @Override
            public void onSubscribe(Disposable d) {

            }

            @Override
            public void onNext(VerifyOtpResponse verifyOtpResponse) {
                if (!verifyOtpResponse.isHasError()) {
                    cd.cancel();
                    LoginData data = verifyOtpResponse.getData();
                    prefHelper.saveUserData(data.getFirstName(), data.getLastName(), data.getScreenName(), data.getEmail(), data.getImage(), data.getProfileStep());
                    prefHelper.saveTokenData(data.getToken().getValidTo(), data.getToken().getValue());
                    onOtpVerify.call();
                } else {
                    isOTPWrong.set(true);
                    isTimerAcive.set(false);
                    isOTPEnter.set(false);
                    mErrorMessage.set(verifyOtpResponse.getError().getMessage());
                    getOnOtpWrong().call();
                }
            }


            @Override
            public void onError(Throwable e) {

            }

            @Override
            public void onComplete() {

            }
        });
    }

    public void verifyOTPRegistration() {
        setIsLoading(true);
        VerifyOtpRequest request = new VerifyOtpRequest();
        request.setOtpCode(mOtpCode.get());
        request.setOtpSessionId(mOtpSessionId);
        repository.verifyOTPRegistration(request).subscribe(new Observer<RegisterOtpVerifyResponse>() {

            @Override
            public void onSubscribe(Disposable d) {

            }

            @Override
            public void onNext(RegisterOtpVerifyResponse verifyOtpResponse) {
                if (!verifyOtpResponse.isHasError()) {
                    cd.cancel();
                    prefHelper.saveProfileStepNumber(2);
                    onOtpVerify.call();

                } else {
                    isOTPWrong.set(true);
                    isTimerAcive.set(false);
                    isOTPEnter.set(false);
                    mErrorMessage.set(verifyOtpResponse.getError().getMessage());
                    getOnOtpWrong().call();
                }
                setIsLoading(false);
            }


            @Override
            public void onError(Throwable e) {
                setIsLoading(false);
            }

            @Override
            public void onComplete() {
                setIsLoading(false);
            }
        });
    }

    public void resendOTP() {

        resendBtn.set(false);
        isProgress.set(true);
        if (redirectFrom == MobileNumberRedirectionType.FROM_REGISTRATION) {
            resendOTPForRegistration();
        } else {
            resendOtpForLogin();
        }
    }

    public void resendOtpForLogin() {
        setIsLoading(true);
        OTPRequest request = new OTPRequest();
        request.setEmail(RSAHelper.Encrypt(mEmail));
        request.setPhone(mMobileNumber);
        repository.sendOTP(request).subscribe(new Observer<OTPResponse>() {

            @Override
            public void onSubscribe(Disposable d) {

            }


            @Override
            public void onNext(OTPResponse otpResponse) {
                if (!otpResponse.isHasError()) {
                    mOtpSessionId = otpResponse.getData().getOtpSessionId();
                    resetFlags();
                } else {
                    mErrorMessage.set(otpResponse.getError().getMessage());
                    getOnOtpWrong().call();
                }
                isProgress.set(false);
                setIsLoading(false);
            }


            @Override
            public void onError(Throwable e) {
                setIsLoading(false);
            }


            @Override
            public void onComplete() {
                setIsLoading(false);
            }
        });


    }

    public void resendOTPForRegistration() {
        setIsLoading(true);
        OTPRequest request = new OTPRequest();
        request.setEmail(RSAHelper.Encrypt(mEmail));
        request.setPhone(mMobileNumber);
        repository.sendOTPForRegistration(request).subscribe(new Observer<RegisterOtpResponse>() {

            @Override
            public void onSubscribe(Disposable d) {

            }


            @Override
            public void onNext(RegisterOtpResponse otpResponse) {
                if (!otpResponse.isHasError()) {
                    mOtpSessionId = otpResponse.getData().getOtpSessionId();
                    resetFlags();
                } else {
                    mErrorMessage.set(otpResponse.getError().getMessage());
                    getOnOtpWrong().call();
                }
                isProgress.set(false);
                setIsLoading(false);
            }


            @Override
            public void onError(Throwable e) {
                setIsLoading(false);
            }


            @Override
            public void onComplete() {
                setIsLoading(false);
            }
        });


    }

    public void resetFlags() {
        mOtpCode.set("");
        mErrorMessage.set("");
        isOTPWrong.set(false);
        isTimerAcive.set(true);
        isOTPEnter.set(false);
        cd.start();
    }
}
