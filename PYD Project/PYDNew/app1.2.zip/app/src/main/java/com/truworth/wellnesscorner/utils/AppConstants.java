/*
 *  Copyright (C) 2017 MINDORKS NEXTGEN PRIVATE LIMITED
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      https://mindorks.com/license/apache-v2
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License
 */

package com.truworth.wellnesscorner.utils;

/**
 * Created by amitshekhar on 07/07/17.
 */

public final class AppConstants {

    public static String ENDPOINT_STAGING = "http://demo.truworth.net/twcmobileapi/";

    public static String UPLOAD_IMAGE_RESOURCE_URL = "http://demo.truworth.net/appimages/android/";

    public static String ENDPOINT_BASE = "";

    public static String API_ENDPOINT = ENDPOINT_STAGING;


    public static final int API_STATUS_CODE_LOCAL_ERROR = 0;

    public static final String DB_NAME = "";

    public static final long NULL_INDEX = -1L;

    public static final String PREF_NAME = "wellnesscorner_pref";

    //  public static final String SEED_DATABASE_OPTIONS = "seed/options.json";

    //public static final String SEED_DATABASE_QUESTIONS = "seed/questions.json";

    public static final String STATUS_CODE_FAILED = "failed";

    public static final String STATUS_CODE_SUCCESS = "success";

    public static final String TIMESTAMP_FORMAT = "yyyyMMdd_HHmmss";
    public static final String JPEG_FILE_PREFIX = "IMG_";
    public static final String JPEG_FILE_SUFFIX = ".jpg";
    public static final String CAPTURE_IMAGE_PATH = "/wellnesscorner/.images/";
    public static final int CAMERA_REQUEST = 1;
    public static final int GALLERY_REQUEST = 2;
    public static final int SHARE_DATA_REQUEST = 4;
    public static final int VIDEO_DATA_REQUEST = 5;
    public static final int CROPPED_IMAGE_REQUEST = 3;
    public static final int ADD_FOOD_DAILY_LOG = 101;
    public static final int CALL_MODULE_REQUEST = 6;
    public static final int MEDIA_TYPE_VIDEO = 3;
    public static final int MEDIA_TYPE_IMAGE = 1;
    public static final int MEDIA_TYPE_URL= 2;

    public static final String FOOD_TRACKER = "FOOD TRACKER";
    public static final String EXCERCISE_TRACKER = "EXCERCISE TRACKER";
    public static final String GLASS_TRACKER = "GLASS TRACKER";
    public static final String STEPS_TRACKER = "STEPS TRACKER";
    public static final String WEIGHT_TRACKER = "WEIGHT TRACKER";
    public static final String S_HEALTH = "Samsung Health";
    public static final String FITBIT = "Fitbit";
    public static final String GOOGLE_FIT = "Google Fit";
    public static final String E_FIT = "E Fit";
    public static final String MISFIT = "MisFit";
    public static final String GARMIN = "Garmin";

    public static final String IMAGE_GOOGLE_FIT_LARGE_URL = UPLOAD_IMAGE_RESOURCE_URL + "ic_google_fit_large.png";
    public static final String IMAGE_E_FIT_LARGE_URL = UPLOAD_IMAGE_RESOURCE_URL + "ic_efit_big.png";
    public static final String IMAGE_FIT_BIT_LARGE_URL = UPLOAD_IMAGE_RESOURCE_URL + "ic_fitbit_large.png";
    public static final String IMAGE_S_HEALTH_LARGE_URL = UPLOAD_IMAGE_RESOURCE_URL + "ic_s_health_large.png";
    public static final String IMAGE_GIRL_WITH_PHONE_URL = UPLOAD_IMAGE_RESOURCE_URL + "girl_with_phone.png";
    public static final String IMAGE_MIS_FIT_LARGE_URL = UPLOAD_IMAGE_RESOURCE_URL + "ic_misfit_large.png";
    public static final String BUNDLE_KEY_DEVICE_NAME = "deviceName";
    public static final String BUNDLE_KEY_DEVICE_TYPE = "deviceType";
    public static final int API_POST_DELAYED_TIME = 500;

    public static final String DATE_FORMAT_MMMM = "MMMM";
    public static final String DATE_FORMAT_MM_DD_YYYY_HHMM_FORWARD_SLASH = "MM/dd/yyyy HH:mm:ss.SSS";
    public static final String DATE_FORMAT_DD_MMM_YYYY = "dd MMM yyyy";
    public static final String DATE_FORMAT_YYYY_MM_DD = "yyyy-MM-dd";
    public static final String DATE_FORMAT_MM_DD_YYYY_FORWARD_SLASH = "MM/dd/yyyy";
    public static final String SERVER_DATE_FORMAT_WITH_MILLISECONDS = "yyyy-MM-dd'T'HH:mm:ss";
    public static final String DATE_FORMAT_YYYYMMDD = "yyyyMMdd";
    private AppConstants() {
        // This utility class is not publicly instantiable
    }
// for open post share type menu
    public static final int TAG_OPEN_FOR_DASHBOARD = 1;
    public static final int TAG_OPEN_FOR_MEAL = 2;
    public static final int TAG_OPEN_FOR_STEPS = 3;
    public static final int TAG_OPEN_FOR_WEIGHT = 4;
    public static final int TAG_OPEN_FOR_EXERICES = 5;
    public static final int TAG_OPEN_FOR_BEFORE_AFTER = 6;
}
