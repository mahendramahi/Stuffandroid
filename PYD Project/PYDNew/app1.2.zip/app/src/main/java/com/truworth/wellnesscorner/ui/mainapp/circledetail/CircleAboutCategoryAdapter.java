package com.truworth.wellnesscorner.ui.mainapp.circledetail;

import android.content.Context;
import android.databinding.DataBindingUtil;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.truworth.wellnesscorner.R;
import com.truworth.wellnesscorner.customviews.CustomTextView;
import com.truworth.wellnesscorner.databinding.RowCoachesBinding;
import com.truworth.wellnesscorner.model.CircleAboutBean;
import com.truworth.wellnesscorner.model.CircleCategoryDataBean;
import com.truworth.wellnesscorner.model.CircleCoach;
import com.truworth.wellnesscorner.model.CityStateCountryData;
import com.truworth.wellnesscorner.ui.registration.registrationstepfourth.CitySearchAdapter;
import com.truworth.wellnesscorner.ui.registration.registrationstepfourth.MyAdapterListener;

import java.util.ArrayList;
import java.util.List;

public class CircleAboutCategoryAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private List<CircleCategoryDataBean> categoryList;
    Context context;
    MyAdapterListener myAdapterListener;

    public CircleAboutCategoryAdapter(List<CircleCategoryDataBean> categoryList) {

        this.categoryList = categoryList;
        //this.context = context;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_circle_about_category, parent, false);
        return new ViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        ViewHolder itemViewHolder = (ViewHolder) holder;

        itemViewHolder.tvCategoryName.setText(categoryList.get(position).getCategoryName());
    }

    @Override
    public int getItemCount() {
        return categoryList != null ? categoryList.size() : 0;
    }

    public class ViewHolder extends RecyclerView.ViewHolder  {
        CustomTextView tvCategoryName;

        public ViewHolder(View itemView) {
            super(itemView);
            tvCategoryName = itemView.findViewById(R.id.tvCategoryName);
           // itemView.setOnClickListener(this);

        }
        /*@Override
        public void onClick(View view) {
            if (myAdapterListener != null) {
                myAdapterListener.onContainerClick(getAdapterPosition());
            }
        }*/
    }

}
