package com.truworth.wellnesscorner.model;

public class PreviousChallengesBean {
    private String challengeIdentity;
    private String challengeName;
    private int challengeEarnPeps;
    private String challengeStartDate;
    private String challengeEndDate;
    private int memberRank;
    private int memberPoints;
    private int challengeTypeId;

    public String getChallengeIdentity() {
        return challengeIdentity;
    }

    public void setChallengeIdentity(String challengeIdentity) {
        this.challengeIdentity = challengeIdentity;
    }

    public String getChallengeName() {
        return challengeName;
    }

    public void setChallengeName(String challengeName) {
        this.challengeName = challengeName;
    }

    public int getChallengePeps() {
        return challengeEarnPeps;
    }

    public void setChallengePeps(int challengeEarnPeps) {
        this.challengeEarnPeps = challengeEarnPeps;
    }

    public String getChallengeStartDate() {
        return challengeStartDate;
    }

    public void setChallengeStartDate(String challengeStartDate) {
        this.challengeStartDate = challengeStartDate;
    }

    public String getChallengeEndDate() {
        return challengeEndDate;
    }

    public void setChallengeEndDate(String challengeEndDate) {
        this.challengeEndDate = challengeEndDate;
    }

    public int getMemberRank() {
        return memberRank;
    }

    public void setMemberRank(int memberRank) {
        this.memberRank = memberRank;
    }

    public int getMemberPoints() {
        return memberPoints;
    }

    public void setMemberPoints(int memberPoints) {
        this.memberPoints = memberPoints;
    }

    public int getChallengeTypeId() {
        return challengeTypeId;
    }

    public void setChallengeTypeId(int challengeTypeId) {
        this.challengeTypeId = challengeTypeId;
    }
}
