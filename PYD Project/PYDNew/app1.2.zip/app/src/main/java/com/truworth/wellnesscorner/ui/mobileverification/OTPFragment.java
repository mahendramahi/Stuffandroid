package com.truworth.wellnesscorner.ui.mobileverification;

import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import com.truworth.wellnesscorner.BR;
import com.truworth.wellnesscorner.R;
import com.truworth.wellnesscorner.base.BaseFragment;
import com.truworth.wellnesscorner.databinding.FragmentOtpBinding;
import com.truworth.wellnesscorner.ui.mainapp.HomeDashBoardActivity;
import com.truworth.wellnesscorner.ui.registration.registrationstepthird.HeightWeightFragment;
import com.truworth.wellnesscorner.utils.FragmentUtils;


public class OTPFragment extends BaseFragment<FragmentOtpBinding, OTPViewModel> {
    public static final String TAG = "OTPFragment";

    private static final String ARG_EMAIL = "email";
    private static final String ARG_MOBILE = "MobileNumber";
    private static final String ARG_OTP_SESSION_ID = "otpSessionId";
    private static final String ARG_REDIRECT_FROM = "from";

    private String mMobileNumber;
    private String mEmail;
    private String mOtpSessionId;
    private int redirectFrom;
    OTPViewModel viewModel;

    public OTPFragment() {
        // Required empty public constructor
    }

    public static OTPFragment newInstance(String mobileNumber, String email, String otpSessionId, int redirectFrom) {
        OTPFragment fragment = new OTPFragment();
        Bundle args = new Bundle();
        args.putString(ARG_MOBILE, mobileNumber);
        args.putString(ARG_EMAIL, email);
        args.putString(ARG_OTP_SESSION_ID, otpSessionId);
        args.putInt(ARG_REDIRECT_FROM, redirectFrom);

        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setKeyboardHideOnTapOutSide(false);
        if (getArguments() != null) {
            mMobileNumber = getArguments().getString(ARG_MOBILE);
            mEmail = getArguments().getString(ARG_EMAIL);
            mOtpSessionId = getArguments().getString(ARG_OTP_SESSION_ID);
            redirectFrom = getArguments().getInt(ARG_REDIRECT_FROM);
        }
    }

    @Override
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        viewModel.setViewModelData(mEmail, mMobileNumber, mOtpSessionId);
        viewModel.setRedirectFrom(redirectFrom);
        setMobileNumber();
        setUpOnOTPVerify();
        attachOtpWrongObserver();
    }

    private void setMobileNumber() {
        String phoneNumber = mMobileNumber;
        String strLastFourDi = phoneNumber.length() >= 4 ? phoneNumber.substring(phoneNumber.length() - 4): "";
        getViewDataBinding().tvMobileNumber.setText("xxxxxx"+strLastFourDi);
    }

    private void setUpOnOTPVerify() {
        viewModel.getOnOtpVerify().observe(this, new Observer<Void>() {
            @Override
            public void onChanged(@Nullable Void aVoid) {
                openNextScreen();
            }
        });
    }


    /**
     * Override for set binding variable
     *
     * @return variable id
     */
    @Override
    public int getBindingVariable() {
        return BR.viewModel;
    }

    /**
     * @return layout resource id
     */
    @Override
    public int getLayoutId() {
        return R.layout.fragment_otp;
    }

    /**
     * Override for set view model
     *
     * @return view model instance
     */
    @Override
    public OTPViewModel getViewModel() {
        viewModel = ViewModelProviders.of(this).get(OTPViewModel.class);

        return viewModel;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

    }

    @Override
    public void onDetach() {
        super.onDetach();

    }


    public void openNextScreen() {
        if (redirectFrom == MobileNumberRedirectionType.FROM_LOGIN) {
            //TODO
            //Open Dashboard here
            openDashBordActivity();

        } else if (redirectFrom == MobileNumberRedirectionType.FROM_REGISTRATION) {
            hideKeyboard();
            //FragmentUtils.removeAllFragmentFromStack((AppCompatActivity) getActivity());
            getActivity().getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.registerContainer, HeightWeightFragment.newInstance(), HeightWeightFragment.TAG)
                    .commit();

        }
    }

    private void openDashBordActivity() {
        Intent intent = new Intent(getActivity(), HomeDashBoardActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        getActivity().finish();
    }

    private void attachOtpWrongObserver() {
        viewModel.getOnOtpWrong().observe(this, new Observer<Void>() {
            @Override
            public void onChanged(@Nullable Void aVoid) {
               // binding.etEnterOTP.getBackground().mutate().setColorFilter(getResources().getColor(android.R.color.holo_red_light), PorterDuff.Mode.SRC_ATOP);
                getViewDataBinding().etEnterOTP.setError(true);
                getViewDataBinding().etEnterOTP.updateColorForLines(true);
            }
        });
    }
}
