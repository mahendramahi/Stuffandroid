package com.truworth.wellnesscorner.model;

import com.truworth.wellnesscorner.ui.mainapp.post.IPostListItem;

public class CommentListData implements IPostListItem {

    private String memberName;
    private String memberImage;
    private String comment;
    private String commentDate;
    private String memberIdentity;
    private String commentIdentity;
    private int totalHiFive;
    private boolean isHiFive;

    @Override
    public int getPostListItemType() {
        return IPostListItem.TYPE_COMMENT;
    }

    public String getMemberName() {
        return memberName;
    }

    public void setMemberName(String memberName) {
        this.memberName = memberName;
    }

    public String getMemberImage() {
        return memberImage;
    }

    public void setMemberImage(String memberImage) {
        this.memberImage = memberImage;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public String getCommentDate() {
        return commentDate;
    }

    public void setCommentDate(String commentDate) {
        this.commentDate = commentDate;
    }

    public String getMemberIdentity() {
        return memberIdentity;
    }

    public void setMemberIdentity(String memberIdentity) {
        this.memberIdentity = memberIdentity;
    }

    public String getCommentIdentity() {
        return commentIdentity;
    }

    public void setCommentIdentity(String commentIdentity) {
        this.commentIdentity = commentIdentity;
    }

    public int getTotalHiFives() {
        return totalHiFive;
    }

    public void setTotalHiFives(int totalHiFives) {
        this.totalHiFive = totalHiFives;
    }

    public boolean isHiFive() {
        return isHiFive;
    }

    public void setHiFive(boolean hiFive) {
        isHiFive = hiFive;
    }
}
