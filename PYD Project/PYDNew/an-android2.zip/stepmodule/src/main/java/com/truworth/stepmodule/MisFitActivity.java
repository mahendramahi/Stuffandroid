package com.truworth.stepmodule;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.customtabs.CustomTabsClient;
import android.support.customtabs.CustomTabsIntent;
import android.support.customtabs.CustomTabsServiceConnection;
import android.support.customtabs.CustomTabsSession;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;

import com.truworth.stepmodule.model.MisFitBody;
import com.truworth.stepmodule.model.MisFitResponse;
import com.truworth.stepmodule.rest.FitBitRestClient;
import com.truworth.stepmodule.utils.Constant;
import com.truworth.stepmodule.utils.FitBitConfig;
import com.truworth.stepmodule.utils.NetworkFactory;
import com.truworth.stepmodule.utils.Utils;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by PalakC on 02/02/2018.
 */

public class MisFitActivity extends AppCompatActivity {

    private static final String CUSTOM_TAB_PACKAGE_NAME = "com.android.chrome";
    private CustomTabsClient mClient;
    private CustomTabsSession mCustomTabsSession;
    private CustomTabsServiceConnection mCustomTabsServiceConnection;
    private CustomTabsIntent customTabsIntent;
    private boolean firstTime;
    private boolean isNewIntentCalled;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fitbit_authentication);
        speedUpChromeTabs();

        CustomTabsClient.bindCustomTabsService(this, CUSTOM_TAB_PACKAGE_NAME, mCustomTabsServiceConnection);

        customTabsIntent = new CustomTabsIntent.Builder(mCustomTabsSession)
                .setToolbarColor(ContextCompat.getColor(this, R.color.colorPrimary))
                .setShowTitle(true)
                .build();
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        unbindCustomTabsService();
    }

    private void speedUpChromeTabs() {
        mCustomTabsServiceConnection = new CustomTabsServiceConnection() {
            @Override
            public void onCustomTabsServiceConnected(ComponentName componentName, CustomTabsClient customTabsClient) {
                //Pre-warming
                mClient = customTabsClient;
                mClient.warmup(0L);
                mCustomTabsSession = mClient.newSession(null);
                customTabsIntent.launchUrl(MisFitActivity.this, Uri.parse(FitBitConfig.MISFIT_AUTHORIZATION_URL));
            }

            @Override
            public void onServiceDisconnected(ComponentName name) {
                mClient = null;

            }
        };
    }

    private void unbindCustomTabsService() {
        if (mCustomTabsServiceConnection == null) {
            return;
        }
        unbindService(mCustomTabsServiceConnection);

        mClient = null;
        mCustomTabsSession = null;
        mCustomTabsServiceConnection = null;
    }

    @Override
    protected void onNewIntent(Intent intent) {
        isNewIntentCalled = true;
        String response = intent.getDataString();
        Intent resultIntent = new Intent();

        if (response != null && response.contains("=")) {
            if (response.length() > 0) {
                String misFitCode = response.substring(response.indexOf("=") + 1, response.length());
                if (misFitCode != null && !misFitCode.isEmpty()) {
                    callFitBitClientApi(misFitCode);
                }
            }
        } else {
            resultIntent.putExtra("misFitStatus", "failure");
            setResult(-2, resultIntent);
            finish();
        }

    }

    private void callFitBitClientApi(String misFitCode) {
        if (NetworkFactory.getInstance().isNetworkAvailable(this)) {
            MisFitBody misFitBody = new MisFitBody();
            misFitBody.setClient_id(FitBitConfig.MISFIT_CLIENT_ID);
            misFitBody.setClient_secret(FitBitConfig.MISFIT_CLIENT_SECRET);
            misFitBody.setCode(misFitCode);
            misFitBody.setGrant_type(FitBitConfig.MISFIT_AUTHORIZATION_CODE);
            misFitBody.setRedirect_uri(FitBitConfig.MISFIT_REDIRECT_URI);

            FitBitRestClient restClient = new FitBitRestClient(Constant.MISFIT, "",MisFitActivity.this, FitBitConfig.MISFIT_BASE_URL, false);
            restClient.getFitBitStepsService().loginToMisFit(misFitBody).enqueue(new Callback<MisFitResponse>() {
                @Override
                public void onResponse(Call<MisFitResponse> call, Response<MisFitResponse> response) {
                    if (response != null && response.body() != null) {
                        Intent resultIntent = new Intent();
                        if (response.code() == 200) {
                            String accessToken = response.body().getAccess_token();
                            String tokenType = response.body().getToken_type();
                            Utils.printLog("accessToken", accessToken + "");
                            Utils.printLog("tokenType", tokenType + "");
                            //      WellnessCornerApp.getPreferenceManager().clearDeviceConnectTokenPreferences();
                            //      WellnessCornerApp.getPreferenceManager().setPrefKeyMisFitAccessToken(accessToken);
                            //WellnessCornerApp.getPreferenceManager().setPrefKeyMisFitAccessToken(tokenType);
                            //     WellnessCornerApp.getPreferenceManager().setPrefKeyDeviceConnected(Constant.MISFIT);

                            resultIntent.putExtra("misFitStatus", "success");
                            resultIntent.putExtra("device_type", Constant.MISFIT);
                            resultIntent.putExtra("token", accessToken);
                            setResult(Activity.RESULT_OK, resultIntent);
                        } else {
                            String error = response.body().getError();
                            String errorDescription = response.body().getError_description();
                            resultIntent.putExtra("misFitStatus", errorDescription);
                            setResult(-2, resultIntent);
                        }
                        finish();
                    }
                }

                @Override
                public void onFailure(Call<MisFitResponse> call, Throwable t) {

                }
            });
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (firstTime) {
            if (getIntent().getDataString() == null && !isNewIntentCalled) {
                finish();
            }
        }
        if (!firstTime) {
            firstTime = !firstTime;
        }
    }
}
