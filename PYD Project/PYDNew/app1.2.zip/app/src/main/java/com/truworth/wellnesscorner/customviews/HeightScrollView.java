package com.truworth.wellnesscorner.customviews;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.ScrollView;

public class HeightScrollView extends ScrollView {

    private OnScrollViewListener mOnScrollViewListener;

    public HeightScrollView(Context context) {
        super(context);
    }

    public HeightScrollView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public HeightScrollView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
    }

    public void setOnScrollViewListener(OnScrollViewListener l) {
        this.mOnScrollViewListener = l;
    }

    protected void onScrollChanged(int l, int t, int oldl, int oldt) {
        if (mOnScrollViewListener != null) {
            mOnScrollViewListener.onScrollChanged(this, l, t, oldl, oldt);
        }
        super.onScrollChanged(l, t, oldl, oldt);
    }
    public interface OnScrollViewListener {
        void onScrollChanged(HeightScrollView v, int l, int t, int oldl, int oldt);
    }
    @Override
    protected float getTopFadingEdgeStrength() {
        return 0.0f;
    }

}
