package com.truworth.wellnesscorner.model;

/**
 * Created by PalakC on 2/21/2018.
 */

public class DataMemberProgramItem {
        private int Workshop_ID;
        private int MemberPID;
        private String Workshop_Name;
        private String Workshop_Image;
        private int Total_Days;
        private int Remaning_Days;
        private double Program_Compliance;
        private String Program_Category;
        private int Pending_Task;
        private double ProgressPercentage;
        private String ProgressTitle;

        public int getWorkshop_ID() {
            return Workshop_ID;
        }

        public void setWorkshop_ID(int Workshop_ID) {
            this.Workshop_ID = Workshop_ID;
        }

        public int getMemberPID() {
            return MemberPID;
        }

        public void setMemberPID(int MemberPID) {
            this.MemberPID = MemberPID;
        }

        public String getWorkshop_Name() {
            return Workshop_Name;
        }

        public void setWorkshop_Name(String Workshop_Name) {
            this.Workshop_Name = Workshop_Name;
        }

        public String getWorkshop_Image() {
            return Workshop_Image;
        }

        public void setWorkshop_Image(String Workshop_Image) {
            this.Workshop_Image = Workshop_Image;
        }

        public int getTotal_Days() {
            return Total_Days;
        }

        public void setTotal_Days(int Total_Days) {
            this.Total_Days = Total_Days;
        }

        public int getRemaning_Days() {
            return Remaning_Days;
        }

        public void setRemaning_Days(int Remaning_Days) {
            this.Remaning_Days = Remaning_Days;
        }

        public double getProgram_Compliance() {
            return Program_Compliance;
        }

        public void setProgram_Compliance(double Program_Compliance) {
            this.Program_Compliance = Program_Compliance;
        }

        public String getProgram_Category() {
            return Program_Category;
        }

        public void setProgram_Category(String Program_Category) {
            this.Program_Category = Program_Category;
        }

        public int getPending_Task() {
            return Pending_Task;
        }

        public void setPending_Task(int Pending_Task) {
            this.Pending_Task = Pending_Task;
        }

        public double getProgressPercentage() {
            return ProgressPercentage;
        }

        public void setProgressPercentage(double ProgressPercentage) {
            this.ProgressPercentage = ProgressPercentage;
        }

        public String getProgressTitle() {
            return ProgressTitle;
        }

        public void setProgressTitle(String ProgressTitle) {
            this.ProgressTitle = ProgressTitle;
        }

}
