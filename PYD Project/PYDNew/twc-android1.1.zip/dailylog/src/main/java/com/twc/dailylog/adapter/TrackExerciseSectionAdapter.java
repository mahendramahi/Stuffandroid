package com.twc.dailylog.adapter;

import android.app.Activity;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.afollestad.sectionedrecyclerview.SectionedRecyclerViewAdapter;
import com.twc.dailylog.R;
import com.twc.dailylog.fragments.TrackActivityFragment;
import com.twc.dailylog.fragments.TrackExerciseFragment;
import com.twc.dailylog.interfaces.OnTrackerReadingSave;
import com.twc.dailylog.model.beans.ExerciseSectionItem;
import com.twc.dailylog.utils.DateFactory;
import com.twc.dailylog.utils.Utils;
import com.twc.greendaolib.ExerciseItem;


import java.util.ArrayList;

/**
 * Created by ManishJ1 on 7/5/2016.
 */
public class TrackExerciseSectionAdapter extends SectionedRecyclerViewAdapter<RecyclerView.ViewHolder> {


    private ArrayList<ExerciseSectionItem> sectionItems;
    private Activity activity;
    private OnTrackerReadingSave onTrackerReadingSave;

    public TrackExerciseSectionAdapter(ArrayList<ExerciseSectionItem> sectionItems, Activity activity, OnTrackerReadingSave onTrackerReadingSave) {
        this.sectionItems = sectionItems;
        this.activity = activity;
        this.onTrackerReadingSave=onTrackerReadingSave;
    }

    @Override
    public int getSectionCount() {
        return sectionItems.size();
    }

    @Override
    public int getItemCount(int section) {
        return sectionItems.get(section).getmExerciseItemsList().size();
    }

    @Override
    public void onBindHeaderViewHolder(RecyclerView.ViewHolder holder, int section) {
        String sectionName = sectionItems.get(section).getSectionName();
        SectionViewHolder sectionViewHolder = (SectionViewHolder) holder;

        sectionViewHolder.tvFoodHeader.setText(sectionName);


    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int section, int relativePosition, int absolutePosition) {
        ArrayList<ExerciseItem> exerciseItems = sectionItems.get(section).getmExerciseItemsList();

        ItemViewHolder itemViewHolder = (ItemViewHolder) holder;
        itemViewHolder.tvSearchList.setText(exerciseItems.get(relativePosition).getActivity());
        itemViewHolder.tvSearchList.setCompoundDrawablesWithIntrinsicBounds(0,0, R.drawable.ic_arrow_next,0);
        itemViewHolder.tvSearchList.setTag(relativePosition);
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View v;
        if (viewType == VIEW_TYPE_HEADER) {
            v = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.row_trackmeal_diet_plan_header, parent, false);
            return new SectionViewHolder(v);
        } else {
            v = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.row_searchexercise_item, parent, false);
            return new ItemViewHolder(v);
        }
    }

    // SectionViewHolder Class for Sections
    public class SectionViewHolder extends RecyclerView.ViewHolder {


        final TextView tvFoodHeader;

        public SectionViewHolder(View itemView) {
            super(itemView);
            tvFoodHeader = itemView.findViewById(R.id.tvFoodHeader);
        }
    }

    // ItemViewHolder Class for Items in each Section
    public class ItemViewHolder extends RecyclerView.ViewHolder {

        final TextView tvSearchList;

        public ItemViewHolder(View itemView) {
            super(itemView);
            tvSearchList = itemView.findViewById(R.id.tvSearchList);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    String tag = tvSearchList.getTag().toString();
                    int position = Integer.parseInt(tag);
                    ArrayList<ExerciseItem> exerciseItems = sectionItems.get(0).getmExerciseItemsList();
                    Bundle bundle = new Bundle();
                    bundle.putInt("ID",0);////put 0 for the new activity id
                    bundle.putString("Name",exerciseItems.get(position).getActivity());
                    bundle.putInt("Duration",exerciseItems.get(position).getActivityDuration());
                    bundle.putDouble("CaloriesBurnedIn1Min",Double.parseDouble(exerciseItems.get(position).getCaloriesBurnedIn1MIn()));
                    bundle.putString("redirectFrom", TrackExerciseFragment.class.getSimpleName());
                    bundle.putString("Time", DateFactory.getInstance().getCurrentTime("hh:mm aa"));

                    TrackActivityFragment trackActivityFragment = TrackActivityFragment.newInstance(bundle);
                    trackActivityFragment.setTrackerReadingCallback(onTrackerReadingSave);

                    Utils.replaceFragment(activity.getFragmentManager(), trackActivityFragment, TrackActivityFragment.class.getSimpleName(), true, R.id.fragmentContainerMeal);
                }
            });
        }
    }
}
