package com.twc.dailylog.model.beans;

/**
 * Created by PankajS on 8/6/2016.
 */
public class DailyLogItem
{
    private String nutritionMealType;
    private int MemberID;
    private int nutritionID;
    private int FoodID;
    private String name;
    private double nutritionQuantity;
    private String nutritionCalorie;
    private String calorie;
    private String nutritionCarbs;
    private String nutritionFat;
    private String nutritionSodium;
    private String nutritionProtein;
    private String nutritionStandardServing;


    private int activityID;
    private String activityDuration;
    private String activityCalorie;
    private String calories;
    private String date;
    private  String time;
    private String type;
    private boolean isTotalCalories = false;
    private double listTotalCalories;

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getNutritionMealType() {
        return nutritionMealType;
    }

    public void setNutritionMealType(String nutritionMealType) {
        this.nutritionMealType = nutritionMealType;
    }

    public int getMemberID() {
        return MemberID;
    }

    public void setMemberID(int memberID) {
        MemberID = memberID;
    }

    public int getNutritionID() {
        return nutritionID;
    }

    public void setNutritionID(int nutritionID) {
        this.nutritionID = nutritionID;
    }

    public int getFoodID() {
        return FoodID;
    }

    public void setFoodID(int foodID) {
        this.FoodID = foodID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getNutritionQuantity() {
        return nutritionQuantity;
    }

    public void setNutritionQuantity(double nutritionQuantity) {
        this.nutritionQuantity = nutritionQuantity;
    }

    public String getNutritionCalorie() {
        return nutritionCalorie;
    }

    public void setNutritionCalorie(String nutritionCalorie) {
        this.nutritionCalorie = nutritionCalorie;
    }

    public String getCalorie() {
        return calorie;
    }

    public void setCalorie(String calorie) {
        this.calorie = calorie;
    }

    public String getNutritionCarbs() {
        return nutritionCarbs;
    }

    public void setNutritionCarbs(String nutritionCarbs) {
        this.nutritionCarbs = nutritionCarbs;
    }

    public String getNutritionFat() {
        return nutritionFat;
    }

    public void setNutritionFat(String nutritionFat) {
        this.nutritionFat = nutritionFat;
    }

    public String getNutritionSodium() {
        return nutritionSodium;
    }

    public void setNutritionSodium(String nutritionSodium) {
        this.nutritionSodium = nutritionSodium;
    }

    public String getNutritionProtein() {
        return nutritionProtein;
    }

    public void setNutritionProtein(String nutritionProtein) {
        this.nutritionProtein = nutritionProtein;
    }

    public String getNutritionStandardServing() {
        return nutritionStandardServing;
    }

    public void setNutritionStandardServing(String nutritionStandardServing) {
        this.nutritionStandardServing = nutritionStandardServing;
    }

    public int getActivityID() {
        return activityID;
    }

    public void setActivityID(int activityID) {
        this.activityID = activityID;
    }

    public String getActivityDuration() {
        return activityDuration;
    }

    public void setActivityDuration(String activityDuration) {
        this.activityDuration = activityDuration;
    }

    public String getActivityCalorie() {
        return activityCalorie;
    }

    public void setActivityCalorie(String activityCalorie) {
        this.activityCalorie = activityCalorie;
    }

    public String getCalories() {
        return calories;
    }

    public void setCalories(String calories) {
        this.calories = calories;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public boolean isTotalCalories() {
        return isTotalCalories;
    }

    public void setTotalCalories(boolean totalCalories) {
        isTotalCalories = totalCalories;
    }

    public double getListTotalCalories() {
        return listTotalCalories;
    }

    public void setListTotalCalories(double totalCalories) {
        this.listTotalCalories = totalCalories;
    }
}
