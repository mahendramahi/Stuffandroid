package com.twc.store.model.response;

/**
 * Created by GurvinderS on 8/16/2016.
 */
public class SaveMemberBillingDetailsResponse {
    private int status;
    private String TransactionID;


    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getTransactionID() {
        return TransactionID;
    }

    public void setTransactionID(String transactionID) {
        TransactionID = transactionID;
    }
}
