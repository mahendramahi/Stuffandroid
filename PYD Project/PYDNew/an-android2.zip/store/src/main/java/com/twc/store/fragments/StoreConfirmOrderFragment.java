package com.twc.store.fragments;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.method.DigitsKeyListener;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.twc.store.BillingAddressConfig;
import com.twc.store.PayUMoneyPaymentActivity;

import com.twc.store.R;
import com.twc.store.R2;
import com.twc.store.StoreActivity;
import com.twc.store.StoreCategoryActivity;
import com.twc.store.StoreDetailActivity;
import com.twc.store.adapter.ConfirmOrderCartAdapter;
import com.twc.store.dialog.ApiErrorDialog;
import com.twc.store.dialog.NetworkErrorDialog;
import com.twc.store.interfaces.OnRetryAfterNetworkError;
import com.twc.store.model.beans.BillingInfoBean;
import com.twc.store.model.beans.CartListItem;
import com.twc.store.model.beans.CartOrderDetailObject;
import com.twc.store.model.requestbody.StoreCheckoutBody;
import com.twc.store.model.requestbody.StoreSaveOrderRequestBody;
import com.twc.store.model.requestbody.StoreUpdateOrderBody;
import com.twc.store.model.response.StoreCheckoutResponse;
import com.twc.store.model.response.StoreSaveOrderResponse;
import com.twc.store.model.response.StoreUpdateOrderResponse;
import com.twc.store.rest.RestClient;
import com.twc.store.utils.Constant;
import com.twc.store.utils.DialogFactory;
import com.twc.store.utils.NetworkFactory;
import com.twc.store.utils.StoreConfig;
import com.twc.store.utils.Utils;
import com.twc.store.views.CustomEditTextView;
import com.twc.store.views.CustomProgressDialog;
import com.twc.store.views.CustomTextView;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;
import butterknife.OnTextChanged;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static butterknife.OnTextChanged.Callback.TEXT_CHANGED;

/**
 * Created by GurvinderS on 9/15/2017.
 */
// Last Updated on 05/02/2018 by richas implemented Error screens
public class StoreConfirmOrderFragment extends BaseFragment implements OnRetryAfterNetworkError {

    private final int wellcashPercent = 20;
    @BindView(R2.id.tvMemberName)
    CustomTextView tvMemberName;
    @BindView(R2.id.tvMemberAddress)
    CustomTextView tvMemberAddress;
    @BindView(R2.id.tvMemberContact)
    CustomTextView tvMemberContact;
    @BindView(R2.id.tvUpdateAddress)
    CustomTextView tvUpdateAddress;
    @BindView(R2.id.tvMemberPostalAddress)
    CustomTextView tvMemberPostalAddress;
    @BindView(R2.id.rvProductList)
    RecyclerView rvProductList;
    @BindView(R2.id.tvPrice)
    CustomTextView tvPrice;
    @BindView(R2.id.tvTax)
    CustomTextView tvTax;
    @BindView(R2.id.tvWellCashDiscount)
    CustomTextView tvWellCashDiscount;
    @BindView(R2.id.tvPriceTotal)
    CustomTextView tvPriceTotal;
    @BindView(R2.id.tvGrandPrice)
    CustomTextView tvGrandPrice;
    @BindView(R2.id.tvProceedToPay)
    CustomTextView tvProceedToPay;
    @BindView(R2.id.tvPriceWithCartCount)
    CustomTextView tvPriceWithCartCount;
    @BindView(R2.id.tvCoupon)
    CustomTextView tvCoupon;
    @BindView(R2.id.discountLayout)
    LinearLayout discountLayout;
    @BindView(R2.id.addAddressLayout)
    LinearLayout addAddressLayout;
    @BindView(R2.id.updateAddressLayout)
    LinearLayout updateAddressLayout;
    @BindView(R2.id.priceCouponLayout)
    LinearLayout priceCouponLayout;
    @BindView(R2.id.wellcashSeparator)
    View wellcashSeparator;
    @BindView(R2.id.tvAddNewAddress)
    CustomTextView tvAddNewAddress;
    @BindView(R2.id.viewCouponSeparator)
    View viewCouponSeparator;
    @BindView(R2.id.tvWellCashPercent)
    CustomTextView tvWellCashPercent;
    @BindView(R2.id.etPayByCash)
    CustomEditTextView etPayByCash;
    @BindView(R2.id.tvWellCashApply)
    CustomTextView tvWellCashApply;
    @BindView(R2.id.tvWellCashPrice)
    CustomTextView tvWellCashPrice;
    @BindView(R2.id.ivWellCashCancel)
    ImageView ivWellCashCancel;
    double calculatedWellCash = 0;
    double calculatedAmount = 0;
    private double wellCashMain;
    private BillingInfoBean billingInfoBean;
    private ArrayList<CartListItem> cartListItems;
    private ConfirmOrderCartAdapter cartAdapter;
    private CartOrderDetailObject cartOrderDetailObject;

    public static StoreConfirmOrderFragment newInstance(CartOrderDetailObject cartOrderDetailObject) {
        StoreConfirmOrderFragment fragment = new StoreConfirmOrderFragment();
        Bundle bundle = new Bundle();
        bundle.putParcelable("cartOrderDetailObject", cartOrderDetailObject);
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    public int getFragmentLayout() {
        return R.layout.fragment_confirm_mycart;
    }

    @Override
    public void onFragmentReady() {

        tvWellCashPercent.setText("Note: Maximum WellCash use is " + wellcashPercent + "% of the Total Amount");
        etPayByCash.setText("0");
        etPayByCash.setKeyListener(DigitsKeyListener.getInstance(true, true)); //use for stop crash on double dot

        LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity());
        rvProductList.setLayoutManager(layoutManager);
        rvProductList.setAdapter(cartAdapter);
        if (cartOrderDetailObject != null) {
            setData(cartOrderDetailObject);
            checkOutApiCall(cartOrderDetailObject);
        }

    }

    @OnTextChanged(value = {R2.id.etPayByCash}, callback = TEXT_CHANGED)
    public void afterPayByCash(Editable editable) {
        if (editable.length() > 0) {
            if (etPayByCash.getText().toString().startsWith(".") || etPayByCash.getText().toString().startsWith("-")) {
                etPayByCash.setText("");
                return;
            }
            tvWellCashApply.setBackground(ContextCompat.getDrawable(getActivity(), R.drawable.custom_store_button));

            double wellCashPrice = (Double.parseDouble(etPayByCash.getText().toString().replace(",", "")));
            if (wellCashPrice == 0.0) {
                tvWellCashApply.setClickable(false);
                tvWellCashApply.setTextColor(Color.LTGRAY);
            } else if (wellCashPrice > wellCashMain) {
                tvWellCashApply.setClickable(false);
                tvWellCashApply.setTextColor(Color.LTGRAY);
            } else {
                tvWellCashApply.setClickable(true);
                tvWellCashApply.setTextColor(Color.WHITE);
            }
        } else {
            tvWellCashApply.setTextColor(ContextCompat.getColor(getActivity(), R.color.color_cc000000));
            tvWellCashApply.setBackground(null);

        }
    }

    private void setData(CartOrderDetailObject cartOrderDetailObject) {
        cartListItems.clear();
        cartListItems.addAll(cartOrderDetailObject.getCartListItems());
        cartAdapter.notifyDataSetChanged();

        tvPrice.setText(getString(R.string.rupee_symbol) + " " + Utils.getFormattedAmount(cartOrderDetailObject.getTotalAmount()));
        tvTax.setText(getString(R.string.rupee_symbol) + " " + Utils.getFormattedAmountManageZero(cartOrderDetailObject.getTotalTax()));
        if (cartOrderDetailObject.getTotalWellCashDiscount() == 0.0) {
            discountLayout.setVisibility(View.GONE);
            wellcashSeparator.setVisibility(View.GONE);
        } else {
            wellcashSeparator.setVisibility(View.VISIBLE);
            discountLayout.setVisibility(View.VISIBLE);
        }
        tvWellCashDiscount.setText(getString(R.string.rupee_symbol) + " " + Utils.getFormattedAmount(cartOrderDetailObject.getTotalWellCashDiscount()));
        tvCoupon.setText(getString(R.string.rupee_symbol) + " " + Utils.getFormattedAmount(cartOrderDetailObject.getCouponDiscount()));
        tvPriceTotal.setText(getString(R.string.rupee_symbol) + " " + Utils.getFormattedAmount(cartOrderDetailObject.getGrandTotalAmount()));
        tvGrandPrice.setText(getString(R.string.rupee_symbol) + " " + Utils.getFormattedAmount(cartOrderDetailObject.getGrandTotalAmount()));
        changeCartItemSize();

        if (cartOrderDetailObject.getCouponDiscount() <= 0) {
            priceCouponLayout.setVisibility(View.GONE);
            viewCouponSeparator.setVisibility(View.GONE);
        } else {
            priceCouponLayout.setVisibility(View.VISIBLE);
            viewCouponSeparator.setVisibility(View.VISIBLE);
        }

    }

    @OnClick({R2.id.tvProceedToPay, R2.id.tvUpdateAddress, R2.id.tvWellCashApply, R2.id.tvAddNewAddress, R2.id.ivWellCashCancel})
    public void onViewClicked(View view) {

            if (view.getId() == R.id.tvProceedToPay) {
                if (validateBillingAddress()) {
                    saveOrderApiCall(cartOrderDetailObject);
                }

            } else if (view.getId() == R.id.tvUpdateAddress) {
                StoreMemberAddressFragment fragment = StoreMemberAddressFragment.newInstance();
                fragment.setMemberBillingDetails(billingInfoBean);
                Utils.replaceFragment(getFragmentManager(), fragment, StoreMemberAddressFragment.class.getSimpleName(), true, R.id.fragmentContainer);
            } else if (view.getId() == R.id.tvAddNewAddress) {
                StoreMemberAddressFragment fragment1 = StoreMemberAddressFragment.newInstance();
                Utils.replaceFragment(getFragmentManager(), fragment1, StoreMemberAddressFragment.class.getSimpleName(), true, R.id.fragmentContainer);

            } else if (view.getId() == R.id.tvWellCashApply){
                Utils.hideSoftKeyboard(getActivity());

            applyWellCashDiscount();
        }

            else if(view.getId()==R.id.ivWellCashCancel) {
                etPayByCash.setText("0");
                discountLayout.setVisibility(View.GONE);
                wellcashSeparator.setVisibility(View.GONE);
                priceCalculation();
            }



    }

    private void applyWellCashDiscount() {
        if (!etPayByCash.getText().toString().equalsIgnoreCase("") && etPayByCash.getText().toString().trim().length() > 0) {
            double wellCashPrice = (Double.parseDouble(etPayByCash.getText().toString().replace(",", "")));
            double applicableWellCash = Double.parseDouble(Utils.convertTwoDecimalPoint((cartOrderDetailObject.getGrandTotalAmount() * wellcashPercent) / 100.0));

            if (Double.compare(wellCashPrice, applicableWellCash) <= 0) {
                etPayByCash.setText(Utils.convertTwoDecimalPoint(wellCashPrice));
                discountLayout.setVisibility(View.VISIBLE);
                wellcashSeparator.setVisibility(View.VISIBLE);
                tvWellCashDiscount.setText(getString(R.string.rupee_symbol) + " -" + Utils.getFormattedAmount(wellCashPrice));
                priceCalculation();
            } else {
                Utils.showToast(getActivity(), "You can apply WellCash only " + wellcashPercent + "% of the cart Total amount.");
            }
        }
    }

    private void setWellCashDiscountFirstTime(double wellCashValue) {
        discountLayout.setVisibility(View.GONE);
        wellcashSeparator.setVisibility(View.GONE);

        double applicableWellCash = (cartOrderDetailObject.getGrandTotalAmount() * wellcashPercent) / 100.0;
        if (wellCashValue > 0 && applicableWellCash > 0) {
            if (Double.compare(applicableWellCash, wellCashValue) <= 0) {
                etPayByCash.setText(Utils.getFormattedAmountManageZero(applicableWellCash));
            } else {
                etPayByCash.setText(Utils.getFormattedAmountManageZero(wellCashValue));
            }
            discountLayout.setVisibility(View.VISIBLE);
            wellcashSeparator.setVisibility(View.VISIBLE);
            tvWellCashDiscount.setText(getString(R.string.rupee_symbol) + " -" + etPayByCash.getText().toString());
        }
        priceCalculation();
    }

    private void priceCalculation() {
        changeCartItemSize();
        if (cartListItems != null && cartListItems.size() > 0) {

            if (cartListItems.size() == 1) {
                tvPriceWithCartCount.setText(getString(R.string.price) + " (" + cartListItems.size() + " item)");
            } else if (cartListItems.size() > 1) {
                tvPriceWithCartCount.setText(getString(R.string.price) + " (" + cartListItems.size() + " items)");
            }
            double totalTax = 0.0;
            double price = 0.0;
            double couponDiscount = 0.0;
            double wellCash = 0.0;
            if (etPayByCash.getText().toString().trim().length() > 0) {
                wellCash = Double.valueOf(etPayByCash.getText().toString().trim().replace(",", ""));
            }
            if (wellCash == 0) {
                discountLayout.setVisibility(View.GONE);
                wellcashSeparator.setVisibility(View.GONE);
            }
            for (CartListItem cartListItem : cartListItems) {
                int quantity = cartListItem.getSCart_Quantity();
                totalTax += cartListItem.getSCart_TaxAmount() * quantity;
                price += cartListItem.getSCart_TotalAmount() * quantity;
            }
            couponDiscount = cartOrderDetailObject.getCouponDiscount();
            tvTax.setText(getString(R.string.rupee_symbol) + " " + Utils.getFormattedAmountManageZero(totalTax));
            tvPrice.setText(getString(R.string.rupee_symbol) + " " + Utils.getFormattedAmount(price));
            tvWellCashDiscount.setText(getString(R.string.rupee_symbol) + " -" + Utils.getFormattedAmount(wellCash));
            tvCoupon.setText(getString(R.string.rupee_symbol) + " -" + Utils.getFormattedAmount(couponDiscount));
            double totalAmount = (price + totalTax) - (wellCash + couponDiscount);


            tvPriceTotal.setText(getString(R.string.rupee_symbol) + " " + Utils.getFormattedAmount((price + totalTax) - couponDiscount));
            tvGrandPrice.setText(getString(R.string.rupee_symbol) + " " + Utils.getFormattedAmount(totalAmount));

            // assign varible to pass wellcash and total amount to payment gateway
            calculatedWellCash = wellCash;
            calculatedAmount = totalAmount;


        }
    }


    private boolean validateBillingAddress() {

        if (billingInfoBean == null || billingInfoBean.getAddress1().isEmpty() || billingInfoBean.getCity().isEmpty() || billingInfoBean.getCountry().isEmpty() || billingInfoBean.getPhoneNo().isEmpty() || billingInfoBean.getPincode().isEmpty() ||
                billingInfoBean.getState().isEmpty() || billingInfoBean.getName().isEmpty()) {
            Utils.showToast(getActivity(), "Please add your complete shipping address");
            return false;
        } else {
            return true;
        }

    }

    private void checkOutApiCall(CartOrderDetailObject cartOrderDetailObject) {
        if (NetworkFactory.getInstance().isNetworkAvailable(getActivity())) {
            final CustomProgressDialog pb;
            pb = new CustomProgressDialog(getActivity(), R.style.custom_progress_style, false);
            pb.show();

            StoreCheckoutBody storeCheckoutBody = new StoreCheckoutBody();
            storeCheckoutBody.setMemberId(StoreConfig.storeUser.getMemberId());
            storeCheckoutBody.setCartIds(cartOrderDetailObject.getCartIds());
            RestClient restClient = new RestClient(getActivity(), StoreConfig.BASE_URL, StoreConfig.mdebug);

            restClient.getStoreService().checkOut(storeCheckoutBody).enqueue(new Callback<StoreCheckoutResponse>() {
                @Override
                public void onResponse(Call<StoreCheckoutResponse> call, Response<StoreCheckoutResponse> response) {

                    if (isAdded() && getActivity() != null) {
                        if (pb.isShowing()) {
                            pb.dismiss();
                        }
                        if (response != null && response.body() != null && response.body().getData() != null) {

                            if (response.body().getStatus() == 0) {
                                wellCashMain = response.body().getData().getWellCashAvailable();


                                tvWellCashPrice.setText("WellCash " + getString(R.string.rupee_symbol) + " (" + Utils.getFormattedAmountManageZero(response.body().getData().getWellCashAvailable()) + ")");


                                setWellCashDiscountFirstTime(response.body().getData().getWellCashAvailable());

                                if (BillingAddressConfig.getInstance().getBillingInfoBean() != null) {
                                    tvMemberName.setText(BillingAddressConfig.getInstance().getBillingInfoBean().getName());

                                    String address1 = BillingAddressConfig.getInstance().getBillingInfoBean().getAddress1() + ",";
                                    String address2 = BillingAddressConfig.getInstance().getBillingInfoBean().getAddress2();

                                    if (address2 != null && !address2.toString().trim().isEmpty()) {
                                        address1 = address1 + address2 + ",";
                                    }
                                    updateAddressLayout.setVisibility(View.VISIBLE);
                                    addAddressLayout.setVisibility(View.GONE);
                                    tvMemberAddress.setText(address1);
                                    tvMemberPostalAddress.setText(BillingAddressConfig.getInstance().getBillingInfoBean().getCity() + " - " + BillingAddressConfig.getInstance().getBillingInfoBean().getPincode() + "," + BillingAddressConfig.getInstance().getBillingInfoBean().getState() + "," + BillingAddressConfig.getInstance().getBillingInfoBean().getCountry());
                                    tvMemberContact.setText(BillingAddressConfig.getInstance().getBillingInfoBean().getPhoneNo());
                                    billingInfoBean = BillingAddressConfig.getInstance().getBillingInfoBean();
                                    tvMemberName.setVisibility(View.VISIBLE);
                                    tvMemberAddress.setVisibility(View.VISIBLE);
                                    tvMemberContact.setVisibility(View.VISIBLE);

                                    String text = "<u>Update</u>";
                                    tvUpdateAddress.setText(Utils.fromHtml(text), TextView.BufferType.SPANNABLE);
                                } else if (response.body().getData().getBillingInfo() != null && !response.body().getData().getBillingInfo().getAddress1().isEmpty() && !response.body().getData().getBillingInfo().getCity().isEmpty() && !response.body().getData().getBillingInfo().getCountry().isEmpty() && !response.body().getData().getBillingInfo().getPhoneNo().isEmpty() && !response.body().getData().getBillingInfo().getPincode().isEmpty() && !response.body().getData().getBillingInfo().getState().isEmpty() && !response.body().getData().getBillingInfo().getName().isEmpty()) {
                                    tvMemberName.setText(response.body().getData().getBillingInfo().getName());

                                    String address1 = response.body().getData().getBillingInfo().getAddress1() + ",";
                                    String address2 = response.body().getData().getBillingInfo().getAddress2();

                                    if (address2 != null && !address2.toString().trim().isEmpty()) {
                                        address1 = address1 + address2 + ",";
                                    }
                                    updateAddressLayout.setVisibility(View.VISIBLE);
                                    addAddressLayout.setVisibility(View.GONE);
                                    tvMemberAddress.setText(address1);
                                    tvMemberPostalAddress.setText(response.body().getData().getBillingInfo().getCity() + " - " + response.body().getData().getBillingInfo().getPincode() + "," + response.body().getData().getBillingInfo().getState() + "," + response.body().getData().getBillingInfo().getCountry());
                                    tvMemberContact.setText(response.body().getData().getBillingInfo().getPhoneNo());
                                    billingInfoBean = response.body().getData().getBillingInfo();
                                    tvMemberName.setVisibility(View.VISIBLE);
                                    tvMemberAddress.setVisibility(View.VISIBLE);
                                    tvMemberContact.setVisibility(View.VISIBLE);
                                    String text = "<u>Update</u>";
                                    tvUpdateAddress.setText(Utils.fromHtml(text), TextView.BufferType.SPANNABLE);
                                } else {
                                    addAddressLayout.setVisibility(View.VISIBLE);
                                    updateAddressLayout.setVisibility(View.GONE);
                                    tvMemberName.setVisibility(View.GONE);
                                    tvMemberAddress.setVisibility(View.GONE);
                                    tvMemberContact.setVisibility(View.GONE);
                                    String text = "<u>Add Address</u>";
                                    tvUpdateAddress.setText(Utils.fromHtml(text), TextView.BufferType.SPANNABLE);
                                }

                                List<StoreCheckoutResponse.DataBean.CartBean> cartItems = response.body().getData().getCart();
                                boolean isPriceUpdate = false;
                                boolean isOutOfStock = false;
                                for (StoreCheckoutResponse.DataBean.CartBean item : cartItems) {
                                    if (item.isIsPriceUpdate()) {
                                        isPriceUpdate = true;
                                    }
                                    if (!item.isIsInStock()) {
                                        isOutOfStock = true;
                                    }
                                }
                                if (isOutOfStock) {
                                    DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.out_of_stock_message), getString(R.string.str_ok), new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialogInterface, int i) {
                                            getActivity().getFragmentManager().popBackStack();
                                        }
                                    }, false);
                                } else if (isPriceUpdate) {
                                    DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.cart_price_update_message), getString(R.string.str_ok), new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialogInterface, int i) {
                                            getActivity().getFragmentManager().popBackStack();
                                        }
                                    }, false);
                                }

                            } else if (response.body().getStatus() == -1) {
                                //DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_response_failure), getString(R.string.str_ok), false);
                                showApiErrorDialog();

                            }
                        } else {
                            //DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_response_failure), getString(R.string.str_ok), false);
                            showApiErrorDialog();
                        }
                    }
                }

                @Override
                public void onFailure(Call<StoreCheckoutResponse> call, Throwable t) {
                    if (isAdded() && getActivity() != null) {
                        if (pb.isShowing()) {
                            pb.dismiss();
                        }
                        //DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_failure), getString(R.string.str_ok), false);
                        showApiErrorDialog();
                    }
                }
            });
        } else {
            // show Network Error Screen Dialog
            NetworkErrorDialog networkErrorDialog = new NetworkErrorDialog(getActivity(), getActivity(), StoreConfirmOrderFragment.this);
            networkErrorDialog.show();
            Window window = networkErrorDialog.getWindow();
            window.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);
        }
    }

    // method to show Api Error Screen Dialog
    private void showApiErrorDialog() {
        ApiErrorDialog apiErrorDialog = new ApiErrorDialog(getActivity(), getActivity(), StoreConfirmOrderFragment.this);
        apiErrorDialog.show();
        Window window = apiErrorDialog.getWindow();
        window.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);
    }

    private void changeCartItemSize() {
        if (cartListItems != null && cartListItems.size() > 0) {
            if (cartListItems.size() == 1) {
                tvPriceWithCartCount.setText(getString(R.string.price) + " (" + cartListItems.size() + " items)");

            } else if (cartListItems.size() > 1) {
                tvPriceWithCartCount.setText(getString(R.string.price) + " (" + cartListItems.size() + " items)");

            }
        } else {

            tvPriceWithCartCount.setText(getString(R.string.price));
        }
    }

    /************ Save Order API ************/

    private void saveOrderApiCall(final CartOrderDetailObject cartOrderDetailObject) {
        final CustomProgressDialog pb;
        pb = new CustomProgressDialog(getActivity(), R.style.custom_progress_style, false);
        pb.show();

        //body
        StoreSaveOrderRequestBody storeSaveOrderRequestBody = new StoreSaveOrderRequestBody();
        storeSaveOrderRequestBody.setFullName(billingInfoBean.getName());
        storeSaveOrderRequestBody.setMobile(billingInfoBean.getPhoneNo());
        storeSaveOrderRequestBody.setBillingAddress(billingInfoBean.getAddress1());
        storeSaveOrderRequestBody.setAddress2(billingInfoBean.getAddress2());
        storeSaveOrderRequestBody.setCity(billingInfoBean.getCity());
        storeSaveOrderRequestBody.setState(billingInfoBean.getState());
        storeSaveOrderRequestBody.setCountry(billingInfoBean.getCountry());
        storeSaveOrderRequestBody.setPincode(billingInfoBean.getPincode());
        storeSaveOrderRequestBody.setMemberBilling_ID(billingInfoBean.getMemberBilling_ID());
        storeSaveOrderRequestBody.setCouponList(cartOrderDetailObject.getCouponList());
        storeSaveOrderRequestBody.setTotalCartAmount(calculatedAmount);
        storeSaveOrderRequestBody.setWellcashDiscount(calculatedWellCash);
        storeSaveOrderRequestBody.setCartIds(cartOrderDetailObject.getCartIds());
        storeSaveOrderRequestBody.setMemberId(Integer.parseInt(StoreConfig.storeUser.getMemberId()));

        RestClient restClient = new RestClient(getActivity(), StoreConfig.BASE_URL, StoreConfig.mdebug);

        restClient.getStoreService().saveOrder(storeSaveOrderRequestBody).enqueue(new Callback<StoreSaveOrderResponse>() {
            @Override
            public void onResponse(Call<StoreSaveOrderResponse> call, Response<StoreSaveOrderResponse> response) {

                if (isAdded() && getActivity() != null) {
                    if (pb.isShowing()) {
                        pb.dismiss();
                    }
                    if (response != null && response.body() != null) {
                        if (response.body().getStatus() == 0 && response.body().getData() != null) {
                            if (response.body().getData().getOrderStatus() == 0) {
                                if (cartOrderDetailObject.getTotalAmount() > 0) {
                                    // getActivity().getFragmentManager().popBackStack(StoreHomeFragment.class.getSimpleName(), 0);

                                    Intent intent = new Intent(getActivity(), PayUMoneyPaymentActivity.class);
                                    cartOrderDetailObject.setTotalWellCashDiscount(calculatedWellCash);
                                    cartOrderDetailObject.setGrandTotalAmount(calculatedAmount);
                                    intent.putExtra("cartOrderDetailObject", cartOrderDetailObject);
                                    intent.putExtra("OrderID", response.body().getData().getOrderId());
                                    intent.putExtra("SaltKey", response.body().getData().getSaltKey());
                                    startActivityForResult(intent, Constant.PAYMENT_INTEGRATION_REQUEST_CODE);
                                } else {
                                    // wellcash is greater than total amount at checkout time. if my cart amount is less from wellcash
                                    updateOrderApiCall("SUCCESS", response.body().getData().getOrderId(), response.body().getData().getOrderId() + " Payment Success");
                                }


                            } else if (response.body().getData().getOrderStatus() == -2) {
                                DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.coupon_expire_message), getString(R.string.str_ok), new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        getActivity().getFragmentManager().popBackStack();
                                    }
                                }, false);
                            } else if (response.body().getData().getOrderStatus() == -3) {
                                DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.wellcash_amount_failure_message), getString(R.string.str_ok), new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        getActivity().getFragmentManager().popBackStack();
                                    }
                                }, false);
                            } else if (response.body().getData().getOrderStatus() == -4) {
                                DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.cart_price_update_message), getString(R.string.str_ok), new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        getActivity().getFragmentManager().popBackStack();
                                    }
                                }, false);
                            } else if (response.body().getData().getOrderStatus() == -5) {
                                DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.out_of_stock_message), getString(R.string.str_ok), new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        getActivity().getFragmentManager().popBackStack();
                                    }
                                }, false);
                            }
                        } else {
                            DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_response_failure), getString(R.string.str_ok), false);
                        }

                    } else {
                        DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_response_failure), getString(R.string.str_ok), false);
                    }
                }
            }

            @Override
            public void onFailure(Call<StoreSaveOrderResponse> call, Throwable t) {
                if (isAdded() && getActivity() != null) {
                    if (pb.isShowing()) {
                        pb.dismiss();
                    }
                    DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_failure), getString(R.string.str_ok), false);
                }
            }
        });
    }

    private void updateOrderApiCall(String status, int orderId, String paymentTransactionId) {
        final CustomProgressDialog pb;
        pb = new CustomProgressDialog(getActivity(), R.style.custom_progress_style, false);
        pb.show();

        StoreUpdateOrderBody storeUpdateOrderBody = new StoreUpdateOrderBody();
        storeUpdateOrderBody.setCartIds(cartOrderDetailObject.getCartIds());
        storeUpdateOrderBody.setOrderID(orderId);
        storeUpdateOrderBody.setStatus(status);
        storeUpdateOrderBody.setTransactionId(paymentTransactionId);
        // storeUpdateOrderBody.setTransactionDetail();
        storeUpdateOrderBody.setMemberId(StoreConfig.storeUser.getMemberId());
        RestClient restClient = new RestClient(getActivity(), StoreConfig.BASE_URL, StoreConfig.mdebug);

        restClient.getStoreService().updateOrder(storeUpdateOrderBody).enqueue(new Callback<StoreUpdateOrderResponse>() {
            @Override
            public void onResponse(Call<StoreUpdateOrderResponse> call, Response<StoreUpdateOrderResponse> response) {

                if (isAdded() && getActivity() != null) {
                    if (pb.isShowing()) {
                        pb.dismiss();
                    }
                        /*if (response != null && response.body() != null) {
                            if (response.body().getStatus() == 0) {
                                getActivity().getFragmentManager().popBackStack(StoreHomeFragment.class.getSimpleName(), 0);
                            } else {
                                DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_response_failure), getString(R.string.str_ok), false);
                            }
                        } else {
                            DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_response_failure), getString(R.string.str_ok), false);

                        }*/

                }
                getActivity().getFragmentManager().popBackStack(StoreHomeFragment.class.getSimpleName(), 0);
            }

            @Override
            public void onFailure(Call<StoreUpdateOrderResponse> call, Throwable t) {
                if (isAdded() && getActivity() != null) {
                    if (pb.isShowing()) {
                        pb.dismiss();
                    }
                }
                getActivity().getFragmentManager().popBackStack(StoreHomeFragment.class.getSimpleName(), 0);
            }
        });

    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == Constant.PAYMENT_INTEGRATION_REQUEST_CODE) {
            if (resultCode == Activity.RESULT_OK) {
                getActivity().getFragmentManager().popBackStackImmediate(StoreHomeFragment.class.getSimpleName(), 0);
            } else if (resultCode == Activity.RESULT_CANCELED) {
                getActivity().getFragmentManager().popBackStack(StoreMyCartFragment.class.getSimpleName(), 0);

            }
        }
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        cartListItems = new ArrayList<>();
        cartAdapter = new ConfirmOrderCartAdapter(getActivity(), cartListItems, StoreConfirmOrderFragment.this);
        if (getArguments() != null) {
            cartOrderDetailObject = getArguments().getParcelable("cartOrderDetailObject");
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        if(getActivity() instanceof StoreActivity) {
            ((StoreActivity) getActivity()).setToolBarTitle(getString(R.string.confirm_order));
            ((StoreActivity) getActivity()).showHomeAsUpEnableToolbar();
        }else  if(getActivity() instanceof StoreDetailActivity) {
            ((StoreDetailActivity) getActivity()).setToolBarTitle(getString(R.string.confirm_order));
            ((StoreDetailActivity) getActivity()).showHomeAsUpEnableToolbar();
        }else if(getActivity() instanceof StoreCategoryActivity){
            ((StoreCategoryActivity) getActivity()).setToolBarTitle("Shipping Address");
            ((StoreCategoryActivity) getActivity()).showHomeAsUpEnableToolbar();
        }
    }

    @Override
    public void onRetry() {
        if (cartOrderDetailObject != null) {
            setData(cartOrderDetailObject);
            checkOutApiCall(cartOrderDetailObject);
        }
    }
}
