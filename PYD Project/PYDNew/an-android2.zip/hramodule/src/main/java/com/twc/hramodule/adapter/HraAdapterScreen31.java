package com.twc.hramodule.adapter;

/**
 Created by GurvinderS on 8/5/2016.
 */

import android.app.Activity;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;


import com.twc.hramodule.R;
import com.twc.hramodule.model.beans.HraItem;

import java.util.ArrayList;
import java.util.List;


/**
 * Created by Gurvinder on 7/5/2016.
 */
public class HraAdapterScreen31 extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    Activity mActivity;
    String tabName;
    private List<HraItem> mHraItemArrayList;
    private boolean isRadioBtn;
    private CheckBox lastChecked = null;
    private int lastCheckedPos = 0;

    public HraAdapterScreen31(List<HraItem> mItemArrayList, Activity activity, boolean isRadioBtn) {
        this.mHraItemArrayList = mItemArrayList;
        this.mActivity = activity;
        this.isRadioBtn = isRadioBtn;
    }


    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_hra_31, parent, false);
        return new ItemViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, final int position) {
        ItemViewHolder itemViewHolder = (ItemViewHolder) holder;
        itemViewHolder.tvAns.setText(mHraItemArrayList.get(position).getAnswer());
        itemViewHolder.checkBox.setChecked(mHraItemArrayList.get(position).isSelected());

        itemViewHolder.checkBox.setTag(position);
        if(itemViewHolder.checkBox.isChecked()){
            lastCheckedPos=position;
            lastChecked= itemViewHolder.checkBox;
        }

        itemViewHolder.checkBox.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

                if (!isRadioBtn) {
                    CheckBox cb = (CheckBox) v;
                    int clickedPos = (Integer) cb.getTag();

                    HraItem item = mHraItemArrayList.get(clickedPos);
                    item.setSelected(cb.isChecked());
                    mHraItemArrayList.get(position).setSelected(cb.isChecked());
                } else {

                    CheckBox cb = (CheckBox) v;
                    int clickedPos = (Integer) cb.getTag();

                    if (cb.isChecked()) {
                        if (lastChecked != null) {
                            lastChecked.setChecked(false);
                            mHraItemArrayList.get(lastCheckedPos).setSelected(false);
                        }

                        lastChecked = cb;
                        lastCheckedPos = clickedPos;
                    } else
                        lastChecked = null;

                    mHraItemArrayList.get(clickedPos).setSelected(cb.isChecked());
                }

            }
        });

    }

    @Override
    public int getItemCount() {
        return (null != mHraItemArrayList ? mHraItemArrayList.size() : 0);
    }

    public ArrayList<HraItem> getSelectedAnswers() {
        ArrayList<HraItem> answerList = new ArrayList<>();
        for (HraItem hraItem : mHraItemArrayList) {
            if (hraItem.isSelected()) {
                answerList.add(hraItem);
            }
        }
        return answerList;
    }

    public class ItemViewHolder extends RecyclerView.ViewHolder {

        final TextView tvAns;
        final CheckBox checkBox;

        public ItemViewHolder(View itemView) {
            super(itemView);
            tvAns = itemView.findViewById(R.id.tvAns);
            checkBox = itemView.findViewById(R.id.checkBox);


            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    CheckBox cb = v.findViewById(R.id.checkBox);

                    if (!isRadioBtn) {

                        cb.setChecked(!cb.isChecked());

                        int clickedPos = (Integer) cb.getTag();

                        HraItem item = mHraItemArrayList.get(clickedPos);

                        item.setSelected(cb.isChecked());
                        mHraItemArrayList.get(getAdapterPosition()).setSelected(cb.isChecked());
                    } else {

                        cb.setChecked(!cb.isChecked());

                        int clickedPos = (Integer) cb.getTag();

                        if (cb.isChecked()) {
                            if (lastChecked != null) {
                                lastChecked.setChecked(false);
                                mHraItemArrayList.get(lastCheckedPos).setSelected(false);
                            }

                            lastChecked = cb;
                            lastCheckedPos = clickedPos;
                        } else
                            lastChecked = null;

                        mHraItemArrayList.get(clickedPos).setSelected(cb.isChecked());
                    }

                }
            });
        }


    }
}

