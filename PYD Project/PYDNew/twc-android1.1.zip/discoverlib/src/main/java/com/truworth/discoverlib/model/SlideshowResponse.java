package com.truworth.discoverlib.model;

import com.google.gson.annotations.SerializedName;

import java.util.List;

/**
 * If this code works it was written by Somesh Kumar on 10 August, 2016. If not, I don't know who wrote it.
 */
public class SlideshowResponse {

    private DataBean data;
    private int status;

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public static class DataBean {
        private int SlideId;
        private String Title;
        private String Category;
        private String Image;
        private String Description;
        private String ModifiedOn;
        private int Rating;
        private int memberRating;
        private int status;
        private boolean IsFavourites;
        @SerializedName("Details")
        private List<DetailsBean> SlideshowDetail;
        private List<RelatedSlideBean> RelatedSlide;

        public int getSlideId() {
            return SlideId;
        }

        public void setSlideId(int SlideId) {
            this.SlideId = SlideId;
        }

        public String getTitle() {
            return Title;
        }

        public void setTitle(String Title) {
            this.Title = Title;
        }

        public String getCategory() {
            return Category;
        }

        public void setCategory(String Category) {
            this.Category = Category;
        }

        public String getImage() {
            return Image;
        }

        public void setImage(String Image) {
            this.Image = Image;
        }

        public String getDescription() {
            return Description;
        }

        public void setDescription(String Description) {
            this.Description = Description;
        }

        public String getModifiedOn() {
            return ModifiedOn;
        }

        public void setModifiedOn(String ModifiedOn) {
            this.ModifiedOn = ModifiedOn;
        }

        public int getRating() {
            return Rating;
        }

        public void setRating(int Rating) {
            this.Rating = Rating;
        }

        public int getMemberRating() {
            return memberRating;
        }

        public void setMemberRating(int memberRating) {
            this.memberRating = memberRating;
        }

        public int getStatus() {
            return status;
        }

        public void setStatus(int status) {
            this.status = status;
        }

        public boolean isIsFavourites() {
            return IsFavourites;
        }

        public void setIsFavourites(boolean IsFavourites) {
            this.IsFavourites = IsFavourites;
        }

        public List<DetailsBean> getSlideshowDetail() {
            return SlideshowDetail;
        }

        public void setSlideshowDetail(List<DetailsBean> SlideshowDetail) {
            this.SlideshowDetail = SlideshowDetail;
        }

        public List<RelatedSlideBean> getRelatedSlide() {
            return RelatedSlide;
        }

        public void setRelatedSlide(List<RelatedSlideBean> RelatedSlide) {
            this.RelatedSlide = RelatedSlide;
        }

        public static class DetailsBean {
            private String SubHeading;
            private String SlideText;
            private String Image;
            private int SlideOrder;

            public String getSubHeading() {
                return SubHeading;
            }

            public void setSubHeading(String SubHeading) {
                this.SubHeading = SubHeading;
            }

            public String getSlideText() {
                return SlideText;
            }

            public void setSlideText(String SlideText) {
                this.SlideText = SlideText;
            }

            public String getImage() {
                return Image;
            }

            public void setImage(String Image) {
                this.Image = Image;
            }

            public int getSlideOrder() {
                return SlideOrder;
            }

            public void setSlideOrder(int SlideOrder) {
                this.SlideOrder = SlideOrder;
            }
        }

        public static class RelatedSlideBean {
            private int SlideID;
            private String SlideName;
            private String SlideImage;
            private String URL;

            public String getURL() {
                return URL;
            }

            public void setURL(String URL) {
                this.URL = URL;
            }

            public int getSlideID() {
                return SlideID;
            }

            public void setSlideID(int SlideID) {
                this.SlideID = SlideID;
            }

            public String getSlideName() {
                return SlideName;
            }

            public void setSlideName(String SlideName) {
                this.SlideName = SlideName;
            }

            public String getSlideImage() {
                return SlideImage;
            }

            public void setSlideImage(String SlideImage) {
                this.SlideImage = SlideImage;
            }
        }
    }
}
