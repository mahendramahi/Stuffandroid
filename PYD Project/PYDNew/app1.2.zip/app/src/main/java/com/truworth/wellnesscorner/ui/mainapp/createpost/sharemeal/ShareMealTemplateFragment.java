package com.truworth.wellnesscorner.ui.mainapp.createpost.sharemeal;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.View;

import com.truworth.wellnesscorner.BR;
import com.truworth.wellnesscorner.R;
import com.truworth.wellnesscorner.base.BaseFragment;
import com.truworth.wellnesscorner.databinding.FragmentShareMealThemeBinding;
import com.truworth.wellnesscorner.model.FoodsBean;
import com.truworth.wellnesscorner.ui.registration.registrationstepfifth.CropActivity;
import com.truworth.wellnesscorner.utils.AppConstants;
import com.truworth.wellnesscorner.utils.CameraGalleryUtil;
import com.truworth.wellnesscorner.utils.CompressImage;
import com.truworth.wellnesscorner.utils.Utils;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@SuppressLint("ValidFragment")
public class ShareMealTemplateFragment extends BaseFragment<FragmentShareMealThemeBinding, ShareMealTemplateViewModel> {
    public static final String TAG = "ShareMealTemplateFragment";
    private static final String DATE = "date";
    private static final String MEAL_TYPE = "mealType";
    private static final String MEMBER_NAME = "memberName";
    private static final String MEMBER_IMAGE = "memberImage";
    ShareMealTemplateViewModel viewModel;
    String date, mealType, memberName, memberImage;
    List<FoodsBean> foodList = new ArrayList<>();
    StringBuilder foodNames;
    private Bitmap finalBitmap;
    private CameraGalleryUtil cameraGalleryUtil;
    private String filePath;
    boolean isCameraSelected;
    private Bitmap cameraBitmap;

    @SuppressLint("ValidFragment")
    public ShareMealTemplateFragment(List<FoodsBean> foodList) {
        // Required empty public constructor
        this.foodList = foodList;
    }

    public static ShareMealTemplateFragment newInstance(String date, String mealType, List<FoodsBean> foodList, String memberName, String memberImage) {
        ShareMealTemplateFragment fragment = new ShareMealTemplateFragment(foodList);
        Bundle args = new Bundle();
        args.putString(DATE, date);
        args.putString(MEAL_TYPE, mealType);
        args.putString(MEMBER_NAME, memberName);
        args.putString(MEMBER_IMAGE, memberImage);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        cameraGalleryUtil = new CameraGalleryUtil(getActivity(), ShareMealTemplateFragment.this);
        if (getArguments() != null) {
            date = getArguments().getString(DATE);
            mealType = getArguments().getString(MEAL_TYPE);
            memberName = getArguments().getString(MEMBER_NAME);
            memberImage = getArguments().getString(MEMBER_IMAGE);
        }

    }

    @Override
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        double foodTotalCalories=0.0;
        double Protein=0.0, Carbs=0.0, Fat=0.0;

        foodNames = new StringBuilder();
        for(int i = 0; i<foodList.size(); i++){
            foodNames.append(foodList.get(i).getName()).append(", ");
            foodTotalCalories = foodTotalCalories + foodList.get(i).getCalorie();
            Protein = Protein + foodList.get(i).getProtein();
            Carbs = Carbs + foodList.get(i).getCarbs();
            Fat = Fat + foodList.get(i).getFat();

        }
        //deleting last comma from all food names
        foodNames.deleteCharAt(foodNames.toString().trim().length() - 1);

        //show meal type's first letter in upper case
        if(mealType!=null) {
            mealType = mealType.toString().toLowerCase();
            mealType = mealType.substring(0, 1).toUpperCase() + mealType.substring(1);
        }

        if(memberName!=null)
            viewModel.getMemberName().set(memberName);

        viewModel.getMemberImage().set(memberImage);
        viewModel.getDate().set(date);
        viewModel.getMealType().set(mealType);
        viewModel.getFoodNames().set(String.valueOf(foodNames));
        viewModel.getFoodCalories().set(Utils.doubleToString(foodTotalCalories));
        viewModel.getFoodProtein().set(Utils.doubleToString(Protein));
        viewModel.getFoodCarbs().set(Utils.doubleToString(Carbs));
        viewModel.getFoodFat().set(Utils.doubleToString(Fat));

        setDefault();
        setClickObserver();

    }

    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    public int getBindingVariable() {
        return BR.viewModel;
    }

    @Override
    public int getLayoutId() {
        return R.layout.fragment_share_meal_theme;
    }

    @Override
    public ShareMealTemplateViewModel getViewModel() {
        viewModel = ViewModelProviders.of(this).get(ShareMealTemplateViewModel.class);
        return viewModel;
    }

    private void setClickObserver() {
        viewModel.getDefaultImgClick().observe(this, new Observer<Void>() {
            @Override
            public void onChanged(@Nullable Void avoid) {
                isCameraSelected = false;
                setSelection(0, R.drawable.template_select_white);

                getViewDataBinding().rlImage.setVisibility(View.GONE);
                getViewDataBinding().rlTemplate.setVisibility(View.VISIBLE);
                setDefault();
            }
        });

        viewModel.getCameraBtnClick().observe(this, new Observer<Void>() {
            @Override
            public void onChanged(@Nullable Void avoid) {
                if (filePath != null) {
                    setSelection(R.drawable.template_select_white, R.drawable.rounded_grey_light_border);

                    setData(filePath);
                    if (isCameraSelected) {
                        Utils.checkForCameraPermissions(getActivity(),cameraGalleryUtil);
                    }
                } else {
                    Utils.checkForCameraPermissions(getActivity(),cameraGalleryUtil);
                }
                isCameraSelected = true;
            }
        });

        viewModel.getShareBtn().observe(this, new Observer<Void>() {
            @Override
            public void onChanged(@Nullable Void avoid) {
                if (finalBitmap != null) {
                    String path = Utils.getImageUri(getContext(), finalBitmap);
                    Intent returnIntent = new Intent();
                    returnIntent.putExtra("result", path);
                    getActivity().setResult(Activity.RESULT_OK, returnIntent);
                    getActivity().finish();

                }
            }
        });
    }



    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode == Activity.RESULT_OK) {
            Uri selectedImage;
            setSelection(R.drawable.template_select_white, R.drawable.rounded_grey_light_border);
            if (requestCode == AppConstants.CAMERA_REQUEST) {
                if (cameraGalleryUtil.getCameraFilePath() != null) {
                    File file = new File(cameraGalleryUtil.getCameraFilePath());
                    Uri myuri = Uri.fromFile(file);
                    filePath = cameraGalleryUtil.getPath(getActivity(), myuri);
                   cameraBitmap=null;
                    setData(filePath);

                }
            }
        } else {

        }
    }



    public void setData(String filePath) {
        if (filePath != null) {
            getViewDataBinding().includeCameraLayout.tvMemberDetails.setVisibility(View.VISIBLE);
            getViewDataBinding().includeCameraLayout.ivInnerLogo.setVisibility(View.VISIBLE);
            getViewDataBinding().rlImage.setVisibility(View.VISIBLE);
            getViewDataBinding().rlTemplate.setVisibility(View.GONE);

            if(cameraBitmap!=null){
                getViewDataBinding().ivCaptureImage.setImageBitmap(cameraBitmap);
            }
            else{
                cameraBitmap = cameraGalleryUtil.getBitmap(filePath,getViewDataBinding().ivCaptureImage.getWidth(), getViewDataBinding().ivCaptureImage.getHeight());
                getViewDataBinding().ivCaptureImage.setImageBitmap(cameraBitmap);
            }

            Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    //setSelection(R.drawable.template_select_white, 0);
                    Bitmap bm = Utils.layoutToImage(getViewDataBinding().rlSwitchLayout);
                    ByteArrayOutputStream bytes = new ByteArrayOutputStream();
                    bm.compress(Bitmap.CompressFormat.JPEG, 100, bytes);
                    getViewDataBinding().cameraTheme.setImageBitmap(bm);
                    finalBitmap=bm;

                    try {
                        bytes.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }, 500);


        }
    }

    public void setSelection(int i1, int i2) {
        getViewDataBinding().rlCameraTemplate.setBackgroundResource(i1);
        getViewDataBinding().rlWhiteTemplate.setBackgroundResource(i2);
    }


    public void setDefault() {

        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {

                Bitmap bm = Utils.layoutToImage(getViewDataBinding().rlSwitchLayout);
                ByteArrayOutputStream bytes = new ByteArrayOutputStream();
                bm.compress(Bitmap.CompressFormat.JPEG, 100, bytes);
                finalBitmap = bm;
            }
        }, 500);

    }
    @Override
    public void onDestroy() {
        super.onDestroy();
        if(finalBitmap!=null){
            finalBitmap.recycle();
            finalBitmap=null;
        }
        if(cameraBitmap!=null){
            cameraBitmap.recycle();
            cameraBitmap=null;
        }

    }
}
