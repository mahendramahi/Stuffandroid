package com.truworth.wellnesscorner.ui.mainapp.post;

public class PostConstants {
    //POST type
    public static final int CONTENT_TYPE_TEXT = 0;
    public static final int CONTENT_TYPE_EVENT = 1;
    public static final int CONTENT_TYPE_CHALLENGE = 2;
    public static final int CONTENT_TYPE_CHALLENGE_CHECK_IN = 3;
    public static final int CONTENT_TYPE_POLL = 5;
    public static final int CONTENT_TYPE_RESOURCE = 4;

    //MEDIA TYPE
    public static final int MEDIA_TYPE_IMAGE = 1;
    public static final int MEDIA_TYPE_URL = 2;
    public static final int MEDIA_TYPE_VIDEO = 3;
    public static final int MEDIA_TYPE_YOU_TUBE_VIDEO = 4;

    //POST TAG TYPE
    public static final int POST_TAG_TYPE_CIRCLE = 1;
    public static final int POST_TAG_TYPE_COACH = 2;
    public static final int POST_TAG_TYPE_MEMBER = 3;

}
