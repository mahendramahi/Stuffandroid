/*
 *  Copyright (C) 2017 MINDORKS NEXTGEN PRIVATE LIMITED
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      https://mindorks.com/license/apache-v2
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License
 */

package com.truworth.wellnesscorner.base;

import android.arch.lifecycle.MutableLiveData;
import android.arch.lifecycle.ViewModel;

import com.truworth.wellnesscorner.utils.SingleLiveEvent;

import io.reactivex.disposables.CompositeDisposable;

/**
 * Created by amitshekhar on 07/07/17.
 */

public abstract class BaseViewModel<N> extends ViewModel {

    //  private final DataManager mDataManager;

    // private final ObservableBoolean mIsLoading = new ObservableBoolean(false);
    private final SingleLiveEvent<Boolean> mIsLoading = new SingleLiveEvent<Boolean>();
    //   private final SchedulerProvider mSchedulerProvider;
   // private final SingleLiveEvent<Boolean> mi
    private CompositeDisposable mCompositeDisposable;

    private N mNavigator;

    public BaseViewModel() {
//        this.mDataManager = dataManager;
//        this.mSchedulerProvider = schedulerProvider;
        this.mCompositeDisposable = new CompositeDisposable();
    }

    @Override
    protected void onCleared() {
        mCompositeDisposable.dispose();
        super.onCleared();
    }

    public CompositeDisposable getCompositeDisposable() {
        return mCompositeDisposable;
    }

    //  public DataManager getDataManager() {
//        return mDataManager;
//    }

    public SingleLiveEvent<Boolean> getIsLoading() {
        return mIsLoading;
    }

    public void setIsLoading(Boolean isLoading) {
        mIsLoading.setValue(isLoading);
    }

    public N getNavigator() {
        return mNavigator;
    }

    public void setNavigator(N navigator) {
        this.mNavigator = navigator;
    }

//    //public SchedulerProvider getSchedulerProvider() {
//        return mSchedulerProvider;
//    }
}
