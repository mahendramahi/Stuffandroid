package com.twc.store.model.response;

/**
 * Created by GurvinderS on 5/9/2017.
 */

public class CheckProductAvailbilityResponse {
    private int status;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }
}
