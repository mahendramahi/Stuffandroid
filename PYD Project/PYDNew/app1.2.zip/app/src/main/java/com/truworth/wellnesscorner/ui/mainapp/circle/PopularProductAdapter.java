package com.truworth.wellnesscorner.ui.mainapp.circle;

import android.content.Intent;
import android.databinding.DataBindingUtil;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import com.truworth.wellnesscorner.R;
import com.truworth.wellnesscorner.TheWellnessCornerApp;
import com.truworth.wellnesscorner.data.SharedPreferenceHelper;
import com.truworth.wellnesscorner.databinding.LayoutStoreItemBinding;
import com.truworth.wellnesscorner.model.PopularProduct;
import com.truworth.wellnesscorner.utils.AppConstants;
import com.twc.store.StoreDetailActivity;
import com.twc.store.model.beans.StoreUser;
import com.twc.store.utils.StoreConfig;

import java.util.List;

import javax.inject.Inject;

/**
 * Created by rajeshs on 4/16/2018.
 */

public class PopularProductAdapter extends RecyclerView.Adapter<PopularProductAdapter.ViewHolder> {
    List<PopularProduct> products;
    @Inject
    SharedPreferenceHelper prefHelper;

    public PopularProductAdapter(List<PopularProduct> products) {
        this.products = products;
        //  this.listener = listener;
        TheWellnessCornerApp.getApp().component().inject(this);
    }

    @NonNull
    @Override
    public PopularProductAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutStoreItemBinding binding = DataBindingUtil.inflate(LayoutInflater.from(parent.getContext()), R.layout.layout_store_item, parent, false);
        return new PopularProductAdapter.ViewHolder(binding);
    }


    @Override
    public void onBindViewHolder(@NonNull PopularProductAdapter.ViewHolder holder, int position) {
        holder.bind(products.get(position));
    }


    @Override
    public int getItemCount() {
        return products.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements ProductViewModel.ProductListener {
        private LayoutStoreItemBinding mBinding;

        public ViewHolder(LayoutStoreItemBinding binding) {
            super(binding.getRoot());
            mBinding = binding;
        }

        public void bind(@NonNull PopularProduct product) {
            ProductViewModel viewModel = new ProductViewModel(product,this);

            mBinding.setViewModel(viewModel);
            mBinding.executePendingBindings();
            viewModel.getRating();
        }

        @Override
        public void onItemClick() {
            setRedirection(products.get(getAdapterPosition()).getProductID(), products.get(getAdapterPosition()).getSku());
        }

        private void setRedirection(String productID, String sku) {
            StoreUser storeUser = new StoreUser(prefHelper.getUserName(), "9834989393", prefHelper.getEmailId(), "0", "Male", "Premium",
                    "bearer " + prefHelper.getToken());
            StoreConfig.init("Wellness", AppConstants.API_ENDPOINT,storeUser,true);

            if (!StoreConfig.APP_NAME.isEmpty() && !StoreConfig.BASE_URL.isEmpty() && StoreConfig.storeUser != null) {
                Intent intent = new Intent(itemView.getContext(), StoreDetailActivity.class);
                intent.putExtra("productId", Integer.parseInt(productID));
                intent.putExtra("sku", sku);
                intent.putExtra("tag", "Health Products");
                itemView.getContext().startActivity(intent);
            }
            else{
            }


        }
    }

}
