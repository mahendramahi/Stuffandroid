/*
 *  Copyright (C) 2017 MINDORKS NEXTGEN PRIVATE LIMITED
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      https://mindorks.com/license/apache-v2
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License
 */

package com.truworth.wellnesscorner.base;

import android.app.ProgressDialog;
import android.arch.lifecycle.Observer;
import android.content.Context;
import android.databinding.DataBindingUtil;
import android.databinding.ViewDataBinding;
import android.os.Bundle;
import android.support.annotation.LayoutRes;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.truworth.wellnesscorner.TheWellnessCornerApp;
import com.truworth.wellnesscorner.network.InternetConnectionListener;
import com.truworth.wellnesscorner.utils.CommonUtils;
import com.truworth.wellnesscorner.utils.KeyBoardUtils;
import com.truworth.wellnesscorner.utils.Utils;

/**
 * Created by amitshekhar on 09/07/17.
 */

public abstract class BaseFragment<T extends ViewDataBinding, V extends BaseViewModel> extends Fragment implements InternetConnectionListener {

    // private BaseActivity mActivity;
    private ProgressDialog mProgressDialog;
    private View mRootView;
    private T mViewDataBinding;
    private V mViewModel;
    private boolean isHideKeyboard = true;
//    @Inject
//    SharedPreferenceHelper preferenceHelper;

    /**
     * Override for set binding variable
     *
     * @return variable id
     */
    public abstract int getBindingVariable();

    /**
     * @return layout resource id
     */
    public abstract
    @LayoutRes
    int getLayoutId();

    /**
     * Override for set view model
     *
     * @return view model instance
     */
    public abstract V getViewModel();

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof BaseActivity) {
//            BaseActivity activity = (BaseActivity) context;
//            this.mActivity = activity;
//            activity.onFragmentAttached();
        }
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        // performDependencyInjection();
        super.onCreate(savedInstanceState);
        //TheWellnessCornerApp.getApp().component().inject(this);
        mViewModel = getViewModel();
        setHasOptionsMenu(false);
    }

//    public SharedPreferenceHelper getPreferences() {
//        return preferenceHelper;
//    }

    @Override
    public void onInternetUnavailable() {
        Utils.showToast(getActivity(),"no internet connection");
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mViewDataBinding = DataBindingUtil.inflate(inflater, getLayoutId(), container, false);
        mRootView = mViewDataBinding.getRoot();
        setLoadingObserver();
        TheWellnessCornerApp.getApp().setInternetConnectionListener(this);
        return mRootView;
    }

    @Override
    public void onDetach() {
        //mActivity = null;
        hideKeyboard();
        super.onDetach();

    }

    @Override
    public void onDestroyView() {
        TheWellnessCornerApp.getApp().removeInternetConnectionListener();
        super.onDestroyView();

    }

    public void setKeyboardHideOnTapOutSide(boolean isHide) {
        this.isHideKeyboard = isHide;
    }

    @Override
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        if (isHideKeyboard) {
            KeyBoardUtils.setupUI(getActivity(), mRootView);
        }
        mViewDataBinding.setVariable(getBindingVariable(), mViewModel);
        mViewDataBinding.executePendingBindings();
    }

//    public BaseActivity getBaseActivity() {
//        return mActivity;
//    }

    public T getViewDataBinding() {
        return mViewDataBinding;
    }

    public void hideLoading() {
        if (mProgressDialog != null && mProgressDialog.isShowing()) {
            mProgressDialog.cancel();
        }
    }

    public void showLoading() {
        hideLoading();
        mProgressDialog = CommonUtils.showLoadingDialog(getActivity());
    }

    private void setLoadingObserver() {
        if (mViewModel != null) {
            mViewModel.getIsLoading().observe(this, new Observer() {
                /**
                 * Called when the data is changed.
                 *
                 * @param o The new data
                 */
                @Override
                public void onChanged(@Nullable Object o) {
                    if (((Boolean) o)) {
                        showLoading();
                    } else {
                        hideLoading();
                    }

                }
            });
        }
    }
//    public BaseViewModel getViewModel() {
//        return ViewModelProviders.of(this).get();
//    }

    public void showKeyboard() {
        KeyBoardUtils.openKeyboard(getActivity(), mRootView);
    }

    public void hideKeyboard() {
        KeyBoardUtils.hideSoftKeyboard(mRootView);
    }

//    public boolean isNetworkConnected() {
//        return mActivity != null && mActivity.isNetworkConnected();
//    }

//    public void openActivityOnTokenExpire() {
//        if (mActivity != null) {
//            mActivity.openActivityOnTokenExpire();
//        }
//    }

    // private void performDependencyInjection() {
//        AndroidSupportInjection.inject(this);
//    }

//    public interface Callback {
//
//        void onFragmentAttached();
//
//        void onFragmentDetached(String tag);
//    }
}
