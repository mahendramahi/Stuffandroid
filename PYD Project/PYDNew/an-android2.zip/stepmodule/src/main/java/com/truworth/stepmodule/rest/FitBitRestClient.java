package com.truworth.stepmodule.rest;

import android.content.Context;


/**
 * Created by ManishJ1 on 6/29/2016.
 */
public class FitBitRestClient extends AbstractRestClient {

    public FitBitStepsService fitBitStepsService;
    public FitBitRestClient(String deviceType,String token, Context context, String baseUrl, boolean debug) {
        super(deviceType,token, context, baseUrl, debug);
    }

    @Override
    public void initApi() {
        fitBitStepsService = client.create(FitBitStepsService.class);
    }

    public FitBitStepsService getFitBitStepsService() {
        return fitBitStepsService;
    }

}
