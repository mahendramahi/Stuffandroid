package com.truworth.wellnesscorner.model;

public class MobileInfo {

    String DeviceId;
    String DevicePlatform;
    String RegToken;
    String UsingVersion;

    public String getDeviceId() {
        return DeviceId;
    }

    public void setDeviceId(String deviceId) {
        DeviceId = deviceId;
    }

    public String getDevicePlatform() {
        return DevicePlatform;
    }

    public void setDevicePlatform(String devicePlatform) {
        DevicePlatform = devicePlatform;
    }

    public String getRegToken() {
        return RegToken;
    }

    public void setRegToken(String regToken) {
        RegToken = regToken;
    }

    public String getUsingVersion() {
        return UsingVersion;
    }

    public void setUsingVersion(String usingVersion) {
        UsingVersion = usingVersion;
    }

    public String getIPAddress() {
        return IPAddress;
    }

    public void setIPAddress(String IPAddress) {
        this.IPAddress = IPAddress;
    }

    String IPAddress;
}
