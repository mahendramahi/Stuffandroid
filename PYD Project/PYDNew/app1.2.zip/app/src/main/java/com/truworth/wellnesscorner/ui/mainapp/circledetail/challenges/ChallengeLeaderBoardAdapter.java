package com.truworth.wellnesscorner.ui.mainapp.circledetail.challenges;

import android.content.Context;
import android.databinding.DataBindingUtil;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import com.truworth.wellnesscorner.R;
import com.truworth.wellnesscorner.databinding.RowAllTimeScoreboardBinding;
import com.truworth.wellnesscorner.databinding.RowLoadingProgressBinding;
import com.truworth.wellnesscorner.model.ChallengeLeaderboardBean;

import java.util.List;

public class ChallengeLeaderBoardAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private static final int VIEW_TYPE_ITEM = 1;
    private static final int VIEW_TYPE_PROGRESS = 2;
    private List<ChallengeLeaderboardBean> challengeList;
    private String challengeIdentity;
    private Context context;
    private int challengeTypeId;
    private int myRank;

    public ChallengeLeaderBoardAdapter(Context context, List<ChallengeLeaderboardBean> challengeList, String challengeIdentity, int challengeTypeId, int myRank) {
        this.challengeList = challengeList;
        this.challengeIdentity = challengeIdentity;
        this.context = context;
        this.challengeTypeId = challengeTypeId;
        this.myRank = myRank;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        RecyclerView.ViewHolder viewHolder = null;
        if (viewType == VIEW_TYPE_ITEM) {

            RowAllTimeScoreboardBinding binding = DataBindingUtil.inflate(LayoutInflater.from(parent.getContext()), R.layout.row_all_time_scoreboard, parent, false);
            viewHolder = new ViewHolder(binding);
        } else {
            RowLoadingProgressBinding rowLoadingProgressBinding = DataBindingUtil.inflate(LayoutInflater.from(parent.getContext()), R.layout.row_loading_progress, parent, false);
            viewHolder = new ViewHolderLoading(rowLoadingProgressBinding);
        }
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {

        if (holder.getItemViewType() == VIEW_TYPE_PROGRESS) {
            ViewHolderLoading viewHolderLoading = (ViewHolderLoading) holder;
            viewHolderLoading.rowLoadingProgressBinding.progressBar.setIndeterminate(true);
        } else {
            ViewHolder viewHolder = (ViewHolder) holder;
            viewHolder.bind(challengeList.get(position));
        }
    }

    @Override
    public int getItemViewType(int position) {
        if (challengeList.get(position) == null) {
            return VIEW_TYPE_PROGRESS;
        }
        return VIEW_TYPE_ITEM;
    }

    @Override
    public int getItemCount() {
        return challengeList != null ? challengeList.size() : 0;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private RowAllTimeScoreboardBinding mBinding;

        public ViewHolder(RowAllTimeScoreboardBinding binding) {
            super(binding.getRoot());
            mBinding = binding;
        }

        public void bind(@NonNull ChallengeLeaderboardBean challengeLeaderboardBean) {

            ChallengeLeaderBoardItemViewModel viewModel = new ChallengeLeaderBoardItemViewModel(challengeLeaderboardBean, challengeIdentity, context, challengeTypeId, myRank);

            mBinding.setViewModel(viewModel);
            mBinding.executePendingBindings();
        }
    }

    public class ViewHolderLoading extends RecyclerView.ViewHolder {
        private RowLoadingProgressBinding rowLoadingProgressBinding;

        public ViewHolderLoading(RowLoadingProgressBinding binding) {
            super(binding.getRoot());
            rowLoadingProgressBinding = binding;
        }
    }

    public void updateMyRank(int rank) {
        this.myRank = rank;
        notifyDataSetChanged();
    }
}
