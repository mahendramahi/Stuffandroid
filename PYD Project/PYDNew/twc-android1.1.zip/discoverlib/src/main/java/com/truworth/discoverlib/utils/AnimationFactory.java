package com.truworth.discoverlib.utils;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.view.View;
import android.view.ViewAnimationUtils;
import android.view.animation.AccelerateDecelerateInterpolator;

/**
 * If this code works, it was written by Somesh Kumar  on 09 April, 2018. If not, I don't know who wrote it.
 */
public class AnimationFactory {


    /**
     @param view        View to animate
     @param shouldOpen  true if you want to open the view and false if you want to close the view
     @param cx          point on X axis
     @param cy          point on Y axis
     @param finalRadius radius of view
     */
    public static void circularReveal(final View view, final boolean shouldOpen, int cx, int cy, int finalRadius) {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
            Animator animator;
            animator = shouldOpen ? ViewAnimationUtils.createCircularReveal(view, cx, cy, 0, finalRadius) : ViewAnimationUtils.createCircularReveal(view, cx, cy, finalRadius, 0);
            animator.setInterpolator(new AccelerateDecelerateInterpolator());
            animator.setDuration(200);
            animator.addListener(
                    new AnimatorListenerAdapter() {
                        @Override
                        public void onAnimationStart(Animator animation) {
                            super.onAnimationStart(animation);
                            view.setVisibility(View.VISIBLE);
                        }

                        @Override
                        public void onAnimationEnd(Animator animation) {
                            super.onAnimationEnd(animation);
                            if (!shouldOpen) {
                                view.setVisibility(View.INVISIBLE);
                            }
                        }
                    }

            );
            animator.start();
        } else {
            view.setVisibility(shouldOpen ? View.VISIBLE : View.INVISIBLE);
        }

    }

}
