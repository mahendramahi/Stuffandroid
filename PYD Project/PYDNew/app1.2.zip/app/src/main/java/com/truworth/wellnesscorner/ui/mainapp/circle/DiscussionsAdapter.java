package com.truworth.wellnesscorner.ui.mainapp.circle;

import android.databinding.DataBindingUtil;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.truworth.wellnesscorner.R;
import com.truworth.wellnesscorner.databinding.RowCommunityDiscussionBinding;
import com.truworth.wellnesscorner.model.Discussions;

import java.util.List;

/**
 * Created by PalakC on 4/19/2018.
 */

public class DiscussionsAdapter extends RecyclerView.Adapter<DiscussionsAdapter.ViewHolder> {
    List<Discussions> discussionsList;

    public DiscussionsAdapter(List<Discussions> discussionsList) {
        this.discussionsList = discussionsList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        RowCommunityDiscussionBinding binding = DataBindingUtil.inflate(LayoutInflater.from(parent.getContext()), R.layout.row_community_discussion, parent, false);
        return new ViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.bind(discussionsList.get(position));
    }

    @Override
    public int getItemCount() {
        return discussionsList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private RowCommunityDiscussionBinding mBinding;

        public ViewHolder(RowCommunityDiscussionBinding binding) {
            super(binding.getRoot());
            mBinding = binding;

           /* mBinding.tvReadMore.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(mBinding.tvReadMore.getText().toString().equalsIgnoreCase("Read More")) {
                     *//*   Animation slide1 = AnimationUtils.loadAnimation(view.getContext(), R.anim.expand);
                        mBinding.webViewAnswer.startAnimation(slide1);*//*
                        mBinding.webViewAnswer.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
                        mBinding.tvReadMore.setText("Read Less");
                    }else {
                      *//*  Animation slide1 = AnimationUtils.loadAnimation(view.getContext(), R.anim.colleps);
                        mBinding.webViewAnswer.startAnimation(slide1);*//*
                        mBinding.webViewAnswer.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 250));
                        mBinding.tvReadMore.setText("Read More");
                    }

                }
            });*/
        }

        public void bind(@NonNull Discussions discussions) {

            DiscussionsItemViewModel viewModel = new DiscussionsItemViewModel(discussions);
            mBinding.setViewModel(viewModel);
            mBinding.executePendingBindings();

            if (viewModel.discussions.getAnswerID() == 0) {
                mBinding.answeredLayout.setVisibility(View.GONE);
                mBinding.webViewLayout.setVisibility(View.GONE);
                mBinding.unAnsweredLayout.setVisibility(View.VISIBLE);
            }
            if (discussions.getAnswer().length() > 300)
                mBinding.tvReadMore.setVisibility(View.VISIBLE);
        }
    }

}
