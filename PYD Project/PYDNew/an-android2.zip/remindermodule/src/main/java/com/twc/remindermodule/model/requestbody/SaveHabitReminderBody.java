package com.twc.remindermodule.model.requestbody;

import java.util.List;

/**
 * Created by GurvinderS on 9/21/2017.
 */

public class SaveHabitReminderBody {


    private List<HabitItem> data;

    public List<HabitItem> getData() {
        return data;
    }

    public void setData(List<HabitItem> data) {
        this.data = data;
    }

    public static class HabitItem {
        /**
         * MemberId : 240095
         * HabitID : 6
         * ReminderName : Sleep at least 7 hours everyday
         * ReminderText : Try to stay away from all your screens and prepare yourself for a healthy 7 hour sleep
         * Times : [{"IsRemoved":0,"Time":"09:02 AM"}]
         */

        private String MemberId;
        private String HabitID;
        private String ReminderName;
        private String ReminderText;
        private List<TimesBean> Times;

        public String getMemberId() {
            return MemberId;
        }

        public void setMemberId(String MemberId) {
            this.MemberId = MemberId;
        }

        public String getHabitID() {
            return HabitID;
        }

        public void setHabitID(String HabitID) {
            this.HabitID = HabitID;
        }

        public String getReminderName() {
            return ReminderName;
        }

        public void setReminderName(String ReminderName) {
            this.ReminderName = ReminderName;
        }

        public String getReminderText() {
            return ReminderText;
        }

        public void setReminderText(String ReminderText) {
            this.ReminderText = ReminderText;
        }

        public List<TimesBean> getTimes() {
            return Times;
        }

        public void setTimes(List<TimesBean> Times) {
            this.Times = Times;
        }

        public static class TimesBean {
            /**
             * IsRemoved : 0
             * Time : 09:02 AM
             */

            private int IsRemoved;
            private String Time;

            public int getIsRemoved() {
                return IsRemoved;
            }

            public void setIsRemoved(int IsRemoved) {
                this.IsRemoved = IsRemoved;
            }

            public String getTime() {
                return Time;
            }

            public void setTime(String Time) {
                this.Time = Time;
            }
        }
    }
}
