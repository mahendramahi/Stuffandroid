package com.truworth.wellnesscorner.ui.mainapp.post.postcomment;

import android.app.Activity;
import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Intent;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;

import com.truworth.wellnesscorner.R;
import com.truworth.wellnesscorner.databinding.ActivityCommentBinding;
import com.truworth.wellnesscorner.interfaces.OnPostItemClickListener;
import com.truworth.wellnesscorner.model.CommentListData;
import com.truworth.wellnesscorner.model.Post;
import com.truworth.wellnesscorner.model.ViewPreviousItem;
import com.truworth.wellnesscorner.ui.mainapp.post.PostRecyclerAdapter;
import com.truworth.wellnesscorner.ui.mainapp.post.IPostListItem;
import com.truworth.wellnesscorner.utils.Utils;

import java.util.ArrayList;
import java.util.List;

public class PostCommentActivity extends AppCompatActivity implements OnPostItemClickListener {
    public static int OPEN_FOR_COMMENT_VIEW = 2;
    public static int OPEN_FOR_COMMENT_WRITE = 3;
    public static String OPEN_FOR = "openfor";
    public static String POST = "post";
    public static String INDEX = "index";
    public static int REQUEST_CODE = 1;
    private static int openFor;
    ActivityCommentBinding binding;
    PostCommentViewModel viewModel;
    private List<IPostListItem> commentList;
    private PostRecyclerAdapter adapter;
    private int page = 1;
    private Post post;
    private ViewPreviousItem viewPreviousItem;
    private int position;
    private boolean isfirstLoad = false;
    private LinearLayoutManager linearLayoutManager;
    private Handler handler = new Handler();
    private Runnable runnableApiCall = new Runnable() {
        @Override
        public void run() {
            adapter.notifyDataSetChanged();
            viewModel.getCommentList(page);
        }
    };

    public static void setComment(int openForComment) {
        openFor = openForComment;
    }

    public static void start(Activity activity, Post post, int index, int openFor) {
        Intent intent = new Intent(activity, PostCommentActivity.class);
        intent.putExtra(POST, post);
        intent.putExtra(INDEX, index);
        intent.putExtra(OPEN_FOR, openFor);
        activity.startActivityForResult(intent, REQUEST_CODE);
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_comment);
        Toolbar toolbar = binding.commentToolbar;
        setupToolbar(toolbar);
        viewPreviousItem = new ViewPreviousItem();

        viewModel = ViewModelProviders.of(this).get(PostCommentViewModel.class);
        binding.setViewModel(viewModel);
        Intent intent = getIntent();

        if (intent != null) {
            post = (Post) getIntent().getSerializableExtra(POST);
            position = getIntent().getIntExtra(INDEX, 0);
            openFor = getIntent().getIntExtra(OPEN_FOR, 3);
        }
        if (openFor == OPEN_FOR_COMMENT_VIEW) {
            binding.etComment.setFocusable(false);
            binding.etComment.setFocusableInTouchMode(true);
        } else {
            binding.etComment.requestFocus();
        }
        commentList = new ArrayList<>();
        commentList.add(post);
        commentList.add(viewPreviousItem);
        adapter = new PostRecyclerAdapter(this, this::onItemClick, commentList, post.getPostMapIdentity(), post.getPostCreatedByName());

        toolbar.setTitle(post.getPostCreatedByName() + "'s Post");

        linearLayoutManager = new LinearLayoutManager(this);
        binding.rvComments.setLayoutManager(linearLayoutManager);
        binding.rvComments.setAdapter(adapter);

        viewModel.setPost(post);
        setDataObserver();

        handler.postDelayed(runnableApiCall, 50);
    }

    private void setupToolbar(Toolbar toolbar) {
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
            getSupportActionBar().setDisplayShowTitleEnabled(false);
        }
    }

    private void setDataObserver() {
        viewModel.getCommentListData().observe(this, new Observer<List<CommentListData>>() {
            @Override
            public void onChanged(@Nullable List<CommentListData> commentListData) {
                if (commentListData != null) {

                    if (!isfirstLoad) {
                        isfirstLoad = false;
                        commentList.subList(2,commentList.size()).clear();
                        commentList.addAll(commentListData);
                        if (commentList.size()-2 >= (10 * page)) {
                            viewPreviousItem.setVisible(true);
                            commentList.set(1, viewPreviousItem);
                        } else {
                            viewPreviousItem.setVisible(false);
                        }
                    } else {
                        for (int i = commentListData.size() - 1; i >= 0; i--) {
                            CommentListData obj = commentListData.get(i);
                            commentList.add(2, obj);
                        }
                        if (commentList.size()-2 > (10 * page)) {
                            viewPreviousItem.setVisible(true);
                            commentList.set(1, viewPreviousItem);
                        } else {
                            viewPreviousItem.setVisible(false);
                        }

                    }
                    adapter.notifyDataSetChanged();
                }
            }
        });

        viewModel.getSaveComment().observe(this, new Observer<Integer>() {
            @Override
            public void onChanged(@Nullable Integer cout) {

                post.setPostTotalComments(cout);
                adapter.notifyItemChanged(0);
                Utils.hideSoftKeyboard(PostCommentActivity.this);
                setScrollToBottom();
            }
        });
    }

    public void setScrollToBottom() {
//        int targetScroll = linearLayoutManager.getHeight();//nestedScrollView.getScrollY() + 150;
        binding.rvComments.scrollToPosition(commentList.size()-1);
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_activity_circle_detail, menu);
        return true;
    }


    @Override
    public void onBackPressed() {
        Intent returnIntent = new Intent();
        returnIntent.putExtra(INDEX, position);
        returnIntent.putExtra(POST, post);
        setResult(Activity.RESULT_OK, returnIntent);
        Utils.hideSoftKeyboard(this);
        //onBackPressed();
        finish();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();

        if (commentList != null) {
            commentList.clear();
            adapter.notifyDataSetChanged();
            adapter = null;
            commentList = null;
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PostCommentActivity.REQUEST_CODE) {
            int position = data.getIntExtra(PostCommentActivity.INDEX, 0);
            Post post = (Post) data.getSerializableExtra(PostCommentActivity.POST);
            commentList.remove(position);
            commentList.add(position, post);
            adapter.notifyItemChanged(position);
        }
    }


    @Override
    public void onItemClick(ViewPreviousItem previousItem, int position) {
        this.viewPreviousItem = previousItem;
        isfirstLoad = true;
        page += 1;
        viewModel.getCommentList(page);
    }
}
