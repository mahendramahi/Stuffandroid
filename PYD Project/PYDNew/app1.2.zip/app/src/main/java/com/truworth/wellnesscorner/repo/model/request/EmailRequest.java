package com.truworth.wellnesscorner.repo.model.request;

/**
 * Created by rajeshs on 3/29/2018.
 */

public class EmailRequest {
    String Email;

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }
}
