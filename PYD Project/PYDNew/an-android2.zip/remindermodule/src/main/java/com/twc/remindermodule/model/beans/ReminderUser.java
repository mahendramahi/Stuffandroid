package com.twc.remindermodule.model.beans;

/**
 * Created by ManishJ1 on 3/20/2018.
 */

public class ReminderUser {

    private String userID;
    private String accessToken;
    private boolean isNotify;

    public ReminderUser() {

    }

    public ReminderUser(String userID,boolean isNotify, String accessToken) {
        this.userID = userID;
        this.isNotify = isNotify;
        this.accessToken = accessToken;
    }

    public String getAccessToken() {
        return accessToken;
    }

    public void setAccessToken(String accessToken) {
        this.accessToken = accessToken;
    }

    public String getUserID() {
        return userID;
    }

    public void setUserID(String userID) {
        this.userID = userID;
    }

    public boolean isNotify() {
        return isNotify;
    }

    public void setNotify(boolean notify) {
        isNotify = notify;
    }
}
