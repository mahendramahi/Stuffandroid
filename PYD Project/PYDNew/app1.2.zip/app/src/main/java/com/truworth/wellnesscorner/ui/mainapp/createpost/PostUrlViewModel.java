package com.truworth.wellnesscorner.ui.mainapp.createpost;

import android.databinding.ObservableBoolean;

import com.truworth.wellnesscorner.base.BaseViewModel;
import com.truworth.wellnesscorner.model.PostMediaData;
import com.truworth.wellnesscorner.repo.model.request.PostMediaTypeDataRequest;
import com.truworth.wellnesscorner.utils.AppConstants;

public class PostUrlViewModel extends BaseViewModel {
    public PostMediaTypeDataRequest postUrl = new PostMediaTypeDataRequest();
    public ObservableBoolean isVisible = new ObservableBoolean();

    public PostUrlViewModel(PostMediaData urlData, boolean forReleasePreviewArea) {

        postUrl.setMediaType(AppConstants.MEDIA_TYPE_URL);
        postUrl.setData(urlData.getUrl());
        postUrl.setDesc(urlData.getDesc());
        postUrl.setTitle(urlData.getTitle());
        postUrl.setFileName(urlData.getFileName());
        isVisible.set(forReleasePreviewArea);
    }

}
