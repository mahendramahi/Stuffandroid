package com.twc.hramodule.fragments;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import com.twc.greendaolib.GreenDaoApp;
import com.twc.greendaolib.HraDBItem;
import com.twc.greendaolib.HraDBItemDao;
import com.twc.hramodule.HraActivity;
import com.twc.hramodule.R;
import com.twc.hramodule.R2;
import com.twc.hramodule.interfaces.OnHraDbAction;
import com.twc.hramodule.model.beans.HraItem;
import com.twc.hramodule.utils.Utils;
import com.twc.hramodule.views.CustomTextView;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;

/**
 * If this code works it was written by Somesh Kumar on 13 October, 2016. If not, I don't know who wrote it.
 */
public class HraQ29Fragment extends BaseFragment {

    private static final int QUESTION_ID = 33;
    private static final String SCREEN_NO = "24";

    @BindView(R2.id.tvQuestionTitleFirst)
    CustomTextView tvQuestionTitleFirst;

    @BindView(R2.id.tvQuestionNoFirst)
    CustomTextView tvQuestionNoFirst;

    @BindView(R2.id.tvQuestionTypeFirst)
    CustomTextView tvQuestionTypeFirst;

    @BindView(R2.id.btnNextQuestion)
    Button btnNextQuestion;
    @BindView(R2.id.ivHRABack)
    ImageView ivHRABack;

    @BindView(R2.id.ivCancelHRA)
    ImageView ivCancelHRA;

    @BindView(R2.id.rbYes)
    RadioButton rbYes;

    @BindView(R2.id.rbNo)
    RadioButton rbNo;

    @BindView(R2.id.rgYesNo)
    RadioGroup rgYesNo;

    private List<HraItem> firstAnswerList;
    private OnHraDbAction onHraDbAction;

    public static HraQ29Fragment newInstance(Bundle bundle) {
        HraQ29Fragment fragment = new HraQ29Fragment();
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        onHraDbAction = (OnHraDbAction) context;
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        onHraDbAction = (OnHraDbAction) activity;
    }

    @Override
    public void onResume() {
        super.onResume();

        getView().setFocusableInTouchMode(true);
        getView().requestFocus();
        getView().setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (keyCode == KeyEvent.KEYCODE_BACK && event.getAction() == KeyEvent.ACTION_DOWN) {
                    onBack();
                    return true;
                }
                return false;
            }
        });

    }

    @Override
    public int getFragmentLayout() {
        return R.layout.fragment_hra_type6;
    }

    @Override
    public void onFragmentReady() {
        firstAnswerList = new ArrayList<>();
        setFirstQuestion();

        // get previous selected answer from database
        String answer;
        HraDBItemDao hraDBDao = GreenDaoApp.getInstance(getActivity()).getDaoSession(getActivity()).getHraDBItemDao();
        List<HraDBItem> answerFromDb = hraDBDao.queryBuilder().where(HraDBItemDao.Properties.QuestionId.eq(QUESTION_ID)).list();

        for (HraDBItem hraDBItem : answerFromDb) {
            answer = hraDBItem.getAnswer();
            if (answer.equalsIgnoreCase("123")) {
                rbYes.setChecked(true);
            } else if (answer.equalsIgnoreCase("124")) {
                rbNo.setChecked(true);
            }
        }
    }


    private void setFirstQuestion() {
        String[] hraQuestion = getActivity().getResources().getStringArray(R.array.hra_questions);
        String[] hraAnswer = getActivity().getResources().getStringArray(R.array.hra_que33_row);
        setFirstHraQuestion(hraQuestion[34], hraAnswer);
    }

    private void setFirstHraQuestion(String question, String[] hraAnswer) {
        tvQuestionTypeFirst.setText("LIFESTYLE");
        tvQuestionNoFirst.setText("29");
        tvQuestionTitleFirst.setText(question);

        for (String ans : hraAnswer) {
            String[] splitArray = ans.split("~");
            String id = splitArray[0];
            String name = splitArray[1];
            HraItem item = new HraItem();
            item.setQuestionID(QUESTION_ID);
            item.setAnswerID(id);
            item.setAnswer(name);
            item.setScreenNo(SCREEN_NO);
            firstAnswerList.add(item);
        }
    }


    @OnClick({R2.id.btnNextQuestion, R2.id.ivCancelHRA, R2.id.ivHRABack})
    public void onClick(View view) {
        int i = view.getId();
        if (i == R.id.ivHRABack) {
            onBack();

        } else if (i == R.id.ivCancelHRA) {
            cancelHra();

        } else if (i == R.id.btnNextQuestion) {
            String answerId;
            int i1 = rgYesNo.getCheckedRadioButtonId();
            if (i1 == R.id.rbYes) {
                answerId = firstAnswerList.get(0).getAnswerID();

            } else if (i1 == R.id.rbNo) {
                answerId = firstAnswerList.get(1).getAnswerID();

            } else {
                answerId = "";

            }
            if (!answerId.isEmpty()) {
                onHraDbAction.onHraQuestionSave(QUESTION_ID, answerId, SCREEN_NO, 0);
            } else {
                Utils.showToast(getActivity(), getString(R.string.pls_select_an_answer));
                return;
            }

            Utils.replaceFragment(getFragmentManager(), HraQ30Fragment.newInstance(getArguments()), HraQ30Fragment.class.getSimpleName(), true, R.id.fragmentContainerHra);

        }
    }

    private void onBack() {
        Utils.replaceFragmentHraBackAnimation(getFragmentManager(), HraQ27And28Fragment.newInstance(getArguments()), HraQ27And28Fragment.class.getSimpleName(), true, R.id.fragmentContainerHra);
    }

    private void cancelHra() {
        // if isRetakeTest parameter is true, then user always came here from hra report
        if (getArguments().containsKey("isRetakeTest") && getArguments().getBoolean("isRetakeTest")) {
            getFragmentManager().popBackStackImmediate(HraRiskGradeFragment.class.getSimpleName(), 0);
        } else {
            getActivity().finish();
        }
    }
}
