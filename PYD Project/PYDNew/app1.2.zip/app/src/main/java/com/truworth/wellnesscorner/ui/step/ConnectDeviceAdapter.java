
package com.truworth.wellnesscorner.ui.step;

import android.app.Activity;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.truworth.wellnesscorner.R;

import com.truworth.wellnesscorner.TheWellnessCornerApp;
import com.truworth.wellnesscorner.data.SharedPreferenceHelper;
import com.truworth.wellnesscorner.utils.AppConstants;
import com.truworth.wellnesscorner.utils.CommonUtils;
import com.truworth.wellnesscorner.utils.Utils;


import java.util.List;

import javax.inject.Inject;


public class ConnectDeviceAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    @Inject
    SharedPreferenceHelper prefHelper;


    private List<ConnectDeviceItem> mConnectDeviceArrayList;
    private Activity mActivity;
    private boolean isRedirectFromRecommendation;


    public ConnectDeviceAdapter(List<ConnectDeviceItem> mItemArrayList, boolean isRedirectFromRecommendation, Activity activity) {
        this.mConnectDeviceArrayList = mItemArrayList;
        this.mActivity = activity;
        this.isRedirectFromRecommendation = isRedirectFromRecommendation;
        TheWellnessCornerApp.getApp().component().inject(this);
    }


    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_connect_devises, parent, false);

        return new ItemViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        ItemViewHolder itemViewHolder = (ItemViewHolder) holder;
        itemViewHolder.tvName.setText(mConnectDeviceArrayList.get(position).getDeviceName());
        String connectedDevice = prefHelper.getPrefKeyDeviceConnected();
        if (position == 0 && connectedDevice.equalsIgnoreCase(AppConstants.E_FIT)) {
            itemViewHolder.tvConnectedType.setVisibility(View.VISIBLE);
        } else if (position == 1 && connectedDevice.equalsIgnoreCase(AppConstants.FITBIT)) {
            itemViewHolder.tvConnectedType.setVisibility(View.VISIBLE);
        } else if (position == 2 && connectedDevice.equalsIgnoreCase(AppConstants.S_HEALTH)) {
            itemViewHolder.tvConnectedType.setVisibility(View.VISIBLE);
        } else if (position == 3 && connectedDevice.equalsIgnoreCase(AppConstants.GOOGLE_FIT)) {
            itemViewHolder.tvConnectedType.setVisibility(View.VISIBLE);
        } else if (position == 4 && connectedDevice.equalsIgnoreCase(AppConstants.MISFIT)) {
            itemViewHolder.tvConnectedType.setVisibility(View.VISIBLE);
        } else if (position == 5 && connectedDevice.equalsIgnoreCase(AppConstants.GARMIN)) {
            itemViewHolder.tvConnectedType.setVisibility(View.VISIBLE);
        } else {
            itemViewHolder.tvConnectedType.setVisibility(View.GONE);
        }

        itemViewHolder.img.setImageResource(mConnectDeviceArrayList.get(position).getDeviceIcon());
    }

    @Override
    public int getItemCount() {
        return (null != mConnectDeviceArrayList ? mConnectDeviceArrayList.size() : 0);
    }

    private boolean checkIfAlreadyConnectedForRecommendation() {

    /*   if (WellnessCornerApp.getPreferenceManager().getTWCVersion().equalsIgnoreCase(TWCVersion.LITE.toString())) {
            CommonUtils.showAlertDialog(mActivity, null, 0, "You are already connected", mActivity.getString(R.string.str_ok), false);
            return true;
        } else if (isRedirectFromRecommendation) {
            CommonUtils.showAlertDialog(mActivity, null, 0, "You are already connected", mActivity.getString(R.string.str_ok), false);
            return true;
        }*/

        return false;
    }

    public class ItemViewHolder extends RecyclerView.ViewHolder {

        final TextView tvName;
        ImageView img;
        TextView tvConnectedType;

        public ItemViewHolder(View itemView) {
            super(itemView);
            tvName = itemView.findViewById(R.id.tvDeviceName);
            img = itemView.findViewById(R.id.imgDeviceIcon);
            tvConnectedType = itemView.findViewById(R.id.tvConnectedType);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String connectedDevice = prefHelper.getPrefKeyDeviceConnected();
                    StepsTrackerFragment stepsTrackerFragment = (StepsTrackerFragment) mActivity.getFragmentManager().findFragmentByTag(StepsTrackerFragment.class.getSimpleName());
                    if (stepsTrackerFragment == null) {
                        stepsTrackerFragment = StepsTrackerFragment.newInstance();
                    }
                    Bundle bundle = new Bundle();
                    bundle.putBoolean("isRedirectFromRecommendation", isRedirectFromRecommendation);
                    if (mConnectDeviceArrayList.get(getLayoutPosition()).getDeviceName().equalsIgnoreCase(AppConstants.FITBIT)) {
                        if (connectedDevice.equalsIgnoreCase(AppConstants.FITBIT)) {
                            if (checkIfAlreadyConnectedForRecommendation()) {
                                return;
                            }
                            stepsTrackerFragment.setConnectedDeviceType(AppConstants.FITBIT);
                            Utils.replaceFragment(mActivity.getFragmentManager(), stepsTrackerFragment, StepsTrackerFragment.class.getSimpleName(), true, R.id.fragmentContainer);
                        } else {
                            bundle.putString(AppConstants.BUNDLE_KEY_DEVICE_NAME, mConnectDeviceArrayList.get(getAdapterPosition()).getDeviceName());
                            Utils.replaceFragment(mActivity.getFragmentManager(), ConnectDeviceDetailFragment.newInstance(bundle), ConnectDeviceDetailFragment.class.getSimpleName(), true, R.id.fragmentContainer);
                        }
                    } else if (mConnectDeviceArrayList.get(getLayoutPosition()).getDeviceName().equalsIgnoreCase(AppConstants.S_HEALTH)) {
                        if (connectedDevice.equalsIgnoreCase(AppConstants.S_HEALTH)) {
                            if (checkIfAlreadyConnectedForRecommendation()) {
                                return;
                            }
                            stepsTrackerFragment.setConnectedDeviceType(AppConstants.S_HEALTH);
                            Utils.replaceFragment(mActivity.getFragmentManager(), stepsTrackerFragment, StepsTrackerFragment.class.getSimpleName(), true, R.id.fragmentContainer);
                        } else {
                            bundle.putString(AppConstants.BUNDLE_KEY_DEVICE_NAME, mConnectDeviceArrayList.get(getAdapterPosition()).getDeviceName());
                            Utils.replaceFragment(mActivity.getFragmentManager(), ConnectDeviceDetailFragment.newInstance(bundle), ConnectDeviceDetailFragment.class.getSimpleName(), true, R.id.fragmentContainer);
                        }
                    } else if (mConnectDeviceArrayList.get(getLayoutPosition()).getDeviceName().equalsIgnoreCase(AppConstants.GOOGLE_FIT)) {
                        if (connectedDevice.equalsIgnoreCase(AppConstants.GOOGLE_FIT)) {
                            if (checkIfAlreadyConnectedForRecommendation()) {
                                return;
                            }
                            stepsTrackerFragment.setConnectedDeviceType(AppConstants.GOOGLE_FIT);
                            Utils.replaceFragment(mActivity.getFragmentManager(), stepsTrackerFragment, StepsTrackerFragment.class.getSimpleName(), true, R.id.fragmentContainer);
                        } else {
                            bundle.putString(AppConstants.BUNDLE_KEY_DEVICE_NAME, mConnectDeviceArrayList.get(getAdapterPosition()).getDeviceName());
                            Utils.replaceFragment(mActivity.getFragmentManager(), ConnectDeviceDetailFragment.newInstance(bundle), ConnectDeviceDetailFragment.class.getSimpleName(), true, R.id.fragmentContainer);
                        }
                    } else if (mConnectDeviceArrayList.get(getLayoutPosition()).getDeviceName().equalsIgnoreCase(AppConstants.E_FIT)) {
                        if (connectedDevice.equalsIgnoreCase(AppConstants.E_FIT)) {
                            if (checkIfAlreadyConnectedForRecommendation()) {
                                return;
                            }
                            stepsTrackerFragment.setConnectedDeviceType(AppConstants.E_FIT);
                            Utils.replaceFragment(mActivity.getFragmentManager(), stepsTrackerFragment, StepsTrackerFragment.class.getSimpleName(), true, R.id.fragmentContainer);
                        } else {
                            bundle.putString(AppConstants.BUNDLE_KEY_DEVICE_NAME, mConnectDeviceArrayList.get(getAdapterPosition()).getDeviceName());
                            Utils.replaceFragment(mActivity.getFragmentManager(), ConnectDeviceDetailFragment.newInstance(bundle), ConnectDeviceDetailFragment.class.getSimpleName(), true, R.id.fragmentContainer);
                        }
                    } else if (mConnectDeviceArrayList.get(getLayoutPosition()).getDeviceName().equalsIgnoreCase(AppConstants.MISFIT)) {
                        if (connectedDevice.equalsIgnoreCase(AppConstants.MISFIT)) {
                            if (checkIfAlreadyConnectedForRecommendation()) {
                                return;
                            }
                            stepsTrackerFragment.setConnectedDeviceType(AppConstants.MISFIT);
                            Utils.replaceFragment(mActivity.getFragmentManager(), stepsTrackerFragment, StepsTrackerFragment.class.getSimpleName(), true, R.id.fragmentContainer);
                        } else {
                            bundle.putString(AppConstants.BUNDLE_KEY_DEVICE_NAME, mConnectDeviceArrayList.get(getAdapterPosition()).getDeviceName());
                            Utils.replaceFragment(mActivity.getFragmentManager(), ConnectDeviceDetailFragment.newInstance(bundle), ConnectDeviceDetailFragment.class.getSimpleName(), true, R.id.fragmentContainer);
                        }
                    } else if (mConnectDeviceArrayList.get(getLayoutPosition()).getDeviceName().equalsIgnoreCase(AppConstants.GARMIN)) {
                        if (connectedDevice.equalsIgnoreCase(AppConstants.GARMIN)) {
                            if (checkIfAlreadyConnectedForRecommendation()) {
                                return;
                            }
                            stepsTrackerFragment.setConnectedDeviceType(AppConstants.GARMIN);
                            Utils.replaceFragment(mActivity.getFragmentManager(), stepsTrackerFragment, StepsTrackerFragment.class.getSimpleName(), true, R.id.fragmentContainer);
                        } else {
                            bundle.putString(AppConstants.BUNDLE_KEY_DEVICE_NAME, mConnectDeviceArrayList.get(getAdapterPosition()).getDeviceName());
                            Utils.replaceFragment(mActivity.getFragmentManager(), ConnectDeviceDetailFragment.newInstance(bundle), ConnectDeviceDetailFragment.class.getSimpleName(), true, R.id.fragmentContainer);
                        }
                    } else {
                        bundle.putString(AppConstants.BUNDLE_KEY_DEVICE_NAME, mConnectDeviceArrayList.get(getAdapterPosition()).getDeviceName());
                        Utils.replaceFragment(mActivity.getFragmentManager(), ConnectDeviceDetailFragment.newInstance(bundle), ConnectDeviceDetailFragment.class.getSimpleName(), true, R.id.fragmentContainer);
                    }
                }
            });
        }


    }
}


