package com.truworth.wellnesscorner.ui.step;

public class MainStepConfig {

    public static String APP_NAME;
    public static String BASE_URL;
    public static boolean mdebug;
    public static StepUser stepUser;


    public static void init(String name, String url, StepUser user, boolean debug) {
        APP_NAME = name;
        BASE_URL = url;
        stepUser = user;
        mdebug = debug;

    }
}
