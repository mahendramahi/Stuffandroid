package com.twc.store.model.requestbody;

/**
 * Created by GurvinderS on 5/12/2017.
 */

public class UpdateProductTransactionBody {


    private String TransactionID;
    private String TransactionStatus;
    private String TransactionDetails;
    private String APIStoreName;
    private String Category;
    private String ProductName;
    private int ProductID;
    private int APIStoreID;
    private double price;
    private String MemberID;
    private int Quantity;

    public String getTransactionID() {
        return TransactionID;
    }

    public void setTransactionID(String transactionID) {
        TransactionID = transactionID;
    }

    public String getTransactionStatus() {
        return TransactionStatus;
    }

    public void setTransactionStatus(String transactionStatus) {
        TransactionStatus = transactionStatus;
    }

    public String getTransactionDetails() {
        return TransactionDetails;
    }

    public void setTransactionDetails(String transactionDetails) {
        TransactionDetails = transactionDetails;
    }

    public String getAPIStoreName() {
        return APIStoreName;
    }

    public void setAPIStoreName(String APIStoreName) {
        this.APIStoreName = APIStoreName;
    }

    public String getCategory() {
        return Category;
    }

    public void setCategory(String category) {
        Category = category;
    }

    public String getProductName() {
        return ProductName;
    }

    public void setProductName(String productName) {
        ProductName = productName;
    }

    public int getProductID() {
        return ProductID;
    }

    public void setProductID(int productID) {
        ProductID = productID;
    }

    public int getAPIStoreID() {
        return APIStoreID;
    }

    public void setAPIStoreID(int APIStoreID) {
        this.APIStoreID = APIStoreID;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getMemberID() {
        return MemberID;
    }

    public void setMemberID(String memberID) {
        MemberID = memberID;
    }

    public int getQuantity() {
        return Quantity;
    }

    public void setQuantity(int quantity) {
        Quantity = quantity;
    }

}
