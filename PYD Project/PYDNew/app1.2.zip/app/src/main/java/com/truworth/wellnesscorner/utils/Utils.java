package com.truworth.wellnesscorner.utils;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Fragment;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.provider.MediaStore;
import android.support.design.widget.Snackbar;
import android.support.design.widget.TabLayout;
import android.support.v4.content.ContextCompat;
import android.text.Html;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.style.RelativeSizeSpan;
import android.text.style.StyleSpan;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.amulyakhare.textdrawable.TextDrawable;
import com.amulyakhare.textdrawable.util.ColorGenerator;
import com.karumi.dexter.Dexter;
import com.karumi.dexter.MultiplePermissionsReport;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.multi.MultiplePermissionsListener;
import com.truworth.wellnesscorner.R;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.NumberFormat;
import java.text.DecimalFormat;
import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;

import static com.truworth.wellnesscorner.ui.registration.registrationstepfourth.LocationDetectFragment.TAG;

/**
 * Created by rajeshs on 4/12/2018.
 */

public class Utils {
    public static void wrapTabIndicatorToTitle(TabLayout tabLayout, int externalMargin, int internalMargin) {
        View tabStrip = tabLayout.getChildAt(0);
        if (tabStrip instanceof ViewGroup) {
            ViewGroup tabStripGroup = (ViewGroup) tabStrip;
            int childCount = ((ViewGroup) tabStrip).getChildCount();
            for (int i = 0; i < childCount; i++) {
                View tabView = tabStripGroup.getChildAt(i);
                //set minimum width to 0 for instead for small texts, indicator is not wrapped as expected
                tabView.setMinimumWidth(0);
                // set padding to 0 for wrapping indicator as title
                tabView.setPadding(0, tabView.getPaddingTop(), 0, tabView.getPaddingBottom());
                // setting custom margin between tabs
                if (tabView.getLayoutParams() instanceof ViewGroup.MarginLayoutParams) {
                    ViewGroup.MarginLayoutParams layoutParams = (ViewGroup.MarginLayoutParams) tabView.getLayoutParams();
                    if (i == 0) {
                        // left
                        settingMargin(layoutParams, externalMargin, internalMargin);
                    } else if (i == childCount - 1) {
                        // right
                        settingMargin(layoutParams, internalMargin, externalMargin);
                    } else {
                        // internal
                        settingMargin(layoutParams, internalMargin, internalMargin);
                    }
                }
            }

            tabLayout.requestLayout();
        }
    }

    private static void settingMargin(ViewGroup.MarginLayoutParams layoutParams, int start, int end) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
            layoutParams.setMarginStart(start);
            layoutParams.setMarginEnd(end);
        } else {
            layoutParams.leftMargin = start;
            layoutParams.rightMargin = end;
        }
    }

    public static void showToast(final Activity activity, final String msg) {
        activity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(activity, msg, Toast.LENGTH_LONG).show();
            }
        });
    }

    public static void reduceMarginsInTabs(TabLayout tabLayout, int marginOffset) {

        View tabStrip = tabLayout.getChildAt(0);
        if (tabStrip instanceof ViewGroup) {
            ViewGroup tabStripGroup = (ViewGroup) tabStrip;
            for (int i = 0; i < ((ViewGroup) tabStrip).getChildCount(); i++) {
                View tabView = tabStripGroup.getChildAt(i);
                if (tabView.getLayoutParams() instanceof ViewGroup.MarginLayoutParams) {
                    ((ViewGroup.MarginLayoutParams) tabView.getLayoutParams()).leftMargin = marginOffset;
                    ((ViewGroup.MarginLayoutParams) tabView.getLayoutParams()).rightMargin = marginOffset;
                }
            }

            tabLayout.requestLayout();
        }
    }

    @SuppressWarnings("deprecation")
    public static Spanned fromHtml(String html) {
        Spanned result;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
            result = Html.fromHtml(html, Html.FROM_HTML_MODE_LEGACY);
        } else {
            result = Html.fromHtml(html);
        }
        return result;
    }

    public static TextDrawable getFirstLetterDrawable(String text, ImageView imageView, Context context) {
        ColorGenerator generator = ColorGenerator.MATERIAL;
        TextDrawable drawable = null;
        if (text == null || text.isEmpty()) {
            Drawable myDrawable = imageView.getResources().getDrawable(R.drawable.no_logo);
            imageView.setImageDrawable(myDrawable);
        } else {
            String letter = String.valueOf(text.charAt(0));
            drawable = TextDrawable.builder().beginConfig().toUpperCase().endConfig().buildRound(letter, ContextCompat.getColor(context, R.color.color_d8d8d8));
           /* if (color == 0) {
                drawable = TextDrawable.builder().beginConfig().toUpperCase().endConfig().buildRound(letter, generator.getColor(position));
            } else {
                drawable = TextDrawable.builder().beginConfig().toUpperCase().endConfig().buildRound(letter, color);
            }*/
            // imageView.setImageDrawable(drawable);
        }


        return drawable;
    }

    public static SpannableStringBuilder makeSpecificTextBold(String fullText, String textToBold) {
        SpannableStringBuilder builder = new SpannableStringBuilder();

        if (textToBold.length() > 0 && !textToBold.trim().equals("")) {

            //for counting start/end indexes
            String testText = fullText.toLowerCase(Locale.US);
            String testTextToBold = textToBold.toLowerCase(Locale.US);
            int startingIndex = testText.indexOf(testTextToBold);
            int endingIndex = startingIndex + testTextToBold.length();
            //for counting start/end indexes

            if (startingIndex < 0 || endingIndex < 0) {
                return builder.append(fullText);
            } else if (startingIndex >= 0 && endingIndex >= 0) {

                builder.append(fullText);
                builder.setSpan(new StyleSpan(Typeface.BOLD), startingIndex, endingIndex, Spannable.SPAN_INCLUSIVE_INCLUSIVE);

            }
        } else {
            return builder.append(fullText);
        }

        return builder;
    }

    public static void replaceFragmentStateLoss(android.app.FragmentManager fragmentManager, Fragment fragment, String tag, boolean addTobackStack, int container) {

        android.app.FragmentTransaction ft = fragmentManager.beginTransaction();
        ft.setCustomAnimations(R.animator.enter, R.animator.exit, R.animator.pop_enter, R.animator.pop_exit);
        if (addTobackStack) {
            ft.addToBackStack(tag);
        }

        ft.replace(container, fragment, tag);
        ft.commitAllowingStateLoss();
    }

    public static final String loadJSONFromAsset(Activity ctx) {
        String json = null;
        try {
            InputStream is = ctx.getAssets().open("post.json");
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            json = new String(buffer, "UTF-8");
        } catch (IOException ex) {
            ex.printStackTrace();
            return null;
        }
        Log.d(TAG, "loadJSONFromAsset: " + json);
        return json;
    }

    public static double getPercentage(float n, float total) {
        if (n == 0 || total == 0) {
            return 0.0;
        }
        try {
            float proportion = n / total;
            BigDecimal bigDecimal = new BigDecimal(proportion * 100);
            bigDecimal = bigDecimal.setScale(1, RoundingMode.HALF_UP);
            return bigDecimal.doubleValue();
        } catch (ArithmeticException e) {
            e.printStackTrace();
            return 0.0;
        }

    }

    public static void replaceFragment(android.app.FragmentManager fragmentManager, Fragment fragment, String tag, boolean addTobackStack, int container) {

        android.app.FragmentTransaction ft = fragmentManager.beginTransaction();
        ft.setCustomAnimations(R.animator.enter, R.animator.exit, R.animator.pop_enter, R.animator.pop_exit);
        if (addTobackStack) {
            ft.addToBackStack(tag);
        }

        ft.replace(container, fragment, tag);
        ft.commit();
    }

    public static String convertNumberWithCommas(String number) {
        try {
            return NumberFormat.getIntegerInstance().format(Integer.valueOf(number));
        } catch (Exception e) {
            e.printStackTrace();
            return number;
        }

    }

    public static void showSnackBarMessage(View view, String msg) {
        Snackbar snackbar = Snackbar.make(view, msg, Snackbar.LENGTH_LONG);

        View sbView = snackbar.getView();
        FrameLayout.LayoutParams params = (FrameLayout.LayoutParams) sbView.getLayoutParams();
        params.bottomMargin = 10;
        sbView.setBackgroundColor(Color.DKGRAY);
        TextView textView = sbView.findViewById(android.support.design.R.id.snackbar_text);
        textView.setTextColor(Color.WHITE);
        textView.setTextSize(20);
        snackbar.show();
    }

    public static String doubleToString(double value) {
        try {
            DecimalFormat format = new DecimalFormat("0.##");
            return format.format(value);
        } catch (Exception e) {
            e.printStackTrace();
            return String.valueOf(value);
        }
    }

    public static String roundOffDouble(double value) {
        try {
            DecimalFormat format = new DecimalFormat("0.##");
            return format.format(Math.round(value));
        } catch (Exception e) {
            e.printStackTrace();
            return String.valueOf(value);
        }
    }

    public static boolean isPasswordValid(String character) {
        boolean isValid = false;

        if (character.length() >= 6) {
            isValid = true;
        }
        return isValid;
    }

    public static boolean isValidEmail(CharSequence target) {
        return target != null && android.util.Patterns.EMAIL_ADDRESS.matcher(target).matches();
    }

    public static boolean isEmailIdValid(String emailId) {
        boolean isValid = false;

        Pattern EMAIL_ADDRESS_PATTERN = Pattern.compile("[a-zA-Z0-9\\+\\.\\_\\%\\-\\+]{1,256}" + "\\@" + "[a-zA-Z0-9][a-zA-Z0-9\\-]{0,64}" + "(" + "\\." + "[a-zA-Z0-9][a-zA-Z0-9\\-]{0,25}" + ")+");
        if (EMAIL_ADDRESS_PATTERN.matcher(emailId).matches()) {
            isValid = true;
        }
        return isValid;
    }

    public static void setupTouchUI(View view, final Activity mActivity) {
        if (!(view instanceof EditText)) {
            view.setOnTouchListener(new View.OnTouchListener() {
                @SuppressLint("ClickableViewAccessibility")
                public boolean onTouch(View v, MotionEvent event) {
                    hideSoftKeyboard(mActivity);
                    return false;
                }
            });
        }
        if (view instanceof ViewGroup) {
            for (int i = 0; i < ((ViewGroup) view).getChildCount(); i++) {
                View innerView = ((ViewGroup) view).getChildAt(i);
                setupTouchUI(innerView, mActivity);
            }
        }
    }

    public static void hideSoftKeyboard(Activity activity) {
        InputMethodManager inputMethodManager = (InputMethodManager) activity.getSystemService(Activity.INPUT_METHOD_SERVICE);
        if (null != activity.getCurrentFocus()) {
            inputMethodManager.hideSoftInputFromWindow(activity.getCurrentFocus().getWindowToken(), 0);
        }
    }

    public static Bitmap layoutToImage(View view) {
        view.destroyDrawingCache();
        view.buildDrawingCache();
        Bitmap bm = view.getDrawingCache();
        return bm;
    }

    public static SpannableStringBuilder makeSpecificTextBoldSize(String fullText, String textToBold, float size) {
        SpannableStringBuilder builder = new SpannableStringBuilder();

        if (textToBold.length() > 0 && !textToBold.trim().equals("")) {

            //for counting start/end indexes
            String testText = fullText.toLowerCase(Locale.US);
            String testTextToBold = textToBold.toLowerCase(Locale.US);
            int startingIndex = testText.indexOf(testTextToBold);
            int endingIndex = startingIndex + testTextToBold.length();
            //for counting start/end indexes

            if (startingIndex < 0 || endingIndex < 0) {
                return builder.append(fullText);
            } else if (startingIndex >= 0 && endingIndex >= 0) {

                builder.append(fullText);
                builder.setSpan(new StyleSpan(Typeface.BOLD), startingIndex, endingIndex, Spannable.SPAN_INCLUSIVE_INCLUSIVE);
                builder.setSpan(new RelativeSizeSpan(size), startingIndex, endingIndex, 0);
            }
        } else {
            return builder.append(fullText);
        }

        return builder;
    }

    public static SpannableStringBuilder makeSpecificTextSize(String fullText, String textToChangeSize,float size) {
        SpannableStringBuilder builder = new SpannableStringBuilder();

        if (textToChangeSize.length() > 0 && !textToChangeSize.trim().equals("")) {
            //for counting start/end indexes
            String testText = fullText.toLowerCase(Locale.US);
            String testTextToBold = textToChangeSize.toLowerCase(Locale.US);
            int startingIndex = testText.indexOf(testTextToBold);
            int endingIndex = startingIndex + testTextToBold.length();
            //for counting start/end indexes

            if (startingIndex < 0 || endingIndex < 0) {
                return builder.append(fullText);
            } else if (startingIndex >= 0 && endingIndex >= 0) {
                builder.append(fullText);
                builder.setSpan(new RelativeSizeSpan(size), startingIndex, endingIndex, 0);
            }
        } else {
            return builder.append(fullText);
        }

        return builder;
    }

    public static SpannableString makeSpecificTextLarger(String stringToLarge, float size){
        SpannableString spanString = new SpannableString(stringToLarge);
        spanString.setSpan(new RelativeSizeSpan(size), 0,spanString.length(), 0); // set size
        return spanString;
    }

    public static String getImageUri(Context inContext, Bitmap inImage) {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        inImage.compress(Bitmap.CompressFormat.JPEG, 100, bytes);
        String path = MediaStore.Images.Media.insertImage(inContext.getContentResolver(), inImage, "Title", null);
        return path;
    }

    public static void checkForCameraPermissions(Activity activity,CameraGalleryUtil cameraGalleryUtil) {

        Dexter.withActivity(activity)
                .withPermissions(Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                .withListener(new MultiplePermissionsListener() {
                    @Override
                    public void onPermissionsChecked(MultiplePermissionsReport report) {
                        if (report.areAllPermissionsGranted()) {

                            cameraGalleryUtil.openCamera();
                        }
                    }

                    @Override
                    public void onPermissionRationaleShouldBeShown(List<PermissionRequest> permissions, PermissionToken token) {
                        token.continuePermissionRequest();
                    }


                }).check();
    }

    public static void checkForCamCoderPermissions(Activity activity,CameraGalleryUtil cameraGalleryUtil) {

        Dexter.withActivity(activity)
                .withPermissions(Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                .withListener(new MultiplePermissionsListener() {
                    @Override
                    public void onPermissionsChecked(MultiplePermissionsReport report) {
                        if (report.areAllPermissionsGranted()) {

                            cameraGalleryUtil.CamCoder();
                        }
                    }

                    @Override
                    public void onPermissionRationaleShouldBeShown(List<PermissionRequest> permissions, PermissionToken token) {
                        token.continuePermissionRequest();
                    }


                }).check();
    }


    public static void checkForGalleryPermissions(Activity activity,CameraGalleryUtil cameraGalleryUtil) {
        Dexter.withActivity(activity)
                .withPermissions(Manifest.permission.READ_EXTERNAL_STORAGE)
                .withListener(new MultiplePermissionsListener() {
                    @Override
                    public void onPermissionsChecked(MultiplePermissionsReport report) {
                        if (report.areAllPermissionsGranted()) {
                            cameraGalleryUtil.openGallery();
                        }
                    }

                    @Override
                    public void onPermissionRationaleShouldBeShown(List<PermissionRequest> permissions, PermissionToken token) {
                        token.continuePermissionRequest();
                    }


                }).check();
    }
    public static void checkForGalleryVideoPermissions(Activity activity,CameraGalleryUtil cameraGalleryUtil) {
        Dexter.withActivity(activity)
                .withPermissions(Manifest.permission.READ_EXTERNAL_STORAGE)
                .withListener(new MultiplePermissionsListener() {
                    @Override
                    public void onPermissionsChecked(MultiplePermissionsReport report) {
                        if (report.areAllPermissionsGranted()) {
                            cameraGalleryUtil.openGalleryChooser();
                        }
                    }

                    @Override
                    public void onPermissionRationaleShouldBeShown(List<PermissionRequest> permissions, PermissionToken token) {
                        token.continuePermissionRequest();
                    }


                }).check();
    }

    public static void checkForStoragePermissions(Activity activity,CameraGalleryUtil cameraGalleryUtil) {

        Dexter.withActivity(activity)
                .withPermissions(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                .withListener(new MultiplePermissionsListener() {
                    @Override
                    public void onPermissionsChecked(MultiplePermissionsReport report) {
                        if (report.areAllPermissionsGranted()) {

                        }
                    }

                    @Override
                    public void onPermissionRationaleShouldBeShown(List<PermissionRequest> permissions, PermissionToken token) {
                        token.continuePermissionRequest();
                    }


                }).check();
    }
}
