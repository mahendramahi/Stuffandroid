package com.twc.dailylog.model.requestbody;

/**
 * Created by ManishJ1 on 6/30/2016.
 */
public class HomeBody extends BaseBody {
    private String MemberID;
    private String DeviceDate;
    public String getMemberID() {
        return MemberID;
    }

    public void setMemberID(String memberID) {
        MemberID = memberID;
    }

    public String getDeviceDate() {
        return DeviceDate;
    }

    public void setDeviceDate(String deviceDate) {
        DeviceDate = deviceDate;
    }
}
