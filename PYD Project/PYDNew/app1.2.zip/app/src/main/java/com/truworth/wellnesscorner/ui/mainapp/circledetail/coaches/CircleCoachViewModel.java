package com.truworth.wellnesscorner.ui.mainapp.circledetail.coaches;

import android.databinding.ObservableBoolean;

import com.truworth.wellnesscorner.TheWellnessCornerApp;
import com.truworth.wellnesscorner.base.BaseViewModel;
import com.truworth.wellnesscorner.model.CircleCoach;
import com.truworth.wellnesscorner.repo.DashboardRepository;
import com.truworth.wellnesscorner.repo.model.request.BaseRequest;
import com.truworth.wellnesscorner.repo.model.response.CircleCoachResponse;
import com.truworth.wellnesscorner.utils.SingleLiveEvent;

import java.util.List;

import javax.inject.Inject;

import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;

public class CircleCoachViewModel extends BaseViewModel {

    public SingleLiveEvent<List<CircleCoach>> coaches = new SingleLiveEvent<>();

    public SingleLiveEvent<List<CircleCoach>> getCoaches() {
        return coaches;
    }

    SingleLiveEvent<Void> upArrow = new SingleLiveEvent<>();

    public SingleLiveEvent<Void> getUpArrow() {
        return upArrow;
    }

    public ObservableBoolean showNoData = new ObservableBoolean();
    @Inject
    DashboardRepository dashboardRepository;

    public CircleCoachViewModel() {
        TheWellnessCornerApp.getApp().component().inject(this);
    }

    public void loadCoaches(String circleIdentity){

        BaseRequest circleCoachRequest = new BaseRequest();
        circleCoachRequest.setId(circleIdentity);

        dashboardRepository.getCircleCoaches(circleCoachRequest).subscribe(new Observer<CircleCoachResponse>() {
            @Override
            public void onSubscribe(Disposable d) {

            }

            @Override
            public void onNext(CircleCoachResponse circleCoachResponse) {
                if (!circleCoachResponse.isHasError()) {
                    coaches.setValue(circleCoachResponse.getData());
                    showNoData.set(false);
                }
                else{
                    showNoData.set(true);
                }
            }

            @Override
            public void onError(Throwable e) {

            }

            @Override
            public void onComplete() {

            }
        });

    }

    public void upArrowClick(){
        upArrow.call();
    }
}
