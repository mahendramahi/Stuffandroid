package com.twc.remindermodule.model.response;


import com.twc.remindermodule.model.beans.HealthyHabitBean;

import java.util.List;

/**
 * Created by richas on 9/21/2017.
 */

public class HealthyHabitResponse {

    private int status;
    private List<HealthyHabitBean> Data;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public List<HealthyHabitBean> getData() {
        return Data;
    }

    public void setData(List<HealthyHabitBean> Data) {
        this.Data = Data;
    }


}
