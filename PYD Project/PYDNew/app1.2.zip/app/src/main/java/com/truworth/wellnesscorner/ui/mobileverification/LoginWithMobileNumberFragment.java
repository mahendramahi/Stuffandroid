package com.truworth.wellnesscorner.ui.mobileverification;

import android.app.Activity;
import android.app.FragmentManager;
import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Intent;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.truworth.wellnesscorner.R;
import com.truworth.wellnesscorner.customviews.CustomProgressDialog;
import com.truworth.wellnesscorner.databinding.FragmentMobileNumberForOtpBinding;
import com.truworth.wellnesscorner.utils.KeyBoardUtils;
import com.twc.remindermodule.fragments.RecommendedHealthyHabitsFragment;

public class LoginWithMobileNumberFragment extends Fragment {

    public static final String TAG = "LoginWithMobileNumberFr";
    private static final String ARG_EMAIL = "email";
    private static final String ARG_REDIRECT_FROM = "from";

    LoginMobileViewModel viewModel;
    CustomProgressDialog pd;
    private int EDIT_LOCATION = 123;
    private FragmentMobileNumberForOtpBinding binding;
    private String mEmail;
    private int mRedirectFrom;

    public LoginWithMobileNumberFragment() {
        // Required empty public constructor
    }

    public static LoginWithMobileNumberFragment newInstance(String email, int flagRedirectFrom) {
        LoginWithMobileNumberFragment fragment = new LoginWithMobileNumberFragment();
        Bundle args = new Bundle();
        args.putString(ARG_EMAIL, email);
        args.putInt(ARG_REDIRECT_FROM, flagRedirectFrom);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mEmail = getArguments().getString(ARG_EMAIL);
            mRedirectFrom = getArguments().getInt(ARG_REDIRECT_FROM);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        pd = new CustomProgressDialog(getActivity(), R.style.custom_progress_style, true);
        binding = DataBindingUtil.inflate(inflater, R.layout.fragment_mobile_number_for_otp, container, false);

        KeyBoardUtils.openKeyboard(getActivity(), binding.etMobileNumber);
        viewModel = ViewModelProviders.of(this).get(LoginMobileViewModel.class);
        viewModel.setEmail(mEmail);
        viewModel.setRedirectFrom(mRedirectFrom);
        binding.setViewModel(viewModel);

        setSuggestionText();
        attachProgressbarObserver();
        attachSentOtpObserver();
        attachClearDataObserver();
        navigateCountrySearch();
        viewModel.selectedCountryCode.set("+91");
        return binding.getRoot();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode == Activity.RESULT_OK && requestCode == EDIT_LOCATION && data != null) {

            String selectedPhoneCode = data.getExtras().getString("phoneCode");
            String selectedCountryCode = data.getExtras().getString("countryCode");
            viewModel.setPhoneCode(selectedPhoneCode);
            binding.ivFlagImage.setImageResource(getResources().getIdentifier("drawable/" + selectedCountryCode, null, getContext().getPackageName()));

        }
    }

    private void navigateCountrySearch() {
        viewModel.getIsNavigateCountrySearch().observe(this, new Observer<Void>() {
            @Override
            public void onChanged(@Nullable Void aVoid) {
                Intent intent = new Intent(getActivity(), CountryCodeListActivity.class);
                intent.putExtra("phoneCode", binding.tvCountryCode.getText().toString());
                startActivityForResult(intent, EDIT_LOCATION);
            }
        });
    }

    private void setSuggestionText() {
        if (mRedirectFrom == MobileNumberRedirectionType.FROM_LOGIN) {
            viewModel.getMobileNumberSubTitle().set(getResources().getString(R.string.label_note_entermobile_for_login));
        } else {
            viewModel.getMobileNumberSubTitle().set(getResources().getString(R.string.label_note_entermobile_for_register));
        }
    }

    private void attachSentOtpObserver() {
        viewModel.getIsSentOtp().observe(this, new Observer<Void>() {
            @Override
            public void onChanged(@Nullable Void aVoid) {
                //Success, update UI
                showOTPFragment();
            }
        });
    }

    private void attachProgressbarObserver() {
        viewModel.getIsLoading().observe(this, new Observer<Boolean>() {
            @Override
            public void onChanged(@Nullable Boolean response) {
                if (response != null && response) {
                    //Success, update UI
                    pd.show();

                } else {

                    pd.dismiss();

                }
            }
        });
    }


    public void showOTPFragment( ) {
        if (mRedirectFrom == MobileNumberRedirectionType.FROM_LOGIN) {
            getActivity().getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.loginContainer, OTPFragment.newInstance(viewModel.mobileNumber.get(), mEmail, viewModel.getOtpData().getOtpSessionId(), mRedirectFrom), OTPFragment.TAG).addToBackStack(OTPFragment.TAG)
                    .commit();
        } else {
            getActivity().getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.registerContainer, OTPFragment.newInstance(viewModel.mobileNumber.get(), mEmail, viewModel.getOtpData().getOtpSessionId(), mRedirectFrom), OTPFragment.TAG).addToBackStack(OTPFragment.TAG)
                    .commit();

        }
    }

    private void attachClearDataObserver() {
        viewModel.getClearData().observe(this, new Observer<Void>() {
            @Override
            public void onChanged(@Nullable Void aVoid) {
                //Success, update UI
                binding.etMobileNumber.setText("");
            }
        });
    }


}
