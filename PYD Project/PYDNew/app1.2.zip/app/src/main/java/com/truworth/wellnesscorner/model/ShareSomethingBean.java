package com.truworth.wellnesscorner.model;

import com.truworth.wellnesscorner.ui.mainapp.post.IPostListItem;

public class ShareSomethingBean implements IPostListItem {
    public String getProfileImage() {
        return profileImage;
    }

    public void setProfileImage(String profileImage) {
        this.profileImage = profileImage;
    }

    String profileImage;
    String userName;

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    @Override
    public int getPostListItemType() {
        return IPostListItem.TYPE_SHARE;
    }
}
