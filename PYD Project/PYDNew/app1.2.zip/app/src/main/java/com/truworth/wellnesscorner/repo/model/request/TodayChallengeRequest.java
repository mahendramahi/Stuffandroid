package com.truworth.wellnesscorner.repo.model.request;

public class TodayChallengeRequest {
    public int getPageIndex() {
        return PageIndex;
    }

    public void setPageIndex(int pageIndex) {
        PageIndex = pageIndex;
    }

    private int PageIndex;
}
