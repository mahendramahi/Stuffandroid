package com.truworth.wellnesscorner.repo.model.response;

/**
 * If this code works it was written by Somesh Kumar on 18 January, 2017. If not, I don't know who wrote it.
 */
public class SaveStepsResponse {

    private int status;
    private String LastStepsTrackerDate;
    private int TodaySteps;
    private String LastConnectedDevice;
    private String LastStepUpdatedDate;
    private double TodayCalorie;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getLastStepsTrackerDate() {
        return LastStepsTrackerDate;
    }

    public void setLastStepsTrackerDate(String LastStepsTrackerDate) {
        this.LastStepsTrackerDate = LastStepsTrackerDate;
    }

    public int getTodaySteps() {
        return TodaySteps;
    }

    public void setTodaySteps(int todaySteps) {
        TodaySteps = todaySteps;
    }

    public String getLastConnectedDevice() {
        return LastConnectedDevice;
    }

    public void setLastConnectedDevice(String lastConnectedDevice) {
        LastConnectedDevice = lastConnectedDevice;
    }

    public double getTodayCalorie() {
        return TodayCalorie;
    }

    public void setTodayCalorie(double todayCalorie) {
        TodayCalorie = todayCalorie;
    }

    public String getLastStepUpdatedDate() {
        return LastStepUpdatedDate;
    }

    public void setLastStepUpdatedDate(String lastStepUpdatedDate) {
        LastStepUpdatedDate = lastStepUpdatedDate;
    }
}
