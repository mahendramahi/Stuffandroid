package com.twc.store.model.response;


import com.twc.store.model.beans.DeleteCartItem;

/**
 * Created by PalakC on 9/14/2017.
 */

public class DeleteCartItemResponse {


    private int status;
    private DeleteCartItem Data;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public DeleteCartItem getData() {
        return Data;
    }

    public void setData(DeleteCartItem Data) {
        this.Data = Data;
    }


}
