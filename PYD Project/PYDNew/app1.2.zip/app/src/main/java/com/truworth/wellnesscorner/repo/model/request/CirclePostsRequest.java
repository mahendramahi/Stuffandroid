package com.truworth.wellnesscorner.repo.model.request;

public class CirclePostsRequest extends BaseRequest{
     int PageIndex;
    int PageSize;

    public int getPageIndex() {
        return PageIndex;
    }

    public void setPageIndex(int pageIndex) {
        PageIndex = pageIndex;
    }

    public int getPageSize() {
        return PageSize;
    }

    public void setPageSize(int pageSize) {
        PageSize = pageSize;
    }
}
