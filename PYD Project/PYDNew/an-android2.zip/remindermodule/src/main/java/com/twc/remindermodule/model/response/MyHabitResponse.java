package com.twc.remindermodule.model.response;

import java.util.List;

/**
 * Created by GurvinderS on 11/16/2017.
 */

public class MyHabitResponse {



    private int status;
    private List<MyHabitItem> Data;
    private boolean IsMoreHabitToAdd;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public List<MyHabitItem> getData() {
        return Data;
    }

    public void setData(List<MyHabitItem> Data) {
        this.Data = Data;
    }

    public boolean isMoreHabitToAdd() {
        return IsMoreHabitToAdd;
    }

    public void setMoreHabitToAdd(boolean moreHabitToAdd) {
        IsMoreHabitToAdd = moreHabitToAdd;
    }

    public static class MyHabitItem {


        public String ImagePath;
        private int HabitID;
        private int TrackerID;
        private String Title;
        private boolean IsTrackerBasedHabit;
        private double ProgressPercentage;
        private List<WeeklyProgressListBean> WeeklyProgressList;

        public String getImagePath() {
            return ImagePath;
        }

        public void setImagePath(String imagePath) {
            ImagePath = imagePath;
        }

        public int getHabitID() {
            return HabitID;
        }

        public void setHabitID(int HabitID) {
            this.HabitID = HabitID;
        }

        public int getTrackerID() {
            return TrackerID;
        }

        public void setTrackerID(int TrackerID) {
            this.TrackerID = TrackerID;
        }

        public String getTitle() {
            return Title;
        }

        public void setTitle(String Title) {
            this.Title = Title;
        }

        public boolean isIsTrackerBasedHabit() {
            return IsTrackerBasedHabit;
        }

        public void setIsTrackerBasedHabit(boolean IsTrackerBasedHabit) {
            this.IsTrackerBasedHabit = IsTrackerBasedHabit;
        }

        public double getProgressPercentage() {
            return ProgressPercentage;
        }

        public void setProgressPercentage(double ProgressPercentage) {
            this.ProgressPercentage = ProgressPercentage;
        }

        public List<WeeklyProgressListBean> getWeeklyProgressList() {
            return WeeklyProgressList;
        }

        public void setWeeklyProgressList(List<WeeklyProgressListBean> WeeklyProgressList) {
            this.WeeklyProgressList = WeeklyProgressList;
        }

        public static class WeeklyProgressListBean {
            /**
             * HabitID : 1
             * TrackerID : 3
             * DayOfWeek : Monday
             * Progress : false
             */

            private int HabitID;
            private int TrackerID;
            private String DayOfWeek;
            private boolean Progress;

            public int getHabitID() {
                return HabitID;
            }

            public void setHabitID(int HabitID) {
                this.HabitID = HabitID;
            }

            public int getTrackerID() {
                return TrackerID;
            }

            public void setTrackerID(int TrackerID) {
                this.TrackerID = TrackerID;
            }

            public String getDayOfWeek() {
                return DayOfWeek;
            }

            public void setDayOfWeek(String DayOfWeek) {
                this.DayOfWeek = DayOfWeek;
            }

            public boolean isProgress() {
                return Progress;
            }

            public void setProgress(boolean Progress) {
                this.Progress = Progress;
            }
        }
    }
}
