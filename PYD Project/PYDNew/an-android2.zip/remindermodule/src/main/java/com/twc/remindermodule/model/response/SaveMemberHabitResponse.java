package com.twc.remindermodule.model.response;

/**
 * Created by richas on 9/21/2017.
 */

public class SaveMemberHabitResponse {

    private int status;
    private DataBean Data;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public DataBean getData() {
        return Data;
    }

    public void setData(DataBean Data) {
        this.Data = Data;
    }

    public static class DataBean {
    }
}
