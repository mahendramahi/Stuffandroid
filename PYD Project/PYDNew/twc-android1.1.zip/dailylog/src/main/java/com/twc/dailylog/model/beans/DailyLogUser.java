package com.twc.dailylog.model.beans;

/**
 * Created by ManishJ1 on 3/20/2018.
 */

public class DailyLogUser {

    private String userID;
    private String accessToken;
    private String type;
    private String mealType;

    public DailyLogUser() {

    }

    public DailyLogUser(String userID, String type,String mealType, String accessToken) {
        this.userID = userID;
        this.accessToken = accessToken;
        this.mealType = mealType;
        this.type = type;
    }

    public String getAccessToken() {
        return accessToken;
    }

    public void setAccessToken(String accessToken) {
        this.accessToken = accessToken;
    }

    public String getUserID() {
        return userID;
    }

    public void setUserID(String userID) {
        this.userID = userID;
    }

    public String getMealType() {
        return mealType;
    }

    public void setMealType(String mealType) {
        this.mealType = mealType;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
