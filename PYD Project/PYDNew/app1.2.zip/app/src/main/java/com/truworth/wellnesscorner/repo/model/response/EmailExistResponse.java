package com.truworth.wellnesscorner.repo.model.response;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * Created by rajeshs on 3/29/2018.
 */

public class EmailExistResponse {
    @SerializedName("data")
    @Expose
    Data data;
    boolean hasError;

    @SerializedName("error")
    @Expose
    private Error error;

    public Data getData() {
        return data;
    }

    public void setData(Data data) {
        this.data = data;
    }

    public boolean isHasError() {
        return hasError;
    }

    public void setHasError(boolean hasError) {
        this.hasError = hasError;
    }

    public Error getError() {
        return error;
    }

    public void setError(Error error) {
        this.error = error;
    }

    public  class Data {
        boolean isEmailExist;

        public boolean isEmailExist() {
            return isEmailExist;
        }

        public void setEmailExist(boolean emailExist) {
            isEmailExist = emailExist;
        }
    }
}
