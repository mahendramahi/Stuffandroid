package com.truworth.wellnesscorner.repo.model.request;

/**
 * Created by GurvinderS on 8/16/2016.
 */
public class ActivityMarkAsReadBody {


    private int programID;
    private String itemType;
    private int itemID;
    private String itemName;
    private int workshopLevelID;

    public int getProgramID() {
        return programID;
    }

    public void setProgramID(int programID) {
        this.programID = programID;
    }

    public String getItemType() {
        return itemType;
    }

    public void setItemType(String itemType) {
        this.itemType = itemType;
    }

    public int getItemID() {
        return itemID;
    }

    public void setItemID(int itemID) {
        this.itemID = itemID;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public int getWorkshopLevelID() {
        return workshopLevelID;
    }

    public void setWorkshopLevelID(int workshopLevelID) {
        this.workshopLevelID = workshopLevelID;
    }
}
