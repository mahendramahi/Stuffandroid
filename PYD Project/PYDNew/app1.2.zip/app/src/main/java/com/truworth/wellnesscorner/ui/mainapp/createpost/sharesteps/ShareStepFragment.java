package com.truworth.wellnesscorner.ui.mainapp.createpost.sharesteps;

import android.app.Activity;
import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.ImageView;

import com.truworth.wellnesscorner.BR;
import com.truworth.wellnesscorner.R;
import com.truworth.wellnesscorner.base.BaseFragment;
import com.truworth.wellnesscorner.databinding.FragmentShareStepsBinding;
import com.truworth.wellnesscorner.ui.mainapp.createpost.ShareActivity;
import com.truworth.wellnesscorner.ui.registration.registrationstepfifth.CropActivity;
import com.truworth.wellnesscorner.utils.AppConstants;
import com.truworth.wellnesscorner.utils.CameraGalleryUtil;
import com.truworth.wellnesscorner.utils.CompressImage;
import com.truworth.wellnesscorner.utils.Utils;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;


public class ShareStepFragment extends BaseFragment<FragmentShareStepsBinding, ShareStepsViewModel> {
    public static final String TAG = "ShareStepFragment";

    private ShareStepsViewModel viewModel;
    private FragmentShareStepsBinding binding;
    private ImageView ivUserImage;
    private CameraGalleryUtil cameraGalleryUtil;
    private String filePath;
    boolean isCameraSelected;
    private Bitmap finalBitmap;
    private Bitmap cameraBitmap;
    final String bb="dkfd";

    public static ShareStepFragment newInstance() {
        ShareStepFragment fragment = new ShareStepFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        cameraGalleryUtil = new CameraGalleryUtil(getActivity(), ShareStepFragment.this);

    }

    @Override
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        binding = getViewDataBinding();

        viewModel.loadStepsPost();
        setClickObserver();
        setApiResponseObserver();

    }

    private void setApiResponseObserver() {
        viewModel.getHasDataLoaded().observe(this, new Observer<Void>() {
            @Override
            public void onChanged(@Nullable Void avoid) {
                setDefault();
            }
        });
    }

    @Override
    public int getBindingVariable() {
        return BR.viewModel;
    }

    @Override
    public int getLayoutId() {
        return R.layout.fragment_share_steps;
    }

    @Override
    public ShareStepsViewModel getViewModel() {
        viewModel = ViewModelProviders.of(this).get(ShareStepsViewModel.class);
        return viewModel;
    }

    private void setClickObserver() {
        viewModel.getDefaultImgClick().observe(this, new Observer<Void>() {
            @Override
            public void onChanged(@Nullable Void avoid) {
                isCameraSelected = false;
                setSelection(0, R.drawable.template_select_white);

                binding.rlStepBaseView.setVisibility(View.VISIBLE);
                binding.rlImage.setVisibility(View.GONE);

                setDefault();
            }
        });

        viewModel.getCameraBtnClick().observe(this, new Observer<Void>() {
            @Override
            public void onChanged(@Nullable Void avoid) {
                if (filePath != null) {
                    setSelection(R.drawable.template_select_white, R.drawable.rounded_grey_light_border);
                    setData(filePath);
                    if (isCameraSelected) {
                        Utils.checkForCameraPermissions(getActivity(), cameraGalleryUtil);
                    }
                } else {
                    Utils.checkForCameraPermissions(getActivity(), cameraGalleryUtil);
                }
                isCameraSelected = true;
            }
        });

        viewModel.getShareBtnClick().observe(this, new Observer<Void>() {
            @Override
            public void onChanged(@Nullable Void avoid) {
                if (finalBitmap != null) {
                    String path = Utils.getImageUri(getContext(), finalBitmap);
                    Intent returnIntent = new Intent();
                    returnIntent.putExtra("result", path);
                    getActivity().setResult(Activity.RESULT_OK, returnIntent);
                    getActivity().finish();

                }
            }
        });


    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode == Activity.RESULT_OK) {
            Uri selectedImage;
            setSelection(R.drawable.template_select_white, R.drawable.rounded_grey_light_border);
            if (requestCode == AppConstants.CAMERA_REQUEST) {
                if (cameraGalleryUtil.getCameraFilePath() != null) {
                    File file = new File(cameraGalleryUtil.getCameraFilePath());
                    Uri myuri = Uri.fromFile(file);
                    filePath = cameraGalleryUtil.getPath(getActivity(), myuri);
                   // CompressImage.compress(filePath);
                    cameraBitmap=null;
                    setData(filePath);
                }
            } else if (requestCode == AppConstants.GALLERY_REQUEST && data != null && data.getData() != null) {

            }
        } else {

        }
    }

    public void setData(String filePath) {
        if (filePath != null) {
            binding.rlStepBaseView.setVisibility(View.GONE);
            if(cameraBitmap!=null){
                binding.ivCaptureImage.setImageBitmap(cameraBitmap);
            }
            else{
                cameraBitmap = cameraGalleryUtil.getBitmap(filePath,  binding.ivCaptureImage.getWidth(), binding.ivCaptureImage.getHeight());
                binding.ivCaptureImage.setImageBitmap(cameraBitmap);
            }

            binding.rlImage.setVisibility(View.VISIBLE);

            Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {

                    Bitmap bm = Utils.layoutToImage(binding.rlMain);
                    ByteArrayOutputStream bytes = new ByteArrayOutputStream();
                    bm.compress(Bitmap.CompressFormat.JPEG, 100, bytes);
                    binding.ivCamera.setImageBitmap(bm);
                    finalBitmap = bm;

                    try {
                        bytes.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }, 500);


        }
    }

    public void setDefault() {

        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {

                Bitmap bm = Utils.layoutToImage(binding.rlStepBaseView);
                ByteArrayOutputStream bytes = new ByteArrayOutputStream();
                bm.compress(Bitmap.CompressFormat.JPEG, 100, bytes);
                finalBitmap = bm;
            }
        }, 500);

    }

    public void setSelection(int i1, int i2) {
        binding.llCameraBorder.setBackgroundResource(i1);
        binding.llDefaultImageBorder.setBackgroundResource(i2);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if(finalBitmap!=null){
            finalBitmap.recycle();
            finalBitmap=null;
        }
        if(cameraBitmap!=null){
            cameraBitmap.recycle();
            cameraBitmap=null;
        }

   }

}
