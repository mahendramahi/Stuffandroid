package com.truworth.wellnesscorner.model;

/**
 * Created by PalakC on 2/21/2018.
 */

public class MemberProgramItem {

    private int MemberPID;
    private int tmpMember_ProgramID;
    private String ProgramName;
    private String Workshop_Image;
    private double Program_Compliance;
    private int Total_Peps;
    private int Earned_Peps;
    private int Total_Days;
    private int RemaningDays;

    public int getMemberPID() {
        return MemberPID;
    }

    public void setMemberPID(int MemberPID) {
        this.MemberPID = MemberPID;
    }

    public int getTmpMember_ProgramID() {
        return tmpMember_ProgramID;
    }

    public void setTmpMember_ProgramID(int tmpMember_ProgramID) {
        this.tmpMember_ProgramID = tmpMember_ProgramID;
    }

    public String getProgramName() {
        return ProgramName;
    }

    public void setProgramName(String ProgramName) {
        this.ProgramName = ProgramName;
    }

    public String getWorkshop_Image() {
        return Workshop_Image;
    }

    public void setWorkshop_Image(String Workshop_Image) {
        this.Workshop_Image = Workshop_Image;
    }

    public double getProgram_Compliance() {
        return Program_Compliance;
    }

    public void setProgram_Compliance(double Program_Compliance) {
        this.Program_Compliance = Program_Compliance;
    }

    public int getTotal_Peps() {
        return Total_Peps;
    }

    public void setTotal_Peps(int Total_Peps) {
        this.Total_Peps = Total_Peps;
    }

    public int getEarned_Peps() {
        return Earned_Peps;
    }

    public void setEarned_Peps(int Earned_Peps) {
        this.Earned_Peps = Earned_Peps;
    }

    public int getTotal_Days() {
        return Total_Days;
    }

    public void setTotal_Days(int Total_Days) {
        this.Total_Days = Total_Days;
    }

    public int getRemaningDays() {
        return RemaningDays;
    }

    public void setRemaningDays(int RemaningDays) {
        this.RemaningDays = RemaningDays;
    }

}
