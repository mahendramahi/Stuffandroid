package com.truworth.wellnesscorner.ui.registration.registrationstepfourth;

import android.app.Activity;
import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Intent;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.truworth.wellnesscorner.R;
import com.truworth.wellnesscorner.databinding.FragmentConfirmLocationBinding;
import com.truworth.wellnesscorner.ui.registration.registrationstepfifth.EditProfileFragment;
import com.truworth.wellnesscorner.utils.FragmentUtils;


/**
 * Created by richas on 4/9/2018.
 */

public class ConfirmLocationFragment extends Fragment{

    public static final String TAG = "ConfirmLocationFragment";
    private int EDIT_LOCATION = 123;
    ConfirmLocationViewModel viewModel;
    private String city, state, country;
    private int CityId;
    private static final String ARG_CITY_ID = "cityId";
    private static final String ARG_CITY = "City";
    private static final String ARG_STATE = "State";
    private static final String ARG_COUNTRY = "Country";


    // TODO: Rename and change types and number of parameters
    public static ConfirmLocationFragment newInstance(int cityId, String city, String state, String country) {
        ConfirmLocationFragment fragment = new ConfirmLocationFragment();
        Bundle args = new Bundle();
        args.putInt(ARG_CITY_ID, cityId);
        args.putString(ARG_CITY, city);
        args.putString(ARG_STATE, state);
        args.putString(ARG_COUNTRY, country);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
        if (getArguments() != null) {
            CityId = getArguments().getInt(ARG_CITY_ID);
            city = getArguments().getString(ARG_CITY);
            state = getArguments().getString(ARG_STATE);
            country = getArguments().getString(ARG_COUNTRY);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        FragmentConfirmLocationBinding binding = DataBindingUtil.inflate(inflater, R.layout.fragment_confirm_location, container, false);
        viewModel = ViewModelProviders.of(this).get(ConfirmLocationViewModel.class);
        binding.setViewModel(viewModel);
        viewModel.setCityId(String.valueOf(CityId));
        viewModel.setCity(city);
        viewModel.setState(state);
        viewModel.setCountry(country);
        attachNavigateCitySearchObserver();
        attachSaveCityObserver();

        return binding.getRoot();
    }
    private void attachNavigateCitySearchObserver() {
        viewModel.getNavigateCitySearch().observe(this, new Observer<Void>() {
            @Override
            public void onChanged(@Nullable Void aVoid) {
                //Success, update UI
                showCitySearchFragment();
            }
        });
    }
    private void showCitySearchFragment() {
        Intent intent = new Intent(getActivity(), CitySearchActivity.class);
        intent.putExtra("CITY", city);
        startActivityForResult(intent,EDIT_LOCATION);
    }
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode == Activity.RESULT_OK && requestCode == EDIT_LOCATION && data!=null) {

          String selectedCity = data.getExtras().getString("City");
          String selectedState = data.getExtras().getString("State");
          String selectedCountry =  data.getExtras().getString("Country");
          int selectedCityId =  data.getExtras().getInt("cityId");
            viewModel.setCity(selectedCity);
            viewModel.setState(selectedState);
            viewModel.setCountry(selectedCountry);
            viewModel.setCityId(String.valueOf(selectedCityId));

        } else {

        }
    }
    private void attachSaveCityObserver() {
        viewModel.getCitySaved().observe(this, new Observer<Void>() {
            @Override
            public void onChanged(@Nullable Void aVoid) {
                //Success, update UI
                Toast.makeText(getActivity(), "City saved successfully!", Toast.LENGTH_LONG).show();
              //  FragmentUtils.removeAllFragmentFromStack((AppCompatActivity) getActivity());
                getActivity().getSupportFragmentManager()
                        .beginTransaction()
                        .replace(R.id.registerContainer, EditProfileFragment.newInstance(), EditProfileFragment.TAG).addToBackStack(ConfirmLocationFragment.TAG)
                        .commit();
            }
        });
    }
}
