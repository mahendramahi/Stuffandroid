package com.truworth.discoverlib.model;


import java.util.List;

/**
 * Created by PalakC on 8/10/2016.
 */
public class GetMyFavoriteResponse {


    /**
     * data : [{"ID":4427,"Type":"Article","Name":"Reduce Your Cortisol Naturally!","Image":"http://demo.truworth.net/truwortharticles/Images/ArticleImages/ReduceYourCortisolNa_19-01-2016_06-13-21-PM_.jpg"},{"ID":48,"Type":"Slide","Name":"10 Simple Ways To Keep Yourself Happy During Pregnancy","Image":"https://e2ap.com/Images/SlideImages/09102015_04_10_27_Happy Pregnanacy - 1.jpg"},{"ID":43,"Type":"Slide","Name":"Packed Lunches For Kids","Image":"https://e2ap.com/Images/SlideImages/10032015_12_03_53_Packed-1.jpg"},{"ID":40,"Type":"Slide","Name":"Fundamentals of Perfect Make-Up","Image":"https://e2ap.com/Images/SlideImages/07132015_02_13_23_Fundamentals-of-Perfect-Make-Up.jpg"},{"ID":38,"Type":"Slide","Name":"Building your Circle of Support","Image":"https://e2ap.com/Images/SlideImages/circle-of-support.jpg"},{"ID":11,"Type":"Slide","Name":"Super Foods for Healthy Hair","Image":"https://e2ap.com/Images/SlideImages/main.jpg"},{"ID":6,"Type":"Slide","Name":"Eating Right During Monsoon","Image":"https://e2ap.com/Images/SlideImages/main-1.jpg"},{"ID":14,"Type":"Slide","Name":"Organize Yourself To Remember Better ","Image":"https://e2ap.com/Images/SlideImages/Organize-Yourself-To-Remember-Better.jpg"},{"ID":1081,"Type":"Article","Name":"Know About Arthritis","Image":"http://demo.truworth.net/truwortharticles/Images/ArticleImages/KnowAboutArthritis_11-02-2016_05-07-59-PM.jpg"},{"ID":33,"Type":"Quiz","Name":null,"Image":""},{"ID":736,"Type":"Article","Name":"RSI &#45; Are You At Risk?","Image":"http://demo.truworth.net/truwortharticles/Images/ArticleImages/RSIAreYouAtRisk_10-03-2016_12-23-48-PM.jpg"},{"ID":33,"Type":"Slide","Name":"Nutrition on a Budget","Image":"https://e2ap.com/Images/SlideImages/Main slide.jpg"},{"ID":5391,"Type":"Article","Name":"How Important Is Exercise In Quitting Smoking?","Image":"http://demo.truworth.net/truwortharticles/Images/ArticleImages/HowImportantIsExerci_03-05-2016_06-20-36-PM.jpg"},{"ID":5388,"Type":"Article","Name":"African Mangoes &#45;&#45;&#45; A Weight Watcher's Boon?","Image":"http://demo.truworth.net/truwortharticles/Images/ArticleImages/AfricanMangoesAWeigh_21-01-2016_06-00-49-PM_.jpg"},{"ID":22,"Type":"Article","Name":"Banana Diet - yet another fad?","Image":"http://demo.truworth.net/truwortharticles/Images/ArticleImages/banana-diet-yet-another-fad.jpg"},{"ID":982,"Type":"Article","Name":"Know the Side Effects of Oral Contraceptive Pills Before You Pop One!!","Image":"http://demo.truworth.net/truwortharticles/Images/ArticleImages/KnowtheSideEffectsof_05-04-2016_04-41-48-PM.jpg"},{"ID":4768,"Type":"Article","Name":"Busting the Myths about Grey Hair","Image":"http://demo.truworth.net/truwortharticles/Images/ArticleImages/BustingtheMythsabout_27-04-2016_07-17-48-PM.jpg"}]
     * status : 0
     */

    private int status;
    /**
     * ID : 4427
     * Type : Article
     * Name : Reduce Your Cortisol Naturally!
     * Image : http://demo.truworth.net/truwortharticles/Images/ArticleImages/ReduceYourCortisolNa_19-01-2016_06-13-21-PM_.jpg
     */

    private List<GetMyFavoriteItem> data;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public List<GetMyFavoriteItem> getData() {
        return data;
    }

    public void setData(List<GetMyFavoriteItem> data) {
        this.data = data;
    }


}
