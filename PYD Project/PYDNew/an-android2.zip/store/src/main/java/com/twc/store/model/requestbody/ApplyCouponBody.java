package com.twc.store.model.requestbody;

/**
 * If this code works it was written by Somesh Kumar on 15 September, 2017. If not, I don't know who wrote it.
 */
public class ApplyCouponBody {
    private int MemberId;
    private String couponCode;
    private String cartIds;
    private String couponIds;

    public int getMemberId() {
        return MemberId;
    }

    public void setMemberId(int MemberId) {
        this.MemberId = MemberId;
    }

    public String getCouponCode() {
        return couponCode;
    }

    public void setCouponCode(String couponCode) {
        this.couponCode = couponCode;
    }

    public String getCartIds() {
        return cartIds;
    }

    public void setCartIds(String cartIds) {
        this.cartIds = cartIds;
    }

    public String getCouponIds() {
        return couponIds;
    }

    public void setCouponIds(String couponIds) {
        this.couponIds = couponIds;
    }
}
