package com.truworth.stepmodule.model;

import com.google.gson.annotations.SerializedName;

/**
 * Created by ManishJ1 on 8/4/2016.
 */
public class FitBitStepsItem {

    // "time" is for Fitbit, "date" is for E-Fit, default "dateTime"
    @SerializedName(value = "dateTime", alternate = {"time", "date"})
    private String dateTime;

    // "steps" is for E-Fit, default "value"
    @SerializedName(value = "value", alternate = {"steps"})
    private String value;
    // "activityCalories" is for Misfit, default "calory"
    @SerializedName(value = "calory", alternate = {"activityCalories"})
    private double calory;
    private boolean mIsMonth;

    public double getCalory() {
        return calory;
    }

    public void setCalory(double calory) {
        this.calory = calory;
    }

    public String getDateTime() {
        return dateTime;
    }

    public void setDateTime(String dateTime) {
        this.dateTime = dateTime;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public boolean getIsMonth() {
        return mIsMonth;
    }

    public void setMonth(boolean isMonth) {
        mIsMonth = isMonth;
    }

   /* @Override
    public boolean equals(Object o) {

        if (o == this) return true;
        if (!(o instanceof FitBitStepsItem)) {
            return false;
        }
        FitBitStepsItem fitBitStepsItem = (FitBitStepsItem) o;
        return Objects.equals(dateTime, fitBitStepsItem.dateTime);
    }

    @Override
    public int hashCode() {
        return Objects.hash(dateTime);
    }*/
}
