package com.truworth.wellnesscorner.model;

public class ShareStepsBean {
    private int steps;
    private double stepsCompliance;
    private double estimatedDistance;
    private String memberName;
    private String memberImage;

    public int getSteps() {
        return steps;
    }

    public void setSteps(int steps) {
        this.steps = steps;
    }

    public double getStepsCompliance() {
        return stepsCompliance;
    }

    public void setStepsCompliance(double stepsCompliance) {
        this.stepsCompliance = stepsCompliance;
    }

    public double getEstimatedDistance() {
        return estimatedDistance;
    }

    public void setEstimatedDistance(double estimatedDistance) {
        this.estimatedDistance = estimatedDistance;
    }

    public String getMemberName() {
        return memberName;
    }

    public void setMemberName(String memberName) {
        this.memberName = memberName;
    }

    public String getMemberImage() {
        return memberImage;
    }

    public void setMemberImage(String memberImage) {
        this.memberImage = memberImage;
    }
}
