package com.twc.hramodule.fragments;

import android.annotation.SuppressLint;
import android.app.Fragment;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.view.KeyEvent;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;


import com.twc.hramodule.R;
import com.twc.hramodule.R2;
import com.twc.hramodule.model.requestbody.BaseMemberIdBody;
import com.twc.hramodule.model.response.GetHraResponse;
import com.twc.hramodule.rest.RestClient;
import com.twc.hramodule.utils.Constant;
import com.twc.hramodule.utils.DialogFactory;
import com.twc.hramodule.utils.HraConfig;
import com.twc.hramodule.utils.Utils;

import java.util.ArrayList;

import butterknife.BindView;
import butterknife.OnClick;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 If this code works it was written by Somesh Kumar on 21 October, 2016. If not, I don't know who wrote it.
 */
public class HraDetailedReportFragment extends BaseFragment {

    @BindView(R2.id.wv)
    WebView wv;
    @BindView(R2.id.progressBar)
    ProgressBar progressBar;
    private LinearLayoutManager layoutManager;

    public static Fragment newInstance(Bundle bundle) {
        HraDetailedReportFragment hraDetailedReportFragment = new HraDetailedReportFragment();
        hraDetailedReportFragment.setArguments(bundle);
        return hraDetailedReportFragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public int getFragmentLayout() {
        return R.layout.fragment_hra_detailed_report;
    }

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    public void onFragmentReady() {
        layoutManager = new LinearLayoutManager(getActivity());
        layoutManager.setOrientation(LinearLayoutManager.HORIZONTAL);
        wv.getSettings().setJavaScriptEnabled(true);
     //   wv.getSettings().setDomStorageEnabled(true);
        wv.setWebViewClient(new WebViewClient() {

            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
                progressBar.setVisibility(View.VISIBLE);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                progressBar.setVisibility(View.GONE);
            }

            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                Utils.showToast(getActivity(),"error loading page");
                progressBar.setVisibility(View.GONE);
            }
        });
        getDetailHraReport();
    }

    private void getDetailHraReport() {
        progressBar.setVisibility(View.VISIBLE);
        BaseMemberIdBody hraReportBody = new BaseMemberIdBody();
        hraReportBody.setMemberID(HraConfig.hraUser.getUserID());
        RestClient restClient = new RestClient(getActivity(), HraConfig.BASE_URL, HraConfig.DEBUG);
        restClient.getHraService().getHRAReport(hraReportBody).enqueue(new Callback<GetHraResponse>() {
            @Override
            public void onResponse(Call<GetHraResponse> call, Response<GetHraResponse> response) {
                if (isAdded() && getActivity() != null) {
                    if (response.body() != null && response.body().getData() != null) {
                        if (response.body().getStatus() == 0) {
                            GetHraResponse.DataBean mHraReport = response.body().getData();
                            progressBar.setVisibility(View.GONE);
                            wv.loadUrl(mHraReport.getHRAURL());

                        } else {
                            DialogFactory.getInstance().showAlertDialog(getActivity(), null, 0, getString(R.string.msg_api_response_failure), getString(R.string.str_ok), true);
                        }
                    } else {
                        DialogFactory.getInstance().showAlertDialog(getActivity(), null, 0, getString(R.string.msg_api_response_null), getString(R.string.str_ok), true);
                    }
                }
            }

            @Override
            public void onFailure(Call<GetHraResponse> call, Throwable t) {
                if (isAdded() && getActivity() != null) {
                    progressBar.setVisibility(View.GONE);
                    DialogFactory.getInstance().showAlertDialog(getActivity(), null, 0, getString(R.string.msg_api_response_failure), getString(R.string.str_ok), true);
                }
            }
        });
    }



    @OnClick({R2.id.ivCancelHRA, R2.id.ivHRABack})
    public void onClick(View view) {
        int i = view.getId();
        if (i == R.id.ivHRABack) {
            onBack();

        } else if (i == R.id.ivCancelHRA) {
            onBack();

        }
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        view.setFocusableInTouchMode(true);
        view.requestFocus();
        view.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (keyCode == KeyEvent.KEYCODE_BACK && event.getAction() == KeyEvent.ACTION_DOWN) {
                    onBack();
                    return true;
                }
                return false;
            }
        });
    }

    private void onBack() {
        getFragmentManager().popBackStack();
    }

}
