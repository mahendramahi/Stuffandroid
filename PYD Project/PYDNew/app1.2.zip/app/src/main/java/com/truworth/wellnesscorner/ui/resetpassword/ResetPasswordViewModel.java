package com.truworth.wellnesscorner.ui.resetpassword;


import android.databinding.BindingAdapter;
import android.databinding.ObservableBoolean;
import android.databinding.ObservableField;
import android.databinding.ObservableInt;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.ImageView;

import com.truworth.wellnesscorner.R;
import com.truworth.wellnesscorner.TheWellnessCornerApp;
import com.truworth.wellnesscorner.base.BaseViewModel;
import com.truworth.wellnesscorner.repo.LoginRepository;
import com.truworth.wellnesscorner.repo.model.request.EmailRequest;
import com.truworth.wellnesscorner.repo.model.response.ResetPasswordResponse;
import com.truworth.wellnesscorner.utils.CommonUtils;
import com.truworth.wellnesscorner.utils.RSAHelper;
import com.truworth.wellnesscorner.utils.SingleLiveEvent;

import javax.inject.Inject;

import io.reactivex.Observer;
import io.reactivex.annotations.NonNull;
import io.reactivex.disposables.Disposable;

/**
 * Created by rajeshs on 3/28/2018.
 */

public class ResetPasswordViewModel extends BaseViewModel {
    @Inject
    LoginRepository repository;
    public ObservableInt resetIcon = new ObservableInt();
    public ObservableField<String> email = new ObservableField<>();
    public ObservableField<String> emailError = new ObservableField<>();
    public ObservableBoolean enableContinue = new ObservableBoolean();
    public ObservableBoolean isEmailFilled = new ObservableBoolean();

    private final SingleLiveEvent<String> popBack = new SingleLiveEvent<>();

    public SingleLiveEvent<String> getPopBack() {
        return popBack;
    }

    private final SingleLiveEvent<Void> clearData = new SingleLiveEvent<>();

    public ResetPasswordViewModel() {
        TheWellnessCornerApp.getApp().component().inject(this);
    }

    public String checkEmail(ObservableField<String> email) {
        if (email.get() == null) {
            //isValidEmail.set(false);
            resetIcon.set(R.drawable.ic_red_cross);
            return null;
        } else if (!CommonUtils.isEmailValid(email.get())) {
            //isValidEmail.set(false);
            resetIcon.set(R.drawable.ic_red_cross);
            return "Email id not valid!";
        } else {
            //isValidEmail.set(true);
            resetIcon.set(R.drawable.ic_check);
            //notifyPropertyChanged(com.truworth.wellnesscorner.BR.isValidEmail);
            return null;
        }
    }

    public void setEmail(String email) {
        this.email.set(email);

    }

    public TextWatcher emailWatcher2() {
        return new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                //setEmail(charSequence.toString());
                resetIcon.set(R.drawable.reset_input_box_icon);
                email.set(charSequence.toString());
                emailError.set(checkEmail(email));
            }

            @Override
            public void afterTextChanged(Editable editable) {
                if (email.get().isEmpty()) {
                    enableContinue.set(false);
                    isEmailFilled.set(false);
                } else {
                    enableContinue.set(true);
                    isEmailFilled.set(true);
                }
            }
        };
    }


    public SingleLiveEvent<Void> getClearData() {
        return clearData;
    }

    public void onCrossIconClick() {
        if (isEmailFilled.get()) {
            emailError.set("");
            if (resetIcon.get() != R.drawable.ic_check) {
                clearData.call();
            }
        }
    }

    @BindingAdapter("imageResource")
    public static void setImageResource(ImageView imageView, int resource) {
        imageView.setImageResource(resource);
    }

    public void sendEmailToChangePassword() {
        enableContinue.set(false);
        setIsLoading(true);

        String encryptedEmail = RSAHelper.Encrypt(email.get());
        EmailRequest emailRequest = new EmailRequest();
        emailRequest.setEmail(encryptedEmail);
        repository.resetPassword(emailRequest).subscribe(new Observer<ResetPasswordResponse>() {
            @Override
            public void onSubscribe(@NonNull Disposable d) {

            }

            @Override
            public void onNext(@NonNull ResetPasswordResponse response) {
                if (!response.isHasError())
                    popBack.setValue(response.getData().getMessage());
                 else
                    emailError.set(response.getError().getMessage());

            }

            @Override
            public void onError(@NonNull Throwable e) {
                e.printStackTrace();
                setIsLoading(false);
                enableContinue.set(true);
            }

            @Override
            public void onComplete() {
                setIsLoading(false);
                enableContinue.set(true);
            }
        });

    }
}
