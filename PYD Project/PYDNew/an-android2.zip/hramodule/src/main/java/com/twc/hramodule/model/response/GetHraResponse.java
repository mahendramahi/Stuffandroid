package com.twc.hramodule.model.response;

import com.google.gson.annotations.SerializedName;

import java.util.List;

/**
 If this code works it was written by Somesh Kumar on 21 October, 2016. If not, I don't know who wrote it.
 */
public class GetHraResponse {

    private DataBean Data;
    private int status;

    public DataBean getData() {
        return Data;
    }

    public void setData(DataBean Data) {
        this.Data = Data;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public static class DataBean {
        private float BMI;
        private int Age;


        private String Gender;
        @SerializedName("HealthStatus")
        private List<String> HealthStatusImagesList;
        @SerializedName("Age_BMI")
        private List<String> AgeBMIImagesList;
        @SerializedName("Severe")
        private List<String> SevereImagesList;
        @SerializedName("High")
        private List<String> HighImagesList;
        @SerializedName("Moderate")
        private List<String> ModerateImagesList;

        public String getHRAURL() {
            return HRAURL;
        }

        public void setHRAURL(String HRAURL) {
            this.HRAURL = HRAURL;
        }

        private  String HRAURL;

        public float getBMI() {
            return BMI;
        }

        public void setBMI(float BMI) {
            this.BMI = BMI;
        }

        public int getAge() {
            return Age;
        }

        public void setAge(int Age) {
            this.Age = Age;
        }

        public String getGender() {
            return Gender;
        }

        public void setGender(String Gender) {
            this.Gender = Gender;
        }

        public List<String> getHealthStatusImagesList() {
            return HealthStatusImagesList;
        }

        public void setHealthStatusImagesList(List<String> HealthStatusImagesList) {
            this.HealthStatusImagesList = HealthStatusImagesList;
        }

        public List<String> getAgeBMIImagesList() {
            return AgeBMIImagesList;
        }

        public void setAgeBMIImagesList(List<String> AgeBMIImagesList) {
            this.AgeBMIImagesList = AgeBMIImagesList;
        }

        public List<String> getSevereImagesList() {
            return SevereImagesList;
        }

        public void setSevereImagesList(List<String> SevereImagesList) {
            this.SevereImagesList = SevereImagesList;
        }

        public List<String> getHighImagesList() {
            return HighImagesList;
        }

        public void setHighImagesList(List<String> HighImagesList) {
            this.HighImagesList = HighImagesList;
        }

        public List<String> getModerateImagesList() {
            return ModerateImagesList;
        }

        public void setModerateImagesList(List<String> ModerateImagesList) {
            this.ModerateImagesList = ModerateImagesList;
        }
    }
}
