package com.twc.dailylog.fragments;

import android.animation.ObjectAnimator;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.view.animation.DecelerateInterpolator;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.twc.dailylog.MealActivity;
import com.twc.dailylog.R;
import com.twc.dailylog.R2;
import com.twc.dailylog.adapter.TabsViewPagerAdapter;
import com.twc.dailylog.utils.NetworkFactory;
import com.twc.dailylog.utils.Utils;


import butterknife.BindView;
import butterknife.OnClick;

public class WeightTrackerFragment extends BaseFragment {

    private final Bundle bundle = new Bundle();
    @BindView(R2.id.pbWeight)
    ProgressBar pbWeight;
    @BindView(R2.id.tabLayout)
    TabLayout tabLayout;
    @BindView(R2.id.viewPager)
    ViewPager viewPager;
    @Nullable
    @BindView(R2.id.btnAddWeight)
    Button btnAddWeight;
    @BindView(R2.id.tvStartWeight)
    TextView tvStartWeight;

    @BindView(R2.id.tvTargetWeight)
    TextView tvTargetWeight;

    @BindView(R2.id.rlChangeWeight)
    RelativeLayout rlChangeWeight;
    @BindView(R2.id.rootView)
    LinearLayout rootView;
    @BindView(R2.id.tvCurrentWeight)
    TextView tvCurrentWeight;
    private double currentWeight, targetWeight, firstWeight;
    private Handler handler = new Handler();
    private Runnable runnable;
    private static final String ARG_CURRENT_WEIGHT = "currentWeight";
    private static final String ARG_FIRST_WEIGHT = "firstWeight";
    private static final String ARG_TARGET_WEIGHT = "targetWeight";

    public static WeightTrackerFragment newInstance(double currentWeight, double firstWeight, double targetWeight) {
        WeightTrackerFragment fragment = new WeightTrackerFragment();
        Bundle args = new Bundle();
        args.putDouble(ARG_CURRENT_WEIGHT,currentWeight );
        args.putDouble(ARG_FIRST_WEIGHT,firstWeight );
        args.putDouble(ARG_TARGET_WEIGHT,targetWeight );
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
        if (getArguments() != null) {
            currentWeight = getArguments().getDouble(ARG_CURRENT_WEIGHT);
            firstWeight = getArguments().getDouble(ARG_FIRST_WEIGHT);
            targetWeight = getArguments().getDouble(ARG_TARGET_WEIGHT);
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        handler.removeCallbacks(runnable);
    }

    @Override
    protected int getFragmentLayout() {
        return R.layout.fragment_weight_tracker;
    }

    @Override
    protected void onFragmentReady() {
        setupViewPager(viewPager);
        tabLayout.setupWithViewPager(viewPager);

        runnable = new Runnable() {
            @Override
            public void run() {
                setDataToUI();
            }
        };


        if (NetworkFactory.getInstance().isNetworkAvailable(getActivity())) {
            //WellnessCornerApp.getInstance().myDashboardApiCall(getActivity());
            handler.postDelayed(runnable,1500);
        }
        else {
            setDataToUI();
        }

    }

    @Override
    public void onResume() {
        super.onResume();
        ((MealActivity) getActivity()).showHomeAsUpEnableToolbar();
        ((MealActivity) getActivity()).setToolBarTitle("Weight Tracker");
    }

    @OnClick(R2.id.rlChangeWeight)
    public void addWeight() {
        bundle.putString("AddWeight", "targetweight");
        Utils.replaceFragment(getFragmentManager(), AddWeightFragment.newInstance(bundle), AddWeightFragment.class.getSimpleName(), true, R.id.fragmentContainerMeal);
    }
    @Nullable
    @OnClick(R2.id.btnAddWeight)
    public void addTargetWeight() {
        bundle.putString("AddWeight", "Currentweight");
        Utils.replaceFragment(getFragmentManager(), AddWeightFragment.newInstance(bundle), AddWeightFragment.class.getSimpleName(), true, R.id.fragmentContainerMeal);
    }

    private void setupViewPager(ViewPager viewPager) {
        TabsViewPagerAdapter adapter = new TabsViewPagerAdapter(getChildFragmentManager());
        Bundle bundle = new Bundle();
        WeightGraphFragment weightGraphFragment1 = WeightGraphFragment.newInstance(bundle);
        WeightLogFragment weightGraphFragment2 = WeightLogFragment.newInstance();
        adapter.addFragment(weightGraphFragment1, "Graph");
        adapter.addFragment(weightGraphFragment2, "Logs");

        viewPager.setAdapter(adapter);
    }

    private void setDataToUI() {
       /* if (WellnessCornerApp.getInstance().getMyDashboardResponse() != null &&
                WellnessCornerApp.getInstance().getMyDashboardResponse().getData() != null &&
                WellnessCornerApp.getInstance().getMyDashboardResponse().getData().getMemberInfo() != null) {
            currentWeight = WellnessCornerApp.getInstance().getMyDashboardResponse().getData().getMemberInfo().getLastTrackedWeight();
            targetWeight = WellnessCornerApp.getInstance().getMyDashboardResponse().getData().getMemberInfo().getMemberTargetWeight();
            firstWeight = WellnessCornerApp.getInstance().getMyDashboardResponse().getData().getMemberInfo().getFirstTrackedWeight();
*/
            tvStartWeight.setText(Utils.doubleToString( firstWeight) + " kg");
            tvCurrentWeight.setText(getString(R.string.current_weight) + Utils.doubleToString( currentWeight )+ " kg");
            tvTargetWeight.setText( Utils.doubleToString(targetWeight) + " kg");

            //handle the progress bar
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    double pbWeightValue;
                    /*if (currentWeight >= targetWeight) {
                        pbWeightValue = 100.0;

                    }
                    else if (currentWeight < firstWeight) {
                        pbWeightValue = 0.0;
                    } else {*/
                    pbWeightValue = ((firstWeight - currentWeight) / (firstWeight - targetWeight)) * 100;
                    // }

                    ObjectAnimator animation = ObjectAnimator.ofInt(pbWeight, "progress", (int) pbWeightValue);
                    animation.setDuration(500); // 0.5 second
                    animation.setInterpolator(new DecelerateInterpolator());
                    animation.start();
                }
            }, 500);
            // }
        //}
    }
}

