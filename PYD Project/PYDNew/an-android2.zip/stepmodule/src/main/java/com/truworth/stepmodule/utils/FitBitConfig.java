package com.truworth.stepmodule.utils;

/**
 * Created by ManishJ1 on 5/27/2016.
 */
public class FitBitConfig {

    public static final String BASE_URL ="https://api.fitbit.com/";
    public static final String CLIENT_SECRET = "d2599fd006bc070f65bb3a965fea56c1";
    public static final String E_FIT_BASE_URL = "http://demo.truworth.net/efit/api/";
    public static final String REDIRECT_URI = "Wellness://";
    public static final String MISFIT_BASE_URL="https://api.misfitwearables.com/auth/";
    public static final String MISFIT_AUTHORIZATION_CODE="authorization_code";
    public static final String MISFIT_REDIRECT_URI = "wellnessmisfit://";
    public static final String MISFIT_CLIENT_ID = "cZ7VYKRKvOS4nC9W";
    public static final String MISFIT_CLIENT_SECRET = "hqRKE1nDk3cWORYp6oStOziVigjri1HG";
    public static final String MISFIT_AUTHORIZATION_URL = "https://api.misfitwearables.com/auth/dialog/authorize?response_type=code&client_id="+MISFIT_CLIENT_ID+
            "&redirect_uri="+MISFIT_REDIRECT_URI+"&scope=tracking";
    public static final String GARMIN_CONSUMER_KEY = "15dea775-0f38-484f-9ad2-b568efb4cd51";
    public static final String GARMIN_CONSUMER_SECRET_KEY = "BW6i5HoKrYdNS2jvwoOItcLwCOEXqYoQSGi";
    public static final String GARMIN_OAUTH_BASE_URL = "https://connectapi.garmin.com/";
    public static final String GARMIN_AUTHORIZATION_URL = "https://connect.garmin.com/oauthConfirm?oauth_token=";
    public static final String GARMIN_API_URL = "https://healthapi.garmin.com/wellness-api/rest/";
    private static final String CLIENT_ID = "227QR4";
    public static final String AUTHORIZATION_URL = "https://www.fitbit.com/oauth2/authorize?response_type=token&client_id=" + CLIENT_ID +
            "&redirect_uri=" + REDIRECT_URI + "&scope=activity%20heartrate%20location%20nutrition%20profile%20settings%20sleep%20social%20weight&expires_in=31536000&prompt=login";
    /*https://api.misfitwearables.com/auth/dialog/authorize?response_type=code&client_id=cZ7VYKRKvOS4nC9W&redirect_uri=wellness&scope=tracking*/
}
