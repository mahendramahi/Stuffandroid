package com.truworth.wellnesscorner.repo.model.request;

import com.truworth.wellnesscorner.ui.step.StepsBean;

import java.util.List;

/**
 * If this code works it was written by Somesh Kumar on 18 January, 2017. If not, I don't know who wrote it.
 */
public class SaveDeviceStepsBody {

    private int MemberID;
    private String Device;
    private List<StepsBean> steps;
    private List<StepsBean> calories;

    public int getMemberID() {
        return MemberID;
    }

    public void setMemberID(int MemberID) {
        this.MemberID = MemberID;
    }

    public List<StepsBean> getSteps() {
        return steps;
    }

    public void setSteps(List<StepsBean> steps) {
        this.steps = steps;
    }

    public String getDevice() {
        return Device;
    }

    public void setDevice(String Device) {
        this.Device = Device;
    }

    public List<StepsBean> getCalories() {
        return calories;
    }

    public void setCalories(List<StepsBean> calories) {
        this.calories = calories;
    }
}
