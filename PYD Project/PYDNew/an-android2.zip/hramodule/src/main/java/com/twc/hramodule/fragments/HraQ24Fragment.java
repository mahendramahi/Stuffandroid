package com.twc.hramodule.fragments;

import android.app.Activity;
import android.app.Fragment;
import android.content.Context;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.twc.greendaolib.GreenDaoApp;
import com.twc.greendaolib.HraDBItem;
import com.twc.greendaolib.HraDBItemDao;
import com.twc.hramodule.HraActivity;
import com.twc.hramodule.R;
import com.twc.hramodule.R2;
import com.twc.hramodule.adapter.HraAdapter;
import com.twc.hramodule.interfaces.OnHraDbAction;
import com.twc.hramodule.model.beans.HraItem;
import com.twc.hramodule.utils.Utils;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;

/**
 * Created by GurvinderS on 10/6/2016.
 */
public class HraQ24Fragment extends BaseFragment {

    private static final long QUESTION_ID = 28;
    private static final String SCREEN_NO = "21";
    @BindView(R2.id.background)
    RelativeLayout background;

    @BindView(R2.id.ivQuestionImage)
    ImageView ivQuestionImage;


    @BindView(R2.id.tvQuestionTitle)
    TextView tvQuestionTitle;

    @BindView(R2.id.tvQuestionNo)
    TextView tvQuestionNo;

    @BindView(R2.id.tvQuestionType)
    TextView tvQuestionType;

    @BindView(R2.id.rvHraAnswerOptions)
    RecyclerView rvHraAnswerOptions;

    @BindView(R2.id.btnNextQuestion)
    Button btnNextQuestion;
    @BindView(R2.id.ivHRABack)
    ImageView ivHRABack;

    @BindView(R2.id.ivCancelHRA)
    ImageView ivCancelHRA;

    private ArrayList<HraItem> answerList;
    private HraAdapter hraAdapter;
    private OnHraDbAction onHraDbAction;
    private HraDBItemDao hraDBDao;

    public static HraQ24Fragment newInstance(Bundle bundle) {
        HraQ24Fragment fragment = new HraQ24Fragment();
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    public int getFragmentLayout() {
        return R.layout.fragment_hra_type1;
    }

    @Override
    public void onFragmentReady() {

        answerList = new ArrayList<>();
        rvHraAnswerOptions.setHasFixedSize(true);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getActivity());
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        rvHraAnswerOptions.setLayoutManager(linearLayoutManager);

        String[] hraQuestion = getActivity().getResources().getStringArray(R.array.hra_questions);
        String[] hraAnswer = getActivity().getResources().getStringArray(R.array.hra_que28_row);

        setHraQuestion(hraQuestion[29], hraAnswer);

    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        onHraDbAction = (OnHraDbAction) context;
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        onHraDbAction = (OnHraDbAction) activity;
    }

    @Override
    public void onResume() {
        super.onResume();

        super.onResume();

        getView().setFocusableInTouchMode(true);
        getView().requestFocus();
        getView().setOnKeyListener(new View.OnKeyListener() {

            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (keyCode == KeyEvent.KEYCODE_BACK && event.getAction() == KeyEvent.ACTION_DOWN) {
                    onBack();
                    return true;
                }
                return false;
            }
        });

    }

    private void setHraQuestion(String question, String[] hraAnswer) {
        tvQuestionType.setText("LIFESTYLE");
        tvQuestionNo.setText("24");
        tvQuestionTitle.setText(question);
        ivQuestionImage.setBackgroundResource(R.drawable.image_q_24);

        for (String ans : hraAnswer) {
            String[] splitArray = ans.split("~");
            String id = splitArray[0];
            String name = splitArray[1];
            HraItem item = new HraItem();
            item.setQuestionID(QUESTION_ID);
            item.setAnswerID(id);
            item.setAnswer(name);
            item.setScreenNo(SCREEN_NO);
            answerList.add(item);

        }
        // get previous selected answer from database
        String answer = "";
        hraDBDao = GreenDaoApp.getInstance(getActivity()).getDaoSession(getActivity()).getHraDBItemDao();
        List<HraDBItem> answerFromDb = hraDBDao.queryBuilder().where(HraDBItemDao.Properties.QuestionId.eq(QUESTION_ID)).list();
        for (HraDBItem hraDBItem : answerFromDb) {
            answer = hraDBItem.getAnswer();
        }
        String[] arr = answer.split("/");
        for (int i = 0; i < answerList.size(); i++) {
            HraItem hraItem = answerList.get(i);
            String answerId = answerList.get(i).getAnswerID();
            for (String selectedAnswerId : arr) {
                if (answerId.equalsIgnoreCase(selectedAnswerId)) {
                    hraItem.setSelected(true);
                    answerList.set(i, hraItem);
                    break;
                }
            }
        }
        hraAdapter = new HraAdapter(answerList, getActivity(), true);
        rvHraAnswerOptions.setAdapter(hraAdapter);
    }

    @OnClick({R2.id.btnNextQuestion, R2.id.ivCancelHRA, R2.id.ivHRABack})
    public void onClick(View view) {
        int i = view.getId();
        if (i == R.id.ivHRABack) {
            onBack();

        } else if (i == R.id.ivCancelHRA) {
            cancelHra();

        } else if (i == R.id.btnNextQuestion) {
            StringBuilder stringBuilder = new StringBuilder();
            for (HraItem hraItem : hraAdapter.getSelectedAnswers()) {
                if (hraItem.isSelected()) {
                    stringBuilder.append(hraItem.getAnswerID()).append("/");
                }
            }
            if (stringBuilder.length() > 0) {
                stringBuilder.setLength(stringBuilder.length() - 1);
                String mergedAnswer = stringBuilder.toString();
                onHraDbAction.onHraQuestionSave(QUESTION_ID, mergedAnswer, SCREEN_NO, 0);
            } else {
                Utils.showToast(getActivity(), getString(R.string.pls_select_an_answer));
                return;
            }
            Utils.replaceFragment(getFragmentManager(), HraQ25And26Fragment.newInstance(getArguments()), HraQ25And26Fragment.class.getSimpleName(), true, R.id.fragmentContainerHra);

        } else {
        }
    }

    private void onBack() {

        List<HraDBItem> answerFromDb = hraDBDao.queryBuilder().where(HraDBItemDao.Properties.QuestionId.eq("27")).limit(1).list();

        Fragment fragment;
        if (String.valueOf(answerFromDb.get(0).getScreeNo()).equalsIgnoreCase("20.1")) {
            fragment = HraQ23YesFragment.newInstance(getArguments());
            Utils.replaceFragmentHraBackAnimation(getFragmentManager(), fragment, HraQ23YesFragment.class.getSimpleName(), true, R.id.fragmentContainerHra);
        } else if (String.valueOf(answerFromDb.get(0).getScreeNo()).equalsIgnoreCase("20.2")) {
            fragment = HraQ23IGaveUpFragment.newInstance(getArguments());
            Utils.replaceFragmentHraBackAnimation(getFragmentManager(), fragment, HraQ23IGaveUpFragment.class.getSimpleName(), true, R.id.fragmentContainerHra);
        } else {
            fragment = HraQ23Fragment.newInstance(getArguments());
            Utils.replaceFragmentHraBackAnimation(getFragmentManager(), fragment, HraQ23Fragment.class.getSimpleName(), true, R.id.fragmentContainerHra);
        }
    }

    private void cancelHra() {
        // if isRetakeTest parameter is true, then user always came here from hra report
        if (getArguments().containsKey("isRetakeTest") && getArguments().getBoolean("isRetakeTest")) {
            getFragmentManager().popBackStackImmediate(HraRiskGradeFragment.class.getSimpleName(), 0);
        } else {
            getActivity().finish();
        }
    }
}
