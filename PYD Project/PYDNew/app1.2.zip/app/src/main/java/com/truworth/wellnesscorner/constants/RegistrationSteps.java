package com.truworth.wellnesscorner.constants;

/**
 * Created by rajeshs on 4/11/2018.
 */

public class RegistrationSteps {
    public static final int PROFILE = 0;
    public static final int MOBILE_NUMBER = 1;
    public static final int HEIGHT_WEIGHT_BMI = 2;
    public static final int LOCATION_ADDRESS = 3;
    public static final int EDIT_PROFILE = 4;
    public static final int HEALTH_GOALS = 5;

}
