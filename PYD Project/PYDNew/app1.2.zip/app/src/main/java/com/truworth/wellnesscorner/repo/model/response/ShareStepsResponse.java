package com.truworth.wellnesscorner.repo.model.response;

import com.truworth.wellnesscorner.model.ShareStepsBean;

public class ShareStepsResponse {


    private ShareStepsBean data;
    private boolean hasError;
    private Object error;

    public ShareStepsBean getData() {
        return data;
    }

    public void setData(ShareStepsBean data) {
        this.data = data;
    }

    public boolean isHasError() {
        return hasError;
    }

    public void setHasError(boolean hasError) {
        this.hasError = hasError;
    }

    public Object getError() {
        return error;
    }

    public void setError(Object error) {
        this.error = error;
    }
}
