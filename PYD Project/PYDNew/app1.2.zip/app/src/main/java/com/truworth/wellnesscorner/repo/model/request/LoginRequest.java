package com.truworth.wellnesscorner.repo.model.request;

/**
 * Created by rajeshs on 3/29/2018.
 */

public class LoginRequest {
    String Email;
    String Password;

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String password) {
        Password = password;
    }
}
