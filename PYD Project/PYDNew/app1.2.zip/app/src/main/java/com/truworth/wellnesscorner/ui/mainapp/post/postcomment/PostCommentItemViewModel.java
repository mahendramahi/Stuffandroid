package com.truworth.wellnesscorner.ui.mainapp.post.postcomment;

import android.databinding.BaseObservable;
import android.databinding.ObservableBoolean;
import android.databinding.ObservableField;
import android.view.View;

import com.truworth.wellnesscorner.TheWellnessCornerApp;
import com.truworth.wellnesscorner.customviews.CustomTextView;
import com.truworth.wellnesscorner.model.CommentListData;
import com.truworth.wellnesscorner.repo.DashboardRepository;
import com.truworth.wellnesscorner.repo.model.request.BaseRequest;
import com.truworth.wellnesscorner.repo.model.request.CommentHiFiveRequest;
import com.truworth.wellnesscorner.repo.model.response.PostHiFiResponse;

import javax.inject.Inject;

import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;

public class PostCommentItemViewModel extends BaseObservable {
    public ObservableField<String> hiFiValue = new ObservableField<>();
    public ObservableBoolean isHiFiVisible = new ObservableBoolean();
    @Inject
    DashboardRepository dashboardRepository;
    private CommentListData commentListData;


    public PostCommentItemViewModel(CommentListData commentListData) {
        this.commentListData = commentListData;
        TheWellnessCornerApp.getApp().component().inject(this);
        isHiFiVisible.set(false);
    }

    public void getHiFive() {
        if (commentListData.getTotalHiFives() > 0)
            isHiFiVisible.set(true);
        else
            isHiFiVisible.set(false);
        hiFiValue.set(String.valueOf(commentListData.getTotalHiFives()));
    }

    public CommentListData getCommentListData() {
        return commentListData;
    }

    public void commentHiFiveApiCall(View view, String commentIdentity) {
        CustomTextView tv = ((CustomTextView) view);
        BaseRequest hiFiveRequest = new BaseRequest();
        hiFiveRequest.setId(commentIdentity);

        dashboardRepository.getCommentHiFi(hiFiveRequest).subscribe(new Observer<PostHiFiResponse>() {
            @Override
            public void onSubscribe(Disposable d) {

            }

            @Override
            public void onNext(PostHiFiResponse hiFiResponse) {
                if (!hiFiResponse.getHasError()) {
                    if (hiFiResponse.getData().isHiFive()) {
                        tv.setSelected(true);
                        tv.setFontBold();
                    } else {
                        tv.setSelected(false);
                        tv.setFontMedium();
                    }
                    if (hiFiResponse.getData().getTotalLike() > 0) {
                        isHiFiVisible.set(true);
                        hiFiValue.set(String.valueOf(hiFiResponse.getData().getTotalLike()));
                    }else
                        isHiFiVisible.set(false);
                }
            }

            @Override
            public void onError(Throwable e) {

            }

            @Override
            public void onComplete() {

            }
        });
    }
}
