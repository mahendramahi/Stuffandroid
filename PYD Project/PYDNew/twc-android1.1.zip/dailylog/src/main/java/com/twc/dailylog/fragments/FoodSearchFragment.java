package com.twc.dailylog.fragments;

import android.app.SearchManager;
import android.content.Context;
import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.SearchView;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import com.twc.dailylog.R;
import com.twc.dailylog.R2;
import com.twc.dailylog.adapter.TabsViewPagerAdapter;
import com.twc.dailylog.interfaces.ISearchResultCallback;
import com.twc.dailylog.model.beans.FoodSearchTypeItem;
import com.twc.dailylog.utils.Utils;

import java.util.List;
import java.util.Locale;

import butterknife.BindView;

/**
 * Created by Manish Jain on 7/5/2016.
 */
public class FoodSearchFragment extends BaseFragment {

    @BindView(R2.id.tabLayout)
    TabLayout tabLayout;

    @BindView(R2.id.viewPager)
    ViewPager viewPager;

    TabsViewPagerAdapter adapter;
    String currentSearchContent = "";
    private ISearchResultCallback mAllSearchResultCallback;
    private ISearchResultCallback mRecentSearchResultCallback;
    private ISearchResultCallback mPrefSearchResultCallback;
    private ISearchResultCallback mSuggestedSearchResultCallback;
    private SearchView searchView;
    private SearchView.OnQueryTextListener queryTextListener;
    private String lastSearchContent = "";
    private List<FoodSearchTypeItem> mList;

    public static FoodSearchFragment newInstance(Bundle bundle) {
        FoodSearchFragment foodSearchFragment = new FoodSearchFragment();
        foodSearchFragment.setArguments(bundle);
        return foodSearchFragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
        setRetainInstance(true);

        setupViewPager();

        if(getArguments()!=null)
        {
            currentSearchContent = getArguments().getString("searchString");

        }

    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.menu_search, menu);

        final MenuItem searchItem = menu.findItem(R.id.action_search);

        SearchManager searchManager = (SearchManager) getActivity().getSystemService(Context.SEARCH_SERVICE);

        if (searchItem != null) {
            searchView = (SearchView) searchItem.getActionView();
        }
        if (searchView != null) {
            searchView.setSearchableInfo(searchManager.getSearchableInfo(getActivity().getComponentName()));
            searchView.setIconified(true);
            searchView.onActionViewExpanded();
            searchView.setQueryHint("Search");

            queryTextListener = new SearchView.OnQueryTextListener() {
                @Override
                public boolean onQueryTextSubmit(String query) {
                    if (query.trim().length() >= 3) {
                        lastSearchContent = currentSearchContent;
                        currentSearchContent = query.trim();
                        if (getCurrentTab() == 0) {
                            if (mAllSearchResultCallback != null) {
                                mAllSearchResultCallback.onTextSubmitSuccess(currentSearchContent, lastSearchContent);
                            }
                        } else if (getCurrentTab() == 1) {
                            if (mRecentSearchResultCallback != null) {
                                mRecentSearchResultCallback.onTextSubmitSuccess(currentSearchContent, lastSearchContent);
                            }
                        } else if (getCurrentTab() == 2) {
                            if (mPrefSearchResultCallback != null) {
                                mPrefSearchResultCallback.onTextSubmitSuccess(currentSearchContent, lastSearchContent);
                            }
                        } else if (getCurrentTab() == 3) {
                            if (mSuggestedSearchResultCallback != null) {
                                mSuggestedSearchResultCallback.onTextSubmitSuccess(currentSearchContent, lastSearchContent);
                            }
                        }
                    }
                    Utils.printLog("onQueryTextSubmit", query);

                    return true;
                }

                @Override
                public boolean onQueryTextChange(String newText) {
                    Utils.printLog("onQueryTextChange", newText);
                    if (newText.trim().length() >= 3) {
                        if (getCurrentTab() == 0) {
                            if (mAllSearchResultCallback != null) {
                                mAllSearchResultCallback.onTextChangedSuccess(newText);
                            }
                        } else if (getCurrentTab() == 1) {
                            if (mRecentSearchResultCallback != null) {
                                mRecentSearchResultCallback.onTextChangedSuccess(newText);
                            }
                        } else if (getCurrentTab() == 2) {
                            if (mPrefSearchResultCallback != null) {
                                mPrefSearchResultCallback.onTextChangedSuccess(newText);
                            }
                        } else if (getCurrentTab() == 3) {
                            if (mSuggestedSearchResultCallback != null) {
                                mSuggestedSearchResultCallback.onTextChangedSuccess(newText);
                            }
                        }
                    }
                    return true;
                }
            };
            searchView.setOnQueryTextListener(queryTextListener);
            if (currentSearchContent != null && currentSearchContent.trim().length() > 0) {
                searchView.setQuery(currentSearchContent, true);
            }
        }
        super.onCreateOptionsMenu(menu, inflater);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int i = item.getItemId();
        if (i == R.id.action_search) {// Not implemented here
            return false;
        } else {
        }
        searchView.setOnQueryTextListener(queryTextListener);
        return super.onOptionsItemSelected(item);
    }

    @Override
    public int getFragmentLayout() {
        return R.layout.fragment_food_search;
    }

    @Override
    public void onFragmentReady() {

        viewPager.setAdapter(adapter);
        tabLayout.setupWithViewPager(viewPager);

        for (int i = 0; i < tabLayout.getTabCount(); i++) {
            TabLayout.Tab tab = tabLayout.getTabAt(i);

            View v = View.inflate(getActivity(),R.layout.row_tab_food_search, null);
            TextView tvFoodSearchType = v.findViewById(R.id.tvFoodSearchType);
            TextView tvFoodSearchCount = v.findViewById(R.id.tvFoodSearchCount);
            tvFoodSearchCount.setText("(0)");
            tvFoodSearchType.setText(adapter.getPageTitle(i));
            assert tab != null;
            tab.setCustomView(v);
        }


        viewPager.addOnPageChangeListener(new ViewPager.SimpleOnPageChangeListener() {

            @Override
            public void onPageSelected(int position) {
                super.onPageSelected(position);
                switch (position) {
                    case 0: //ALL
                        if (mAllSearchResultCallback != null) {
                            mAllSearchResultCallback.onTextSubmitSuccess(currentSearchContent, lastSearchContent);
                        }
                        break;

                    case 1: //RECENT
                        if (mRecentSearchResultCallback != null) {
                            mRecentSearchResultCallback.onTextSubmitSuccess(currentSearchContent, lastSearchContent);
                        }
                        break;

                    case 2: //PREFERRED
                        if (mPrefSearchResultCallback != null) {
                            mPrefSearchResultCallback.onTextSubmitSuccess(currentSearchContent, lastSearchContent);
                        }
                        break;

                    case 3: //POPULAR
                        if (mSuggestedSearchResultCallback != null) {
                            mSuggestedSearchResultCallback.onTextSubmitSuccess(currentSearchContent, lastSearchContent);
                        }
                        break;
                }

            }
        });
    }

    private void setupViewPager() {
        adapter = new TabsViewPagerAdapter(getChildFragmentManager());

        FoodSearchTypeFragment allFoodSearchTypeFragment = FoodSearchTypeFragment.newInstance();
        mAllSearchResultCallback = allFoodSearchTypeFragment;

        FoodSearchTypeFragment recentFoodSearchTypeFragment = FoodSearchTypeFragment.newInstance();
        mRecentSearchResultCallback = recentFoodSearchTypeFragment;

        FoodSearchTypeFragment preFoodSearchTypeFragment = FoodSearchTypeFragment.newInstance();
        mPrefSearchResultCallback = preFoodSearchTypeFragment;

        FoodSearchTypeFragment suggestFoodSearchTypeFragment = FoodSearchTypeFragment.newInstance();
        mSuggestedSearchResultCallback = suggestFoodSearchTypeFragment;

        adapter.addFragment(allFoodSearchTypeFragment, "ALL");
        adapter.addFragment(recentFoodSearchTypeFragment, "RECENT");
        adapter.addFragment(preFoodSearchTypeFragment, "PREFERRED");
        adapter.addFragment(suggestFoodSearchTypeFragment, "POPULAR");

    }

    public void updateTabsCountList(List<FoodSearchTypeItem> list) {
        mList = list;
        updateTabsCountValues();
    }

    public void updateTabsCountValues() {
        // Iterate over all tabs and set the custom view
        if(tabLayout!=null) {
            for (int i = 0; i < mList.size(); i++) {
                TabLayout.Tab tab = tabLayout.getTabAt(i);
                assert tab != null;
                View v = tab.getCustomView();
                assert v != null;
                TextView tvFoodSearchCount = v.findViewById(R.id.tvFoodSearchCount);
                tvFoodSearchCount.setText(String.format(Locale.getDefault(), "(%d)", mList.get(i).getTotalCount()));
            }
        }
    }

    public int getCurrentTab() {
        return viewPager.getCurrentItem();
    }
}
