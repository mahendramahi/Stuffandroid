package com.twc.hramodule.model.beans;

/**
 * Created by ManishJ1 on 3/20/2018.
 */

public class HraUser {

    private String userID;
    private String gender;
    private String userType;
    private String accessToken;

    public HraUser() {

    }

    public HraUser(String userID, String gender, String userType, String accessToken) {
        this.userID = userID;
        this.gender = gender;
        this.userType = userType;
        this.accessToken = accessToken;
    }

    public String getAccessToken() {
        return accessToken;
    }

    public void setAccessToken(String accessToken) {
        this.accessToken = accessToken;
    }

    public String getUserID() {
        return userID;
    }

    public void setUserID(String userID) {
        this.userID = userID;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getUserType() {
        return userType;
    }

    public void setUserType(String userType) {
        this.userType = userType;
    }
}
