package com.truworth.wellnesscorner.interfaces;

import com.truworth.wellnesscorner.model.ViewPreviousItem;

public interface OnPostItemClickListener {
    void onItemClick(ViewPreviousItem previousItem, int position);

}
