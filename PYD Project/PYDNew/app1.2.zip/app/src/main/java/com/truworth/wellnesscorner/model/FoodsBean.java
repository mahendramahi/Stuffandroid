package com.truworth.wellnesscorner.model;

import java.io.Serializable;

public class FoodsBean implements Serializable {
    private String name;
    private double calorie;
    private double carbs;
    private double fat;
    private double protein;
    private double quantity;
    private String serving;
    public boolean isItemChecked;

    public boolean isItemChecked() {
        return isItemChecked;
    }

    public void setItemChecked(boolean itemChecked) {
        isItemChecked = itemChecked;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getCalorie() {
        return calorie;
    }

    public void setCalorie(double calorie) {
        this.calorie = calorie;
    }

    public double getCarbs() {
        return carbs;
    }

    public void setCarbs(double carbs) {
        this.carbs = carbs;
    }

    public double getFat() {
        return fat;
    }

    public void setFat(double fat) {
        this.fat = fat;
    }

    public double getProtein() {
        return protein;
    }

    public void setProtein(double protein) {
        this.protein = protein;
    }

    public double getQuantity() {
        return quantity;
    }

    public void setQuantity(double quantity) {
        this.quantity = quantity;
    }

    public String getServing() {
        return serving;
    }

    public void setServing(String serving) {
        this.serving = serving;
    }
}
