package com.truworth.wellnesscorner.ui.mainapp.circledetail.challenges;

import android.arch.lifecycle.ViewModelProviders;
import android.content.Context;
import android.content.Intent;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;

import com.truworth.wellnesscorner.R;
import com.truworth.wellnesscorner.databinding.ActivityChallengeLeaderboardBinding;

public class ChallengeLeaderBoardActivity extends AppCompatActivity {
    public static final String CHALLENGE_IDENTITY = "challengeIdentity";
    public static final String CHALLENGE_TYPE_IDENTITY = "challengeTypeId";
    public static final String ALL_TIME = "ALL_TIME";
    public static final String TODAY = "TODAY";
    private ChallengeLeaderBoardViewPagerAdapter mSectionsPagerAdapter;
    private ViewPager mViewPager;
    ActivityChallengeLeaderboardBinding binding;
    ChallengeLeaderBoardViewModel viewModel;
    private String ChallengeIdentity = "";
    private int ChallengeTypeId ;


    public static void start(Context context, String challengeIdentity,int challengeTypeId) {
        Intent intent = new Intent(context, ChallengeLeaderBoardActivity.class);
        intent.putExtra(CHALLENGE_IDENTITY, challengeIdentity);
        intent.putExtra(CHALLENGE_TYPE_IDENTITY,challengeTypeId);
        context.startActivity(intent);
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = DataBindingUtil.setContentView(this, R.layout.activity_challenge_leaderboard);
        viewModel = ViewModelProviders.of(this).get(ChallengeLeaderBoardViewModel.class);

        Toolbar toolbar = binding.challengeToolbar;
        setupToolbar(toolbar);
        toolbar.setTitle("Scoreboard");

        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            ChallengeIdentity = extras.getString(CHALLENGE_IDENTITY);
            ChallengeTypeId=extras.getInt(CHALLENGE_TYPE_IDENTITY);
        }
        // Create the adapter that will return a fragment for each of the three
        // primary sections of the activity.
        mSectionsPagerAdapter = new ChallengeLeaderBoardViewPagerAdapter(getSupportFragmentManager());
        mSectionsPagerAdapter.addFrag(ChallengeScoreboardFragment.newInstance(ChallengeIdentity,ChallengeTypeId,ALL_TIME), "All Time");
        mSectionsPagerAdapter.addFrag(ChallengeScoreboardFragment.newInstance(ChallengeIdentity,ChallengeTypeId,TODAY), "Today");
        binding.setViewModel(viewModel);
        binding.setPagerAdapter(mSectionsPagerAdapter);
        binding.tabLayout.setupWithViewPager(binding.container);

    }

    private void setupToolbar(Toolbar toolbar) {
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
            getSupportActionBar().setDisplayShowTitleEnabled(false);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_activity_circle_detail, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }
}




