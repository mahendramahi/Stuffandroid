package com.truworth.wellnesscorner.utils.fileuploader;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ContentResolver;
import android.net.Uri;
import android.os.AsyncTask;
import android.webkit.MimeTypeMap;

import com.transloadit.android.sdk.AndroidAsyncAssembly;
import com.transloadit.android.sdk.AndroidTransloadit;
import com.transloadit.sdk.async.AssemblyProgressListener;
import com.transloadit.sdk.exceptions.LocalOperationException;
import com.transloadit.sdk.exceptions.RequestException;
import com.transloadit.sdk.response.AssemblyResponse;

import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.Map;


public class FileUploader {
    // http://api2.transloadit.com/instances/bored"
    //let params = ["template_id" : templateIdentifier, "auth" : ["expires" : self.dateFormatter.string(from: date), "key" : self.apiKey], "blocking" : "true"] as [String : Any]
//let fields = ["path" : "memberimages"]
    String transloaditAPIKey = "8a6be32063ef11e88759ed752c64bc2a";// "TRANSLOADIT_API_KEY"
    String transloaditSecretKey = "72c3f3a08302ef1c629e26daa90b0b7ba367a477"; //"TRANSLOADIT_SECRET_KEY"
    String transloaditTemplate = "52f4c8d0640811e880858f0c3f064924";//"TRANSLOADIT_TEMPLATE_ID"
    public static final String TEMPLATE_ID_VIDEO = "f2f3fbc0655d11e8bf0863cf303930f7";
    public static final String TEMPLATE_ID_IMAGE = "bb9f8370655c11e89b23f370040b9d9d";
    /// FileUploadListener mListener;
    Activity mContext;
    AssemblyProgressListener mListener;
    private AndroidAsyncAssembly androidAsyncAssembly;

    public FileUploader(Activity context, AssemblyProgressListener listener) {
        this.mListener = listener;
        this.mContext = context;

        AndroidTransloadit transloadit = new AndroidTransloadit(transloaditAPIKey, transloaditSecretKey);


        androidAsyncAssembly = transloadit.newAssembly(mListener, context);

    }

//    public static String getMimeType(String url) {
//        String type = null;
//        String extension = MimeTypeMap.getFileExtensionFromUrl(url);
//        if (extension != null) {
//            type = MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension);
//        }
//        return type;
//    }

    private String getMimeType(Uri uri) {
        String mimeType = null;
        if (uri.getScheme().equals(ContentResolver.SCHEME_CONTENT)) {
            ContentResolver cr = mContext.getContentResolver();
            mimeType = cr.getType(uri);
        } else {
            String fileExtension = MimeTypeMap.getFileExtensionFromUrl(uri
                    .toString());
            mimeType = MimeTypeMap.getSingleton().getMimeTypeFromExtension(
                    fileExtension.toLowerCase());
        }
        return mimeType;
    }

    public void submitAssembly(Uri uri, String fileName, String ext,boolean isProfileImage) {
        String newFileName = fileName;
        String SaveToFolder = "socialpostfile";
        String Extension = ext;
        getMimeType(uri);
        try {
            androidAsyncAssembly.addFile(mContext.getContentResolver().openInputStream(uri), "file");

        } catch (FileNotFoundException e) {
            e.printStackTrace();
            // showError(e);
        }
        //        Map<String, Object> stepOptions = new HashMap<>();
//        stepOptions.put("width", 75);
//        stepOptions.put("height", 75);
//        stepOptions.put("resize_strategy", "pad");
//        androidAsyncAssembly.addStep("resize", "/image/resize", stepOptions);


        // Step 1- Scan file for Virus
//        Map<String, Object> stepScan = new HashMap<>();
//        stepScan.put("use", ":original");
//        stepScan.put("result", true);
//        stepScan.put("error_on_decline", true);
//        androidAsyncAssembly.addStep("virus_scanned", "/file/virusscan", stepScan);
//
//        // Step 2- Apply file size filter
//        Map<String, Object> stepFilter = new HashMap<>();
//        stepFilter.put("use", "virus_scanned");
//        stepFilter.put("result", true);
//        stepFilter.put("accepts", new Object[]{new Object[]{"${file.mime}", "regex", "image"}, new Object[]{"${file.mime}", "regex", "video"}, new Object[]{"${file.mime}", "regex", "pdf"}});
//        //stepFilter.put("declines", JsonConvert.DeserializeObject<object>(JsonConvert.SerializeObject(filter)));
//        //stepFilter.put("accepts", JsonConvert.DeserializeObject<object>(JsonConvert.SerializeObject(filterMime)));
//        stepFilter.put("error_on_decline", true);
//        androidAsyncAssembly.addStep("files_filtered", "/file/filter", stepFilter);
        String mimeType = getMimeType(uri);
        if (mimeType.startsWith("image/")) {
            Map<String, Object> fields = new HashMap<>();
            //Map<String, Object> params = new HashMap<>();
            androidAsyncAssembly.addOption("template_id", TEMPLATE_ID_IMAGE);

            //  fields.put("params", params);
            fields.put("filename", newFileName+ "." + Extension);
            if (isProfileImage)
            {
                fields.put("path", "memberimages");
            }else{
                fields.put("path", "socialpostfile");
            }

            androidAsyncAssembly.addOption("fields",fields);



           /* Map<String, Object> stepOptimize = new HashMap<>();
            stepOptimize.put("use", "files_filtered");
            stepOptimize.put("progressive", true);
            stepOptimize.put("result", true);
            androidAsyncAssembly.addStep("optimized", "/image/optimize", stepOptimize);


            // Step 4- Store files on AWS server and Transloadit
            Map<String, Object> stepStore = new HashMap<>();
            stepStore.put("use", new Object[]{"virus_scanned", "files_filtered", "optimized", ":original"});
            stepStore.put("path", SaveToFolder + "/" + newFileName + "." + Extension);
            stepStore.put("credentials", "TWCDNMAIN");
            androidAsyncAssembly.addStep("thumb2", "/s3/store", stepStore);*/
        } else if (mimeType.startsWith("video/")) {


            Map<String, Object> fields = new HashMap<>();
            //Map<String, Object> params = new HashMap<>();
            androidAsyncAssembly.addOption("template_id", TEMPLATE_ID_VIDEO);

          //  fields.put("params", params);
            fields.put("filename", newFileName);
            fields.put("path", "socialpostfile");
            androidAsyncAssembly.addOption("fields",fields);



//            Map<String, Object> stepHlsEncode = new HashMap<>();
//            stepHlsEncode.put("use", "files_filtered");
//            stepHlsEncode.put("ffmpeg_stack", "v3.3.3");
//            stepHlsEncode.put("preset", "hls_720p"); // hls_720p, hls_360p, hls_270p
//            androidAsyncAssembly.addStep("hls_720p_video", "/video/encode", stepHlsEncode);
//
//            Map<String, Object> dcHls = new HashMap<>();
//            dcHls.put("steps", new Object[]{"hls_720p_video"});
//            dcHls.put("bundle_steps", true);
//
//            Map stepHlsAdaptive = new HashMap();
//            stepHlsAdaptive.put("use", dcHls);
//
//            stepHlsAdaptive.put("result", true);
//            stepHlsAdaptive.put("ffmpeg_stack", "v3.3.3");
//            stepHlsAdaptive.put("playlist_name", newFileName + ".m3u8");
//            stepHlsAdaptive.put("technique", "hls");
//            androidAsyncAssembly.addStep("hls_adapted", "/video/adaptive", stepHlsAdaptive);
//
//
//            // Step 6- Store files on AWS server and Transloadit
//            Map<String, Object> stepStore = new HashMap<>();
//            stepStore.put("use", new Object[]{":original", "virus_scanned", "files_filtered", "hls_adapted"});
//            stepStore.put("credentials", "TWCDNMAIN");
//            stepStore.put("path", SaveToFolder + "/${file.meta.relative_path}/${file.name}");
//            androidAsyncAssembly.addStep("adaptive_exported", "/s3/store", stepStore);

        }

        SaveTask saveTask = new SaveTask();
        saveTask.execute(true);
    }

    @SuppressLint("StaticFieldLeak")
    private class SaveTask extends AsyncTask<Boolean, Void, AssemblyResponse> {


        SaveTask() {
        }

        @Override
        protected void onPostExecute(AssemblyResponse response) {
//            activity.setStatus("Your androidAsyncAssembly is running on " + response.getUrl());
//            activity.setPauseButtonEnabled(true);
        }

        @Override
        protected AssemblyResponse doInBackground(Boolean... params) {
            try {
                return androidAsyncAssembly.save(params[0]);
            } catch (LocalOperationException e) {
                // showError(e);
            } catch (RequestException e) {
                e.printStackTrace();
                //  showError(e);
            }

            return null;
        }
    }
//    public interface FileUploadListener {
//        void onUploadSuccess();
//
//        void onUploadFail();
//    }
}
