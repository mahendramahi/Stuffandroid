package com.truworth.wellnesscorner.repo.model.response;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.truworth.wellnesscorner.model.MyCircle;

import java.util.ArrayList;

/**
 * Created by rajeshs on 4/13/2018.
 */

public class MyCirclesResponse {
    @SerializedName("error")
    @Expose
    private Error error;
    @SerializedName("data")
    @Expose
    private ArrayList<MyCircle> data;
    @SerializedName("hasError")
    @Expose
    private boolean hasError;

    public ArrayList<MyCircle> getData() {
        return data;
    }

    public void setData(ArrayList<MyCircle> data) {
        this.data = data;
    }

    public boolean isHasError() {
        return hasError;
    }

    public void setHasError(boolean hasError) {
        this.hasError = hasError;
    }

    public Error getError() {
        return error;
    }

    public void setError(Error error) {
        this.error = error;
    }


}
