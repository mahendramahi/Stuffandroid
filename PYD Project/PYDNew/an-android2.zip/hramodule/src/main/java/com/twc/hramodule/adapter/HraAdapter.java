package com.twc.hramodule.adapter;

/**
 * Created by GurvinderS on 8/5/2016.
 */

import android.app.Activity;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.RecyclerView;
import android.text.SpannableStringBuilder;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;


import com.twc.hramodule.R;
import com.twc.hramodule.model.beans.HraItem;
import com.twc.hramodule.utils.Utils;

import java.util.ArrayList;
import java.util.List;


/**
 * Created by Gurvinder on 7/5/2016.
 */
public class HraAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private CheckBox lastChecked = null;
    private int lastCheckedPos = 0;
    private List<HraItem> mHraItemArrayList;
    private Activity mActivity;
    String tabName;
    private boolean isRadioBtn;

    public HraAdapter(List<HraItem> mItemArrayList, Activity activity, boolean isRadioBtn) {
        this.mHraItemArrayList = mItemArrayList;
        this.mActivity = activity;
        this.isRadioBtn = isRadioBtn;
    }


    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_hra, parent, false);
        return new ItemViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, final int position) {
        ItemViewHolder itemViewHolder = (ItemViewHolder) holder;
        String option = mHraItemArrayList.get(position).getAnswer();
        if (option.contains("@#")) {
            String[] combination = option.split("@#");
            String subOption = combination[1].trim();
            SpannableStringBuilder modifiedText = Utils.makeSpecificTextSmall(mActivity, option.trim().replace("@#", ""), subOption.trim());
            itemViewHolder.tvAns.setText(modifiedText);

        } else {
            itemViewHolder.tvAns.setText(option);
        }

        itemViewHolder.checkBox.setChecked(mHraItemArrayList.get(position).isSelected());
        if (mHraItemArrayList.get(position).isSelected()) {
            itemViewHolder.tvAns.setTextColor(ContextCompat.getColor(mActivity, R.color.colorPrimary));
        } else {
            itemViewHolder.tvAns.setTextColor(ContextCompat.getColor(mActivity, R.color.color_000000));
        }
        itemViewHolder.checkBox.setTag(position);

        if (itemViewHolder.checkBox.isChecked()) {
            lastCheckedPos = position;
            lastChecked = itemViewHolder.checkBox;
        }
    }

    @Override
    public int getItemCount() {
        return (null != mHraItemArrayList ? mHraItemArrayList.size() : 0);
    }

    public ArrayList<HraItem> getSelectedAnswers() {
        ArrayList<HraItem> answerList = new ArrayList<>();
        for (HraItem hraItem : mHraItemArrayList) {
            if (hraItem.isSelected()) {
                answerList.add(hraItem);
            }
        }
        return answerList;
    }

    public class ItemViewHolder extends RecyclerView.ViewHolder {

        final TextView tvAns;
        final CheckBox checkBox;

        public ItemViewHolder(View itemView) {
            super(itemView);
            tvAns = itemView.findViewById(R.id.tvAns);
            checkBox = itemView.findViewById(R.id.checkBox);
            checkBox.setClickable(false);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    CheckBox cb = v.findViewById(R.id.checkBox);
                    TextView textView = v.findViewById(R.id.tvAns);
                    if (!isRadioBtn) {
                        int clickedPos = (Integer) cb.getTag();
                        HraItem item = mHraItemArrayList.get(clickedPos);

                        if (item.getAnswer().equalsIgnoreCase("None of these")) {
                            if (!cb.isChecked()) {
                                unSelectItem();
                            }
                        } else {
                            unSelectItemNoneOfthese();
                        }
                        cb.setChecked(!cb.isChecked());
                        item.setSelected(cb.isChecked());
                        mHraItemArrayList.get(clickedPos).setSelected(cb.isChecked());
                    } else {
                        cb.setChecked(!cb.isChecked());
                        int clickedPos = (Integer) cb.getTag();
                        if (cb.isChecked()) {
                            if (lastChecked != null) {
                                lastChecked.setChecked(false);
                                mHraItemArrayList.get(lastCheckedPos).setSelected(false);
                            }

                            lastChecked = cb;
                            lastCheckedPos = clickedPos;
                        } else {
                            lastChecked = null;
                        }
                        mHraItemArrayList.get(clickedPos).setSelected(cb.isChecked());
                    }
                }
            });
        }
    }

    private void unSelectItem() {
        for (int i = 0; i < mHraItemArrayList.size(); i++) {
            HraItem item = mHraItemArrayList.get(i);
            item.setSelected(false);
            mHraItemArrayList.set(i, item);
        }
        notifyDataSetChanged();
    }


    private void unSelectItemNoneOfthese() {
        for (int i = 0; i < mHraItemArrayList.size(); i++) {
            HraItem item = mHraItemArrayList.get(i);
            if (item.getAnswer().equalsIgnoreCase("None of these")) {
                item.setSelected(false);
                mHraItemArrayList.set(i, item);
                break;
            }
        }
        notifyDataSetChanged();
    }
}

