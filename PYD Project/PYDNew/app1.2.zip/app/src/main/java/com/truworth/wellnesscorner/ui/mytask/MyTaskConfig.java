package com.truworth.wellnesscorner.ui.mytask;

import android.util.Log;

public class MyTaskConfig {
    public static String APP_NAME = ""; //
    public static String BASE_URL = "http://192.168.1.91:9003/twcapi/";// default testing url
    public static boolean mdebug;
    public static MyTaskUser myTaskUser;


    public static void init(String appName, String apiBaseUrl, MyTaskUser user, boolean debug) {
        if (!appName.isEmpty() && !apiBaseUrl.isEmpty() && user != null) {
            BASE_URL = apiBaseUrl;
            APP_NAME = appName;
            myTaskUser = user;
            mdebug = debug;
        } else {
            Log.d("HRA", "init: " + apiBaseUrl);
            Log.d("HRA", "init: failed hralib. Please all fields of init.");
        }

    }
}
