package com.truworth.wellnesscorner.repo;

import com.truworth.wellnesscorner.network.ApiServices;
import com.truworth.wellnesscorner.repo.model.request.DeviceStepRequest;
import com.truworth.wellnesscorner.repo.model.response.GetMonthlyDeviceStepsResponse;
import com.truworth.wellnesscorner.repo.model.request.SaveDeviceStepsBody;
import com.truworth.wellnesscorner.repo.model.response.SaveStepsResponse;

import javax.inject.Inject;
import javax.inject.Singleton;
import io.reactivex.Observable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.schedulers.Schedulers;

@Singleton
public class StepRepository {
    private final ApiServices apiService;

    @Inject
    public StepRepository(ApiServices apiService) {

        this.apiService = apiService;
    }

    public Observable<SaveStepsResponse> saveDeviceSteps(SaveDeviceStepsBody request) {
        return apiService.saveDeviceSteps(request).subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread());
    }

    public Observable<GetMonthlyDeviceStepsResponse> getMemberStepsFromServer(DeviceStepRequest request) {
        return apiService.getMemberStepsFromServer(request).subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread());
    }

}
