package com.truworth.wellnesscorner.repo.model.response;

public class SaveCurrentWeightResponse {

    /**
     * status : 0
     */

    private int status;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }
}
