package com.truworth.wellnesscorner.ui.login;

import android.content.Context;
import android.databinding.BindingAdapter;
import android.databinding.ObservableBoolean;
import android.databinding.ObservableField;
import android.databinding.ObservableInt;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.widget.ImageView;

import com.truworth.wellnesscorner.R;
import com.truworth.wellnesscorner.TheWellnessCornerApp;
import com.truworth.wellnesscorner.base.BaseViewModel;
import com.truworth.wellnesscorner.network.NoConnectivityException;
import com.truworth.wellnesscorner.repo.LoginRepository;
import com.truworth.wellnesscorner.repo.model.request.EmailRequest;
import com.truworth.wellnesscorner.repo.model.response.EmailExistResponse;
import com.truworth.wellnesscorner.utils.CommonUtils;
import com.truworth.wellnesscorner.utils.RSAHelper;
import com.truworth.wellnesscorner.utils.SingleLiveEvent;

import javax.inject.Inject;

import io.reactivex.Observer;
import io.reactivex.annotations.NonNull;
import io.reactivex.disposables.Disposable;

/**
 * Created by rajeshs on 3/27/2018.
 */

public class LoginEmailViewModel extends BaseViewModel {
    public ObservableInt resetIcon = new ObservableInt();
    private SingleLiveEvent<String> moveToRegistration = new SingleLiveEvent<>();

    public SingleLiveEvent<String> getMoveToRegistration() {
        return moveToRegistration;
    }

    @Inject
    LoginRepository repository;
    public ObservableField<String> email = new ObservableField<>();
    public ObservableField<String> emailError = new ObservableField<>();

    public ObservableBoolean isEnableContinue = new ObservableBoolean();
    public ObservableBoolean isEmailFilled = new ObservableBoolean();
    public SingleLiveEvent<String> emailChecked = new SingleLiveEvent<>();


    public LoginEmailViewModel() {
        email.set("sunil.kumar@truworth.com");
        TheWellnessCornerApp.getApp().component().inject(this);
    }

    public boolean checkEmailValid(ObservableField<String> email) {
        if (email.get().isEmpty()) {
            //isEnableContinue.set(false);
            //resetIcon.set(R.drawable.ic_red_cross);
            emailError.set("Enter Email Id!");
            return false;
        } else if (!CommonUtils.isEmailValid(email.get())) {
                      // isEnableContinue.set(false);
            //resetIcon.set(R.drawable.ic_red_cross);
            emailError.set("Email id not valid!");
            return false;
        } else {
            //isEnableContinue.set(true);
            emailError.set("");
            //resetIcon.set(R.drawable.reset_input_box_icon);
            return true;
        }
    }

    public TextWatcher emailWatcher() {
        return new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                emailError.set("");

                if(email.get().isEmpty()) {
                    emailError.set("");
                    isEmailFilled.set(false);
                }
                else{
                    resetIcon.set(R.drawable.reset_input_box_icon);
                    isEmailFilled.set(true);
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        };
    }


    public void checkEmailExist() {
       if(checkEmailValid(email)){
           resetIcon.set(R.drawable.reset_input_box_icon);

           String encryptedEmail = RSAHelper.Encrypt(email.get());
           EmailRequest emailRequest = new EmailRequest();
           emailRequest.setEmail(encryptedEmail);

           setIsLoading(true);
           repository.checkEmailExist(emailRequest).subscribe(new Observer<EmailExistResponse>() {
               @Override
               public void onSubscribe(@NonNull Disposable d) {

               }

               @Override
               public void onNext(@NonNull EmailExistResponse response) {
                   setIsLoading(false);
                   if (!response.isHasError()) {
                       if (response.getData().isEmailExist()) {
                           resetIcon.set(R.drawable.ic_check);
                           emailChecked.setValue(email.get());
                       }
                       else
                           resetIcon.set(R.drawable.reset_input_box_icon);
                   } else {
                       if (response.getError().getCode() == 2) {
                           moveToRegistration.call();
                       }
                   }
               }

               @Override
               public void onError(@NonNull Throwable e) {
                   if (e instanceof NoConnectivityException) {
                       // No internet connection
                   }
                   e.printStackTrace();
                   setIsLoading(false);
               }

               @Override
               public void onComplete() {
                   setIsLoading(false);
               }
           });
       }
       else{
           resetIcon.set(R.drawable.ic_red_cross);
       }


    }
    private final SingleLiveEvent<Void> clearData = new SingleLiveEvent<>();
    public SingleLiveEvent<String> getEmailChecked() {
        return emailChecked;
    }

    public SingleLiveEvent<Void> getClearData() {
        return clearData;
    }
    public void onCrossIconClick(){
        if(isEmailFilled.get()){
            emailError.set("");
            if( resetIcon.get()!=R.drawable.ic_check)
                clearData.call();
        }
    }

    @BindingAdapter("imageResource")
    public static void setImageResource(ImageView imageView, int resource){
        imageView.setImageResource(resource);
    }
}

