package com.truworth.wellnesscorner.ui.mainapp;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.app.AppCompatDelegate;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import com.truworth.wellnesscorner.R;
import com.truworth.wellnesscorner.TheWellnessCornerApp;
import com.truworth.wellnesscorner.data.SharedPreferenceHelper;
import com.truworth.wellnesscorner.ui.mainapp.circle.CirclesFragment;
import com.truworth.wellnesscorner.ui.mainapp.more.MoreOptionsFragment;
import com.truworth.wellnesscorner.ui.mainapp.notifications.NotificationsFragment;
import com.truworth.wellnesscorner.ui.mainapp.today.TodayFragment;
import com.truworth.wellnesscorner.ui.mytask.MyTaskConfig;
import com.truworth.wellnesscorner.ui.mytask.MyTaskUser;
import com.truworth.wellnesscorner.utils.AppConstants;
import com.truworth.wellnesscorner.utils.NonSwipeableViewPager;
import com.twc.dailylog.model.beans.DailyLogUser;
import com.twc.dailylog.utils.DailyLogConfig;
import com.twc.dailylog.utils.WaterConfig;
import com.twc.remindermodule.model.beans.ReminderUser;
import com.twc.remindermodule.rest.ReminderConfig;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

public class HomeDashBoardActivity extends AppCompatActivity {

    //private TextView mTextMessage;

    @Inject
    SharedPreferenceHelper prefHelper;
    TabLayout tabLayout;
    NonSwipeableViewPager viewpager;
    private boolean isShownExit;

    static {
        AppCompatDelegate.setCompatVectorFromResourcesEnabled(true);
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_dash_board);

        TheWellnessCornerApp.getApp().component().inject(this);


        tabLayout = findViewById(R.id.bottomTabLayout);

        viewpager = findViewById(R.id.viewpager);

        viewpager.setOffscreenPageLimit(4);
        setupViewPager(viewpager);
        tabLayout.setupWithViewPager(viewpager);

        setupTabIcons();

        // init reminder config
        ReminderUser reminderUser = new ReminderUser("0", true, "bearer " + prefHelper.getToken());
        ReminderConfig.init("Wellness", AppConstants.API_ENDPOINT, reminderUser, false, HomeDashBoardActivity.this);


        // init MY_TASK CONFIG
        MyTaskUser taskUser = new MyTaskUser("0", "bearer " + prefHelper.getToken());
        MyTaskConfig.init("Wellness", AppConstants.API_ENDPOINT, taskUser, false);

      // daily log

        DailyLogUser dailyLogUser = new DailyLogUser("0", "", "",
                "bearer " + prefHelper.getToken());
        DailyLogConfig.init("Wellness", AppConstants.API_ENDPOINT, dailyLogUser, false);

        // water config

        WaterConfig.init("Wellness", AppConstants.API_ENDPOINT, false);

    }


    private void setupTabIcons() {
        View tabOne = LayoutInflater.from(this).inflate(R.layout.layout_tab_item, null);
        ImageView imgView = tabOne.findViewById(R.id.imgTab);
        imgView.setImageResource(R.drawable.ic_today_selector);


        View tabTwo = LayoutInflater.from(this).inflate(R.layout.layout_tab_item, null);
        ImageView imgViewTwo = tabTwo.findViewById(R.id.imgTab);
        imgViewTwo.setImageResource(R.drawable.ic_circle_selector);

        View tabThree = LayoutInflater.from(this).inflate(R.layout.layout_tab_item, null);
        ImageView imgViewThree = tabThree.findViewById(R.id.imgTab);
        imgViewThree.setImageResource(R.drawable.ic_notification_selector);

        View tabFour = LayoutInflater.from(this).inflate(R.layout.layout_tab_item, null);
        ImageView imgViewFour = tabFour.findViewById(R.id.imgTab);
        imgViewFour.setImageResource(R.drawable.ic_more_selector);

        tabLayout.getTabAt(0).setCustomView(tabOne);
        tabLayout.getTabAt(1).setCustomView(tabTwo);
        tabLayout.getTabAt(2).setCustomView(tabThree);
        tabLayout.getTabAt(3).setCustomView(tabFour);

    }

    private void setupViewPager(ViewPager viewPager) {
        ViewPagerAdapter adapter = new ViewPagerAdapter(getSupportFragmentManager());
        adapter.addFrag(new TodayFragment(), "");
        adapter.addFrag(new CirclesFragment(), "");
        adapter.addFrag(new NotificationsFragment(), "");
        adapter.addFrag(new MoreOptionsFragment(), "");
        viewPager.setAdapter(adapter);

    }

    private TabLayout.OnTabSelectedListener onTabSelectedListener(final ViewPager viewPager) {

        return new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                viewPager.setCurrentItem(tab.getPosition());
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        };
    }

    class ViewPagerAdapter extends FragmentPagerAdapter {
        private final List<Fragment> mFragmentList = new ArrayList<>();
        private final List<String> mFragmentTitleList = new ArrayList<>();

        public ViewPagerAdapter(FragmentManager manager) {
            super(manager);
        }

        @Override
        public Fragment getItem(int position) {
            return mFragmentList.get(position);
        }

        @Override
        public int getCount() {
            return mFragmentList.size();
        }

        public void addFrag(Fragment fragment, String title) {
            mFragmentList.add(fragment);
            mFragmentTitleList.add(title);
        }

        @Override
        public CharSequence getPageTitle(int position) {
            return null;
        }
    }

    @Override
    public void onBackPressed() {
        FragmentManager fm = getSupportFragmentManager();
        int count = fm.getBackStackEntryCount();
        if (count <= 1) {
            if (!isShownExit) {
                isShownExit = true;
                Toast.makeText(HomeDashBoardActivity.this, "Press again to exit", Toast.LENGTH_SHORT).show();
            } else {
                finish();
            }
        } else {
            isShownExit = false;
            super.onBackPressed();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        Fragment fragment = getSupportFragmentManager().findFragmentByTag("android:switcher:" + R.id.viewpager + ":" + viewpager.getCurrentItem());
        // based on the current position you can then cast the page to the correct Fragment class and call some method inside that fragment to reload the data:
        if (null != fragment) {
            fragment.onActivityResult(requestCode, resultCode, data);
        }

    }

    private boolean getCurrentFragmentName(String fragmentName) {
        FragmentManager fragmentManager = getSupportFragmentManager();
        if (fragmentManager.findFragmentByTag(fragmentName) != null) {
            String fragmentTag = fragmentManager.getBackStackEntryAt(fragmentManager.getBackStackEntryCount() - 1).getName();
            return fragmentTag.equalsIgnoreCase(fragmentName);
        } else
            return false;
    }
}
