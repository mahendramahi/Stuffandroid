package com.truworth.wellnesscorner.utils;

import android.text.format.DateFormat;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import static java.util.Calendar.DATE;
import static java.util.Calendar.MONTH;
import static java.util.Calendar.YEAR;

import org.joda.time.Days;

/**
 * Created by rajeshs on 4/4/2018.
 */

public class DateUtils {
    public static final String dd_MM_yyyy = "dd/MM/yyyy";
    public static final String yyyy_MM_dd = "yyyy-MM-dd";
    public static final String SERVER_DATE = "yyyy-MM-dd'T'HH:mm:ss";
    private static DateUtils dateFactory;


    private static Locale locale = Locale.US;

    private DateUtils() {
        // set locale
        locale = Locale.US;
    }

    public static DateUtils getInstance() {
        if (dateFactory == null) {
            dateFactory = new DateUtils();
        }

        return dateFactory;
    }

    public static String formatDate(String strDate, String fromFormat, String toFormat) {

        SimpleDateFormat fromDateFormat = new SimpleDateFormat(fromFormat, locale);
        SimpleDateFormat toDateFormat = new SimpleDateFormat(toFormat, locale);

        try {
            Date d = fromDateFormat.parse(strDate);

            return toDateFormat.format(d);
        } catch (Exception e) {
            //java.text.ParseException: Unparseable date: Geting error
            System.out.println("Excep" + e);
        }
        return "";
    }

    public static String formatDateStep(String formatSrc, String formatDest, String date) {
        String str;
        SimpleDateFormat sdf = new SimpleDateFormat(formatSrc, locale);
        try {
            Date myDate = sdf.parse(date);
            str = new SimpleDateFormat(formatDest, locale).format(myDate);
        } catch (ParseException e) {
            e.printStackTrace();
            return "";
        }
        return str;
    }

    public String getDateFromDateFormat(Date inputDate, String formatDest) {
        SimpleDateFormat sdf = new SimpleDateFormat(formatDest, locale);
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(inputDate);
        Date d = calendar.getTime();
        return sdf.format(d);
    }

    public static String truncateMilliseconds(String date) {
        String truncatedDate;
        truncatedDate = date.contains(".") ? date.substring(0, date.indexOf(".")) : date;
        return truncatedDate;

    }

    public static SimpleDateFormat getSimpleDateFormatInstance(String format) {
        return new SimpleDateFormat(format, locale);
    }

    public String daysDiffFromToday(String toDate, String format) {
        String inputDateString = toDate;
        Calendar calCurr = Calendar.getInstance();
        Calendar day = Calendar.getInstance();
        try {
            day.setTime(new SimpleDateFormat(format).parse(inputDateString));
        } catch (ParseException e) {
            e.printStackTrace();
        }
        if (day.after(calCurr)) {
            // System.out.println("Days Left: " + ) );
            return String.valueOf(day.get(Calendar.DAY_OF_MONTH) - (calCurr.get(Calendar.DAY_OF_MONTH)));
        } else {
            return "0";
        }
    }

    public static String getDayDifference(String endDate) {

        String startDate = DateUtils.getTodayDate("yyyy-MM-dd'T'HH:mm:ss");

        String daysDifference = "";
        if (startDate != null && endDate != null)
            daysDifference = DateUtils.getOnlyDaysDifference(startDate, endDate, "yyyy-MM-dd'T'HH:mm:ss");

        return daysDifference;
    }


    public static String getOnlyDaysDifference(String firstDate, String nextDate, String format) {
       /* long days = 0, hours = 0;
        SimpleDateFormat sdf = new SimpleDateFormat(format, locale);

        try {
            Date date1 = sdf.parse(firstDate);
            Date date2 = sdf.parse(nextDate);
            long diff = date2.getTime() - date1.getTime();
            long seconds = diff / 1000;
            long minutes = seconds / 60;
            hours = minutes / 60;
            days = hours / 24;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return String.valueOf(days);*/
        long days = 0;
        SimpleDateFormat sdf = new SimpleDateFormat(format, locale);

        try {
            Date date1 = sdf.parse(firstDate);
            Date date2 = sdf.parse(nextDate);
            long diff = date2.getTime() - date1.getTime();
            days = diff / (24 * 60 * 60 * 1000);

        } catch (Exception e) {
            e.printStackTrace();
        }
        return String.valueOf(days);
       /* String inputDateString = nextDate;
        Calendar calCurr = Calendar.getInstance();
        Calendar day = Calendar.getInstance();
        try {
            day.setTime(new SimpleDateFormat(format).parse(inputDateString));
        } catch (ParseException e) {
            e.printStackTrace();
        }
        if (day.after(calCurr)) {
            // System.out.println("Days Left: " + ) );
            return String.valueOf(day.get(Calendar.DAY_OF_MONTH) - (calCurr.get(Calendar.DAY_OF_MONTH)));
        } else {
            return "0";
        }*/

    }

    public static String getTodayDate(String outputFormat) {
        SimpleDateFormat sdf = new SimpleDateFormat(outputFormat, locale);
        return sdf.format(Calendar.getInstance().getTime());
    }


    public static int getDiffYears(Date first, Date last) {
        Calendar a = getCalendar(first);
        Calendar b = getCalendar(last);
        int diff = b.get(YEAR) - a.get(YEAR);
        if (a.get(MONTH) > b.get(MONTH) ||
                (a.get(MONTH) == b.get(MONTH) && a.get(DATE) > b.get(DATE))) {
            diff--;
        }
        return diff;
    }

    public static Calendar getCalendar(Date date) {
        Calendar cal = Calendar.getInstance(Locale.US);
        cal.setTime(date);
        return cal;
    }

    public static Date getDate(String inputDate, String formatSrc) {
        Date myDate = null;
        try {
            SimpleDateFormat sdf = new SimpleDateFormat(formatSrc, locale);
            myDate = sdf.parse(inputDate);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return myDate;


    }

    public static boolean isFutureDate(int dayToCheck, int monthToCheck, int yearToCheck) {
        Date currantDate = new Date();
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.DAY_OF_MONTH, dayToCheck);
        calendar.set(Calendar.MONTH, monthToCheck);
        calendar.set(Calendar.YEAR, yearToCheck);
        Date selectedDate = calendar.getTime();
        return selectedDate.after(currantDate);
    }

    public String getFormattedDate(long smsTimeInMilis) {
        Calendar smsTime = Calendar.getInstance();
        smsTime.setTimeInMillis(smsTimeInMilis);

        Calendar now = Calendar.getInstance();

        final String timeFormatString = "h:mm aa";
        final String dateTimeFormatString = "EEEE, MMMM d, h:mm aa";
        final long HOURS = 60 * 60 * 60;
        if (now.get(Calendar.DATE) == smsTime.get(Calendar.DATE)) {
            return "Today " + DateFormat.format(timeFormatString, smsTime);
        } else if (now.get(Calendar.DATE) - smsTime.get(Calendar.DATE) == 1) {
            return "Yesterday " + DateFormat.format(timeFormatString, smsTime);
        }
//        else if (now.get(Calendar.YEAR) == smsTime.get(Calendar.YEAR)) {
//            return DateFormat.format(dateTimeFormatString, smsTime).toString();
//        }
        else {
            return DateFormat.format("MMMM dd yyyy, h:mm aa", smsTime).toString();
        }
    }

    public String getFormattedDateForEvent(long smsTimeInMilis) {
        Calendar smsTime = Calendar.getInstance();
        smsTime.setTimeInMillis(smsTimeInMilis);

        //   Calendar now = Calendar.getInstance();

        final String timeFormatString = "h:mm aa";
//        final String dateTimeFormatString = "EEEE, MMMM d, h:mm aa";
//        final long HOURS = 60 * 60 * 60;
//        if (now.get(Calendar.DATE) == smsTime.get(Calendar.DATE)) {
//            return "Today " + DateFormat.format(timeFormatString, smsTime);
//        } else if (now.get(Calendar.DATE) - smsTime.get(Calendar.DATE) == 1) {
//            return "Yesterday " + DateFormat.format(timeFormatString, smsTime);
//        }
////        else if (now.get(Calendar.YEAR) == smsTime.get(Calendar.YEAR)) {
////            return DateFormat.format(dateTimeFormatString, smsTime).toString();
////        }
//        else {
        return DateFormat.format("EEE, MMM dd", smsTime).toString() + " AT " + DateFormat.format(timeFormatString, smsTime);
        // }
    }

    public static String showDateTimeUsingServerFormatDate(String date) {
        if (date != null && date.length() > 0) {
            String currentDateTime = getTodayStartTimeInFormat(AppConstants.SERVER_DATE_FORMAT_WITH_MILLISECONDS);
            String getDateInStartOFDay = getDateFromMillis(getStartTimeOfGivenDay(getMillisFromStringDate(date, AppConstants.SERVER_DATE_FORMAT_WITH_MILLISECONDS)), AppConstants.SERVER_DATE_FORMAT_WITH_MILLISECONDS);
            long syncDaysDifference = getDaysDifferenceStep(getDateInStartOFDay, currentDateTime, AppConstants.SERVER_DATE_FORMAT_WITH_MILLISECONDS);
            if (syncDaysDifference == 0)
                return "Today at " + formatDateStep("yyyy-MM-dd'T'HH:mm:ss", "hh:mm a", truncateMilliseconds(date));
            else if (syncDaysDifference > 0)
                if (truncateMilliseconds(date).contains("T00:00:00"))
                    return formatDateStep("yyyy-MM-dd'T'HH:mm:ss", "MMM dd, yyyy", truncateMilliseconds(date));
                else
                    return formatDateStep("yyyy-MM-dd'T'HH:mm:ss", "MMM dd, yyyy hh:mm a", truncateMilliseconds(date));
            else
                return "";
        } else {
            return "";
        }
    }

    public static String getDateFromMillis(long milliSeconds, String dateFormat) {
        // Create a DateFormatter object for displaying date in specified format.
        java.text.DateFormat formatter = new SimpleDateFormat(dateFormat, locale);

        // Create a calendar object that will convert the date and time value in milliseconds to date.
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(milliSeconds);
        return formatter.format(calendar.getTime());
    }

    public static String getTodayStartTimeInFormat(String format) {
        SimpleDateFormat sdf = new SimpleDateFormat(format, locale);
        Calendar today = Calendar.getInstance();
        today.set(Calendar.HOUR_OF_DAY, 0);
        today.set(Calendar.MINUTE, 0);
        today.set(Calendar.SECOND, 0);
        today.set(Calendar.MILLISECOND, 0);
        Date date = today.getTime();

        return sdf.format(date);
    }

    public static long getStartTimeOfGivenDay(long millis) {
        Calendar day = Calendar.getInstance();
        day.setTimeInMillis(millis);
        day.set(Calendar.HOUR_OF_DAY, 0);
        day.set(Calendar.MINUTE, 0);
        day.set(Calendar.SECOND, 0);
        day.set(Calendar.MILLISECOND, 0);

        return day.getTimeInMillis();
    }

    public static long getMillisFromStringDate(String inputDate, String inputFormate) {
        Date date;
        long millisecondsFromNow = 0;
        try {
            date = new SimpleDateFormat(inputFormate, locale).parse(inputDate);
            millisecondsFromNow = date.getTime();

        } catch (ParseException e) {
            e.printStackTrace();
        }
        return millisecondsFromNow;
    }

    public static long getDaysDifferenceStep(String firstDate, String nextDate, String format) {
        long days = 0;
        SimpleDateFormat sdf = new SimpleDateFormat(format, locale);

        try {
            Date date1 = sdf.parse(firstDate);
            Date date2 = sdf.parse(nextDate);
            long diff = date2.getTime() - date1.getTime();
            days = diff / (24 * 60 * 60 * 1000);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return days;
    }

    public String getDaysDifference(String firstDate, String nextDate, String format) {
        long days = 0, hours = 0;
        SimpleDateFormat sdf = new SimpleDateFormat(format, locale);

        try {
            Date date1 = sdf.parse(firstDate);
            Date date2 = sdf.parse(nextDate);
            long diff = date2.getTime() - date1.getTime();
            long seconds = diff / 1000;
            long minutes = seconds / 60;
            hours = minutes / 60;
            days = hours / 24;
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (days > 1)
            return days + "d";
        else
            return hours + "h";
    }

    public static String GetMonthSlot(int option, String inputDate) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd MMM yyyy", locale);
        Date myDate = null;
        try {
            myDate = sdf.parse(inputDate);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(myDate);

        calendar.add(Calendar.MONTH, option);
        calendar.set(Calendar.DATE, calendar.getActualMinimum(Calendar.DAY_OF_MONTH));
        Date MonthFirstDay = calendar.getTime();
        calendar.set(Calendar.DATE, calendar.getActualMaximum(Calendar.DAY_OF_MONTH));
        Date MonthLastDay = calendar.getTime();

        return sdf.format(MonthFirstDay) + "-" + sdf.format(MonthLastDay);
    }

    public static boolean isDateFromCurrentsMonth(Calendar calendar) {
        Calendar currentMonthCal = Calendar.getInstance();

        if (currentMonthCal.get(Calendar.YEAR) == calendar.get(Calendar.YEAR)) {
            if (currentMonthCal.get(Calendar.MONTH) == calendar.get(Calendar.MONTH)) {
                return true;
            }
        }
        return false;
    }
}
