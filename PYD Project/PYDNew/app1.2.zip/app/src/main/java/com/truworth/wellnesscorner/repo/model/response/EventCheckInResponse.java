package com.truworth.wellnesscorner.repo.model.response;


import com.truworth.wellnesscorner.model.EventCheckInData;

import java.util.List;

public class EventCheckInResponse {


    private EventCheckInData data;
    private boolean hasError;
    private Error error;

    public EventCheckInData getData() {
        return data;
    }

    public void setData(EventCheckInData data) {
        this.data = data;
    }

    public boolean isHasError() {
        return hasError;
    }

    public void setHasError(boolean hasError) {
        this.hasError = hasError;
    }

    public Error getError() {
        return error;
    }

    public void setError(Error error) {
        this.error = error;
    }
}
