package com.truworth.wellnesscorner.ui.mainapp.circledetail;

import android.databinding.ObservableBoolean;
import android.databinding.ObservableField;
import android.databinding.ObservableInt;
import android.view.View;
import android.widget.Toast;

import com.truworth.wellnesscorner.TheWellnessCornerApp;
import com.truworth.wellnesscorner.base.BaseViewModel;
import com.truworth.wellnesscorner.model.CircleCategoryDataBean;
import com.truworth.wellnesscorner.repo.DashboardRepository;
import com.truworth.wellnesscorner.repo.model.request.BaseRequest;
import com.truworth.wellnesscorner.repo.model.response.CircleAboutResponse;
import com.truworth.wellnesscorner.repo.model.response.GetJoinCircleResponse;
import com.truworth.wellnesscorner.utils.DateUtils;
import com.truworth.wellnesscorner.utils.SingleLiveEvent;

import java.util.List;

import javax.inject.Inject;

import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;

public class CircleAboutViewModel extends BaseViewModel {

    public ObservableField<String> circleName = new ObservableField();
    public ObservableField<String> circleImageUrl = new ObservableField();
    public ObservableField<String> circleDescription = new ObservableField();
    public ObservableField<String> circleCreatedDate = new ObservableField();
    public ObservableInt totalMembers = new ObservableInt();
    public ObservableField<String> member1ImageUrl = new ObservableField();
    public ObservableField<String> member2ImageUrl = new ObservableField();
    public ObservableField<String> member3ImageUrl = new ObservableField();
    public ObservableField<String> member1Name = new ObservableField();
    public ObservableField<String> member2Name = new ObservableField();
    public ObservableField<String> member3Name = new ObservableField();
    public ObservableBoolean isOpenCircle = new ObservableBoolean();
    public ObservableBoolean isExpanded = new ObservableBoolean();
    public ObservableBoolean isJoinEnable = new ObservableBoolean();
    public ObservableBoolean showSeeMore = new ObservableBoolean();
    public ObservableBoolean isVisibleJoin = new ObservableBoolean();
    public ObservableBoolean isMemberVisible = new ObservableBoolean();
    public SingleLiveEvent<List<CircleCategoryDataBean>> category = new SingleLiveEvent<>();
    public SingleLiveEvent<String> onJoinNow = new SingleLiveEvent<>();
    SingleLiveEvent<String> zoomImage = new SingleLiveEvent<>();
    SingleLiveEvent<Void> onBack = new SingleLiveEvent<>();



    @Inject
    DashboardRepository dashboardRepository;
    private SingleLiveEvent<Void> expandData = new SingleLiveEvent<>();
    private String circleIdentity;

    public CircleAboutViewModel() {
        isJoinEnable.set(true);
        TheWellnessCornerApp.getApp().component().inject(this);
    }

    public SingleLiveEvent<String> getZoomImage() {
        return zoomImage;
    }

    public SingleLiveEvent<Void> getOnBack() {
        return onBack;
    }

    public SingleLiveEvent<List<CircleCategoryDataBean>> getCategory() {
        return category;
    }

    public void setCategory(SingleLiveEvent<List<CircleCategoryDataBean>> category) {
        this.category = category;
    }

    public SingleLiveEvent<String> getOnJoinNow() {
        return onJoinNow;
    }

    public SingleLiveEvent<Void> getExpandData() {
        return expandData;
    }

    public void loadAboutDetails(String circleIdentity) {
        this.circleIdentity = circleIdentity;
        BaseRequest circleCoachRequest = new BaseRequest();
        circleCoachRequest.setId(circleIdentity);

        dashboardRepository.getCircleAboutDetails(circleCoachRequest).subscribe(new Observer<CircleAboutResponse>() {
            @Override
            public void onSubscribe(Disposable d) {

            }

            @Override
            public void onNext(CircleAboutResponse circleAboutResponse) {
                if (!circleAboutResponse.isHasError()) {

                    circleName.set(circleAboutResponse.getData().getCircleName());
                    circleImageUrl.set(circleAboutResponse.getData().getCircleImage());
                    circleDescription.set(circleAboutResponse.getData().getCircleDescription());
                    circleCreatedDate.set(circleAboutResponse.getData().getCircleCreatedOn());
                    totalMembers.set(circleAboutResponse.getData().getTotalMembers());

                    if(totalMembers.get()>0)
                        isMemberVisible.set(true);
                    else
                        isMemberVisible.set(false);


                    if (circleAboutResponse.getData().getCircleMemberData().size() > 0) {
                        member1ImageUrl.set(circleAboutResponse.getData().getCircleMemberData().get(0).getMemberImage());
                        member1Name.set(circleAboutResponse.getData().getCircleMemberData().get(0).getMemberName());
                    }

                    if (circleAboutResponse.getData().getCircleMemberData().size() > 1) {
                        member2ImageUrl.set(circleAboutResponse.getData().getCircleMemberData().get(1).getMemberImage());
                        member2Name.set(circleAboutResponse.getData().getCircleMemberData().get(1).getMemberName());
                    }

                    if (circleAboutResponse.getData().getCircleMemberData().size() > 2) {
                        member3ImageUrl.set(circleAboutResponse.getData().getCircleMemberData().get(2).getMemberImage());
                        member3Name.set(circleAboutResponse.getData().getCircleMemberData().get(2).getMemberName());
                    }
                    // set condition for join now button visiblity on base of isMemberCircleJoin and isOpen
                    if (circleAboutResponse.getData().isMemberCircleJoin())
                        isVisibleJoin.set(false);
                    else if (circleAboutResponse.getData().getCircleAccessData().isOpen())
                        isVisibleJoin.set(circleAboutResponse.getData().getCircleAccessData().isOpen());

                    isOpenCircle.set(circleAboutResponse.getData().getCircleAccessData().isOpen());
                    category.setValue(circleAboutResponse.getData().getCircleCategoryData());
                }
            }

            @Override
            public void onError(Throwable e) {

            }

            @Override
            public void onComplete() {

            }
        });
    }

    public String getDateinFormat(String date) {
        String newDateString = "";
        if (date != null)
            newDateString = DateUtils.formatDate(date, "yyyy-MM-dd'T'HH:mm:ss", "MMMM dd,yyyy");

        return newDateString;
    }

    public void expandSeeMore() {
        if (isExpanded.get())
            isExpanded.set(false);
        else
            isExpanded.set(true);

        expandData.call();
    }

    public void onBackPressed() {
        onBack.call();
    }

    public void zoomImageClick() {
        zoomImage.setValue(circleImageUrl.get());
    }

    public void joinCircle() {
        isJoinEnable.set(false);
        BaseRequest baseRequest = new BaseRequest();
        baseRequest.setId(circleIdentity);

        dashboardRepository.getJoinCircle(baseRequest).subscribe(new Observer<GetJoinCircleResponse>() {
            @Override
            public void onSubscribe(Disposable d) {

            }

            @Override
            public void onNext(GetJoinCircleResponse joinCircleResponse) {
                if (!joinCircleResponse.isHasError()) {
                    isJoinEnable.set(true);
                    if (joinCircleResponse.getData() != null && joinCircleResponse.getData().getStatus() == 1) {
                        onJoinNow.setValue(joinCircleResponse.getData().getMessage());
                    }

                }
            }

            @Override
            public void onError(Throwable e) {

            }

            @Override
            public void onComplete() {

            }
        });
    }
}
