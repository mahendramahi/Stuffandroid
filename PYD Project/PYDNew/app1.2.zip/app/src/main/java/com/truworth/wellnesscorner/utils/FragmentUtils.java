package com.truworth.wellnesscorner.utils;

import android.app.Activity;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;


/**
 * Created by rajeshs on 4/3/2018.
 */

public class FragmentUtils {

    public static void removeAllFragmentFromStack(AppCompatActivity context) {
        FragmentManager fm =context. getSupportFragmentManager();
        for (int i = 0; i < fm.getBackStackEntryCount(); ++i) {
            fm.popBackStack(null,FragmentManager.POP_BACK_STACK_INCLUSIVE);
        }

    }
}
