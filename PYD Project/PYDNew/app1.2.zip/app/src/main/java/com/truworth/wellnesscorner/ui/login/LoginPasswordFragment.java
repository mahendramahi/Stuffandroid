package com.truworth.wellnesscorner.ui.login;

import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.BottomSheetDialog;
import android.text.InputFilter;
import android.text.Spanned;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;

import com.truworth.wellnesscorner.BR;
import com.truworth.wellnesscorner.R;
import com.truworth.wellnesscorner.TheWellnessCornerApp;
import com.truworth.wellnesscorner.base.BaseFragment;
import com.truworth.wellnesscorner.data.SharedPreferenceHelper;
import com.truworth.wellnesscorner.databinding.FragmentLoginPasswordBinding;
import com.truworth.wellnesscorner.ui.mainapp.HomeDashBoardActivity;
import com.truworth.wellnesscorner.ui.mobileverification.LoginWithMobileNumberFragment;
import com.truworth.wellnesscorner.ui.mobileverification.MobileNumberRedirectionType;
import com.truworth.wellnesscorner.ui.registration.RegistrationActivity;
import com.truworth.wellnesscorner.ui.resetpassword.ResetPasswordFragment;

import javax.inject.Inject;


public class LoginPasswordFragment extends BaseFragment<FragmentLoginPasswordBinding, LoginPasswordViewModel> {
    public static final String TAG = "LoginPasswordFragment";
    private static final String ARG_PARAM1 = "param1";
    LoginPasswordViewModel viewModel;
    FragmentLoginPasswordBinding binding;

    private String emailID;
    @Inject
    SharedPreferenceHelper preferenceHelper;

    public LoginPasswordFragment() {
        // Required empty public constructor
    }


    public static LoginPasswordFragment newInstance(String param1) {
        LoginPasswordFragment fragment = new LoginPasswordFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setKeyboardHideOnTapOutSide(false);
        setHasOptionsMenu(true);
        if (getArguments() != null) {
            emailID = getArguments().getString(ARG_PARAM1);
        }
    }


    @Override
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        TheWellnessCornerApp.getApp().component().inject(this);

        //email id setted to viewModel for login api arguments
        viewModel.setEmail(emailID);

        binding = getViewDataBinding();
        binding.etPassword.requestFocus();
        showKeyboard();
        binding.etPassword.setFilters(new InputFilter[]{filter, new InputFilter.LengthFilter(20)});

        setUpMoveToDashBoard();


    }

    InputFilter filter = new InputFilter() {
        @Override
        public CharSequence filter(CharSequence source, int start, int end, Spanned dest, int dstart, int dend) {
            for (int i = start; i < end; i++) {
                int type = Character.getType(source.charAt(i));
                if (type == Character.SURROGATE || type == Character.OTHER_SYMBOL) {
                    return "";
                }
                else if(type == Character.SPACE_SEPARATOR){
                    return "";
                }
            }
            return null;
        }
    };

    private void setUpMoveToDashBoard() {
        viewModel.getOnSuccessLogin().observe(this, new Observer<Void>() {
            @Override
            public void onChanged(@Nullable Void aVoid) {
                if (preferenceHelper.getProfileStepNumber() >= 6) {
                    startActivity(new Intent(getActivity(), HomeDashBoardActivity.class));
                    getActivity().finish();
                } else {
                    hideKeyboard();
                    startActivity(new Intent(getActivity(), RegistrationActivity.class));
                }

            }
        });
    }


    /**
     * Override for set binding variable
     *
     * @return variable id
     */
    @Override
    public int getBindingVariable() {
        return BR.viewModel;
    }

    /**
     * @return layout resource id
     */
    @Override
    public int getLayoutId() {
        return R.layout.fragment_login_password;
    }

    /**
     * Override for set view model
     *
     * @return view model instance
     */
    @Override
    public LoginPasswordViewModel getViewModel() {
        return viewModel = ViewModelProviders.of(this).get(LoginPasswordViewModel.class);
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

    }

    @Override
    public void onDetach() {
        super.onDetach();


    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.menu_password_fragment, menu);
        super.onCreateOptionsMenu(menu, inflater);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle item selection
        switch (item.getItemId()) {
            case R.id.action_help:
                showHelpMenuDialog();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }


    public void showHelpMenuDialog() {
        hideKeyboard();
        BottomSheetDialog mBottomSheetDialog = new BottomSheetDialog(getActivity());

        View sheetView = getActivity().getLayoutInflater().inflate(R.layout.layout_help_menu, null);
        mBottomSheetDialog.setContentView(sheetView);
        ((View) sheetView.getParent()).setBackgroundColor(getResources().getColor(android.R.color.transparent));
        ((View) sheetView.getParent()).setPadding(30, 30, 30, 30);

        LinearLayout loginWithOTP = sheetView.findViewById(R.id.llLoginWithOTP);
        LinearLayout resetPassword = sheetView.findViewById(R.id.llResetPassword);
        loginWithOTP.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mBottomSheetDialog.dismiss();
                showLoginWithMobileFragment();
            }
        });
        resetPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mBottomSheetDialog.dismiss();
                showResetPasswordFragment();
            }
        });

        mBottomSheetDialog.show();
    }

    private void showLoginWithMobileFragment() {
        getActivity().getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.loginContainer, LoginWithMobileNumberFragment.newInstance(emailID, MobileNumberRedirectionType.FROM_LOGIN), LoginWithMobileNumberFragment.TAG).addToBackStack(LoginWithMobileNumberFragment.TAG)
                .commit();
    }

    private void showResetPasswordFragment() {
        getActivity().getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.loginContainer, ResetPasswordFragment.newInstance(emailID), ResetPasswordFragment.TAG).addToBackStack(ResetPasswordFragment.TAG)
                .commit();
    }
}
