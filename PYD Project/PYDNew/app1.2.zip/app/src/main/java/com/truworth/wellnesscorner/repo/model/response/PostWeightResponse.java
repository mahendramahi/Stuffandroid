package com.truworth.wellnesscorner.repo.model.response;

import com.truworth.wellnesscorner.model.SharePostWeightData;

public class PostWeightResponse {

    private SharePostWeightData data;
    private boolean hasError;
    private Error error;

    public SharePostWeightData getData() {
        return data;
    }

    public void setData(SharePostWeightData data) {
        this.data = data;
    }

    public boolean isHasError() {
        return hasError;
    }

    public void setHasError(boolean hasError) {
        this.hasError = hasError;
    }

    public Error getError() {
        return error;
    }

    public void setError(Error error) {
        this.error = error;
    }
}
