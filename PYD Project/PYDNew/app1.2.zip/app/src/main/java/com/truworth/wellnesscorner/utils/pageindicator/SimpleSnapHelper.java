package com.truworth.wellnesscorner.utils.pageindicator;

import android.support.annotation.NonNull;
import android.support.v7.widget.PagerSnapHelper;
import android.support.v7.widget.RecyclerView;


public class SimpleSnapHelper extends PagerSnapHelper {

	private OverflowPagerIndicator mOverflowPagerIndicator;

	public SimpleSnapHelper(@NonNull OverflowPagerIndicator overflowPagerIndicator) {
		mOverflowPagerIndicator = overflowPagerIndicator;
	}

	@Override
	public int findTargetSnapPosition(RecyclerView.LayoutManager layoutManager, int velocityX, int velocityY) {
		int position = super.findTargetSnapPosition(layoutManager, velocityX, velocityY);

		// Notify OverflowPagerIndicator about changed page
		mOverflowPagerIndicator.onPageSelected(position);

		return position;
	}

}
