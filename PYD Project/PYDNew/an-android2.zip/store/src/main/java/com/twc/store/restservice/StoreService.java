package com.twc.store.restservice;


import com.twc.store.model.requestbody.ApplyCouponBody;
import com.twc.store.model.requestbody.BaseMemberIdBody;
import com.twc.store.model.requestbody.DeleteCartItemBody;
import com.twc.store.model.requestbody.ProductBody;
import com.twc.store.model.requestbody.StoreCheckoutBody;
import com.twc.store.model.requestbody.StoreSaveCartRequestBody;
import com.twc.store.model.requestbody.StoreSaveOrderRequestBody;
import com.twc.store.model.requestbody.StoreUpdateOrderBody;
import com.twc.store.model.requestbody.UpdateCartQuantityBody;
import com.twc.store.model.response.ApplyCouponResponse;
import com.twc.store.model.response.DeleteCartItemResponse;
import com.twc.store.model.response.GetCartItemsResponse;
import com.twc.store.model.response.StoreCartCountResponse;
import com.twc.store.model.response.StoreCheckoutResponse;
import com.twc.store.model.response.StoreProductResponse;
import com.twc.store.model.response.StoreSaveCartResponse;
import com.twc.store.model.response.StoreSaveOrderResponse;
import com.twc.store.model.response.StoreUpdateOrderResponse;
import com.twc.store.model.response.UpdateCartQuantityResponse;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

/**
 * If this code works it was written by Palak chawla on 13 September, 2017. If not, I don't know who wrote it.
 */
public interface StoreService {

    @POST("Member/Store/GetCartItems")
    Call<GetCartItemsResponse> getCartItems(@Body BaseMemberIdBody baseMemberIdBody);

    @POST("Member/Store/DeleteCartItem")
    Call<DeleteCartItemResponse> getDeleteCartItem(@Body DeleteCartItemBody deleteCartItemBody);

    @POST("Member/Store/UpdateCartQuantity")
    Call<UpdateCartQuantityResponse> getUpdateCartQuantity(@Body UpdateCartQuantityBody updateCartQuantityBody);

    @POST("Member/Store/ApplyCoupon")
    Call<ApplyCouponResponse> applyCoupon(@Body ApplyCouponBody applyCouponBody);

    @POST("Member/Store/CheckOut")
    Call<StoreCheckoutResponse> checkOut(@Body StoreCheckoutBody storeCheckoutBody);

    @POST("Member/Store/SaveOrder")
    Call<StoreSaveOrderResponse> saveOrder(@Body StoreSaveOrderRequestBody storeSaveOrderRequestBody);

    @POST("Member/Store/SaveCart")
    Call<StoreSaveCartResponse> saveCart(@Body StoreSaveCartRequestBody storeSaveCartRequestBody);

    @POST("Member/Store/CartCount")
    Call<StoreCartCountResponse> getCartCount(@Body BaseMemberIdBody baseMemberIdBody);


    @POST("Member/Store/UpdateOrder")
    Call<StoreUpdateOrderResponse> updateOrder(@Body StoreUpdateOrderBody storeUpdateOrderBody);

    @POST("Product")
    Call<StoreProductResponse> getProducts(@Body ProductBody ProductsBody);
}
