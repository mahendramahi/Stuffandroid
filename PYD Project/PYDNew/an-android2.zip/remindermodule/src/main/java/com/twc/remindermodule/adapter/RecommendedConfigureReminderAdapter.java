package com.twc.remindermodule.adapter;



import android.app.Activity;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.TimePicker;

import com.twc.remindermodule.R;
import com.twc.remindermodule.dialog.TimePickerFragment;
import com.twc.remindermodule.model.beans.HabitReminderBean;
import com.twc.remindermodule.utils.DateFactory;
import com.twc.remindermodule.utils.DialogFactory;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;


public class RecommendedConfigureReminderAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    Activity mActivity;
    ArrayList<HabitReminderBean> mHabitReminderList;
    LayoutInflater inflater;

    public RecommendedConfigureReminderAdapter(Activity activity, ArrayList<HabitReminderBean> habitReminderList) {
        this.mActivity = activity;
        this.mHabitReminderList = habitReminderList;
        inflater = (LayoutInflater) mActivity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.row_configure_reminder_timings, parent, false);
        return new ItemViewHolder(itemView);

    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, final int position) {
        final ItemViewHolder itemViewHolder = (ItemViewHolder) holder;

        final HabitReminderBean habitReminderBean = mHabitReminderList.get(position);
        itemViewHolder.tvReminderName.setText(habitReminderBean.getReminderName());
        itemViewHolder.switchReminderOnOff.setTag(position);
        itemViewHolder.tvAdd.setTag(position);
        itemViewHolder.llTime.removeAllViews();



        List<HabitReminderBean.HabitReminderItem> listHabitReminders = mHabitReminderList.get(position).getHabitReminder();

        if (listHabitReminders.size() > 0) {
            if (listHabitReminders.get(0).getTime().equalsIgnoreCase("")) {
                listHabitReminders.get(0).setIsDisabled(true);

            }
        }

        boolean IsDisabled = false;
        for (HabitReminderBean.HabitReminderItem item : listHabitReminders) {
            if (item.isRemoved() == 0 && !item.getTime().equalsIgnoreCase("")) {
                setReminderTime(itemViewHolder.llTime, item.getTime(), item, listHabitReminders, habitReminderBean.getReminderName(), itemViewHolder.switchReminderOnOff);
            }
            IsDisabled = item.isIsDisabled();
        }
        if (IsDisabled) {
            itemViewHolder.switchReminderOnOff.setChecked(false);
        } else {
            itemViewHolder.switchReminderOnOff.setChecked(true);
        }


        itemViewHolder.tvAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                int pos = Integer.parseInt(v.getTag().toString());
                timeDialog(pos);

            }
        });

        itemViewHolder.switchReminderOnOff.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

                int pos = Integer.parseInt(buttonView.getTag().toString());
                for (HabitReminderBean.HabitReminderItem item : mHabitReminderList.get(pos).getHabitReminder()) {
                    if (!isChecked)
                        item.setIsDisabled(true);
                    else
                        item.setIsDisabled(false);
                }

            }
        });

    }

    @Override
    public int getItemCount() {
        return mHabitReminderList.size();
    }

    // ItemViewHolder Class for Items in each Section
    public class ItemViewHolder extends RecyclerView.ViewHolder {

        private TextView tvAdd;
        private LinearLayout llTime;
        private TextView tvReminderName;
        private Switch switchReminderOnOff;

        public ItemViewHolder(View itemView) {
            super(itemView);

            tvReminderName = itemView.findViewById(R.id.tvReminderName);
            tvAdd = itemView.findViewById(R.id.tvAdd);
            llTime = itemView.findViewById(R.id.llTime);
            switchReminderOnOff = itemView.findViewById(R.id.switchReminderOnOff);
        }

    }

    public void timeDialog(final int pos) {

        String TIME_FORMAT = "hh:mm a";
        String currentTime = DateFactory.getInstance().getCurrentTime(TIME_FORMAT);
        String time24format = DateFactory.getInstance().formatTime(TIME_FORMAT, "HH:mm", currentTime);
        String[] timeSplit = time24format.split(":");

        TimePickerFragment timePicker = new TimePickerFragment();
        Bundle bundle = new Bundle();
        bundle.putInt("hour", Integer.parseInt(timeSplit[0]));
        bundle.putInt("minute", Integer.parseInt(timeSplit[1]));
        bundle.putBoolean("is24hrsFormat", false);
        timePicker.setArguments(bundle);
        timePicker.setCallBack(new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                String AM_PM = " AM";
                String mm_precede = "";
                String hh_precede = "";
                if (hourOfDay >= 12) {
                    AM_PM = " PM";
                    if (hourOfDay >= 13 && hourOfDay < 24) {
                        hourOfDay -= 12;
                    } else {
                        hourOfDay = 12;
                    }
                } else if (hourOfDay == 0) {
                    hourOfDay = 12;
                }
                if (minute < 10) {
                    mm_precede = "0";
                }
                if (hourOfDay < 10) {
                    hh_precede = "0";
                }
                HabitReminderBean.HabitReminderItem item = new HabitReminderBean.HabitReminderItem();
                String time = String.format(Locale.getDefault(), "%s%d:%s%d%s", hh_precede, hourOfDay, mm_precede, minute, AM_PM);

                boolean isTimeAlreadyAdded = false;
                for (HabitReminderBean.HabitReminderItem habitReminderItem : mHabitReminderList.get(pos).getHabitReminder()) {
                    if (time.equalsIgnoreCase(habitReminderItem.getTime())) {
                        if (habitReminderItem.isRemoved() == 0) {
                            isTimeAlreadyAdded = true;
                        }
                    }
                }
                if (isTimeAlreadyAdded) {
                    DialogFactory.getInstance().showAlertDialog(mActivity, mActivity.getString(R.string.app_name), 0, "This time is already added!", mActivity.getString(R.string.str_ok), false);
                } else {
                    item.setTime(time);
                    item.setLocallyAdded(true);
                    mHabitReminderList.get(pos).getHabitReminder().add(item);
                    sortHabitTimeItemList(mHabitReminderList.get(pos).getHabitReminder());

                    for (HabitReminderBean.HabitReminderItem item1 : mHabitReminderList.get(pos).getHabitReminder()) {
                        item1.setIsDisabled(false);
                    }

                    notifyItemChanged(pos);

                }
            }
        });
        timePicker.show(mActivity.getFragmentManager(), "dialog");

    }

    private void setReminderTime(final LinearLayout llTime, String time, final HabitReminderBean.HabitReminderItem item, final List<HabitReminderBean.HabitReminderItem> listHabitReminders, final String reminderName, final Switch switchReminderOnOff) {

        //LayoutInflater inflater = (LayoutInflater) mActivity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        final View myView = inflater.inflate(R.layout.row_configure_time, null);
        final TextView textView = (TextView) myView.findViewById(R.id.tvTime);

        textView.setText(time);

        textView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {

                int unRemovedItemSize = 0;
                for (HabitReminderBean.HabitReminderItem item : listHabitReminders) {
                    if (item.isRemoved() == 0) {
                        unRemovedItemSize = unRemovedItemSize + 1;
                    }
                }

                // user would have at least 1 time with reminder
                if (unRemovedItemSize == 1) {

                    DialogFactory.getInstance().showAlertDialog(mActivity, mActivity.getString(R.string.app_name), 0, "A reminder should at least have 1 time. Would you like to disable this reminder instead?", "Yes", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            switchReminderOnOff.setChecked(false);
                            for (HabitReminderBean.HabitReminderItem item : listHabitReminders) {
                                item.setIsDisabled(true);
                            }
                        }
                    }, "No", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            dialogInterface.dismiss();

                        }
                    }, false);


                } else if (unRemovedItemSize > 1) {
                    DialogFactory.getInstance().showAlertDialog(mActivity, mActivity.getString(R.string.app_name), 0, "Are you sure you want to remove " + textView.getText().toString() + " from " + reminderName + " habit ?", "Yes", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            llTime.removeAllViews();

                            if (item.isLocallyAdded()) {
                                listHabitReminders.remove(item);
                            } else {
                                item.setRemoved(1);
                            }
                            dialogInterface.dismiss();
                            notifyDataSetChanged();


                        }
                    }, "No", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            dialogInterface.dismiss();

                        }
                    }, false);
                }
                return false;
            }

        });

        llTime.addView(myView);

    }

    private void sortHabitTimeItemList(List<HabitReminderBean.HabitReminderItem> habitReminderList) {

        Collections.sort(habitReminderList, new Comparator<HabitReminderBean.HabitReminderItem>() {
            public int compare(HabitReminderBean.HabitReminderItem obj1, HabitReminderBean.HabitReminderItem obj2) {
                try {
                    return new SimpleDateFormat("hh:mm a", Locale.getDefault()).parse(obj1.getTime()).compareTo(new SimpleDateFormat("hh:mm a", Locale.getDefault()).parse(obj2.getTime()));
                } catch (ParseException e) {
                    return 0;
                }

            }
        });
    }
}
