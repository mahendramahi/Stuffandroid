package com.twc.remindermodule.model.response;

/**
 * Created by PalakC on 1/19/2018.
 */

public class SaveSleepLogResponse {

    private int status;
    private SaveSleepItem data;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public SaveSleepItem getData() {
        return data;
    }

    public void setData(SaveSleepItem data) {
        this.data = data;
    }

    public static class SaveSleepItem {
        private int status;
        private String message;
        private int SleepLogID;

        public int getStatus() {
            return status;
        }

        public void setStatus(int status) {
            this.status = status;
        }

        public String getMessage() {
            return message;
        }

        public void setMessage(String message) {
            this.message = message;
        }

        public int getSleepLogID() {
            return SleepLogID;
        }

        public void setSleepLogID(int SleepLogID) {
            this.SleepLogID = SleepLogID;
        }
    }
}
