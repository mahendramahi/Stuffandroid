package com.truworth.discoverlib.model;

/**
 * Created by ManishJ1 on 6/30/2016.
 */
public class RandomArticleBody extends BaseBody {

    private String PageIndex;
    private String Type;
    private String Category;

    public String getPageIndex() {
        return PageIndex;
    }

    public void setPageIndex(String pageIndex) {
        PageIndex = pageIndex;
    }

    public String getType() {
        return Type;
    }

    public void setType(String type) {
        Type = type;
    }

    public String getCategory() {
        return Category;
    }

    public void setCategory(String category) {
        Category = category;
    }
}
