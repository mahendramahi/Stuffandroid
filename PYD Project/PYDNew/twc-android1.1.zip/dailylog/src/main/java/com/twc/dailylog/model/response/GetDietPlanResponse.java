package com.twc.dailylog.model.response;


import com.twc.dailylog.model.beans.FoodItem;

import java.util.List;

/**
 * Created by ManishJ1 on 7/4/2016.
 */
public class GetDietPlanResponse {

    private int status;

    private List<FoodItem> data;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public List<FoodItem> getData() {
        return data;
    }

    public void setData(List<FoodItem> data) {
        this.data = data;
    }


}
