package com.twc.dailylog.model.response;

/**
 Created by PalakC on 8/3/2016.
 */
public class SaveExerciseResponse {


    /**
     ActivityID : 16787
     status : 0
     */

    private int ActivityID;
    private int status;

    public int getActivityID() {
        return ActivityID;
    }

    public void setActivityID(int ActivityID) {
        this.ActivityID = ActivityID;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }
}
