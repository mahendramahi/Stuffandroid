package com.truworth.wellnesscorner.repo.model.response;

import java.util.List;

public class ShareMealNewResponse {


    private ShareMealResponse data;
    private boolean hasError;
    private Error error;

    public ShareMealResponse getData() {
        return data;
    }

    public void setData(ShareMealResponse data) {
        this.data = data;
    }

    public boolean isHasError() {
        return hasError;
    }

    public void setHasError(boolean hasError) {
        this.hasError = hasError;
    }

    public Object getError() {
        return error;
    }

    public void setError(Error error) {
        this.error = error;
    }
}
