package com.twc.store.interfaces;

/**
 * Created by GurvinderS on 3/17/2017.
 */

public interface OnCityFindListener {

    void onCityFound(String city);
}
