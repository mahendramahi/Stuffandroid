package com.twc.store;

import com.twc.store.model.beans.BillingInfoBean;

/**
 * Created by GurvinderS on 3/28/2018.
 */

public class BillingAddressConfig {
    private static BillingAddressConfig instance = null;
    private BillingInfoBean billingInfoBean;

    public synchronized static BillingAddressConfig getInstance() {
        return instance;
    }
    public void setBillingConfig(StoreActivity activity){
        instance=BillingAddressConfig.this;
    }
    public void setBillingConfigDetail(StoreDetailActivity activity){
        instance=BillingAddressConfig.this;
    }
    public void setBillingConfigCategory(StoreCategoryActivity activity){
        instance=BillingAddressConfig.this;
    }

    public BillingInfoBean getBillingInfoBean() {
        return billingInfoBean;
    }

    public void setBillingInfoBean(BillingInfoBean billingInfoBean) {
        this.billingInfoBean = billingInfoBean;
    }
}
