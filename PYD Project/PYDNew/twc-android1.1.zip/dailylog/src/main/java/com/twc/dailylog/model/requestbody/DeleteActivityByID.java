package com.twc.dailylog.model.requestbody;

/**
 * Created by PankajS on 8/17/2016.
 */
public class DeleteActivityByID
    {
    private int ActivityID;

    public int getActivityID()
        {
        return ActivityID;
        }

    public void setActivityID(int activityID)
        {
        ActivityID = activityID;
        }
    }
