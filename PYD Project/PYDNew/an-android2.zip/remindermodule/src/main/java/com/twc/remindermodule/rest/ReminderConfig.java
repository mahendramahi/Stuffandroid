package com.twc.remindermodule.rest;


import android.app.Activity;
import android.util.Log;

import com.twc.remindermodule.model.beans.ReminderUser;

import static android.content.Context.MODE_PRIVATE;

/**
 * If this code works, it was written by Somesh Kumar  on 27 November, 2017. If not, I don't know who wrote it.
 */

public class ReminderConfig {
    public static String BASE_URL = "http://192.168.1.91:9003/twcapi/";// default testing url
    public static String APP_NAME = ""; //
    public static boolean DEBUG;
    public static ReminderUser reminderUser = new ReminderUser();
    public static Activity mActivity;
    /**
     * @param appName
     * @param apiBaseUrl
     * @param user
     * @param activity
     */
    public static void init(String appName, String apiBaseUrl, ReminderUser user, boolean debug, Activity activity) {
        if (!appName.isEmpty() && !apiBaseUrl.isEmpty() && user != null) {
            BASE_URL = apiBaseUrl;
            APP_NAME = appName;
            reminderUser = user;
            DEBUG = debug;
            mActivity=activity;

        } else {
            Log.d("REMINDER", "init: " + apiBaseUrl);
            Log.d("REMINDER", "init: failed reminderlib. Please all fields of init.");
        }
    }

}
