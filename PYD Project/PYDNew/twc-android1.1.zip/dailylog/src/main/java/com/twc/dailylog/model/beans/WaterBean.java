package com.twc.dailylog.model.beans;

/**
 * Created by GurvinderS on 12/27/2017.
 */

public class WaterBean {

    public boolean isFill() {
        return isFill;
    }

    public void setFill(boolean fill) {
        isFill = fill;
    }

    public boolean isFill;

    public boolean isAdd() {
        return isAdd;
    }

    public void setAdd(boolean add) {
        isAdd = add;
    }

    public boolean isAdd;

    public boolean isShowAddIcon() {
        return showAddIcon;
    }

    public void setShowAddIcon(boolean showAddIcon) {
        this.showAddIcon = showAddIcon;
    }

    public boolean showAddIcon;
}
