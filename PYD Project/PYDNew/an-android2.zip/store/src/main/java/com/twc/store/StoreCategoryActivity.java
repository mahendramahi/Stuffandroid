package com.twc.store;

import android.app.Fragment;
import android.app.FragmentManager;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;

import com.twc.store.dialog.ApiErrorDialog;
import com.twc.store.dialog.NetworkErrorDialog;
import com.twc.store.fragments.StoreHomeFragment;
import com.twc.store.fragments.StoreMemberAddressFragment;
import com.twc.store.fragments.StoreProductListingFragment;
import com.twc.store.model.beans.ProductItem;
import com.twc.store.model.beans.StoreDataBeanItem;
import com.twc.store.model.requestbody.ProductBody;
import com.twc.store.model.requestbody.StoreProductsBody;
import com.twc.store.model.response.ProductResponse;
import com.twc.store.model.response.StoreProductResponse;
import com.twc.store.rest.RestClient;
import com.twc.store.utils.Constant;
import com.twc.store.utils.DialogFactory;
import com.twc.store.utils.NetworkFactory;
import com.twc.store.utils.StoreConfig;
import com.twc.store.utils.Utils;
import com.twc.store.views.CustomProgressDialog;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class StoreCategoryActivity extends AppCompatActivity {
    public Toolbar mToolbar;

    private TextView tvToolbarTitle;
    private int categoryId, venderId;
    private String category;
    private int productItmesPosition;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setupToolbar();

        new GlideConfig().glideSetupCategory(this);
        new BillingAddressConfig().setBillingConfigCategory(this);

        Bundle bundle = getIntent().getExtras();
        if (bundle != null) {
            category= bundle.getString("category");
            categoryId = bundle.getInt("categoryId");
            venderId = bundle.getInt("venderId");

        }
        callGetProductsApi(category,categoryId,venderId);
    }

    private void setupToolbar() {
        mToolbar = findViewById(R.id.toolbar);
        tvToolbarTitle = findViewById(R.id.tbTitle);
        // ivMenuExpertImage = findViewById(R.id.ivMenuExpertImage);
        setSupportActionBar(mToolbar);
        mToolbar.setNavigationIcon(R.drawable.ic_arrow_left_white_24dp);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
    }

    public void setToolBarTitle(String toolBarTitle) {
        tvToolbarTitle.setText(toolBarTitle);
        assert getSupportActionBar() != null;
        getSupportActionBar().show();
    }

    public void showHomeAsUpEnableToolbar() {

        mToolbar.setNavigationIcon(R.drawable.ic_arrow_left_white_24dp);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }


        mToolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int count = getFragmentManager().getBackStackEntryCount();
                //1 == HomeFragment
                if (count == 1) {
                    finish();
                } else {
                    getFragmentManager().popBackStackImmediate();
                }

            }
        });
    }

    @Override
    public void onBackPressed() {
        int count = getFragmentManager().getBackStackEntryCount();
        //1 == HomeFragment
        if (count == 1) {
            finish();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (getCurrentFragmentName(StoreMemberAddressFragment.class.getSimpleName())) {
            Fragment fragment = getFragmentManager().findFragmentByTag(StoreMemberAddressFragment.class.getSimpleName());
            if (fragment != null) {
                fragment.onActivityResult(requestCode, resultCode, data);
            }
        }
    }

    private boolean getCurrentFragmentName(String fragmentName) {
        FragmentManager fragmentManager = getFragmentManager();
        if (fragmentManager.findFragmentByTag(fragmentName) != null) {
            String fragmentTag = fragmentManager.getBackStackEntryAt(fragmentManager.getBackStackEntryCount() - 1).getName();
            return fragmentTag.equalsIgnoreCase(fragmentName);
        } else
            return false;
    }

    private void callGetProductsApi(String category,int categoryId, int venderId) {
        if (NetworkFactory.getInstance().isNetworkAvailable(this)) {
            CustomProgressDialog customProgressDialog = new CustomProgressDialog(this, R.style.custom_progress_style, true);
           // customProgressDialog.setCancelable(false);
            customProgressDialog.show();

            ProductBody productBody = new ProductBody();
            productBody.setVendorId(venderId);
            productBody.setCategoryId(categoryId);

            RestClient restClient = new RestClient(this, StoreConfig.BASE_URL, StoreConfig.mdebug);

            restClient.getStoreService().getProducts(productBody).enqueue(new Callback<StoreProductResponse>() {
                @Override
                public void onResponse(Call<StoreProductResponse> call, Response<StoreProductResponse> response) {
                        customProgressDialog.dismiss();
                        if (response != null && response.body() != null) {
                            if (response.body().getStatus() == 0) {
                                if (response.body().getProducts().size() > 0) {
                                    for (int i = 0; i < response.body().getProducts().size(); i++) {
                                        productItmesPosition = i;
                                    }
                                    Utils.replaceFragment(getFragmentManager(), StoreProductListingFragment.newInstance(category, (ArrayList<ProductItem>)response.body().getProducts().get(productItmesPosition).getProduct()), StoreProductListingFragment.class.getSimpleName(), true, R.id.fragmentContainer);
                                    }
                            } else if (response.body().getStatus() == -1) {
                                DialogFactory.getInstance().showAlertDialog(StoreCategoryActivity.this, getString(R.string.app_name), 0, getString(R.string.msg_api_response_failure), getString(R.string.str_ok), false);
                            }
                        } else {
                            DialogFactory.getInstance().showAlertDialog(StoreCategoryActivity.this, getString(R.string.app_name), 0, getString(R.string.msg_api_response_null), getString(R.string.str_ok), false);
                        }
                }

                @Override
                public void onFailure(Call<StoreProductResponse> call, Throwable t) {
                        customProgressDialog.dismiss();
                        DialogFactory.getInstance().showAlertDialog(StoreCategoryActivity.this, getString(R.string.app_name), 0, getString(R.string.msg_api_failure), getString(R.string.str_ok), false);

                }
            });
        } else {
            DialogFactory.getInstance().showAlertDialog(StoreCategoryActivity.this, getString(R.string.app_name), 0, getString(R.string.network_error), getString(R.string.str_ok), false);
        }
    }

}
