package com.twc.hramodule.rest;



import com.twc.hramodule.model.requestbody.BaseMemberIdBody;
import com.twc.hramodule.model.requestbody.HraSaveBody;
import com.twc.hramodule.model.response.GetHraResponse;
import com.twc.hramodule.model.response.HraSaveResponse;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

/**
 Created by GurvinderS on 10/15/2016.
 */
public interface HraService {

    // @Headers({"Content-Type: application/json", "charset: utf-8"})
    @POST("Member/MemberHRA/SaveMemberHRA")
    Call<HraSaveResponse> saveHra(@Body HraSaveBody homeBody);

    @POST("Member/MemberHRA/GetHRAReport")
    Call<GetHraResponse> getHRAReport(@Body BaseMemberIdBody hraReportBody);

    @POST("Member/MemberHRA/GetHRAScoreForMember")
    Call<HraSaveResponse> getHRAScore(@Body BaseMemberIdBody hragetScoreBody);

    /*@POST("MemberHRA/GetRecommendedPrograms")
    Call<MyProgramsResponse> getRecommendedPrograms(@Body ProgramsChallengesBody programsChallengesBody);*/

}
