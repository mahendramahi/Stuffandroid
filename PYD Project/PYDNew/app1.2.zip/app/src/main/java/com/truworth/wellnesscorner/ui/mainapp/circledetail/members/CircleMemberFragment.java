package com.truworth.wellnesscorner.ui.mainapp.circledetail.members;

import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.v4.widget.NestedScrollView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import com.truworth.discoverlib.interfaces.OnLoadMoreListener;
import com.truworth.discoverlib.utils.NetworkFactory;
import com.truworth.wellnesscorner.BR;
import com.truworth.wellnesscorner.R;
import com.truworth.wellnesscorner.base.BaseFragment;
import com.truworth.wellnesscorner.databinding.FragmentCircleMembersBinding;
import com.truworth.wellnesscorner.model.CircleMemberListBean;
import com.truworth.wellnesscorner.utils.Utils;

import java.util.ArrayList;
import java.util.List;

public class CircleMemberFragment extends BaseFragment<FragmentCircleMembersBinding, CircleMemberViewModel> {
    public static final String TAG = "CircleMemberFragment";
    CircleMemberViewModel viewModel;
    List<CircleMemberListBean> memberList;
    CircleMemberAdapter circleMemberAdapter;
    private static final String CIRCLE_IDENTITY = "circleIdentity";
    String CircleIdentity = "";
    private LinearLayoutManager linearLayoutManager;
    boolean isLoadMore = false;
    private OnLoadMoreListener onLoadMoreListener;
    RecyclerView recyclerView;
    private int nestedScrollViewX = 0;
    private int nestedScrollViewY = 0;
    private Handler handler = new Handler();
    boolean _areDataLoaded = false;
    private Runnable runnable = new Runnable() {
        @Override
        public void run() {
            viewModel.loadMembers(CircleIdentity, viewModel.pageIndex);
        }
    };

    public CircleMemberFragment() {
        // Required empty public constructor
    }


    public static CircleMemberFragment newInstance(String circleIdentity) {
        CircleMemberFragment fragment = new CircleMemberFragment();
        Bundle args = new Bundle();
        args.putString(CIRCLE_IDENTITY, circleIdentity);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            CircleIdentity = getArguments().getString(CIRCLE_IDENTITY);
        }
        memberList = new ArrayList<>();
        circleMemberAdapter = new CircleMemberAdapter(memberList);
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        getViewDataBinding().nsView.scrollTo(nestedScrollViewX, nestedScrollViewY);
        viewModel.setCircleIdentity(CircleIdentity);

        recyclerView = getViewDataBinding().rvCircleMembers;
        linearLayoutManager = new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false);
        recyclerView.setLayoutManager(linearLayoutManager);
        recyclerView.setAdapter(circleMemberAdapter);

        setOnLoadMoreListener(linearLayoutManager);

        setMemberObserver();
        attachNotifySearchObserver();
        attachRemoveLoadingObserver();
        setUpArrowObserver();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (memberList != null) {
            memberList.clear();
            circleMemberAdapter.notifyDataSetChanged();
            circleMemberAdapter = null;
            memberList = null;
        }
    }

    @Override
    public void setUserVisibleHint(final boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        if (isVisibleToUser && !_areDataLoaded) {
            handler.postDelayed(runnable, 50);
            _areDataLoaded = true;
        }
    }

    @Override
    public int getBindingVariable() {
        return BR.viewModel;
    }

    @Override
    public int getLayoutId() {
        return R.layout.fragment_circle_members;
    }

    @Override
    public CircleMemberViewModel getViewModel() {
        viewModel = ViewModelProviders.of(this).get(CircleMemberViewModel.class);
        return viewModel;
    }

    private void setMemberObserver() {
        viewModel.getMembers().observe(this, new Observer<List<CircleMemberListBean>>() {
            @Override
            public void onChanged(@Nullable List<CircleMemberListBean> members) {
                getViewDataBinding().rootLayout.requestFocus();
                if (!isLoadMore) {
                    memberList.clear();
                    memberList.addAll(members);
                    circleMemberAdapter.notifyDataSetChanged();
                } else {
                    memberList.addAll(members);
                    circleMemberAdapter.notifyDataSetChanged();
                    isLoadMore = false;
                }
            }
        });
    }

    private void attachNotifySearchObserver() {
        viewModel.getNotifySearch().observe(this, new Observer<Void>() {
            @Override
            public void onChanged(@Nullable Void aVoid) {
                //Success, update UI
                if (!isLoadMore) {
                    memberList.clear();
                    circleMemberAdapter.notifyDataSetChanged();
                } else {
                    circleMemberAdapter.notifyDataSetChanged();
                    isLoadMore = false;
                }
            }
        });
    }

    private void attachRemoveLoadingObserver() {
        viewModel.getRemoveLoading().observe(this, new Observer<Void>() {
            @Override
            public void onChanged(@Nullable Void aVoid) {
                //Success, update UI
                removeProgressLoading();
            }
        });
    }

    private void setOnLoadMoreListener(final LinearLayoutManager linearLayoutManager) {
        onLoadMoreListener = new OnLoadMoreListener() {
            @Override
            public void onLoadMore() {
                if (!viewModel.isLastResult) {
                    if (memberList != null && memberList.size() > 5) {
                        memberList.add(null);
                        circleMemberAdapter.notifyItemInserted(memberList.size() - 1);
                        recyclerView.getLayoutManager().scrollToPosition(memberList.size());
                        isLoadMore = true;
                        viewModel.pageIndex = viewModel.pageIndex + 1;
                        viewModel.loadMembers(CircleIdentity, viewModel.pageIndex);
                    }
                }
            }
        };

        getViewDataBinding().nsView.setOnScrollChangeListener(new NestedScrollView.OnScrollChangeListener() {
            @Override
            public void onScrollChange(NestedScrollView v, int scrollX, int scrollY, int oldScrollX, int oldScrollY) {
                nestedScrollViewX = scrollX;
                nestedScrollViewY = scrollY;
                View view = getViewDataBinding().nsView.getChildAt(getViewDataBinding().nsView.getChildCount() - 1);
                int diff = (view.getBottom() - (getViewDataBinding().nsView.getHeight() + getViewDataBinding().nsView.getScrollY()));

                if (view != null) {
                    if ((scrollY >= (v.getChildAt(v.getChildCount() - 1).getMeasuredHeight() - v.getMeasuredHeight())) && scrollY > oldScrollY && !viewModel.loading) {
                        //code to fetch more data for endless scrolling
                        onLoadMoreListener.onLoadMore();
                        viewModel.loading = true;
                    }
                }
                if (diff >= 0) {
                    if (scrollY == 0) {
                        getViewDataBinding().imgUpArrow.setVisibility(View.GONE);
                    } else {
                        getViewDataBinding().imgUpArrow.setVisibility(View.VISIBLE);
                    }
                } else {
                    getViewDataBinding().imgUpArrow.setVisibility(View.GONE);
                }
            }
        });
    }

    private void removeProgressLoading() {
        if (memberList.size() > 0 && memberList.get(memberList.size() - 1) == null) {
            memberList.remove(memberList.size() - 1);
            circleMemberAdapter.notifyDataSetChanged();
        }
    }

    private void setUpArrowObserver() {
        viewModel.getUpArrow().observe(this, new Observer<Void>() {
            @Override
            public void onChanged(@Nullable Void avoid) {
                getViewDataBinding().nsView.fling(0);
                getViewDataBinding().nsView.smoothScrollTo(0, 0);
                new Handler().postDelayed(() -> getViewDataBinding().imgUpArrow.setVisibility(View.GONE), 500);
            }
        });
    }

    @Override
    public void onStop() {
        super.onStop();
        if (handler != null) {
            handler.removeCallbacks(runnable);
        }
    }
}

