package com.truworth.wellnesscorner.ui.mainapp.circle;

import android.content.Intent;
import android.databinding.ObservableBoolean;

import com.truworth.wellnesscorner.TheWellnessCornerApp;
import com.truworth.wellnesscorner.base.BaseViewModel;
import com.truworth.wellnesscorner.data.SharedPreferenceHelper;
import com.truworth.wellnesscorner.model.Article;
import com.truworth.wellnesscorner.model.Discussions;
import com.truworth.wellnesscorner.model.MyCircle;
import com.truworth.wellnesscorner.model.PopularCircle;
import com.truworth.wellnesscorner.model.PopularProduct;
import com.truworth.wellnesscorner.repo.DashboardRepository;
import com.truworth.wellnesscorner.repo.model.response.MyCirclesResponse;
import com.truworth.wellnesscorner.repo.model.response.PopularArticlesResponse;
import com.truworth.wellnesscorner.repo.model.response.PopularCircleResponse;
import com.truworth.wellnesscorner.repo.model.response.PopularDiscussionsResponse;
import com.truworth.wellnesscorner.repo.model.response.PopularProductResponse;
import com.truworth.wellnesscorner.utils.AppConstants;
import com.truworth.wellnesscorner.utils.SingleLiveEvent;
import com.twc.store.StoreActivity;
import com.twc.store.model.beans.StoreUser;
import com.twc.store.utils.StoreConfig;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;

/**
 * Created by rajeshs on 4/13/2018.
 */

public class CircleViewModel extends BaseViewModel {
    public ObservableBoolean isPopularCircleLoaded = new ObservableBoolean();
    public ObservableBoolean isButtonDataLoaded = new ObservableBoolean();
    public ObservableBoolean isStoreDataLoaded = new ObservableBoolean();
    public ObservableBoolean isArticlesLoaded = new ObservableBoolean();
    public ObservableBoolean isCommunityDiscussionLoaded = new ObservableBoolean();

    public ObservableBoolean isSwipeRefresh =new ObservableBoolean();

    public SingleLiveEvent<ArrayList<MyCircle>> getMyCircles() {
        return myCircles;
    }

    public SingleLiveEvent<ArrayList<MyCircle>> myCircles = new SingleLiveEvent<>();

    public SingleLiveEvent<ArrayList<PopularProduct>> getProducts() {
        return products;
    }

    public SingleLiveEvent<ArrayList<PopularProduct>> products = new SingleLiveEvent<>();

    public SingleLiveEvent<ArrayList<PopularCircle>> getPopularCircles() {
        return popularCircles;
    }

    public SingleLiveEvent<ArrayList<PopularCircle>> popularCircles = new SingleLiveEvent<>();

    public SingleLiveEvent<ArrayList<Article>> getArticles() {
        return articles;
    }

    public SingleLiveEvent<ArrayList<Article>> articles = new SingleLiveEvent<>();

    public SingleLiveEvent<List<Discussions>> discussions = new SingleLiveEvent<>();

    public SingleLiveEvent<List<Discussions>> getDiscussions() {
        return discussions;
    }

    SingleLiveEvent<Void> onPlanClick = new SingleLiveEvent<>();
    SingleLiveEvent<Void> onDeviceClick = new SingleLiveEvent<>();
    SingleLiveEvent<Void> onSupplementsClick = new SingleLiveEvent<>();
    SingleLiveEvent<Void> onSpaClick = new SingleLiveEvent<>();
    SingleLiveEvent<Void> upArrow = new SingleLiveEvent<>();

    public SingleLiveEvent<Void> getOnPlanClick() {
        return onPlanClick;
    }

    public SingleLiveEvent<Void> getOnDeviceClick() {
        return onDeviceClick;
    }

    public SingleLiveEvent<Void> getOnSupplementsClick() {
        return onSupplementsClick;
    }

    public SingleLiveEvent<Void> getOnSpaClick() {
        return onSpaClick;
    }

    public SingleLiveEvent<Void> getUpArrow() {
        return upArrow;
    }

    @Inject
    DashboardRepository dashboardRepository;

    public CircleViewModel() {
        TheWellnessCornerApp.getApp().component().inject(this);
        isSwipeRefresh.set(false);
    }


    public void loadMyCircles() {
      isRefresh(isSwipeRefresh.get());
        dashboardRepository.getMyCircles().subscribe(new Observer<MyCirclesResponse>() {
            @Override
            public void onSubscribe(Disposable d) {

            }

            @Override
            public void onNext(MyCirclesResponse myCirclesResponse) {
                if (!myCirclesResponse.isHasError()) {
                    myCircles.setValue(myCirclesResponse.getData());
                }
            }

            @Override
            public void onError(Throwable e) {
                setIsLoading(false);
                isSwipeRefresh.set(false);
            }

            @Override
            public void onComplete() {
                setIsLoading(false);
                isSwipeRefresh.set(false);

            }
        });
    }


    public void loadPopularCircles() {
        isRefresh(isSwipeRefresh.get());
        dashboardRepository.getPopularCircles().subscribe(new Observer<PopularCircleResponse>() {
            @Override
            public void onSubscribe(Disposable d) {

            }

            @Override
            public void onNext(PopularCircleResponse popularCircleResponse) {
                isButtonDataLoaded.set(true);
                if (!popularCircleResponse.isHasError()) {
                    if (popularCircleResponse.getData().size() > 0) {
                        isPopularCircleLoaded.set(true);
                    }
                    popularCircles.setValue(popularCircleResponse.getData());
                }
            }

            @Override
            public void onError(Throwable e) {
                isButtonDataLoaded.set(true);
                setIsLoading(false);
            }

            @Override
            public void onComplete() {
                setIsLoading(false);
            }
        });
    }

    public void loadPopularProducts() {
        isRefresh(isSwipeRefresh.get());
        dashboardRepository.getPopularProducts().subscribe(new Observer<PopularProductResponse>() {
            @Override
            public void onSubscribe(Disposable d) {

            }

            @Override
            public void onNext(PopularProductResponse popularProductResponse) {

                if (!popularProductResponse.isHasError()) {
                    if (popularProductResponse.getData().size() > 0) {
                        isStoreDataLoaded.set(true);
                    }

                    products.setValue(popularProductResponse.getData());
                }
            }

            @Override
            public void onError(Throwable e) {

                setIsLoading(false);
            }

            @Override
            public void onComplete() {
                isButtonDataLoaded.set(true);
                setIsLoading(false);
            }
        });
    }

    public void loadPopularArticles() {
        isRefresh(isSwipeRefresh.get());
        dashboardRepository.getPopularArticles().subscribe(new Observer<PopularArticlesResponse>() {
            @Override
            public void onSubscribe(Disposable d) {

            }

            @Override
            public void onNext(PopularArticlesResponse popularArticlesResponse) {
                if (!popularArticlesResponse.isHasError()) {
                    if(popularArticlesResponse.getData().size()>0){
                        isArticlesLoaded.set(true);
                    }
                    articles.setValue(popularArticlesResponse.getData());
                }
            }

            @Override
            public void onError(Throwable e) {
                setIsLoading(false);
            }

            @Override
            public void onComplete() {
                setIsLoading(false);
            }
        });
    }

    public void loadPopularDiscussions() {
        isRefresh(isSwipeRefresh.get());
        dashboardRepository.getPopularDiscussions().subscribe(new Observer<PopularDiscussionsResponse>() {
            @Override
            public void onSubscribe(Disposable d) {

            }

            @Override
            public void onNext(PopularDiscussionsResponse popularDiscussionsResponse) {
                if (!popularDiscussionsResponse.isHasError()) {
                    if(popularDiscussionsResponse.getData().size()>0){
                        isCommunityDiscussionLoaded.set(true);
                    }
                    discussions.setValue(popularDiscussionsResponse.getData());
                }
            }

            @Override
            public void onError(Throwable e) {
                setIsLoading(false);
            }

            @Override
            public void onComplete() {
                setIsLoading(false);
            }
        });
    }

    public void navigateToPlan() {
        onPlanClick.call();
    }

    public void navigateToDevices() {
        onDeviceClick.call();
    }

    public void navigateToSupplements() {
        onSupplementsClick.call();
    }

    public void navigateToSpa() {
        onSpaClick.call();
    }

    public void upArrowClick() {
        upArrow.call();
    }

    public void isRefresh(boolean isShowLoading){
        if(isShowLoading)
            setIsLoading(false);
        else
            setIsLoading(true);
    }
}
