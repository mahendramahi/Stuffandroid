package com.truworth.wellnesscorner.repo.model.response;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * Created by GurvinderS on 4/11/2018.
 */

public class ScreenNameResponse {
    private DataBean data;
    private boolean hasError;
    @SerializedName("error")
    @Expose
    private Error error;

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public boolean isHasError() {
        return hasError;
    }

    public void setHasError(boolean hasError) {
        this.hasError = hasError;
    }

    public Error getError() {
        return error;
    }

    public void setError(Error error) {
        this.error = error;
    }

    public static class DataBean {

        private boolean isScreenNameExist;

        public boolean isIsScreenNameExist() {
            return isScreenNameExist;
        }

        public void setIsScreenNameExist(boolean isScreenNameExist) {
            this.isScreenNameExist = isScreenNameExist;
        }
    }


}
