package com.twc.hramodule.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.widget.DrawerLayout;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import com.twc.hramodule.R;
import com.twc.hramodule.R2;
import com.twc.hramodule.utils.Utils;

import butterknife.BindView;
import butterknife.OnClick;

/**
 * If this code works it was written by Somesh Kumar on 21 October, 2016. If not, I don't know who wrote it.
 */
public class HraScreen17Fragment extends BaseFragment {
    @BindView(R2.id.ivHRABack)
    ImageView ivHRABack;
    @BindView(R2.id.ivCancelHRA)
    ImageView ivCancelHRA;
    @BindView(R2.id.btnNextQuestion)
    Button btnNextQuestion;

    public static HraScreen17Fragment newInstance(Bundle bundle) {
        HraScreen17Fragment fragment = new HraScreen17Fragment();
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        view.setFocusableInTouchMode(true);
        view.requestFocus();
        view.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (keyCode == KeyEvent.KEYCODE_BACK && event.getAction() == KeyEvent.ACTION_DOWN) {
                    onBack();
                    return true;
                }
                return false;
            }
        });
    }


    @Override
    public int getFragmentLayout() {
        return R.layout.fragment_hra_type9;
    }

    @Override
    public void onFragmentReady() {

    }


    @OnClick({R2.id.btnNextQuestion, R2.id.ivCancelHRA, R2.id.ivHRABack})
    public void onClick(View view) {
        int i = view.getId();
        if (i == R.id.ivHRABack) {
            onBack();

        } else if (i == R.id.ivCancelHRA) {
            cancelHra();

        } else if (i == R.id.btnNextQuestion) {
            Utils.replaceFragment(getFragmentManager(), HraQ16NewFragment.newInstance(getArguments()), HraQ16NewFragment.class.getSimpleName(), true, R.id.fragmentContainerHra);

        }
    }

    private void onBack() {
        Utils.replaceFragment(getFragmentManager(), HraQ15NewFragment.newInstance(getArguments()), HraQ15NewFragment.class.getSimpleName(), true, R.id.fragmentContainerHra);
    }

    private void cancelHra() {
        // if isRetakeTest parameter is true, then user always came here from hra report
        if (getArguments().containsKey("isRetakeTest") && getArguments().getBoolean("isRetakeTest")) {
            getFragmentManager().popBackStackImmediate(HraRiskGradeFragment.class.getSimpleName(), 0);
        } else {
            getActivity().finish();
        }
    }

}
