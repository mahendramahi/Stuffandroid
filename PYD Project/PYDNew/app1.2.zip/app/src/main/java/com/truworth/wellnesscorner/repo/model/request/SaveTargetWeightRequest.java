package com.truworth.wellnesscorner.repo.model.request;

public class SaveTargetWeightRequest {

    private String MemberID;
    private String Reading;

    public String getMemberID() {
        return MemberID;
    }

    public void setMemberID(String memberID) {
        MemberID = memberID;
    }

    public String getReading() {
        return Reading;
    }

    public void setReading(String reading) {
        Reading = reading;
    }
}
