package com.truworth.stepmodule.model;


import java.util.List;

/**
 * Created by PalakC on 11/17/2017.
 */

public class GetMisFitResponse {

    private List<FitBitStepsItem> summary;
    private String error_message;
    private int steps;
    private double calories;
    private double activityCalories;

    public List<FitBitStepsItem> getSummary() {
        return summary;
    }

    public void setSummary(List<FitBitStepsItem> summary) {
        this.summary = summary;
    }

    public String getError_message() {
        return error_message;
    }

    public void setError_message(String error_message) {
        this.error_message = error_message;
    }

    public int getSteps() {
        return steps;
    }

    public void setSteps(int steps) {
        this.steps = steps;
    }

    public double getCalories() {
        return calories;
    }

    public void setCalories(double calories) {
        this.calories = calories;
    }

    public double getActivityCalories() {
        return activityCalories;
    }

    public void setActivityCalories(double activityCalories) {
        this.activityCalories = activityCalories;
    }
}
