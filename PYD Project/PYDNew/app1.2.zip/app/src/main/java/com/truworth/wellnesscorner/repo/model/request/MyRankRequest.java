package com.truworth.wellnesscorner.repo.model.request;

import com.google.gson.annotations.SerializedName;

public class MyRankRequest extends BaseRequest{

    //private String challengeIdentity;

    private boolean isToday;

    /*public String getChallengeIdentity() {
        return challengeIdentity;
    }

    public void setChallengeIdentity(String challengeIdentity) {
        this.challengeIdentity = challengeIdentity;
    }*/

    public boolean isToday() {
        return isToday;
    }

    public void setToday(boolean today) {
        isToday = today;
    }
}
