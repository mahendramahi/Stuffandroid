package com.twc.dailylog.fragments;

import android.content.DialogInterface;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;

import com.twc.dailylog.MealActivity;
import com.twc.dailylog.R;
import com.twc.dailylog.R2;
import com.twc.dailylog.adapter.FoodSearchAdapter;
import com.twc.dailylog.dialog.AddSuggestedFoodDialog;
import com.twc.dailylog.interfaces.ISearchResultCallback;
import com.twc.dailylog.model.beans.DailyLogUser;
import com.twc.dailylog.model.beans.FoodSearchItem;
import com.twc.dailylog.model.beans.FoodSearchTypeItem;
import com.twc.dailylog.model.requestbody.FoodSearchBody;
import com.twc.dailylog.model.response.GetFoodSearchResponse;
import com.twc.dailylog.rest.RestClient;
import com.twc.dailylog.utils.DailyLogConfig;
import com.twc.dailylog.utils.DialogFactory;
import com.twc.dailylog.utils.NetworkFactory;
import com.twc.dailylog.utils.Utils;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by PalakC on 7/5/2016.
 */
public class FoodSearchTypeFragment extends BaseFragment implements ISearchResultCallback {

    @BindView(R2.id.rvFoodSearch)
    RecyclerView rvFoodSearch;

    @BindView(R2.id.rootView)
    RelativeLayout rootView;

    @BindView(R2.id.progressBar)
    ProgressBar progressBar;
    private FoodSearchTypeFragment foodSearchTypeFragment;
    private FoodSearchAdapter foodSearchAdapter;
    private ArrayList<FoodSearchItem> foodSearchItemList;
    private String searchContent = "";
    private String lastKeyword = "";
    private GetFoodSearchResponse mGetFoodSearchResponse;

    public static FoodSearchTypeFragment newInstance() {
        return new FoodSearchTypeFragment();
    }

    @Override
    public int getFragmentLayout() {
        return R.layout.fragment_type_food_search_list;
    }

    @Override
    public void onFragmentReady() {
        progressBar.setVisibility(View.GONE);
        rvFoodSearch.setHasFixedSize(true);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getActivity());
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        rvFoodSearch.setLayoutManager(linearLayoutManager);

        if (foodSearchAdapter != null) {
            rvFoodSearch.setAdapter(foodSearchAdapter);
            foodSearchAdapter.notifyDataSetChanged();
            ((FoodSearchFragment) getParentFragment()).updateTabsCountValues();
        }
        else {

        }


    }

    private void updateTabValues(List<FoodSearchTypeItem> mList) {
        ((FoodSearchFragment) getParentFragment()).updateTabsCountList(mList);
    }

    private void foodSearchApiCall(final String searchContent) {
        if (NetworkFactory.getInstance().isNetworkAvailable(getActivity())) {
            progressBar.setVisibility(View.VISIBLE);
            FoodSearchBody foodSearchBody = new FoodSearchBody();
            foodSearchBody.setMemberID(DailyLogConfig.dailyLogUser.getUserID());
            String foodType = ((FoodSearchFragment) getParentFragment()).adapter.getPageTitle(((FoodSearchFragment) getParentFragment()).getCurrentTab()).toString();
            foodSearchBody.setFoodDataFor(foodType);
            foodSearchBody.setFOODNAME(searchContent);
            RestClient restClient = new RestClient(getActivity(), DailyLogConfig.BASE_URL, DailyLogConfig.DEBUG);
            restClient.getDailyLogService().getFoodSearchByKeyword(foodSearchBody).enqueue(new Callback<GetFoodSearchResponse>() {
                @Override
                public void onResponse(Call<GetFoodSearchResponse> call, Response<GetFoodSearchResponse> response) {
                    if (isAdded() && getActivity() != null) {
                        progressBar.setVisibility(View.GONE);
                        Utils.hideSoftKeyboard(getActivity());
                        if (response != null && response.body() != null && response.body().getFoodSearchList() != null) {
                            if (response.body().getStatus() == 0) {
                                mGetFoodSearchResponse = response.body();
                                if (response.body().getFoodSearchList().size() > 0) {

                                    foodSearchItemList.clear();
                                    foodSearchAdapter = null;

                                    foodSearchItemList.addAll(response.body().getFoodSearchList());
                                    Utils.printLog("rec food List", foodSearchItemList.size() + "");

                                    if (foodSearchAdapter != null) {
                                        foodSearchAdapter.notifyDataSetChanged();
                                    }
                                    else {
                                        foodSearchAdapter = new FoodSearchAdapter(foodSearchItemList, getActivity());
                                        rvFoodSearch.setAdapter(foodSearchAdapter);
                                    }

                                }
                                else {
                                    DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, " The food you are looking for is not available. Would you like us to add this in food list?", "Yes", new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialogInterface, int i) {

                                            dialogInterface.dismiss();
                                            Bundle bundle = new Bundle();
                                            bundle.putString("suggestedFoodName", searchContent);
                                          AddSuggestedFoodDialog addSuggestedFoodDialog = new AddSuggestedFoodDialog(getActivity(), bundle);
                                       addSuggestedFoodDialog.show();

                                        }
                                    }, "No", new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialogInterface, int i) {
                                            dialogInterface.dismiss();
                                        }
                                    }, false);

                                }
                                if (mGetFoodSearchResponse.getFoodSearchTypeList() != null &&
                                        mGetFoodSearchResponse.getFoodSearchTypeList().size() > 0) {
                                    updateTabValues(mGetFoodSearchResponse.getFoodSearchTypeList());
                                }
                            }
                            else{
                                DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, " The food you are looking for is not available. Would you like us to add this in food list?", "Yes", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialogInterface, int i) {

                                        dialogInterface.dismiss();
                                        Bundle bundle = new Bundle();
                                        bundle.putString("suggestedFoodName", searchContent);
                                        AddSuggestedFoodDialog addSuggestedFoodDialog = new AddSuggestedFoodDialog(getActivity(), bundle);
                                          addSuggestedFoodDialog.show();

                                    }
                                }, "No", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialogInterface, int i) {
                                        dialogInterface.dismiss();
                                    }
                                }, false);
                            }
                        }
                    }
                }

                @Override
                public void onFailure(Call<GetFoodSearchResponse> call, Throwable t) {
                    if (isAdded() && getActivity() != null) {
                        progressBar.setVisibility(View.GONE);
                        Utils.hideSoftKeyboard(getActivity());
                    }
                }
            });
        }
        else {
            Utils.showSnackBarMessage(rootView, getString(R.string.internet_not_available));
        }
    }

    @Override
    public void onTextSubmitSuccess(String searchText, String lastKeyword) {
        this.lastKeyword = searchContent;
        this.searchContent = searchText;
        foodSearchTypeFragment = this;
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                if (!foodSearchTypeFragment.lastKeyword.equalsIgnoreCase(searchContent)) {
                    foodSearchApiCall(searchContent);
                }
            }
        }, 100);

    }

    @Override
    public void onTextChangedSuccess(String searchText) {
        filterFoodList(searchText);
    }

    private void filterFoodList(String content) {
        if (foodSearchAdapter != null) {
            foodSearchAdapter.setSearchType(content);
            foodSearchAdapter.getFilter().filter(content);
        }
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        if (isVisibleToUser && rootView != null && foodSearchAdapter == null) {
            if (foodSearchItemList == null) {
                foodSearchItemList = new ArrayList<>();
            }
            if (foodSearchItemList.size() == 0) {
                searchContent = ((FoodSearchFragment) getParentFragment()).currentSearchContent;
                Utils.printLog("searchContent", searchContent + "");
                if (searchContent != null && searchContent.trim().length() >= 3) {
                    foodSearchApiCall(searchContent);
                }
            }
        }
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        foodSearchItemList = new ArrayList<>();

    }

    @Override
    public void onResume() {
        super.onResume();
        ((MealActivity) getActivity()).setToolBarTitle("");
        ((MealActivity) getActivity()).showHomeAsUpEnableToolbar();

    }
}
