package com.twc.dailylog.fragments;

import android.app.SearchManager;
import android.content.Context;
import android.database.Cursor;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SearchView;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;

import com.twc.dailylog.MealActivity;
import com.twc.dailylog.R;
import com.twc.dailylog.R2;
import com.twc.dailylog.adapter.SearchExerciseAdapter;
import com.twc.dailylog.adapter.TrackExerciseSectionAdapter;
import com.twc.dailylog.interfaces.OnTrackerReadingSave;
import com.twc.dailylog.model.beans.ExerciseItem;
import com.twc.dailylog.model.beans.ExerciseSectionItem;
import com.twc.dailylog.model.requestbody.SearchExerciseBody;
import com.twc.dailylog.model.response.TrackExerciseResponse;
import com.twc.dailylog.rest.RestClient;
import com.twc.dailylog.utils.DailyLogConfig;
import com.twc.dailylog.utils.DialogFactory;
import com.twc.dailylog.utils.NetworkFactory;
import com.twc.dailylog.utils.Utils;
import com.twc.dailylog.views.NoDataView;
import com.twc.greendaolib.ExerciseItemDao;
import com.twc.greendaolib.GreenDaoApp;

import java.util.ArrayList;

import butterknife.BindView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by PalakC on 7/6/2016.
 */
public class TrackExerciseFragment extends BaseFragment {

    @BindView(R2.id.exerciseRecycleView)
    RecyclerView exerciseRecycleView;

    @BindView(R2.id.rootView)
    LinearLayout rootView;

    @BindView(R2.id.noDataView)
    NoDataView noDataView;
    private OnTrackerReadingSave onTrackerReadingSave;



    private SearchView searchView = null;
    private SearchExerciseAdapter mSearchExerciseAdapter;
    private TrackExerciseSectionAdapter trackExerciseSectionAdapter;
    private ArrayList<ExerciseItem> mExerciseItems;
    private SearchView.OnQueryTextListener queryTextListener;

    public static TrackExerciseFragment newInstance(Bundle bundle) {

        TrackExerciseFragment trackExerciseFragment=new TrackExerciseFragment();
        trackExerciseFragment.setArguments(bundle);
        return trackExerciseFragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
        mExerciseItems = new ArrayList<>();
        mSearchExerciseAdapter = new SearchExerciseAdapter(mExerciseItems, getActivity(),onTrackerReadingSave);

    }

    @Override
    public int getFragmentLayout() {
        return R.layout.fragment_trackexercise;
    }


    @Override
    public void onFragmentReady() {

      /*  tvNoTitle.setText(getString(R.string.no_track_exercise_available));
        tvNoSubtitle.setText(getString(R.string.no_track_exercise_msg));
        imgNoData.setImageResource(R.drawable.no_message_icon);*/

        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getActivity());
        exerciseRecycleView.setLayoutManager(layoutManager);

        if (mExerciseItems.size() > 0) {
            if (mSearchExerciseAdapter != null)
                exerciseRecycleView.setAdapter(mSearchExerciseAdapter);
            else {
                mSearchExerciseAdapter = new SearchExerciseAdapter(mExerciseItems, getActivity(),onTrackerReadingSave);
                exerciseRecycleView.setAdapter(mSearchExerciseAdapter);
            }
        } else {
            if (trackExerciseSectionAdapter == null) {
                getAllRecentExercise();
            } else {
                exerciseRecycleView.setAdapter(trackExerciseSectionAdapter);
            }
        }

    }

    @Override
    public void onResume() {
        super.onResume();
        ((MealActivity) getActivity()).showHomeAsUpEnableToolbar();
        ((MealActivity) getActivity()).setToolBarTitle("");
    }

    /*
    * create search option menu*/
    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.menu_search, menu);
        MenuItem searchItem = menu.findItem(R.id.action_search);
        SearchManager searchManager = (SearchManager) getActivity().getSystemService(Context.SEARCH_SERVICE);

        if (searchItem != null) {
            searchView = (SearchView) searchItem.getActionView();
        }
        if (searchView != null) {
            searchView.setSearchableInfo(searchManager.getSearchableInfo(getActivity().getComponentName()));
            searchView.setIconified(true);
            searchView.onActionViewExpanded();
            searchView.setQueryHint("Search");
            queryTextListener = new SearchView.OnQueryTextListener() {
                @Override
                public boolean onQueryTextChange(String newText) {
                    // mExerciseItems.clear(); committed by somesh on 18-Oct-2016 due to a crash when user clicks on close icon in search bar it gets crashed after clicking result.
                    return true;
                }

                @Override
                public boolean onQueryTextSubmit(String query) {
                    if (query.trim().length() >= 3)
                        trackExerciseApiCall(query);

                    return true;
                }
            };
            searchView.setOnQueryTextListener(queryTextListener);
            if (getArguments() != null) {
                String itemName = getArguments().getString("itemName");
                if (searchView != null) {
                    searchView.setQuery(itemName,true);
                }
            }

        }
        super.onCreateOptionsMenu(menu, inflater);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int i = item.getItemId();
        if (i == R.id.action_search) {
        } else {
        }
        searchView.setOnQueryTextListener(queryTextListener);
        return super.onOptionsItemSelected(item);
    }


    /*
    * call API for search item*/
    private void trackExerciseApiCall(String searchContent) {
        if (NetworkFactory.getInstance().isNetworkAvailable(getActivity())) {

            SearchExerciseBody searchBody = new SearchExerciseBody();
            searchBody.setUserID(DailyLogConfig.dailyLogUser.getUserID());
            searchBody.setKeyword(searchContent);

            RestClient restClient = new RestClient(getActivity(), DailyLogConfig.BASE_URL, DailyLogConfig.DEBUG);
            restClient.getDailyLogService().getTrackExercise(searchBody).enqueue(new Callback<TrackExerciseResponse>() {
                @Override
                public void onResponse(Call<TrackExerciseResponse> call, Response<TrackExerciseResponse> response) {
                    if (isAdded() && getActivity() != null) {

                        if (response != null && response.body() != null) {
                            if (response.body().getStatus() == 0) {
                                if(response.body().getData()!=null) {
                                    if (response.body().getData().size() > 0) {
                                        mExerciseItems.clear();
                                        mExerciseItems.addAll(response.body().getData());
                                        exerciseRecycleView.setAdapter(mSearchExerciseAdapter);
                                        mSearchExerciseAdapter.notifyDataSetChanged();
                                        exerciseRecycleView.setVisibility(View.VISIBLE);
                                        //llNoRecentData.setVisibility(View.GONE);
                                        noDataView.setVisibility(View.GONE);
                                    } else {
                                        exerciseRecycleView.setVisibility(View.GONE);
                                        //llNoRecentData.setVisibility(View.VISIBLE);
                                        noDataView.setVisibility(View.VISIBLE);
                                    }
                                }
                            }
                        } else {
                            DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_response_null), getString(R.string.str_ok), false);
                            // Toast.makeText(getActivity(), getString(R.string.msg_api_response_null), Toast.LENGTH_SHORT).show();
                        }
                    }

                }

                @Override
                public void onFailure(Call<TrackExerciseResponse> call, Throwable t) {
                    if (isAdded() && getActivity() != null) {
                        DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_failure), getString(R.string.str_ok), false);
                        // Toast.makeText(getActivity(), getString(R.string.msg_api_failure), Toast.LENGTH_SHORT).show();
                    }
                }
            });
        } else {
            Utils.showSnackBarMessage(rootView, getString(R.string.internet_not_available));
        }
    }

    private void getAllRecentExercise() {

        ExerciseItemDao exerciseItemDao = GreenDaoApp.getInstance(getActivity()).getDaoSession(getActivity()).getExerciseItemDao();
        //Query query = exerciseItemDao.queryBuilder().build();
      //  ArrayList<com.truworth.wellnesscorner.model.database.ExerciseItem> exerciseItems = (ArrayList<com.truworth.wellnesscorner.model.database.ExerciseItem>) query.list();

        String queryExercise = "select activity,ACTIVITY_DURATION,CALORIES_BURNED_IN1_MIN,CALORIES_BURNED " +
                "from EXERCISE_ITEM group by activity";
        Cursor cursor = exerciseItemDao.getDatabase().rawQuery(queryExercise,null);
        ArrayList<com.twc.greendaolib.ExerciseItem> exerciseItems
                = new ArrayList<>();
        if(cursor!=null && cursor.moveToFirst()){
            do{
                com.twc.greendaolib.ExerciseItem exerciseItem = new com.twc.greendaolib.ExerciseItem();
                exerciseItem.setActivity(cursor.getString(0));
                exerciseItem.setActivityDuration(cursor.getInt(1));
                exerciseItem.setCaloriesBurnedIn1MIn(cursor.getString(2));
                exerciseItem.setCaloriesBurned(cursor.getString(3));
                exerciseItems.add(exerciseItem);
            }while (cursor.moveToNext());
        }


        Utils.printLog("exercise list", exerciseItems.size() + "");

        if (exerciseItems.size() > 0) {
            /* create sections arrayList of date using cursor*/
            ArrayList<ExerciseSectionItem> sectionItemsList = new ArrayList<>();
            ExerciseSectionItem sectionItem = new ExerciseSectionItem();
            sectionItem.setSectionName("Recent");
            sectionItem.setmExerciseItemsList(exerciseItems);
            sectionItemsList.add(sectionItem);

            trackExerciseSectionAdapter = new TrackExerciseSectionAdapter(sectionItemsList, getActivity(),onTrackerReadingSave);
            exerciseRecycleView.setAdapter(trackExerciseSectionAdapter);
            exerciseRecycleView.setVisibility(View.VISIBLE);
            //llNoRecentData.setVisibility(View.GONE);
            noDataView.setVisibility(View.GONE);
        } else {
            exerciseRecycleView.setVisibility(View.GONE);
            //llNoRecentData.setVisibility(View.VISIBLE);
            noDataView.setVisibility(View.VISIBLE);
        }

    }
    public void setTrackerReadingCallback(OnTrackerReadingSave onTrackerReadingSave) {
        this.onTrackerReadingSave = onTrackerReadingSave;
    }
}
