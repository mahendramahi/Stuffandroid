package com.twc.remindermodule.receiver;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.support.v4.app.NotificationCompat;

import com.twc.remindermodule.R;
import com.twc.remindermodule.TTSActivity;
import com.twc.remindermodule.rest.ReminderConfig;
import com.twc.remindermodule.service.TTS;
import com.twc.remindermodule.service.TTS1;
import com.twc.remindermodule.utils.Constant;

public class AlarmReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent.getExtras() != null) {
            //  if (!ReminderConfig.reminderUser.getUserID().equals("")) {
            //   if (ReminderConfig.reminderUser.isNotify()) {
            sendNotification(context, intent.getExtras().getInt("id"),
                    intent.getExtras().getString("title"),
                    intent.getExtras().getString("message"));
            // }
            // }
        }
    }


    private void sendNotification(Context context, int id, String title, String message) {
        NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);

        Uri defaultSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel notificationChannel = new NotificationChannel(Constant.NOTIFICATION_CHANNEL_ID_REMINDERS,
                    Constant.NOTIFICATION_CHANNEL_NAME_REMINDERS,
                    NotificationManager.IMPORTANCE_HIGH);
            notificationManager.createNotificationChannel(notificationChannel);
        }
        NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(context, Constant.NOTIFICATION_CHANNEL_ID_REMINDERS)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle(context.getString(R.string.app_name))
                .setContentText(title).setStyle(new NotificationCompat.BigTextStyle().bigText(title))
                .setVibrate(new long[]{1000, 1000, 1000, 1000, 1000})
                .setAutoCancel(true)
                .setPriority(Notification.PRIORITY_HIGH)
                .setSound(defaultSoundUri);


        notificationManager.notify(id, notificationBuilder.build());

      /*  Intent speechIntent = new Intent();
        speechIntent.setClass(context, TTSActivity.class);
        speechIntent.putExtra("MESSAGE",title);
        speechIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK |  Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
        context.startActivity(speechIntent);
*/

       Intent intent = new Intent(context, TTS.class);
        intent.putExtra("title", title);
       if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      context.startForegroundService(intent);
        } else {
        context.startService(intent);
       }
    }
}
