package com.truworth.wellnesscorner.ui.mainapp.createpost.sharemeal;

import android.databinding.ObservableField;

import com.truworth.wellnesscorner.TheWellnessCornerApp;
import com.truworth.wellnesscorner.base.BaseViewModel;
import com.truworth.wellnesscorner.model.ShareExerciseBean;
import com.truworth.wellnesscorner.data.SharedPreferenceHelper;
import com.truworth.wellnesscorner.model.ShareMealBean;
import com.truworth.wellnesscorner.repo.CreatePostRepository;
import com.truworth.wellnesscorner.repo.DashboardRepository;
import com.truworth.wellnesscorner.repo.model.request.ShareMealRequest;
import com.truworth.wellnesscorner.repo.model.response.ShareExerciseResponse;
import com.truworth.wellnesscorner.repo.model.response.ShareMealResponse;
import com.truworth.wellnesscorner.repo.model.response.ShareMealNewResponse;
import com.truworth.wellnesscorner.utils.SingleLiveEvent;

import java.util.List;

import javax.inject.Inject;

import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;

public class ShareMealViewModel extends BaseViewModel {

    public boolean loading;
    public boolean isLastResult = false;
    public SingleLiveEvent<List<ShareExerciseBean>> exerciseHeaderList = new SingleLiveEvent<>();
    @Inject
    CreatePostRepository createPostRepository;
    public SingleLiveEvent<List<ShareExerciseBean>> getExerciseHeaderList() {
        return exerciseHeaderList;
    }

    String memberName = "";
    String memberImageUrl="";

    @Inject
    public SharedPreferenceHelper prefHelper;

    public String getMemberName() {
        return memberName;
    }

    public String getMemberImageUrl() {
        return memberImageUrl;
    }

    SingleLiveEvent<Void> trackTodayMeal = new SingleLiveEvent<Void>();

    public SingleLiveEvent<Void> getTrackTodayMeal() {
        return trackTodayMeal;
    }

    public SingleLiveEvent<List<ShareMealBean>> headerList = new SingleLiveEvent<>();

    public SingleLiveEvent<List<ShareMealBean>> getHeaderList() {
        return headerList;
    }

    public SingleLiveEvent<Void> removeLoading = new SingleLiveEvent<>();

    public SingleLiveEvent<Void> getRemoveLoading() {
        return removeLoading;
    }

    @Inject
    DashboardRepository dashboardRepository;

    public ShareMealViewModel() {
        TheWellnessCornerApp.getApp().component().inject(this);
    }

    public void loadMealPostData(int pageIndex, boolean addToDailyLog) {
        setIsLoading(true);
        ShareMealRequest shareMealRequest = new ShareMealRequest();
        shareMealRequest.setPageIndex(pageIndex);

        dashboardRepository.getPostMeal(shareMealRequest).subscribe(new Observer<ShareMealNewResponse>() {
            @Override
            public void onSubscribe(Disposable d) {

            }

            @Override
            public void onNext(ShareMealNewResponse response) {
                setIsLoading(false);
                removeLoading.call();
                loading = false;

                if (!response.isHasError()) {
                    if(addToDailyLog){
                        headerList.getValue().clear();
                    }
                    memberName = response.getData().getMemberName();
                    memberImageUrl =  response.getData().getMemberImage();
                    headerList.setValue(response.getData().getMeal());

                } else {
                    isLastResult = true;
                }
            }

            @Override
            public void onError(Throwable e) {
                removeLoading.call();
                setIsLoading(false);
            }

            @Override
            public void onComplete() {
                setIsLoading(false);
            }
        });
    }

    public void loadPostExerciseData(int pageIndex) {
        setIsLoading(true);
        ShareMealRequest shareMealRequest = new ShareMealRequest();
        shareMealRequest.setPageIndex(pageIndex);

        createPostRepository.getPostExercise(shareMealRequest).subscribe(new Observer<ShareExerciseResponse>() {
            @Override
            public void onSubscribe(Disposable d) {

            }

            @Override
            public void onNext(ShareExerciseResponse response) {
                setIsLoading(false);
                removeLoading.call();
                loading = false;

                if (!response.isHasError()) {
                    exerciseHeaderList.setValue(response.getData());

                } else {
                    isLastResult = true;
                }
            }

            @Override
            public void onError(Throwable e) {
                setIsLoading(false);
                removeLoading.call();
            }

            @Override
            public void onComplete() {
                setIsLoading(false);
            }
        });
    }

    public void trackTodayMealBtn(){
        trackTodayMeal.call();
    }
}
