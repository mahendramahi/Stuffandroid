package com.twc.store.dialog;

/**
 * Created by GurvinderS on 2/5/2018.
 */

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.view.View;
import android.view.Window;


import com.twc.store.R;
import com.twc.store.interfaces.OnLocationAccess;
import com.twc.store.views.ViewCustomRoundedTextView;


/**
 * Created by GurvinderS on 2/2/2018.
 */


public class LocationAccessDialog extends Dialog {
    private Activity activity;
    OnLocationAccess mOnLocationAccess;

    public LocationAccessDialog(@NonNull Context context, Activity activity, OnLocationAccess onLocationAccess) {
        super(context, R.style.FullScreenTheme);
        this.activity = activity;
        this.mOnLocationAccess = onLocationAccess;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        View view = activity.getLayoutInflater().inflate(R.layout.view_location_error, null);
        setContentView(view);
        setCancelable(false);
        View parent = (View) view.getParent();
        parent.setFitsSystemWindows(true);
      /*  final BottomSheetBehavior bottomSheetBehavior = BottomSheetBehavior.from(parent);
        parent.measure(0, 0);
        DisplayMetrics displaymetrics = new DisplayMetrics();
        activity.getWindowManager().getDefaultDisplay().getMetrics(displaymetrics);
        int screenHeight = displaymetrics.heightPixels;*/
        //bottomSheetBehavior.setPeekHeight(screenHeight);
        ViewCustomRoundedTextView btnEnable = view.findViewById(R.id.btnEnable);
        btnEnable.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mOnLocationAccess.onAccess();
            }
        });

      /*  final Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                bottomSheetBehavior.setState(BottomSheetBehavior.STATE_EXPANDED);
            }
        }, 100);


        bottomSheetBehavior.setBottomSheetCallback(new BottomSheetBehavior.BottomSheetCallback() {
            @Override
            public void onStateChanged(@NonNull View bottomSheet, int newState) {
                if (newState == BottomSheetBehavior.STATE_DRAGGING) {
                    bottomSheetBehavior.setState(BottomSheetBehavior.STATE_EXPANDED);
                }
            }

            @Override
            public void onSlide(@NonNull View bottomSheet, float slideOffset) {
            }
        });*/
    }
}
