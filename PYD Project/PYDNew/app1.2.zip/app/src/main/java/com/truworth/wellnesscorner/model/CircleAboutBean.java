package com.truworth.wellnesscorner.model;

import java.util.List;

public class CircleAboutBean {

    private String circleName;
    private String circleImage;
    private int totalMembers;
    private String circleDescription;
    private String circleCreatedOn;
    private CircleAccess circleAccessData;
    private List<CircleMemberDataBean> circleMemberData;
    private List<CircleCategoryDataBean> circleCategoryData;
    private boolean isMemberCircleJoin;

    public String getCircleName() {
        return circleName;
    }

    public void setCircleName(String circleName) {
        this.circleName = circleName;
    }

    public String getCircleImage() {
        return circleImage;
    }

    public void setCircleImage(String circleImage) {
        this.circleImage = circleImage;
    }

    public int getTotalMembers() {
        return totalMembers;
    }

    public void setTotalMembers(int totalMembers) {
        this.totalMembers = totalMembers;
    }

    public String getCircleDescription() {
        return circleDescription;
    }

    public void setCircleDescription(String circleDescription) {
        this.circleDescription = circleDescription;
    }

    public String getCircleCreatedOn() {
        return circleCreatedOn;
    }

    public void setCircleCreatedOn(String circleCreatedOn) {
        this.circleCreatedOn = circleCreatedOn;
    }

    public CircleAccess getCircleAccessData() {
        return circleAccessData;
    }

    public void setCircleAccessData(CircleAccess circleAccessData) {
        this.circleAccessData = circleAccessData;
    }

    public List<CircleMemberDataBean> getCircleMemberData() {
        return circleMemberData;
    }

    public void setCircleMemberData(List<CircleMemberDataBean> circleMemberData) {
        this.circleMemberData = circleMemberData;
    }

    public List<CircleCategoryDataBean> getCircleCategoryData() {
        return circleCategoryData;
    }

    public void setCircleCategoryData(List<CircleCategoryDataBean> circleCategoryData) {
        this.circleCategoryData = circleCategoryData;
    }

    public boolean isMemberCircleJoin() {
        return isMemberCircleJoin;
    }

    public void setMemberCircleJoin(boolean memberCircleJoin) {
        isMemberCircleJoin = memberCircleJoin;
    }

    public static class CircleMemberDataBean {
        private String memberName;
        private String memberImage;

        public String getMemberName() {
            return memberName;
        }

        public void setMemberName(String memberName) {
            this.memberName = memberName;
        }

        public String getMemberImage() {
            return memberImage;
        }

        public void setMemberImage(String memberImage) {
            this.memberImage = memberImage;
        }
    }
}
