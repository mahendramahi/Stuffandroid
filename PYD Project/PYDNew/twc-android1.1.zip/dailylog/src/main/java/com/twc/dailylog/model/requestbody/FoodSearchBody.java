package com.twc.dailylog.model.requestbody;

/**
 * Created by ManishJ1 on 6/30/2016.
 */
public class FoodSearchBody extends BaseBody {

    private String MemberID;
    private String FOODNAME;
    private String FoodDataFor;

    public String getMemberID() {
        return MemberID;
    }

    public void setMemberID(String memberID) {
        MemberID = memberID;
    }

    public String getFOODNAME() {
        return FOODNAME;
    }

    public void setFOODNAME(String FOODNAME) {
        this.FOODNAME = FOODNAME;
    }

    public String getFoodDataFor() {
        return FoodDataFor;
    }

    public void setFoodDataFor(String foodDataFor) {
        FoodDataFor = foodDataFor;
    }
}
