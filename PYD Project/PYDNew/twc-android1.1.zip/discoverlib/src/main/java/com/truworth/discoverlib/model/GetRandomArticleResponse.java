package com.truworth.discoverlib.model;

import java.util.List;

/**
 * Created by ManishJ1 on 7/13/2016.
 */
public class GetRandomArticleResponse {

    private int status;
    private List<ArticleItem> data;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public List<ArticleItem> getData() {
        return data;
    }

    public void setData(List<ArticleItem> data) {
        this.data = data;
    }


}
