package com.truworth.wellnesscorner.data;

import android.content.SharedPreferences;

import javax.inject.Inject;
import javax.inject.Singleton;

/**
 * Created by rajeshs on 4/4/2018.
 */
@Singleton
public class SharedPreferenceHelper {
    private SharedPreferences mSharedPreferences;


    private static final String PREF_KEY_FIRST_NAME = "PREF_KEY_FIRST_NAME";
    private static final String PREF_KEY_LAST_NAME = "PREF_KEY_LAST_NAME";
    private static final String PREF_KEY_IMAGE_URL = "PREF_KEY_IMAGE_URL";
    private static final String PREF_KEY_EMAIL = "PREF_KEY_EMAIL";
    private static final String PREF_KEY_SCREEN_NAME = "PREF_KEY_SCREEN_NAME";
    private static final String PREF_KEY_PROFILE_STEP = "PREF_KEY_PROFILE_STEP";
    private static final String PREF_KEY_TOKEN = "PREF_KEY_TOKEN";
    private static final String PREF_KEY_TOKEN_VALIDITY = "PREF_KEY_TOKEN_VALIDITY";
    private static final String PREF_KEY_DEVICE_CONNECTED = "PREF_KEY_DEVICE_CONNECTED";
    private static final String PREF_KEY_MISFIT_ACCESS_TOKEN = "misfit_access_token";
    private static final String PREF_KEY_FITBIT_ACCESS_TOKEN = "fitbit_access_token";
    private static final String PREF_KEY_EFIT_MEMBERID = "EFitMemberID";
    private static final String PREF_KEY_LastReminderUpdate = "LastReminderUpdate";


    @Inject
    public SharedPreferenceHelper(SharedPreferences mSharedPreferences) {
        this.mSharedPreferences = mSharedPreferences;
    }


    public void putData(String key, int data) {
        mSharedPreferences.edit().putInt(key, data).apply();
    }

    public int getData(String key) {
        return mSharedPreferences.getInt(key, 0);
    }

    public void saveUserData(String firstName, String lastName, String screenName, String email, String image, int profileStep) {
        mSharedPreferences.edit().putString(PREF_KEY_FIRST_NAME, firstName)
                .putString(PREF_KEY_FIRST_NAME, firstName)
                .putString(PREF_KEY_LAST_NAME, lastName)
                .putString(PREF_KEY_EMAIL, email)
                .putString(PREF_KEY_IMAGE_URL, image)
                .putInt(PREF_KEY_PROFILE_STEP, profileStep)
                .putString(PREF_KEY_SCREEN_NAME, screenName).apply();
    }

    public void saveProfileStepNumber(int stepNumber) {
        mSharedPreferences.edit().putInt(PREF_KEY_PROFILE_STEP, stepNumber)
                .apply();
    }

    public void saveTokenData(String tokenValidity, String token) {
        mSharedPreferences.edit().putString(PREF_KEY_TOKEN, token)
                .putString(PREF_KEY_TOKEN_VALIDITY, tokenValidity)
                .apply();
    }

    public String getToken() {
        return mSharedPreferences.getString(PREF_KEY_TOKEN, "");
    }

    public String getTokenValidity() {
        return mSharedPreferences.getString(PREF_KEY_TOKEN_VALIDITY, "");
    }

    public int getProfileStepNumber() {
        return mSharedPreferences.getInt(PREF_KEY_PROFILE_STEP, 0);
    }

    public String getEmailId() {
        return mSharedPreferences.getString(PREF_KEY_EMAIL, "");
    }

    public String getUserName() {
        return mSharedPreferences.getString(PREF_KEY_FIRST_NAME, "")+" "+mSharedPreferences.getString(PREF_KEY_LAST_NAME, "");
    }

    public String getFirstName() {
        return mSharedPreferences.getString(PREF_KEY_FIRST_NAME, "");
    }

    public void setPrefKeyDeviceConnected(String key){
        mSharedPreferences.edit().putString(PREF_KEY_DEVICE_CONNECTED, key).apply();
    }


    public String getPrefKeyDeviceConnected(){
        return mSharedPreferences.getString(PREF_KEY_DEVICE_CONNECTED, "");
    }
    public String getPrefKeyMisFitAccessToken() {

        return mSharedPreferences.getString(PREF_KEY_MISFIT_ACCESS_TOKEN, "");
    }

    public void setPrefKeyMisFitAccessToken(String accessToken) {
        mSharedPreferences.edit().putString(PREF_KEY_MISFIT_ACCESS_TOKEN, accessToken)
                .apply();
    }


    public String getPrefKeyFitBitAccessToken() {

        return mSharedPreferences.getString(PREF_KEY_FITBIT_ACCESS_TOKEN, "");
    }

    public void setPrefKeyFitBitAccessToken(String accessToken) {
        mSharedPreferences.edit().putString(PREF_KEY_FITBIT_ACCESS_TOKEN, accessToken)
                .apply();
    }
    public String getEFitUserId() {
        return mSharedPreferences.getString(PREF_KEY_EFIT_MEMBERID, "");
    }

    public void setEFitUserId(String userId) {
        mSharedPreferences.edit().putString(PREF_KEY_EFIT_MEMBERID, userId)
                .apply();

    }
    public void clearDeviceConnectTokenPreferences() {
        //setPrefKeyFitBitTokenType("");
        //setPrefKeyFitBitUserId("");
        setPrefKeyFitBitAccessToken("");
        setPrefKeyMisFitAccessToken("");
       // setPrefKeyGarminAccessToken("");
    }

    public void clearPrefData() {
        mSharedPreferences.edit().clear().apply();
    }

    public String getPrefKeyImageUrl() {
        return PREF_KEY_IMAGE_URL;
    }

    public String getUserImageUrl() {
        return mSharedPreferences.getString(PREF_KEY_IMAGE_URL, "");
    }


    public String getLastReminderUpdate() {
        return mSharedPreferences.getString(PREF_KEY_LastReminderUpdate, "");
    }

    public void setLastReminderUpdate(String time) {
        mSharedPreferences.edit().putString(PREF_KEY_LastReminderUpdate, time)
                .apply();

    }
}
