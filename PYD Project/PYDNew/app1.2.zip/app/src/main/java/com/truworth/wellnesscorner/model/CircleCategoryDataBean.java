package com.truworth.wellnesscorner.model;

public class CircleCategoryDataBean {
    private String categoryName;

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

}
