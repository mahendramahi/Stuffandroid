package com.truworth.wellnesscorner.ui.mainapp.circledetail.coaches;

import com.truworth.wellnesscorner.base.BaseViewModel;
import com.truworth.wellnesscorner.model.CircleCoach;

public class CoachItemViewModel extends BaseViewModel {
    CircleCoach coaches;

    public CoachItemViewModel(CircleCoach coaches) {
        this.coaches = coaches;
    }

    public CircleCoach getCoaches() {
        return coaches;
    }

    public void setCoaches(CircleCoach coaches) {
        this.coaches = coaches;
    }
}
