package com.twc.hramodule;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.Button;

import com.twc.hramodule.model.beans.HraUser;
import com.twc.hramodule.utils.HraConfig;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class TestActivity extends AppCompatActivity {

    @BindView(R2.id.btnClick)
    Button btnClick;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test);
        ButterKnife.bind(this);

    }

    @OnClick(R2.id.btnClick)
    public void navigateToHRA(){
        HraUser hraUser = new HraUser("487808","Male","Premium",
                "bearer t7HB5liL99qzdxxouhnDtLmcM_5JDILjZcDmxwnE9Ims2f2MNbGKUBv3z9L4AwFwwU_WO4_7ngNI7bCCi1Lb-8AQ7w-HhGhlaEU_41Yh_4YD-sNwFFivrTWDTSHNEbjJ0YTa-VeTgOht0sYQxsNJOqTJS2gRh-c6nYfaKXNqD63DfTEGhHujyi9bCHAaD1nJ_rr7WVrfH8uzL0nk1jXVlQE6beiWdfT-9_NmIQ9Wb2F3Jue5RTnoA1a4dc_WZG5xL7AwRMR356Tmc4dvvh_OVgOTTs7XRUqE5Km6tJeab6DDsTNb39vERXltfO65z0T8");
        HraConfig.init("Wellness","http://demo.truworthit.com/E2APWellnessWebAPI_V3/api/",hraUser,true);

        startHra(this);
    }

    public void startHra(Activity activity) {
        if (!HraConfig.APP_NAME.isEmpty() && !HraConfig.BASE_URL.isEmpty() && HraConfig.hraUser != null) {
            Intent intent = new Intent(activity, HraActivity.class);
            activity.startActivity(intent);
        } else {
            Log.d("Hra", "hralib: not initialised in right way.");
        }
    }

}
