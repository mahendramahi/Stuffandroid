package com.twc.dailylog.model.beans;

public class WeightTrackerBean {

    private boolean isShow;
    private double currentWeight;
    private String lastTrackedDate;
    private double firstWeight;
    private double targetWeight;

    public boolean isIsShow() {
        return isShow;
    }

    public void setIsShow(boolean isShow) {
        this.isShow = isShow;
    }

    public double getCurrentWeight() {
        return currentWeight;
    }

    public void setCurrentWeight(double currentWeight) {
        this.currentWeight = currentWeight;
    }

    public String getLastTrackedDate() {
        return lastTrackedDate;
    }

    public void setLastTrackedDate(String lastTrackedDate) {
        this.lastTrackedDate = lastTrackedDate;
    }

    public double getFirstWeight() {
        return firstWeight;
    }

    public void setFirstWeight(double firstWeight) {
        this.firstWeight = firstWeight;
    }

    public double getTargetWeight() {
        return targetWeight;
    }

    public void setTargetWeight(double targetWeight) {
        this.targetWeight = targetWeight;
    }
}
