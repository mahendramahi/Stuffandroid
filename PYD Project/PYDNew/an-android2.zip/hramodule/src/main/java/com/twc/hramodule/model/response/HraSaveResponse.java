package com.twc.hramodule.model.response;

/**
 * Created by GurvinderS on 10/15/2016.
 */
public class HraSaveResponse {

    private DataBean Data;
    private int status;
    private boolean isHraAvailable;

    public DataBean getData() {
        return Data;
    }

    public void setData(DataBean Data) {
        this.Data = Data;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public boolean isIsHraAvailable() {
        return isHraAvailable;
    }

    public void setIsHraAvailable(boolean isHraAvailable) {
        this.isHraAvailable = isHraAvailable;
    }

    public static class DataBean {
        private int Score;
        private String Grade;
        private String Message;

        public int getScore() {
            return Score;
        }

        public void setScore(int Score) {
            this.Score = Score;
        }

        public String getGrade() {
            return Grade;
        }

        public void setGrade(String Grade) {
            this.Grade = Grade;
        }

        public String getMessage() {
            return Message;
        }

        public void setMessage(String Message) {
            this.Message = Message;
        }
    }
}
