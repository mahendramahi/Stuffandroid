package com.twc.dailylog.adapter;

import android.app.Activity;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.twc.dailylog.R;
import com.twc.dailylog.fragments.TrackActivityFragment;
import com.twc.dailylog.fragments.TrackExerciseFragment;
import com.twc.dailylog.interfaces.OnTrackerReadingSave;
import com.twc.dailylog.model.beans.ExerciseItem;
import com.twc.dailylog.utils.DateFactory;
import com.twc.dailylog.utils.Utils;

import java.util.ArrayList;

/**
 * Created by PalakC on 7/5/2016.
 */
public class SearchExerciseAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private Activity mActivity;
    private ArrayList<ExerciseItem> mExerciseItems;
    private OnTrackerReadingSave onTrackerReadingSave;

    public SearchExerciseAdapter(ArrayList<ExerciseItem> mExerciseItems, Activity activity, OnTrackerReadingSave onTrackerReadingSave) {

        this.mExerciseItems=mExerciseItems;
        this.mActivity = activity;
        this.onTrackerReadingSave=onTrackerReadingSave;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View view=LayoutInflater.from(parent.getContext()).inflate(R.layout.row_searchexercise_item,parent,false);

        return  new ItemViewHolder(view);

    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        ItemViewHolder itemViewHolder = (ItemViewHolder) holder;

        itemViewHolder.tvSearchList.setText(mExerciseItems.get(position).getActivityName() );
       itemViewHolder.tvSearchList.setCompoundDrawablesWithIntrinsicBounds(0,0,R.drawable.ic_arrow_next,0);
    }


    @Override
    public int getItemCount() {
    return (null != mExerciseItems ? mExerciseItems.size() : 0);

    }



    // ItemViewHolder Class for Items in each Section
    public class ItemViewHolder extends RecyclerView.ViewHolder {

        final TextView tvSearchList;

        public ItemViewHolder(View itemView) {
            super(itemView);
            tvSearchList = itemView.findViewById(R.id.tvSearchList);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    Bundle bundle = new Bundle();

                    bundle.putInt("ID",0);////put 0 for the new activity id
                    bundle.putString("Name",mExerciseItems.get(getLayoutPosition()).getActivityName());
                    bundle.putInt("Duration",1);
                    bundle.putDouble("CaloriesBurnedIn1Min",mExerciseItems.get(getLayoutPosition()).getActivityCalorie());
                    bundle.putString("redirectFrom", TrackExerciseFragment.class.getSimpleName());
                    bundle.putString("Time", DateFactory.getInstance().getCurrentTime("hh:mm aa"));

                    TrackActivityFragment trackActivityFragment = TrackActivityFragment.newInstance(bundle);
                    trackActivityFragment.setTrackerReadingCallback(onTrackerReadingSave);

                    Utils.replaceFragment(mActivity.getFragmentManager(), trackActivityFragment, TrackActivityFragment.class.getSimpleName(), true, R.id.fragmentContainerMeal);



                }
            });


        }
    }


    }
