package com.twc.remindermodule.receiver;

import android.app.Activity;
import android.app.AlarmManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import com.twc.greendaolib.GreenDaoApp;
import com.twc.greendaolib.ReminderItem;
import com.twc.greendaolib.ReminderItemDao;
import com.twc.greendaolib.ReminderTimeItem;
import com.twc.greendaolib.ReminderTimeItemDao;
import com.twc.remindermodule.fragments.NotificationScheduler;
import com.twc.remindermodule.service.RemindersService;
import com.twc.remindermodule.utils.Utils;

import java.util.List;

/**
 * Created by ManishJ1 on 11/12/2016.
 */

public class OnBootAlarmReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        Utils.printLog("OnBootAlar status","OnBootAlarmReceiver change");
     
     
     
     //getRemindersFromDatabase(context);
        Intent intent1 = new Intent(context,RemindersService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(intent1);
        } else {
            context.startService(intent1);
        }

    }
    private void getRemindersFromDatabase(Context context) {
        AlarmManager alarmMgr = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        ReminderItemDao reminderItemDao = GreenDaoApp.getInstance(context).getDaoSession(context).getReminderItemDao();
        ReminderTimeItemDao reminderTimeItemDao = GreenDaoApp.getInstance(context).getDaoSession(context).getReminderTimeItemDao();
        List<ReminderItem> reminderItems = reminderItemDao.loadAll();
        for (int i = 0; i < reminderItems.size(); i++) {
            List<ReminderTimeItem> reminderTimeItems = reminderTimeItemDao.queryBuilder().where(ReminderTimeItemDao.Properties.ReminderId.eq(reminderItems.get(i).getId())).list();
            String title = reminderItems.get(i).getReminderText();
            for (int k = 0; k < reminderTimeItems.size(); k++) {
                if (reminderItems.get(i).getIsActive() && reminderTimeItems.get(k).getIsActive()) {
                    //String title = reminderTimeItems.get(k).getReminderType();
                    if (reminderTimeItems.get(k).getReminderTime() != null && !reminderTimeItems.get(k).getReminderTime().isEmpty()) {

                        NotificationScheduler.setNotificationAlarm((Activity) context,alarmMgr,(int) (long) reminderTimeItems.get(k).getId(), title, "", reminderTimeItems.get(k).getReminderTime());
                    }

                }
            }
        }

    }


}
