package com.truworth.discoverlib.model;

import java.util.List;

/**
 * Created by ManishJ1 on 8/12/2016.
 */
public class SearchDiscoverByKeywordResponse {
    private DiscoverInfoBean Info;
    private int status;
    private List<DiscoverSearchBean> Data;

    public DiscoverInfoBean getInfo() {
        return Info;
    }

    public void setInfo(DiscoverInfoBean Info) {
        this.Info = Info;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public List<DiscoverSearchBean> getData() {
        return Data;
    }

    public void setData(List<DiscoverSearchBean> Data) {
        this.Data = Data;
    }

    public static class DiscoverInfoBean {
        private int Article;
        private int Discussion;
        private int Challenges;
        private int Programs;
        private int Slides;
        private int Quizes;

        public int getArticle() {
            return Article;
        }

        public void setArticle(int Article) {
            this.Article = Article;
        }

        public int getDiscussion() {
            return Discussion;
        }

        public void setDiscussion(int Discussion) {
            this.Discussion = Discussion;
        }

        public int getChallenges() {
            return Challenges;
        }

        public void setChallenges(int Challenges) {
            this.Challenges = Challenges;
        }

        public int getPrograms() {
            return Programs;
        }

        public void setPrograms(int Programs) {
            this.Programs = Programs;
        }

        public int getSlides() {
            return Slides;
        }

        public void setSlides(int Slides) {
            this.Slides = Slides;
        }

        public int getQuizes() {
            return Quizes;
        }

        public void setQuizes(int Quizes) {
            this.Quizes = Quizes;
        }
    }

    public static class DiscoverSearchBean {
        private int ID;
        private String ImageName;
        private String NAME;
        private int NoOfRows;
        private int RowNumber;
        private String SHORT_DESC;
        private String Type;
        private String Category;
        private String URL;

        public int getID() {
            return ID;
        }

        public void setID(int ID) {
            this.ID = ID;
        }

        public String getImageName() {
            return ImageName;
        }

        public void setImageName(String ImageName) {
            this.ImageName = ImageName;
        }

        public String getNAME() {
            return NAME;
        }

        public void setNAME(String NAME) {
            this.NAME = NAME;
        }

        public int getNoOfRows() {
            return NoOfRows;
        }

        public void setNoOfRows(int NoOfRows) {
            this.NoOfRows = NoOfRows;
        }

        public int getRowNumber() {
            return RowNumber;
        }

        public void setRowNumber(int RowNumber) {
            this.RowNumber = RowNumber;
        }

        public String getSHORT_DESC() {
            return SHORT_DESC;
        }

        public void setSHORT_DESC(String SHORT_DESC) {
            this.SHORT_DESC = SHORT_DESC;
        }

        public String getType() {
            return Type;
        }

        public void setType(String Type) {
            this.Type = Type;
        }

        public String getCategory() {
            return Category;
        }

        public void setCategory(String Category) {
            this.Category = Category;
        }

        public String getURL() {
            return URL;
        }

        public void setURL(String URL) {
            this.URL = URL;
        }
    }
}
