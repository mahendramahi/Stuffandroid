package com.twc.dailylog.interfaces;

/**
 * If this code works it was written by Somesh Kumar on 11 May, 2016. If not, I don't know who wrote
 * it.
 */
public interface ISearchResultCallback {
    void onTextSubmitSuccess(String searchContent, String lastKeyword);
    void onTextChangedSuccess(String searchContent);
}
