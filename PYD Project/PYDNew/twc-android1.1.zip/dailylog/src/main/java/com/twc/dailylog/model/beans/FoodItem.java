package com.twc.dailylog.model.beans;

import com.google.gson.annotations.SerializedName;

/**
 * Created by ManishJ1 on 7/5/2016.
 */
public class FoodItem {

    /**
     * FoodID : 147
     * FoodName : Fresh Lime Water, without Sugar
     * Quantity : 1
     * StandardServing : Glass
     * Calories : 1.2
     * MealType : Bed Tea
     * Days : MON
     * MealTime : 07:00
     * DietPlanQty : 1
     */
    @SerializedName(value="FoodID", alternate={"FoodId"})
    private int FoodID;
    private String FoodName;
    private String Quantity;
    private String StandardServing;
    private double Calories;
    private String MealType;
    private String Days;
    private String MealTime;
    private double DietPlanQty;
    private double CaloriesPerItem;

    /* server id of the food for the user*/
    private int nutritionId;

    public int getFoodID() {
        return FoodID;
    }

    public void setFoodID(int FoodID) {
        this.FoodID = FoodID;
    }

    public String getFoodName() {
        return FoodName;
    }

    public void setFoodName(String FoodName) {
        this.FoodName = FoodName;
    }

    public String getQuantity() {
        return Quantity;
    }

    public void setQuantity(String Quantity) {
        this.Quantity = Quantity;
    }

    public String getStandardServing() {
        return StandardServing;
    }

    public void setStandardServing(String StandardServing) {
        this.StandardServing = StandardServing;
    }

    public double getCalories() {
        return Calories;
    }

    public void setCalories(double Calories) {
        this.Calories = Calories;
    }

    public String getMealType() {
        return MealType;
    }

    public void setMealType(String MealType) {
        this.MealType = MealType;
    }

    public String getDays() {
        return Days;
    }

    public void setDays(String Days) {
        this.Days = Days;
    }

    public String getMealTime() {
        return MealTime;
    }

    public void setMealTime(String MealTime) {
        this.MealTime = MealTime;
    }

    public double getDietPlanQty() {
        return DietPlanQty;
    }

    public void setDietPlanQty(double DietPlanQty) {
        this.DietPlanQty = DietPlanQty;
    }

    public int getNutritionId() {
        return nutritionId;
    }

    public void setNutritionId(int nutritionId) {
        this.nutritionId = nutritionId;
    }

    public double getCaloriesPerItem() {
        return CaloriesPerItem;
    }

    public void setCaloriesPerItem(double caloriesPerItem) {
        CaloriesPerItem = caloriesPerItem;
    }
}
