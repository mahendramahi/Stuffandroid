package com.truworth.wellnesscorner.repo.model.request;

public class ShareDashboardRequest {


    private String deviceDate;

    public String getDeviceDate() {
        return deviceDate;
    }

    public void setDeviceDate(String deviceDate) {
        this.deviceDate = deviceDate;
    }
}
