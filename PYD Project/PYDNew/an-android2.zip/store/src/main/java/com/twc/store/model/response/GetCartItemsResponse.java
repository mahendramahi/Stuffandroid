package com.twc.store.model.response;


import com.twc.store.model.beans.DataStoreCartItem;

/**
 * Created by PalakC on 9/13/2017.
 */

public class GetCartItemsResponse {


    private int status;
    private DataStoreCartItem Data;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public DataStoreCartItem getData() {
        return Data;
    }

    public void setData(DataStoreCartItem Data) {
        this.Data = Data;
    }


}
