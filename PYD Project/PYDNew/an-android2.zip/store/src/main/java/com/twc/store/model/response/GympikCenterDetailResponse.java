package com.twc.store.model.response;

import java.util.List;

/**
 * Created by GurvinderS on 11/29/2017.
 */

public class GympikCenterDetailResponse {


    /**
     * status : 0
     * data : {"result":{"latitude":"13.1155273","longitude":"77.5654035","center_slug":"power-world-gyms-kattigenahalli","landmark":"","center_name":"Power World Gyms","fitnesscenter_type":"Gyms","center_address":"2nd Floor \u2018Chinna's Complex\u2019 Bagalur Main Road Reva University Circle Kattigenahalli Yelanhaka\r\nBangalore","city_name":"Bangalore"},"fee":[{"offering_name":"all","offering_type":"Yearly","amount":"5000"}],"time":[{"days":"week_days_morning","start_time":"05:00","finish_time":"13:00"},{"days":"week_days_evening","start_time":"13:00","finish_time":"22:00"},{"days":"week_ends_morning","start_time":"05:00","finish_time":"13:00"},{"days":"week_ends_evening","start_time":"13:00","finish_time":"22:00"}],"facilities":["Resistance Machines","Changing Room","Parking"],"offerings":[{"offering_name":"Certified Trainers","healthBenefits":"[\"Certified and Trained Experts.\",\"Research based techniques and guidance.\"]","averageCalorieBurn":"NA","results":"8-12 weeks","goodReads":"[\"NA\"]","exerpt":"Certified Trainers are nationally or internationally trained experts who guide people through research-based techniques to help attain fitness goals."},{"offering_name":"Circuit Training","healthBenefits":"[\"High Intensity Carido workout.\",\"Improves cardiovascular health.\",\"Heps in strengthening, conditioning and boosting stamina.\",\"Tones, conditions and defines muscles.\",\"Enhances endurance.\"]","averageCalorieBurn":"540 Calories/hour","results":"8-12 weeks","goodReads":"[\"\\\"Circuit Training for bodybuilding (https:\\/\\/www.gympik.com\\/articles\\/circuit-training-for-bodybuilding\\/)\\\"\",\"This is How your Endurance Workout Plan should look like (https:\\/\\/www.gympik.com\\/articles\\/endurance-workout-plan\\/)\\\"\"]","exerpt":"Circuit training is defined as a type of exercise focusing in body strengthening, conditioning and stamina boosting using high-intensity aerobics."},{"offering_name":"Weight Gain","healthBenefits":"[\"Increase in body weight.\",\"Could indicate high muscle mass.\",\"Increse in body fats and or fluids.\"]","averageCalorieBurn":"NA","results":"NA","goodReads":"[\"\\\"Workout Regimen and Diet guide for Weight Gain.\\\"\",\"The right way to gain weight.\\\"\"]","exerpt":"Weight gain is a condition when there is an increase in body weight. This can be due to high muscle mass, increse in fats and body fluids."},{"offering_name":"Weight Loss","healthBenefits":"[\"Weight loss is when body loses weight. This can involve factors like certain medicinal intake, poor health condition, lack of physical fitness etc.\"]","averageCalorieBurn":"","results":"","goodReads":"","exerpt":"Weight loss is when body loses weight. This can involve factors like certain medicinal intake, poor health condition, lack of physical fitness etc."},{"offering_name":"Body Building","healthBenefits":"[\"A physical fitness regimen to build muscles.\",\"Better muscular strength and endurance.\",\"Increases fat and calorie burn.\",\"Long lasting results.\"]","averageCalorieBurn":"300-500 Calories/hour","results":"8-12 weeks","goodReads":"[\"\\\"5 reasons muscle building is for everybody (https:\\/\\/www.gympik.com\\/articles\\/5-reasons-muscle-building-everybody\\/)\\\"\",\"5 Best Foods For Muscle Building (https:\\/\\/www.gympik.com\\/articles\\/5-best-foods-muscle-building\\/)\\\"\",\"5 crucial steps to muscle building (https:\\/\\/www.gympik.com\\/articles\\/5-crucial-steps-muscle-building\\/)\\\"\"]","exerpt":"Bodybuilding is a physical fitness regime involving different exercises for increasing body mass, and thus, developing one's muscular structure."},{"offering_name":"Strengthening","healthBenefits":"[\"Strengthening your core, abs and back.\",\"Improves flexibility.\",\"Increases muscle mass.\",\"Builds resistance.\",\"Boosts metabolism.\"]","averageCalorieBurn":"600-700 Calories/hour","results":"8-12 weeks","goodReads":"","exerpt":"Strengthening is derived by performing different physical activities or indulging in sports that yield muscle strength, resistance and flexibility."},{"offering_name":"Stretching","healthBenefits":"[\"Stretches and soothes muscles.\",\"Relieves muscle cramps.\",\"Increases strength.\",\"Builds flexibility.\"]","averageCalorieBurn":"50-100 Calories/hour","results":"2-3 weeks","goodReads":"[\"\\\"5 Common Stretching Mistakes You Must Avoid (https:\\/\\/www.gympik.com\\/articles\\/5-common-stretching-mistakes-you-must-avoid\\/)\\\"\"]","exerpt":"Stretching is a type of physical activity which requires flexing specific muscles to increase strength, flexibility, and relieve muscle cramps."},{"offering_name":"Gym","healthBenefits":"[\"A place with variety of equipments to work your entire body.\",\"From cardio to weights and other complex machines.\",\"Certified trainers to guide with the workouts.\",\"Dieticians and nutritionists to help with diets.\",\"Meant for weight loss, weight gain, muscle building, cardio vascular functioning etc.\"]","averageCalorieBurn":"500-700 Calories/hour","results":"8-12 weeks","goodReads":"[\"5 Things You Should Look For When Choosing A Gym (https://www.gympik.com/articles/5-things-look-choosing-gym/)\",\"3 Things Every Woman Looks For In A Gym (https://www.gympik.com/articles/3-things-every-woman-looks-gym/)\"]","exerpt":"A gym is a place that is aptly equipped for performing different fitness activities including strength building, muscle toning, firming and more."}]}
     */

    private int status;
    private DataBean data;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public static class DataBean {
        /**
         * result : {"latitude":"13.1155273","longitude":"77.5654035","center_slug":"power-world-gyms-kattigenahalli","landmark":"","center_name":"Power World Gyms","fitnesscenter_type":"Gyms","center_address":"2nd Floor \u2018Chinna's Complex\u2019 Bagalur Main Road Reva University Circle Kattigenahalli Yelanhaka\r\nBangalore","city_name":"Bangalore"}
         * fee : [{"offering_name":"all","offering_type":"Yearly","amount":"5000"}]
         * time : [{"days":"week_days_morning","start_time":"05:00","finish_time":"13:00"},{"days":"week_days_evening","start_time":"13:00","finish_time":"22:00"},{"days":"week_ends_morning","start_time":"05:00","finish_time":"13:00"},{"days":"week_ends_evening","start_time":"13:00","finish_time":"22:00"}]
         * facilities : ["Resistance Machines","Changing Room","Parking"]
         * offerings : [{"offering_name":"Certified Trainers","healthBenefits":"[\"Certified and Trained Experts.\",\"Research based techniques and guidance.\"]","averageCalorieBurn":"NA","results":"8-12 weeks","goodReads":"[\"NA\"]","exerpt":"Certified Trainers are nationally or internationally trained experts who guide people through research-based techniques to help attain fitness goals."},{"offering_name":"Circuit Training","healthBenefits":"[\"High Intensity Carido workout.\",\"Improves cardiovascular health.\",\"Heps in strengthening, conditioning and boosting stamina.\",\"Tones, conditions and defines muscles.\",\"Enhances endurance.\"]","averageCalorieBurn":"540 Calories/hour","results":"8-12 weeks","goodReads":"[\"\\\"Circuit Training for bodybuilding (https:\\/\\/www.gympik.com\\/articles\\/circuit-training-for-bodybuilding\\/)\\\"\",\"This is How your Endurance Workout Plan should look like (https:\\/\\/www.gympik.com\\/articles\\/endurance-workout-plan\\/)\\\"\"]","exerpt":"Circuit training is defined as a type of exercise focusing in body strengthening, conditioning and stamina boosting using high-intensity aerobics."},{"offering_name":"Weight Gain","healthBenefits":"[\"Increase in body weight.\",\"Could indicate high muscle mass.\",\"Increse in body fats and or fluids.\"]","averageCalorieBurn":"NA","results":"NA","goodReads":"[\"\\\"Workout Regimen and Diet guide for Weight Gain.\\\"\",\"The right way to gain weight.\\\"\"]","exerpt":"Weight gain is a condition when there is an increase in body weight. This can be due to high muscle mass, increse in fats and body fluids."},{"offering_name":"Weight Loss","healthBenefits":"[\"Weight loss is when body loses weight. This can involve factors like certain medicinal intake, poor health condition, lack of physical fitness etc.\"]","averageCalorieBurn":"","results":"","goodReads":"","exerpt":"Weight loss is when body loses weight. This can involve factors like certain medicinal intake, poor health condition, lack of physical fitness etc."},{"offering_name":"Body Building","healthBenefits":"[\"A physical fitness regimen to build muscles.\",\"Better muscular strength and endurance.\",\"Increases fat and calorie burn.\",\"Long lasting results.\"]","averageCalorieBurn":"300-500 Calories/hour","results":"8-12 weeks","goodReads":"[\"\\\"5 reasons muscle building is for everybody (https:\\/\\/www.gympik.com\\/articles\\/5-reasons-muscle-building-everybody\\/)\\\"\",\"5 Best Foods For Muscle Building (https:\\/\\/www.gympik.com\\/articles\\/5-best-foods-muscle-building\\/)\\\"\",\"5 crucial steps to muscle building (https:\\/\\/www.gympik.com\\/articles\\/5-crucial-steps-muscle-building\\/)\\\"\"]","exerpt":"Bodybuilding is a physical fitness regime involving different exercises for increasing body mass, and thus, developing one's muscular structure."},{"offering_name":"Strengthening","healthBenefits":"[\"Strengthening your core, abs and back.\",\"Improves flexibility.\",\"Increases muscle mass.\",\"Builds resistance.\",\"Boosts metabolism.\"]","averageCalorieBurn":"600-700 Calories/hour","results":"8-12 weeks","goodReads":"","exerpt":"Strengthening is derived by performing different physical activities or indulging in sports that yield muscle strength, resistance and flexibility."},{"offering_name":"Stretching","healthBenefits":"[\"Stretches and soothes muscles.\",\"Relieves muscle cramps.\",\"Increases strength.\",\"Builds flexibility.\"]","averageCalorieBurn":"50-100 Calories/hour","results":"2-3 weeks","goodReads":"[\"\\\"5 Common Stretching Mistakes You Must Avoid (https:\\/\\/www.gympik.com\\/articles\\/5-common-stretching-mistakes-you-must-avoid\\/)\\\"\"]","exerpt":"Stretching is a type of physical activity which requires flexing specific muscles to increase strength, flexibility, and relieve muscle cramps."},{"offering_name":"Gym","healthBenefits":"[\"A place with variety of equipments to work your entire body.\",\"From cardio to weights and other complex machines.\",\"Certified trainers to guide with the workouts.\",\"Dieticians and nutritionists to help with diets.\",\"Meant for weight loss, weight gain, muscle building, cardio vascular functioning etc.\"]","averageCalorieBurn":"500-700 Calories/hour","results":"8-12 weeks","goodReads":"[\"5 Things You Should Look For When Choosing A Gym (https://www.gympik.com/articles/5-things-look-choosing-gym/)\",\"3 Things Every Woman Looks For In A Gym (https://www.gympik.com/articles/3-things-every-woman-looks-gym/)\"]","exerpt":"A gym is a place that is aptly equipped for performing different fitness activities including strength building, muscle toning, firming and more."}]
         */

        private ResultBean result;
        private List<PassesBean> passes;
        private List<TimeBean> time;
        private List<FacilityBean> facilitiesList;
        private List<OfferingsBean> offerings;
        private List<ReviewBean> review;

        public ResultBean getResult() {
            return result;
        }

        public void setResult(ResultBean result) {
            this.result = result;
        }

        public List<PassesBean> getPasses() {
            return passes;
        }

        public void setPasses(List<PassesBean> fee) {
            this.passes = fee;
        }

        public List<TimeBean> getTime() {
            return time;
        }

        public void setTime(List<TimeBean> time) {
            this.time = time;
        }

        public List<FacilityBean> getFacilities() {
            return facilitiesList;
        }

        public void setFacilities(List<FacilityBean> facilities) {
            this.facilitiesList = facilities;
        }

        public List<OfferingsBean> getOfferings() {
            return offerings;
        }

        public void setOfferings(List<OfferingsBean> offerings) {
            this.offerings = offerings;
        }

        public List<ReviewBean> getReviews() {
            return review;
        }

        public void setReviews(List<ReviewBean> reviews) {
            this.review = reviews;
        }


        public static class FacilityBean {
            private String facility;

            public String getFacility() {
                return facility;
            }

            public void setFacility(String facility) {
                this.facility = facility;
            }

            public String getFacilityImage() {
                return facilityImage;
            }

            public void setFacilityImage(String facilityImage) {
                this.facilityImage = facilityImage;
            }

            private String facilityImage;
        }

        public static class ResultBean {

            private String latitude;
            private String longitude;
            private String center_slug;
            private String landmark;
            private String center_name;
            private String fitnesscenter_type;
            private String center_address;
            private String city_name;
            private String isFreeTrial;
            private String extension;
            private String contact;

            public int getVendorId() {
                return VendorId;
            }

            public void setVendorId(int vendorId) {
                VendorId = vendorId;
            }

            private int VendorId;

            public String getLatitude() {
                return latitude;
            }

            public void setLatitude(String latitude) {
                this.latitude = latitude;
            }

            public String getLongitude() {
                return longitude;
            }

            public void setLongitude(String longitude) {
                this.longitude = longitude;
            }

            public String getCenter_slug() {
                return center_slug;
            }

            public void setCenter_slug(String center_slug) {
                this.center_slug = center_slug;
            }

            public String getLandmark() {
                return landmark;
            }

            public void setLandmark(String landmark) {
                this.landmark = landmark;
            }

            public String getCenter_name() {
                return center_name;
            }

            public void setCenter_name(String center_name) {
                this.center_name = center_name;
            }

            public String getFitnesscenter_type() {
                return fitnesscenter_type;
            }

            public void setFitnesscenter_type(String fitnesscenter_type) {
                this.fitnesscenter_type = fitnesscenter_type;
            }

            public String getCenter_address() {
                return center_address;
            }

            public void setCenter_address(String center_address) {
                this.center_address = center_address;
            }

            public String getCity_name() {
                return city_name;
            }

            public void setCity_name(String city_name) {
                this.city_name = city_name;
            }

            public String getIsFreeTrial() {
                return isFreeTrial;
            }

            public void setIsFreeTrial(String isFreeTrial) {
                this.isFreeTrial = isFreeTrial;
            }

            public String getExtension() {
                return extension;
            }

            public void setExtension(String extension) {
                this.extension = extension;
            }

            public String getContact() {
                return contact;
            }

            public void setContact(String contact) {
                this.contact = contact;
            }
        }

        public static class PassesBean {
            public boolean isSelected() {
                return isSelected;
            }

            public void setSelected(boolean selected) {
                isSelected = selected;
            }

            /**
             * offering_name : all
             * offering_type : Yearly
             * amount : 5000
             */
            public boolean isSelected;
            public String productName;
            public String productDescription;

            public String getProductName() {
                return productName;
            }

            public void setProductName(String productName) {
                this.productName = productName;
            }

            public String getProductDescription() {
                return productDescription;
            }

            public void setProductDescription(String productDescription) {
                this.productDescription = productDescription;
            }

            public double getProductFinalPrice() {
                return productFinalPrice;
            }

            public void setProductFinalPrice(double productFinalPrice) {
                this.productFinalPrice = productFinalPrice;
            }

            public int getProductSessions() {
                return productSessions;
            }

            public void setProductSessions(int productSessions) {
                this.productSessions = productSessions;
            }

            public double getProductPrice() {
                return productPrice;
            }

            public void setProductPrice(double productPrice) {
                this.productPrice = productPrice;
            }

            public double getProductDiscountAmount() {
                return productDiscountAmount;
            }

            public void setProductDiscountAmount(double productDiscountAmount) {
                this.productDiscountAmount = productDiscountAmount;
            }

            public double getProductRegistrationPrice() {
                return productRegistrationPrice;
            }

            public void setProductRegistrationPrice(double productRegistrationPrice) {
                this.productRegistrationPrice = productRegistrationPrice;
            }

            public String getDays() {
                return days;
            }

            public void setDays(String days) {
                this.days = days;
            }

            public String getStartTime() {
                return startTime;
            }

            public void setStartTime(String startTime) {
                this.startTime = startTime;
            }

            public String getEndTime() {
                return endTime;
            }

            public void setEndTime(String endTime) {
                this.endTime = endTime;
            }

            public String getTypeName() {
                return typeName;
            }

            public void setTypeName(String typeName) {
                this.typeName = typeName;
            }

            public int getIsEnabled() {
                return isEnabled;
            }

            public void setIsEnabled(int isEnabled) {
                this.isEnabled = isEnabled;
            }

            public String getProductCode() {
                return productCode;
            }

            public void setProductCode(String productCode) {
                this.productCode = productCode;
            }

            public double productFinalPrice;
            public int productSessions;
            public double productPrice;

            private String productCode;
            public double productDiscountAmount;
            public double productRegistrationPrice;
            public String days;
            public String startTime;
            public String endTime;
            public String typeName;
            public int isEnabled;


        }

        public static class TimeBean {
            /**
             * days : week_days_morning
             * start_time : 05:00
             * finish_time : 13:00
             */

            private String days;
            private String start_time;
            private String finish_time;

            public String getDays() {
                return days;
            }

            public void setDays(String days) {
                this.days = days;
            }

            public String getStart_time() {
                return start_time;
            }

            public void setStart_time(String start_time) {
                this.start_time = start_time;
            }

            public String getFinish_time() {
                return finish_time;
            }

            public void setFinish_time(String finish_time) {
                this.finish_time = finish_time;
            }
        }

        public static class OfferingsBean {
            /**
             * offering_name : Certified Trainers
             * healthBenefits : ["Certified and Trained Experts.","Research based techniques and guidance."]
             * averageCalorieBurn : NA
             * results : 8-12 weeks
             * goodReads : ["NA"]
             * exerpt : Certified Trainers are nationally or internationally trained experts who guide people through research-based techniques to help attain fitness goals.
             */

            private String offering_name;
            private String healthBenefits;
            private String averageCalorieBurn;
            private String results;
            private String goodReads;
            private String exerpt;

            public String getOffering_name() {
                return offering_name;
            }

            public void setOffering_name(String offering_name) {
                this.offering_name = offering_name;
            }

            public String getHealthBenefits() {
                return healthBenefits;
            }

            public void setHealthBenefits(String healthBenefits) {
                this.healthBenefits = healthBenefits;
            }

            public String getAverageCalorieBurn() {
                return averageCalorieBurn;
            }

            public void setAverageCalorieBurn(String averageCalorieBurn) {
                this.averageCalorieBurn = averageCalorieBurn;
            }

            public String getResults() {
                return results;
            }

            public void setResults(String results) {
                this.results = results;
            }

            public String getGoodReads() {
                return goodReads;
            }

            public void setGoodReads(String goodReads) {
                this.goodReads = goodReads;
            }

            public String getExerpt() {
                return exerpt;
            }

            public void setExerpt(String exerpt) {
                this.exerpt = exerpt;
            }
        }


        public static class ReviewBean {
            private String added_on;
            private String lastName;
            private String firstName;
            private String reviewStatus;
            private String userId;
            private String rating;
            private String comment;

            public String getAdded_on() {
                return added_on;
            }

            public void setAdded_on(String added_on) {
                this.added_on = added_on;
            }

            public String getLastName() {
                return lastName;
            }

            public void setLastName(String lastName) {
                this.lastName = lastName;
            }

            public String getFirstName() {
                return firstName;
            }

            public void setFirstName(String firstName) {
                this.firstName = firstName;
            }

            public String getReviewStatus() {
                return reviewStatus;
            }

            public void setReviewStatus(String reviewStatus) {
                this.reviewStatus = reviewStatus;
            }

            public String getUserId() {
                return userId;
            }

            public void setUserId(String userId) {
                this.userId = userId;
            }

            public String getRating() {
                return rating;
            }

            public void setRating(String rating) {
                this.rating = rating;
            }

            public String getComment() {
                return comment;
            }

            public void setComment(String comment) {
                this.comment = comment;
            }
        }
    }

}
