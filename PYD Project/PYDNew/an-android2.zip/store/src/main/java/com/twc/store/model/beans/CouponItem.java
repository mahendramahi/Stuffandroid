package com.twc.store.model.beans;

import java.util.List;

/**
 * If this code works it was written by Somesh Kumar on 15 September, 2017. If not, I don't know who wrote it.
 */
public class CouponItem {

    private int couponStatus;
    private String message;
    private int couponID;
    private double couponDiscount;
    private List<ClashCouponItem> clashCoupon;


    public int getCouponStatus() {
        return couponStatus;
    }

    public void setCouponStatus(int couponStatus) {
        this.couponStatus = couponStatus;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public int getCouponID() {
        return couponID;
    }

    public void setCouponID(int couponID) {
        this.couponID = couponID;
    }

    public double getCouponDiscount() {
        return couponDiscount;
    }

    public void setCouponDiscount(double couponDiscount) {
        this.couponDiscount = couponDiscount;
    }

    public List<ClashCouponItem> getClashCoupon() {
        return clashCoupon;
    }

    public void setClashCoupon(List<ClashCouponItem> clashCoupon) {
        this.clashCoupon = clashCoupon;
    }

    public static class ClashCouponItem {
        private int CouponID;
        private String Code;

        public int getCouponID() {
            return CouponID;
        }

        public void setCouponID(int CouponID) {
            this.CouponID = CouponID;
        }

        public String getCode() {
            return Code;
        }

        public void setCode(String Code) {
            this.Code = Code;
        }
    }

}
