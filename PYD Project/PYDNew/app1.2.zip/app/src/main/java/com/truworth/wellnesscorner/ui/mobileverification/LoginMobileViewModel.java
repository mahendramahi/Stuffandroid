package com.truworth.wellnesscorner.ui.mobileverification;

import android.databinding.BindingAdapter;
import android.databinding.ObservableArrayList;
import android.databinding.ObservableBoolean;
import android.databinding.ObservableField;
import android.databinding.ObservableInt;
import android.databinding.ObservableList;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.widget.ImageView;

import com.google.i18n.phonenumbers.PhoneNumberUtil;
import com.google.i18n.phonenumbers.Phonenumber.PhoneNumber;
import com.truworth.wellnesscorner.R;
import com.truworth.wellnesscorner.TheWellnessCornerApp;
import com.truworth.wellnesscorner.base.BaseViewModel;
import com.truworth.wellnesscorner.model.CountryData;
import com.truworth.wellnesscorner.model.OTPData;
import com.truworth.wellnesscorner.repo.LoginRepository;
import com.truworth.wellnesscorner.repo.model.request.OTPRequest;
import com.truworth.wellnesscorner.repo.model.response.OTPResponse;
import com.truworth.wellnesscorner.repo.model.response.RegisterOtpResponse;
import com.truworth.wellnesscorner.utils.RSAHelper;
import com.truworth.wellnesscorner.utils.SingleLiveEvent;

import javax.inject.Inject;

import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;


/**
 * Created by rajeshs on 3/28/2018.
 */

public class LoginMobileViewModel extends BaseViewModel {
    @Inject
    LoginRepository repository;
    public ObservableInt resetIcon = new ObservableInt();
    public ObservableBoolean isMobileNumberFilled = new ObservableBoolean();
    public ObservableBoolean enableContinue = new ObservableBoolean();
    private final SingleLiveEvent<Void> clearData = new SingleLiveEvent<>();
    private final SingleLiveEvent<Void> isSentOtp = new SingleLiveEvent<>();

    private String mEmail;

    public int getRedirectFrom() {
        return redirectFrom;
    }

    public void setRedirectFrom(int redirectFrom) {
        this.redirectFrom = redirectFrom;
    }

    private int redirectFrom;
    public OTPData otpData;


    public ObservableList<CountryData> getCountryCodes() {
        return countryCodes;
    }

    public ObservableField<String> selectedCountryCode = new ObservableField<>();
    public final ObservableList<CountryData> countryCodes = new ObservableArrayList<>();


    public ObservableField<String> mobileNumber = new ObservableField<>();

    public ObservableField<String> getMobileNumberSubTitle() {
        return mobileNumberSubTitle;
    }

    public void setMobileNumberSubTitle(ObservableField<String> mobileNumberSubTitle) {
        this.mobileNumberSubTitle = mobileNumberSubTitle;
    }

    public ObservableField<String> mobileNumberSubTitle = new ObservableField<>();

    public ObservableField<String> errorMessage = new ObservableField<>();

    private final SingleLiveEvent<Void> isNavigateCountrySearch = new SingleLiveEvent<>();

    public SingleLiveEvent<Void> getIsNavigateCountrySearch() {
        return isNavigateCountrySearch;
    }

    public void navigateToSearchCountry() {
        isNavigateCountrySearch.call();
    }

    public LoginMobileViewModel() {
        TheWellnessCornerApp.getApp().component().inject(this);
        this.isMobileNumberFilled.set(false);
    }

    public SingleLiveEvent<Void> getIsSentOtp() {
        return isSentOtp;
    }

    public void setEmail(String email) {
        this.mEmail = email;
    }

    public void registerMobileNumber() {

    }




    public OTPData getOtpData() {
        return otpData;
    }


    public void sendOTP() {
        if (redirectFrom == MobileNumberRedirectionType.FROM_REGISTRATION) {
            sendOtpForRegistration();
        } else {
            sendOtpForLogin();
        }

    }

    public void sendOtpForLogin() {
        if (isNumberMobileNumber()) {
            resetIcon.set(R.drawable.reset_input_box_icon);
            setIsLoading(true);
            OTPRequest request = new OTPRequest();
            request.setEmail(RSAHelper.Encrypt(mEmail));
            request.setPhone(mobileNumber.get());
            repository.sendOTP(request).subscribe(new Observer<OTPResponse>() {

                @Override
                public void onSubscribe(Disposable d) {

                }

                @Override
                public void onNext(OTPResponse otpResponse) {
                    if (!otpResponse.isHasError()) {
                        otpData = otpResponse.getData();
                        isSentOtp.call();
                        resetIcon.set(R.drawable.ic_check);
                    } else {
                        errorMessage.set(otpResponse.getError().getMessage());
                        resetIcon.set(R.drawable.ic_red_cross);
                    }
                    setIsLoading(false);
                }

                @Override
                public void onError(Throwable e) {
                    setIsLoading(false);
                }

                @Override
                public void onComplete() {
                    setIsLoading(false);
                }
            });

        } else {
            Log.d("Phone number ", "invalid phone number");
            errorMessage.set("invalid phone number");
            resetIcon.set(R.drawable.ic_red_cross);
        }
    }

    public void sendOtpForRegistration() {
        if (isNumberMobileNumber()) {
            setIsLoading(true);
            OTPRequest request = new OTPRequest();
            request.setEmail(RSAHelper.Encrypt(mEmail));
            request.setPhone(mobileNumber.get());
            repository.sendOTPForRegistration(request).subscribe(new Observer<RegisterOtpResponse>() {

                @Override
                public void onSubscribe(Disposable d) {

                }


                @Override
                public void onNext(RegisterOtpResponse otpResponse) {
                    if (!otpResponse.isHasError()) {
                        otpData = otpResponse.getData();
                        isSentOtp.call();
                        resetIcon.set(R.drawable.ic_check);
                    } else {
                        errorMessage.set(otpResponse.getError().getMessage());
                        resetIcon.set(R.drawable.ic_red_cross);

                    }
                    setIsLoading(false);
                }


                @Override
                public void onError(Throwable e) {
                    setIsLoading(false);
                }


                @Override
                public void onComplete() {
                    setIsLoading(false);
                }
            });

        } else {
            Log.d("Phone number ", "invalid phone number");
            resetIcon.set(R.drawable.ic_red_cross);
            errorMessage.set("invalid phone number");
        }
    }


    public TextWatcher countryWatcher() {
        return new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                if(isMobileNumberFilled.get()){
                    if(isNumberMobileNumber()) {
                        resetIcon.set(R.drawable.reset_input_box_icon);
                        errorMessage.set("");
                        enableContinue.set(true);
                    }
                    else {
                        resetIcon.set(R.drawable.ic_red_cross);
                        errorMessage.set("invalid phone number");
                        enableContinue.set(false);
                    }
                }
            }
        };
    }

    public TextWatcher MobileNumberWatcher() {
        return new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                mobileNumber.set(charSequence.toString());
                errorMessage.set("");
                if (mobileNumber.get().isEmpty()) {
                    isMobileNumberFilled.set(false);
                    enableContinue.set(false);
                } else {
                    isMobileNumberFilled.set(true);
                    resetIcon.set(R.drawable.reset_input_box_icon);
                    enableContinue.set(true);
                    /*if(isNumberMobileNumber()) {
                        resetIcon.set(R.drawable.reset_input_box_icon);
                        errorMessage.set("");
                        enableContinue.set(true);
                    }
                    else {
                        resetIcon.set(R.drawable.ic_red_cross);
                        errorMessage.set("invalid phone number");
                        enableContinue.set(false);
                    }*/
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        };
    }

    public boolean isNumberMobileNumber() {
        boolean isMobile = false;
        if (mobileNumber.get() != null && selectedCountryCode.get() != null) {
            PhoneNumberUtil phoneNumberUtils = PhoneNumberUtil.getInstance();
            try {
                PhoneNumberUtil.PhoneNumberType pnt =  phoneNumberUtils.getNumberType(new PhoneNumber().setNationalNumber(Long.parseLong(mobileNumber.get())).setCountryCode(Integer.parseInt(selectedCountryCode.get())));
                if(pnt.equals(PhoneNumberUtil.PhoneNumberType.FIXED_LINE_OR_MOBILE) || pnt.equals(PhoneNumberUtil.PhoneNumberType.MOBILE))
                {
                    isMobile = true;
                }
                else{
                    isMobile = false;
                }

            }catch (NumberFormatException e){}
        }
        return isMobile;
    }

    public SingleLiveEvent<Void> getClearData() {
        return clearData;
    }

    public void onCrossIconClick() {
        if (isMobileNumberFilled.get()) {
            errorMessage.set("");
            if( resetIcon.get()!=R.drawable.ic_check)
                clearData.call();
        }
    }
    @BindingAdapter("imageResource")
    public static void setImageResource(ImageView imageView, int resource){
        imageView.setImageResource(resource);
    }

    public void setPhoneCode(String phoneCode) {
        this.selectedCountryCode.set(phoneCode);
    }
}
