package com.twc.store.model.beans;

import java.util.List;


/**
 * Created by PalakC on 10/9/2017.
 */
public class StoreDataBeanItem {

    private int VendorId;
    private int CategoryId;
    private String CategoryName;
    private List<ProductItem> Product;


    public int getVendorId() {
        return VendorId;
    }

    public void setVendorId(int vendorId) {
        VendorId = vendorId;
    }

    public int getCategoryId() {
        return CategoryId;
    }

    public void setCategoryId(int CategoryId) {
        this.CategoryId = CategoryId;
    }

    public String getCategoryName() {
        return CategoryName;
    }

    public void setCategoryName(String CategoryName) {
        this.CategoryName = CategoryName;
    }

    public List<ProductItem> getProduct() {
        return Product;
    }

    public void setProduct(List<ProductItem> Product) {
        this.Product = Product;
    }


}

