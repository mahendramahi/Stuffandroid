package com.twc.dailylog.model.beans;

public class StepsTrackerBean {


    private int value;
    private String LastStepSyncDate;
    private String LastConnectedDevice;
    private String LastStepUpdatedDate;

    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    }

    public String getLastStepSyncDate() {
        return LastStepSyncDate;
    }

    public void setLastStepSyncDate(String LastStepSyncDate) {
        this.LastStepSyncDate = LastStepSyncDate;
    }

    public String getLastConnectedDevice() {
        return LastConnectedDevice;
    }

    public void setLastConnectedDevice(String LastConnectedDevice) {
        this.LastConnectedDevice = LastConnectedDevice;
    }

    public String getLastStepUpdatedDate() {
        return LastStepUpdatedDate;
    }

    public void setLastStepUpdatedDate(String LastStepUpdatedDate) {
        this.LastStepUpdatedDate = LastStepUpdatedDate;
    }
}
