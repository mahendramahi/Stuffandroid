package com.truworth.wellnesscorner.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * Created by rajeshs on 4/13/2018.
 */

public class PopularCircle {

    @SerializedName("circleIdentity")
    @Expose
    private String circleIdentity;
    @SerializedName("circle_Name")
    @Expose
    private String circleName;
    @SerializedName("circle_Rating")
    @Expose
    private float circleRating;
    @SerializedName("circle_ImageName")
    @Expose
    private String circleImageName;
    @SerializedName("totalMembers")
    @Expose
    private int totalMembers;
    @SerializedName("circleCategory")
    @Expose
    private String circleCategory;
    private CircleAccess circleAccess;

    public String getCircleIdentity() {
        return circleIdentity;
    }

    public void setCircleIdentity(String circleIdentity) {
        this.circleIdentity = circleIdentity;
    }

    public String getCircleName() {
        return circleName;
    }

    public void setCircleName(String circleName) {
        this.circleName = circleName;
    }

    public float getCircleRating() {
        return circleRating;
    }

    public void setCircleRating(float circleRating) {
        this.circleRating = circleRating;
    }

    public String getCircleImageName() {
        return circleImageName;
    }

    public void setCircleImageName(String circleImageName) {
        this.circleImageName = circleImageName;
    }

    public int getTotalMembers() {
        return totalMembers;
    }

    public void setTotalMembers(int totalMembers) {
        this.totalMembers = totalMembers;
    }

    public String getCircleCategory() {
        return circleCategory;
    }

    public void setCircleCategory(String circleCategory) {
        this.circleCategory = circleCategory;
    }

    public CircleAccess getCircleAccess() {
        return circleAccess;
    }

    public void setCircleAccess(CircleAccess circleAccess) {
        this.circleAccess = circleAccess;
    }
}
