package com.twc.dailylog.fragments;


import android.os.Bundle;
import android.os.Handler;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.LinearLayout;

import com.twc.dailylog.R;
import com.twc.dailylog.R2;
import com.twc.dailylog.adapter.WeightLogAdapter;
import com.twc.dailylog.model.beans.WeightLogItem;
import com.twc.dailylog.model.requestbody.BaseMemberIdBody;
import com.twc.dailylog.model.response.WeightLogResponse;
import com.twc.dailylog.rest.RestClient;
import com.twc.dailylog.utils.DailyLogConfig;
import com.twc.dailylog.utils.DialogFactory;
import com.twc.dailylog.utils.NetworkFactory;
import com.twc.dailylog.utils.Utils;
import com.twc.dailylog.views.CustomProgressDialog;
import com.twc.dailylog.views.NoDataView;

import java.util.ArrayList;

import butterknife.BindView;
import butterknife.ButterKnife;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class WeightLogFragment extends BaseFragment {

    @BindView(R2.id.weightLogRecycleView)
    RecyclerView weightLogRecycleView;

    @BindView(R2.id.rootView)
    LinearLayout rootView;

    @BindView(R2.id.noDataView)
    NoDataView noDataView;

    private ArrayList<WeightLogItem> mWeightItems;
    private WeightLogAdapter mWeightLogAdapter;

    public static WeightLogFragment newInstance() {
        return new WeightLogFragment();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
        mWeightItems = new ArrayList<>();
        mWeightLogAdapter = new WeightLogAdapter(mWeightItems, getActivity());

    }

    @Override
    protected int getFragmentLayout() {
        return R.layout.fragment_weightlog;
    }

    @Override
    protected void onFragmentReady() {

        noDataView.setTitleView(getString(R.string.no_track__weight_available));
        noDataView.setSubTitleView(getString(R.string.no_track__weight_msg));
        noDataView.setImageIcon(ContextCompat.getDrawable(getActivity(),R.drawable.ic_launcher));

        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getActivity());
        weightLogRecycleView.setLayoutManager(layoutManager);

        weightLogRecycleView.setAdapter(mWeightLogAdapter);

    }

    @Override
    public void onResume() {
        super.onResume();

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                weightLogApiCall();
            }
        }, 500);
    }

    //call Api for all weight log
    private void weightLogApiCall() {
        if (NetworkFactory.getInstance().isNetworkAvailable(getActivity())) {
            final CustomProgressDialog pd;
            pd = new CustomProgressDialog(getActivity(), R.style.custom_progress_style, true);
            pd.show();
            BaseMemberIdBody weightLogBody = new BaseMemberIdBody();
            //weightLogBody.setMemberID(WellnessCornerApp.getPreferenceManager().getUserId());

            RestClient restClient = new RestClient(getActivity(), DailyLogConfig.BASE_URL, DailyLogConfig.DEBUG);
            restClient.getWeightService().getWeight(weightLogBody).enqueue(new Callback<WeightLogResponse>() {
                @Override
                public void onResponse(Call<WeightLogResponse> call, Response<WeightLogResponse> response) {
                    if (isAdded() && getActivity() != null) {
                        if (pd != null && pd.isShowing())
                            pd.dismiss();

                        if (response != null && response.body() != null) {
                            if (response.body().getStatus() == 0) {
                                if (response.body().getData().size() > 0) {
                                    mWeightItems.clear();
                                    mWeightItems.addAll(response.body().getData());
                                    mWeightLogAdapter.notifyDataSetChanged();
                                    noDataView.setVisibility(View.GONE);
                                } else {

                                    noDataView.setVisibility(View.VISIBLE);
                                }
                            } else if (response.body().getStatus() == -1) {
                                DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_response_failure), getString(R.string.str_ok), false);
                                // Toast.makeText(getActivity(), getString(R.string.msg_api_response_failure), Toast.LENGTH_SHORT).show();
                            }
                        } else {
                            DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_response_null), getString(R.string.str_ok), false);
                            // Toast.makeText(getActivity(), getString(R.string.msg_api_response_null), Toast.LENGTH_SHORT).show();
                        }
                    }
                }

                @Override
                public void onFailure(Call<WeightLogResponse> call, Throwable t) {
                    if (isAdded() && getActivity() != null) {
                        if (pd != null && pd.isShowing()) {
                            pd.dismiss();
                            DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_failure), getString(R.string.str_ok), false);
                            // Toast.makeText(getActivity(), getString(R.string.msg_api_failure), Toast.LENGTH_SHORT).show();
                        }
                    }
                }
            });

        } else {
            Utils.showSnackBarMessage(rootView, getString(R.string.internet_not_available));
        }
    }


}

