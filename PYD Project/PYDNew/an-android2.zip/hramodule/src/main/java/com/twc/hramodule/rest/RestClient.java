package com.twc.hramodule.rest;

import android.content.Context;

/**
 * Created by ManishJ1 on 6/29/2016.
 */
public class RestClient extends AbstractRestClient {

    private HraService hraService;

    public RestClient(Context context, String baseUrl, boolean debug) {
        super(context, baseUrl, debug);
    }

    @Override
    public void initApi() {

        hraService = client.create(HraService.class);
    }


    public HraService getHraService() {
        return hraService;
    }


}
