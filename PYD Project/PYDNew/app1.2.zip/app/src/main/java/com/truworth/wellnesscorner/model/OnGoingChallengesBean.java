package com.truworth.wellnesscorner.model;

import java.io.Serializable;

public class OnGoingChallengesBean implements Serializable{
    private String challengeIdentity;
    private String challengeName;
    private int challengeEarnPeps;
    private String challengeStartDate;
    private String challengeEndDate;
    private int challengeTypeId;
    public int memberIsCheckIn;

    public String getChallengeIdentity() {
        return challengeIdentity;
    }

    public void setChallengeIdentity(String challengeIdentity) {
        this.challengeIdentity = challengeIdentity;
    }

    public String getChallengeName() {
        return challengeName;
    }

    public void setChallengeName(String challengeName) {
        this.challengeName = challengeName;
    }

    public int getChallengeEarnPeps() {
        return challengeEarnPeps;
    }

    public void setChallengeEarnPeps(int challengePeps) {
        this.challengeEarnPeps = challengePeps;
    }

    public String getChallengeStartDate() {
        return challengeStartDate;
    }

    public void setChallengeStartDate(String challengeStartDate) {
        this.challengeStartDate = challengeStartDate;
    }

    public String getChallengeEndDate() {
        return challengeEndDate;
    }

    public void setChallengeEndDate(String challengeEndDate) {
        this.challengeEndDate = challengeEndDate;
    }

    public int getChallengeTypeId() {
        return challengeTypeId;
    }

    public void setChallengeTypeId(int challengeTypeId) {
        this.challengeTypeId = challengeTypeId;
    }

    public int getMemberIsCheckIn() {
        return memberIsCheckIn;
    }

    public void setMemberIsCheckIn(int memberIsCheckIn) {
        this.memberIsCheckIn = memberIsCheckIn;
    }
}
