package com.truworth.wellnesscorner.model;

import com.truworth.wellnesscorner.ui.mainapp.post.IPostListItem;

public class ViewPreviousItem implements IPostListItem {
    private boolean isVisible;

    public boolean isVisible() {
        return isVisible;
    }

    public void setVisible(boolean visible) {
        isVisible = visible;
    }

    @Override
    public int getPostListItemType() {
        return IPostListItem.TYPE_VIEW_PREVIOUS;
    }
}
