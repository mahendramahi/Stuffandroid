package com.twc.remindermodule.adapter;


import android.content.Context;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.support.annotation.NonNull;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.RecyclerView;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import com.afollestad.sectionedrecyclerview.SectionedRecyclerViewAdapter;
import com.tooltip.OnClickListener;
import com.tooltip.Tooltip;
import com.twc.remindermodule.R;

import com.twc.remindermodule.model.beans.SectionSleepLogItem;
import com.twc.remindermodule.model.response.GetSleepLogResponse;
import com.twc.remindermodule.utils.Constant;
import com.twc.remindermodule.utils.DateFactory;
import com.twc.remindermodule.views.CustomTextView;

import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

/**
 * Created by richas on 1/17/2018.
 */

public class SleepLogSectionAdapter extends SectionedRecyclerViewAdapter<RecyclerView.ViewHolder> {

    private ArrayList<SectionSleepLogItem> sectionItems;
    private Context context;

    public SleepLogSectionAdapter(ArrayList<SectionSleepLogItem> sectionItems, Context context) {
        this.sectionItems = sectionItems;
        this.context = context;
    }

    @Override
    public int getSectionCount() {
        return sectionItems.size();
    }

    @Override
    public int getItemCount(int section) {
        if (sectionItems.get(section) != null)
            return sectionItems.get(section).getmSleepLogArrayList().size();
        else
            return 0;
    }

    @Override
    public void onBindHeaderViewHolder(RecyclerView.ViewHolder holder, int section) {
        SectionViewHolder sectionViewHolder = (SectionViewHolder) holder;
        if (!sectionItems.get(section).getMonthName().equalsIgnoreCase("null")) {
            // section header
            sectionViewHolder.tvMonthName.setText(sectionItems.get(section).getMonthName());
            if (sectionItems.get(section).getmSleepLogArrayList().size() > 1)
                sectionViewHolder.tvNightsCount.setText(String.format(Locale.getDefault(), "%d nights", sectionItems.get(section).getmSleepLogArrayList().size()));
            else
                sectionViewHolder.tvNightsCount.setText(String.format(Locale.getDefault(), "%d night", sectionItems.get(section).getmSleepLogArrayList().size()));

            sectionViewHolder.tvAveragePercent.setText(String.format(Locale.getDefault(), "avg.%d%%", sectionItems.get(section).getAveragePercent()));

            GradientDrawable ivAverageColorShape = (GradientDrawable) sectionViewHolder.ivAverageColor.getBackground().mutate();
            ivAverageColorShape.setColor(context.getResources().getColor(R.color.color_2bc7bb));
            ivAverageColorShape.setStroke(0, 0);
            sectionViewHolder.rootProgress.setVisibility(View.GONE);
            sectionViewHolder.headerLayout.setVisibility(View.VISIBLE);
        } else {
            sectionViewHolder.rootProgress.setVisibility(View.VISIBLE);
            sectionViewHolder.headerLayout.setVisibility(View.GONE);
        }
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int section, final int relativePosition, final int absolutePosition) {

        final ArrayList<GetSleepLogResponse.DataSleepLogItem> sleepLogData = sectionItems.get(section).getmSleepLogArrayList();

        final ItemViewHolder itemViewHolder = (ItemViewHolder) holder;
        if (sleepLogData.get(relativePosition).getSleepLog_DateTime() != null) {
            String dateString = DateFactory.getInstance().truncateMilliseconds(sleepLogData.get(relativePosition).getSleepLog_DateTime());
            String date = DateFactory.getInstance().formatDate(Constant.SERVER_DATE_FORMAT_WITH_MILLISECONDS, "EEE, MMM dd", dateString);
            String time = DateFactory.getInstance().formatDate(Constant.SERVER_DATE_FORMAT_WITH_MILLISECONDS, "HH:mm", dateString);
            String wakeUpDateString = DateFactory.getInstance().truncateMilliseconds(sleepLogData.get(relativePosition).getSleepLog_WakeUpTime());

            itemViewHolder.tvDate.setText(date);
            itemViewHolder.tvTime.setText(time);

            String sleepDuration="";
            if(dateString!=null && wakeUpDateString!=null)
                  sleepDuration = calculateDuration(dateString, wakeUpDateString);
            if (sleepDuration != null)
                itemViewHolder.tvSleepDuration.setText(sleepDuration);

            int feel = sleepLogData.get(relativePosition).getSleepLog_Feel();
            if (feel == 1) {
                itemViewHolder.ivMood.setImageResource(R.drawable.excellent_small);
            } else if (feel == 2) {
                itemViewHolder.ivMood.setImageResource(R.drawable.good_small);
            } else if (feel == 3) {
                itemViewHolder.ivMood.setImageResource(R.drawable.normal_small);
            } else if (feel == 4) {
                itemViewHolder.ivMood.setImageResource(R.drawable.sad_small);
            } else if (feel == 5) {
                itemViewHolder.ivMood.setImageResource(R.drawable.very_sad_small);
            } else {
                itemViewHolder.ivMood.setImageResource(R.drawable.no_feel);
            }
            String noteString = sleepLogData.get(relativePosition).getSleepLog_Remarks();
            if (noteString.isEmpty())
                itemViewHolder.tvNote.setVisibility(View.INVISIBLE);
            else
                itemViewHolder.tvNote.setVisibility(View.VISIBLE);

            itemViewHolder.tvNote.setTag(absolutePosition);
            itemViewHolder.tvNote.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                   // condtion check for last row note tooltip visibility
                    if(itemViewHolder.tvNote.getTag().equals(getItemCount()-(sectionItems.size()+1))){
                        Tooltip toolTip = new Tooltip.Builder(view)
                                .setBackgroundColor(ContextCompat.getColor(context, R.color.color_FFFFFF))
                                .setCancelable(true)
                                .setCornerRadius(R.dimen.space1)
                                .setOnClickListener(new OnClickListener() {
                                    @Override
                                    public void onClick(@NonNull Tooltip tooltip) {
                                        if (tooltip.isShowing())
                                            tooltip.dismiss();
                                    }
                                })
                                .setGravity(Gravity.TOP)
                                .setTextStyle(Typeface.NORMAL)
                                .setPadding(R.dimen.space3)
                                .setTextSize(R.dimen.textSize3)
                                .setTextColor(ContextCompat.getColor(context, R.color.color_050313))
                                .setText(sleepLogData.get(relativePosition).getSleepLog_Remarks()).show();
                    } else {
                        Tooltip toolTip = new Tooltip.Builder(view)
                                .setBackgroundColor(ContextCompat.getColor(context, R.color.color_FFFFFF))
                                .setCancelable(true)
                                .setCornerRadius(R.dimen.space1)
                                .setOnClickListener(new OnClickListener() {
                                    @Override
                                    public void onClick(@NonNull Tooltip tooltip) {
                                        if (tooltip.isShowing())
                                            tooltip.dismiss();
                                    }
                                })
                                .setTextStyle(Typeface.NORMAL)
                                .setPadding(R.dimen.space3)
                                .setTextSize(R.dimen.textSize3)
                                .setTextColor(ContextCompat.getColor(context, R.color.color_050313))
                                .setText(sleepLogData.get(relativePosition).getSleepLog_Remarks()).show();
                    }
                }
            });


        }
    }


    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View v;
        if (viewType == VIEW_TYPE_HEADER) {
            v = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.row_sleep_logs_header, parent, false);
            return new SectionViewHolder(v);
        } else {
            v = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.row_sleep_logs, parent, false);
            return new ItemViewHolder(v);
        }
    }

    private String calculateDuration(String sleepDateString, String wakeUpDateString) {

        String duration = "";
        Date dtSleepDateTime = DateFactory.getInstance().getDate(sleepDateString, Constant.SERVER_DATE_FORMAT_WITH_MILLISECONDS);
        Date dtAwakeDateTime = DateFactory.getInstance().getDate(wakeUpDateString, Constant.SERVER_DATE_FORMAT_WITH_MILLISECONDS);

        if (dtSleepDateTime.after(dtAwakeDateTime)) {
            duration = "0 h 0 min";

        } else {
            long diffDays = DateFactory.getInstance().getDaysDifference(sleepDateString, wakeUpDateString, Constant.SERVER_DATE_FORMAT_WITH_MILLISECONDS);
            long diffHours = DateFactory.getInstance().getHourDifference(sleepDateString, wakeUpDateString, Constant.SERVER_DATE_FORMAT_WITH_MILLISECONDS);
            long diffMinutes = DateFactory.getInstance().getMinuteDifference(sleepDateString, wakeUpDateString, Constant.SERVER_DATE_FORMAT_WITH_MILLISECONDS);
            diffHours = (diffDays * 24) + diffHours;

            duration = diffHours + " h " + diffMinutes + " min";
        }
        return duration;
    }

    // SectionViewHolder Class for Sections
    public class SectionViewHolder extends RecyclerView.ViewHolder {

        CustomTextView tvMonthName;
        CustomTextView tvAveragePercent;
        CustomTextView tvNightsCount;
        ImageView ivAverageColor;
        LinearLayout rootProgress;
        RelativeLayout headerLayout;

        public SectionViewHolder(View itemView) {
            super(itemView);
            headerLayout = itemView.findViewById(R.id.headerLayout);
            rootProgress = itemView.findViewById(R.id.rootProgress);
            tvMonthName = itemView.findViewById(R.id.tvMonthName);
            tvAveragePercent = itemView.findViewById(R.id.tvAveragePercent);
            tvNightsCount = itemView.findViewById(R.id.tvNightsCount);
            ivAverageColor = itemView.findViewById(R.id.ivAverageColor);

        }
    }

    // ItemViewHolder Class for Items in each Section
    public class ItemViewHolder extends RecyclerView.ViewHolder {

        CustomTextView tvDate;
        CustomTextView tvTime;
        CustomTextView tvSleepDuration;
        ImageView ivMood;
        CustomTextView tvNote;
        RelativeLayout rootLayout;

        public ItemViewHolder(View itemView) {
            super(itemView);
            tvDate = itemView.findViewById(R.id.tvDate);
            tvTime = itemView.findViewById(R.id.tvTime);
            tvSleepDuration = itemView.findViewById(R.id.tvSleepDuration);
            ivMood = itemView.findViewById(R.id.ivMood);
            tvNote = itemView.findViewById(R.id.tvNote);
            rootLayout = itemView.findViewById(R.id.rootLayout);

        }
    }

}

