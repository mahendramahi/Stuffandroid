package com.truworth.wellnesscorner.ui.mainapp.post;

import android.databinding.DataBindingUtil;
import android.net.Uri;
import android.support.v4.view.ViewCompat;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.truworth.wellnesscorner.R;
import com.truworth.wellnesscorner.databinding.ItemImageSliderBinding;
import com.truworth.wellnesscorner.databinding.RowVideoPlayerBinding;
import com.truworth.wellnesscorner.model.PostMediaList;

import java.util.List;

import im.ene.toro.media.PlaybackInfo;

public class MediaFileRecyclerAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    public static int MEDIA_TYPE_IMAGE = 1;
    public static int MEDIA_TYPE_VIDEO = 2;

    private LayoutInflater inflater;
    List<PostMediaList> postMediaDataList;
    private final ItemClickListener itemClickListener;

    public MediaFileRecyclerAdapter(List<PostMediaList> postMediaDataList, ItemClickListener itemClickListener) {
        this.postMediaDataList = postMediaDataList;
        this.itemClickListener = itemClickListener;
    }


    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        if (inflater == null || inflater.getContext() != parent.getContext()) {
            inflater = LayoutInflater.from(parent.getContext());
        }

        RecyclerView.ViewHolder viewHolder = null;
        if (viewType == MEDIA_TYPE_IMAGE) {
            ItemImageSliderBinding binding = DataBindingUtil.inflate(inflater, R.layout.item_image_slider, parent, false);
            viewHolder = new MediaImageViewHolder(binding);
        } else {
            RowVideoPlayerBinding videoBinding = DataBindingUtil.inflate(inflater, R.layout.row_video_player, parent, false);
            MediaVideoViewHolder mediaVideoViewHolder = new MediaVideoViewHolder(videoBinding);
            ViewCompat.setTransitionName(mediaVideoViewHolder.playerView,
                    "single player");
            mediaVideoViewHolder.setClickListener(v -> {
                int pos = mediaVideoViewHolder.getAdapterPosition();
                if (itemClickListener != null && pos != RecyclerView.NO_POSITION) {
                    itemClickListener.onItemClick(mediaVideoViewHolder.playerView, pos, Uri.parse(postMediaDataList.get(pos).getPostMediaData().get(0).getFileName()),
                            mediaVideoViewHolder.getCurrentPlaybackInfo());
                }
            });
            viewHolder = mediaVideoViewHolder;
        }

        return viewHolder;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        if (holder.getItemViewType() == MEDIA_TYPE_IMAGE) {
            ((MediaImageViewHolder) holder).bind(postMediaDataList.get(position).getPostMediaData().get(0));
        } else if (holder.getItemViewType() == MEDIA_TYPE_VIDEO) {
            ((MediaVideoViewHolder) holder).bind(postMediaDataList.get(position).getPostMediaData().get(0));
        }
    }

    @Override
    public int getItemViewType(int position) {
        Log.d("MediaFileRecyclera", "getItemViewType: " + position);
        if (postMediaDataList.get(position).getPostMediaType() == PostConstants.MEDIA_TYPE_IMAGE) {
            return MEDIA_TYPE_IMAGE;
        }
        return MEDIA_TYPE_VIDEO;
    }

    @Override
    public int getItemCount() {
        return postMediaDataList.size();
    }

    static abstract class ItemClickListener {

        abstract void onItemClick(View view, int position, Uri media,
                                  PlaybackInfo playbackInfo);
    }
}
