package com.twc.dailylog.model.response;


import com.twc.dailylog.model.beans.ExerciseItem;

import java.util.List;

/**
 * Created by PalakC on 7/6/2016.
 */
public class TrackExerciseResponse {
    /**
     * data : [{"ExerciseID":8,"ActivityCalorie":6,"ActivityName":"Teaching aerobics"}]
     * status : 0
     */

    private int status;
    /**
     * ExerciseID : 8
     * ActivityCalorie : 6
     * ActivityName : Teaching aerobics
     */

    private List<ExerciseItem> Data;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public List<ExerciseItem> getData() {
        return Data;
    }

    public void setData(List<ExerciseItem> data) {
        this.Data = data;
    }
}
