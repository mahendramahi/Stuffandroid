package com.truworth.wellnesscorner.repo.model.request;

/**
 * Created by PalakC on 2/20/2018.
 */

public class GetMemberProgramDetailBody {

    private int MemberPID;

    public int getMemberPID() {
        return MemberPID;
    }

    public void setMemberPID(int MemberPID) {
        this.MemberPID = MemberPID;
    }
}
