package com.truworth.wellnesscorner.ui.step;

/**
 * If this code works it was written by Somesh Kumar on 31 March, 2017. If not, I don't know who wrote it.
 */
public class SaveActivityCaloriesResponse {
    private int status;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }
}
