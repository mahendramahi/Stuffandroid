package com.truworth.wellnesscorner.repo.model.response;

/**
 If this code works it was written by Somesh Kumar on 17 August, 2016. If not, I don't know who wrote it.
 */
public class LeaveProgramChallengeResponse {
    private int status;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }
}
