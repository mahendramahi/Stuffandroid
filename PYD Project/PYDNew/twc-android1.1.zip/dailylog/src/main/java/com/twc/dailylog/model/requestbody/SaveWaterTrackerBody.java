package com.twc.dailylog.model.requestbody;

/**
 * Created by GurvinderS on 8/23/2016.
 */
public class SaveWaterTrackerBody {

    private String MemberID;

    public String getDate() {
        return Date;
    }

    public void setDate(String date) {
        Date = date;
    }

    public String getMemberID() {
        return MemberID;
    }

    public void setMemberID(String memberID) {
        MemberID = memberID;
    }

    public String getNoOfWaterGlass() {
        return NoOfWaterGlass;
    }

    public void setNoOfWaterGlass(String noOfWaterGlass) {
        NoOfWaterGlass = noOfWaterGlass;
    }

    private String Date;
    private String NoOfWaterGlass;
}
