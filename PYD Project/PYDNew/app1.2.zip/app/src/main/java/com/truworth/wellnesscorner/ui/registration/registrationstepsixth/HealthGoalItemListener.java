package com.truworth.wellnesscorner.ui.registration.registrationstepsixth;

import com.truworth.wellnesscorner.repo.model.response.HealthGoalResponse;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by PalakC on 4/12/2018.
 */

public interface HealthGoalItemListener {
    void onItemSeleced(ArrayList<Integer> healthIds);
}
