package com.twc.dailylog.model.response;


import com.twc.dailylog.model.beans.FoodDetailItem;

/**
 * Created by ManishJ1 on 7/13/2016.
 */
public class GetFoodDetailResponse {

    /**
     * name : CHILGOZA
     * quantity : 1
     * calorie : 615.0
     * fat : 49.3
     * sodium : 42.3
     * carbs : 29.0
     * cholestrol : 0.0
     * protin : 13.9
     */

    private FoodDetailItem data;
    /**
     * data : {"name":"CHILGOZA","quantity":1,"calorie":615,"fat":49.3,"sodium":42.3,"carbs":29,"cholestrol":0,"protin":13.9}
     * status : 0
     */

    private int status;

    public FoodDetailItem getData() {
        return data;
    }

    public void setData(FoodDetailItem data) {
        this.data = data;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }
}
