package com.twc.store.model.beans;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by ManishJ1 on 9/15/2017.
 */

public class CouponBean implements Parcelable {
    public static final Creator<CouponBean> CREATOR = new Creator<CouponBean>() {
        @Override
        public CouponBean createFromParcel(Parcel source) {
            return new CouponBean(source);
        }

        @Override
        public CouponBean[] newArray(int size) {
            return new CouponBean[size];
        }
    };
    private int couponId;
    private String couponCode;
    private double couponDiscount;

    public CouponBean() {
    }

    protected CouponBean(Parcel in) {
        this.couponId = in.readInt();
        this.couponCode = in.readString();
        this.couponDiscount = in.readDouble();
    }

    public int getCouponId() {
        return couponId;
    }

    public void setCouponId(int couponId) {
        this.couponId = couponId;
    }

    public String getCouponCode() {
        return couponCode;
    }

    public void setCouponCode(String couponCode) {
        this.couponCode = couponCode;
    }

    public double getCouponDiscount() {
        return couponDiscount;
    }

    public void setCouponDiscount(double couponDiscount) {
        this.couponDiscount = couponDiscount;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(this.couponId);
        dest.writeString(this.couponCode);
        dest.writeDouble(this.couponDiscount);
    }
}
