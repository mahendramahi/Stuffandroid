package com.twc.store.model.requestbody;

/**
 * Created by GurvinderS on 9/18/2017.
 */

public class StoreCheckoutBody {


    /**
     * MemberId : 246170
     * couponCode :
     * cartIds : 4292,4291
     * couponIds :
     */

    private String MemberId;
    private String cartIds;

    public String getMemberId() {
        return MemberId;
    }

    public void setMemberId(String MemberId) {
        this.MemberId = MemberId;
    }

    public String getCartIds() {
        return cartIds;
    }

    public void setCartIds(String cartIds) {
        this.cartIds = cartIds;
    }
}
