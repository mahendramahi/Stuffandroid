package com.twc.greendaolib;

import org.greenrobot.greendao.annotation.Entity;
import org.greenrobot.greendao.annotation.Id;
import org.greenrobot.greendao.annotation.NotNull;
import org.greenrobot.greendao.annotation.Generated;

/**
 * If this code works it was written by Somesh Kumar on 15 October, 2016. If not, I don't know who wrote it.
 */
@Entity
public class HraDBItem {
    @Id
    long questionId;
    @NotNull
    String answer;
    @NotNull
    float screeNo;
    int isSure;

    @Generated(hash = 372497430)
    public HraDBItem(long questionId, @NotNull String answer, float screeNo, int isSure) {
        this.questionId = questionId;
        this.answer = answer;
        this.screeNo = screeNo;
        this.isSure = isSure;
    }

    @Generated(hash = 2042027991)
    public HraDBItem() {
    }

    public int getIsSure() {
        return this.isSure;
    }

    public void setIsSure(int isSure) {
        this.isSure = isSure;
    }

    public float getScreeNo() {
        return this.screeNo;
    }

    public void setScreeNo(float screeNo) {
        this.screeNo = screeNo;
    }

    public String getAnswer() {
        return this.answer;
    }

    public void setAnswer(String answer) {
        this.answer = answer;
    }

    public long getQuestionId() {
        return this.questionId;
    }

    public void setQuestionId(long questionId) {
        this.questionId = questionId;
    }


}
