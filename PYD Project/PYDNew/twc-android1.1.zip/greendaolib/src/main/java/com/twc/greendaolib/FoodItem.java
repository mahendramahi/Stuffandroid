package com.twc.greendaolib;


import org.greenrobot.greendao.annotation.Entity;
import org.greenrobot.greendao.annotation.Generated;

/**
 * Created by ManishJ1 on 8/3/2016.
 */
@Entity
public class FoodItem {

    public int foodId;
    public String name;
    public String quantity;
    public String standardServing;
    public String calories;
    public String unit;
    public String protein;
    public String fat;
    public String carbs;
    public String sodium;
    public String serverId;
    public String mealType;
    public String dateTime;
    public boolean isModified;
    public boolean isUploaded;
    public boolean isDeleted;

    @Generated(hash = 1839260769)
    public FoodItem(int foodId, String name, String quantity,
            String standardServing, String calories, String unit, String protein,
            String fat, String carbs, String sodium, String serverId,
            String mealType, String dateTime, boolean isModified,
            boolean isUploaded, boolean isDeleted) {
        this.foodId = foodId;
        this.name = name;
        this.quantity = quantity;
        this.standardServing = standardServing;
        this.calories = calories;
        this.unit = unit;
        this.protein = protein;
        this.fat = fat;
        this.carbs = carbs;
        this.sodium = sodium;
        this.serverId = serverId;
        this.mealType = mealType;
        this.dateTime = dateTime;
        this.isModified = isModified;
        this.isUploaded = isUploaded;
        this.isDeleted = isDeleted;
    }

    @Generated(hash = 502595677)
    public FoodItem() {
    }

    public boolean getIsDeleted() {
        return this.isDeleted;
    }

    public void setIsDeleted(boolean isDeleted) {
        this.isDeleted = isDeleted;
    }

    public boolean getIsUploaded() {
        return this.isUploaded;
    }

    public void setIsUploaded(boolean isUploaded) {
        this.isUploaded = isUploaded;
    }

    public boolean getIsModified() {
        return this.isModified;
    }

    public void setIsModified(boolean isModified) {
        this.isModified = isModified;
    }

    public String getDateTime() {
        return this.dateTime;
    }

    public void setDateTime(String dateTime) {
        this.dateTime = dateTime;
    }

    public String getMealType() {
        return this.mealType;
    }

    public void setMealType(String mealType) {
        this.mealType = mealType;
    }

    public String getServerId() {
        return this.serverId;
    }

    public void setServerId(String serverId) {
        this.serverId = serverId;
    }

    public String getSodium() {
        return this.sodium;
    }

    public void setSodium(String sodium) {
        this.sodium = sodium;
    }

    public String getCarbs() {
        return this.carbs;
    }

    public void setCarbs(String carbs) {
        this.carbs = carbs;
    }

    public String getFat() {
        return this.fat;
    }

    public void setFat(String fat) {
        this.fat = fat;
    }

    public String getProtein() {
        return this.protein;
    }

    public void setProtein(String protein) {
        this.protein = protein;
    }

    public String getUnit() {
        return this.unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public String getCalories() {
        return this.calories;
    }

    public void setCalories(String calories) {
        this.calories = calories;
    }

    public String getStandardServing() {
        return this.standardServing;
    }

    public void setStandardServing(String standardServing) {
        this.standardServing = standardServing;
    }

    public String getQuantity() {
        return this.quantity;
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getFoodId() {
        return this.foodId;
    }

    public void setFoodId(int foodId) {
        this.foodId = foodId;
    }



}
