package com.truworth.wellnesscorner.ui.mainapp.today;


import android.databinding.ObservableField;

import com.truworth.wellnesscorner.model.TodayMyChallenge;
import com.truworth.wellnesscorner.utils.DateUtils;
import com.truworth.wellnesscorner.utils.Utils;

public class MyChallengeItemViewModel {


    private final MyChallengeListener myChallengeListener;
    public ObservableField<String> days = new ObservableField<>();
    public TodayMyChallenge getMyChallenge() {
        return myChallenge;
    }



    public TodayMyChallenge myChallenge;
    public String mCircleIdentity;


    public MyChallengeItemViewModel(TodayMyChallenge myChallenge, MyChallengeItemViewModel.MyChallengeListener myChallengeListener, String circleIdentity) {
        this.myChallenge = myChallenge;
        this.myChallengeListener = myChallengeListener;
        this.mCircleIdentity=circleIdentity;
        int daysLeft = Integer.parseInt(DateUtils.getDayDifference(myChallenge.getChallengeEndDate()));
        days.set(daysLeft+" days remaining");
    }

    public void onItemClick() {
        myChallengeListener.onItemClick(myChallenge,mCircleIdentity);
    }
    public interface MyChallengeListener {

        void onItemClick(TodayMyChallenge onGoingChallenge, String postMapId);
    }
    public int getProgress() {
        int progressValue;
        int daysLeft = Integer.parseInt(DateUtils.getDayDifference(myChallenge.getChallengeEndDate()));
        int daysDifference = Integer.parseInt(DateUtils.getOnlyDaysDifference(myChallenge.getChallengeStartDate(), myChallenge.getChallengeEndDate(), "yyyy-MM-dd'T'HH:mm:ss"));
        progressValue = (int) Utils.getPercentage(daysDifference-daysLeft, daysDifference);
        return progressValue;
    }

}
