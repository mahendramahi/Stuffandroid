package com.twc.remindermodule.fragments;

/**
 * Created by GurvinderS on 10/12/2016.
 */
public interface OnTrackerReadingSave {

    void onTrackerReadingSuccess();
}
