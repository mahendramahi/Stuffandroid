package com.truworth.wellnesscorner.ui.mainapp.createpost.sharemeal;

public interface AdapterCallback {
    void onMethodCallback(int position, boolean setSelected);
}
