package com.truworth.wellnesscorner.ui.mytask;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.CardView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.truworth.wellnesscorner.R;
import com.truworth.wellnesscorner.TheWellnessCornerApp;
import com.truworth.wellnesscorner.model.DataMemberProgramItem;
import com.truworth.wellnesscorner.repo.MyTaskRepository;
import com.truworth.wellnesscorner.repo.model.request.BaseMemberIdBody;
import com.truworth.wellnesscorner.repo.model.response.GetMemberProgramResponse;

import java.util.List;

import javax.inject.Inject;

import butterknife.BindView;
import butterknife.ButterKnife;
import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;

/**
 * Created by PalakC on 2/16/2018.
 */

public class MyTaskPagerFragment extends Fragment implements View.OnClickListener {
    public static final String TAG = "MyTaskPagerFragment";
    @BindView(R.id.viewPager)
    ViewPager viewPager;
    @BindView(R.id.rooView)
    LinearLayout rooView;
    @BindView(R.id.cvNoTask)
    CardView cvNoTask;
    @BindView(R.id.mainProgressBar)
    ProgressBar mainProgressBar;
    @BindView(R.id.rlViewPager)
    RelativeLayout rlViewPager;
    @BindView(R.id.ivBack)
    ImageView ivBack;

    @Inject
    MyTaskRepository myTaskRepository;

    public static MyTaskPagerFragment newInstance() {
        return new MyTaskPagerFragment();
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        TheWellnessCornerApp.getApp().component().inject(this);

    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_mytask_viewpager,
                container, false);
        ButterKnife.bind(this, view);
        getMemberProgramApiCall();

        viewPager.setOffscreenPageLimit(3);
        viewPager.setClipToPadding(false);
        viewPager.setPageMargin((int)dpToPixels(12, getActivity()));
        ivBack.setOnClickListener(this);
        return view;
    }

    public static float dpToPixels(int dp, Context context) {
        return dp * (context.getResources().getDisplayMetrics().density);
    }

    // call get member program api for all programs
    private void getMemberProgramApiCall() {
        if (NetworkFactory.getInstance().isNetworkAvailable(getActivity())) {
            BaseMemberIdBody memberIdBody = new BaseMemberIdBody();
            memberIdBody.setMemberID(MyTaskConfig.myTaskUser.getUserID());

            myTaskRepository.getMemberPrograms(memberIdBody).subscribe(new Observer<GetMemberProgramResponse>() {
                @Override
                public void onSubscribe(Disposable d) {

                }
                @Override
                public void onNext(GetMemberProgramResponse programResponse) {
                    if (isAdded() && getActivity() != null) {
                        mainProgressBar.setVisibility(View.GONE);
                        if (programResponse != null &&  programResponse.getData() != null) {
                            if (programResponse.getStatus() == 0) {
                                if (programResponse.getData().size() > 0) {
                                    cvNoTask.setVisibility(View.GONE);
                                    rlViewPager.setVisibility(View.VISIBLE);
                                    viewPager.setVisibility(View.VISIBLE);


                                    List<DataMemberProgramItem> item = programResponse.getData();
                                    MyTaskPagerAdapter pagerAdapter = new MyTaskPagerAdapter(getChildFragmentManager(), dpToPixels(2, getActivity()),item);
                                    ShadowTransformer fragmentCardShadowTransformer = new ShadowTransformer(viewPager, pagerAdapter);
                                    fragmentCardShadowTransformer.enableScaling(true);
                                    viewPager.setAdapter(pagerAdapter);
                                    viewPager.setPageTransformer(false, fragmentCardShadowTransformer);
                                }
                                else{
                                    viewPager.setVisibility(View.GONE);
                                    rlViewPager.setVisibility(View.GONE);
                                    //cvNoTask.setBackgroundColor(getActivity().getResources().getColor(R.color.transparent));
                                    cvNoTask.setVisibility(View.VISIBLE);
                                }
                            } else {
                                // DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_response_failure), getString(R.string.str_ok), false);
                                Toast.makeText(getActivity(), getString(R.string.msg_api_response_failure), Toast.LENGTH_SHORT).show();
                            }

                        } else {
                            //  DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_response_null), getString(R.string.str_ok), false);
                            Toast.makeText(getActivity(), getString(R.string.msg_api_response_null), Toast.LENGTH_SHORT).show();
                        }
                    }
                }
                @Override
                public void onError(Throwable e) {
                    if (isAdded() && getActivity() != null) {
                        mainProgressBar.setVisibility(View.GONE);
                        // DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_failure), getString(R.string.str_ok), false);
                        Toast.makeText(getActivity(), getString(R.string.msg_api_failure), Toast.LENGTH_SHORT).show();
                    }
                }

                @Override
                public void onComplete() {

                }
            });

        } else {
           // Utils.showSnackBarMessage(rooView, getString(R.string.internet_not_available));
            Toast.makeText(getActivity(), getString(R.string.internet_not_available), Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onClick(View view) {
        getActivity().onBackPressed();
    }
}
