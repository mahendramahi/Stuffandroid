package com.twc.dailylog.model.response;

/**
 * Created by GurvinderS on 8/23/2016.
 */
public class SaveWaterTrackerResponse {
    private int status;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }
}
