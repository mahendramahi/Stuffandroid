package com.truworth.wellnesscorner.repo;

import com.truworth.wellnesscorner.network.ApiServices;
import com.truworth.wellnesscorner.repo.model.request.ActivityMarkAsReadBody;
import com.truworth.wellnesscorner.repo.model.response.ActivityMarkAsReadResponse;
import com.truworth.wellnesscorner.repo.model.request.BaseMemberIdBody;
import com.truworth.wellnesscorner.repo.model.request.GetMemberProgramDetailBody;
import com.truworth.wellnesscorner.repo.model.response.GetMemberProgramDetailResponse;
import com.truworth.wellnesscorner.repo.model.response.GetMemberProgramResponse;
import com.truworth.wellnesscorner.repo.model.request.LeaveProgramChallengeBody;
import com.truworth.wellnesscorner.repo.model.response.LeaveProgramChallengeResponse;
import com.truworth.wellnesscorner.repo.model.response.MemberProgramComplianceResponse;

import javax.inject.Inject;
import javax.inject.Singleton;

import io.reactivex.Observable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.schedulers.Schedulers;

@Singleton
public class MyTaskRepository {
    private final ApiServices myTaskServices;

    @Inject
    public MyTaskRepository(ApiServices myTaskServices) {
        this.myTaskServices = myTaskServices;
    }

    public Observable<GetMemberProgramResponse> getMemberPrograms(BaseMemberIdBody memberIdBody) {
        return myTaskServices.getmemberprogram(memberIdBody)
                .subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread());
    }

    public Observable<GetMemberProgramDetailResponse> getMemberProgramDetail(GetMemberProgramDetailBody programDetailBody) {
        return myTaskServices.getmemberprogramdetail(programDetailBody)
                .subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread());
    }

    public Observable<ActivityMarkAsReadResponse> getActivityMarkAsRead(ActivityMarkAsReadBody markAsReadBody) {
        return myTaskServices.getActivityMarkAsRead(markAsReadBody)
                .subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread());
    }

    public Observable<LeaveProgramChallengeResponse> leaveProgram(LeaveProgramChallengeBody leaveProgramChallengeBody) {
        return myTaskServices.leaveProgramChallenge(leaveProgramChallengeBody)
                .subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread());
    }

    public Observable<MemberProgramComplianceResponse> memberProgramCompliance(GetMemberProgramDetailBody programDetailBody) {
        return myTaskServices.getMemberProgramCompliance(programDetailBody)
                .subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread());
    }

    public Observable<ActivityMarkAsReadResponse> getActivityMarkAsDelete(ActivityMarkAsReadBody markAsReadBody) {
        return myTaskServices.getActivityMarkAsDelete(markAsReadBody)
                .subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread());
    }

}
