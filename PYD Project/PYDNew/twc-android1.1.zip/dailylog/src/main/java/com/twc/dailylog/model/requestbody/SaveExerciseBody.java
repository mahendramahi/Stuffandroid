package com.twc.dailylog.model.requestbody;

/**
 * Created by PalakC on 8/3/2016.
 */
public class SaveExerciseBody {

    private int ActivityID;
    private int ActivityMemberID;
    private String ActivityDate;
    private double ActivityCalorie;
    private String ActivityName;
    private int ActivityDuration;

    public double getActivityCalorie() {
        return ActivityCalorie;
    }

    public void setActivityCalorie(double activityCalorie) {
        ActivityCalorie = activityCalorie;
    }


    public int getActivityID() {
        return ActivityID;
    }

    public void setActivityID(int activityID) {
        ActivityID = activityID;
    }

    public int getActivityMemberID() {
        return ActivityMemberID;
    }

    public void setActivityMemberID(int activityMemberID) {
        ActivityMemberID = activityMemberID;
    }

    public String getActivityDate() {
        return ActivityDate;
    }

    public void setActivityDate(String activityDate) {
        ActivityDate = activityDate;
    }

    public String getActivityName() {
        return ActivityName;
    }

    public void setActivityName(String activityName) {
        ActivityName = activityName;
    }

    public int getActivityDuration() {
        return ActivityDuration;
    }

    public void setActivityDuration(int activityDuration) {
        ActivityDuration = activityDuration;
    }


}
