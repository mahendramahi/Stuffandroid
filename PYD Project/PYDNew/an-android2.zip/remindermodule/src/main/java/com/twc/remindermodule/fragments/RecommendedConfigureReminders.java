package com.twc.remindermodule.fragments;

import android.app.Activity;
import android.app.AlarmManager;
import android.app.Fragment;
import android.app.FragmentManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.KeyEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.twc.greendaolib.GreenDaoApp;
import com.twc.greendaolib.ReminderItem;
import com.twc.greendaolib.ReminderItemDao;
import com.twc.greendaolib.ReminderTimeItem;
import com.twc.greendaolib.ReminderTimeItemDao;
import com.twc.remindermodule.R;
import com.twc.remindermodule.R2;
import com.twc.remindermodule.adapter.RecommendedConfigureReminderAdapter;
import com.twc.remindermodule.model.beans.HabitReminderBean;
import com.twc.remindermodule.model.requestbody.BaseMemberIdBody;
import com.twc.remindermodule.model.requestbody.SaveHabitReminderBody;
import com.twc.remindermodule.model.response.HabitReminderResponse;
import com.twc.remindermodule.model.response.SaveHabitReminderResponse;

import com.twc.remindermodule.rest.ReminderConfig;
import com.twc.remindermodule.rest.RestClient;
import com.twc.remindermodule.service.RemindersService;
import com.twc.remindermodule.utils.DateFactory;
import com.twc.remindermodule.utils.DialogFactory;
import com.twc.remindermodule.utils.RemindersDefault;
import com.twc.remindermodule.utils.Utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static android.content.Context.MODE_PRIVATE;

/**
 * Created by GurvinderS on 9/20/2017.
 */

public class RecommendedConfigureReminders extends BaseFragment {

    @BindView(R2.id.ivAddHabit)
    ImageView ivAddHabit;

    @BindView(R2.id.tvSave)
    TextView tvSave;
    @BindView(R2.id.rvConfigureReminder)
    RecyclerView rvConfigureReminder;
    @BindView(R2.id.ivBack)
    ImageView ivBack;
    private ArrayList<HabitReminderBean> habitReminderList;
    private RecommendedConfigureReminderAdapter adapter;

    public static RecommendedConfigureReminders newInstance(Bundle bundle) {
        RecommendedConfigureReminders fragment = new RecommendedConfigureReminders();
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        habitReminderList = new ArrayList<>();

    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        view.setFocusableInTouchMode(true);
        view.requestFocus();
        view.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (keyCode == KeyEvent.KEYCODE_BACK && event.getAction() == KeyEvent.ACTION_DOWN) {
                    navigateToBack();
                    return true;
                }
                return false;
            }
        });
    }


    @Override
    public int getFragmentLayout() {
        return R.layout.fragment_configure_reminder;
    }

    @Override
    public void onFragmentReady() {
       /* if (WellnessCornerApp.getPreferenceManager().getLastUpdatedReminder() != null && WellnessCornerApp.getPreferenceManager().getLastUpdatedReminder().length() > 0) {
            ivAddHabit.setVisibility(View.VISIBLE);
        } else {
            ivAddHabit.setVisibility(View.INVISIBLE);
        }*/

        if (getArguments().containsKey("isRedirectFromMyHabit")) {
            ivAddHabit.setVisibility(View.INVISIBLE);
        }

        rvConfigureReminder.setHasFixedSize(true);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getActivity());
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        rvConfigureReminder.setLayoutManager(linearLayoutManager);

        adapter = new RecommendedConfigureReminderAdapter(getActivity(), habitReminderList);
        rvConfigureReminder.setAdapter(adapter);

        getHabitReminderApiCall();
    }

    private void navigateToBack() {
        getActivity().getFragmentManager().popBackStackImmediate();
    }

    @OnClick(R2.id.tvSave)
    public void onClickSaveReminder() {
        saveHabitReminderApiCall();
    }

    @OnClick(R2.id.ivBack)
    public void onBack() {
        navigateToBack();
    }

    @OnClick(R2.id.ivAddHabit)
    public void onClickAddHabit() {
        Bundle bundle = new Bundle();
        bundle.putBoolean("isAddHabit", true);
        Utils.replaceFragment(getFragmentManager(), RecommendedHealthyHabitsFragment.newInstance(bundle), RecommendedHealthyHabitsFragment.class.getSimpleName(), true, R.id.fragmentContainerReminder);
    }

    private void getHabitReminderApiCall() {

        BaseMemberIdBody baseMemberIdBody = new BaseMemberIdBody();
        baseMemberIdBody.setMemberID(ReminderConfig.reminderUser.getUserID());

        RestClient restClient = new RestClient(getActivity(), ReminderConfig.BASE_URL, ReminderConfig.DEBUG);
        restClient.getRecommendedService().getHabitReminder(baseMemberIdBody).enqueue(new Callback<HabitReminderResponse>() {
            @Override
            public void onResponse(Call<HabitReminderResponse> call, Response<HabitReminderResponse> response) {

                if (isAdded() && getActivity() != null) {

                    if (response != null && response.body() != null && response.body().getData() != null) {
                        if (response.body().getStatus() == 0) {
                            if (response.body().getData().size() > 0) {

                                habitReminderList.clear();
                                habitReminderList.addAll(response.body().getData());
                                for (HabitReminderBean item : habitReminderList) {
                                    sortHabitTimeItemList(item.getHabitReminder());
                                }

                                adapter.notifyDataSetChanged();

                            }

                        } else {
                            DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_response_failure), getString(R.string.str_ok), false);
                        }
                    } else {
                        DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_response_null), getString(R.string.str_ok), false);
                    }
                }
            }

            @Override
            public void onFailure(Call<HabitReminderResponse> call, Throwable t) {
                if (isAdded() && getActivity() != null) {

                    DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_failure), getString(R.string.str_ok), false);
                }
            }
        });
    }

    private void saveHabitReminderApiCall() {

        ArrayList<SaveHabitReminderBody.HabitItem> habitList = new ArrayList<>();

        for (HabitReminderBean bean : habitReminderList) {
            SaveHabitReminderBody.HabitItem item = new SaveHabitReminderBody.HabitItem();
            item.setHabitID(String.format("%d", bean.getHabitID()));
            item.setMemberId(ReminderConfig.reminderUser.getUserID());
            item.setReminderName(bean.getReminderName());
            item.setReminderText(bean.getReminderText());
            ArrayList<SaveHabitReminderBody.HabitItem.TimesBean> listTimes = new ArrayList<>();
            for (HabitReminderBean.HabitReminderItem habitReminderItem : bean.getHabitReminder()) {

                SaveHabitReminderBody.HabitItem.TimesBean timesBean = new SaveHabitReminderBody.HabitItem.TimesBean();
                timesBean.setTime(habitReminderItem.getTime());
                timesBean.setIsRemoved(habitReminderItem.isRemoved());

                if (habitReminderItem.isIsDisabled()) {
                    timesBean.setIsRemoved(1);
                }

                listTimes.add(timesBean);

            }
            item.setTimes(listTimes);
            habitList.add(item);
        }

        SaveHabitReminderBody saveHabitReminderBody = new SaveHabitReminderBody();
        saveHabitReminderBody.setData(habitList);

        RestClient restClient = new RestClient(getActivity(), ReminderConfig.BASE_URL, ReminderConfig.DEBUG);
        restClient.getRecommendedService().saveHabitReminder(saveHabitReminderBody).enqueue(new Callback<SaveHabitReminderResponse>() {
            @Override
            public void onResponse(Call<SaveHabitReminderResponse> call, Response<SaveHabitReminderResponse> response) {

                if (isAdded() && getActivity() != null) {

                    if (response != null && response.body() != null && response.body().getData() != null) {
                        if (response.body().getStatus() == 0) {
                            SharedPreferences mPrefs =ReminderConfig.mActivity.getSharedPreferences("thewellnesscorner",MODE_PRIVATE);

                            mPrefs.edit().putString("LastReminderUpdate",response.body().getData().getLastUpdateDate()).apply();
                         insertRemindersInDataBase();
                            getRemindersFromDatabase();
                           // Utils.setTimeChangeReceiverForHabit(getActivity());
                          //  Intent intent1 = new Intent(getActivity(), RemindersService.class);
                         /*   if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                getActivity().startForegroundService(intent1);
                            } else {
                                getActivity().startService(intent1);
                            }
*/
                            if (getArguments().getBoolean("isRedirectFromSelectHabit")) {
                                DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, "Reminder saved successfully", getString(R.string.str_ok), new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialogInterface, int i) {
                                        FragmentManager fragmentManager = getFragmentManager();
                                        Fragment fragment = (Fragment) fragmentManager.findFragmentByTag("RecommendedMyHabitsFragment");
                                        if (fragment != null && fragment instanceof RecommendedMyHabitsFragment) {
                                            getActivity().getFragmentManager().popBackStack(RecommendedHealthyHabitsFragment.class.getSimpleName(), FragmentManager.POP_BACK_STACK_INCLUSIVE);
                                        } else {
                                            dialogInterface.dismiss();
                                            getActivity().setResult(Activity.RESULT_OK);
                                            getActivity().finish();
                                        }


                                    }
                                }, false);

                            } else if (!getArguments().getBoolean("isRedirectFromSelectHabit")) {
                                DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, "Reminder saved successfully", getString(R.string.str_ok), new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialogInterface, int i) {
                                        getFragmentManager().popBackStack();
                                    }
                                }, false);

                            } else {
                                DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, "Reminder saved successfully", getString(R.string.str_ok), false);
                            }


                        } else {
                            DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_response_failure), getString(R.string.str_ok), false);
                        }
                    } else {
                        DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_response_null), getString(R.string.str_ok), false);
                    }
                }
            }

            @Override
            public void onFailure(Call<SaveHabitReminderResponse> call, Throwable t) {
                if (isAdded() && getActivity() != null) {

                    DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_failure), getString(R.string.str_ok), false);
                }
            }
        });
    }

    private void insertRemindersInDataBase() {


        ReminderItemDao dBDaoReminder = GreenDaoApp.getInstance(getActivity()).getDaoSession(getActivity()).getReminderItemDao();
        ReminderTimeItemDao dBDaoTime = GreenDaoApp.getInstance(getActivity()).getDaoSession(getActivity()).getReminderTimeItemDao();

        List<ReminderTimeItem> reminderTimeList = dBDaoTime.loadAll();
        for (ReminderTimeItem item : reminderTimeList) {
            Utils.cancelReminder(getActivity(), (int) (long) item.getId());
        }

        dBDaoReminder.deleteAll();
        dBDaoTime.deleteAll();
        RemindersDefault.getInstance(GreenDaoApp.getInstance(getActivity()).getDaoSession(getActivity())).loadDefaultValuesOfReminders();
        // insert  in database
        for (HabitReminderBean bean : habitReminderList) {

            boolean isDisabled = false;
            if (bean.getHabitReminder().size() > 0) {
                isDisabled = bean.getHabitReminder().get(0).isIsDisabled();
            }

            if (!isDisabled) {

                int rowId = RemindersDefault.getInstance(GreenDaoApp.getInstance(getActivity()).getDaoSession(getActivity())).insertRemindersData(bean.getHabitID(), bean.getReminderName(), bean.getReminderText(), "", true, false);

                for (HabitReminderBean.HabitReminderItem habitReminderItem : bean.getHabitReminder()) {
                    habitReminderItem.setLocallyAdded(false);
                    ReminderTimeItem reminderTimeItem = new ReminderTimeItem();
                    reminderTimeItem.setReminderId((long) rowId);
                    reminderTimeItem.setReminderType(bean.getReminderName());
                    reminderTimeItem.setUserId(ReminderConfig.reminderUser.getUserID());
                    reminderTimeItem.setReminderTime(habitReminderItem.getTime());
                    reminderTimeItem.setIsCustom(false);
                    reminderTimeItem.setIsActive(true);
                    if (habitReminderItem.isRemoved() == 0) {
                        dBDaoTime.insert(reminderTimeItem);
                    }
                }

            }
        }

    }

    private void sortHabitTimeItemList(List<HabitReminderBean.HabitReminderItem> habitReminderList) {

        Collections.sort(habitReminderList, new Comparator<HabitReminderBean.HabitReminderItem>() {
            public int compare(HabitReminderBean.HabitReminderItem obj1, HabitReminderBean.HabitReminderItem obj2) {
                try {
                    return new SimpleDateFormat("hh:mm a").parse(obj1.getTime()).compareTo(new SimpleDateFormat("hh:mm a").parse(obj2.getTime()));
                } catch (ParseException e) {
                    return 0;
                }

            }
        });
    }
    private void getRemindersFromDatabase() {
        AlarmManager alarmMgr = (AlarmManager) getActivity().getSystemService(Context.ALARM_SERVICE);
        ReminderItemDao reminderItemDao = GreenDaoApp.getInstance(getActivity()).getDaoSession(getActivity()).getReminderItemDao();
        ReminderTimeItemDao reminderTimeItemDao = GreenDaoApp.getInstance(getActivity()).getDaoSession(getActivity()).getReminderTimeItemDao();
        List<ReminderItem> reminderItems = reminderItemDao.loadAll();
        for (int i = 0; i < reminderItems.size(); i++) {
            List<ReminderTimeItem> reminderTimeItems = reminderTimeItemDao.queryBuilder().where(ReminderTimeItemDao.Properties.ReminderId.eq(reminderItems.get(i).getId())).list();
            String title = reminderItems.get(i).getReminderText();
            for (int k = 0; k < reminderTimeItems.size(); k++) {
                if (reminderItems.get(i).getIsActive() && reminderTimeItems.get(k).getIsActive()) {
                    //String title = reminderTimeItems.get(k).getReminderType();
                    if (reminderTimeItems.get(k).getReminderTime() != null && !reminderTimeItems.get(k).getReminderTime().isEmpty()) {

                        NotificationScheduler.setNotificationAlarm(getActivity(),alarmMgr,(int) (long) reminderTimeItems.get(k).getId(), title, "", reminderTimeItems.get(k).getReminderTime());
                    }

                }
            }
        }

    }
}
