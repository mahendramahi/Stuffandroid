package com.truworth.wellnesscorner.ui.mainapp.post;

import android.databinding.ObservableBoolean;
import android.databinding.ObservableField;
import android.databinding.ObservableInt;
import android.view.View;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.truworth.wellnesscorner.TheWellnessCornerApp;
import com.truworth.wellnesscorner.base.BaseViewModel;
import com.truworth.wellnesscorner.model.EventBean;
import com.truworth.wellnesscorner.repo.DashboardRepository;
import com.truworth.wellnesscorner.repo.model.request.EventCheckInRequest;
import com.truworth.wellnesscorner.repo.model.response.EventCheckInResponse;
import com.truworth.wellnesscorner.utils.DateUtils;

import javax.inject.Inject;

import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;

public class EventViewModel extends BaseViewModel {
    public final ObservableBoolean optionGoing = new ObservableBoolean();
    public final ObservableBoolean optionNotGoing = new ObservableBoolean();
    public final ObservableBoolean optionMaybe = new ObservableBoolean();
    public ObservableInt peoples = new ObservableInt();
    public ObservableField<String> errorMessage = new ObservableField<>();
    public ObservableField<String> totalMembersGoing = new ObservableField<>();
    public ObservableField<String> personImage1 = new ObservableField<>();
    public ObservableField<String> personImage2 = new ObservableField<>();
    public ObservableField<String> personImage3 = new ObservableField<>();
    public UpdateEventClickListener eventClickListener;
    EventBean event;
    @Inject
    DashboardRepository dashboardRepository;
    private String circleIdentity;

    public EventViewModel(EventBean event, UpdateEventClickListener eventClickListener) {
        this.event = event;
        this.eventClickListener = eventClickListener;
        setEventOption();
        setPeopleImage();
        TheWellnessCornerApp.getApp().component().inject(this);
    }

    private void setPeopleImage() {
        this.personImage1.set(getMemberImage(0));
        this.personImage2.set(getMemberImage(1));
        this.personImage3.set(getMemberImage(2));
        this.totalMembersGoing.set(String.valueOf(event.getTotalMembersGoing()));
    }

    public EventBean getEvent() {
        return event;
    }

    public void setEvent(EventBean event) {
        this.event = event;
    }

    private void setEventOption() {
        if (event.getMyStatus() != null) {
            if (event.getMyStatus().equals("Y")) {
                optionGoing.set(true);
            } else if (event.getMyStatus().equals("N")) {
                optionNotGoing.set(true);
            } else if (event.getMyStatus().equals("M")) {
                optionMaybe.set(true);
            }
            peoples.set(event.getTotalMembersGoing());
        }
    }

    public String getMemberImage(int index) {
        if (event.getMemberImages() != null)
            if (event.getMemberImages().size() > index)
                return event.getMemberImages().get(index).getImageName();
        return "";
    }

    public String getEventDate() {
        return DateUtils.getInstance().getFormattedDateForEvent(DateUtils.getDate(event.getEventStartDate(), DateUtils.SERVER_DATE).getTime());
    }

    public void onEventOptionChanged(RadioGroup radioGroup, int id) {

    }

    public void setPeopleCount(String option) {
        if (option.equals("Y")) {
            peoples.set(peoples.get() + 1);
        } else if (option.equals("N")) {
            peoples.set(peoples.get() - 1);
        } else if (option.equals("M")) {
            peoples.set(peoples.get() + 1);
        }
    }

    public void checkinApiCall(View view, String option) {
        event.setMyStatus(option);
        EventCheckInRequest checkInRequest = new EventCheckInRequest();
        checkInRequest.setId(event.getEventIdentity());
        checkInRequest.setMyStatus(option);
        checkInRequest.setCircleId(circleIdentity);
        dashboardRepository.getEventCheckIn(checkInRequest).subscribe(new Observer<EventCheckInResponse>() {
            @Override
            public void onSubscribe(Disposable d) {

            }

            @Override
            public void onNext(EventCheckInResponse checkInResponse) {
                if (!checkInResponse.isHasError()) {
                    if (checkInResponse.getData() != null) {
                        if (checkInResponse.getData().getEventData() != null) {
                            if (checkInResponse.getData().getEventData().getMemberImages() != null && checkInResponse.getData().getEventData().getMemberImages().size() > 0) {
                                event.setMemberImages(checkInResponse.getData().getEventData().getMemberImages());
                            }
                            event.setTotalMembersGoing(checkInResponse.getData().getEventData().getTotalMembersGoing());
                            peoples.set(event.getTotalMembersGoing());
                            setPeopleImage();
                        }
                        if (checkInResponse.getData().getStatus() == 1) {
                            eventClickListener.updateEvent();
                            //  setPeopleCount(option);
                        } else
                            Toast.makeText(view.getContext(), checkInResponse.getData().getMessage(), Toast.LENGTH_SHORT).show();

                    }
                } else {
                    errorMessage.set(checkInResponse.getError().getMessage());
                }
            }

            @Override
            public void onError(Throwable e) {

            }

            @Override
            public void onComplete() {

            }
        });
    }

    public void setCircleIdentity(String circleIdentity) {
        this.circleIdentity = circleIdentity;
    }

    public interface UpdateEventClickListener {
        void updateEvent();
    }
}
