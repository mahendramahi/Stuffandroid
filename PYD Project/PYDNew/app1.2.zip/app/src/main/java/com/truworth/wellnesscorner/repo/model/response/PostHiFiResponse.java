package com.truworth.wellnesscorner.repo.model.response;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.truworth.wellnesscorner.model.PostHiFiData;

public class PostHiFiResponse {
    @SerializedName("data")
    @Expose
    private PostHiFiData data;
    @SerializedName("hasError")
    @Expose
    private Boolean hasError;
    @SerializedName("error")
    @Expose
    private Error error;

    public PostHiFiData getData() {
        return data;
    }

    public void setData(PostHiFiData data) {
        this.data = data;
    }

    public Boolean getHasError() {
        return hasError;
    }

    public void setHasError(Boolean hasError) {
        this.hasError = hasError;
    }

    public Error getError() {
        return error;
    }

    public void setError(Error error) {
        this.error = error;
    }
}
