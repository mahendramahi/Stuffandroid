package com.twc.store.model.beans;

/**
 * Created by PalakC on 9/18/2017.
 */

public class SaveItem {

    private int TotalItems;
    private int ProgramIn;
    private String ProcMessage;

    public int getTotalItems() {
        return TotalItems;
    }

    public void setTotalItems(int TotalItems) {
        this.TotalItems = TotalItems;
    }

    public int getProgramIn() {
        return ProgramIn;
    }

    public void setProgramIn(int ProgramIn) {
        this.ProgramIn = ProgramIn;
    }

    public String getProcMessage() {
        return ProcMessage;
    }

    public void setProcMessage(String ProcMessage) {
        this.ProcMessage = ProcMessage;
    }

}
