package com.twc.remindermodule;

import android.app.Activity;
import android.app.AlarmManager;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import com.twc.greendaolib.GreenDaoApp;
import com.twc.greendaolib.ReminderItem;
import com.twc.greendaolib.ReminderItemDao;
import com.twc.greendaolib.ReminderTimeItem;
import com.twc.greendaolib.ReminderTimeItemDao;
import com.twc.remindermodule.fragments.NotificationScheduler;
import com.twc.remindermodule.model.beans.HabitReminderBean;
import com.twc.remindermodule.model.requestbody.BaseMemberIdBody;
import com.twc.remindermodule.model.response.HabitReminderResponse;
import com.twc.remindermodule.rest.ReminderConfig;
import com.twc.remindermodule.rest.RestClient;
import com.twc.remindermodule.service.RemindersService;
import com.twc.remindermodule.utils.RemindersDefault;
import com.twc.remindermodule.utils.Utils;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ReminderHelper {
    private ArrayList<HabitReminderBean> habitReminderList;
    Activity mActivity;

    public ReminderHelper(Activity activity){
        mActivity=activity;
    }

    public void getHabitReminderApiCall() {

        habitReminderList = new ArrayList<>();
        BaseMemberIdBody baseMemberIdBody = new BaseMemberIdBody();

        RestClient restClient = new RestClient(mActivity, ReminderConfig.BASE_URL, ReminderConfig.DEBUG);
        restClient.getRecommendedService().getHabitReminder(baseMemberIdBody).enqueue(new Callback<HabitReminderResponse>() {
            @Override
            public void onResponse(Call<HabitReminderResponse> call, Response<HabitReminderResponse> response) {

                if (mActivity!= null) {

                    if (response != null && response.body() != null && response.body().getData() != null) {
                        if (response.body().getStatus() == 0) {
                            if (response.body().getData().size() > 0) {

                                habitReminderList.clear();
                                habitReminderList.addAll(response.body().getData());
                                insertRemindersInDataBase();
                                getRemindersFromDatabase();

                            }

                        } else {

                        }
                    } else {

                    }
                }
            }

            @Override
            public void onFailure(Call<HabitReminderResponse> call, Throwable t) {

            }
        });
    }

    public void insertRemindersInDataBase() {
        ReminderItemDao dBDaoReminder = GreenDaoApp.getInstance(mActivity).getDaoSession(mActivity).getReminderItemDao();
        ReminderTimeItemDao dBDaoTime = GreenDaoApp.getInstance(mActivity).getDaoSession(mActivity).getReminderTimeItemDao();

        List<ReminderTimeItem> reminderTimeList = dBDaoTime.loadAll();
        for (ReminderTimeItem item : reminderTimeList) {
            Utils.cancelReminder(mActivity, (int) (long) item.getId());
        }

        dBDaoReminder.deleteAll();
        dBDaoTime.deleteAll();
        RemindersDefault.getInstance(GreenDaoApp.getInstance(mActivity).getDaoSession(mActivity)).loadDefaultValuesOfReminders();
        // insert  in database
        for (HabitReminderBean bean : habitReminderList) {
            boolean isDisabled = false;
            if (bean.getHabitReminder().size() > 0) {
                isDisabled = bean.getHabitReminder().get(0).isIsDisabled();
            }

            if (!isDisabled) {
                int rowId = RemindersDefault.getInstance(GreenDaoApp.getInstance(mActivity).getDaoSession(mActivity)).insertRemindersData(bean.getHabitID(), bean.getReminderName(), bean.getReminderText(), "", true, false);
                for (HabitReminderBean.HabitReminderItem habitReminderItem : bean.getHabitReminder()) {
                    ReminderTimeItem reminderTimeItem = new ReminderTimeItem();
                    reminderTimeItem.setReminderId((long) rowId);
                    reminderTimeItem.setReminderType(bean.getReminderName());
                    // reminderTimeItem.setUserId(WellnessCornerApp.getPreferenceManager().getUserId());
                    reminderTimeItem.setReminderTime(habitReminderItem.getTime());
                    reminderTimeItem.setIsCustom(false);
                    reminderTimeItem.setIsActive(true);
                    if (habitReminderItem.isRemoved() == 0) {
                        dBDaoTime.insert(reminderTimeItem);
                    }
                }
            }
        }
    }
    private void getRemindersFromDatabase() {
        AlarmManager alarmMgr = (AlarmManager) mActivity.getSystemService(Context.ALARM_SERVICE);
        ReminderItemDao reminderItemDao = GreenDaoApp.getInstance(mActivity).getDaoSession(mActivity).getReminderItemDao();
        ReminderTimeItemDao reminderTimeItemDao = GreenDaoApp.getInstance(mActivity).getDaoSession(mActivity).getReminderTimeItemDao();
        List<ReminderItem> reminderItems = reminderItemDao.loadAll();
        for (int i = 0; i < reminderItems.size(); i++) {
            List<ReminderTimeItem> reminderTimeItems = reminderTimeItemDao.queryBuilder().where(ReminderTimeItemDao.Properties.ReminderId.eq(reminderItems.get(i).getId())).list();
            String title = reminderItems.get(i).getReminderText();
            for (int k = 0; k < reminderTimeItems.size(); k++) {
                if (reminderItems.get(i).getIsActive() && reminderTimeItems.get(k).getIsActive()) {
                    //String title = reminderTimeItems.get(k).getReminderType();
                    if (reminderTimeItems.get(k).getReminderTime() != null && !reminderTimeItems.get(k).getReminderTime().isEmpty()) {

                        NotificationScheduler.setNotificationAlarm(mActivity,alarmMgr,(int) (long) reminderTimeItems.get(k).getId(), title, "", reminderTimeItems.get(k).getReminderTime());
                    }

                }
            }
        }

    }
}
