package com.truworth.wellnesscorner.repo.model.request;

public class ShareMealRequest {

    private int pageIndex;

    public int getPageIndex() {
        return pageIndex;
    }

    public void setPageIndex(int pageIndex) {
        this.pageIndex = pageIndex;
    }
}
