package com.twc.dailylog.model.response;

import com.twc.dailylog.model.beans.WeightLogItem;

import java.util.List;

public class WeightLogResponse {

    private int status;
    /**
     * Date : 2016-07-11T17:56:37.49
     * Reading : 80
     * WeightUnit : Kg
     */

    private List<WeightLogItem> data;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public List<WeightLogItem> getData() {
        return data;
    }

    public void setData(List<WeightLogItem> data) {
        this.data = data;
    }

}
