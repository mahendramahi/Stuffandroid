package com.twc.hramodule.utils;

import android.app.FragmentManager;
import android.os.Bundle;


import com.twc.greendaolib.HraDBItem;
import com.twc.greendaolib.HraDBItemDao;
import com.twc.hramodule.R;
import com.twc.hramodule.fragments.HraQ10And11Fragment;
import com.twc.hramodule.fragments.HraQ12Fragment;
import com.twc.hramodule.fragments.HraQ13Fragment;
import com.twc.hramodule.fragments.HraQ14Fragment;
import com.twc.hramodule.fragments.HraQ15NewFragment;
import com.twc.hramodule.fragments.HraQ16NewFragment;
import com.twc.hramodule.fragments.HraQ17Fragment;
import com.twc.hramodule.fragments.HraQ18Fragment;
import com.twc.hramodule.fragments.HraQ19Fragment;
import com.twc.hramodule.fragments.HraQ1Fragment;
import com.twc.hramodule.fragments.HraQ20And21Fragment;
import com.twc.hramodule.fragments.HraQ22Fragment;
import com.twc.hramodule.fragments.HraQ23Fragment;
import com.twc.hramodule.fragments.HraQ23IGaveUpFragment;
import com.twc.hramodule.fragments.HraQ23YesFragment;
import com.twc.hramodule.fragments.HraQ24Fragment;
import com.twc.hramodule.fragments.HraQ25And26Fragment;
import com.twc.hramodule.fragments.HraQ27And28Fragment;
import com.twc.hramodule.fragments.HraQ29Fragment;
import com.twc.hramodule.fragments.HraQ2NewFragment;
import com.twc.hramodule.fragments.HraQ30Fragment;
import com.twc.hramodule.fragments.HraQ31Fragment;
import com.twc.hramodule.fragments.HraQ3NewFragment;
import com.twc.hramodule.fragments.HraQ4Fragment;
import com.twc.hramodule.fragments.HraQ5Fragment;
import com.twc.hramodule.fragments.HraQ6Fragment;
import com.twc.hramodule.fragments.HraQ7Fragment;
import com.twc.hramodule.fragments.HraQ8And9Fragment;

import java.util.List;

/**
 * Created by ManishJ1 on 12/23/2016.
 */

public class HRARedirectionUtils {

    private static HRARedirectionUtils hraRedirectionUtils;

    public static HRARedirectionUtils getInstance() {
        if (hraRedirectionUtils == null)
            hraRedirectionUtils = new HRARedirectionUtils();
        return hraRedirectionUtils;
    }

    public void navigateToHRAQuestionScreen(Bundle bundle, FragmentManager fragmentManager,HraDBItemDao hraDBDao) {
        String screenNo;
        List<HraDBItem> answerFromDb = hraDBDao.queryBuilder().orderDesc(HraDBItemDao.Properties.ScreeNo).limit(1).list();
        if (answerFromDb.size() == 0) {

            Utils.replaceFragmentWithoutAnimation(fragmentManager, HraQ1Fragment.newInstance(bundle), HraQ1Fragment.class.getSimpleName(), true, R.id.fragmentContainerHra);
        } else if (answerFromDb.size() > 0) {
            screenNo = String.valueOf(answerFromDb.get(0).getScreeNo());
            if (screenNo.equalsIgnoreCase("1.0")) {
                Utils.replaceFragmentWithoutAnimation(fragmentManager, HraQ2NewFragment.newInstance(bundle), HraQ2NewFragment.class.getSimpleName(), true, R.id.fragmentContainerHra);
            } else if (screenNo.equalsIgnoreCase("2.0")) {
                Utils.replaceFragmentWithoutAnimation(fragmentManager, HraQ3NewFragment.newInstance(bundle), HraQ3NewFragment.class.getSimpleName(), true, R.id.fragmentContainerHra);
            } else if (screenNo.equalsIgnoreCase("3.0")) {
                Utils.replaceFragmentWithoutAnimation(fragmentManager, HraQ4Fragment.newInstance(bundle), HraQ4Fragment.class.getSimpleName(), true, R.id.fragmentContainerHra);
            } else if (screenNo.equalsIgnoreCase("4.0")) {
                Utils.replaceFragmentWithoutAnimation(fragmentManager, HraQ5Fragment.newInstance(bundle), HraQ5Fragment.class.getSimpleName(), true, R.id.fragmentContainerHra);
            } else if (screenNo.equalsIgnoreCase("5.0")) {
                Utils.replaceFragmentWithoutAnimation(fragmentManager, HraQ6Fragment.newInstance(bundle), HraQ6Fragment.class.getSimpleName(), true, R.id.fragmentContainerHra);
            } else if (screenNo.equalsIgnoreCase("6.0")) {
                Utils.replaceFragmentWithoutAnimation(fragmentManager, HraQ7Fragment.newInstance(bundle), HraQ7Fragment.class.getSimpleName(), true, R.id.fragmentContainerHra);
            } else if (screenNo.equalsIgnoreCase("7.0")) {
                Utils.replaceFragmentWithoutAnimation(fragmentManager, HraQ8And9Fragment.newInstance(bundle), HraQ8And9Fragment.class.getSimpleName(), true, R.id.fragmentContainerHra);
            } else if (screenNo.equalsIgnoreCase("8.0")) {
                Utils.replaceFragmentWithoutAnimation(fragmentManager, HraQ10And11Fragment.newInstance(bundle), HraQ10And11Fragment.class.getSimpleName(), true, R.id.fragmentContainerHra);
            } else if (screenNo.equalsIgnoreCase("9.0")) {
                Utils.replaceFragmentWithoutAnimation(fragmentManager, HraQ12Fragment.newInstance(bundle), HraQ12Fragment.class.getSimpleName(), true, R.id.fragmentContainerHra);
            } else if (screenNo.equalsIgnoreCase("10.0")) {
                Utils.replaceFragmentWithoutAnimation(fragmentManager, HraQ13Fragment.newInstance(bundle), HraQ13Fragment.class.getSimpleName(), true, R.id.fragmentContainerHra);
            } else if (screenNo.equalsIgnoreCase("11.0")) {
                Utils.replaceFragmentWithoutAnimation(fragmentManager, HraQ14Fragment.newInstance(bundle), HraQ14Fragment.class.getSimpleName(), true, R.id.fragmentContainerHra);
            } else if (screenNo.equalsIgnoreCase("12.0")) {
                Utils.replaceFragmentWithoutAnimation(fragmentManager, HraQ15NewFragment.newInstance(bundle), HraQ15NewFragment.class.getSimpleName(), true, R.id.fragmentContainerHra);
            } else if (screenNo.equalsIgnoreCase("13.0")) {
                Utils.replaceFragmentWithoutAnimation(fragmentManager, HraQ16NewFragment.newInstance(bundle), HraQ16NewFragment.class.getSimpleName(), true, R.id.fragmentContainerHra);
            } else if (screenNo.equalsIgnoreCase("14.0")) {
                Utils.replaceFragmentWithoutAnimation(fragmentManager, HraQ17Fragment.newInstance(bundle), HraQ17Fragment.class.getSimpleName(), true, R.id.fragmentContainerHra);
            } else if (screenNo.equalsIgnoreCase("15.0")) {
                Utils.replaceFragmentWithoutAnimation(fragmentManager, HraQ18Fragment.newInstance(bundle), HraQ18Fragment.class.getSimpleName(), true, R.id.fragmentContainerHra);
            } else if (screenNo.equalsIgnoreCase("16.0")) {
                Utils.replaceFragmentWithoutAnimation(fragmentManager, HraQ19Fragment.newInstance(bundle), HraQ19Fragment.class.getSimpleName(), true, R.id.fragmentContainerHra);
            } else if (screenNo.equalsIgnoreCase("17.0")) {
                Utils.replaceFragmentWithoutAnimation(fragmentManager, HraQ20And21Fragment.newInstance(bundle), HraQ20And21Fragment.class.getSimpleName(), true, R.id.fragmentContainerHra);
            } else if (screenNo.equalsIgnoreCase("18.0")) {
                Utils.replaceFragmentWithoutAnimation(fragmentManager, HraQ22Fragment.newInstance(bundle), HraQ22Fragment.class.getSimpleName(), true, R.id.fragmentContainerHra);
            } else if (screenNo.equalsIgnoreCase("19.0")) {
                Utils.replaceFragmentWithoutAnimation(fragmentManager, HraQ23Fragment.newInstance(bundle), HraQ23Fragment.class.getSimpleName(), true, R.id.fragmentContainerHra);
            } else if (screenNo.equalsIgnoreCase("20.0")) {

                if (answerFromDb.get(0).getAnswer().equalsIgnoreCase("-1")) {
                    Utils.replaceFragmentWithoutAnimation(fragmentManager, HraQ23YesFragment.newInstance(bundle), HraQ23YesFragment.class.getSimpleName(), true, R.id.fragmentContainerHra);
                } else if (answerFromDb.get(0).getAnswer().equalsIgnoreCase("-2")) {
                    Utils.replaceFragmentWithoutAnimation(fragmentManager, HraQ23IGaveUpFragment.newInstance(bundle), HraQ23IGaveUpFragment.class.getSimpleName(), true, R.id.fragmentContainerHra);
                } else {
                    Utils.replaceFragmentWithoutAnimation(fragmentManager, HraQ24Fragment.newInstance(bundle), HraQ24Fragment.class.getSimpleName(), true, R.id.fragmentContainerHra);
                }
            } else if (screenNo.equalsIgnoreCase("20.1")) {
                Utils.replaceFragmentWithoutAnimation(fragmentManager, HraQ24Fragment.newInstance(bundle), HraQ24Fragment.class.getSimpleName(), true, R.id.fragmentContainerHra);

            } else if (screenNo.equalsIgnoreCase("20.2")) {
                Utils.replaceFragmentWithoutAnimation(fragmentManager, HraQ24Fragment.newInstance(bundle), HraQ24Fragment.class.getSimpleName(), true, R.id.fragmentContainerHra);

            } else if (screenNo.equalsIgnoreCase("21.0")) {
                Utils.replaceFragmentWithoutAnimation(fragmentManager, HraQ25And26Fragment.newInstance(bundle), HraQ25And26Fragment.class.getSimpleName(), true, R.id.fragmentContainerHra);
            } else if (screenNo.equalsIgnoreCase("22.0")) {
                Utils.replaceFragmentWithoutAnimation(fragmentManager, HraQ27And28Fragment.newInstance(bundle), HraQ27And28Fragment.class.getSimpleName(), true, R.id.fragmentContainerHra);
            } else if (screenNo.equalsIgnoreCase("23.0")) {
                if (answerFromDb.get(0).getAnswer().equalsIgnoreCase("0")) {
                    if ( HraConfig.hraUser.getGender().equalsIgnoreCase("Male")) {
                        Utils.replaceFragmentWithoutAnimation(fragmentManager, HraQ30Fragment.newInstance(bundle), HraQ30Fragment.class.getSimpleName(), true, R.id.fragmentContainerHra);
                    } else {
                        Utils.replaceFragmentWithoutAnimation(fragmentManager, HraQ31Fragment.newInstance(bundle), HraQ31Fragment.class.getSimpleName(), true, R.id.fragmentContainerHra);
                    }
                } else {
                    Utils.replaceFragmentWithoutAnimation(fragmentManager, HraQ29Fragment.newInstance(bundle), HraQ29Fragment.class.getSimpleName(), true, R.id.fragmentContainerHra);
                }
            } else if (screenNo.equalsIgnoreCase("24.0")) {
                Utils.replaceFragmentWithoutAnimation(fragmentManager, HraQ30Fragment.newInstance(bundle), HraQ30Fragment.class.getSimpleName(), true, R.id.fragmentContainerHra);
            } else if (screenNo.equalsIgnoreCase("25.0")) {
                    Utils.replaceFragmentWithoutAnimation(fragmentManager, HraQ31Fragment.newInstance(bundle), HraQ31Fragment.class.getSimpleName(), true, R.id.fragmentContainerHra);
            } else if (screenNo.equalsIgnoreCase("26.0")) {
                Utils.replaceFragmentWithoutAnimation(fragmentManager, HraQ1Fragment.newInstance(bundle), HraQ1Fragment.class.getSimpleName(), true, R.id.fragmentContainerHra);
            }
        }

    }
}
