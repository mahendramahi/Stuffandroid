package com.twc.store;

import android.app.Fragment;
import android.app.FragmentManager;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.TextView;

import com.twc.store.fragments.StoreMemberAddressFragment;
import com.twc.store.fragments.StoreProductDetailFragment;
import com.twc.store.utils.Utils;

public class StoreDetailActivity extends AppCompatActivity {
    public Toolbar mToolbar;

    private TextView tvToolbarTitle;
    private int productId;
    private String sku, tag;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setupToolbar();

        new GlideConfig().glideSetupDetail(this);
        new BillingAddressConfig().setBillingConfigDetail(this);

        Bundle bundle = getIntent().getExtras();
        if (bundle != null) {
            productId = bundle.getInt("productId");
            sku = bundle.getString("sku");
            tag = bundle.getString("tag");
        }
        StoreProductDetailFragment storeProductDetailFragment = StoreProductDetailFragment.newInstance(productId, sku, tag);
        Utils.replaceFragmentWithoutAnimation(getFragmentManager(), storeProductDetailFragment, StoreProductDetailFragment.class.getSimpleName(), true, com.twc.store.R.id.fragmentContainer);
    }

    private void setupToolbar() {
        mToolbar = findViewById(R.id.toolbar);
        tvToolbarTitle = findViewById(R.id.tbTitle);
        // ivMenuExpertImage = findViewById(R.id.ivMenuExpertImage);
        setSupportActionBar(mToolbar);
        mToolbar.setNavigationIcon(R.drawable.ic_arrow_left_white_24dp);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
    }

    public void setToolBarTitle(String toolBarTitle) {
        tvToolbarTitle.setText(toolBarTitle);
        assert getSupportActionBar() != null;
        getSupportActionBar().show();
    }

    public void showHomeAsUpEnableToolbar() {

        mToolbar.setNavigationIcon(R.drawable.ic_arrow_left_white_24dp);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }


        mToolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int count = getFragmentManager().getBackStackEntryCount();
                //1 == HomeFragment
                if (count == 1) {
                    finish();
                } else {
                    getFragmentManager().popBackStackImmediate();
                }

            }
        });
    }

    @Override
    public void onBackPressed() {
        int count = getFragmentManager().getBackStackEntryCount();
        //1 == HomeFragment
        if (count == 1) {
            finish();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (getCurrentFragmentName(StoreMemberAddressFragment.class.getSimpleName())) {
            Fragment fragment = getFragmentManager().findFragmentByTag(StoreMemberAddressFragment.class.getSimpleName());
            if (fragment != null) {
                fragment.onActivityResult(requestCode, resultCode, data);
            }
        }
    }

    private boolean getCurrentFragmentName(String fragmentName) {
        FragmentManager fragmentManager = getFragmentManager();
        if (fragmentManager.findFragmentByTag(fragmentName) != null) {
            String fragmentTag = fragmentManager.getBackStackEntryAt(fragmentManager.getBackStackEntryCount() - 1).getName();
            return fragmentTag.equalsIgnoreCase(fragmentName);
        } else
            return false;
    }
}
