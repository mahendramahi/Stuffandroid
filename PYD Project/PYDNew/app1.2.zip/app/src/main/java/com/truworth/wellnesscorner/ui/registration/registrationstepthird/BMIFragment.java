package com.truworth.wellnesscorner.ui.registration.registrationstepthird;

import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.truworth.wellnesscorner.BR;
import com.truworth.wellnesscorner.R;
import com.truworth.wellnesscorner.base.BaseFragment;
import com.truworth.wellnesscorner.databinding.FragmentBmiResultBinding;
import com.truworth.wellnesscorner.model.BMIData;
import com.truworth.wellnesscorner.ui.registration.RegistrationActivity;
import com.truworth.wellnesscorner.ui.registration.registrationstepfourth.LocationDetectFragment;
import com.truworth.wellnesscorner.utils.Utils;


public class BMIFragment extends BaseFragment<FragmentBmiResultBinding, BMIViewModel> {
    public static final String TAG = "BMIFragment";
    private static final String ARG_BMI_DATA = "bmiData";

    FragmentBmiResultBinding binding;
    BMIViewModel viewModel;
    BMIData bmiData;

    public BMIFragment() {
        // Required empty public constructor
    }

    public static Fragment newInstance(BMIData bmiData) {
        BMIFragment fragment = new BMIFragment();
        Bundle args = new Bundle();
        args.putSerializable(ARG_BMI_DATA, bmiData);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            bmiData = (BMIData) getArguments().getSerializable(ARG_BMI_DATA);
        }
    }

    @Override
    public void onStart() {
        super.onStart();
    }

    @Override
    public void onViewStateRestored(@Nullable Bundle savedInstanceState) {
        super.onViewStateRestored(savedInstanceState);
        if (bmiData != null) {
            ((RegistrationActivity) getActivity()).getToolbar().setBackgroundColor(Color.parseColor(bmiData.getColorCode()));
        }
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return super.onCreateView(inflater, container, savedInstanceState);
    }

    @Override
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        binding = getViewDataBinding();
        viewModel.setBmiData(bmiData);
        setUpObserver();
        openBmiCalculating();
        setBodyWeightDec();
        setBodyWeightDecinfo();
        ((RegistrationActivity) getActivity()).getToolbar().setBackgroundColor(Color.parseColor(bmiData.getColorCode()));
    }

    @Override
    public void onResume() {
        super.onResume();
        ((RegistrationActivity) getActivity()).getToolbar().setBackgroundColor(Color.parseColor(bmiData.getColorCode()));
    }

    private void setBodyWeightDecinfo() {
        viewModel.getOnibwDescriptionInfo().observe(this, new Observer<String>() {
            @Override
            public void onChanged(@Nullable String s) {
                binding.tvBodyWeightDesc.append(Utils.fromHtml("<u><b>" + s + "</u></b>"));
            }
        });
    }

    private void setBodyWeightDec() {
        viewModel.getOnibwDescription().observe(this, new Observer<String>() {
            @Override
            public void onChanged(@Nullable String s) {
                binding.tvBodyWeightDesc.setText(s);
            }
        });
    }

    private void openBmiCalculating() {
        viewModel.getOnClickBmiCalculating().observe(this, new Observer<Void>() {
            @Override
            public void onChanged(@Nullable Void aVoid) {
                getFragmentManager().popBackStackImmediate();
            }
        });
    }

    private void setUpObserver() {

        viewModel.getOnClickContinue().observe(this, new Observer<Void>() {
            @Override
            public void onChanged(@Nullable Void aVoid) {
                openLocationFragment();
            }
        });

        viewModel.getOnBmiLoaded().observe(this, new Observer<String>() {
            @Override
            public void onChanged(@Nullable String s) {
                ((RegistrationActivity) getActivity()).getToolbar().setBackgroundColor(Color.parseColor(s));
                //check from the background color
                if (!(s.equalsIgnoreCase("#f9e485"))) {
                    ((RegistrationActivity) getActivity()).getToolbar().setNavigationIcon(R.drawable.ic_arrow_left_white_24dp);
                } else {
                    ((RegistrationActivity) getActivity()).getToolbar().setNavigationIcon(R.drawable.arrow_back);
                }

            }
        });
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

    }

    @Override
    public int getBindingVariable() {
        return BR.viewModel;
    }

    @Override
    public int getLayoutId() {
        return R.layout.fragment_bmi_result;
    }

    @Override
    public BMIViewModel getViewModel() {
        viewModel = ViewModelProviders.of(this).get(BMIViewModel.class);
        return viewModel;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

    }

    @Override
    public void onDetach() {
        super.onDetach();

    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        ((RegistrationActivity) getActivity()).getToolbar().setBackgroundColor(Color.parseColor("#FFFFFF"));
        ((RegistrationActivity) getActivity()).getToolbar().setNavigationIcon(R.drawable.arrow_back);
    }

    public void openLocationFragment() {

        //FragmentUtils.removeAllFragmentFromStack((AppCompatActivity) getActivity());

        getActivity().getSupportFragmentManager().beginTransaction().replace(R.id.registerContainer, LocationDetectFragment.newInstance(), LocationDetectFragment.TAG).addToBackStack(LocationDetectFragment.TAG).commit();
    }
}
