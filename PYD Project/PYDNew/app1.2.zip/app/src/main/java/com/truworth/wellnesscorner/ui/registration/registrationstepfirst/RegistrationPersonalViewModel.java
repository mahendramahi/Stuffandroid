package com.truworth.wellnesscorner.ui.registration.registrationstepfirst;

import android.databinding.ObservableBoolean;
import android.databinding.ObservableField;
import android.text.Editable;
import android.text.TextWatcher;

import com.truworth.wellnesscorner.base.BaseViewModel;
import com.truworth.wellnesscorner.utils.SingleLiveEvent;

/**
 * If this code works, it was written by Somesh Kumar  on 03 April, 2018. If not, I don't know who wrote it.
 */
public class RegistrationPersonalViewModel extends BaseViewModel {

    private ObservableField<String> firstName = new ObservableField<>();
    private ObservableField<String> lastName = new ObservableField<>();
    private ObservableField<String> dob = new ObservableField<>();
    private ObservableField<String> gender = new ObservableField<>();
    public ObservableBoolean isFirstNameFilled = new ObservableBoolean();
    public ObservableBoolean isLastNameFilled = new ObservableBoolean();


    public ObservableField<String> getEmail() {
        return email;
    }

    private ObservableField<String> email = new ObservableField<>();


    private SingleLiveEvent<Void> openDateDialog = new SingleLiveEvent<>();


    private SingleLiveEvent<Void> moveToOpenPassword = new SingleLiveEvent<>();


    public SingleLiveEvent<Void> getOpenDateDialog() {
        return openDateDialog;
    }

    public RegistrationPersonalViewModel() {

    }

    public void setDob(ObservableField<String> dob) {
        this.dob = dob;
    }

    public ObservableField<String> getFirstName() {
        return firstName;
    }

    public ObservableField<String> getLastName() {
        return lastName;
    }

    public ObservableField<String> getDob() {
        return dob;
    }

    public ObservableField<String> getGender() {
        return gender;
    }

    public SingleLiveEvent<Void> getMoveToOpenPassword() {
        return moveToOpenPassword;
    }

    public void onClickDate() {
        openDateDialog.call();
    }

    public void moveToCreatePassword() {
        moveToOpenPassword.call();
    }

    public TextWatcher firstNameWatcher() {
        return new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if (firstName.get().trim().isEmpty())
                    isFirstNameFilled.set(false);
                else
                    isFirstNameFilled.set(true);
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        };
    }

    public TextWatcher LastNameWatcher() {
        return new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if (lastName.get().trim().isEmpty())
                    isLastNameFilled.set(false);
                else
                    isLastNameFilled.set(true);

            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        };
    }

    public void onCrossIconClickFirst() {
        if (isFirstNameFilled.get()) {
            firstName.set("");
        }
    }

    public void onCrossIconClickSecond() {
        if (isLastNameFilled.get()) {
            lastName.set("");
        }
    }
}
