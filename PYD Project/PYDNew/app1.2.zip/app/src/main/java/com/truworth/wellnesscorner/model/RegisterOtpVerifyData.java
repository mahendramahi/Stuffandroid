package com.truworth.wellnesscorner.model;

/**
 * Created by rajeshs on 4/9/2018.
 */

public class RegisterOtpVerifyData {
    boolean isVerify;

    public boolean isVerify() {
        return isVerify;
    }

    public void setVerify(boolean verify) {
        isVerify = verify;
    }
}
