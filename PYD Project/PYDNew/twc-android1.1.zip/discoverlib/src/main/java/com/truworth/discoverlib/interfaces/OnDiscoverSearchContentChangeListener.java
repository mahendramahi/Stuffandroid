package com.truworth.discoverlib.interfaces;

/**
 Created by ManishJ1 on 8/12/2016.
 */
public interface OnDiscoverSearchContentChangeListener {

    /**
     Called when user swipe thorough tab of discover search

     @param query           Search keyword
     @param isUserSubmitted is query submitted by user
     */
    void onDiscoverSearchContentChange(String query, boolean isUserSubmitted);
}
