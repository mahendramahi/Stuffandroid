package com.truworth.wellnesscorner.ui.registration.registrationstepfourth;


import android.databinding.ObservableField;
import com.truworth.wellnesscorner.TheWellnessCornerApp;
import com.truworth.wellnesscorner.base.BaseViewModel;
import com.truworth.wellnesscorner.repo.LoginRepository;
import com.truworth.wellnesscorner.repo.model.request.SaveCityRequest;
import com.truworth.wellnesscorner.repo.model.response.SaveCityResponse;
import com.truworth.wellnesscorner.utils.SingleLiveEvent;
import javax.inject.Inject;
import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;

/**
 * Created by richas on 4/9/2018.
 */

public class ConfirmLocationViewModel extends BaseViewModel {

    public ObservableField<String> city = new ObservableField<>();
    public ObservableField<String> cityId = new ObservableField<>();
    public ObservableField<String> state = new ObservableField<>();
    public ObservableField<String> country = new ObservableField<>();

    @Inject
    LoginRepository repository;

   public ConfirmLocationViewModel() {
        TheWellnessCornerApp.getApp().component().inject(this);
   }

    public void setCity(String city) {
        this.city.set(city);
    }

    public void setCityId(String cityId) {
        this.cityId.set(cityId);
    }

    public ObservableField<String> getCityId() {
        return cityId;
    }

    public void setState(String state) {
        this.state.set(state);
    }

    public void setCountry(String country) {
        this.country.set(country);
    }

    private final SingleLiveEvent<Void> isNavigateCitySearch = new SingleLiveEvent<>();
    public SingleLiveEvent<Void> getNavigateCitySearch() {
        return isNavigateCitySearch;
    }

    public void navigateToSearchCity() {
        isNavigateCitySearch.call();
    }
    public void confirmLocation() {
            saveLocation(getCityId().get().toString());
    }

    public void saveLocation(String cityId) {
        //setIsLoading(true);
        SaveCityRequest saveCityRequest = new SaveCityRequest();
        saveCityRequest.setCityId(cityId);

        repository.saveMembeCity(saveCityRequest).subscribe(new Observer<SaveCityResponse>() {

            @Override
            public void onSubscribe(Disposable d) {

            }
            @Override
            public void onNext(SaveCityResponse saveCityResponse) {
                if (!saveCityResponse.isHasError()) {
                    if(saveCityResponse.getData().getIsSave()!=null && saveCityResponse.getData().getIsSave().equalsIgnoreCase("true")){
                        isCitySaved.call();
                    }
                }
            }

            @Override
            public void onError(Throwable e) {

            }
            @Override
            public void onComplete() {
                //setIsLoading(false);
            }
        });
    }

    private final SingleLiveEvent<Void> isCitySaved = new SingleLiveEvent<>();
    public SingleLiveEvent<Void> getCitySaved() {
        return isCitySaved;
    }

}
