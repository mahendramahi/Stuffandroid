package com.twc.dailylog.model.response;


import com.twc.dailylog.model.beans.DailyLogItemDetail;

/**
 * Created by ManishJ1 on 7/4/2016.
 */
public class GetDailyLogResponse {

    private DailyLogItemDetail data;

    private int status;

    public DailyLogItemDetail getData() {
        return data;
    }

    public void setData(DailyLogItemDetail data) {
        this.data = data;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public static class DataBean {




    }
}
