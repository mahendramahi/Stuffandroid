package com.truworth.discoverlib.adapter;

import android.app.Activity;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.truworth.discoverlib.R;
import com.truworth.discoverlib.fragment.ArticleDetailFragmentNew;
import com.truworth.discoverlib.fragment.SlideshowFragment;
import com.truworth.discoverlib.model.ArticleItem;
import com.truworth.discoverlib.utils.Constant;
import com.truworth.discoverlib.utils.DateFactory;
import com.truworth.discoverlib.utils.Utils;

import java.util.ArrayList;
import java.util.List;

import static com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions.withCrossFade;

/**
 * If this code works it was written by Somesh Kumar on 05 August, 2016. If not, I don't know who wrote it.
 */
public class DiscoverListAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> implements Filterable {

    private static final int VIEW_TYPE_BIG = 0;
    private static final int VIEW_TYPE_SMALL = 1;
    private static final int VIEW_TYPE_PROGRESS = 2;
    private List<ArticleItem> mArticleItems, mFilterList;
    private ItemFilter mFilter;
    private Activity activity;

    public DiscoverListAdapter(List<ArticleItem> articleList, Activity activity) {
        mArticleItems = articleList;
        mFilterList = articleList;
        this.activity = activity;

    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        RecyclerView.ViewHolder viewHolder = null;
        View itemView;
        switch (viewType) {
            case VIEW_TYPE_BIG:
                itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_discover_list_big, parent, false);
                viewHolder = new ViewHolderBig(itemView);
                break;
            case VIEW_TYPE_SMALL:
                itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_discover_list_small, parent, false);
                viewHolder = new ViewHolderSmall(itemView);
                break;

            case VIEW_TYPE_PROGRESS:
                itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_loading_progress, parent, false);
                viewHolder = new ViewHolderLoading(itemView);
        }

        return viewHolder;

    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        ArticleItem articleItem = mFilterList.get(position);
        switch (holder.getItemViewType()) {
            case VIEW_TYPE_BIG:
                ViewHolderBig viewHolderBig = (ViewHolderBig) holder;
                viewHolderBig.tvDiscoverTitle.setText(Utils.fromHtml(articleItem.getTitle()));
                String serverDateString = articleItem.getModifiedDate();
                serverDateString = DateFactory.getInstance().truncateMilliseconds(serverDateString);
                //  String relativeTime = DateFactory.getInstance().getCustomRelativeTime(Constant.SERVER_DATE_FORMAT_WITH_MILLISECONDS, serverDateString);
                String relativeTime = DateFactory.getInstance().timeAgo(DateFactory.getInstance().getMillisFromStringDate(serverDateString, Constant.SERVER_DATE_FORMAT_WITH_MILLISECONDS) / 1000);
                viewHolderBig.tvDiscoverAddedTime.setText(relativeTime);
                Glide.with(activity).load(articleItem.getImage()).transition(withCrossFade()).into(viewHolderBig.ivDiscoverImage);
                break;

            case VIEW_TYPE_SMALL:
                ViewHolderSmall viewHolderSmall = (ViewHolderSmall) holder;
                viewHolderSmall.tvDiscoverTitle.setText(Utils.fromHtml(articleItem.getTitle()));
                Glide.with(activity).load(articleItem.getImage()).transition(withCrossFade()).into(viewHolderSmall.ivDiscoverImage);
                break;

            case VIEW_TYPE_PROGRESS:
                ViewHolderLoading viewHolderLoading = (ViewHolderLoading) holder;
                viewHolderLoading.mProgressBar.setIndeterminate(true);
                break;
        }

    }

    @Override
    public int getItemViewType(int position) {
        if (position == 0 || position == 1) {
            return VIEW_TYPE_BIG;
        } else if (mFilterList.get(position) == null) {
            return VIEW_TYPE_PROGRESS;
        } else {
            return VIEW_TYPE_SMALL;
        }
    }

    @Override
    public int getItemCount() {
        return mFilterList != null ? mFilterList.size() : 0;
    }

    @Override
    public Filter getFilter() {
        if (mFilter == null) {
            mFilter = new ItemFilter();
        }
        return mFilter;
    }


    private void showDetailScreen(int position) {
        if (mFilterList.get(position).getType().equalsIgnoreCase(Constant.ARTICLE_TYPE_ARTICLES)) {
            Bundle bundle = new Bundle();
            bundle.putString(Constant.BUNDLE_KEY_ARTICLE_ID, mFilterList.get(position).getURL());
            Utils.replaceFragment(activity.getFragmentManager(), ArticleDetailFragmentNew.newInstance(bundle), ArticleDetailFragmentNew.class.getSimpleName(), true, R.id.container);
        } else if (mFilterList.get(position).getType().equalsIgnoreCase(Constant.ARTICLE_TYPE_SLIDESHOW)) {
            Bundle bundle = new Bundle();
            bundle.putInt(Constant.BUNDLE_KEY_SLIDESHOW_ID, mFilterList.get(position).getID());
            bundle.putString(Constant.BUNDLE_KEY_SLIDESHOW_URL, mFilterList.get(position).getURL());
            Utils.replaceFragment(activity.getFragmentManager(), SlideshowFragment.newInstance(bundle), SlideshowFragment.class.getSimpleName(), true, R.id.container);
        }
    }


    public class ViewHolderBig extends RecyclerView.ViewHolder {
        ImageView ivDiscoverImage;
        TextView tvDiscoverTitle, tvDiscoverAddedTime;

        public ViewHolderBig(View itemView) {
            super(itemView);
            ivDiscoverImage = itemView.findViewById(R.id.ivDiscoverImage);
            tvDiscoverTitle = itemView.findViewById(R.id.tvDiscoverTitle);
            tvDiscoverAddedTime = itemView.findViewById(R.id.tvDiscoverAddedTime);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    showDetailScreen(getAdapterPosition());
                }
            });
        }
    }

    public class ViewHolderSmall extends RecyclerView.ViewHolder {
        ImageView ivDiscoverImage;
        TextView tvDiscoverTitle;

        public ViewHolderSmall(View itemView) {
            super(itemView);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    showDetailScreen(getAdapterPosition());
                }
            });
            ivDiscoverImage = itemView.findViewById(R.id.ivDiscoverImage);
            tvDiscoverTitle = itemView.findViewById(R.id.tvDiscoverTitle);
        }
    }

    public class ViewHolderLoading extends RecyclerView.ViewHolder {
        ProgressBar mProgressBar;

        public ViewHolderLoading(View itemView) {
            super(itemView);
            mProgressBar = itemView.findViewById(R.id.progressBar);
        }
    }

    private class ItemFilter extends Filter {
        @Override
        protected FilterResults performFiltering(CharSequence constraint) {

            String filterString = constraint.toString().toLowerCase();

            FilterResults results = new FilterResults();

            final List<ArticleItem> list = mArticleItems;

            int count = list.size();
            final ArrayList<ArticleItem> nlist = new ArrayList<>(count);

            String filterableString;

            for (int i = 0; i < count; i++) {
                filterableString = list.get(i).getTitle();
                if (filterableString.toLowerCase().contains(filterString)) {
                    nlist.add(list.get(i));
                }
            }

            results.values = nlist;
            results.count = nlist.size();

            return results;
        }

        @SuppressWarnings("unchecked")
        @Override
        protected void publishResults(CharSequence constraint, FilterResults results) {
            mFilterList = (ArrayList<ArticleItem>) results.values;
            notifyDataSetChanged();
        }

    }

}
