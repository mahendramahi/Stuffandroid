package com.twc.dailylog.model.requestbody;


import com.twc.dailylog.model.beans.AddFoodItem;

import java.util.List;

/**
 * Created by ManishJ1 on 8/4/2016.
 */
public class AddFoodBody {

    /**
     * NutritionMealType : Breakfast
     * NutritionID : 0
     * NutritionMemberID : 252330
     * NutritionFat : 9
     * NutritionQuantity : 1
     * NutritionFoodItem : Alle Piyav Gashi, Karnataka
     * NutritionCarbs : 9
     * FoodID : 46476
     * NutritionDate : 05/26/2016 04:25:33
     * NutritionSodium : 206.4
     * NutritionProtien : 21
     * NutritionStandardServing : Plate
     * NutritionCalorie : 201
     */

    private List<AddFoodItem> model;

    public List<AddFoodItem> getModel() {
        return model;
    }

    public void setModel(List<AddFoodItem> model) {
        this.model = model;
    }


}
