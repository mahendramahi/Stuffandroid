package com.twc.dailylog.model.beans;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * Created by ManishJ1 on 5/27/2016.
 */
public class FoodSearchItem {
    @SerializedName("DIETFOOD_ID")
    @Expose
    private Integer foodId;
    @SerializedName("DIETFOOD_NAME")
    @Expose
    private String foodName;
    @SerializedName("DIETFOOD_QUANTITY")
    @Expose
    private double foodQuantity;
    @SerializedName("DIETFOOD_STANDARDSERVING")
    @Expose
    private String foodStandardServing;
    @SerializedName("DIETFOOD_CALORIES")
    @Expose
    private double foodCalories;
    @SerializedName("DIETFOOD_UNIT")
    @Expose
    private String foodUnit;

    private String searchType;

    public Integer getFoodId() {
        return foodId;
    }

    public void setFoodId(Integer foodId) {
        this.foodId = foodId;
    }

    public String getFoodName() {
        return foodName;
    }

    public void setFoodName(String foodName) {
        this.foodName = foodName;
    }

    public double getFoodQuantity() {
        return foodQuantity;
    }

    public void setFoodQuantity(double foodQuantity) {
        this.foodQuantity = foodQuantity;
    }

    public String getFoodStandardServing() {
        return foodStandardServing;
    }

    public void setFoodStandardServing(String foodStandardServing) {
        this.foodStandardServing = foodStandardServing;
    }

    public double getFoodCalories() {
        return foodCalories;
    }

    public void setFoodCalories(double foodCalories) {
        this.foodCalories = foodCalories;
    }

    public String getFoodUnit() {
        return foodUnit;
    }

    public void setFoodUnit(String foodUnit) {
        this.foodUnit = foodUnit;
    }

    public String getSearchType() {
        return searchType;
    }

    public void setSearchType(String searchType) {
        this.searchType = searchType;
    }
}
