package com.twc.remindermodule.fragments;

import android.app.Fragment;
import android.app.FragmentManager;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.content.ContextCompat;
import android.support.v4.widget.DrawerLayout;
import android.view.KeyEvent;
import android.view.View;
import android.widget.ImageView;

import com.twc.remindermodule.R;
import com.twc.remindermodule.R2;
import com.twc.remindermodule.utils.Utils;
import com.twc.remindermodule.views.CustomTextView;

import java.util.ArrayList;

import butterknife.BindView;
import butterknife.OnClick;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by richas on 9/21/2017.
 */

public class RecommendedHealthyHabitsMainFragment extends BaseFragment {
    @BindView(R2.id.tvConfigureNow)
    CustomTextView tvConfigureNow;
    @BindView(R2.id.tvShowMore)
    CustomTextView tvShowMore;
    @BindView(R2.id.ivBack)
    ImageView ivBack;

    public static RecommendedHealthyHabitsMainFragment newInstance(Bundle bundle) {
        RecommendedHealthyHabitsMainFragment fragment = new RecommendedHealthyHabitsMainFragment();
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    public int getFragmentLayout() {
        return R.layout.fragment_healthy_habits_main;
    }

    @Override
    public void onFragmentReady() {
    }


    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
       // view.setFocusableInTouchMode(true);
      //  view.requestFocus();
       /* view.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (keyCode == KeyEvent.KEYCODE_BACK && event.getAction() == KeyEvent.ACTION_DOWN) {
                    getActivity().getFragmentManager().popBackStack();
                    return true;
                }
                return false;
            }
        });*/
    }

    @OnClick({R2.id.tvConfigureNow, R2.id.tvShowMore, R2.id.ivBack})
    public void onClick(View view) {
        int i = view.getId();
        if (i == R.id.tvConfigureNow) {
            Bundle bundle1 = new Bundle();
            Utils.replaceFragment(getFragmentManager(), RecommendedHealthyHabitsFragment.newInstance(bundle1), RecommendedHealthyHabitsFragment.class.getSimpleName(), true, R.id.fragmentContainerReminder);
        } else if (i == R.id.ivBack) {
            getActivity().finish();
        }
    }


}
