package com.truworth.wellnesscorner.ui.mainapp.post;

import android.databinding.DataBindingUtil;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.FragmentActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.gson.Gson;
import com.truworth.wellnesscorner.R;
import com.truworth.wellnesscorner.TheWellnessCornerApp;
import com.truworth.wellnesscorner.customviews.FullImageDialog;
import com.truworth.wellnesscorner.data.SharedPreferenceHelper;
import com.truworth.wellnesscorner.databinding.LayoutPostUrlBinding;
import com.truworth.wellnesscorner.databinding.RowContentTypeChallengeBinding;
import com.truworth.wellnesscorner.databinding.RowContentTypeEventBinding;
import com.truworth.wellnesscorner.databinding.RowContentTypeResourceBinding;
import com.truworth.wellnesscorner.databinding.RowLoadingProgressBinding;
import com.truworth.wellnesscorner.databinding.RowPostCommentListBinding;
import com.truworth.wellnesscorner.databinding.RowPostContainerBinding;
import com.truworth.wellnesscorner.databinding.RowShareSomethingBinding;
import com.truworth.wellnesscorner.databinding.RowTodayDashboardBinding;
import com.truworth.wellnesscorner.databinding.RowViewPreviousCommentBinding;
import com.truworth.wellnesscorner.interfaces.OnClickRefreshStep;
import com.truworth.wellnesscorner.interfaces.OnPostItemClickListener;
import com.truworth.wellnesscorner.model.CommentListData;
import com.truworth.wellnesscorner.model.EventBean;
import com.truworth.wellnesscorner.model.OnGoingChallengesBean;
import com.truworth.wellnesscorner.model.Post;
import com.truworth.wellnesscorner.model.PostMediaData;
import com.truworth.wellnesscorner.model.ShareSomethingBean;
import com.truworth.wellnesscorner.model.TodayDashBoardBean;
import com.truworth.wellnesscorner.model.ViewPreviousItem;
import com.truworth.wellnesscorner.ui.mainapp.circledetail.challenges.ChallengeDetailActivity;
import com.truworth.wellnesscorner.ui.mainapp.circledetail.challenges.OngoingChallengeItemViewModel;
import com.truworth.wellnesscorner.ui.mainapp.circledetail.home.ShareSomethingViewModel;
import com.truworth.wellnesscorner.ui.mainapp.createpost.CreatePostActivity;
import com.truworth.wellnesscorner.ui.mainapp.createpost.PostUrlViewModel;
import com.truworth.wellnesscorner.ui.mainapp.post.postcomment.PostCommentItemViewModel;
import com.truworth.wellnesscorner.ui.mainapp.today.MyChallengesAdapter;
import com.truworth.wellnesscorner.ui.mainapp.today.TodayDashBoardViewModel;

import java.util.List;

import javax.inject.Inject;

import im.ene.toro.CacheManager;

public class PostRecyclerAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> implements OngoingChallengeItemViewModel.MyChallengeListener, CacheManager, EventViewModel.UpdateEventClickListener {
    public static final int POST_TYPE_TEXT = 1;
    public static final int POST_TYPE_MEDIA = 2;
    // public static final int POST_TYPE_IMAGE = 3;
    public static final int POST_TYPE_CHALLENGE = 4;
    public static final int POST_TYPE_CHALLENGE_CHECK_IN = 5;
    public static final int POST_TYPE_EVENT = 6;
    public static final int POST_TYPE_RESOURCE = 8;
    public static final int POST_TYPE_SHARE_SOMETHING = 9;
    public static final int POST_TYPE_URL = 7;
    public static final int POST_TYPE_SIMPLE = 200;

    public static final int VIEW_TYPE_PROGRESS = -1;

    @Inject
    SharedPreferenceHelper prefHelper;
    List<IPostListItem> mPostsList;
    FragmentActivity mActivity;
    String circleIdentity, circleName;
    Gson gson = new Gson();
    private OnClickRefreshStep onRefreshStepClickListener;
    private OnPostItemClickListener itemClickListener;

    public PostRecyclerAdapter(FragmentActivity mActivity, List<IPostListItem> posts, String circleIdentity, String circleName) {
        this.mPostsList = posts;
        this.circleIdentity = circleIdentity;
        this.circleName = circleName;
        this.mActivity = mActivity;
        TheWellnessCornerApp.getApp().component().inject(this);

    }

    // for post comment activity
    public PostRecyclerAdapter(FragmentActivity mActivity, OnPostItemClickListener itemClickListener, List<IPostListItem> posts, String circleIdentity, String circleName) {
        this.mPostsList = posts;
        this.circleIdentity = circleIdentity;
        this.circleName = circleName;
        this.mActivity = mActivity;
        this.itemClickListener = itemClickListener;
        TheWellnessCornerApp.getApp().component().inject(this);

    }

    // for today Fragment
    public PostRecyclerAdapter(FragmentActivity mActivity, List<IPostListItem> posts, String circleIdentity, String circleName, OnClickRefreshStep listener) {
        this.mPostsList = posts;
        this.circleIdentity = circleIdentity;
        this.circleName = circleName;
        this.mActivity = mActivity;
        this.onRefreshStepClickListener = listener;
        TheWellnessCornerApp.getApp().component().inject(this);

    }

    public void setCircleName(String circleName) {
        this.circleName = circleName;
    }

    public void setItems(List<IPostListItem> posts) {
        this.mPostsList = posts;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        //if (mPostsList.get(viewType) != null) {
        switch (viewType) {
            case IPostListItem.TYPE_TODAY_DASHBOARD:

                RowTodayDashboardBinding rowTodayDashboardBinding = DataBindingUtil.inflate(LayoutInflater.from(parent.getContext()), R.layout.row_today_dashboard, parent, false);
                //shareSomethingBinding.setViewModel(new ShareSomethingViewModel());
                return new TodayDashBoardViewHolder(rowTodayDashboardBinding);

            case IPostListItem.TYPE_SHARE:
                //case POST_TYPE_SHARE_SOMETHING:
                RowShareSomethingBinding shareSomethingBinding = DataBindingUtil.inflate(LayoutInflater.from(parent.getContext()), R.layout.row_share_something, parent, false);
                return new ShareSomethingViewHolder(shareSomethingBinding);

            case POST_TYPE_MEDIA:
                RowPostContainerBinding binding = DataBindingUtil.inflate(LayoutInflater.from(parent.getContext()), R.layout.row_post_container, parent, false);
                return new PostViewHolderWithVideoPlayer(binding);
            // break;
            case POST_TYPE_SIMPLE:
                RowPostContainerBinding bindingSimplePost = DataBindingUtil.inflate(LayoutInflater.from(parent.getContext()), R.layout.row_post_container, parent, false);
                return new PostsViewHolder(bindingSimplePost);

            //break;
            //case IPostListItem.TYPE_POST:
//                    RowPostContainerBinding binding = DataBindingUtil.inflate(LayoutInflater.from(parent.getContext()), R.layout.row_post_container, parent, false);
//                    Gson gson = new Gson();
//                    Post mPost = (Post) mPostsList.get(get);


//                    if (viewModel.videoMediaData.size() == 0 && viewModel.imageMediaData.size() == 1 && postType != POST_TYPE_RESOURCE) {
//                        viewModel.setImageUrlPost(viewModel.imageMediaData.get(0).getFileName());
//                    } else {
//                        binding.imSlider.setVisibility(View.GONE);
//                    }
            //  switch (postType) {

//            case POST_TYPE_TEXT:
//
//                break;
//                case POST_TYPE_MEDIA:
            //break;
//                if (mPost.getPostIsHasMedia() && (mPost.videoMediaData.size() > 0 || mPost.imageMediaData.size() > 1)) {
//                    RowContentTypeMediaBinding bindingMedia = DataBindingUtil.inflate(LayoutInflater.from(parent.getContext()), R.layout.row_content_type_media, parent, false);
//                    binding.container.addView(bindingMedia.getRoot());
//                    return new PostViewHolderWithVideoPlayer(binding, bindingMedia);
//                }
////                    break;
//                case POST_TYPE_EVENT:
//                    RowContentTypeEventBinding bindingEvent = DataBindingUtil.inflate(LayoutInflater.from(parent.getContext()), R.layout.row_content_type_event, parent, false);
//                    EventBean eventBean = gson.fromJson(gson.toJson(mPost.getContentData()), EventBean.class);
//
//                    if (eventBean != null) {
//                        EventViewModel eventViewModel = new EventViewModel(eventBean, this);
//                        bindingEvent.setViewModel(eventViewModel);
//                        binding.containerForEventAndChallenge.addView(bindingEvent.getRoot());
//                        eventViewModel.setCircleIdentity(mPost.getPostMapIdentity());
//                    }
//                    break;
//                case POST_TYPE_CHALLENGE:
//                    RowContentTypeChallengeBinding bindingChallenge = DataBindingUtil.inflate(LayoutInflater.from(parent.getContext()), R.layout.row_content_type_challenge, parent, false);
//                    OnGoingChallengesBean challenge = gson.fromJson(gson.toJson(mPost.getContentData()), OnGoingChallengesBean.class);
//                    if (challenge != null) {
//                        OngoingChallengeItemViewModel challengeViewModel = new OngoingChallengeItemViewModel(challenge, this, mPost.getPostMapIdentity());
//                        bindingChallenge.setViewModel(challengeViewModel);
//                        binding.containerForEventAndChallenge.addView(bindingChallenge.getRoot());
//                    }
//                    if (mPost.getPostIsHasMedia() && (mPost.videoMediaData.size() > 0 || mPost.imageMediaData.size() > 1)) {
//                        RowContentTypeMediaBinding bindingMedia = DataBindingUtil.inflate(LayoutInflater.from(parent.getContext()), R.layout.row_content_type_media, parent, false);
//                        binding.container.addView(bindingMedia.getRoot());
//                        return new PostViewHolderWithVideoPlayer(binding, bindingMedia);
//                    }
//                    break;
//                case POST_TYPE_CHALLENGE_CHECK_IN:
//
//                    if (mPost.getPostIsHasMedia() && (mPost.videoMediaData.size() > 0 || mPost.imageMediaData.size() > 1)) {
//                        RowContentTypeMediaBinding bindingMedia = DataBindingUtil.inflate(LayoutInflater.from(parent.getContext()), R.layout.row_content_type_media, parent, false);
//                        binding.container.addView(bindingMedia.getRoot());
//                        return new PostViewHolderWithVideoPlayer(binding, bindingMedia);
//                    }
//                    break;
//                case POST_TYPE_RESOURCE:
//                    RowContentTypeResourceBinding resourceBinding = DataBindingUtil.inflate(LayoutInflater.from(parent.getContext()), R.layout.row_content_type_resource, parent, false);
//                    ResourceViewModel resourceViewModel = new ResourceViewModel(mPost.getPostMediaList());
//                    resourceBinding.setViewModel(resourceViewModel);
//                    binding.containerForEventAndChallenge.addView(resourceBinding.getRoot());
//
//                    break;

            //}

            case IPostListItem.TYPE_VIEW_PREVIOUS:
                RowViewPreviousCommentBinding previousCommentBinding = DataBindingUtil.inflate(LayoutInflater.from(parent.getContext()), R.layout.row_view_previous_comment, parent, false);
                return new ViewPreviousHolder(previousCommentBinding, itemClickListener);

            case IPostListItem.TYPE_COMMENT:

                RowPostCommentListBinding commentListBinding = DataBindingUtil.inflate(LayoutInflater.from(parent.getContext()), R.layout.row_post_comment_list, parent, false);
                return new ViewHolderComment(commentListBinding);
            case VIEW_TYPE_PROGRESS:
                RowLoadingProgressBinding rowLoadingProgressBinding = DataBindingUtil.inflate(LayoutInflater.from(parent.getContext()), R.layout.row_loading_progress, parent, false);
                return new ViewHolderLoading(rowLoadingProgressBinding);

        }

        return null;

    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        if (holder instanceof TodayDashBoardViewHolder) {
            ((TodayDashBoardViewHolder) holder).bind((TodayDashBoardBean) mPostsList.get(position));
        } else if (holder instanceof ViewHolderLoading) {
            ((ViewHolderLoading) holder).bind();
        } else if (holder instanceof ViewPreviousHolder) {
            ((ViewPreviousHolder) holder).bind((ViewPreviousItem) mPostsList.get(position));
        } else if (holder instanceof ViewHolderComment) {
            ((ViewHolderComment) holder).bind((CommentListData) mPostsList.get(position));
        } else if (holder instanceof ShareSomethingViewHolder) {
            ((ShareSomethingViewHolder) holder).bind((ShareSomethingBean) mPostsList.get(position));
        } else if (holder instanceof PostViewHolderWithVideoPlayer) {
            addRequiredViews(holder, ((PostViewHolderWithVideoPlayer) holder).getBinding(), (Post) mPostsList.get(position));
            ((PostViewHolderWithVideoPlayer) holder).bind((Post) mPostsList.get(position));
        } else {
            addRequiredViews(holder, ((PostsViewHolder) holder).getBinding(), (Post) mPostsList.get(position));
            ((PostsViewHolder) holder).bind((Post) mPostsList.get(position));
        }
    }

    public void addRequiredViews(RecyclerView.ViewHolder holder, RowPostContainerBinding binding, Post p) {
        // p.extractMediaData();
        binding.containerForEventAndChallenge.removeAllViews();
        switch (getViewType(p)) {
            case POST_TYPE_TEXT:

                break;
            case POST_TYPE_MEDIA:

                if (p.getPostIsHasMedia() && (p.urlMediaData.size() > 0)) {
                    LayoutPostUrlBinding postUrlBinding = DataBindingUtil.inflate(LayoutInflater.from(holder.itemView.getContext()), R.layout.layout_post_url, null, false);
                    PostMediaData urlData = p.urlMediaData.get(0);
                    if (urlData != null) {
                        PostUrlViewModel urlViewModel = new PostUrlViewModel(urlData,false);
                        postUrlBinding.setUrlViewModel(urlViewModel);
                        binding.containerForEventAndChallenge.setPadding(0,0,0,0);
                        binding.containerForEventAndChallenge.addView(postUrlBinding.getRoot());
                    }

                }
                break;
            case POST_TYPE_EVENT:
                RowContentTypeEventBinding bindingEvent = DataBindingUtil.inflate(LayoutInflater.from(holder.itemView.getContext()), R.layout.row_content_type_event, null, false);
                EventBean eventBean = gson.fromJson(gson.toJson(p.getContentData()), EventBean.class);

                if (eventBean != null) {
                    EventViewModel eventViewModel = new EventViewModel(eventBean, this);
                    bindingEvent.setViewModel(eventViewModel);
                    binding.containerForEventAndChallenge.addView(bindingEvent.getRoot());
                    eventViewModel.setCircleIdentity(p.getPostMapIdentity());
                }
                break;
            case POST_TYPE_CHALLENGE:
                RowContentTypeChallengeBinding bindingChallenge = DataBindingUtil.inflate(LayoutInflater.from(holder.itemView.getContext()), R.layout.row_content_type_challenge, null, false);
                OnGoingChallengesBean challenge = gson.fromJson(gson.toJson(p.getContentData()), OnGoingChallengesBean.class);
                if (challenge != null) {
                    OngoingChallengeItemViewModel challengeViewModel = new OngoingChallengeItemViewModel(challenge, this, p.getPostMapIdentity());
                    bindingChallenge.setViewModel(challengeViewModel);
                    binding.containerForEventAndChallenge.addView(bindingChallenge.getRoot());
                }
//                if (p.getPostIsHasMedia() && (p.videoMediaData.size() > 0 || p.imageMediaData.size() > 1)) {
//                    RowContentTypeMediaBinding bindingMedia = DataBindingUtil.inflate(LayoutInflater.from(holder.itemView.getContext()), R.layout.row_content_type_media, null, false);
//                    binding.container.addView(bindingMedia.getRoot());
//                    // return new PostViewHolderWithVideoPlayer(binding, bindingMedia);
//                }
                break;
            case POST_TYPE_CHALLENGE_CHECK_IN:

//                if (p.getPostIsHasMedia() && (p.videoMediaData.size() > 0 || p.imageMediaData.size() > 1)) {
//                    RowContentTypeMediaBinding bindingMedia = DataBindingUtil.inflate(LayoutInflater.from(holder.itemView.getContext()), R.layout.row_content_type_media, null, false);
//                    binding.container.addView(bindingMedia.getRoot());
//                    //return new PostViewHolderWithVideoPlayer(binding, bindingMedia);
//                }
                break;
            case POST_TYPE_RESOURCE:
                RowContentTypeResourceBinding resourceBinding = DataBindingUtil.inflate(LayoutInflater.from(holder.itemView.getContext()), R.layout.row_content_type_resource, null, false);
                ResourceViewModel resourceViewModel = new ResourceViewModel(p.getPostMediaList());
                resourceBinding.setViewModel(resourceViewModel);

                binding.containerForEventAndChallenge.addView(resourceBinding.getRoot());

                break;


        }
    }

    @Override
    public int getItemCount() {
        return mPostsList.size();
    }

    @Override
    public void onItemClick(OnGoingChallengesBean onGoingChallenge, String postMapId, boolean isOpenForCheckIn) {
        if (isOpenForCheckIn)
            CreatePostActivity.start(mActivity, "", postMapId, true, onGoingChallenge);
        else {
            if (!(mActivity instanceof ChallengeDetailActivity)) {
                ChallengeDetailActivity.start(mActivity, onGoingChallenge.getChallengeIdentity(), circleIdentity, onGoingChallenge.getChallengeTypeId());
            }
        }
    }

    @Nullable
    @Override
    public Object getKeyForOrder(int order) {
        return null;//mPostsList.get(order);
    }

    @Nullable
    @Override
    public Integer getOrderForKey(@NonNull Object key) {
        return null;//key instanceof Post ? mPostsList.indexOf(key) : null;
    }

    @Override
    public void updateEvent() {
        notifyDataSetChanged();
    }

    @Override
    public void onViewDetachedFromWindow(RecyclerView.ViewHolder holder) {
        super.onViewDetachedFromWindow(holder);
        if (holder instanceof PostViewHolderWithVideoPlayer) {
            ((PostViewHolderWithVideoPlayer) holder).onDetached();
        }
    }

    @Override
    public void onViewAttachedToWindow(RecyclerView.ViewHolder holder) {
        super.onViewAttachedToWindow(holder);
        if (holder instanceof PostViewHolderWithVideoPlayer) {
            ((PostViewHolderWithVideoPlayer) holder).onAttached();
        }
    }

    @Override
    public int getItemViewType(int position) {

        if (mPostsList.get(position) == null) {
            return VIEW_TYPE_PROGRESS;
        } else if (mPostsList.get(position).getPostListItemType() == IPostListItem.TYPE_POST) {
            Post p = (Post) mPostsList.get(position);
            p.extractMediaData();
            if (p.getPostIsHasMedia() && (p.videoMediaData.size() > 0 || p.imageMediaData.size() > 1) && (p.getPostContentTypeId() != PostConstants.CONTENT_TYPE_RESOURCE)) {
                return POST_TYPE_MEDIA;
            } else {
                return POST_TYPE_SIMPLE;
            }

        } else {
            return mPostsList.get(position).getPostListItemType();
        }
    }

    private int getViewType(Post post) {
        int viewType = -1;
        if (post.getPostContentTypeId() == 0 && !post.getPostIsHasMedia()) {
            viewType = POST_TYPE_TEXT;
        } else if (post.getPostContentTypeId() == 0 && post.getPostIsHasMedia()) {
            viewType = POST_TYPE_MEDIA;
        } else if (post.getPostContentTypeId() == PostConstants.CONTENT_TYPE_EVENT) {
            viewType = POST_TYPE_EVENT;
        } else if (post.getPostContentTypeId() == PostConstants.CONTENT_TYPE_CHALLENGE) {
            viewType = POST_TYPE_CHALLENGE;
        } else if (post.getPostContentTypeId() == PostConstants.CONTENT_TYPE_CHALLENGE_CHECK_IN) {
            viewType = POST_TYPE_CHALLENGE_CHECK_IN;
        } else if (post.getPostContentTypeId() == PostConstants.CONTENT_TYPE_RESOURCE) {
            viewType = POST_TYPE_RESOURCE;
        } else {
            viewType = POST_TYPE_TEXT;
        }
        return viewType;
    }

    public void getLastItemClicked() {

    }

    class PostsViewHolder extends RecyclerView.ViewHolder {
        RowPostContainerBinding mBinding;
        PostViewModel viewModel;

        public PostsViewHolder(RowPostContainerBinding binding) {
            super(binding.getRoot());
            mBinding = binding;
            //  this.viewModel = viewModel;
        }

        public RowPostContainerBinding getBinding() {
            return mBinding;
        }

        public void bind(Post post) {
            viewModel = new PostViewModel(post, getAdapterPosition());
            mBinding.setViewModel(viewModel);
            viewModel.getHifiValue();
            viewModel.getCommentValue();
            mBinding.containerMedia.setVisibility(View.GONE);

            if (viewModel.videoMediaData.size() == 0 && viewModel.imageMediaData.size() == 1 && (post.getPostContentTypeId() != PostConstants.CONTENT_TYPE_RESOURCE)) {

                viewModel.setImageUrlPost(viewModel.imageMediaData.get(0).getFileName());
                mBinding.imgFullView.setVisibility(View.VISIBLE);
                mBinding.imgFullView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        FullImageDialog dialog = new FullImageDialog(view.getContext(), viewModel.imageUrlPost.get(), "");
                        dialog.show();
                    }
                });
            } else {
                mBinding.imgFullView.setVisibility(View.GONE);
            }
            mBinding.executePendingBindings();
        }
    }

    class TodayDashBoardViewHolder extends RecyclerView.ViewHolder {
        RowTodayDashboardBinding mBinding;

        public TodayDashBoardViewHolder(RowTodayDashboardBinding binding) {
            super(binding.getRoot());
            mBinding = binding;
        }

        public void bind(TodayDashBoardBean todayBean) {
            if (mPostsList.size() > 1) {
                mBinding.tvActivityFeeds.setVisibility(View.VISIBLE);
                mBinding.tvSubTextActivityFeeds.setVisibility(View.VISIBLE);
            }
            mBinding.homeToolbar.tvToolBarText.setText("Today");
            if (todayBean.getListTodayMyChallenge() != null) {
                mBinding.tvMyChallenges.setVisibility(View.VISIBLE);
                mBinding.tvSubTextMyChallenges.setVisibility(View.VISIBLE);
                mBinding.rvMyChallenges.setLayoutManager(new LinearLayoutManager(mActivity, LinearLayoutManager.HORIZONTAL, false));
                MyChallengesAdapter adapterMyChallenge = new MyChallengesAdapter(todayBean.getListTodayMyChallenge());
                mBinding.rvMyChallenges.setAdapter(adapterMyChallenge);

            }
            TodayDashBoardViewModel todayDashBoardViewModel = new TodayDashBoardViewModel(todayBean, onRefreshStepClickListener);
            mBinding.setViewModel(todayDashBoardViewModel);
            mBinding.executePendingBindings();
        }
    }

    class ShareSomethingViewHolder extends RecyclerView.ViewHolder {
        RowShareSomethingBinding mBinding;

        public ShareSomethingViewHolder(RowShareSomethingBinding binding) {
            super(binding.getRoot());
            mBinding = binding;
        }

        public void bind(ShareSomethingBean shareSomethingBean) {
            // mBinding.setViewModel(viewModel);
            ShareSomethingViewModel shareViewModel = new ShareSomethingViewModel();
            shareViewModel.getUserImageUrl().set(shareSomethingBean.getProfileImage());
            shareViewModel.getUserName().set(shareSomethingBean.getUserName());
            mBinding.setViewModel(shareViewModel);
            shareViewModel.getCircleId(circleIdentity, circleName);
            mBinding.executePendingBindings();
        }
    }

    public class ViewHolderLoading extends RecyclerView.ViewHolder {
        private RowLoadingProgressBinding rowLoadingProgressBinding;

        public ViewHolderLoading(RowLoadingProgressBinding binding) {
            super(binding.getRoot());
            rowLoadingProgressBinding = binding;
        }

        public void bind() {
            rowLoadingProgressBinding.progressBar.setIndeterminate(true);
        }
    }

    public class ViewHolderComment extends RecyclerView.ViewHolder {
        private RowPostCommentListBinding commentListBinding;

        public ViewHolderComment(RowPostCommentListBinding binding) {
            super(binding.getRoot());
            commentListBinding = binding;
        }

        public void bind(CommentListData commentListData) {
            PostCommentItemViewModel viewModel = new PostCommentItemViewModel(commentListData);
            commentListBinding.setViewModel(viewModel);
            commentListBinding.executePendingBindings();
            viewModel.getHiFive();
        }
    }

    public class ViewPreviousHolder extends RecyclerView.ViewHolder {
        private RowViewPreviousCommentBinding previousCommentBinding;
        private OnPostItemClickListener onClickItem;

        public ViewPreviousHolder(RowViewPreviousCommentBinding binding, OnPostItemClickListener onClickItem) {
            super(binding.getRoot());
            previousCommentBinding = binding;
            this.onClickItem = onClickItem;
        }

        public void bind(ViewPreviousItem mPostsList) {
            previousCommentBinding.tvViewPrevious.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    onClickItem.onItemClick(mPostsList, getAdapterPosition());
                }
            });
            if (mPostsList.isVisible())
                previousCommentBinding.viewPreviousLayout.setVisibility(View.VISIBLE);
            else
                previousCommentBinding.viewPreviousLayout.setVisibility(View.GONE);

            previousCommentBinding.executePendingBindings();
        }

    }

}
