package com.truworth.stepmodule.rest;


import com.truworth.stepmodule.model.EFitLoginBody;
import com.truworth.stepmodule.model.EFitLoginResponse;
import com.truworth.stepmodule.model.EFitMonthStepsBody;
import com.truworth.stepmodule.model.EFitMonthStepsResponse;
import com.truworth.stepmodule.model.FitBitResponse;
import com.truworth.stepmodule.model.GetMisFitResponse;
import com.truworth.stepmodule.model.MisFitBody;
import com.truworth.stepmodule.model.MisFitResponse;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Path;
import retrofit2.http.Query;

/**
 * Created by ManishJ1 on 6/29/2016.
 */
public interface FitBitStepsService {

    @GET("1/user/-/activities/steps/date/{startDate}/{endDate}.json")
    Call<FitBitResponse> getUserStepsMonthly(@Path("startDate") String startDate, @Path("endDate") String endDate);

    @GET("1/user/-/activities/activityCalories/date/{startDate}/{endDate}.json")
    Call<FitBitResponse> getUserCaloriesMonthly(@Path("startDate") String startDate, @Path("endDate") String endDate);

    @GET("1/user/-/activities/steps/date/today/1d.json")
    Call<FitBitResponse> getUserTodaySteps();

    @GET("1/user/-/activities/activityCalories/date/today/1d.json")
    Call<FitBitResponse> getUserTodayCalories();

    /*efit api calling service*/
    @POST("login")
    Call<EFitLoginResponse> loginToEFit(@Body EFitLoginBody fitLoginBody);

    @POST("datewisesteps")
    Call<EFitMonthStepsResponse> getEFitMonthSteps(@Body EFitMonthStepsBody eFitMonthStepsBody);

    @POST("https://api.misfitwearables.com/auth/tokens/exchange")
    Call<MisFitResponse> loginToMisFit(@Body MisFitBody misFitBody);

    //https://api.misfitwearables.com/move/resource/v1/user/me/activity/summary?start_date=2017-10-18&end_date=2017-11-16&detail=true
    @GET("https://api.misfitwearables.com/move/resource/v1/user/me/activity/summary")
    Call<GetMisFitResponse> getUserSummary(@Query("start_date") String startDate, @Query("end_date") String endDate, @Query("detail") boolean detail);

}
