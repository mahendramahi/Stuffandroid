package com.truworth.wellnesscorner.ui.registration.registrationstepfourth;


import android.app.Activity;
import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Intent;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;

import com.truworth.wellnesscorner.R;
import com.truworth.wellnesscorner.databinding.FragmentCitySearchBinding;
import com.truworth.wellnesscorner.utils.Utils;

/**
 * Created by richas on 4/12/2018.
 */

public class CitySearchActivity extends AppCompatActivity {

    public static final String TAG = "CitySearchFragment";
    private CitySearchViewModel viewModel;
    private static final String ARG_CITY = "City";
    CitySearchAdapter citySearchAdapter;
    private MyAdapterListener addressListener = new MyAdapterListener() {
        @Override
        public void onContainerClick(int position) {

            String selectedCity = viewModel.addressData.get(position).getCityName();
            String selectedState = viewModel.addressData.get(position).getStateName();
            String selectedCountry = viewModel.addressData.get(position).getCountryName();
            int selectedCityId = viewModel.addressData.get(position).getCityId();

            Intent returnIntent = new Intent();
            returnIntent.putExtra("City", selectedCity);
            returnIntent.putExtra("State", selectedState);
            returnIntent.putExtra("Country", selectedCountry);
            returnIntent.putExtra("cityId", selectedCityId);
            setResult(Activity.RESULT_OK, returnIntent);
            Utils.hideSoftKeyboard(CitySearchActivity.this);
            finish();
        }
    };


    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        String city = getIntent().getStringExtra("CITY");

        FragmentCitySearchBinding binding = DataBindingUtil.setContentView(this, R.layout.fragment_city_search);
        viewModel = ViewModelProviders.of(this).get(CitySearchViewModel.class);
        binding.setViewModel(viewModel);
        viewModel.setCity(city);
        citySearchAdapter = new CitySearchAdapter(viewModel.getAddressData(), this,addressListener);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        binding.rvCitySearch.setLayoutManager(linearLayoutManager);
        binding.rvCitySearch.setAdapter(citySearchAdapter);
        setListdataObserver();
        setOnBackObserver();
    }

    private void setListdataObserver() {
        viewModel.getCityStateCountryList().observe(this, new Observer<Void>() {
            @Override
            public void onChanged(@Nullable Void aVoid) {
                citySearchAdapter.notifyDataSetChanged();
            }
        });
    }

    private void setOnBackObserver() {
        viewModel.getOnBackPressed().observe(this, new Observer<Void>() {
            @Override
            public void onChanged(@Nullable Void aVoid) {
            onBackPressed();
            }
        });
    }
}
