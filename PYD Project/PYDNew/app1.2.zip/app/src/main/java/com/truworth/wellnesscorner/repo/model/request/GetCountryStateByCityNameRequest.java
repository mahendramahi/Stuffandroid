package com.truworth.wellnesscorner.repo.model.request;

/**
 * Created by richas on 4/12/2018.
 */

public class GetCountryStateByCityNameRequest {

    private String Name;

    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }
}
