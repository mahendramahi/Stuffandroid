package com.truworth.wellnesscorner.repo.model.response;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.truworth.wellnesscorner.model.BMIData;

/**
 * Created by rajeshs on 4/9/2018.
 */

public class BMIResponse {

    @SerializedName("data")
    @Expose
    private BMIData data;
    @SerializedName("hasError")
    @Expose
    private boolean hasError;

    public BMIData getData() {
        return data;
    }

    public void setData(BMIData data) {
        this.data = data;
    }

    public boolean isHasError() {
        return hasError;
    }

    public void setHasError(boolean hasError) {
        this.hasError = hasError;
    }

    public Error getError() {
        return error;
    }

    public void setError(Error error) {
        this.error = error;
    }

    @SerializedName("error")
    @Expose
    private Error error;
}
