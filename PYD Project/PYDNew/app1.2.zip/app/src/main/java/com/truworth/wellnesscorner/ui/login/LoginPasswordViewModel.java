package com.truworth.wellnesscorner.ui.login;

import android.databinding.BindingAdapter;
import android.databinding.ObservableBoolean;
import android.databinding.ObservableField;
import android.databinding.ObservableInt;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.ImageView;

import com.truworth.wellnesscorner.R;
import com.truworth.wellnesscorner.TheWellnessCornerApp;
import com.truworth.wellnesscorner.base.BaseViewModel;
import com.truworth.wellnesscorner.data.SharedPreferenceHelper;
import com.truworth.wellnesscorner.model.LoginData;
import com.truworth.wellnesscorner.repo.LoginRepository;
import com.truworth.wellnesscorner.repo.model.request.LoginRequest;
import com.truworth.wellnesscorner.repo.model.response.LoginResponse;
import com.truworth.wellnesscorner.utils.RSAHelper;
import com.truworth.wellnesscorner.utils.SingleLiveEvent;

import javax.inject.Inject;

import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;

/**
 * Created by rajeshs on 3/27/2018.
 */

public class LoginPasswordViewModel extends BaseViewModel {
    private static final String TAG = "LoginPasswordViewModel";

    public ObservableInt resetIcon = new ObservableInt();
    public ObservableField<String> password = new ObservableField<>();
    public ObservableField<String> email = new ObservableField<>();
    public ObservableField<String> errorMessage = new ObservableField<>();
    public ObservableBoolean enableContinue = new ObservableBoolean();
    //public ObservableBoolean isPasswordFilled = new ObservableBoolean();

   // private final SingleLiveEvent<Void> clearData = new SingleLiveEvent<>();
    @Inject
    LoginRepository loginRepository;
    @Inject
    SharedPreferenceHelper prefHelper;
    private SingleLiveEvent<Void> onSuccessLogin = new SingleLiveEvent<>();

    public LoginPasswordViewModel() {
        TheWellnessCornerApp.getApp().component().inject(this);
        //this.isPasswordFilled.set(false);
    }

    public SingleLiveEvent<Void> getOnSuccessLogin() {
        return onSuccessLogin;
    }

    public void setEmail(String emailId) {
        this.email.set(emailId);
    }

    public TextWatcher passwordWatcher() {
        return new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                resetIcon.set(R.drawable.reset_input_box_icon);
                if (charSequence.toString().isEmpty())
                    errorMessage.set("");
            }

            @Override
            public void afterTextChanged(Editable editable) {
                if (password.get().isEmpty()) {
                    enableContinue.set(false);
                    //isPasswordFilled.set(false);
                } else {
                    enableContinue.set(true);
                   // isPasswordFilled.set(true);
                }
            }
        };
    }

    public void logInUser() {
        LoginRequest loginRequest = new LoginRequest();
        loginRequest.setEmail(RSAHelper.Encrypt(email.get()));
        loginRequest.setPassword(RSAHelper.Encrypt(password.get()));
        loginRepository.login(loginRequest).subscribe(new Observer<LoginResponse>() {
            @Override
            public void onSubscribe(Disposable d) {

            }

            @Override
            public void onNext(LoginResponse loginResponse) {
                if (!loginResponse.isHasError()) {
                    errorMessage.set("");
                    LoginData data = loginResponse.getData();
                    prefHelper.saveUserData(data.getFirstName(), data.getLastName(), data.getScreenName(), data.getEmail(), data.getImage(), data.getProfileStep());
                    prefHelper.saveTokenData(data.getToken().getValidTo(), data.getToken().getValue());
                    onSuccessLogin.call();
                    //resetIcon.set(R.drawable.ic_check);

                } else {
                    errorMessage.set(loginResponse.getError().getMessage());
                   // resetIcon.set(R.drawable.ic_red_cross);
                }
            }

            @Override
            public void onError(Throwable e) {

            }

            @Override
            public void onComplete() {

            }
        });

    }

    /*public SingleLiveEvent<Void> getClearData() {
        return clearData;
    }*/



    @BindingAdapter("imageResource")
    public static void setImageResource(ImageView imageView, int resource) {
        imageView.setImageResource(resource);
    }
}

