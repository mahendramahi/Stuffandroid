package com.truworth.wellnesscorner.ui.mainapp.createpost.shareweight;

import android.databinding.ObservableBoolean;
import android.databinding.ObservableField;
import android.text.SpannableStringBuilder;

import com.truworth.wellnesscorner.TheWellnessCornerApp;
import com.truworth.wellnesscorner.base.BaseViewModel;
import com.truworth.wellnesscorner.repo.CreatePostRepository;
import com.truworth.wellnesscorner.repo.model.request.ShareDashboardRequest;
import com.truworth.wellnesscorner.repo.model.response.PostWeightResponse;
import com.truworth.wellnesscorner.utils.DateUtils;
import com.truworth.wellnesscorner.utils.SingleLiveEvent;
import com.truworth.wellnesscorner.utils.Utils;

import javax.inject.Inject;

import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;

public class ShareWeightViewModel extends BaseViewModel {
    public ObservableField<String> errorMessage = new ObservableField<>();
    public ObservableField<String> userName = new ObservableField<>();
    public ObservableField<String> userImage = new ObservableField<>();
    public ObservableField<SpannableStringBuilder> bmi = new ObservableField<>();
    public ObservableField<SpannableStringBuilder> targetWeight = new ObservableField<>();
    public ObservableField<SpannableStringBuilder> weight = new ObservableField<>();
    public ObservableField<String> date = new ObservableField<>();
    SingleLiveEvent<Void> shareBtnClick = new SingleLiveEvent<>();
    public SingleLiveEvent<Void> getShareBtnClick() {
        return shareBtnClick;
    }
    public ObservableBoolean isDataLoaded = new ObservableBoolean();

    @Inject
    CreatePostRepository postRepository;

    public ShareWeightViewModel() {
        TheWellnessCornerApp.getApp().component().inject(this);
    }

    public void loadSharepostWeight() {
        setIsLoading(true);
        ShareDashboardRequest shareDashboardRequest = new ShareDashboardRequest();
        shareDashboardRequest.setDeviceDate(DateUtils.getTodayDate("yyyy-MM-dd hh:mm:ss.SSS"));


        postRepository.getPostWeight(shareDashboardRequest).subscribe(new Observer<PostWeightResponse>() {
            @Override
            public void onSubscribe(Disposable d) {

            }
            @Override
            public void onNext(PostWeightResponse response) {
                setIsLoading(false);

                if (!response.isHasError()) {
                    if(response.getData().getMemberName()!=null)
                        userName.set(response.getData().getMemberName() + "'s Weight");
                    userImage.set(response.getData().getMemberImage());
                    date.set(DateUtils.formatDate(response.getData().getDate(), DateUtils.SERVER_DATE, "MMMM dd, yyyy"));

                    SpannableStringBuilder htmlTargetWeight = Utils.makeSpecificTextBoldSize(("Target\n" + Utils.doubleToString(response.getData().getTargetWeight()) + " kgs"), Utils.doubleToString(response.getData().getTargetWeight()),1.5f);
                    targetWeight.set(htmlTargetWeight);
                    SpannableStringBuilder htmlWeight = Utils.makeSpecificTextBoldSize((Utils.doubleToString(response.getData().getWeight()) + " kgs"), Utils.doubleToString(response.getData().getWeight()),2f);
                    weight.set(htmlWeight);
                    SpannableStringBuilder htmlBmi = Utils.makeSpecificTextBoldSize(("BMI\n" + Utils.doubleToString(response.getData().getBMI())), Utils.doubleToString(response.getData().getBMI()),1.5f);
                    bmi.set(htmlBmi);
                    isDataLoaded.set(true);
                }else {
                    errorMessage.set(response.getError().getMessage());
                    isDataLoaded.set(false);
                }

            }

            @Override
            public void onError(Throwable e) {
                e.printStackTrace();
                isDataLoaded.set(false);
                setIsLoading(false);
            }

            @Override
            public void onComplete() {
                setIsLoading(false);
            }
        });
    }
    public void onShareClicked() {
        shareBtnClick.call();
    }
}
