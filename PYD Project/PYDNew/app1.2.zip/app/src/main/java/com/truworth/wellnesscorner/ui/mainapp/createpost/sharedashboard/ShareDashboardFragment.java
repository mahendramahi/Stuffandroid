package com.truworth.wellnesscorner.ui.mainapp.createpost.sharedashboard;

import android.app.Activity;
import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.View;

import com.truworth.wellnesscorner.BR;
import com.truworth.wellnesscorner.R;
import com.truworth.wellnesscorner.base.BaseFragment;
import com.truworth.wellnesscorner.databinding.FragmentShareDashboardBinding;
import com.truworth.wellnesscorner.ui.mainapp.createpost.ShareActivity;
import com.truworth.wellnesscorner.utils.Utils;

import java.io.ByteArrayOutputStream;


public class ShareDashboardFragment extends BaseFragment<FragmentShareDashboardBinding, ShareDashboardViewModel> {

    ShareDashboardViewModel viewModel;
    private Bitmap finalBitmap;
    public ShareDashboardFragment() {
        // Required empty public constructor
    }

    public static ShareDashboardFragment newInstance() {
        ShareDashboardFragment fragment = new ShareDashboardFragment();

        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        viewModel.loadDashboardPost();

        setClickObserver();
        setApiResponseObserver();
    }

    @Override
    public int getBindingVariable() {
        return BR.viewModel;
    }

    @Override
    public int getLayoutId() {
        return R.layout.fragment_share_dashboard;
    }

    @Override
    public ShareDashboardViewModel getViewModel() {
        viewModel = ViewModelProviders.of(this).get(ShareDashboardViewModel.class);
        return viewModel;
    }
    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
    }

    @Override
    public void onDetach() {
        super.onDetach();
    }

    private void setClickObserver() {

        viewModel.getShareBtnClick().observe(this, new Observer<Void>() {
            @Override
            public void onChanged(@Nullable Void avoid) {
                if (finalBitmap != null) {
                    String path = Utils.getImageUri(getContext(), finalBitmap);
                    Intent returnIntent = new Intent();
                    returnIntent.putExtra("result", path);
                    getActivity().setResult(Activity.RESULT_OK, returnIntent);
                    getActivity().finish();

                }
            }
        });

        viewModel.getThemeColorChange().observe(this, new Observer<String>() {
            @Override
            public void onChanged(@Nullable String color) {
              if(color.equals("BLACK")){
                  setBlackTheme();
                  setDefault();
              }
              else if(color.equals("GREEN")){
                  setGreenTheme();
                  setDefault();
              }
              else{
                  setWhiteTheme();
                  setDefault();
              }
            }
        });
    }


    private void setBlackTheme() {

        getViewDataBinding().rlTemplate.setBackgroundColor(getActivity().getResources().getColor(R.color.black));
        setTextColor(getActivity().getResources().getColor(R.color.white));

        getViewDataBinding().StepsProgres.setProgressDrawable(getActivity().getResources().getDrawable(R.drawable.circular_white_progress_bg));
        getViewDataBinding().CalorieConsumedProgress.setProgressDrawable(getActivity().getResources().getDrawable(R.drawable.circular_white_progress_bg));
        getViewDataBinding().CalorieBurnedProgres.setProgressDrawable(getActivity().getResources().getDrawable(R.drawable.circular_white_progress_bg));
        getViewDataBinding().GlassWaterProgres.setProgressDrawable(getActivity().getResources().getDrawable(R.drawable.circular_white_progress_bg));

        setImages("BLACK");
        getViewDataBinding().rlBlackTemplate.setBackground(getActivity().getResources().getDrawable(R.drawable.template_select_black));
        getViewDataBinding().rlWhiteTemplate.setBackground(getActivity().getResources().getDrawable(R.drawable.rounded_white_grey_border));
        getViewDataBinding().rlGreenTemplate.setBackground(getActivity().getResources().getDrawable(R.drawable.gradient_left_to_right));
    }

    private void setGreenTheme() {
        getViewDataBinding().rlTemplate.setBackground(getActivity().getResources().getDrawable(R.drawable.gradient_left_to_right));
        setTextColor(getActivity().getResources().getColor(R.color.white));

        getViewDataBinding().StepsProgres.setProgressDrawable(getActivity().getResources().getDrawable(R.drawable.circular_green_progress_bg));
        getViewDataBinding().CalorieConsumedProgress.setProgressDrawable(getActivity().getResources().getDrawable(R.drawable.circular_green_progress_bg));
        getViewDataBinding().CalorieBurnedProgres.setProgressDrawable(getActivity().getResources().getDrawable(R.drawable.circular_green_progress_bg));
        getViewDataBinding().GlassWaterProgres.setProgressDrawable(getActivity().getResources().getDrawable(R.drawable.circular_green_progress_bg));

        setImages("GREEN");
        getViewDataBinding().rlBlackTemplate.setBackgroundColor(getActivity().getResources().getColor(R.color.black));
        getViewDataBinding().rlWhiteTemplate.setBackground(getActivity().getResources().getDrawable(R.drawable.rounded_white_grey_border));
        getViewDataBinding().rlGreenTemplate.setBackground(getActivity().getResources().getDrawable(R.drawable.template_select_green));
    }

    private void setWhiteTheme() {
        getViewDataBinding().rlTemplate.setBackgroundColor(getActivity().getResources().getColor(R.color.white));
        setTextColor(getActivity().getResources().getColor(R.color.black));

        getViewDataBinding().StepsProgres.setProgressDrawable(getActivity().getResources().getDrawable(R.drawable.circular_white_progress_bg));
        getViewDataBinding().CalorieConsumedProgress.setProgressDrawable(getActivity().getResources().getDrawable(R.drawable.circular_white_progress_bg));
        getViewDataBinding().CalorieBurnedProgres.setProgressDrawable(getActivity().getResources().getDrawable(R.drawable.circular_white_progress_bg));
        getViewDataBinding().GlassWaterProgres.setProgressDrawable(getActivity().getResources().getDrawable(R.drawable.circular_white_progress_bg));

        setImages("WHITE");
        getViewDataBinding().rlWhiteTemplate.setBackground(getActivity().getResources().getDrawable(R.drawable.template_select_white));
        getViewDataBinding().rlBlackTemplate.setBackgroundColor(getActivity().getResources().getColor(R.color.black));
        getViewDataBinding().rlGreenTemplate.setBackground(getActivity().getResources().getDrawable(R.drawable.gradient_left_to_right));
    }


    private void setTextColor(int color) {
        getViewDataBinding().tvMemberStats.setTextColor(color);
        getViewDataBinding().tvDate.setTextColor(color);
        getViewDataBinding().tvStepsCount.setTextColor(color);
        getViewDataBinding().tvCalorieConsumedCount.setTextColor(color);
        getViewDataBinding().tvCalorieBurnedCount.setTextColor(color);
        getViewDataBinding().tvGlassWaterCount.setTextColor(color);
    }


    private void setImages(String themeColor) {

        if(themeColor.equals("GREEN")){
            getViewDataBinding().ivSteps.setImageResource(R.drawable.ic_footsteps_dashboard_share_white_icon);
            getViewDataBinding().ivCalorieConsumed.setImageResource(R.drawable.ic_meal_dashboard_share_white_icon);
            getViewDataBinding().ivCalorieBurned.setImageResource(R.drawable.ic_exercise_dashboard_share_white_icon);
            getViewDataBinding().ivGlassWater.setImageResource(R.drawable.ic_water_drop_white);
        }
        else{
            getViewDataBinding().ivSteps.setImageResource(R.drawable.ic_footsteps_dashboard_share_icon);
            getViewDataBinding().ivCalorieConsumed.setImageResource(R.drawable.ic_meal_dashboard_share_icon);
            getViewDataBinding().ivCalorieBurned.setImageResource(R.drawable.ic_exercise_dashboard_share_icon);
            getViewDataBinding().ivGlassWater.setImageResource(R.drawable.ic_water_dashboard_share_icon);
        }

    }

    private void setApiResponseObserver() {
        viewModel.getHasDataLoaded().observe(this, new Observer<Void>() {
            @Override
            public void onChanged(@Nullable Void avoid) {
                setDefault();
            }
        });
    }

    public void setDefault() {

        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {

                Bitmap bm = Utils.layoutToImage(getViewDataBinding().rlTemplate);
                ByteArrayOutputStream bytes = new ByteArrayOutputStream();
                bm.compress(Bitmap.CompressFormat.JPEG, 100, bytes);
                finalBitmap = bm;
            }
        }, 500);

    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if(finalBitmap!=null){
            finalBitmap.recycle();
            finalBitmap=null;
        }
    }
}
