package com.truworth.wellnesscorner.repo.model.request;

import java.util.List;

import io.reactivex.annotations.Nullable;

public class CreatePostRequest extends BaseRequest {

    private int PostFor;
    private String PostText;
    private boolean IsHasTags;
    private boolean IsHasMedia;
    @Nullable
    private Integer ContentTypeId;
    private PostContentDataRequest ContentData;
    private List<PostTagTypeDataRequest> TagTypeValue;
    private List<PostMediaTypeDataRequest> MediaTypeValue;

    public int getPostFor() {
        return PostFor;
    }

    public void setPostFor(int PostFor) {
        this.PostFor = PostFor;
    }

    public String getPostText() {
        return PostText;
    }

    public void setPostText(String PostText) {
        this.PostText = PostText;
    }

    public boolean isIsHasTags() {
        return IsHasTags;
    }

    public void setIsHasTags(boolean IsHasTags) {
        this.IsHasTags = IsHasTags;
    }

    public boolean isIsHasMedia() {
        return IsHasMedia;
    }

    public void setIsHasMedia(boolean IsHasMedia) {
        this.IsHasMedia = IsHasMedia;
    }

    public int getContentTypeId() {
        return ContentTypeId;
    }

    public void setContentTypeId(int ContentTypeId) {
        this.ContentTypeId = ContentTypeId;
    }

    public PostContentDataRequest getContentData() {
        return ContentData;
    }

    public void setContentData(PostContentDataRequest ContentData) {
        this.ContentData = ContentData;
    }

    public List<PostTagTypeDataRequest> getTagTypeValue() {
        return TagTypeValue;
    }

    public void setTagTypeValue(List<PostTagTypeDataRequest> TagTypeValue) {
        this.TagTypeValue = TagTypeValue;
    }

    public List<PostMediaTypeDataRequest> getMediaTypeValue() {
        return MediaTypeValue;
    }

    public void setMediaTypeValue(List<PostMediaTypeDataRequest> MediaTypeValue) {
        this.MediaTypeValue = MediaTypeValue;
    }
}
