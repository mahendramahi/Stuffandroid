package com.twc.remindermodule.model.requestbody;

/**
 * Created by richas on 9/21/2017.
 */

public class HealthyHabitBody {

    private String MemberID;

    public String getMemberID() {
        return MemberID;
    }

    public void setMemberID(String MemberID) {
        this.MemberID = MemberID;
    }
}
