package com.twc.dailylog.model.beans;

import java.util.ArrayList;

/**
 * Created by PankajS on 8/5/2016.
 */
public class DailyLogSectionItem
{
    private String sectionName;
    private ArrayList<DailyLogItem> mDailyLogDataArrayList;

    public String getSectionName() {
        return sectionName;
    }

    public void setSectionName(String sectionName) {
        this.sectionName = sectionName;
    }

    public ArrayList<DailyLogItem> getDailyLogDataArrayList() {
        return mDailyLogDataArrayList;
    }

    public void setDailyLogDataArrayList(ArrayList<DailyLogItem> dailyLogDataArrayList) {
        mDailyLogDataArrayList = dailyLogDataArrayList;
    }
}
