package com.truworth.wellnesscorner.ui.splash;

import android.arch.lifecycle.ViewModel;

import com.truworth.wellnesscorner.TheWellnessCornerApp;
import com.truworth.wellnesscorner.data.SharedPreferenceHelper;

import javax.inject.Inject;

/**
 * Created by rajeshs on 4/6/2018.
 */

public class SplashViewModel extends ViewModel {
    @Inject
    SharedPreferenceHelper prefHelper;

    public SplashViewModel() {
        TheWellnessCornerApp.getApp().component().inject(this);
    }

    public boolean isAlreadyLoggedIn() {
        if (prefHelper.getToken().isEmpty()) {
            return false;
        }
        return true;
    }

    public boolean isProfileStepCompleted() {
        if (prefHelper.getProfileStepNumber() >=6) {
            return true;
        }
        return false;
    }

    public int getProfileStepNumber() {
        return prefHelper.getProfileStepNumber();
    }

    public String getEmailId() {
        return prefHelper.getEmailId();
    }
}
