package com.twc.remindermodule.service;

import android.annotation.TargetApi;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;
import android.os.Build;
import android.os.IBinder;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.support.v4.app.NotificationCompat;
import android.util.Log;

import com.twc.remindermodule.utils.Constant;

import java.util.HashMap;
import java.util.Locale;

/**
 * Created by GurvinderS on 11/11/2016.
 */

public class TTS extends Service implements TextToSpeech.OnInitListener, TextToSpeech.OnUtteranceCompletedListener {

    private TextToSpeech tts;
    private String msg = "";
    private AudioManager am;
    private final AudioManager.OnAudioFocusChangeListener afl = new AudioManager.OnAudioFocusChangeListener() {
        @Override
        public void onAudioFocusChange(int focusChange) {
            // TODO React to audio-focus changes here!

            switch (focusChange) {
                case AudioManager.AUDIOFOCUS_GAIN:
                    am.setStreamVolume(am.STREAM_MUSIC, 6,0 );
                    break;

                case AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK:
                    am.setStreamVolume(am.STREAM_MUSIC, 6,0 );
                    break;
                case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK:
                    am.setStreamVolume(am.STREAM_MUSIC, 0,0 );
                    break;
                case AudioManager.AUDIOFOCUS_LOSS:
                    am.setStreamVolume(am.STREAM_MUSIC, 0,0 );
                    break;

                case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT:
                    // am.adjustVolume(AudioManager.ADJUST_MUTE, AudioManager.FLAG_PLAY_SOUND);
                    am.setStreamVolume(am.STREAM_MUSIC, 0,0 );
                    break;

            }

        }
    };
    private int focus_res = -1;

    @Override
    public void onCreate() {
        super.onCreate();

        am = (AudioManager) this.getSystemService(Context.AUDIO_SERVICE);

        tts = new TextToSpeech(this, this);
        focus_res = am.requestAudioFocus(
                afl, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK
        );
        if (Build.VERSION.SDK_INT >= 26) {
            String CHANNEL_ID = Constant.NOTIFICATION_CHANNEL_ID_REMINDERS;
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID,
                    Constant.NOTIFICATION_CHANNEL_NAME_REMINDERS,
                    NotificationManager.IMPORTANCE_HIGH);

            ((NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE)).createNotificationChannel(channel);
            Notification notification = new NotificationCompat.Builder(this, CHANNEL_ID)
                    .setContentTitle("Reminders")
                    .setContentText("App is syncing reminders")
                    .build();

            startForeground(1002, notification);
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && intent.getExtras() != null) {
            msg = intent.getExtras().getString("title");
            if (focus_res == AudioManager.AUDIOFOCUS_REQUEST_GRANTED) {
                speakOut(msg);
            }
        }
        return super.onStartCommand(intent, flags, startId);

    }

    @Override
    public void onDestroy() {
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onInit(int status) {

        if (status == TextToSpeech.SUCCESS) {
            tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                @Override
                public void onDone(String utteranceId) {
                    stopSelf();
                }

                @Override
                public void onError(String utteranceId) {
                }

                @Override
                public void onStart(String utteranceId) {
                }
            });
            int result = tts.setLanguage(Locale.US);
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                Log.d("TTS", "This Language is not supported");
            }
            if (focus_res == AudioManager.AUDIOFOCUS_REQUEST_GRANTED) {
                speakOut(msg);
            }
        } else {
            Log.d("TTS", "Initialization Failed!");
        }
    }

    private void speakOut(String msg) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            ttsGreater21(msg);
        } else {
            ttsUnder20(msg);
        }
       // stopSelf();
    }

    @SuppressWarnings("deprecation")
    private void ttsUnder20(String text) {
        HashMap<String, String> map = new HashMap<>();
        map.put(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, "MessageId");
        tts.speak(text, TextToSpeech.QUEUE_ADD, map);
    }

    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    private void ttsGreater21(String text) {
        String utteranceId = this.hashCode() + "";
        tts.speak(text, TextToSpeech.QUEUE_ADD, null, utteranceId);
    }

    @Override
    public void onUtteranceCompleted(String uttId) {
        stopSelf();
    }


}