package com.twc.remindermodule.adapter;

/**
 * Created by GurvinderS on 9/15/2017.
 */


import android.app.Activity;
import android.content.Intent;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.twc.dailylog.MealActivity;
import com.twc.dailylog.WaterActivity;
import com.twc.dailylog.model.beans.DailyLogUser;
import com.twc.dailylog.utils.DailyLogConfig;
import com.twc.dailylog.utils.WaterConfig;
import com.twc.remindermodule.GlideConfig;
import com.twc.remindermodule.R;
import com.twc.remindermodule.fragments.RecommendedMyHabitsFragment;
import com.twc.remindermodule.fragments.SleepTrackerLogsFragment;
import com.twc.remindermodule.model.response.MyHabitResponse;
import com.twc.remindermodule.rest.ReminderConfig;
import com.twc.remindermodule.utils.Constant;
import com.twc.remindermodule.utils.DateFactory;
import com.twc.remindermodule.utils.Utils;

import java.util.ArrayList;

import static com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions.withCrossFade;

public class RecommendedMyHabitAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {


    ArrayList<MyHabitResponse.MyHabitItem> myHabitList;
    RecommendedMyHabitsFragment mFragment;
    private String token;
    private String waterIntake;
    private Activity mActivity;
    private String connectedDevice;

    public RecommendedMyHabitAdapter(Activity activity, ArrayList<MyHabitResponse.MyHabitItem> arrListMyHabit, RecommendedMyHabitsFragment recommendedMyHabits, Bundle arguments) {

        this.mActivity = activity;
        this.myHabitList = arrListMyHabit;
        this.mFragment = recommendedMyHabits;
        token = arguments.getString("token");
        waterIntake = arguments.getString("waterIntake");
        connectedDevice = arguments.getString("connectedDevice");
    }


    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.row_my_habit, parent, false);
        return new ItemViewHolder(itemView);

    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, final int position) {
        final ItemViewHolder itemViewHolder = (ItemViewHolder) holder;

        itemViewHolder.tvHabitName.setText(myHabitList.get(position).getTitle());

        GlideConfig.getInstance().getImageLoader().load(myHabitList.get(position).getImagePath()).transition(withCrossFade()).into(itemViewHolder.ivHabit);

        itemViewHolder.checkBox.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int habitId = myHabitList.get(position).getHabitID();

                if (((CheckBox) view).isChecked()) {
                    mFragment.saveMemberHabitValueAPICall(habitId, true);
                } else {
                    mFragment.saveMemberHabitValueAPICall(habitId, false);
                }
            }
        });

        if (myHabitList.get(position).isIsTrackerBasedHabit()) {
            int progressPercentage = (int) myHabitList.get(position).getProgressPercentage();
            itemViewHolder.progressBar.setProgress(progressPercentage);
            itemViewHolder.tvProgressValue.setText(progressPercentage + "%");
            itemViewHolder.progressBar.setVisibility(View.VISIBLE);
            itemViewHolder.tvProgressValue.setVisibility(View.VISIBLE);
            itemViewHolder.checkBox.setVisibility(View.INVISIBLE);
        } else {
            itemViewHolder.progressBar.setVisibility(View.INVISIBLE);
            itemViewHolder.tvProgressValue.setVisibility(View.INVISIBLE);
            itemViewHolder.checkBox.setVisibility(View.VISIBLE);

            int progress = (int) myHabitList.get(position).getProgressPercentage();
            if (progress == 1)
                itemViewHolder.checkBox.setChecked(true);
            else if (progress == 0)
                itemViewHolder.checkBox.setChecked(false);
        }

        String day = DateFactory.getInstance().getTodayDate("EEEE");

        for (int i = 0; i < myHabitList.get(position).getWeeklyProgressList().size(); i++) {

            if (day.equalsIgnoreCase(myHabitList.get(position).getWeeklyProgressList().get(i).getDayOfWeek())) {
                if (day.equalsIgnoreCase("Monday"))
                    setColorCurrentDay(itemViewHolder.tvMon, myHabitList.get(position).getWeeklyProgressList().get(i).isProgress());
                else if (day.equalsIgnoreCase("Tuesday"))
                    setColorCurrentDay(itemViewHolder.tvTue, myHabitList.get(position).getWeeklyProgressList().get(i).isProgress());
                else if (day.equalsIgnoreCase("Wednesday"))
                    setColorCurrentDay(itemViewHolder.tvWed, myHabitList.get(position).getWeeklyProgressList().get(i).isProgress());
                else if (day.equalsIgnoreCase("Thursday"))
                    setColorCurrentDay(itemViewHolder.tvThus, myHabitList.get(position).getWeeklyProgressList().get(i).isProgress());
                else if (day.equalsIgnoreCase("Friday"))
                    setColorCurrentDay(itemViewHolder.tvFri, myHabitList.get(position).getWeeklyProgressList().get(i).isProgress());
                else if (day.equalsIgnoreCase("Saturday"))
                    setColorCurrentDay(itemViewHolder.tvSat, myHabitList.get(position).getWeeklyProgressList().get(i).isProgress());
                else if (day.equalsIgnoreCase("Sunday"))
                    setColorCurrentDay(itemViewHolder.tvSun, myHabitList.get(position).getWeeklyProgressList().get(i).isProgress());

                break;
            } else {
                if (i == 0)
                    setColor(itemViewHolder.tvMon, myHabitList.get(position).getWeeklyProgressList().get(i).isProgress());
                else if (i == 1)
                    setColor(itemViewHolder.tvTue, myHabitList.get(position).getWeeklyProgressList().get(i).isProgress());
                else if (i == 2)
                    setColor(itemViewHolder.tvWed, myHabitList.get(position).getWeeklyProgressList().get(i).isProgress());
                else if (i == 3)
                    setColor(itemViewHolder.tvThus, myHabitList.get(position).getWeeklyProgressList().get(i).isProgress());
                else if (i == 4)
                    setColor(itemViewHolder.tvFri, myHabitList.get(position).getWeeklyProgressList().get(i).isProgress());
                else if (i == 5)
                    setColor(itemViewHolder.tvSat, myHabitList.get(position).getWeeklyProgressList().get(i).isProgress());
                else if (i == 6)
                    setColor(itemViewHolder.tvSun, myHabitList.get(position).getWeeklyProgressList().get(i).isProgress());

            }
        }


    }


    @Override
    public int getItemCount() {
        return myHabitList.size();
    }

    private void setColorCurrentDay(TextView tv, boolean progress) {
        GradientDrawable bg = (GradientDrawable) tv.getBackground().mutate();
        tv.setTextColor(ContextCompat.getColor(mActivity, R.color.color_FFFFFF));
        if (progress)
            bg.setColor(ContextCompat.getColor(mActivity, R.color.color_28bcca));
        else
            bg.setColor(ContextCompat.getColor(mActivity, R.color.color_f5a623));

    }

    private void setColor(TextView tv, boolean progress) {

        GradientDrawable bg = (GradientDrawable) tv.getBackground().mutate();
        tv.setTextColor(ContextCompat.getColor(mActivity, R.color.color_FFFFFF));
        if (progress)
            bg.setColor(ContextCompat.getColor(mActivity, R.color.color_28bcca));
        else
            bg.setColor(ContextCompat.getColor(mActivity, R.color.color_fa6161));

    }

    private void navigationOfStepsTracker() {
        Intent intent = null;
        try {
            intent = new Intent(mActivity, Class.forName("com.truworth.wellnesscorner.ui.step.StepActivity"));

        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }


        if (connectedDevice != null && connectedDevice.length() > 0) {
          /* StepUser stepUser = new StepUser("0", "", "",
                            "bearer " + token);
                    MainStepConfig.init("Wellness", "http://demo.truworth.net/twcmobileapi/", stepUser, false);
*/
            switch (connectedDevice) {
                case Constant.FITBIT:
                    intent.putExtra("connectedDevice", Constant.FITBIT);
                    // stepsTrackerFragment.setConnectedDeviceType(Constant.FITBIT);
                    break;
                case Constant.S_HEALTH:
                    //  stepsTrackerFragment.setConnectedDeviceType(Constant.S_HEALTH);
                    intent.putExtra("connectedDevice", Constant.S_HEALTH);
                    break;
                case Constant.GOOGLE_FIT:
                    //  stepsTrackerFragment.setConnectedDeviceType(Constant.GOOGLE_FIT);
                    intent.putExtra("connectedDevice", Constant.GOOGLE_FIT);
                    break;
                case Constant.E_FIT:
                    // stepsTrackerFragment.setConnectedDeviceType(Constant.E_FIT);
                    intent.putExtra("connectedDevice", Constant.E_FIT);
                    break;
                case Constant.MISFIT:
                    //stepsTrackerFragment.setConnectedDeviceType(Constant.MISFIT);
                    //   intent.putExtra("connectedDevice", Constant.MISFIT);
                    break;
                case Constant.GARMIN:
                    // stepsTrackerFragment.setConnectedDeviceType(Constant.GARMIN);
                    /*   intent.putExtra("connectedDevice", Constant.GARMIN);*/
                    break;
            }
            //  Utils.replaceFragment(mActivity.getFragmentManager(), stepsTrackerFragment, StepsTrackerFragment.class.getSimpleName(), true, R.id.fragmentContainer);
            mActivity.startActivity(intent);
        } else {
            intent.putExtra("connectedDevice", "");
            mActivity.startActivity(intent);
            // Utils.replaceFragment(mActivity.getFragmentManager(), ConnectDeviceListFragment.newInstance(null), ConnectDeviceListFragment.class.getSimpleName(), true, R.id.fragmentContainer);

        }
    }

    // ItemViewHolder Class for Items in each Section
    public class ItemViewHolder extends RecyclerView.ViewHolder {


        private final TextView tvHabitName, tvMon, tvTue, tvWed, tvThus, tvFri, tvSat, tvSun, tvProgressValue;
        ProgressBar progressBar;
        CheckBox checkBox;
        ImageView ivHabit;

        public ItemViewHolder(View itemView) {
            super(itemView);

            ivHabit = itemView.findViewById(R.id.ivHabit);
            tvHabitName = itemView.findViewById(R.id.tvHabitName);
            tvMon = itemView.findViewById(R.id.imgMon);
            tvTue = itemView.findViewById(R.id.imgTue);
            tvWed = itemView.findViewById(R.id.imgWed);
            tvThus = itemView.findViewById(R.id.imgThus);
            tvFri = itemView.findViewById(R.id.imgFri);
            tvSat = itemView.findViewById(R.id.imgSat);
            tvSun = itemView.findViewById(R.id.imgSun);
            progressBar = itemView.findViewById(R.id.progressBar);
            tvProgressValue = itemView.findViewById(R.id.tvProgressValue);
            checkBox = itemView.findViewById(R.id.checkBox);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Bundle bundle = new Bundle();

                    // check habit ids hardcoded  as suggested
                    // 2=water,1= step,4=food,5 =activity,6= sleep
                    if (myHabitList.get(getAdapterPosition()).getHabitID() == 2) {

                        DailyLogConfig.dailyLogUser.setType("");
                        DailyLogConfig.dailyLogUser.setMealType("");

                        Intent intent = new Intent(mActivity, WaterActivity.class);
                        intent.putExtra("waterIntake", waterIntake);
                        mActivity.startActivity(intent);
                    } else if (myHabitList.get(getAdapterPosition()).getHabitID() == 1) {
                        navigationOfStepsTracker();
                    } else if (myHabitList.get(getAdapterPosition()).getHabitID() == 4) {
                       /* WellnessCornerApp.getInstance().setTrackDate(DateFactory.getInstance().getTodayDate("MM/dd/yyyy"));

                        bundle.putString("trackMealType", mActivity.getString(R.string.breakfast));
                        Utils.replaceFragment(mActivity.getFragmentManager(), TrackMealFragment.newInstance(bundle), TrackMealFragment.class.getSimpleName(), true, R.id.fragmentContainer);*/

                        DailyLogConfig.dailyLogUser.setType("Meal");
                        DailyLogConfig.dailyLogUser.setMealType("Breakfast");
                        Intent intent = new Intent(mActivity, MealActivity.class);
                        mActivity.startActivity(intent);
                    } else if (myHabitList.get(getAdapterPosition()).getHabitID() == 5) {

                      /*  WellnessCornerApp.getInstance().setTrackDate(DateFactory.getInstance().getTodayDate("MM/dd/yyyy"));
                        Utils.replaceFragment(mActivity.getFragmentManager(), TrackExerciseFragment.newInstance(), TrackExerciseFragment.class.getSimpleName(), true, R.id.fragmentContainer);*/

                        DailyLogConfig.dailyLogUser.setType("Exercise");
                        DailyLogConfig.dailyLogUser.setMealType("");


                        Intent intent = new Intent(mActivity, MealActivity.class);
                        mActivity.startActivity(intent);
                    }
                     else if (myHabitList.get(getAdapterPosition()).getHabitID() == 6) {

                       // WellnessCornerApp.getInstance().setTrackDate(DateFactory.getInstance().getTodayDate("MM/dd/yyyy"));
                        Utils.replaceFragment(mActivity.getFragmentManager(), new SleepTrackerLogsFragment(), SleepTrackerLogsFragment.class.getSimpleName(), true, R.id.fragmentContainerReminder);
                    }
                }
            });
        }

    }
}