package com.twc.store.fragments;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.twc.store.R;
import com.twc.store.R2;
import com.twc.store.StoreActivity;
import com.twc.store.StoreCategoryActivity;
import com.twc.store.adapter.WellnessProductListingAdapter;
import com.twc.store.model.beans.ProductItem;
import com.twc.store.model.requestbody.BaseMemberIdBody;
import com.twc.store.model.response.StoreCartCountResponse;
import com.twc.store.rest.RestClient;
import com.twc.store.utils.DialogFactory;
import com.twc.store.utils.StoreConfig;
import com.twc.store.utils.Utils;
import com.twc.store.views.NoDataView;

import java.util.ArrayList;
import java.util.Locale;

import butterknife.BindView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by GurvinderS on 5/3/2017.
 */

public class StoreProductListingFragment extends BaseFragment {
    private static final String BUNDLE_KEY_TITLE = "TITLE";
    private static final String BUNDLE_KEY_PARCELABLE_LIST = "PARCELABLE_LIST";
    @BindView(R2.id.rvWellnessPlan)
    RecyclerView rvWellnessPlan;
    @BindView(R2.id.noDataView)
    NoDataView noDataView;

    private WellnessProductListingAdapter wellnessProductListingAdapter;
    private TextView tvBadge;
    private ArrayList<ProductItem> productList;
    private String title = "";

    private Button notificationButton;
    private ImageView imgpendingFriend;
    private int cartItemCount;

    public static StoreProductListingFragment newInstance(String title, ArrayList<ProductItem> productList) {
        Bundle args = new Bundle();
        args.putString(BUNDLE_KEY_TITLE, title);
        args.putParcelableArrayList(BUNDLE_KEY_PARCELABLE_LIST, productList);
        StoreProductListingFragment fragment = new StoreProductListingFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (getArguments() != null) {
            if (getArguments().containsKey(BUNDLE_KEY_TITLE) && getArguments().containsKey(BUNDLE_KEY_PARCELABLE_LIST)) {
                title = getArguments().getString(BUNDLE_KEY_TITLE);
                productList = getArguments().getParcelableArrayList(BUNDLE_KEY_PARCELABLE_LIST);
            }
        } else {
            if(getActivity() instanceof StoreActivity)
            ((StoreActivity) getActivity()).setToolBarTitle("");
            else  if(getActivity() instanceof StoreCategoryActivity)
                ((StoreCategoryActivity) getActivity()).setToolBarTitle("");
        }

    }

    @Override
    public void onResume() {
        super.onResume();
        if(getActivity() instanceof StoreActivity) {
            ((StoreActivity) getActivity()).showHomeAsUpEnableToolbar();
            ((StoreActivity) getActivity()).setToolBarTitle(title);
        }else if(getActivity() instanceof StoreCategoryActivity) {
            ((StoreCategoryActivity) getActivity()).showHomeAsUpEnableToolbar();
            ((StoreCategoryActivity) getActivity()).setToolBarTitle(title);
        }
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        inflater.inflate(R.menu.menu_save, menu);
        MenuItem menuItemRefresh = menu.findItem(R.id.action_save);

        menuItemRefresh = menuItemRefresh.setActionView(R.layout.pending_request_count);
        menuItemRefresh.setTitle("Notification");

        View view = menuItemRefresh.getActionView();
        RelativeLayout rlayout = view.findViewById(R.id.rlayout);
        notificationButton = view.findViewById(R.id.notif_count);
        imgpendingFriend = view.findViewById(R.id.imgpendingFriend);
        imgpendingFriend.setImageResource(R.drawable.ic_store_cartcount);

        notificationButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Utils.replaceFragment(getFragmentManager(), StoreMyCartFragment.newInstance(), StoreMyCartFragment.class.getSimpleName(), true, R.id.fragmentContainer);
            }
        });
        imgpendingFriend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               Utils.replaceFragment(getFragmentManager(), StoreMyCartFragment.newInstance(), StoreMyCartFragment.class.getSimpleName(), true, R.id.fragmentContainer);
            }
        });

    }

    @Override
    public int getFragmentLayout() {
        return R.layout.fragment_wellness_product_listing;
    }

    @Override
    public void onFragmentReady() {
        setHasOptionsMenu(true);
        rvWellnessPlan.setHasFixedSize(true);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getActivity());
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        rvWellnessPlan.setLayoutManager(linearLayoutManager);

        getCartCountApiCall();

        if (productList != null && productList.size() > 0) {
            // title will be either Constant.HEALTH_PRODUCT or Constant.Wellness_Plan
            wellnessProductListingAdapter = new WellnessProductListingAdapter(getActivity(), productList, title);
            rvWellnessPlan.setAdapter(wellnessProductListingAdapter);
        } else {
            noDataView.setVisibility(View.VISIBLE);
            rvWellnessPlan.setVisibility(View.GONE);
        }
    }

    /*  @Override
      public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
          inflater.inflate(R.menu.menu_wellness_plans, menu);
          final View menu_cart = menu.findItem(R.id.action_cart).getActionView();
          tvBadge = (TextView) menu_cart.findViewById(R.id.tvBadge);
          // updateCount(4);
          super.onCreateOptionsMenu(menu, inflater);

      }


      @Override
      public boolean onOptionsItemSelected(MenuItem item) {
          switch (item.getItemId()) {
              case R.id.action_cart:

                  break;
          }
          return super.onOptionsItemSelected(item);
      }
  */
    public void updateCount(final int number) {

        if (tvBadge == null) {
            return;
        }
        getActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (number == 0) {
                    tvBadge.setVisibility(View.INVISIBLE);
                } else {
                    tvBadge.setVisibility(View.VISIBLE);
                    tvBadge.setText(String.valueOf(number));
                }
            }
        });
    }

    private void displayCartItemCount() {
        notificationButton.setVisibility(View.GONE);
        imgpendingFriend.setVisibility(View.VISIBLE);

        if (cartItemCount > 0) {
            notificationButton.setVisibility(View.VISIBLE);
            if (cartItemCount > 99) {
                notificationButton.setText("99+");
            } else {
                notificationButton.setText(String.format(Locale.getDefault(), "%d", cartItemCount));
            }
        }
    }

    private void getCartCountApiCall() {

        //body
        BaseMemberIdBody baseMemberIdBody = new BaseMemberIdBody();
        baseMemberIdBody.setMemberID(StoreConfig.storeUser.getMemberId());
        RestClient restClient = new RestClient(getActivity(),StoreConfig.BASE_URL, StoreConfig.mdebug);

     restClient.getStoreService().getCartCount(baseMemberIdBody).enqueue(new Callback<StoreCartCountResponse>() {
            @Override
            public void onResponse(Call<StoreCartCountResponse> call, Response<StoreCartCountResponse> response) {

                if (isAdded() && getActivity() != null) {
                    if (response != null && response.body() != null) {
                        if (response.body().getStatus() == 0) {
                            cartItemCount = response.body().getData();
                            displayCartItemCount();
                        } else {
                            DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_response_failure), getString(R.string.str_ok), false);
                        }
                    } else {
                        DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_response_null), getString(R.string.str_ok), false);
                    }
                }
            }

            @Override
            public void onFailure(Call<StoreCartCountResponse> call, Throwable t) {
                if (isAdded() && getActivity() != null) {
                    DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_failure), getString(R.string.str_ok), false);
                }
            }
        });
    }
}
