package com.twc.store.model.response;



import com.twc.store.model.beans.BillingInfoBean;

import java.util.List;

/**
 * Created by GurvinderS on 9/18/2017.
 */

public class StoreCheckoutResponse {


    /**
     * status : 0
     * Data : {"personalInfo":{"Name":"nidhi mishra","Email":"nidhi.mishra@truworth.com"},"billingInfo":{"MemberBilling_ID":1193,"Name":"nm nm","PhoneNo":"9568321448","Address1":"test","Address2":"test","City":"test","State":"RAJASTHAN","Country":"India","Pincode":"302001"},"cart":[{"CartId":4292,"BasePrice":1200,"NewBasePrice":1200,"TaxAmount":251.88,"NewTaxAmount":251.88,"IsPriceUpdate":false,"IsInStock":true},{"CartId":4291,"BasePrice":999,"NewBasePrice":999,"TaxAmount":179.82,"NewTaxAmount":179.82,"IsPriceUpdate":false,"IsInStock":true}]}
     */

    private int status;
    private DataBean Data;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public DataBean getData() {
        return Data;
    }

    public void setData(DataBean Data) {
        this.Data = Data;
    }

    public static class DataBean {
        /**
         * personalInfo : {"Name":"nidhi mishra","Email":"nidhi.mishra@truworth.com"}
         * billingInfo : {"MemberBilling_ID":1193,"Name":"nm nm","PhoneNo":"9568321448","Address1":"test","Address2":"test","City":"test","State":"RAJASTHAN","Country":"India","Pincode":"302001"}
         * cart : [{"CartId":4292,"BasePrice":1200,"NewBasePrice":1200,"TaxAmount":251.88,"NewTaxAmount":251.88,"IsPriceUpdate":false,"IsInStock":true},{"CartId":4291,"BasePrice":999,"NewBasePrice":999,"TaxAmount":179.82,"NewTaxAmount":179.82,"IsPriceUpdate":false,"IsInStock":true}]
         */

        private PersonalInfoBean personalInfo;
        private BillingInfoBean billingInfo;
        private List<CartBean> cart;

        public double getWellCashAvailable() {
            return wellCashAvailable;
        }

        public void setWellCashAvailable(double wellCashAvailable) {
            this.wellCashAvailable = wellCashAvailable;
        }

        private double wellCashAvailable;

        public PersonalInfoBean getPersonalInfo() {
            return personalInfo;
        }

        public void setPersonalInfo(PersonalInfoBean personalInfo) {
            this.personalInfo = personalInfo;
        }

        public BillingInfoBean getBillingInfo() {
            return billingInfo;
        }

        public void setBillingInfo(BillingInfoBean billingInfo) {
            this.billingInfo = billingInfo;
        }

        public List<CartBean> getCart() {
            return cart;
        }

        public void setCart(List<CartBean> cart) {
            this.cart = cart;
        }

        public static class PersonalInfoBean {
            /**
             * Name : nidhi mishra
             * Email : nidhi.mishra@truworth.com
             */

            private String Name;
            private String Email;

            public String getName() {
                return Name;
            }

            public void setName(String Name) {
                this.Name = Name;
            }

            public String getEmail() {
                return Email;
            }

            public void setEmail(String Email) {
                this.Email = Email;
            }
        }



        public static class CartBean {
            /**
             * CartId : 4292
             * BasePrice : 1200.0
             * NewBasePrice : 1200.0
             * TaxAmount : 251.88
             * NewTaxAmount : 251.88
             * IsPriceUpdate : false
             * IsInStock : true
             */

            private int CartId;
            private double BasePrice;
            private double NewBasePrice;
            private double TaxAmount;
            private double NewTaxAmount;
            private boolean IsPriceUpdate;
            private boolean IsInStock;

            public int getCartId() {
                return CartId;
            }

            public void setCartId(int CartId) {
                this.CartId = CartId;
            }

            public double getBasePrice() {
                return BasePrice;
            }

            public void setBasePrice(double BasePrice) {
                this.BasePrice = BasePrice;
            }

            public double getNewBasePrice() {
                return NewBasePrice;
            }

            public void setNewBasePrice(double NewBasePrice) {
                this.NewBasePrice = NewBasePrice;
            }

            public double getTaxAmount() {
                return TaxAmount;
            }

            public void setTaxAmount(double TaxAmount) {
                this.TaxAmount = TaxAmount;
            }

            public double getNewTaxAmount() {
                return NewTaxAmount;
            }

            public void setNewTaxAmount(double NewTaxAmount) {
                this.NewTaxAmount = NewTaxAmount;
            }

            public boolean isIsPriceUpdate() {
                return IsPriceUpdate;
            }

            public void setIsPriceUpdate(boolean IsPriceUpdate) {
                this.IsPriceUpdate = IsPriceUpdate;
            }

            public boolean isIsInStock() {
                return IsInStock;
            }

            public void setIsInStock(boolean IsInStock) {
                this.IsInStock = IsInStock;
            }
        }
    }
}
