package com.truworth.wellnesscorner.ui.mainapp.post.postcomment;

import android.databinding.ObservableBoolean;
import android.databinding.ObservableField;
import android.databinding.ObservableInt;
import android.text.Editable;
import android.text.TextWatcher;

import com.truworth.wellnesscorner.TheWellnessCornerApp;
import com.truworth.wellnesscorner.base.BaseViewModel;
import com.truworth.wellnesscorner.model.CommentListData;
import com.truworth.wellnesscorner.model.Post;
import com.truworth.wellnesscorner.repo.DashboardRepository;
import com.truworth.wellnesscorner.repo.model.request.CommentRequest;
import com.truworth.wellnesscorner.repo.model.request.GetCommentsListRequest;
import com.truworth.wellnesscorner.repo.model.response.GetCommentsListResponse;
import com.truworth.wellnesscorner.repo.model.response.SaveCommentResponse;
import com.truworth.wellnesscorner.utils.SingleLiveEvent;

import java.util.List;

import javax.inject.Inject;

import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;

public class PostCommentViewModel extends BaseViewModel {

    public ObservableField<String> errorMessage = new ObservableField<>();
    public ObservableBoolean isEnablePost = new ObservableBoolean();
    public ObservableField<String> postComment = new ObservableField<>();
    public SingleLiveEvent<List<CommentListData>> commentListData = new SingleLiveEvent<>();
    public SingleLiveEvent<Void> removeLoading = new SingleLiveEvent<>();
    public SingleLiveEvent<Integer> saveComment = new SingleLiveEvent<>();
    public ObservableBoolean isProgress=new ObservableBoolean();
    Post post;
    @Inject
    DashboardRepository dashboardRepository;

    public PostCommentViewModel() {
        TheWellnessCornerApp.getApp().component().inject(this);
    }

    public ObservableField<String> getPostComment() {
        return postComment;
    }

    public SingleLiveEvent<List<CommentListData>> getCommentListData() {
        return commentListData;
    }

    public SingleLiveEvent<Void> getRemoveLoading() {
        return removeLoading;
    }

    public SingleLiveEvent<Integer> getSaveComment() {
        return saveComment;
    }

    public void getCommentList(int pageIndex) {
        setIsLoading(true);
        isProgress.set(true);
        GetCommentsListRequest commentsListRequest = new GetCommentsListRequest();
        commentsListRequest.setPageIndex(pageIndex);
        commentsListRequest.setPageSize(10);
        commentsListRequest.setId(post.getPostIdentity());
        dashboardRepository.getComments(commentsListRequest).subscribe(new Observer<GetCommentsListResponse>() {
            @Override
            public void onSubscribe(Disposable d) {

            }

            @Override
            public void onNext(GetCommentsListResponse commentsListResponse) {
                if (!commentsListResponse.isHasError()) {
                    if (commentsListResponse.getData() != null && commentsListResponse.getData().size() > 0) {
                        setIsLoading(false);
                        isProgress.set(false);
                        //set data in list pagewise
                        commentListData.setValue(commentsListResponse.getData());
                    } else {
                        isProgress.set(false);
                        setIsLoading(false);
                    }
                } else {
                    isProgress.set(false);
                    setIsLoading(false);
                    errorMessage.set(commentsListResponse.getError().getMessage());
                }
            }

            @Override
            public void onError(Throwable e) {
                setIsLoading(false);
            }

            @Override
            public void onComplete() {

            }
        });
    }

    public void saveCommentApi() {
        isEnablePost.set(false);

        CommentRequest commentRequest = new CommentRequest();
        commentRequest.setComments(postComment.get());
        commentRequest.setId(post.getPostIdentity());

        dashboardRepository.saveComment(commentRequest).subscribe(new Observer<SaveCommentResponse>() {
            @Override
            public void onSubscribe(Disposable d) {

            }

            @Override
            public void onNext(SaveCommentResponse saveCommentResponse) {
                if (!saveCommentResponse.isHasError()) {
                    postComment.set("");
                    // Toast.makeText(view.getContext(),"comment save successfully",Toast.LENGTH_SHORT).show();
                    saveComment.setValue(saveCommentResponse.getData().getTotalComments());
                    getCommentList(1);

                } else {
                    errorMessage.set(saveCommentResponse.getError().getMessage());
                }
            }

            @Override
            public void onError(Throwable e) {

            }

            @Override
            public void onComplete() {

            }
        });
    }

    public TextWatcher commentWatcher() {
        return new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if (charSequence.toString().trim().length() <= 0) {
                    isEnablePost.set(false);
                } else
                    isEnablePost.set(true);
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        };
    }

    public void setPost(Post post) {
        this.post = post;
    }
}
