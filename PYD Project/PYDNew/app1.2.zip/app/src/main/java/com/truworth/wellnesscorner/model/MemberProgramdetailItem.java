package com.truworth.wellnesscorner.model;

import java.util.List;

/**
 * Created by PalakC on 2/21/2018.
 */

public class MemberProgramdetailItem {
    private int TaskStatus;
    private MemberProgramItem Progarm;
    private List<MemberProgramTaskDetailItem> TaskDetail;

    public int getTaskStatus() {
        return TaskStatus;
    }

    public void setTaskStatus(int taskStatus) {
        TaskStatus = taskStatus;
    }

    public MemberProgramItem getProgarm() {
        return Progarm;
    }

    public void setProgarm(MemberProgramItem Progarm) {
        this.Progarm = Progarm;
    }

    public List<MemberProgramTaskDetailItem> getTaskDetail() {
        return TaskDetail;
    }

    public void setTaskDetail(List<MemberProgramTaskDetailItem> TaskDetail) {
        this.TaskDetail = TaskDetail;
    }
}
