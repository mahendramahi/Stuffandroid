package com.twc.store.model.requestbody;

/**
 * Created by GurvinderS on 5/9/2017.
 */

public class StoreProductDetailBody {

    private String MemberID;
    private int ProductID;
    private String Sku;

    public String getMemberID() {
        return MemberID;
    }

    public void setMemberID(String memberID) {
        MemberID = memberID;
    }

    public int getProductId() {
        return ProductID;
    }

    public void setProductId(int productId) {
        this.ProductID = productId;
    }

    public String getSku() {
        return Sku;
    }

    public void setSku(String sku) {
        Sku = sku;
    }

}
