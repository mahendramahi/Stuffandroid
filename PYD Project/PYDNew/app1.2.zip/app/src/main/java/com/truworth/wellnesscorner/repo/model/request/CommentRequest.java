package com.truworth.wellnesscorner.repo.model.request;

public class CommentRequest extends BaseRequest {
    private String Comments;

    public String getComments() {
        return Comments;
    }

    public void setComments(String Comments) {
        this.Comments = Comments;
    }
}
