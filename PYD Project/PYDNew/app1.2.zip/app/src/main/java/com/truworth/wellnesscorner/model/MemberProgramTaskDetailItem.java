package com.truworth.wellnesscorner.model;

import java.util.List;

/**
 * Created by PalakC on 2/21/2018.
 */

public class MemberProgramTaskDetailItem {

    private int MemberPID;
    private int WorkshopLevel_Day;
    private boolean IsCompleted;
    private String ItemType;
    private String ProgramName;
    private int ID;
    private String ItemName;
    private String ItemDesc;
    private String ItemImageName;
    private int ItemPoints;
    private int WorkshopLevel_ID;
    private String URL;
    private List<OtherInfoItem> OtherInfo;

    public int getMemberPID() {
        return MemberPID;
    }

    public void setMemberPID(int MemberPID) {
        this.MemberPID = MemberPID;
    }

    public int getWorkshopLevel_Day() {
        return WorkshopLevel_Day;
    }

    public void setWorkshopLevel_Day(int WorkshopLevel_Day) {
        this.WorkshopLevel_Day = WorkshopLevel_Day;
    }

    public boolean getIsCompleted() {
        return IsCompleted;
    }

    public void setIsCompleted(boolean IsCompleted) {
        this.IsCompleted = IsCompleted;
    }

    public String getItemType() {
        return ItemType;
    }

    public void setItemType(String ItemType) {
        this.ItemType = ItemType;
    }

    public String getProgramName() {
        return ProgramName;
    }

    public void setProgramName(String ProgramName) {
        this.ProgramName = ProgramName;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getItemName() {
        return ItemName;
    }

    public void setItemName(String ItemName) {
        this.ItemName = ItemName;
    }

    public String getItemDesc() {
        return ItemDesc;
    }

    public void setItemDesc(String ItemDesc) {
        this.ItemDesc = ItemDesc;
    }

    public String getItemImageName() {
        return ItemImageName;
    }

    public void setItemImageName(String ItemImageName) {
        this.ItemImageName = ItemImageName;
    }

    public int getItemPoints() {
        return ItemPoints;
    }

    public void setItemPoints(int ItemPoints) {
        this.ItemPoints = ItemPoints;
    }

    public int getWorkshopLevel_ID() {
        return WorkshopLevel_ID;
    }

    public void setWorkshopLevel_ID(int WorkshopLevel_ID) {
        this.WorkshopLevel_ID = WorkshopLevel_ID;
    }

    public String getURL() {
        return URL;
    }

    public void setURL(String URL) {
        this.URL = URL;
    }

    public List<OtherInfoItem> getOtherInfo() {
        return OtherInfo;
    }

    public void setOtherInfo(List<OtherInfoItem> OtherInfo) {
        this.OtherInfo = OtherInfo;
    }

    public static class OtherInfoItem {
        private String key;
        private String value;

        public String getKey() {
            return key;
        }

        public void setKey(String key) {
            this.key = key;
        }

        public String getValue() {
            return value;
        }

        public void setValue(String value) {
            this.value = value;
        }
    }
}
