package com.truworth.wellnesscorner.ui.mainapp.today;

import android.app.Activity;
import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.content.ContextCompat;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import com.truworth.stepmodule.StepHelper;

import com.truworth.wellnesscorner.BR;
import com.truworth.wellnesscorner.R;
import com.truworth.wellnesscorner.TheWellnessCornerApp;
import com.truworth.wellnesscorner.base.BaseFragment;
import com.truworth.wellnesscorner.data.SharedPreferenceHelper;
import com.truworth.wellnesscorner.databinding.FragmentTodayBinding;
import com.truworth.wellnesscorner.interfaces.OnClickRefreshStep;
import com.truworth.wellnesscorner.interfaces.OnLoadMoreListener;
import com.truworth.wellnesscorner.model.Post;
import com.truworth.wellnesscorner.model.TodayDashBoardBean;
import com.truworth.wellnesscorner.model.TodayMyChallenge;
import com.truworth.wellnesscorner.model.TodayTrackerValue;
import com.truworth.wellnesscorner.repo.StepRepository;

import com.truworth.wellnesscorner.repo.model.response.TodayTrackerResponse;
import com.truworth.wellnesscorner.ui.mainapp.post.PostRecyclerAdapter;
import com.truworth.wellnesscorner.ui.mainapp.post.postcomment.PostCommentActivity;
import com.truworth.wellnesscorner.ui.mainapp.post.IPostListItem;

import com.truworth.wellnesscorner.ui.mytask.SwipeRevealLayout;
import com.truworth.wellnesscorner.utils.AppConstants;
import com.twc.remindermodule.ReminderHelper;
import com.twc.remindermodule.rest.ReminderConfig;

import java.util.ArrayList;

import java.util.List;

import javax.inject.Inject;

import im.ene.toro.PlayerSelector;
import im.ene.toro.exoplayer.ToroExo;
import im.ene.toro.widget.Container;

public class TodayFragment extends BaseFragment<FragmentTodayBinding, TodayDashBoardViewModel> implements OnClickRefreshStep, SwipeRefreshLayout.OnRefreshListener {
    final Handler handler = new Handler();
    private final int visibleThreshold = 5;
    @Inject
    StepRepository repository;
    @Inject
    SharedPreferenceHelper prefHelper;
    FragmentTodayBinding binding;
    TodayDashBoardViewModel viewModel;
    ArrayList<TodayTrackerValue> todayHabitList;
    ArrayList<IPostListItem> todayPostList;
    List<TodayMyChallenge> listTodayMyChallenge;
    Container recyclerView;
    PostRecyclerAdapter adapter;
    PlayerSelector selector = PlayerSelector.DEFAULT; // visible to user by default.
    TodayTrackerResponse todayTrackerResponse;
    TodayDashBoardBean todayDashBoardBean;//= new TodayDashBoardBean();
    boolean isLoadMore = false;
    boolean isUserVisibleHintCall = false;
    boolean _areDataLoaded = false;
    private String accessToken;
    private StepHelper stepHelper;
    private OnLoadMoreListener onLoadMoreListener;
    private int lastVisibleItem, totalItemCount;
    private Handler handlerTodayDashBoard = new Handler();
    private Runnable runnable = new Runnable() {
        @Override
        public void run() {
            if (prefHelper.getPrefKeyDeviceConnected() != null && prefHelper.getPrefKeyDeviceConnected().length() > 0) {
                if (prefHelper.getPrefKeyDeviceConnected().equalsIgnoreCase(AppConstants.FITBIT))
                    accessToken = prefHelper.getPrefKeyFitBitAccessToken();
                else if (prefHelper.getPrefKeyDeviceConnected().equalsIgnoreCase(AppConstants.MISFIT))
                    accessToken = prefHelper.getPrefKeyMisFitAccessToken();

                stepHelper = new StepHelper(getActivity(), accessToken);
                viewModel.fetchDeviceStepsData(getActivity(), stepHelper);

            } else {

                viewModel.getTodayTrackerValues(true);
            }
        }
    };

    public TodayFragment() {
        TheWellnessCornerApp.getApp().component().inject(this);
    }

    public static TodayFragment newInstance() {
        TodayFragment fragment = new TodayFragment();
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        ToroExo.with(getActivity()).getDefaultCreator();

        todayHabitList = new ArrayList<>();
        listTodayMyChallenge = new ArrayList<>();
        todayPostList = new ArrayList<>();
        todayDashBoardBean = new TodayDashBoardBean();
        setUpRecyclerView();
        setDataObserver();
        setUpArrowObserver();
        attachRemoveLoadingObserver();
        getViewDataBinding().swipeRefreshLayout.setColorSchemeColors(ContextCompat.getColor(getContext(),R.color.text_grey));
        getViewDataBinding().swipeRefreshLayout.setProgressViewOffset(true,80,150);
        getViewDataBinding().swipeRefreshLayout.setOnRefreshListener(this);
    }

    private void setUpRecyclerView() {
        recyclerView = getViewDataBinding().rvTodayDashboard;
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(linearLayoutManager);

        //todayPostList.add(todayDashBoardBean);
        adapter = new PostRecyclerAdapter(getActivity(), todayPostList, "", "", this);
        recyclerView.setAdapter(adapter);
        recyclerView.setCacheManager(adapter);
        setOnLoadMoreListener(linearLayoutManager);
        // FIXME Only use the following workaround when using this Fragment in ViewPager.
        boolean viewPagerMode = true;
        if (viewPagerMode) {
            recyclerView.setPlayerSelector(null);

            handler.postDelayed(() -> {
                if (recyclerView != null) recyclerView.setPlayerSelector(selector);
            }, 200);
        } else {
            recyclerView.setPlayerSelector(selector);
        }

    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        isUserVisibleHintCall = true;
        if (isVisibleToUser && !_areDataLoaded) {
            isLoadMore = false;

            handlerTodayDashBoard.postDelayed(runnable, 50);
            _areDataLoaded = true;
        } else {
            isUserVisibleHintCall = false;


        }
    }

    /*@Override
    public void onResume() {
        super.onResume();
        if (!isUserVisibleHintCall) {
            isLoadMore = false;

            handlerTodayDashBoard.postDelayed(runnable, 50);
            _areDataLoaded = true;
        }


    }*/


    @Override
    public int getBindingVariable() {
        return BR.viewModel;
    }

    @Override
    public int getLayoutId() {
        return R.layout.fragment_today;
    }

    @Override
    public TodayDashBoardViewModel getViewModel() {
        viewModel = ViewModelProviders.of(this).get(TodayDashBoardViewModel.class);

        return viewModel;
    }

    private void setDataObserver() {

        viewModel.getTodayTrackerResponse().observe(this, new Observer<TodayTrackerResponse>() {
            @Override
            public void onChanged(@Nullable TodayTrackerResponse trackerResponse) {
                todayTrackerResponse = trackerResponse;

                todayDashBoardBean.setTodayTrackerValues(todayTrackerResponse.getData().getTrackers());

                todayDashBoardBean.setHabitStatus(todayTrackerResponse.getData().getHabitStatus());
                todayDashBoardBean.setMyTask(todayTrackerResponse.getData().getMyTask());

                if (todayPostList.size() == 0) {
                    todayPostList.add(todayDashBoardBean);

                    adapter.notifyDataSetChanged();
                } else {
                    todayPostList.set(0, todayDashBoardBean);

                    adapter.notifyItemChanged(0);
                }

                syncHabitReminder(todayDashBoardBean);
            }
        });

        viewModel.getTodayMyChallenge().observe(this, new Observer<List<TodayMyChallenge>>() {
            @Override
            public void onChanged(@Nullable List<TodayMyChallenge> list) {

                listTodayMyChallenge = list;
                if (list != null) {
                    todayDashBoardBean.setListTodayMyChallenge(listTodayMyChallenge);
                }

                if (todayPostList.size() == 0) {
                    todayPostList.add(todayDashBoardBean);

                    adapter.notifyDataSetChanged();
                } else {
                    todayPostList.set(0, todayDashBoardBean);

                    adapter.notifyItemChanged(0);
                }


            }
        });

        viewModel.getTodayPosts().observe(this, new Observer<List<Post>>() {
            @Override
            public void onChanged(@Nullable List<Post> list) {
                if (!isLoadMore) {
                    if (todayPostList.size() > 1) {
                        todayPostList.subList(1, todayPostList.size()).clear();
                        todayPostList.addAll(1, list);
                        adapter.notifyDataSetChanged();                       // recyclerView.setAdapter(adapter);

                    } else {
                        todayPostList.addAll(list);
                        adapter.notifyDataSetChanged();

                    }
                } else {
                    todayPostList.addAll(list);
                    adapter.notifyDataSetChanged();
                    isLoadMore = false;
                }


            }
        });


    }

    private void setOnLoadMoreListener(final LinearLayoutManager linearLayoutManager) {
        onLoadMoreListener = new OnLoadMoreListener() {
            @Override
            public void onLoadMore() {
                if (!viewModel.isLastResult) {
                    if (todayPostList != null && todayPostList.size() > 5) {
                        todayPostList.add(null);
                        adapter.notifyItemInserted(todayPostList.size() - 1);
                        recyclerView.getLayoutManager().scrollToPosition(todayPostList.size());
                        viewModel.page = viewModel.page + 1;
                        isLoadMore = true;
                        viewModel.getTodayPost();
                    }
                }
            }
        };


        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                totalItemCount = linearLayoutManager.getItemCount();
                lastVisibleItem = linearLayoutManager.findLastVisibleItemPosition();
                if (!viewModel.loading && totalItemCount <= (lastVisibleItem + visibleThreshold)) {

                    onLoadMoreListener.onLoadMore();
                    viewModel.loading = true;
                }


            }
        });


    }

    private void attachRemoveLoadingObserver() {
        viewModel.getRemoveLoading().observe(this, new Observer<Void>() {
            @Override
            public void onChanged(@Nullable Void aVoid) {
                //Success, update UI
                if (todayPostList.size() > 0 && todayPostList.get(todayPostList.size() - 1) == null) {
                    todayPostList.remove(todayPostList.size() - 1);
                    adapter.notifyDataSetChanged();
                }

            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        isUserVisibleHintCall = false;
        _areDataLoaded = false;
        if (handlerTodayDashBoard != null) {
            handlerTodayDashBoard.removeCallbacks(runnable);
        }
    }

    @Override
    public void onStop() {
        super.onStop();
        isUserVisibleHintCall = false;
        _areDataLoaded = false;
        if (handlerTodayDashBoard != null) {
            handlerTodayDashBoard.removeCallbacks(runnable);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
    }

    @Override
    public void onDetach() {
        super.onDetach();
    }


    private void setUpArrowObserver() {
      /*  viewModel.getUpArrow().observe(this, new Observer<Void>() {
            @Override
            public void onChanged(@Nullable Void avoid) {
               // getViewDataBinding().nsView.fling(0);
              //  getViewDataBinding().nsView.smoothScrollTo(0, 0);
                getViewDataBinding().imgUpArrow.setVisibility(View.GONE);
            }
        });*/


    }

    @Override
    public void onClickRefresh() {

        isLoadMore = false;

        handlerTodayDashBoard.postDelayed(runnable, 50);
        _areDataLoaded = true;

    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == Activity.RESULT_OK) {

            if (requestCode == AppConstants.CALL_MODULE_REQUEST) {
                viewModel.getTodayTrackerValues(false);
            }   else if (requestCode == PostCommentActivity.REQUEST_CODE) {
                int position = data.getIntExtra(PostCommentActivity.INDEX, 0);
                Post post = (Post) data.getSerializableExtra(PostCommentActivity.POST);
                todayPostList.remove(position);
                todayPostList.add(position, post);
                adapter.notifyItemChanged(position);
            }
        }
    }

    @Override
    public void onRefresh() {
        viewModel.isSwipeRefresh.set(true);
        handlerTodayDashBoard.postDelayed(runnable, 50);
    }

    private void syncHabitReminder(TodayDashBoardBean todayDashBoardBean) {
        if (prefHelper.getLastReminderUpdate() != null) {
            if (todayDashBoardBean != null && todayDashBoardBean.getHabitStatus() != null && todayDashBoardBean.getHabitStatus().getHabitReminderUpdateDate()!=null) {

                if (!prefHelper.getLastReminderUpdate().equalsIgnoreCase(todayDashBoardBean.getHabitStatus().getHabitReminderUpdateDate())) {
                    ReminderHelper helper=new ReminderHelper(getActivity());
                    helper.getHabitReminderApiCall();
                }
            } else {
                ReminderHelper helper=new ReminderHelper(getActivity());
                helper.getHabitReminderApiCall();
            }
        } else {
            ReminderHelper helper=new ReminderHelper(getActivity());
            helper.getHabitReminderApiCall();
        }
        prefHelper.setLastReminderUpdate(todayDashBoardBean.getHabitStatus().getHabitReminderUpdateDate());
    }
}
