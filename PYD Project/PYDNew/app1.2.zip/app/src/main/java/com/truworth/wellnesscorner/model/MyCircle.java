package com.truworth.wellnesscorner.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * Created by rajeshs on 4/13/2018.
 */

public class MyCircle {
    @SerializedName("circleIdentity")
    @Expose
    private String circleIdentity;
    @SerializedName("circleName")
    @Expose
    private String circleName;
    @SerializedName("totalPosts")
    @Expose
    private int totalPosts;
    @SerializedName("totalChallenges")
    @Expose
    private int totalChallenges;


    private float rating;
    private String circle_ImageName;

    public float getRating() {
        return rating;
    }

    public void setRating(float rating) {
        this.rating = rating;
    }

    public String getCircle_ImageName() {
        return circle_ImageName;
    }

    public void setCircle_ImageName(String circle_ImageName) {
        this.circle_ImageName = circle_ImageName;
    }

    public String getCircleIdentity() {
        return circleIdentity;
    }

    public void setCircleIdentity(String circleIdentity) {
        this.circleIdentity = circleIdentity;
    }

    public String getCircleName() {
        return circleName;
    }

    public void setCircleName(String circleName) {
        this.circleName = circleName;
    }

    public int getTotalPosts() {
        return totalPosts;
    }

    public void setTotalPosts(int totalPosts) {
        this.totalPosts = totalPosts;
    }

    public int getTotalChallenges() {
        return totalChallenges;
    }

    public void setTotalChallenges(int totalChallenges) {
        this.totalChallenges = totalChallenges;
    }
}
