package com.truworth.wellnesscorner.ui.mainapp.createpost.sharemeal;

import android.databinding.ObservableField;
import android.text.SpannableStringBuilder;

import com.truworth.wellnesscorner.base.BaseViewModel;
import com.truworth.wellnesscorner.utils.DateUtils;
import com.truworth.wellnesscorner.utils.SingleLiveEvent;
import com.truworth.wellnesscorner.utils.Utils;

public class ShareMealTemplateViewModel extends BaseViewModel {

    public ObservableField<String> memberName = new ObservableField<>();
    public ObservableField<String> memberImage = new ObservableField<>();
    public ObservableField<String> date = new ObservableField<>();
    public ObservableField<String> mealType = new ObservableField<>();
    public ObservableField<String> foodNames = new ObservableField<>();
    public ObservableField<String> foodCalories = new ObservableField<>();
    public ObservableField<String> foodProtein = new ObservableField<>();
    public ObservableField<String> foodCarbs = new ObservableField<>();
    public ObservableField<String> foodFat = new ObservableField<>();



    public boolean isThemeSelected = true;
    public String filePath;


    SingleLiveEvent<Void> defaultImgClick = new SingleLiveEvent<>();

    public SingleLiveEvent<Void> getDefaultImgClick() {
        return defaultImgClick;
    }

    SingleLiveEvent<Void> cameraBtnClick = new SingleLiveEvent<>();

    public SingleLiveEvent<Void> getCameraBtnClick() {
        return cameraBtnClick;
    }

    SingleLiveEvent<Void> shareBtn = new SingleLiveEvent<>();

    public SingleLiveEvent<Void> getShareBtn() {
        return shareBtn;
    }

    public ObservableField<String> getFoodCalories() {
        return foodCalories;
    }

    public ObservableField<String> getFoodProtein() {
        return foodProtein;
    }

    public ObservableField<String> getFoodCarbs() {
        return foodCarbs;
    }

    public ObservableField<String> getFoodFat() {
        return foodFat;
    }

    public ObservableField<String> getMemberName() {
        return memberName;
    }

    public ObservableField<String> getMemberImage() {
        return memberImage;
    }

    public ObservableField<String> getDate() {
        return date;
    }

    public ObservableField<String> getMealType() {
        return mealType;
    }

    public ObservableField<String> getFoodNames() {
       return foodNames;
   }


    public ObservableField<SpannableStringBuilder> getNutritionalValues(String calories, String protein, String carbs, String fats){
        ObservableField<SpannableStringBuilder> spanString = new ObservableField<>();
        SpannableStringBuilder htmlCalorie = Utils.makeSpecificTextBoldSize(("Calories"+" - "+calories+" kcal, "),"Calories",1f);
        SpannableStringBuilder htmlProtein = Utils.makeSpecificTextBoldSize(("Protien"+" - "+protein+"g, "), "Protien",1f);
        SpannableStringBuilder htmlCarbs = Utils.makeSpecificTextBoldSize(("Carbs"+" - "+carbs+"g, "), "Carbs",1f);
        SpannableStringBuilder htmlFats = Utils.makeSpecificTextBoldSize(("Fat"+" - "+fats+"g"), "Fat",1f);

        spanString.set(htmlCalorie.append(htmlProtein.append(htmlCarbs.append(htmlFats))));

        return spanString;
    }

    public String getDateInFormat(String date){
        String newDateString ="";
        if(date !=null)
            newDateString = DateUtils.formatDate(date, "yyyy-MM-dd'T'HH:mm:ss", "MMMM dd, yyyy");
        return newDateString;
    }

    public String getDateInCameraFormat(String date){
        String newDateString ="";
        if(date !=null)
            newDateString = DateUtils.formatDate(date, "yyyy-MM-dd'T'HH:mm:ss", "EEEE, MMMM dd, yyyy");
        return newDateString;
    }

    public void cameraBtnClick(){
        cameraBtnClick.call();
    }

    public void imageOnClick() {
        isThemeSelected = false;
        defaultImgClick.call();
    }

    public String getTitle(String name, String mealtype, String date){
        String titleString = "";
        if(name!=null && mealtype!=null && date!=null){
            titleString = name +"'s "+mealtype+" - "+date;
        }

        return titleString;
    }

    public void shareBtnClick(){
        shareBtn.call();
    }
}
