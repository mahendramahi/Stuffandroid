package com.twc.dailylog.dialog;

import android.app.Activity;
import android.app.Dialog;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.EditText;
import android.widget.TextView;


import com.twc.dailylog.R;
import com.twc.dailylog.model.requestbody.AddSuggestedFoodBody;
import com.twc.dailylog.model.response.AddFoodResponse;
import com.twc.dailylog.rest.RestClient;
import com.twc.dailylog.utils.DailyLogConfig;
import com.twc.dailylog.utils.NetworkFactory;
import com.twc.dailylog.utils.Utils;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class AddSuggestedFoodDialog extends Dialog implements View.OnClickListener{
    private Activity activity;
    private Bundle bundle;
    private EditText etFoodName;
    private EditText etFoodDesc;

    public AddSuggestedFoodDialog(Activity activity, Bundle bundle) {
        //super(context);
        super(activity, R.style.CustomAlertDialog);
        this.activity = activity;
        this.bundle = bundle;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.dialog_add_custom_food);

        etFoodName = findViewById(R.id.etFoodName);
        etFoodDesc = findViewById(R.id.etFoodDesc);

        if(bundle!=null && bundle.containsKey("suggestedFoodName")){
            etFoodName.setText(bundle.getString("suggestedFoodName"));
        }

        TextView tvSubmit = findViewById(R.id.tvSubmit);

        tvSubmit.setOnClickListener(this);

    }
    private boolean validate() {
        String foodName = etFoodName.getText().toString().trim();

        if (foodName.isEmpty() || foodName.trim().length()<=0) {
            etFoodName.setError("enter the display text");
            return false;
        }
        return true;
    }

    @Override
    public void onClick(View v) {
        int i = v.getId();
        if (i == R.id.tvSubmit) {
            if (validate()) {

                saveSuggestedFoodAPI();
            }

        }
    }

    private void saveSuggestedFoodAPI() {

        if (NetworkFactory.getInstance().isNetworkAvailable(activity)) {



            AddSuggestedFoodBody addSuggestedFoodBody = new AddSuggestedFoodBody();
            addSuggestedFoodBody.setMemberID(Integer.parseInt(DailyLogConfig.dailyLogUser.getUserID()));
            addSuggestedFoodBody.setSuggestedDietFood_Name(etFoodName.getText().toString().trim());
            addSuggestedFoodBody.setSuggestedDietFood_Description(etFoodDesc.getText().toString().trim());

            RestClient restClient = new RestClient(getContext(), DailyLogConfig.BASE_URL, DailyLogConfig.DEBUG);
            restClient.getDailyLogService().saveSuggestedDietFood(addSuggestedFoodBody).enqueue(new Callback<AddFoodResponse>() {
                @Override
                public void onResponse(Call<AddFoodResponse> call, Response<AddFoodResponse> response) {

                    if(response!=null && response.body().getStatus()==0){
                        Utils.showToast(activity,"Your suggested food added successfully.");
                        dismiss();
                    }
                    else
                        Utils.showToast(activity,activity.getString(R.string.msg_api_response_null));
                    dismiss();
                }

                @Override
                public void onFailure(Call<AddFoodResponse> call, Throwable t) {

                    Utils.showToast(activity,activity.getString(R.string.msg_api_failure));
                }
            });
        } else {
            Utils.showToast(activity, activity.getString(R.string.internet_not_available));
        }
    }

}
