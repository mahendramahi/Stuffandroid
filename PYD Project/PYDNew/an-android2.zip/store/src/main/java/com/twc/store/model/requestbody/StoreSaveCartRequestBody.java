package com.twc.store.model.requestbody;



import com.twc.store.model.response.GympikCenterDetailResponse;

import java.util.List;

/**
 * Created by PalakC on 9/18/2017.
 */

public class StoreSaveCartRequestBody {

    private int MemberId;
    private int ProductCategoryId;
    private int ProductId;
    private String ProductName;
    private double Price;
    private double TaxAmount;
    private int Quantity;
    private String ProductImage;


    public int ProductVendorId;




    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    private String city;

    public String getCenterSlug() {
        return CenterSlug;
    }

    public void setCenterSlug(String centerSlug) {
        CenterSlug = centerSlug;
    }

    private String CenterSlug;
    private List<GympikCenterDetailResponse.DataBean.PassesBean> ProductPasses;
    public int getMemberId() {
        return MemberId;
    }

    public void setMemberId(int MemberId) {
        this.MemberId = MemberId;
    }

    public int getProductCategoryId() {
        return ProductCategoryId;
    }

    public void setProductCategoryId(int ProductCategoryId) {
        this.ProductCategoryId = ProductCategoryId;
    }

    public int getProductId() {
        return ProductId;
    }

    public void setProductId(int ProductId) {
        this.ProductId = ProductId;
    }

    public String getProductName() {
        return ProductName;
    }

    public void setProductName(String ProductName) {
        this.ProductName = ProductName;
    }

    public double getPrice() {
        return Price;
    }

    public void setPrice(double BasicPrice) {
        this.Price = BasicPrice;
    }

    public int getProductVendorId() {
        return ProductVendorId;
    }

    public void setProductVendorId(int productVendorId) {
        ProductVendorId = productVendorId;
    }

    public double getTaxAmount() {
        return TaxAmount;
    }

    public void setTaxAmount(double TaxAmount) {
        this.TaxAmount = TaxAmount;
    }

    public int getQuantity() {
        return Quantity;
    }

    public void setQuantity(int Quantity) {
        this.Quantity = Quantity;
    }

    public String getProductImage() {
        return ProductImage;
    }

    public void setProductImage(String ProductImage) {
        this.ProductImage = ProductImage;
    }

    public List<GympikCenterDetailResponse.DataBean.PassesBean> getPasses() {
        return ProductPasses;
    }

    public void setPasses(List<GympikCenterDetailResponse.DataBean.PassesBean> fee) {
        this.ProductPasses = fee;
    }
}
