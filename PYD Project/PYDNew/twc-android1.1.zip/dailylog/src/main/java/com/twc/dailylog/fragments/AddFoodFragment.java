package com.twc.dailylog.fragments;


import android.app.FragmentManager;
import android.app.ProgressDialog;
import android.app.TimePickerDialog;
import android.database.Cursor;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.MotionEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.TimePicker;


import com.twc.dailylog.MealActivity;
import com.twc.dailylog.R;
import com.twc.dailylog.R2;
import com.twc.dailylog.dialog.TimePickerFragment;
import com.twc.dailylog.model.beans.AddFoodItem;
import com.twc.dailylog.model.beans.FoodDetailItem;
import com.twc.dailylog.model.requestbody.AddFoodBody;
import com.twc.dailylog.model.requestbody.FoodDetailBody;
import com.twc.dailylog.model.response.AddFoodResponse;
import com.twc.dailylog.model.response.GetFoodDetailResponse;
import com.twc.dailylog.rest.RestClient;
import com.twc.dailylog.utils.Constant;
import com.twc.dailylog.utils.DailyLogConfig;
import com.twc.dailylog.utils.DateFactory;
import com.twc.dailylog.utils.DialogFactory;
import com.twc.dailylog.utils.NetworkFactory;
import com.twc.dailylog.utils.Utils;
import com.twc.greendaolib.FoodItemDao;
import com.twc.greendaolib.GreenDaoApp;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import butterknife.BindView;
import butterknife.OnClick;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by Manish Jain on 7/5/2016.
 */
public class AddFoodFragment extends BaseFragment {

    @BindView(R2.id.etQuantity)
    EditText etQuantity;

    @BindView(R2.id.etServing)
    EditText etServing;

    @BindView(R2.id.etTime)
    EditText etTime;

    @BindView(R2.id.tvFoodName)
    TextView tvFoodName;

    @BindView(R2.id.tvCalories)
    TextView tvCalories;

    @BindView(R2.id.tvAddLog)
    TextView tvAddLog;

    @BindView(R2.id.tvServing)
    TextView tvServing;

    @BindView(R2.id.tvProtein)
    TextView tvProtein;

    @BindView(R2.id.tvFat)
    TextView tvFat;

    @BindView(R2.id.tvCarbs)
    TextView tvCarbs;

    @BindView(R2.id.tvSodium)
    TextView tvSodium;

    @BindView(R2.id.rootView)
    ScrollView rootView;

    private int foodId = 0;
    private int nutritionId = 0;
    private double quantity = 0;
    private String time;
    private String date;

    private FoodItemDao foodItemDao;
    private FoodDetailItem foodDetailItem;
    private double proteinValue;
    private double fatValue;
    private double carbsValue;
    private double sodiumValue;
    private double caloriesValue;


    public static AddFoodFragment newInstance(Bundle bundle) {
        AddFoodFragment fragment = new AddFoodFragment();
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (getArguments() != null) {
            foodId = getArguments().getInt("foodId");
            nutritionId = getArguments().getInt("nutritionId", 0);
            quantity = getArguments().getDouble("quantity", 0);
           // time = getArguments().getString("Time", DateFactory.getInstance().getCurrentTime("hh:mm aa"));
            //date=getArguments().getString("Date",DateFactory.getInstance().getTodayDate("MM/dd/yyyy"));
            //date = getArguments().getString("Date", WellnessCornerApp.getPreferenceManager().getTrackDate());
            //date = getArguments().getString("Date", WellnessCornerApp.getInstance().getTrackDate());
        }

        foodItemDao = GreenDaoApp.getInstance(getActivity()).getDaoSession(getActivity()).getFoodItemDao();

    }

    @Override
    public void onResume() {
        super.onResume();
        ((MealActivity) getActivity()).setToolBarTitle("");
        ((MealActivity) getActivity()).showHomeAsUpEnableToolbar();

    }

    @Override
    public int getFragmentLayout() {
        return R.layout.fragment_add_food;
    }

    @Override
    public void onFragmentReady() {

        date=DateFactory.getInstance().getTodayDate("MM/dd/yyyy");
        time = DateFactory.getInstance().getCurrentTime("hh:mm aa");

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                if (isAdded() && getActivity() != null) {
                    if (foodDetailItem == null && foodId > 0) {
                        getFoodDetail(foodId);
                    }
                }
            }
        }, Constant.API_POST_DELAYED_TIME);

        etQuantity.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED);

        etTime.setText(time);

        etQuantity.addTextChangedListener(new TextWatcher() {

            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            public void afterTextChanged(Editable s) {

                if (s.toString().trim().length() > 0) {
                    try {
                        double qty = Double.parseDouble(s.toString().trim());
                        if (qty > 0) {
                            updateData(qty);
                        }

                    } catch (NumberFormatException e) {
                        etQuantity.setError(getString(R.string.quantity_error));
                        e.printStackTrace();
                    }
                }
            }
        });


        rootView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                hideKeyBoard(v);
                return false;
            }
        });
    }

    private boolean validation() {
        boolean isValid = true;

        if (etQuantity.getText().toString().trim().equals("")) {
            etQuantity.setError(getString(R.string.enter_quantity_error));
            isValid = false;
        } else if (etQuantity.getText().toString().trim().equals(".")) {
            etQuantity.setError(getString(R.string.quantity_error));
            isValid = false;
        } else {
            double durationTime = Double.parseDouble(etQuantity.getText().toString());
            if (durationTime <= 0) {
                etQuantity.setError(getString(R.string.quantity_error));
                isValid = false;
            }
        }
        return isValid;
    }

    private void hideKeyBoard(View v) {
        Utils.hideSoftKeyboard(getActivity());
    }

    private void getFoodDetail(int foodId) {
        if (NetworkFactory.getInstance().isNetworkAvailable(getActivity())) {
            /*final ProgressDialog pd;
            pd = ProgressDialog.show(getActivity(), "", ""
                    + getString(R.string.app_name));*/



            FoodDetailBody foodDetailBody = new FoodDetailBody();
            foodDetailBody.setFoodID(foodId + "");

            RestClient restClient = new RestClient(getActivity(), DailyLogConfig.BASE_URL, DailyLogConfig.DEBUG);
            restClient.getDailyLogService().getFoodDetailById(foodDetailBody).enqueue(new Callback<GetFoodDetailResponse>() {
                @Override
                public void onResponse(Call<GetFoodDetailResponse> call, Response<GetFoodDetailResponse> response) {
                    if (isAdded() && getActivity() != null) {

                        if (response != null && response.body() != null) {
                            foodDetailItem = response.body().getData();
                            proteinValue = foodDetailItem.getProtin();
                            fatValue = foodDetailItem.getFat();
                            carbsValue = foodDetailItem.getCarbs();
                            sodiumValue = foodDetailItem.getSodium();
                            caloriesValue = foodDetailItem.getCalorie();

                            tvFoodName.setText(foodDetailItem.getName());
                            etServing.setText(foodDetailItem.getStandardServing());


                        /* if food item quantity fetch from the database*/
                            if (quantity > 0) {
                                etQuantity.setText(String.valueOf(quantity));
                                tvServing.setText(String.format(Locale.getDefault(), "Serving -%s %s", Utils.doubleToString(quantity), foodDetailItem.getStandardServing()));
                            } else {
                                etQuantity.setText(String.valueOf(foodDetailItem.getQuantity()));
                                tvServing.setText(String.format(Locale.getDefault(), "Serving -%s %s", Utils.doubleToString(foodDetailItem.getQuantity()), foodDetailItem.getStandardServing()));
                            }
                        }
                    }
                }

                @Override
                public void onFailure(Call<GetFoodDetailResponse> call, Throwable t) {
                    if (isAdded() && getActivity() != null) {

                            DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.network_error), getString(R.string.str_ok), false);

                    }
                }
            });
        } else {
            Utils.showSnackBarMessage(rootView, getString(R.string.internet_not_available));
        }
    }

    private void updateData(double quantityValue) {
        double protein = proteinValue * quantityValue;
        tvProtein.setText(String.format(Locale.getDefault(),"%d", Math.round(proteinValue * quantityValue)));

        double fat = fatValue * quantityValue;
        tvFat.setText(String.format(Locale.getDefault(),"%d", Math.round(fatValue * quantityValue)));

        double carbs = carbsValue * quantityValue;
        tvCarbs.setText(String.format(Locale.getDefault(),"%d", Math.round(carbsValue * quantityValue)));

        double sodium = sodiumValue * quantityValue;
        tvSodium.setText(String.format(Locale.getDefault(),"%d", Math.round(sodiumValue * quantityValue)));

        double calories = caloriesValue * quantityValue;
        tvCalories.setText(String.format(Locale.getDefault(),"%d", Math.round(caloriesValue * quantityValue)));

        tvServing.setText(String.format(Locale.getDefault(), "Serving -%s %s", Utils.doubleToString(quantityValue), etServing.getText().toString().trim()));


    }

    @OnClick(R2.id.etTime)
    public void timeDialog() {

        String TIME_FORMAT = "hh:mm a";
        String time24format = DateFactory.getInstance().formatTime(TIME_FORMAT, "HH:mm", etTime.getText().toString());
        String[] timeSplit = time24format.split(":");

        TimePickerFragment timePicker = new TimePickerFragment();
        Bundle bundle = new Bundle();
        bundle.putInt("hour", Integer.parseInt(timeSplit[0]));
        bundle.putInt("minute", Integer.parseInt(timeSplit[1]));
        bundle.putBoolean("is24hrsFormat", false);
        timePicker.setArguments(bundle);
        timePicker.setCallBack(new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                String AM_PM = " AM";
                String mm_precede = "";
                if (hourOfDay >= 12) {
                    AM_PM = " PM";
                    if (hourOfDay >= 13 && hourOfDay < 24) {
                        hourOfDay -= 12;
                    } else {
                        hourOfDay = 12;
                    }
                } else if (hourOfDay == 0) {
                    hourOfDay = 12;
                }
                if (minute < 10) {
                    mm_precede = "0";
                }
                etTime.setText(String.format(Locale.getDefault(), "%d:%s%d%s", hourOfDay, mm_precede, minute, AM_PM));
            }
        });
        timePicker.show(getFragmentManager(), "dialog");

    }

    @OnClick(R2.id.tvAddLog)
    public void addFood() {
        if (validation()) {
            if (nutritionId > 0) {
                updateFoodDetail();
            } else {
                addFoodDetail();
            }
        }
    }

    private void addFoodDetail() {
        if (NetworkFactory.getInstance().isNetworkAvailable(getActivity())) {
           /* final ProgressDialog pd;
            pd = ProgressDialog.show(getActivity(), "", ""
                    + getString(R.string.app_name));*/



            String selectTime = DateFactory.getInstance().formatTime("hh:mm a", "HH:mm:ss", etTime.getText().toString().trim());
            String dateTime = date + " " + selectTime;
            /* attach this array list to api body*/
            ArrayList<AddFoodItem> addFoodItemsList = new ArrayList<>();
            AddFoodItem addFoodItem = new AddFoodItem();
            addFoodItem.setFoodID(foodId);
            addFoodItem.setNutritionID(nutritionId);
            addFoodItem.setNutritionFoodItem(tvFoodName.getText().toString());
            addFoodItem.setNutritionMealType(((MealActivity)getActivity()).getMealType());
            addFoodItem.setNutritionQuantity(Double.parseDouble(etQuantity.getText().toString().trim()));
            addFoodItem.setNutritionCalorie(Double.parseDouble(tvCalories.getText().toString().trim()));
            addFoodItem.setNutritionFat(Double.parseDouble(tvFat.getText().toString().trim()));
            addFoodItem.setNutritionCarbs(Double.parseDouble(tvCarbs.getText().toString().trim()));
            addFoodItem.setNutritionProtien(Double.parseDouble(tvProtein.getText().toString().trim()));
            addFoodItem.setNutritionSodium(Double.parseDouble(tvSodium.getText().toString().trim()));
            addFoodItem.setNutritionStandardServing(etServing.getText().toString().trim());
            addFoodItem.setNutritionMemberID(DailyLogConfig.dailyLogUser.getUserID());
            addFoodItem.setNutritionDate(dateTime);
            addFoodItemsList.add(addFoodItem);

            /* food item object is used to store values in database*/
            final com.twc.greendaolib.FoodItem foodItem = new com.twc.greendaolib.FoodItem();
            foodItem.setFoodId(foodId);
            foodItem.setName(tvFoodName.getText().toString());
            foodItem.setMealType(((MealActivity)getActivity()).getMealType());
            foodItem.setQuantity(etQuantity.getText().toString().trim());
            foodItem.setCalories(tvCalories.getText().toString().trim());
            foodItem.setFat(tvFat.getText().toString().trim());
            foodItem.setCarbs(tvCarbs.getText().toString().trim());
            foodItem.setProtein(tvProtein.getText().toString().trim());
            foodItem.setSodium(tvSodium.getText().toString().trim());
            foodItem.setDateTime(DateFactory.getInstance().formatDate("MM/dd/yyyy", "yyyyMMdd", date));
            foodItem.setStandardServing(etServing.getText().toString().trim());

            AddFoodBody addFoodBody = new AddFoodBody();
            addFoodBody.setModel(addFoodItemsList);

            RestClient restClient = new RestClient(getActivity(), DailyLogConfig.BASE_URL, DailyLogConfig.DEBUG);
            restClient.getDailyLogService().addFoodData(addFoodBody).enqueue(new Callback<AddFoodResponse>() {
                @Override
                public void onResponse(Call<AddFoodResponse> call, Response<AddFoodResponse> response) {
                    if (isAdded() && getActivity() != null) {

                        if (response != null && response.body() != null) {
                            if (response.body().getStatus() == 0) {
                                foodItem.setServerId(response.body().getNutritionID() + "");
                                foodItem.setIsDeleted(false);
                                foodItem.setIsModified(false);
                                foodItem.setIsUploaded(true);

                                foodItemDao.insert(foodItem);

                                Utils.printLog("food count", (getAllFood() != null ? getAllFood().size() : 0) + "");
                                Utils.showToast(getActivity(), getString(R.string.food_added));

                                Bundle bundle = new Bundle();
                                bundle.putString("date", date);
                                Utils.replaceFragmentTopDown(getFragmentManager(), DailyLogFragment.newInstance(bundle), DailyLogFragment.class.getSimpleName(), true, R.id.fragmentContainerMeal);

                            }
                        } else {
                            DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_response_null), getString(R.string.str_ok), false);
                            // Toast.makeText(getActivity(), getString(R.string.msg_api_response_null), Toast.LENGTH_SHORT).show();
                        }
                    }

                }

                @Override
                public void onFailure(Call<AddFoodResponse> call, Throwable t) {
                    if (isAdded() && getActivity() != null) {

                            DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_failure), getString(R.string.str_ok), false);
                            // Toast.makeText(getActivity(), getString(R.string.msg_api_failure), Toast.LENGTH_SHORT).show();


                    }
                }
            });
        } else {
            Utils.showSnackBarMessage(rootView, getString(R.string.internet_not_available));
        }
    }

    private void updateFoodDetail() {
        if (NetworkFactory.getInstance().isNetworkAvailable(getActivity())) {
            final ProgressDialog pd;
            pd = ProgressDialog.show(getActivity(), "", ""
                    + getString(R.string.app_name));

            String selectTime = DateFactory.getInstance().formatTime("hh:mm a", "HH:mm:ss", etTime.getText().toString().trim());
            String dateTime = date + " " + selectTime;
            /* attach this object to api body*/
            final AddFoodItem updateFoodItem = new AddFoodItem();
            updateFoodItem.setFoodID(foodId);
            updateFoodItem.setNutritionID(nutritionId);
            updateFoodItem.setNutritionFoodItem(tvFoodName.getText().toString());
            updateFoodItem.setNutritionMealType(((MealActivity)getActivity()).getMealType());
            updateFoodItem.setNutritionQuantity(Double.parseDouble(etQuantity.getText().toString().trim()));
            updateFoodItem.setNutritionCalorie(Double.parseDouble(tvCalories.getText().toString().trim()));
            updateFoodItem.setNutritionFat(Double.parseDouble(tvFat.getText().toString().trim()));
            updateFoodItem.setNutritionCarbs(Double.parseDouble(tvCarbs.getText().toString().trim()));
            updateFoodItem.setNutritionProtien(Double.parseDouble(tvProtein.getText().toString().trim()));
            updateFoodItem.setNutritionSodium(Double.parseDouble(tvSodium.getText().toString().trim()));
            updateFoodItem.setNutritionStandardServing(etServing.getText().toString().trim());
            updateFoodItem.setNutritionMemberID(DailyLogConfig.dailyLogUser.getUserID());
            updateFoodItem.setNutritionDate(dateTime);


            RestClient restClient = new RestClient(getActivity(), DailyLogConfig.BASE_URL, DailyLogConfig.DEBUG);
            restClient.getDailyLogService().updateFoodData(updateFoodItem).enqueue(new Callback<AddFoodResponse>() {
                @Override
                public void onResponse(Call<AddFoodResponse> call, Response<AddFoodResponse> response) {
                    if (isAdded() && getActivity() != null) {
                        if (pd != null && pd.isShowing()) {
                            pd.dismiss();
                        }
                        if (response != null && response.body() != null) {
                            if (response.body().getStatus() == 0) {
                                String query = " UPDATE " + FoodItemDao.TABLENAME + " SET " +
                                        FoodItemDao.Properties.Quantity.columnName + "='" + updateFoodItem.getNutritionQuantity() + "',"
                                        + FoodItemDao.Properties.Calories.columnName + "='" + updateFoodItem.getNutritionCalorie() + "',"
                                        + FoodItemDao.Properties.Protein.columnName + "='" + updateFoodItem.getNutritionProtien() + "',"
                                        + FoodItemDao.Properties.Fat.columnName + "='" + updateFoodItem.getNutritionFat() + "',"
                                        + FoodItemDao.Properties.Carbs.columnName + "='" + updateFoodItem.getNutritionCarbs() + "',"
                                        + FoodItemDao.Properties.Sodium.columnName + "='" + updateFoodItem.getNutritionSodium() + "',"
                                        + FoodItemDao.Properties.DateTime.columnName + "='" + DateFactory.getInstance().formatDate("MM/dd/yyyy", "yyyyMMdd", date) + "',"
                                        + FoodItemDao.Properties.IsModified.columnName + "= 1"
                                        + " WHERE " + FoodItemDao.Properties.ServerId.columnName + "=" + nutritionId;
                                Cursor cursor = GreenDaoApp.getInstance(getActivity()).getDaoSession(getActivity()).getDatabase().rawQuery(query, null);

                                Utils.printLog("update food", cursor.getCount() + "");
                                Utils.showToast(getActivity(), getString(R.string.food_updated));
                                Bundle bundle = new Bundle();
                                bundle.putString("date", date);
                                Utils.replaceFragmentTopDown(getFragmentManager(), DailyLogFragment.newInstance(bundle), DailyLogFragment.class.getSimpleName(), true, R.id.fragmentContainerMeal);


                            }
                        } else {
                            DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_response_null), getString(R.string.str_ok), false);
                            // Toast.makeText(getActivity(), getString(R.string.msg_api_response_null), Toast.LENGTH_SHORT).show();
                        }
                    }
                }

                @Override
                public void onFailure(Call<AddFoodResponse> call, Throwable t) {
                    if (isAdded() && getActivity() != null) {
                        if (pd != null && pd.isShowing()) {
                            pd.dismiss();
                            DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_failure), getString(R.string.str_ok), false);
                            // Toast.makeText(getActivity(), getString(R.string.msg_api_failure), Toast.LENGTH_SHORT).show();
                        }

                    }
                }
            });
        } else {
            Utils.showSnackBarMessage(rootView, getString(R.string.internet_not_available));
        }
    }

    private List<com.twc.greendaolib.FoodItem> getAllFood() {
        return foodItemDao.queryBuilder().list();
    }
}
