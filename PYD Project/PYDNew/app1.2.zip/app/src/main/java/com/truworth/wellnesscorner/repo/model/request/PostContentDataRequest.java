package com.truworth.wellnesscorner.repo.model.request;

import com.google.gson.annotations.SerializedName;

public class PostContentDataRequest {
    @SerializedName("ChallengeIdentity")
        private String ChallengeIdentity;

        public String getChallengeIdentity() {
            return ChallengeIdentity;
        }

        public void setChallengeIdentity(String ChallengeIdentity) {
            this.ChallengeIdentity = ChallengeIdentity;
        }

}
