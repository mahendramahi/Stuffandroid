package com.truworth.stepmodule.model;

import com.google.gson.annotations.SerializedName;

/**
 * If this code works it was written by Somesh Kumar on 13 January, 2017. If not, I don't know who wrote it.
 */
public class EFitMonthStepsBody {
    @SerializedName("member_id")
    private String memberId;
    private String startDate;
    private String endDate;

    public String getMemberId() {
        return memberId;
    }

    public void setMemberId(String memberId) {
        this.memberId = memberId;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }
 /*   @SerializedName("member_id")
    private String memberId;
    private String month;
    private String year;

    public String getMemberId() {
        return memberId;
    }

    public void setMemberId(String memberId) {
        this.memberId = memberId;
    }

    public String getMonth() {
        return month;
    }

    public void setMonth(String month) {
        this.month = month;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }*/
}
