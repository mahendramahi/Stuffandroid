package com.truworth.wellnesscorner.repo.model.response;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.truworth.wellnesscorner.model.CircleAccess;
import com.truworth.wellnesscorner.model.Post;

import java.util.List;

public class CircleResponseData {
    @SerializedName("circleName")
    @Expose
    private String circleName;
    @SerializedName("circleImage")
    @Expose
    private String circleImage;
    @SerializedName("totalStepChallenge")
    @Expose
    private Integer totalStepChallenge;
    @SerializedName("socialPost")
    @Expose
    private List<Post> socialPost = null;
    private CircleAccess circleAccess;

    public String getCircleName() {
        return circleName;
    }

    public void setCircleName(String circleName) {
        this.circleName = circleName;
    }

    public String getCircleImage() {
        return circleImage;
    }

    public void setCircleImage(String circleImage) {
        this.circleImage = circleImage;
    }

    public Integer getTotalStepChallenge() {
        return totalStepChallenge;
    }

    public void setTotalStepChallenge(Integer totalStepChallenge) {
        this.totalStepChallenge = totalStepChallenge;
    }

    public List<Post> getSocialPost() {
        return socialPost;
    }

    public void setSocialPost(List<Post> socialPost) {
        this.socialPost = socialPost;
    }

    public CircleAccess getCircleAccess() {
        return circleAccess;
    }

    public void setCircleAccess(CircleAccess circleAccess) {
        this.circleAccess = circleAccess;
    }
}
