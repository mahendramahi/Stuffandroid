package com.twc.remindermodule.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import com.twc.remindermodule.service.RemindersService;
import com.twc.remindermodule.utils.Utils;

/**
 * Created by ManishJ1 on 11/12/2016.
 */

public class TimeChangeReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        Utils.printLog("Time change", "Time change");
        Intent intent1 = new Intent(context, RemindersService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(intent1);
        } else {
            context.startService(intent1);
        }
    }


}
