package com.truworth.wellnesscorner.repo.model.response;

/**
 * Created by GurvinderS on 8/16/2016.
 */
public class ActivityMarkAsReadResponse {
    private int status;



    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }
}
