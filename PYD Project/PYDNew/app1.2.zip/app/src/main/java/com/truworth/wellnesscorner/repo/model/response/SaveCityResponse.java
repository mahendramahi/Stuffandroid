package com.truworth.wellnesscorner.repo.model.response;

/**
 * Created by richas on 4/16/2018.
 */

public class SaveCityResponse {

    private DataBean data;
    private boolean hasError;
    private Object error;

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public boolean isHasError() {
        return hasError;
    }

    public void setHasError(boolean hasError) {
        this.hasError = hasError;
    }

    public Object getError() {
        return error;
    }

    public void setError(Object error) {
        this.error = error;
    }

    public static class DataBean {
        private String isSave;

        public String getIsSave() {
            return isSave;
        }

        public void setIsSave(String isSave) {
            this.isSave = isSave;
        }
    }
}
