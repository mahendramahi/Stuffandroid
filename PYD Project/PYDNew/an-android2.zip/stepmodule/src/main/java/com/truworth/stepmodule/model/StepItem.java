package com.truworth.stepmodule.model;

/**
 * If this code works, it was written by Somesh Kumar  on 25 April, 2018. If not, I don't know who wrote it.
 */
public class StepItem {
    private String stepCount;
    private String stepTime;
    private int calories;
    public String getStepCount() {
        return this.stepCount;
    }

    public void setStepCount(String stepCount) {
        this.stepCount = stepCount;
    }

    public String getStepTime() {
        return this.stepTime;
    }

    public void setStepTime(String stepTime) {
        this.stepTime = stepTime;
    }

    public int getCalories() {
        return calories;
    }

    public void setCalories(int calories) {
        this.calories = calories;
    }
}

