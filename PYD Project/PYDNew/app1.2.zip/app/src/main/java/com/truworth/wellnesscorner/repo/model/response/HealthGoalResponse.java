package com.truworth.wellnesscorner.repo.model.response;

import java.util.List;

/**
 * Created by PalakC on 4/5/2018.
 */

public class HealthGoalResponse {


    private boolean hasError;
    private Error error;
    private List<HealthGoalItem> data;

    public boolean isHasError() {
        return hasError;
    }

    public void setHasError(boolean hasError) {
        this.hasError = hasError;
    }

    public Error getError() {
        return error;
    }

    public void setError(Error error) {
        this.error = error;
    }

    public List<HealthGoalItem> getData() {
        return data;
    }

    public void setData(List<HealthGoalItem> data) {
        this.data = data;
    }

    public static class HealthGoalItem {
        private int id;
        private String name;
        private String image;
        private boolean isSelected;

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getImage() {
            return image;
        }

        public void setImage(String image) {
            this.image = image;
        }

        public boolean isIsSelected() {
            return isSelected;
        }

        public void setIsSelected(boolean isSelected) {
            this.isSelected = isSelected;
        }
    }
}
