package com.truworth.wellnesscorner.model;

public class ResetPasswordBean {
    private boolean isSendMail;
    private String message;

    public boolean isIsSendMail() {
        return isSendMail;
    }

    public void setIsSendMail(boolean isSendMail) {
        this.isSendMail = isSendMail;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
