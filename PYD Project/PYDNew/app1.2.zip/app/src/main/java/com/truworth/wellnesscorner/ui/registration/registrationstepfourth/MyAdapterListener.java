package com.truworth.wellnesscorner.ui.registration.registrationstepfourth;

/**
 * Created by richas on 4/11/2018.
 */

public interface MyAdapterListener {
    void onContainerClick(int position);
}
