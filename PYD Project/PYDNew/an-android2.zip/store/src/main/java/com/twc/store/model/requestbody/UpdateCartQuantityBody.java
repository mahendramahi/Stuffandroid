package com.twc.store.model.requestbody;

/**
 * Created by richas on 9/14/2017.
 */

public class UpdateCartQuantityBody {

    private int ProductId;
    private int Quantity;
    private int cartId;

    public int getProductVendorID() {
        return ProductVendorID;
    }

    public void setProductVendorID(int productVendorID) {
        ProductVendorID = productVendorID;
    }

    private int ProductVendorID;

    public int getProductId() {
        return ProductId;
    }

    public void setProductId(int ProductId) {
        this.ProductId = ProductId;
    }

    public int getQuantity() {
        return Quantity;
    }

    public void setQuantity(int Quantity) {
        this.Quantity = Quantity;
    }

    public int getCartId() {
        return cartId;
    }

    public void setCartId(int cartId) {
        this.cartId = cartId;
    }
}
