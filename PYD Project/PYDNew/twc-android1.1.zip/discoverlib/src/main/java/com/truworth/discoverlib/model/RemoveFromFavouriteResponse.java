package com.truworth.discoverlib.model;

/**
 If this code works it was written by Somesh Kumar on 15 August, 2016. If not, I don't know who wrote it.
 */
public class RemoveFromFavouriteResponse {
    private int status;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }
}
