package com.truworth.stepmodule.inteface;


import com.truworth.stepmodule.model.StepItem;

import java.util.ArrayList;

/**
 * If this code works, it was written by Somesh Kumar  on 26 April, 2018. If not, I don't know who wrote it.
 */
public interface OnRangeStepsFound {
    void onRangeStepsFound(ArrayList<StepItem> foundStepList);

    void onStepsFoundError(String error);
}