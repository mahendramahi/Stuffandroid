package com.twc.remindermodule.fragments;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.twc.remindermodule.R;
import com.twc.remindermodule.R2;
import com.twc.remindermodule.adapter.RecommendedMyHabitAdapter;
import com.twc.remindermodule.model.requestbody.HealthyHabitBody;
import com.twc.remindermodule.model.requestbody.SaveHabitValueBody;
import com.twc.remindermodule.model.response.BaseResponse;
import com.twc.remindermodule.model.response.MyHabitResponse;
import com.twc.remindermodule.rest.ReminderConfig;
import com.twc.remindermodule.rest.RestClient;
import com.twc.remindermodule.utils.Constant;
import com.twc.remindermodule.utils.DialogFactory;
import com.twc.remindermodule.utils.Utils;
import com.twc.remindermodule.views.CustomProgressDialog;

import java.util.ArrayList;

import butterknife.BindView;
import butterknife.OnClick;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by GurvinderS on 11/13/2017.
 */

public class RecommendedMyHabitsFragment extends BaseFragment  {
    @BindView(R2.id.rvMyHabits)
    RecyclerView rvMyHabits;

    @BindView(R2.id.ivBack)
    ImageView ivBack;

    @BindView(R2.id.ivSettings)
    ImageView ivSettings;

    @BindView(R2.id.tvAddHabit)
    TextView tvAddHabit;

    @BindView(R2.id.llAddHabit)
    LinearLayout llAddHabit;

    private ArrayList<MyHabitResponse.MyHabitItem> arrListMyHabit;
    private RecommendedMyHabitAdapter adapter;
    private Handler handler = new Handler();
    private Runnable runnable = new Runnable() {
        @Override
        public void run() {
            getMyHabitAPICall();
        }
    };

    public static RecommendedMyHabitsFragment newInstance(Bundle bundle) {
        RecommendedMyHabitsFragment fragment = new RecommendedMyHabitsFragment();
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public int getFragmentLayout() {
        return R.layout.fragment_my_habit;
    }

    @Override
    public void onFragmentReady() {

        arrListMyHabit = new ArrayList<>();
        rvMyHabits.setHasFixedSize(true);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getActivity());
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        rvMyHabits.setLayoutManager(linearLayoutManager);

        adapter = new RecommendedMyHabitAdapter(getActivity(), arrListMyHabit, RecommendedMyHabitsFragment.this,getArguments());
        rvMyHabits.setAdapter(adapter);

        //handler.postDelayed(runnable, Constant.API_POST_DELAYED_TIME);

    }


    @Override
    public void onResume() {
        super.onResume();
        handler.postDelayed(runnable, Constant.API_POST_DELAYED_TIME);
        adapter.notifyDataSetChanged();
    }

    @OnClick({R2.id.tvAddHabit, R2.id.ivBack, R2.id.ivSettings})
    void OnViewClick(View v) {
        int i = v.getId();
        if (i == R.id.tvAddHabit) {
            Bundle bundle = new Bundle();
            bundle.putBoolean("isRedirectFromRecommended", false);
            bundle.putBoolean("isRedirectFromMyHabit", true);
            Utils.replaceFragment(getFragmentManager(), RecommendedHealthyHabitsFragment.newInstance(bundle), RecommendedHealthyHabitsFragment.class.getSimpleName(), true, R.id.fragmentContainerReminder);

        } else if (i == R.id.ivBack) {
            getActivity().setResult(Activity.RESULT_OK);
           getActivity().finish();

        } else if (i == R.id.ivSettings) {
            Bundle bundle1 = new Bundle();
            //  bundle1.putBoolean("isRedirectFromSelectHabit", false);
            //  bundle1.putBoolean("isRedirectFromRecommended",false);
            //  bundle1.putBoolean("isRedirectFromMyHabit", true);
            //   Utils.replaceFragment(getFragmentManager(), RecommendedConfigureReminders.newInstance(bundle1), RecommendedConfigureReminders.class.getSimpleName(), true, R.id.fragmentContainer);
            bundle1.putBoolean("isRedirectFromRecommended", false);
            bundle1.putBoolean("isRedirectFromMyHabit", true);
            Utils.replaceFragment(getFragmentManager(), RecommendedHealthyHabitsFragment.newInstance(bundle1), RecommendedHealthyHabitsFragment.class.getSimpleName(), true, R.id.fragmentContainerReminder);

        }
    }


    private void getMyHabitAPICall() {

        final CustomProgressDialog pb = new CustomProgressDialog(getActivity(), R.style.custom_progress_style, false);
        if (pb != null)
            pb.show();
        HealthyHabitBody healthyHabitBody = new HealthyHabitBody();
        healthyHabitBody.setMemberID(ReminderConfig.reminderUser.getUserID());

            RestClient restClient = new RestClient(getActivity(), ReminderConfig.BASE_URL, ReminderConfig.DEBUG);
        restClient.getRecommendedService().getMemberHabitWeeklyStatus(healthyHabitBody).enqueue(new Callback<MyHabitResponse>() {

                @Override
            public void onResponse(Call<MyHabitResponse> call, Response<MyHabitResponse> response) {

                if (isAdded() && getActivity() != null) {
                    if (pb.isShowing()) {
                        pb.dismiss();
                    }
                    if (response != null && response.body() != null) {
                        if (response.body().getStatus() == 0 && response.body().getData() != null) {
                            arrListMyHabit.clear();
                            arrListMyHabit.addAll(response.body().getData());
                            adapter.notifyDataSetChanged();

                            if (response.body().isMoreHabitToAdd())
                                llAddHabit.setVisibility(View.VISIBLE);
                            else
                                llAddHabit.setVisibility(View.GONE);

                        } else {
                            DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_response_failure), getString(R.string.str_ok), false);
                        }
                    } else {
                        DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_response_failure), getString(R.string.str_ok), false);
                    }
                }
            }

            @Override
            public void onFailure(Call<MyHabitResponse> call, Throwable t) {
                if (isAdded() && getActivity() != null) {
                    if (pb.isShowing()) {
                        pb.dismiss();
                    }
                    DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_failure), getString(R.string.str_ok), false);
                }
            }
        });
    }

    public void saveMemberHabitValueAPICall(int habitId, boolean value) {
        final CustomProgressDialog pb = new CustomProgressDialog(getActivity(), R.style.custom_progress_style, false);
        if (pb != null)
            pb.show();

        SaveHabitValueBody saveHabitValueBody = new SaveHabitValueBody();
        saveHabitValueBody.setMemberID(ReminderConfig.reminderUser.getUserID());
        saveHabitValueBody.setHabitID(habitId);
        saveHabitValueBody.setValue(value);

        RestClient restClient = new RestClient(getActivity(), ReminderConfig.BASE_URL, ReminderConfig.DEBUG);
        restClient.getRecommendedService().saveMemberHabitValue(saveHabitValueBody).enqueue(new Callback<BaseResponse>() {

            @Override
            public void onResponse(Call<BaseResponse> call, Response<BaseResponse> response) {

                if (isAdded() && getActivity() != null) {
                    if (pb.isShowing()) {
                        pb.dismiss();
                    }
                    if (response != null && response.body() != null) {
                        if (response.body().getStatus() == 0) {

                            getMyHabitAPICall();

                        } else {
                            DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_response_failure), getString(R.string.str_ok), false);
                        }
                    } else {
                        DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_response_failure), getString(R.string.str_ok), false);
                    }
                }
            }

            @Override
            public void onFailure(Call<BaseResponse> call, Throwable t) {
                if (isAdded() && getActivity() != null) {
                    if (pb.isShowing()) {
                        pb.dismiss();
                    }
                    DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_failure), getString(R.string.str_ok), false);
                }
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        handler.removeCallbacks(runnable);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        handler.removeCallbacks(runnable);
    }
}

