package com.truworth.wellnesscorner.repo.model.request;

import com.google.gson.annotations.SerializedName;

public class PostMediaTypeDataRequest {
    @SerializedName("MediaType")
    private int MediaType;
    @SerializedName("Data")
    private String Data;
    @SerializedName("Title")
    private String Title;
    @SerializedName("Desc")
    private String Desc;
    @SerializedName("FileName")
    private String FileName;
    @SerializedName("Width")
    private int Width;
    @SerializedName("Height")
    private int Height;


    public int getMediaType() {
        return MediaType;
    }

    public void setMediaType(int MediaType) {
        this.MediaType = MediaType;
    }

    public String getData() {
        return Data;
    }

    public void setData(String Data) {
        this.Data = Data;
    }

    public String getTitle() {
        return Title;
    }

    public void setTitle(String Title) {
        this.Title = Title;
    }

    public String getDesc() {
        return Desc;
    }

    public void setDesc(String Desc) {
        this.Desc = Desc;
    }

    public String getFileName() {
        return FileName;
    }

    public void setFileName(String fileName) {
        FileName = fileName;
    }

    public int getWidth() {
        return Width;
    }

    public void setWidth(int width) {
        Width = width;
    }

    public int getHeight() {
        return Height;
    }

    public void setHeight(int height) {
        Height = height;
    }
}
