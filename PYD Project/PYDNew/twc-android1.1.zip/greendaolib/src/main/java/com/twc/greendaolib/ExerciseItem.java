package com.twc.greendaolib;

import org.greenrobot.greendao.annotation.Entity;
import org.greenrobot.greendao.annotation.Generated;

/**
 * Created by PankajS on 8/29/2016.
 */
@Entity
public class ExerciseItem
    {
    public int serverID;
    public String Activity;
    public int ActivityDuration;
    public String caloriesBurnedIn1MIn;
    public String caloriesBurned;
    public String dateTime;
    public int isModified;
    public int isUploaded;
    public int isDeleted;

    @Generated(hash = 604614505)
    public ExerciseItem(int serverID, String Activity, int ActivityDuration,
            String caloriesBurnedIn1MIn, String caloriesBurned, String dateTime,
            int isModified, int isUploaded, int isDeleted) {
        this.serverID = serverID;
        this.Activity = Activity;
        this.ActivityDuration = ActivityDuration;
        this.caloriesBurnedIn1MIn = caloriesBurnedIn1MIn;
        this.caloriesBurned = caloriesBurned;
        this.dateTime = dateTime;
        this.isModified = isModified;
        this.isUploaded = isUploaded;
        this.isDeleted = isDeleted;
    }

    @Generated(hash = 780870238)
    public ExerciseItem() {
    }
        
    public int getServerID()
        {
        return serverID;
        }

    public void setServerID(int serverID)
        {
        this.serverID = serverID;
        }

    public String getActivity()
        {
        return Activity;
        }

    public void setActivity(String activity)
        {
        Activity = activity;
        }

    public String getCaloriesBurnedIn1MIn()
        {
        return caloriesBurnedIn1MIn;
        }

    public void setCaloriesBurnedIn1MIn(String caloriesBurnedIn1MIn)
        {
        this.caloriesBurnedIn1MIn = caloriesBurnedIn1MIn;
        }

    public String getCaloriesBurned()
        {
        return caloriesBurned;
        }

    public void setCaloriesBurned(String caloriesBurned)
        {
        this.caloriesBurned = caloriesBurned;
        }

    public String getDateTime()
        {
        return dateTime;
        }

    public void setDateTime(String dateTime)
        {
        this.dateTime = dateTime;
        }

    public int getIsModified()
        {
        return isModified;
        }

    public void setIsModified(int isModified)
        {
        this.isModified = isModified;
        }

    public int getIsUploaded()
        {
        return isUploaded;
        }

    public void setIsUploaded(int isUploaded)
        {
        this.isUploaded = isUploaded;
        }

    public int getIsDeleted()
        {
        return isDeleted;
        }

    public void setIsDeleted(int isDeleted)
        {
        this.isDeleted = isDeleted;
        }

    public int getActivityDuration()
        {
        return ActivityDuration;
        }

    public void setActivityDuration(int activityDuration)
        {
        ActivityDuration = activityDuration;
        }
    }
