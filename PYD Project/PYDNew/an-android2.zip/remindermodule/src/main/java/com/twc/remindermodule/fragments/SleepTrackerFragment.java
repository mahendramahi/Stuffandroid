package com.twc.remindermodule.fragments;


import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v4.widget.NestedScrollView;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.DatePicker;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import com.github.florent37.singledateandtimepicker.SingleDateAndTimePicker;
import com.twc.remindermodule.R;
import com.twc.remindermodule.R2;
import com.twc.remindermodule.ReminderActivity;
import com.twc.remindermodule.dialog.ApiErrorDialog;
import com.twc.remindermodule.dialog.DatePickerFragment;
import com.twc.remindermodule.dialog.NetworkErrorDialog;
import com.twc.remindermodule.model.requestbody.SaveSleepLogBody;
import com.twc.remindermodule.model.response.SaveSleepLogResponse;
import com.twc.remindermodule.rest.ReminderConfig;
import com.twc.remindermodule.rest.RestClient;
import com.twc.remindermodule.utils.Constant;
import com.twc.remindermodule.utils.DateFactory;
import com.twc.remindermodule.utils.DialogFactory;
import com.twc.remindermodule.utils.NetworkFactory;
import com.twc.remindermodule.utils.Utils;
import com.twc.remindermodule.views.CustomEditTextView;
import com.twc.remindermodule.views.CustomProgressDialog;
import com.twc.remindermodule.views.CustomTextView;

import java.util.Calendar;
import java.util.Date;

import butterknife.BindView;
import butterknife.OnClick;
import retrofit2.Call;
import retrofit2.Callback;

/**
 * Created by richas on 1/17/2018.
 */
// Last Updated on 15/02/2018 by richas implemented mandatory smiley, cannot select future date in calendar
public class SleepTrackerFragment extends BaseFragment implements OnRetryAfterNetworkError {

    @BindView(R2.id.tvTodayDateSleep)
    CustomTextView tvTodayDateSleep;
    @BindView(R2.id.tvTodayDateAwake)
    CustomTextView tvTodayDateAwake;
    @BindView(R2.id.tvBack)
    CustomTextView tvBack;
    @BindView(R2.id.tvHourDuration)
    CustomTextView tvHourDuration;
    @BindView(R2.id.tvMinutesDuration)
    CustomTextView tvMinutesDuration;
    @BindView(R2.id.ivMoodExcellent)
    ImageView ivMoodExcellent;
    @BindView(R2.id.ivMoodGood)
    ImageView ivMoodGood;
    @BindView(R2.id.ivMoodNormal)
    ImageView ivMoodNormal;
    @BindView(R2.id.ivMoodSad)
    ImageView ivMoodSad;
    @BindView(R2.id.ivMoodVerySad)
    ImageView ivMoodVerySad;
    @BindView(R2.id.etSleepNote)
    CustomEditTextView etSleepNote;
    @BindView(R2.id.btnSave)
    CustomTextView btnSave;
    @BindView(R2.id.tpSleepTimePicker)
    SingleDateAndTimePicker tpSleepTimePicker;
    @BindView(R2.id.tpAwakeTimePicker)
    SingleDateAndTimePicker tpAwakeTimePicker;
    @BindView(R2.id.tvHour)
    CustomTextView tvHour;
    @BindView(R2.id.rootView)
    RelativeLayout rootView;
    @BindView(R2.id.nestedScrollView)
    NestedScrollView nestedScrollView;
    private int mMonth, mDay, mYear;
    private int feel = 0;
    private long diffHours;
    private String sleepDateTime="", awakeDateTime="";
    private int sleepLogId=0;
    boolean isSleepDatePicker = true;
    boolean isAwakeTimeAfterSleepTime = false;
    private Calendar calendar;

    private final android.app.DatePickerDialog.OnDateSetListener ondate = new android.app.DatePickerDialog.OnDateSetListener() {
        @Override
        public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
            // cannot select future date in calendar
            if(DateFactory.getInstance().isFutureDate(dayOfMonth, monthOfYear, year)){
                Utils.showToast(getActivity(), getActivity().getResources().getString(R.string.msg_future_date));
            }
            else {
            monthOfYear = monthOfYear + 1;
            StringBuilder date = new StringBuilder();

            date.append(year);
            if (monthOfYear < 10) {
                date.append("0").append(monthOfYear).append(dayOfMonth);
            } else {
                date.append(monthOfYear).append(dayOfMonth);
            }

                String formattedDate = DateFactory.getInstance().formatDate("yyyyMMdd", Constant.DATE_FORMAT_MMMM_DD_YYYY, date.toString());


                if (isSleepDatePicker)
                    tvTodayDateSleep.setText(formattedDate);
                else
                    tvTodayDateAwake.setText(formattedDate);

                calculateDuration();
            }
        }
    };

    @Override
    protected int getFragmentLayout() {
        return R.layout.fragment_sleep_tracker;
    }



    @Override
    protected void onFragmentReady() {

        initializeData();

        // sleep time picker time change listener
        tpSleepTimePicker.setListener(new SingleDateAndTimePicker.Listener() {
            @Override
            public void onDateChanged(String displayed, Date date) {
                calculateDuration();
            }
        });

        // awake time picker time change listener
        tpAwakeTimePicker.setListener(new SingleDateAndTimePicker.Listener() {
            @Override
            public void onDateChanged(String displayed, Date date) {
                calculateDuration();
            }
        });

        nestedScrollView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                hideKeyBoard(view);
                return false;
            }
        });

        rootView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                hideKeyBoard(view);
                return false;
            }
        });
    }

    private void initializeData() {

        String currentDate = DateFactory.getInstance().getTodayDate(Constant.DATE_FORMAT_MMMM_DD_YYYY);
        tvTodayDateSleep.setText(currentDate);
        tvTodayDateAwake.setText(currentDate);
        tpSleepTimePicker.setIsAmPm(true);
        tpAwakeTimePicker.setIsAmPm(true);
        tpSleepTimePicker.setStepMinutes(1);
        tpAwakeTimePicker.setStepMinutes(1);

        // set current time in time pickers
        calendar = Calendar.getInstance();
        tpSleepTimePicker.selectDate(calendar);
        tpAwakeTimePicker.selectDate(calendar);

        etSleepNote.setText("");
        ivMoodExcellent.setImageResource(R.drawable.excellent);
        ivMoodGood.setImageResource(R.drawable.good);
        ivMoodNormal.setImageResource(R.drawable.normal);
        ivMoodSad.setImageResource(R.drawable.sad);
        ivMoodVerySad.setImageResource(R.drawable.very_sad);

        calculateDuration();
    }

    // method to calculate duration between sleep datetime and awake datetime
    private void calculateDuration() {
        calendar = Calendar.getInstance();
        String sleepDate = tvTodayDateSleep.getText().toString();
        String awakeDate = tvTodayDateAwake.getText().toString();
        Date sleepPickerDate = tpSleepTimePicker.getDate();
        String sleepTime = DateFactory.getInstance().getDateFromDateFormat(sleepPickerDate,"hh:mm:ss a");
        Date awakePickerDate = tpAwakeTimePicker.getDate();
        String awakeTime = DateFactory.getInstance().getDateFromDateFormat(awakePickerDate,"hh:mm:ss a");

        sleepDateTime = sleepDate+" "+sleepTime;
        Date dtSleepDateTime = DateFactory.getInstance().getDate(sleepDateTime,Constant.DATE_FORMAT_24_HOUR);
        awakeDateTime = awakeDate+" "+awakeTime;
        Date dtAwakeDateTime = DateFactory.getInstance().getDate(awakeDateTime,Constant.DATE_FORMAT_24_HOUR);

        // Awake date time is before Sleep date time condition
        if(dtSleepDateTime.after(dtAwakeDateTime)) {
            Utils.showToast(getActivity(), "Awake date can not before sleep date");
            tvHourDuration.setText("0");
            tvMinutesDuration.setText("0");
            //tvTodayDateAwake.setText(sleepDate);
            tvTodayDateSleep.setText(awakeDate);
            tpSleepTimePicker.selectDate(calendar);
            tpAwakeTimePicker.selectDate(calendar);

            isAwakeTimeAfterSleepTime = false;
            tvHourDuration.setText("0");
            tvMinutesDuration.setText("0");
        }
        else {
            long diffDays = DateFactory.getInstance().getDaysDifference(sleepDateTime, awakeDateTime, Constant.DATE_FORMAT_24_HOUR);
            diffHours = DateFactory.getInstance().getHourDifference(sleepDateTime, awakeDateTime, Constant.DATE_FORMAT_24_HOUR);
            long diffMinutes = DateFactory.getInstance().getMinuteDifference(sleepDateTime, awakeDateTime, Constant.DATE_FORMAT_24_HOUR);

            if (diffDays < 0 || diffHours < 0 || diffMinutes < 0) {
                isAwakeTimeAfterSleepTime = false;
                tvHourDuration.setText("0");
                tvMinutesDuration.setText("0");
            } else {
                diffHours = (diffDays * 24) + diffHours;
                if (diffHours == 0 && diffMinutes == 0) {
                    isAwakeTimeAfterSleepTime = false;
                    tvHourDuration.setText("0");
                    tvMinutesDuration.setText("0");
                } else {
                    isAwakeTimeAfterSleepTime = true;
                    tvHourDuration.setText(String.valueOf(diffHours));
                    tvMinutesDuration.setText(String.valueOf(diffMinutes));

                    if (diffHours == 1)
                        tvHour.setText("Hr");
                    else
                        tvHour.setText("Hrs");
                }
            }
        }
    }

    @Override
    public void onResume() {
        super.onResume();
     //   ((ReminderActivity) getActivity()).hideToolbar();
    }

    @OnClick({R2.id.tvTodayDateSleep, R2.id.tvTodayDateAwake, R2.id.ivMoodExcellent,
    R2.id.ivMoodGood, R2.id.ivMoodNormal, R2.id.ivMoodSad, R2.id.ivMoodVerySad,
            R2.id.btnSave,R2.id.tvBack})
    public void onClick(View view) {
        int i = view.getId();
        if (i == R.id.tvTodayDateSleep) {
            isSleepDatePicker = true;
            openDateDialog(DateFactory.getInstance().getTodayDate(Constant.DATE_FORMAT_MMMM_DD_YYYY));

        } else if (i == R.id.tvTodayDateAwake) {
            isSleepDatePicker = false;
            openDateDialog(DateFactory.getInstance().getTodayDate(Constant.DATE_FORMAT_MMMM_DD_YYYY));

        } else if (i == R.id.ivMoodExcellent) {
            feel = 1;
            ivMoodExcellent.setImageResource(R.drawable.excellent_hover);
            ivMoodGood.setImageResource(R.drawable.good);
            ivMoodNormal.setImageResource(R.drawable.normal);
            ivMoodSad.setImageResource(R.drawable.sad);
            ivMoodVerySad.setImageResource(R.drawable.very_sad);

        } else if (i == R.id.ivMoodGood) {
            feel = 2;
            ivMoodExcellent.setImageResource(R.drawable.excellent);
            ivMoodGood.setImageResource(R.drawable.good_hover);
            ivMoodNormal.setImageResource(R.drawable.normal);
            ivMoodSad.setImageResource(R.drawable.sad);
            ivMoodVerySad.setImageResource(R.drawable.very_sad);

        } else if (i == R.id.ivMoodNormal) {
            feel = 3;
            ivMoodExcellent.setImageResource(R.drawable.excellent);
            ivMoodGood.setImageResource(R.drawable.good);
            ivMoodNormal.setImageResource(R.drawable.normal_hover);
            ivMoodSad.setImageResource(R.drawable.sad);
            ivMoodVerySad.setImageResource(R.drawable.very_sad);

        } else if (i == R.id.ivMoodSad) {
            feel = 4;
            ivMoodExcellent.setImageResource(R.drawable.excellent);
            ivMoodGood.setImageResource(R.drawable.good);
            ivMoodNormal.setImageResource(R.drawable.normal);
            ivMoodSad.setImageResource(R.drawable.sad_hover);
            ivMoodVerySad.setImageResource(R.drawable.very_sad);

        } else if (i == R.id.ivMoodVerySad) {
            feel = 5;
            ivMoodExcellent.setImageResource(R.drawable.excellent);
            ivMoodGood.setImageResource(R.drawable.good);
            ivMoodNormal.setImageResource(R.drawable.normal);
            ivMoodSad.setImageResource(R.drawable.sad);
            ivMoodVerySad.setImageResource(R.drawable.very_sad_hover);

        } else if (i == R.id.btnSave) {
            if (isAwakeTimeAfterSleepTime)
                // insert smiley is mandatory before save sleep log
                if (isValidSmiley())
                    saveSleepLogApiCall(sleepLogId);
                else
                    Utils.showToast(getActivity(), getActivity().getResources().getString(R.string.msg_select_smiley));
            else
                Utils.showToast(getActivity(), getActivity().getResources().getString(R.string.msg_awake_before_sleep_time));

        } else if (i == R.id.tvBack) {
            getFragmentManager().popBackStackImmediate();

        }
    }

    private boolean isValidSmiley() {
        if(feel==0)
            return false;
        else
            return true;
    }

    //method to open calendar dialog and set selected date on sleep date and awake date
    private void openDateDialog(String syncDate) {

        if (syncDate != null) {
            String formatDate = DateFactory.getInstance().formatDate(Constant.DATE_FORMAT_MMMM_DD_YYYY, Constant.DD_MM_YYYY_FORWARD_SLASH, syncDate);
            String[] dobArray = formatDate.split("/");
            if (dobArray.length > 0) {
                try {
                    mDay   = Integer.parseInt(dobArray[0]);
                    mMonth = Integer.parseInt(dobArray[1]);
                    mYear = Integer.parseInt(dobArray[2]);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
        DatePickerFragment date = new DatePickerFragment();
        /**
         * Set Up Current Date Into dialog
         */
        Bundle args = new Bundle();
        args.putInt("year", mYear);
        args.putInt("month", mMonth - 1);
        args.putInt("day", mDay);

        args.putBoolean("maxDate", true);    // set to true to disable future dates in calendar on 15/02/2018
        args.putBoolean("setMinimumDate", false); // set to false to show back date in calender on 09/02/2018
        date.setArguments(args);
        /**
         * Set Call back to capture selected date
         */
        date.setCallBack(ondate);
        date.show(getActivity().getFragmentManager(), "Date Picker");
    }

    // api call to save sleep data in sleep log
    private void saveSleepLogApiCall(int sleepLogId) {
        if (NetworkFactory.getInstance().isNetworkAvailable(getActivity())) {
            final CustomProgressDialog pd = new CustomProgressDialog(getActivity(), R.style.custom_progress_style, true);
            if (!isRemoving()) {
                pd.show();
            }

            String finalSleepDate = DateFactory.getInstance().formatDate(Constant.DATE_FORMAT_24_HOUR, "yyyy-MM-dd HH:mm:ss", sleepDateTime);
            String finalAwakeDate = DateFactory.getInstance().formatDate(Constant.DATE_FORMAT_24_HOUR, "yyyy-MM-dd HH:mm:ss", awakeDateTime);

            SaveSleepLogBody saveSleepLogBody = new SaveSleepLogBody();
            saveSleepLogBody.setSleepLogID(sleepLogId);
            saveSleepLogBody.setSleepLog_DateTime(finalSleepDate);
            saveSleepLogBody.setSleepLog_Duration((int) diffHours);// as discuss with arvind sir we snd in hrs but its not usable its only show in web
            saveSleepLogBody.setSleepLog_Feel(feel);
            saveSleepLogBody.setSleepLog_MemberID(Integer.parseInt(ReminderConfig.reminderUser.getUserID()));
            saveSleepLogBody.setSleepLog_Remarks(etSleepNote.getText().toString());
            saveSleepLogBody.setSleepLog_WakeUpTime(finalAwakeDate);
            saveSleepLogBody.setSleepLog_IsActive(true);

            RestClient restClient = new RestClient(getActivity(), ReminderConfig.BASE_URL, ReminderConfig.DEBUG);
            restClient.getRecommendedService().saveSleepLogTracker(saveSleepLogBody).enqueue(new Callback<SaveSleepLogResponse>() {
                @Override
                public void onResponse(Call<SaveSleepLogResponse> call, final retrofit2.Response<SaveSleepLogResponse> response) {
                    if (isAdded() && getActivity() != null) {
                        if (pd != null && pd.isShowing()) {
                            pd.dismiss();
                        }
                        if (response != null && response.body() != null) {
                            if (response.body().getStatus() == 0) {
                                if (response.body().getData() != null) {
                                    if (response.body().getData().getStatus() == 0)

                                        DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, response.body().getData().getMessage(), getString(R.string.str_ok), new DialogInterface.OnClickListener() {
                                            @Override
                                            public void onClick(DialogInterface dialogInterface, int i) {
                                                initializeData();
                                                getFragmentManager().popBackStackImmediate();                                                                                      }
                                        }, false);
                                    else if (response.body().getData().getStatus() == 1) {
                                        DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getActivity().getString(R.string.msg_sleep_track_already_exist), "Yes", new DialogInterface.OnClickListener() {
                                            @Override
                                            public void onClick(DialogInterface dialogInterface, int i) {
                                                dialogInterface.cancel();
                                                saveSleepLogApiCall(response.body().getData().getSleepLogID());

                                            }
                                        }, "No", false);
                                    }
                                    else
                                        //DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, response.body().getData().getMessage(), getString(R.string.str_ok), false);
                                        showApiErrorDialog();
                                } else
                                    //DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_response_null), getString(R.string.str_ok), false);
                                    showApiErrorDialog();

                            } else if (response.body().getStatus() == -1)
                                //DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_response_failure), getString(R.string.str_ok), false);
                                showApiErrorDialog();
                        } else
                            //DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_response_null), getString(R.string.str_ok), false);
                            showApiErrorDialog();

                    }
                }

                @Override
                public void onFailure(Call<SaveSleepLogResponse> call, Throwable t) {
                    if (isAdded() && getActivity() != null) {
                        if (pd != null && pd.isShowing()) {
                            pd.dismiss();
                        }
                        //DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_failure), getString(R.string.str_ok), false);
                        showApiErrorDialog();
                    }
                }
            });
        } else {
            //Utils.showSnackBarMessage(rootView, getString(R.string.internet_not_available));
            // show Network Error Screen Dialog
            NetworkErrorDialog networkErrorDialog = new NetworkErrorDialog(getActivity(), getActivity(), SleepTrackerFragment.this);
            networkErrorDialog.show();
            Window window = networkErrorDialog.getWindow();
            window.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);
        }
    }

    // method to show Api Error Screen Dialog on 7 Feb 2018
    private void showApiErrorDialog() {
        ApiErrorDialog apiErrorDialog = new ApiErrorDialog(getActivity(), getActivity(), SleepTrackerFragment.this);
        apiErrorDialog.show();
        Window window = apiErrorDialog.getWindow();
        window.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);
    }

    // method to hide soft keyboard on tap outside the sleep remark edittext
    private void hideKeyBoard(View v) {
        Utils.hideSoftKeyboard(getActivity());
    }

    @Override
    public void onRetry() {
        if(isAwakeTimeAfterSleepTime)
            saveSleepLogApiCall(sleepLogId);
        else
            Utils.showToast(getActivity(),"Awake date time should be after Sleep date time");
    }
}
