package com.truworth.wellnesscorner.ui.mainapp.today;


import android.databinding.DataBindingUtil;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import com.truworth.wellnesscorner.R;

import com.truworth.wellnesscorner.databinding.RowMyChallengesBinding;
import com.truworth.wellnesscorner.model.TodayMyChallenge;
import com.truworth.wellnesscorner.ui.mainapp.circledetail.challenges.ChallengeDetailActivity;

import java.util.List;


// Created by gurvinder on 4/23/2018.

public class MyChallengesAdapter extends RecyclerView.Adapter<MyChallengesAdapter.ViewHolder> {
    List<TodayMyChallenge> myChallenges;

    public MyChallengesAdapter(List<TodayMyChallenge> myChallenges) {
        this.myChallenges = myChallenges;
        //  this.listener = listener;
    }

    @NonNull
    @Override
    public MyChallengesAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        RowMyChallengesBinding binding = DataBindingUtil.inflate(LayoutInflater.from(parent.getContext()), R.layout.row_my_challenges, parent, false);
        return new MyChallengesAdapter.ViewHolder(binding);
    }


    @Override
    public void onBindViewHolder(@NonNull MyChallengesAdapter.ViewHolder holder, int position) {
        holder.bind(myChallenges.get(position));
    }


    @Override
    public int getItemCount() {
        return myChallenges.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements MyChallengeItemViewModel.MyChallengeListener {
        private RowMyChallengesBinding mBinding;


        public ViewHolder(RowMyChallengesBinding binding) {
            super(binding.getRoot());
            mBinding = binding;
        }

        public void bind(@NonNull TodayMyChallenge myChallenge) {

            MyChallengeItemViewModel viewModel = new MyChallengeItemViewModel(myChallenge,this,myChallenge.getCircleIdentity());

            mBinding.setViewModel(viewModel);
            //mBinding.tvChallengeName.setText(myChallenge.getChallengeName());
            //mBinding.setMyCircle(circle);
            mBinding.executePendingBindings();

            /*int daysLeft = Integer.parseInt(viewModel.getDayDifference(onGoingChallengesBean.getChallengeEndDate()));
            int daysDifference = Integer.parseInt(DateUtils.getOnlyDaysDifference(onGoingChallengesBean.getChallengeStartDate(), onGoingChallengesBean.getChallengeEndDate(), "yyyy-MM-dd'T'HH:mm:ss"));
            mBinding.pbchallenge.setProgress((int) Utils.getPercentage(daysLeft, daysDifference));*/

        }


        @Override
        public void onItemClick(TodayMyChallenge onGoingChallenge, String postMapId) {
            int challengeTypeId = myChallenges.get(getAdapterPosition()).getChallengeTypeId();
            String circleIdentity = myChallenges.get(getAdapterPosition()).getCircleIdentity();
           ChallengeDetailActivity.start(itemView.getContext(), myChallenges.get(getAdapterPosition()).getChallengeIdentity(), circleIdentity, challengeTypeId);

        }
    }


}

