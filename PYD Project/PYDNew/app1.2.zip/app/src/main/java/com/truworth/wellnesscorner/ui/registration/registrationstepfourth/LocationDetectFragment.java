package com.truworth.wellnesscorner.ui.registration.registrationstepfourth;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.databinding.DataBindingUtil;
import android.graphics.Color;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.common.api.ResolvableApiException;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationSettingsRequest;
import com.google.android.gms.location.LocationSettingsResponse;
import com.google.android.gms.location.LocationSettingsStatusCodes;
import com.google.android.gms.tasks.Task;
import com.karumi.dexter.Dexter;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionDeniedResponse;
import com.karumi.dexter.listener.PermissionGrantedResponse;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.single.PermissionListener;
import com.truworth.wellnesscorner.BR;
import com.truworth.wellnesscorner.R;
import com.truworth.wellnesscorner.base.BaseFragment;
import com.truworth.wellnesscorner.databinding.FragmentDetectLocationBinding;
import com.truworth.wellnesscorner.ui.mainapp.circle.CircleViewModel;
import com.truworth.wellnesscorner.ui.registration.RegistrationActivity;

import java.util.List;
import java.util.Locale;
import java.util.Objects;

/**
 * If this code works, it was written by Somesh Kumar  on 06 April, 2018. If not, I don't know who wrote it.
 */
public class LocationDetectFragment extends BaseFragment<FragmentDetectLocationBinding,LocationDetectViewModel > {

    public static final String TAG = "LocationDetectFragment";
    private static final String ARG_PARAM1 = "param1";
    private static final int REQUEST_CHECK_SETTINGS = 21213;
    private static final long UPDATE_INTERVAL_IN_MILLISECONDS = 3000;
    private static final long FASTEST_UPDATE_INTERVAL_IN_MILLISECONDS = UPDATE_INTERVAL_IN_MILLISECONDS / 2;
    FragmentDetectLocationBinding locationDetectBinding;
    private LocationRequest mLocationRequest;
    private LocationDetectViewModel locationDetectViewModel;
    private String City = "", State = "", Country = "";
    private int cityId;
    boolean isBack = false;

    public static LocationDetectFragment newInstance() {
        LocationDetectFragment fragment = new LocationDetectFragment();
        return fragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        isBack =false;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        locationDetectBinding = getViewDataBinding();

        locationDetectViewModel.progressLocation.set(true);
        locationDetectBinding.progressBarLocation.show();
        locationDetectBinding.setViewModel(locationDetectViewModel);
        attachContinueClickObserver();
        checkForPermissions();
        setListdataObserver();
    }


    @Override
    public int getBindingVariable() {
        return BR.viewModel;
    }

    /**
     * @return layout resource id
     */
    @Override
    public int getLayoutId() {
        return R.layout.fragment_detect_location;
    }

    /**
     * Override for set view model
     *
     * @return view model instance
     */
    @Override
    public LocationDetectViewModel getViewModel() {
        locationDetectViewModel = ViewModelProviders.of(this).get(LocationDetectViewModel.class);
        return locationDetectViewModel;
    }


    private void checkForPermissions() {
        Dexter.withActivity(getActivity()).withPermission(Manifest.permission.ACCESS_FINE_LOCATION).withListener(new PermissionListener() {
            @Override
            public void onPermissionGranted(PermissionGrantedResponse response) {
                //Toast.makeText(getActivity(), "Searching for location", Toast.LENGTH_SHORT).show();
                createLocationRequest();
                checkLocationSettings();
            }

            @Override
            public void onPermissionDenied(PermissionDeniedResponse response) {
                Toast.makeText(getActivity(), response.getPermissionName(), Toast.LENGTH_SHORT).show();
                if (response.isPermanentlyDenied()) {
                    Toast.makeText(getActivity(), "Permanently denied " + response.getPermissionName(), Toast.LENGTH_SHORT).show();
                    locationDetectViewModel.progressLocation.set(false);
                    locationDetectBinding.progressBarLocation.hide();
                }
            }

            @Override
            public void onPermissionRationaleShouldBeShown(PermissionRequest permission, PermissionToken token) {
                token.continuePermissionRequest();
            }
        }).check();
    }


    private void createLocationRequest() {
        mLocationRequest = LocationRequest.create();
        mLocationRequest.setInterval(UPDATE_INTERVAL_IN_MILLISECONDS);
        mLocationRequest.setFastestInterval(FASTEST_UPDATE_INTERVAL_IN_MILLISECONDS);
        mLocationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
    }

    private void checkLocationSettings() {
        LocationSettingsRequest.Builder builder = new LocationSettingsRequest.Builder().addLocationRequest(mLocationRequest).setAlwaysShow(false);

        Task<LocationSettingsResponse> result = LocationServices.getSettingsClient(Objects.requireNonNull(getActivity())).checkLocationSettings(builder.build());
        result.addOnCompleteListener(task -> {
            try {
                //noinspection unused
                LocationSettingsResponse response = task.getResult(ApiException.class);
                // All location settings are satisfied. The client can initialize location requests here.
                getLocation();
            } catch (ApiException exception) {
                switch (exception.getStatusCode()) {
                    case LocationSettingsStatusCodes.RESOLUTION_REQUIRED:
                        try {
                            ResolvableApiException resolvable = (ResolvableApiException) exception;
                            LocationDetectFragment.this.startIntentSenderForResult(resolvable.getResolution().getIntentSender(), REQUEST_CHECK_SETTINGS, null, 0, 0, 0, null);
                            // resolvable.startResolutionForResult(getActivity(), REQUEST_CHECK_SETTINGS);
                        } catch (IntentSender.SendIntentException | ClassCastException e) {
                            e.printStackTrace();
                            locationDetectViewModel.progressLocation.set(false);
                            locationDetectBinding.progressBarLocation.hide();
                        }
                        break;
                    case LocationSettingsStatusCodes.SETTINGS_CHANGE_UNAVAILABLE:
                        break;
                }
            }
        });
    }

    @Override
    public void onResume() {
        super.onResume();
        ((RegistrationActivity) getActivity()).getToolbar().setBackgroundColor(Color.parseColor("#FFFFFF"));

    }


    @Override
    public void onDestroyView() {
        super.onDestroyView();
        isBack = true;
    }

    @SuppressLint("MissingPermission")
    private void getLocation() {
        FusedLocationProviderClient mFusedLocationClient = LocationServices.getFusedLocationProviderClient(Objects.requireNonNull(getActivity()));
        mFusedLocationClient.getLastLocation().addOnSuccessListener(getActivity(), location -> {
            if (location != null) {
                // Toast.makeText(LocationDetectFragment.this.getActivity(), "LAT: " + location.getLatitude() + " LONG: " + location.getLongitude(), Toast.LENGTH_SHORT).show();
                updateCityAndPincode(location.getLatitude(), location.getLongitude());
            } else {
                locationDetectViewModel.progressLocation.set(false);
                locationDetectBinding.progressBarLocation.hide();
                //  Toast.makeText(LocationDetectFragment.this.getActivity(), "LAT: NULL, LONG: NULL", Toast.LENGTH_SHORT).show();
            }
        }).addOnFailureListener(e -> Toast.makeText(LocationDetectFragment.this.getActivity(), e.getLocalizedMessage(), Toast.LENGTH_SHORT).show());
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (requestCode) {
            case REQUEST_CHECK_SETTINGS:
                switch (resultCode) {
                    case Activity.RESULT_OK:
                        getLocation();
                        break;
                    case Activity.RESULT_CANCELED:
                        Toast.makeText(getActivity(), "You must turn on the location to be able to search the location automatically.", Toast.LENGTH_SHORT).show();
                        break;
                    default:
                        break;
                }
                break;
        }
    }

    private void updateCityAndPincode(double latitude, double longitude) {
        try {
            Geocoder gcd = new Geocoder(getActivity(), Locale.getDefault());
            List<Address> addresses = gcd.getFromLocation(latitude, longitude, 1);
            if (addresses.size() > 0) {

                City = "" + addresses.get(0).getLocality();
                State = "" + addresses.get(0).getAdminArea();
                Country = "" + addresses.get(0).getCountryName();

                if (City != null && City.length() > 0 && State != null && State.length() > 0 && Country != null && Country.length() > 0) {
                    locationDetectViewModel.isContinueEnabled.set(true);
                    locationDetectViewModel.loadSearchCitiesData(City);
                }
                locationDetectViewModel.progressLocation.set(false);
                locationDetectBinding.progressBarLocation.hide();

            }

        } catch (Exception e) {
            Log.e(TAG, "exception:" + e.toString());
        }

    }

    private void attachContinueClickObserver() {
        locationDetectViewModel.getContinueClick().observe(this, new Observer<Void>() {
            @Override
            public void onChanged(@Nullable Void aVoid) {
                //Success, update UI
                showConfirmLocationFragment();
            }
        });
    }

    private void showConfirmLocationFragment() {
        getActivity().getSupportFragmentManager().beginTransaction().replace(R.id.registerContainer, ConfirmLocationFragment.newInstance(cityId, City, State, Country), ConfirmLocationFragment.TAG).addToBackStack(LocationDetectFragment.TAG).commit();
    }

    private void setListdataObserver() {
        locationDetectViewModel.getCityStateCountryList().observe(this, new Observer<Void>() {
            @Override
            public void onChanged(@Nullable Void aVoid) {
                if (locationDetectViewModel.getAddressData() != null) {
                    cityId = locationDetectViewModel.getAddressData().get(0).getCityId();
                    City = locationDetectViewModel.getAddressData().get(0).getCityName();
                    State = locationDetectViewModel.getAddressData().get(0).getStateName();
                    Country = locationDetectViewModel.getAddressData().get(0).getCountryName();
                    if(!isBack)
                        showConfirmLocationFragment();
                }
            }
        });
    }

}
