package com.twc.dailylog.model.requestbody;

/**
 * Created by PalakC on 7/6/2016.
 */
public class SearchExerciseBody {

    private  String UserID;

    public String getUserID() {
        return UserID;
    }

    public void setUserID(String userID) {
        UserID = userID;
    }

    public String getKeyword() {
        return Keyword;
    }

    public void setKeyword(String keyword) {
        Keyword = keyword;
    }

    private String Keyword;


}
