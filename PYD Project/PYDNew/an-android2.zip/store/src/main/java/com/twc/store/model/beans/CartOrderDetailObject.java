package com.twc.store.model.beans;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.ArrayList;

/**
 * Created by ManishJ1 on 9/15/2017.
 */

public class CartOrderDetailObject implements Parcelable {
    public static final Creator<CartOrderDetailObject> CREATOR = new Creator<CartOrderDetailObject>() {
        @Override
        public CartOrderDetailObject createFromParcel(Parcel source) {
            return new CartOrderDetailObject(source);
        }

        @Override
        public CartOrderDetailObject[] newArray(int size) {
            return new CartOrderDetailObject[size];
        }
    };
    private ArrayList<CartListItem> cartListItems;
    private ArrayList<CouponBean> couponList;
    private int cartItemsSize;
    private double totalTax;
    private double totalWellCashDiscount;
    private double couponDiscount;
    private double totalAmount;
    private double grandTotalAmount;
    private String cartIds;
    private String couponIds;

    public CartOrderDetailObject() {
    }

    protected CartOrderDetailObject(Parcel in) {
        this.cartListItems = new ArrayList<>();
        in.readList(this.cartListItems, CartListItem.class.getClassLoader());
        this.couponList = new ArrayList<>();
        in.readList(this.couponList, CouponBean.class.getClassLoader());
        this.cartItemsSize = in.readInt();
        this.totalTax = in.readDouble();
        this.totalWellCashDiscount = in.readDouble();
        this.couponDiscount = in.readDouble();
        this.totalAmount = in.readDouble();
        this.grandTotalAmount = in.readDouble();
        this.cartIds = in.readString();
        this.couponIds = in.readString();
    }

    public ArrayList<CartListItem> getCartListItems() {
        return cartListItems;
    }

    public void setCartListItems(ArrayList<CartListItem> cartListItems) {
        this.cartListItems = cartListItems;
    }

    public ArrayList<CouponBean> getCouponList() {
        return couponList;
    }

    public void setCouponList(ArrayList<CouponBean> couponList) {
        this.couponList = couponList;
    }

    public int getCartItemsSize() {
        return cartItemsSize;
    }

    public void setCartItemsSize(int cartItemsSize) {
        this.cartItemsSize = cartItemsSize;
    }

    public double getTotalTax() {
        return totalTax;
    }

    public void setTotalTax(double totalTax) {
        this.totalTax = totalTax;
    }

    public double getTotalWellCashDiscount() {
        return totalWellCashDiscount;
    }

    public void setTotalWellCashDiscount(double totalWellCashDiscount) {
        this.totalWellCashDiscount = totalWellCashDiscount;
    }

    public double getCouponDiscount() {
        return couponDiscount;
    }

    public void setCouponDiscount(double couponDiscount) {
        this.couponDiscount = couponDiscount;
    }

    public double getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(double totalAmount) {
        this.totalAmount = totalAmount;
    }

    public double getGrandTotalAmount() {
        return grandTotalAmount;
    }

    public void setGrandTotalAmount(double grandTotalAmount) {
        this.grandTotalAmount = grandTotalAmount;
    }

    public String getCartIds() {
        return cartIds;
    }

    public void setCartIds(String cartIds) {
        this.cartIds = cartIds;
    }

    public String getCouponIds() {
        return couponIds;
    }

    public void setCouponIds(String couponIds) {
        this.couponIds = couponIds;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeList(this.cartListItems);
        dest.writeList(this.couponList);
        dest.writeInt(this.cartItemsSize);
        dest.writeDouble(this.totalTax);
        dest.writeDouble(this.totalWellCashDiscount);
        dest.writeDouble(this.couponDiscount);
        dest.writeDouble(this.totalAmount);
        dest.writeDouble(this.grandTotalAmount);
        dest.writeString(this.cartIds);
        dest.writeString(this.couponIds);
    }
}
