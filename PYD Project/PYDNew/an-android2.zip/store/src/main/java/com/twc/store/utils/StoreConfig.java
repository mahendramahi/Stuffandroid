package com.twc.store.utils;

import com.twc.store.model.beans.BillingInfoBean;
import com.twc.store.model.beans.StoreUser;

/**
 * Created by GurvinderS on 3/27/2018.
 */

public class StoreConfig {
    public static String APP_NAME;
    public static String BASE_URL;
    public static boolean mdebug;
    public static StoreUser storeUser;
    private BillingInfoBean billingInfoBean;

    public static void init(String name, String url, StoreUser user, boolean debug) {
        APP_NAME = name;
        BASE_URL = url;
        storeUser = user;
        mdebug = debug;

    }
    public BillingInfoBean getBillingInfoBean() {
        return billingInfoBean;
    }

    public void setBillingInfoBean(BillingInfoBean billingInfoBean) {
        this.billingInfoBean = billingInfoBean;
    }

}
