package com.truworth.wellnesscorner.repo.model.request;

public class EventCheckInRequest extends BaseRequest {


    private String myStatus;
    private String CircleId;

    public String getMyStatus() {
        return myStatus;
    }

    public void setMyStatus(String myStatus) {
        this.myStatus = myStatus;
    }

    public String getCircleId() {
        return CircleId;
    }

    public void setCircleId(String circleId) {
        CircleId = circleId;
    }
}
