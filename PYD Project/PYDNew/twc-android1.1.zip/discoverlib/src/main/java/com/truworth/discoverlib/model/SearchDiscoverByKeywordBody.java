package com.truworth.discoverlib.model;

/**
 * Created by ManishJ1 on 8/12/2016.
 */
public class SearchDiscoverByKeywordBody {

    private int MemberID;
    private String Keyword;
    private String Type;
    private int PageIndex;

    public int getMemberID() {
        return MemberID;
    }

    public void setMemberID(int memberID) {
        MemberID = memberID;
    }

    public String getKeyword() {
        return Keyword;
    }

    public void setKeyword(String Keyword) {
        this.Keyword = Keyword;
    }

    public String getType() {
        return Type;
    }

    public void setType(String Type) {
        this.Type = Type;
    }

    public int getPageIndex() {
        return PageIndex;
    }

    public void setPageIndex(int PageIndex) {
        this.PageIndex = PageIndex;
    }
}
