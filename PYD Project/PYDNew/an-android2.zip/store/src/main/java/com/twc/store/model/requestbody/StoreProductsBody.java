package com.twc.store.model.requestbody;

/**
 * If this code works it was written by Somesh Kumar on 04 May, 2017. If not, I don't know who wrote it.
 */
public class StoreProductsBody {
}
