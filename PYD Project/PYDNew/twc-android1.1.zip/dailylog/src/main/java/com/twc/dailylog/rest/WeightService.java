package com.twc.dailylog.rest;



import com.twc.dailylog.model.requestbody.BaseMemberIdBody;
import com.twc.dailylog.model.requestbody.SaveCurrentWeightBody;
import com.twc.dailylog.model.requestbody.SaveTargetWeightBody;
import com.twc.dailylog.model.response.SaveCurrentWeightResponse;
import com.twc.dailylog.model.response.SaveTargetWeightResponse;
import com.twc.dailylog.model.response.WeightLogResponse;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

/**
 * Created by PalakC on 7/6/2016.
 */
public interface WeightService {

   // @Headers({"Content-Type: application/json", "charset: utf-8"})
    @POST("member/Tracker/GetAllWeightReadings")
    Call<WeightLogResponse> getWeight(@Body BaseMemberIdBody weightBody);


    @POST("member/Tracker/SaveWeightReading")
    Call<SaveCurrentWeightResponse> getSaveCurrentWeight(@Body SaveCurrentWeightBody addWeightBody);

    @POST("member/Tracker/SaveTargetWeight")
    Call<SaveTargetWeightResponse> getSaveTargetWeight(@Body SaveTargetWeightBody saveTargetWeightBody);


}
