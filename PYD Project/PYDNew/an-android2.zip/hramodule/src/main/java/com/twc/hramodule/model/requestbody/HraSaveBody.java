package com.twc.hramodule.model.requestbody;

import java.util.List;

/**
 * Created by GurvinderS on 10/15/2016.
 */
public class HraSaveBody {


    private String MemberID;
    private String FromMobile;
    private List<QuestionBean> Question;

    public String getMemberID() {
        return MemberID;
    }

    public void setMemberID(String MemberID) {
        this.MemberID = MemberID;
    }

    public String getFromMobile() {
        return FromMobile;
    }

    public void setFromMobile(String FromMobile) {
        this.FromMobile = FromMobile;
    }

    public List<QuestionBean> getQuestion() {
        return Question;
    }

    public void setQuestion(List<QuestionBean> Question) {
        this.Question = Question;
    }

    public static class QuestionBean {
        private long QuestionID;
        private String Answer;
        private int isSure;

        public long getQuestionID() {
            return QuestionID;
        }

        public void setQuestionID(long QuestionID) {
            this.QuestionID = QuestionID;
        }

        public String getAnswer() {
            return Answer;
        }

        public void setAnswer(String Answer) {
            this.Answer = Answer;
        }

        public int getIsSure() {
            return isSure;
        }

        public void setIsSure(int isSure) {
            this.isSure = isSure;
        }
    }
}
