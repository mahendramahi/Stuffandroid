package com.twc.store.restservice;


import com.twc.store.model.requestbody.StateRequestBody;
import com.twc.store.model.response.StateListResponse;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

/**
 * Created by PalakC on 7/6/2016.
 */
public interface SettingService {

    // @Headers({"Content-Type: application/json", "charset: utf-8"})




    @POST("Member/value/GetStateList")
    Call<StateListResponse> getStateList(@Body StateRequestBody body);



}
