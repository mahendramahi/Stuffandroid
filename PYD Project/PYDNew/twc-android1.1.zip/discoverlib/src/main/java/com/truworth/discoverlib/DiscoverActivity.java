package com.truworth.discoverlib;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.TextView;

import com.truworth.discoverlib.fragment.DiscoverFragment;
import com.truworth.discoverlib.utils.Utils;

import java.util.Objects;

public class DiscoverActivity extends AppCompatActivity {

    private Toolbar mToolbar;
    private TextView tvToolbarTitle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_discover);
        setupToolbar();
        Utils.replaceFragment(getFragmentManager(), DiscoverFragment.newInstance(null), DiscoverFragment.class.getSimpleName(), true, R.id.container);
    }

    @Override
    protected void onResume() {
        super.onResume();
        Objects.requireNonNull(getSupportActionBar()).setDisplayShowTitleEnabled(false);
    }

    private void setupToolbar() {
        mToolbar = findViewById(R.id.toolbar);
        tvToolbarTitle = findViewById(R.id.tbTitle);
        setSupportActionBar(mToolbar);
        mToolbar.setNavigationIcon(R.drawable.ic_arrow_left_white_24dp);
        mToolbar.setNavigationOnClickListener((View view) -> onBackPressed());
    }

    public void setToolBarTitle(String toolBarTitle) {
        tvToolbarTitle.setText(toolBarTitle);
        assert getSupportActionBar() != null;
        getSupportActionBar().show();
    }

    public void showActionDrawerToggleToolbar() {
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(false);
            getSupportActionBar().setDisplayShowHomeEnabled(false);
        }
    }

    public void hideToolbarTitle() {
        assert getSupportActionBar() != null;
        tvToolbarTitle.setText("");
    }


    public void showHomeAsUpEnableToolbar() {
        mToolbar.setNavigationIcon(R.drawable.ic_arrow_left_white_24dp);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }
    }


    @Override
    public void onBackPressed() {
        int count = getFragmentManager().getBackStackEntryCount();
        //1 == HomeFragment
        if (count == 1) {
            finish();
        } else {
            super.onBackPressed();
        }
    }
}
