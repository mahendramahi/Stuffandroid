package com.truworth.wellnesscorner.ui.step;

import android.app.Fragment;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;


import com.truworth.wellnesscorner.R;
import com.truworth.wellnesscorner.utils.AppConstants;



import java.util.ArrayList;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * Created by GurvinderS on 9/8/2016.
 */
// Add MISFIT in list by PalakC on 2 feb 2018
public class ConnectDeviceListFragment extends Fragment {


    @BindView(R.id.rvConnectDevise)
    RecyclerView rvConnectDevise;


    private ArrayList<ConnectDeviceItem> listConnectDevice;
    private boolean redirectFromRecommendation;


    public static ConnectDeviceListFragment newInstance(Bundle bundle) {
        ConnectDeviceListFragment connectDeviceListFragment = new ConnectDeviceListFragment();
        connectDeviceListFragment.setArguments(bundle);
        return connectDeviceListFragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (getArguments() != null) {
            redirectFromRecommendation = getArguments().getBoolean("redirectFromRecommendation");
        }

        listConnectDevice = new ArrayList<>();

        ConnectDeviceItem fitbitItem = new ConnectDeviceItem();
        fitbitItem.setDeviceName(AppConstants.FITBIT);
        fitbitItem.setDeviceIcon(R.drawable.fitbit_logo);

        ConnectDeviceItem samsungHealthItem = new ConnectDeviceItem();
        samsungHealthItem.setDeviceName(AppConstants.S_HEALTH);
        samsungHealthItem.setDeviceIcon(R.drawable.ic_samsung_health);

        ConnectDeviceItem gFitItem = new ConnectDeviceItem();
        gFitItem.setDeviceName(AppConstants.GOOGLE_FIT);
        gFitItem.setDeviceIcon(R.drawable.ic_google_fit);

        ConnectDeviceItem eFitItem = new ConnectDeviceItem();
        eFitItem.setDeviceName(AppConstants.E_FIT);
        eFitItem.setDeviceIcon(R.drawable.ic_efit);

        ConnectDeviceItem misFitItem = new ConnectDeviceItem();
        misFitItem.setDeviceName(AppConstants.MISFIT);
        misFitItem.setDeviceIcon(R.drawable.ic_misfit_logo);

        ConnectDeviceItem garminFitItem = new ConnectDeviceItem();
        garminFitItem.setDeviceName(AppConstants.GARMIN);
        garminFitItem.setDeviceIcon(R.drawable.ic_efit);

        listConnectDevice.add(eFitItem);
        listConnectDevice.add(fitbitItem);
        listConnectDevice.add(samsungHealthItem);
        listConnectDevice.add(gFitItem);
        listConnectDevice.add(misFitItem);
        //listConnectDevice.add(garminFitItem);

    }

    @Override
    public void onResume() {
        super.onResume();
      if (getActivity() instanceof StepActivity) {
            ((StepActivity) getActivity()).showHomeAsUpEnableToolbar();
            ((StepActivity) getActivity()).makeStatusBarColorDefault();
            ((StepActivity) getActivity()).makeToolbarColorDefault();
            ((StepActivity) getActivity()).makeToolBarTitleColorDefault();
            ((StepActivity) getActivity()).setToolBarTitle("Connect Apps and Devices");
        }
    }


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_connect_devicelist, container, false);
        ButterKnife.bind(this, rootView);
        rvConnectDevise.setHasFixedSize(true);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getActivity());
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        rvConnectDevise.setLayoutManager(linearLayoutManager);


     ConnectDeviceAdapter mConnectDeviceAdapter = new ConnectDeviceAdapter(listConnectDevice, redirectFromRecommendation, getActivity());
      rvConnectDevise.setAdapter(mConnectDeviceAdapter);
        return rootView;
    }

}
