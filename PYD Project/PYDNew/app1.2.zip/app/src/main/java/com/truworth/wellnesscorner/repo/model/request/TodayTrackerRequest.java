package com.truworth.wellnesscorner.repo.model.request;

public class TodayTrackerRequest {
    public String getDeviceDate() {
        return DeviceDate;
    }

    public void setDeviceDate(String deviceDate) {
        DeviceDate = deviceDate;
    }

    private String DeviceDate;
}
