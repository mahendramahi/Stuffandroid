package com.twc.store.model.response;

/**
 * Created by GurvinderS on 9/19/2017.
 */

public class StoreUpdateOrderResponse {

    /**
     * status : 0
     */

    private int status;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }
}
