package com.twc.store.model.beans;

/**
 * Created by richas on 9/14/2017.
 */

public class UpdateCartQuantityBean {

    private double ItemAmount;
    private double TotalTaxAmount;
    private double TotalAmount;
    private int Quantity;

    public double getItemAmount() {
        return ItemAmount;
    }

    public void setItemAmount(double ItemAmount) {
        this.ItemAmount = ItemAmount;
    }

    public double getTotalTaxAmount() {
        return TotalTaxAmount;
    }

    public void setTotalTaxAmount(double TotalTaxAmount) {
        this.TotalTaxAmount = TotalTaxAmount;
    }

    public double getTotalAmount() {
        return TotalAmount;
    }

    public void setTotalAmount(double TotalAmount) {
        this.TotalAmount = TotalAmount;
    }

    public int getQuantity() {
        return Quantity;
    }

    public void setQuantity(int quantity) {
        Quantity = quantity;
    }
}
