package com.truworth.wellnesscorner.model;

public class ShareDashboardBean {

    private String date;
    private String memberName;
    private String memberImage;
    private int steps;
    private double stepsCompliance;
    private double calsConsumed;
    private double calsConsumedCompliance;
    private double calsBurned;
    private double calsBurnedCompliance;
    private int glasses;
    private double glassesCompliance;

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getMemberName() {
        return memberName;
    }

    public void setMemberName(String memberName) {
        this.memberName = memberName;
    }

    public String getMemberImage() {
        return memberImage;
    }

    public void setMemberImage(String memberImage) {
        this.memberImage = memberImage;
    }

    public int getSteps() {
        return steps;
    }

    public void setSteps(int steps) {
        this.steps = steps;
    }

    public double getStepsCompliance() {
        return stepsCompliance;
    }

    public void setStepsCompliance(double stepsCompliance) {
        this.stepsCompliance = stepsCompliance;
    }

    public double getCalsConsumed() {
        return calsConsumed;
    }

    public void setCalsConsumed(double calsConsumed) {
        this.calsConsumed = calsConsumed;
    }

    public double getCalsConsumedCompliance() {
        return calsConsumedCompliance;
    }

    public void setCalsConsumedCompliance(double calsConsumedCompliance) {
        this.calsConsumedCompliance = calsConsumedCompliance;
    }

    public double getCalsBurned() {
        return calsBurned;
    }

    public void setCalsBurned(double calsBurned) {
        this.calsBurned = calsBurned;
    }

    public double getCalsBurnedCompliance() {
        return calsBurnedCompliance;
    }

    public void setCalsBurnedCompliance(double calsBurnedCompliance) {
        this.calsBurnedCompliance = calsBurnedCompliance;
    }

    public int getGlasses() {
        return glasses;
    }

    public void setGlasses(int glasses) {
        this.glasses = glasses;
    }

    public double getGlassesCompliance() {
        return glassesCompliance;
    }

    public void setGlassesCompliance(double glassesCompliance) {
        this.glassesCompliance = glassesCompliance;
    }
}
