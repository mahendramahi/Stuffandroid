package com.truworth.wellnesscorner.network;

import com.truworth.wellnesscorner.repo.model.request.ActivityMarkAsReadBody;
import com.truworth.wellnesscorner.repo.model.request.BMIRequest;
import com.truworth.wellnesscorner.repo.model.request.BaseMemberIdBody;
import com.truworth.wellnesscorner.repo.model.request.ChallengeLeaderBoardRequest;
import com.truworth.wellnesscorner.repo.model.request.CircleChallengeRequest;
import com.truworth.wellnesscorner.repo.model.request.BaseRequest;
import com.truworth.wellnesscorner.repo.model.request.CircleDetailPostRequest;
import com.truworth.wellnesscorner.repo.model.request.CircleMemberRequest;
import com.truworth.wellnesscorner.repo.model.request.CirclePostsRequest;
import com.truworth.wellnesscorner.repo.model.request.CommentHiFiveRequest;
import com.truworth.wellnesscorner.repo.model.request.CommentRequest;
import com.truworth.wellnesscorner.repo.model.request.CreatePostRequest;
import com.truworth.wellnesscorner.repo.model.request.DeviceStepRequest;
import com.truworth.wellnesscorner.repo.model.request.EmailRequest;
import com.truworth.wellnesscorner.repo.model.request.EventCheckInRequest;
import com.truworth.wellnesscorner.repo.model.request.GetCommentsListRequest;
import com.truworth.wellnesscorner.repo.model.request.GetCountryStateByCityNameRequest;
import com.truworth.wellnesscorner.repo.model.request.GetMemberProgramDetailBody;
import com.truworth.wellnesscorner.repo.model.request.CityIdRequest;
import com.truworth.wellnesscorner.repo.model.request.LeaveProgramChallengeBody;
import com.truworth.wellnesscorner.repo.model.request.LoginRequest;
import com.truworth.wellnesscorner.repo.model.request.MyRankRequest;
import com.truworth.wellnesscorner.repo.model.request.OTPRequest;
import com.truworth.wellnesscorner.repo.model.request.PostTagRequest;
import com.truworth.wellnesscorner.repo.model.request.SaveCityRequest;
import com.truworth.wellnesscorner.repo.model.request.SaveDeviceStepsBody;
import com.truworth.wellnesscorner.repo.model.request.SaveMemberHealthGoalsRequest;
import com.truworth.wellnesscorner.repo.model.request.SaveMemberRequest;
import com.truworth.wellnesscorner.repo.model.request.SaveProfileRequest;
import com.truworth.wellnesscorner.repo.model.request.ScreenNameRequest;
import com.truworth.wellnesscorner.repo.model.request.ShareDashboardRequest;
import com.truworth.wellnesscorner.repo.model.request.ShareMealRequest;
import com.truworth.wellnesscorner.repo.model.request.TodayChallengeRequest;
import com.truworth.wellnesscorner.repo.model.request.TodayPostsRequest;
import com.truworth.wellnesscorner.repo.model.request.TodayTrackerRequest;
import com.truworth.wellnesscorner.repo.model.request.VerifyOtpRequest;
import com.truworth.wellnesscorner.repo.model.response.ActivityMarkAsReadResponse;
import com.truworth.wellnesscorner.repo.model.response.BMIResponse;
import com.truworth.wellnesscorner.repo.model.response.ChallengeLeaderBoardResponse;
import com.truworth.wellnesscorner.repo.model.response.CircleAboutResponse;
import com.truworth.wellnesscorner.repo.model.response.CircleChallengeResponse;
import com.truworth.wellnesscorner.repo.model.response.CircleCoachResponse;
import com.truworth.wellnesscorner.repo.model.response.CircleMembersResponse;
import com.truworth.wellnesscorner.repo.model.response.CircleResponse;
import com.truworth.wellnesscorner.repo.model.response.CountryResponse;
import com.truworth.wellnesscorner.repo.model.response.CreatePostResponse;
import com.truworth.wellnesscorner.repo.model.response.EmailExistResponse;
import com.truworth.wellnesscorner.repo.model.response.EventCheckInResponse;
import com.truworth.wellnesscorner.repo.model.response.GetCommentsListResponse;
import com.truworth.wellnesscorner.repo.model.response.GetCountryStateByCityNameResponse;
import com.truworth.wellnesscorner.repo.model.response.GetJoinCircleResponse;
import com.truworth.wellnesscorner.repo.model.response.GetMemberProgramDetailResponse;
import com.truworth.wellnesscorner.repo.model.response.GetMemberProgramResponse;
import com.truworth.wellnesscorner.repo.model.response.GetMonthlyDeviceStepsResponse;
import com.truworth.wellnesscorner.repo.model.response.HealthGoalResponse;
import com.truworth.wellnesscorner.repo.model.response.LeaveProgramChallengeResponse;
import com.truworth.wellnesscorner.repo.model.response.LoginResponse;
import com.truworth.wellnesscorner.repo.model.response.MemberProgramComplianceResponse;
import com.truworth.wellnesscorner.repo.model.response.MyCirclesResponse;
import com.truworth.wellnesscorner.repo.model.response.MyRankResponse;
import com.truworth.wellnesscorner.repo.model.response.OTPResponse;
import com.truworth.wellnesscorner.repo.model.response.PopularArticlesResponse;
import com.truworth.wellnesscorner.repo.model.response.PopularCircleResponse;
import com.truworth.wellnesscorner.repo.model.response.PopularDiscussionsResponse;
import com.truworth.wellnesscorner.repo.model.response.PopularProductResponse;
import com.truworth.wellnesscorner.repo.model.response.PostHiFiResponse;
import com.truworth.wellnesscorner.repo.model.response.PostResponse;
import com.truworth.wellnesscorner.repo.model.response.PostWeightResponse;
import com.truworth.wellnesscorner.repo.model.response.RegisterOtpResponse;
import com.truworth.wellnesscorner.repo.model.response.RegisterOtpVerifyResponse;
import com.truworth.wellnesscorner.repo.model.response.ResetPasswordResponse;
import com.truworth.wellnesscorner.repo.model.response.SaveCityResponse;
import com.truworth.wellnesscorner.repo.model.response.SaveCommentResponse;
import com.truworth.wellnesscorner.repo.model.response.SaveMemberHealthGoalsResponse;
import com.truworth.wellnesscorner.repo.model.response.SaveMemberResponse;
import com.truworth.wellnesscorner.repo.model.response.SaveProfileResponse;
import com.truworth.wellnesscorner.repo.model.response.SaveStepsResponse;
import com.truworth.wellnesscorner.repo.model.response.ScreenNameResponse;
import com.truworth.wellnesscorner.repo.model.response.ShareDashboardResponse;
import com.truworth.wellnesscorner.repo.model.response.ShareMealNewResponse;
import com.truworth.wellnesscorner.repo.model.response.ShareExerciseResponse;
import com.truworth.wellnesscorner.repo.model.response.ShareMealResponse;
import com.truworth.wellnesscorner.repo.model.response.ShareStepsResponse;
import com.truworth.wellnesscorner.repo.model.response.StateByCountryResponse;
import com.truworth.wellnesscorner.repo.model.response.TagResponse;
import com.truworth.wellnesscorner.repo.model.response.TodayMyChallengesResponse;
import com.truworth.wellnesscorner.repo.model.response.TodayTrackerResponse;
import com.truworth.wellnesscorner.repo.model.response.VerifyOtpResponse;

import io.reactivex.Observable;
import retrofit2.http.Body;
import retrofit2.http.POST;

/**
 * Created by rajeshs on 3/27/2018.
 */

public interface ApiServices {

    @POST("login/checkemailexist")
    Observable<EmailExistResponse> isEmailExist(@Body EmailRequest emailId);

    @POST("login")
    Observable<LoginResponse> login(@Body LoginRequest loginRequest);

    @POST("member/value/GetCountry")
    Observable<CountryResponse> getCountryList();

    @POST("value/GetStateByCountryId")
    Observable<StateByCountryResponse> getStateList(@Body CityIdRequest idRequest);

    @POST("register/citysearch")
    Observable<GetCountryStateByCityNameResponse> getCountryStateList(@Body GetCountryStateByCityNameRequest getCountryStateByCityNameRequest);

    @POST("value/GetCityByStateId")
    Observable<StateByCountryResponse> getCityList(@Body CityIdRequest idRequest);

    @POST("login/otp")
    Observable<OTPResponse> sendOtp(@Body OTPRequest otpRequest);

    @POST("login/loginwotp")
    Observable<VerifyOtpResponse> getVerifyOtp(@Body VerifyOtpRequest otpRequest);

    @POST("login/resetpassword")
    Observable<ResetPasswordResponse> resetPassword(@Body EmailRequest emailRequest);

    @POST("register/mobile")
    Observable<RegisterOtpResponse> sendOtpForRegistration(@Body OTPRequest otpRequest);

    @POST("register/mobile/verification")
    Observable<RegisterOtpVerifyResponse> getVerifyOtpRegister(@Body VerifyOtpRequest otpRequest);

    @POST("register")
    Observable<SaveMemberResponse> saveMemberRegistration(@Body SaveMemberRequest request);

    @POST("register/profile")
    Observable<SaveProfileResponse> saveMemberProfile(@Body SaveProfileRequest request);

    @POST("register/bmi")
    Observable<BMIResponse> getMemberBMIAndIBW(@Body BMIRequest bmiRequest);

    @POST("register/healthgoals")
    Observable<HealthGoalResponse> getHealthGoal();

    @POST("register/checkscreennameexist")
    Observable<ScreenNameResponse> checkScreenName(@Body ScreenNameRequest request);

    @POST("register/healthgoal")
    Observable<SaveMemberHealthGoalsResponse> saveMemberHealthGoals(@Body SaveMemberHealthGoalsRequest request);


    //Dashboard services
    @POST("mycircles")
    Observable<MyCirclesResponse> getMyCircles();

    @POST("mycircles/popularcircles")
    Observable<PopularCircleResponse> getPopularCircles();

    @POST("mycircles/products")
    Observable<PopularProductResponse> getPopularProducts();

    @POST("mycircles/articles")
    Observable<PopularArticlesResponse> getPopularArticles();

    @POST("register/location")
    Observable<SaveCityResponse> saveMembeCity(@Body SaveCityRequest saveCityRequest);

    @POST("mycircles/discussions")
    Observable<PopularDiscussionsResponse> getPopularDiscussions();

    @POST("Circle/Coaches")
    Observable<CircleCoachResponse> getCircleCoaches(@Body BaseRequest circleCoachRequest);

    @POST("today")
    Observable<TodayTrackerResponse> getTodayTracker(@Body TodayTrackerRequest todayTrackerRequest);


    @POST("today/posts")
    Observable<PostResponse> getTodayPost(@Body TodayPostsRequest todayPostsRequest);

    @POST("today/challenges")
    Observable<TodayMyChallengesResponse> getTodayMyChallenges(@Body TodayChallengeRequest todayChallengeRequest);

    @POST("Circle")
    Observable<CircleResponse> getCircleDetail(@Body BaseRequest circleCoachRequest);

    @POST("Circle/posts")
    Observable<PostResponse> getCirclePosts(@Body CirclePostsRequest circleCoachRequest);

    @POST("Circle/members")
    Observable<CircleMembersResponse> getCircleMembers(@Body CircleMemberRequest circleMemberRequest);

    @POST("Circle/challenges")
    Observable<CircleChallengeResponse> getCircleChallenges(@Body CircleChallengeRequest circleChallengeRequest);

    @POST("Circle/events/checkin")
    Observable<EventCheckInResponse> getEventCheckIn(@Body EventCheckInRequest checkInRequest);

    @POST("Circle/about")
    Observable<CircleAboutResponse> getCircleAboutDetails(@Body BaseRequest circleCoachRequest);

    @POST("Circle/posts")
    Observable<PostResponse> getCirclePostsWithPaging(@Body CircleDetailPostRequest circleDetailPostRequest);

    @POST("Circle/JoinCircle")
    Observable<GetJoinCircleResponse> getJoinCircle(@Body BaseRequest baseRequest);

    // post services

    @POST("post/high-five")
    Observable<PostHiFiResponse> getPostHiFi(@Body BaseRequest postHiFiRequest);

    @POST("post/save-comment")
    Observable<SaveCommentResponse> saveComment(@Body CommentRequest commentRequest);

    @POST("post/comments")
    Observable<GetCommentsListResponse> getCommentsList(@Body GetCommentsListRequest commentsListRequest);

    @POST("social/comments/High-Five")
    Observable<PostHiFiResponse> getCommentHiFi(@Body BaseRequest hiFiveRequest);


    @POST("Circle/challenges/leaderboard")
    Observable<ChallengeLeaderBoardResponse> getLeaderBoardData(@Body ChallengeLeaderBoardRequest challengeLeaderBoardRequest);

    @POST("Circle/challenges/myrank")
    Observable<MyRankResponse> getMyRank(@Body MyRankRequest myRankRequest);

    // my task services
    @POST("program")
    Observable<GetMemberProgramResponse> getmemberprogram(@Body BaseMemberIdBody memberIdBody);

    @POST("tasks")
    Observable<GetMemberProgramDetailResponse> getmemberprogramdetail(@Body GetMemberProgramDetailBody memberProgramDetailBody);

    @POST("MemberDashboard/MemberActivityMarkAsRead")
    Observable<ActivityMarkAsReadResponse> getActivityMarkAsRead(@Body ActivityMarkAsReadBody getchallengeCheckInBody);

    @POST("MemberDashboard/LeaveProgramChallenge")
    Observable<LeaveProgramChallengeResponse> leaveProgramChallenge(@Body LeaveProgramChallengeBody leaveProgramChallengeBody);

    @POST("MemberDashboard/GetMemberProgramCompliance")
    Observable<MemberProgramComplianceResponse> getMemberProgramCompliance(@Body GetMemberProgramDetailBody memberProgramDetailBody);

    @POST("MemberDashboard/MemberActivityMarkAsDelete")
    Observable<ActivityMarkAsReadResponse> getActivityMarkAsDelete(@Body ActivityMarkAsReadBody getchallengeCheckInBody);

    @POST("member/Steps/SaveMemberSteps")
    Observable<SaveStepsResponse> saveDeviceSteps(@Body SaveDeviceStepsBody saveDeviceStepsBody);

    @POST("member/Steps/GetSteps")
    Observable<GetMonthlyDeviceStepsResponse> getMemberStepsFromServer(@Body DeviceStepRequest deviceStepRequest);

    //Post tag members
    @POST("post/create-post/tags")
    Observable<TagResponse> getTagMembers(@Body PostTagRequest myRankRequest);

    @POST("post/dashboard")
    Observable<ShareDashboardResponse> getPostDashboard(@Body ShareDashboardRequest shareDashboardRequest);

    @POST("post/steps")
    Observable<ShareStepsResponse> getPostSteps(@Body ShareDashboardRequest shareDashboardRequest);

    @POST("post/meal")
    Observable<ShareMealNewResponse> getPostMeal(@Body ShareMealRequest shareMealRequest);

    @POST("post/exercise")
    Observable<ShareExerciseResponse> getPostExercise(@Body ShareMealRequest shareMealRequest);


    //create post
    @POST("post/create")
    Observable<CreatePostResponse> createPost(@Body CreatePostRequest postRequest);


    @POST("post/weight")
    Observable<PostWeightResponse> getPostWeight(@Body ShareDashboardRequest shareDashboardRequest);

}
