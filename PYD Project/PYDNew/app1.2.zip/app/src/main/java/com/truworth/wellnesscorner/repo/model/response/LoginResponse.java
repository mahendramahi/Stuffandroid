package com.truworth.wellnesscorner.repo.model.response;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.truworth.wellnesscorner.model.LoginData;

/**
 * Created by rajeshs on 3/29/2018.
 */

public class LoginResponse {

    @SerializedName("data")
    @Expose
    private LoginData data;
    @SerializedName("hasError")
    @Expose
    private boolean hasError;
    @SerializedName("message")
    @Expose
    private String message;

    @SerializedName("error")
    @Expose
    private Error error;


    public Error getError() {
        return error;
    }

    public void setError(Error error) {
        this.error = error;
    }

    public boolean isHasError() {
        return hasError;
    }

    public void setHasError(boolean hasError) {
        this.hasError = hasError;
    }

    public LoginData getData() {
        return data;
    }

    public void setData(LoginData data) {
        this.data = data;
    }


    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

}
