package com.twc.remindermodule.dialog;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.view.View;
import android.view.Window;
import android.widget.TextView;

import com.twc.remindermodule.fragments.OnRetryAfterNetworkError;
import com.twc.remindermodule.R;


/**
 * Created by GurvinderS on 2/2/2018.
 */


public class ApiErrorDialog extends Dialog {
    private Activity activity;
    OnRetryAfterNetworkError mOnRetryAfterNetworkError;
    public ApiErrorDialog(@NonNull Context context, Activity activity, OnRetryAfterNetworkError onRetryAfterNetworkError) {
        super(context, R.style.FullScreenTheme);
        this.activity = activity;
        this.mOnRetryAfterNetworkError=onRetryAfterNetworkError;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        View view = activity.getLayoutInflater().inflate(R.layout.view_error_layout, null);
        setContentView(view);

        View parent = (View) view.getParent();
        parent.setFitsSystemWindows(true);
        /*final BottomSheetBehavior bottomSheetBehavior = BottomSheetBehavior.from(parent);
        parent.measure(0, 0);
        DisplayMetrics displaymetrics = new DisplayMetrics();
        activity.getWindowManager().getDefaultDisplay().getMetrics(displaymetrics);
        int screenHeight = displaymetrics.heightPixels;*/
       // bottomSheetBehavior.setPeekHeight(screenHeight);
        TextView tvRetry = view.findViewById(R.id.tvRetry);
        tvRetry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dismiss();
                mOnRetryAfterNetworkError.onRetry();
            }
        });
       /* final Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                bottomSheetBehavior.setState(BottomSheetBehavior.STATE_EXPANDED);
            }
        }, 100);


        bottomSheetBehavior.setBottomSheetCallback(new BottomSheetBehavior.BottomSheetCallback() {
            @Override
            public void onStateChanged(@NonNull View bottomSheet, int newState) {
                if (newState == BottomSheetBehavior.STATE_DRAGGING) {
                    bottomSheetBehavior.setState(BottomSheetBehavior.STATE_EXPANDED);
                }
            }

            @Override
            public void onSlide(@NonNull View bottomSheet, float slideOffset) {
            }
        });*/
    }
}
