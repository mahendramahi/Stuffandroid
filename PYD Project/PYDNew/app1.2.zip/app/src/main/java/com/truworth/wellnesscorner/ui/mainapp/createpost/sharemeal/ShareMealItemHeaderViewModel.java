package com.truworth.wellnesscorner.ui.mainapp.createpost.sharemeal;

import com.truworth.wellnesscorner.base.BaseViewModel;
import com.truworth.wellnesscorner.model.ShareMealBean;
import com.truworth.wellnesscorner.utils.DateUtils;

public class ShareMealItemHeaderViewModel extends BaseViewModel {

    public ShareMealBean shareMealBean;

    public ShareMealBean getShareMealBean() {
        return shareMealBean;
    }

    public void setShareMealBean(ShareMealBean shareMealBean) {
        this.shareMealBean = shareMealBean;
    }

    public ShareMealItemHeaderViewModel(ShareMealBean shareMealBean) {

        this.shareMealBean = shareMealBean;
    }


    public String getDateInFormat(String date){
        String newDateString ="";
        if(date !=null)
            newDateString = DateUtils.formatDate(date, "yyyy-MM-dd'T'HH:mm:ss", "MMMM dd, yyyy");
        return newDateString;
    }
}