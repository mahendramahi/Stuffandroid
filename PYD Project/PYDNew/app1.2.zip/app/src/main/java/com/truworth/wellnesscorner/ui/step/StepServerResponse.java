package com.truworth.wellnesscorner.ui.step;

import java.util.List;

public class StepServerResponse {

    private int status;
    private DataBean Data;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public DataBean getData() {
        return Data;
    }

    public void setData(DataBean Data) {
        this.Data = Data;
    }

    public static class DataBean {
        private int NotificationCount;

        private String MemberName;
        private String Steps;
        private int TasksCount;
        private String HabitReminderUpdateDate;
        private String LastStepSyncDate;
        private String LastStepUpdatedDate;
        private String LastConnectedDevice;
        private String FirstStepSyncDate;

        public String getFirstStepSyncDate() {
            return FirstStepSyncDate;
        }

        public void setFirstStepSyncDate(String firstStepSyncDate) {
            FirstStepSyncDate = firstStepSyncDate;
        }




        public int getNotificationCount() {
            return NotificationCount;
        }

        public void setNotificationCount(int NotificationCount) {
            this.NotificationCount = NotificationCount;
        }

        public String getMemberName() {
            return MemberName;
        }

        public void setMemberName(String MemberName) {
            this.MemberName = MemberName;
        }

        public String getSteps() {
            return Steps;
        }

        public void setSteps(String Steps) {
            this.Steps = Steps;
        }

        public int getTasksCount() {
            return TasksCount;
        }

        public void setTasksCount(int TasksCount) {
            this.TasksCount = TasksCount;
        }



        public String getHabitReminderUpdateDate() {
            return HabitReminderUpdateDate;
        }

        public void setHabitReminderUpdateDate(String habitReminderUpdateDate) {
            HabitReminderUpdateDate = habitReminderUpdateDate;
        }

        public String getLastStepSyncDate() {
            return LastStepSyncDate;
        }

        public void setLastStepSyncDate(String lastStepSyncDate) {
            LastStepSyncDate = lastStepSyncDate;
        }

        public String getLastConnectedDevice() {
            return LastConnectedDevice;
        }

        public void setLastConnectedDevice(String lastConnectedDevice) {
            LastConnectedDevice = lastConnectedDevice;
        }

        public String getLastStepUpdatedDate() {
            return LastStepUpdatedDate;
        }

        public void setLastStepUpdatedDate(String lastStepUpdatedDate) {
            LastStepUpdatedDate = lastStepUpdatedDate;
        }
    }

}
