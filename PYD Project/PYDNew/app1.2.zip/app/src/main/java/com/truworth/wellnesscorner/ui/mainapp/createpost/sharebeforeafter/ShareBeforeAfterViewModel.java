package com.truworth.wellnesscorner.ui.mainapp.createpost.sharebeforeafter;

import android.databinding.ObservableBoolean;

import com.truworth.wellnesscorner.base.BaseViewModel;
import com.truworth.wellnesscorner.utils.SingleLiveEvent;

public class ShareBeforeAfterViewModel extends BaseViewModel {

    public ObservableBoolean isShareEnabled = new ObservableBoolean();
    public ObservableBoolean showBeforeImage = new ObservableBoolean();
    public ObservableBoolean showAfterImage = new ObservableBoolean();

    SingleLiveEvent<Void> openGallery = new SingleLiveEvent<>();
    SingleLiveEvent<Void> openCamera = new SingleLiveEvent<>();
    SingleLiveEvent<Void> shareBtn = new SingleLiveEvent<>();

    public SingleLiveEvent<Void> getOpenGallery() {
        return openGallery;
    }
    public SingleLiveEvent<Void> getOpenCamera() {
        return openCamera;
    }
    public SingleLiveEvent<Void> getShareBtn() {
        return shareBtn;
    }

    public void openGalleryBtnClick(){
        openGallery.call();
    }
    public void openCameraBtnClick(){
        openCamera.call();
    }
    public void ShareBtnClick(){
        shareBtn.call();
    }
}
