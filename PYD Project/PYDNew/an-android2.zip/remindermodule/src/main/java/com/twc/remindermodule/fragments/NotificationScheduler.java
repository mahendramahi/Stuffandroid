package com.twc.remindermodule.fragments;

import android.app.Activity;
import android.app.AlarmManager;

import android.app.PendingIntent;

import android.content.Intent;

import android.os.Build;


import com.twc.remindermodule.receiver.AlarmReceiver;
import com.twc.remindermodule.utils.DateFactory;
import com.twc.remindermodule.utils.Utils;

import java.util.Calendar;





public class NotificationScheduler
{


    public static void setNotificationAlarm(Activity activity, AlarmManager alarmMgr, final int id, String title, String message, String time) {


        Intent intent = new Intent(activity, AlarmReceiver.class);
        intent.putExtra("id", id);
        intent.putExtra("title", title);
        intent.putExtra("message", message);
        PendingIntent alarmIntent = PendingIntent.getBroadcast(activity, id, intent, PendingIntent.FLAG_UPDATE_CURRENT);

        String formatTime = DateFactory.getInstance().formatTime("hh:mm a", "HH:mm", time);
        String timeArray[] = formatTime.split(":");

        Calendar calendar1 = Calendar.getInstance();
        int hour = calendar1.get(Calendar.HOUR_OF_DAY);
        int minute = calendar1.get(Calendar.MINUTE);


        if (Integer.parseInt(Integer.valueOf(timeArray[0]).toString()) >= hour) {
            if (hour == 0) {
                Utils.printLog("current/time hour", Integer.valueOf(timeArray[0]).toString());
                Utils.printLog("current/time minute", Integer.valueOf(timeArray[1]).toString());
                Calendar calendar = Calendar.getInstance();
                calendar.set(Calendar.HOUR_OF_DAY, Integer.parseInt(Integer.valueOf(timeArray[0]).toString()));
                calendar.set(Calendar.MINUTE, Integer.parseInt(Integer.valueOf(timeArray[1]).toString()));
                calendar.set(Calendar.SECOND, 0);

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                    alarmMgr.setExact(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), alarmIntent);
                } else {
                    alarmMgr.set(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), alarmIntent);
                }
            } else {
                if (Integer.parseInt(Integer.valueOf(timeArray[0]).toString()) == hour) {
                    if (Integer.parseInt(Integer.valueOf(timeArray[1]).toString()) > minute) {
                        Utils.printLog("current/time hour", Integer.valueOf(timeArray[0]).toString());
                        Utils.printLog("current/time minute", Integer.valueOf(timeArray[1]).toString());
                        Calendar calendar = Calendar.getInstance();
                        calendar.set(Calendar.HOUR_OF_DAY, Integer.parseInt(Integer.valueOf(timeArray[0]).toString()));
                        calendar.set(Calendar.MINUTE, Integer.parseInt(Integer.valueOf(timeArray[1]).toString()));
                        calendar.set(Calendar.SECOND, 0);

                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                            alarmMgr.setExact(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), alarmIntent);
                        } else {
                            alarmMgr.set(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), alarmIntent);
                        }
                    }
                } else if (Integer.parseInt(Integer.valueOf(timeArray[0]).toString()) > hour) {
                    Utils.printLog("current/time hour", Integer.valueOf(timeArray[0]).toString());
                    Utils.printLog("current/time minute", Integer.valueOf(timeArray[1]).toString());
                    Calendar calendar = Calendar.getInstance();
                    calendar.set(Calendar.HOUR_OF_DAY, Integer.parseInt(Integer.valueOf(timeArray[0]).toString()));
                    calendar.set(Calendar.MINUTE, Integer.parseInt(Integer.valueOf(timeArray[1]).toString()));
                    calendar.set(Calendar.SECOND, 0);

                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                        alarmMgr.setExact(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), alarmIntent);
                    } else {
                        alarmMgr.set(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), alarmIntent);
                    }
                }


            }
        }

    }

}
