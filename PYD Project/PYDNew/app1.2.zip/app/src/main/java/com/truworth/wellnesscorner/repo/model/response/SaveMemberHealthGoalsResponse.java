package com.truworth.wellnesscorner.repo.model.response;

/**
 * Created by PalakC on 4/11/2018.
 */

public class SaveMemberHealthGoalsResponse {

    private SaveMemberGoalItem data;
    private boolean hasError;
    private Error error;

    public SaveMemberGoalItem getData() {
        return data;
    }

    public void setData(SaveMemberGoalItem data) {
        this.data = data;
    }

    public boolean isHasError() {
        return hasError;
    }

    public void setHasError(boolean hasError) {
        this.hasError = hasError;
    }

    public Error getError() {
        return error;
    }

    public void setError(Error error) {
        this.error = error;
    }

    public static class SaveMemberGoalItem {
        private boolean isSave;

        public boolean isIsSave() {
            return isSave;
        }

        public void setIsSave(boolean isSave) {
            this.isSave = isSave;
        }
    }
}
