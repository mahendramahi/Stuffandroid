package com.twc.remindermodule.rest;

import android.content.Context;

/**
 * Created by ManishJ1 on 6/29/2016.
 */
public class RestClient extends AbstractRestClient {

    private ReminderApiService reminderApiService;

    public RestClient(Context context, String baseUrl, boolean debug) {
        super(context, baseUrl, debug);
    }

    @Override
    public void initApi() {

        reminderApiService = client.create(ReminderApiService.class);
    }


    public ReminderApiService getRecommendedService() {
        return reminderApiService;
    }


}
