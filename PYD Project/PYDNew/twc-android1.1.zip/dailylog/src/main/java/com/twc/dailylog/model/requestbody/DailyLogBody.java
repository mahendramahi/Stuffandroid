package com.twc.dailylog.model.requestbody;

/**
 * Created by ManishJ1 on 8/4/2016.
 */
public class DailyLogBody {

    private String MemberID;
    private String Date;

    public String getMemberID() {
        return MemberID;
    }

    public void setMemberID(String memberID) {
        MemberID = memberID;
    }

    public String getDate() {
        return Date;
    }

    public void setDate(String date) {
        Date = date;
    }
}
