package com.truworth.wellnesscorner.repo.model.request;

import com.google.gson.annotations.SerializedName;

/**
 * Created by richas on 4/10/2018.
 */

public class CityIdRequest {
    int Id;

    public int getId() {
        return Id;
    }

    public void setId(int id) {
        Id = id;
    }
}
