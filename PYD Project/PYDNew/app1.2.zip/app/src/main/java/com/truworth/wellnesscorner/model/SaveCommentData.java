package com.truworth.wellnesscorner.model;

public class SaveCommentData {
        private int totalComments;
        private int commentID;

        public int getTotalComments() {
            return totalComments;
        }

        public void setTotalComments(int totalComments) {
            this.totalComments = totalComments;
        }

        public int getCommentID() {
            return commentID;
        }

        public void setCommentID(int commentID) {
            this.commentID = commentID;
        }

}
