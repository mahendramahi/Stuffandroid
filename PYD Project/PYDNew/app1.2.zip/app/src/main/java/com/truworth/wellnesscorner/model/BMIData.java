package com.truworth.wellnesscorner.model;

import java.io.Serializable;

/**
 * Created by rajeshs on 4/9/2018.
 */

public class BMIData implements Serializable {

    double bmi;
    double ibw;
    String colorCode;
    String bmiDescription;
    String ibwDescription;


    String ibwDescriptionInfo;
    String fontColorCode;

    public String getFontColorCode() {
        return fontColorCode;
    }

    public void setFontColorCode(String fontColorCode) {
        this.fontColorCode = fontColorCode;
    }

    public String getBmiTitle() {
        return bmiTitle;
    }

    public void setBmiTitle(String bmiTitle) {
        this.bmiTitle = bmiTitle;
    }

    String bmiTitle;

    public double getBmi() {
        return bmi;
    }

    public void setBmi(double bmi) {
        this.bmi = bmi;
    }

    public double getIbw() {
        return ibw;
    }

    public String getBmiDescription() {
        return bmiDescription;
    }

    public void setBmiDescription(String bmiDescription) {
        this.bmiDescription = bmiDescription;
    }

    public String getIbwDescription() {
        return ibwDescription;
    }

    public void setIbwDescription(String ibwDescription) {
        this.ibwDescription = ibwDescription;
    }

    public String getIbwDescriptionInfo() {
        return ibwDescriptionInfo;
    }

    public void setIbwDescriptionInfo(String ibwDescriptionInfo) {
        this.ibwDescriptionInfo = ibwDescriptionInfo;
    }

    public void setIbw(double ibw) {
        this.ibw = ibw;
    }

    public String getColorCode() {
        return colorCode;
    }

    public void setColorCode(String colorCode) {
        this.colorCode = colorCode;
    }




}
