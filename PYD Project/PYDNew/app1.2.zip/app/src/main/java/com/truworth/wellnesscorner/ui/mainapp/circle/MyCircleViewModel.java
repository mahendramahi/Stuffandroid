package com.truworth.wellnesscorner.ui.mainapp.circle;

import android.databinding.ObservableBoolean;
import android.databinding.ObservableField;

import com.truworth.wellnesscorner.base.BaseViewModel;
import com.truworth.wellnesscorner.model.MyCircle;

/**
 * Created by rajeshs on 4/16/2018.
 */

public class MyCircleViewModel extends BaseViewModel {
    public final MyCircleListener myCircleListener;
    public ObservableBoolean isRating = new ObservableBoolean();
    public ObservableField<String> ratingValue = new ObservableField<>();
    public ObservableBoolean isPostVisible = new ObservableBoolean();
    public ObservableField<String> postValue = new ObservableField<>();
    public MyCircle myCircle;

    public MyCircleViewModel(MyCircle myCircle, MyCircleListener myCircleListener) {
        this.myCircle = myCircle;
        this.myCircleListener = myCircleListener;
    }

    public MyCircle getMyCircle() {
        return myCircle;

    }

    public void onItemClick() {
        myCircleListener.onItemClick();
    }

    public void getRating() {
        if (myCircle.getRating() > 0) {
            ratingValue.set(String.valueOf(myCircle.getRating()));
            isRating.set(true);
        } else
            isRating.set(false);
    }

    public void getNewPost() {
        if (myCircle.getTotalPosts() > 1) {
            postValue.set(String.valueOf(myCircle.getTotalPosts() + " new posts"));
            isPostVisible.set(true);
        } else if (myCircle.getTotalPosts() == 1) {
            postValue.set(String.valueOf(myCircle.getTotalPosts() + " new post"));
            isPostVisible.set(true);
        } else
            isPostVisible.set(false);
    }

    public interface MyCircleListener {

        void onItemClick();
    }
}
