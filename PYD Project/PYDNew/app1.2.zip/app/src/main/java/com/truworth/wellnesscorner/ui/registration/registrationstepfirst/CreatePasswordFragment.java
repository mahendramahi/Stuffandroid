package com.truworth.wellnesscorner.ui.registration.registrationstepfirst;

import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.text.InputFilter;
import android.text.Spanned;
import android.view.View;
import android.view.WindowManager;

import com.truworth.wellnesscorner.BR;
import com.truworth.wellnesscorner.R;
import com.truworth.wellnesscorner.base.BaseFragment;
import com.truworth.wellnesscorner.databinding.FragmentRegistrationPasswordBinding;
import com.truworth.wellnesscorner.repo.model.request.SaveMemberRequest;

public class CreatePasswordFragment extends BaseFragment<FragmentRegistrationPasswordBinding, CreatePasswordViewModel> {
    public static final String TAG = "CreatePasswordFragment";


    private static final String ARG_PARAM1 = "param1";
    private SaveMemberRequest memberRequest;

    CreatePasswordViewModel viewModel;

    public CreatePasswordFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @return A new instance of fragment CreatePasswordFragment.
     */

    public static CreatePasswordFragment newInstance(SaveMemberRequest param1) {
        CreatePasswordFragment fragment = new CreatePasswordFragment();
        Bundle args = new Bundle();
        args.putSerializable(ARG_PARAM1, param1);
               fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setKeyboardHideOnTapOutSide(false);
        getActivity().getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        if (getArguments() != null) {
            memberRequest = (SaveMemberRequest) getArguments().getSerializable(ARG_PARAM1);
        }
    }


    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        getViewDataBinding().etConfirmPassword.requestFocus();
        getViewDataBinding().etConfirmPassword.setFilters(new InputFilter[]{filter,new InputFilter.LengthFilter(20)});
        showKeyboard();
        setSubscribeForNavigation();

    }
    InputFilter filter = new InputFilter() {
        @Override
        public CharSequence filter(CharSequence source, int start, int end, Spanned dest, int dstart, int dend) {
            for (int i = start; i < end; i++) {
                int type = Character.getType(source.charAt(i));
                if (type == Character.SURROGATE || type == Character.OTHER_SYMBOL) {
                    return "";
                }
                if (Character.isSpaceChar(source.charAt(i)) || Character.isWhitespace(source.charAt(i))) {
                    return "";
                }
            }
            return null;
        }
    };
    public void setSubscribeForNavigation() {
        viewModel.getMoveToConfirmPassWord().observe(this, new Observer<Void>() {
            @Override
            public void onChanged(@Nullable Void aVoid) {
                moveToConfirmPasswordFragment();
            }
        });
    }


    /**
     * Override for set binding variable
     *
     * @return variable id
     */
    @Override
    public int getBindingVariable() {
        return BR.viewModel;
    }

    /**
     * @return layout resource id
     */
    @Override
    public int getLayoutId() {
        return R.layout.fragment_registration_password;
    }

    /**
     * Override for set view model
     *
     * @return view model instance
     */
    @Override
    public CreatePasswordViewModel getViewModel() {
        viewModel = ViewModelProviders.of(this).get(CreatePasswordViewModel.class);
        return viewModel;
    }

    public void moveToConfirmPasswordFragment() {
        memberRequest.setPassword(viewModel.password.get());
        getActivity().getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.registerContainer, ConfirmPasswordFragment.newInstance(memberRequest), ConfirmPasswordFragment.TAG).addToBackStack(ConfirmPasswordFragment.TAG)
                .commit();

    }

}
