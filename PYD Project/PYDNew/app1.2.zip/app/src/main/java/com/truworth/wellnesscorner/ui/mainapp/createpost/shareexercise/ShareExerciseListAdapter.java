package com.truworth.wellnesscorner.ui.mainapp.createpost.shareexercise;

import android.content.Context;
import android.databinding.DataBindingUtil;
import android.support.annotation.NonNull;
import android.support.v4.app.FragmentManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import com.truworth.wellnesscorner.R;
import com.truworth.wellnesscorner.databinding.RowLoadingProgressBinding;
import com.truworth.wellnesscorner.databinding.RowShareExerciseListBinding;
import com.truworth.wellnesscorner.databinding.RowShareMealHeaderBinding;
import com.truworth.wellnesscorner.model.ExerciseData;
import com.truworth.wellnesscorner.model.ShareExerciseBean;
import com.truworth.wellnesscorner.ui.mainapp.createpost.sharemeal.ShareMealDetailFragment;
import com.truworth.wellnesscorner.utils.DateUtils;

import java.util.List;

public class ShareExerciseListAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> implements ShareExerciseItemViewModel.ExerciseListener {
    private static final int VIEW_TYPE_ITEM = 1;
    private static final int VIEW_TYPE_PROGRESS = 2;
    private List<ShareExerciseBean> exerciseHeaderList;
    private Context context;
    private FragmentManager fragmentManager;
    private String date;

    public ShareExerciseListAdapter(Context context, List<ShareExerciseBean> exerciseHeaderList, FragmentManager fragmentManager) {
        this.context = context;
        this.exerciseHeaderList = exerciseHeaderList;
        this.fragmentManager = fragmentManager;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        RecyclerView.ViewHolder viewHolder = null;
        if (viewType == VIEW_TYPE_ITEM) {
            RowShareMealHeaderBinding headerBinding = DataBindingUtil.inflate(LayoutInflater.from(parent.getContext()), R.layout.row_share_meal_header, parent, false);
            viewHolder = new HeaderViewHolder(headerBinding);
        } else {
            RowLoadingProgressBinding rowLoadingProgressBinding = DataBindingUtil.inflate(LayoutInflater.from(parent.getContext()), R.layout.row_loading_progress, parent, false);
            viewHolder = new ViewHolderLoading(rowLoadingProgressBinding);
        }
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        if (holder.getItemViewType() == VIEW_TYPE_PROGRESS) {
            ViewHolderLoading viewHolderLoading = (ViewHolderLoading) holder;
            viewHolderLoading.rowLoadingProgressBinding.progressBar.setIndeterminate(true);
        } else {
            HeaderViewHolder viewHolderHeader = (HeaderViewHolder) holder;
            //viewHolderHeader.bind(headerList.get(position));

            viewHolderHeader.mHeaderBinding.tvDate.setText(DateUtils.formatDate(exerciseHeaderList.get(position).getDate(), "yyyy-MM-dd'T'HH:mm:ss", "MMMM dd, yyyy"));
            date = viewHolderHeader.mHeaderBinding.tvDate.getText().toString();
            viewHolderHeader.mHeaderBinding.foodContainer.removeAllViews();
            if (exerciseHeaderList.get(position).getExerciseData() != null) {
                List<ExerciseData> daysMealList = exerciseHeaderList.get(position).getExerciseData();

                for (int index = 0; index < daysMealList.size(); index++) {
                    RowShareExerciseListBinding listBinding = DataBindingUtil.inflate(LayoutInflater.from(context), R.layout.row_share_exercise_list, null, false);
                    ShareExerciseItemViewModel viewModel = new ShareExerciseItemViewModel(daysMealList.get(index), this);
                    listBinding.setViewModel(viewModel);
                    viewModel.getCalories();
                    viewHolderHeader.mHeaderBinding.foodContainer.addView(listBinding.getRoot());
                    listBinding.ivExerciseImage.setSelected(true);
                    viewHolderHeader.bind(daysMealList.get(index));
                }

            }
        }
    }

    @Override
    public int getItemViewType(int position) {
        if (exerciseHeaderList.get(position) == null) {
            return VIEW_TYPE_PROGRESS;
        } else {
            return VIEW_TYPE_ITEM;
        }
    }

    @Override
    public int getItemCount() {
        return exerciseHeaderList.size();
    }

    @Override
    public void onItemClick(ExerciseData exerciseData) {
        fragmentManager.beginTransaction()
                .replace(R.id.shareContainer, ShareExerciseFragment.newInstance(exerciseData,date), ShareMealDetailFragment.TAG).addToBackStack(ShareMealDetailFragment.TAG)
                .commit();
    }


    public class HeaderViewHolder extends RecyclerView.ViewHolder {
        private RowShareMealHeaderBinding mHeaderBinding;

        public HeaderViewHolder(RowShareMealHeaderBinding binding) {
            super(binding.getRoot());
            mHeaderBinding = binding;
        }

        public void bind(@NonNull ExerciseData exerciseData) {


            mHeaderBinding.executePendingBindings();
        }

    }

    public class ViewHolderLoading extends RecyclerView.ViewHolder {
        private RowLoadingProgressBinding rowLoadingProgressBinding;

        public ViewHolderLoading(RowLoadingProgressBinding binding) {
            super(binding.getRoot());
            rowLoadingProgressBinding = binding;
        }
    }
}
