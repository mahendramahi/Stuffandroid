package com.twc.store.model.response;

import com.google.gson.annotations.SerializedName;
import com.twc.store.model.beans.CouponItem;


/**
 * If this code works it was written by Somesh Kumar on 15 September, 2017. If not, I don't know who wrote it.
 */
public class ApplyCouponResponse {
    private int status;
    @SerializedName("Data")
    private CouponItem Coupon;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public CouponItem getCoupon() {
        return Coupon;
    }

    public void setCoupon(CouponItem Coupon) {
        this.Coupon = Coupon;
    }

}
