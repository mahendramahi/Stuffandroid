package com.twc.store.model.beans;

/**
 * Created by PalakC on 9/14/2017.
 */

public class DeleteCartItem {

    private double TotalAmount;
    private double TotalTaxAmount;
    private int TotalItems;

    public double getTotalAmount() {
        return TotalAmount;
    }

    public void setTotalAmount(double TotalAmount) {
        this.TotalAmount = TotalAmount;
    }

    public double getTotalTaxAmount() {
        return TotalTaxAmount;
    }

    public void setTotalTaxAmount(double TotalTaxAmount) {
        this.TotalTaxAmount = TotalTaxAmount;
    }

    public int getTotalItems() {
        return TotalItems;
    }

    public void setTotalItems(int TotalItems) {
        this.TotalItems = TotalItems;
    }

}
