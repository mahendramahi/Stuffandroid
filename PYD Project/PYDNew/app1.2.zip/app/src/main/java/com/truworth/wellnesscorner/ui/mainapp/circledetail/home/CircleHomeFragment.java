package com.truworth.wellnesscorner.ui.mainapp.circledetail.home;

import android.app.Activity;
import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.content.ContextCompat;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import com.truworth.wellnesscorner.BR;
import com.truworth.wellnesscorner.R;
import com.truworth.wellnesscorner.TheWellnessCornerApp;
import com.truworth.wellnesscorner.base.BaseFragment;
import com.truworth.wellnesscorner.data.SharedPreferenceHelper;
import com.truworth.wellnesscorner.databinding.FragmentCircleHomeBinding;
import com.truworth.wellnesscorner.interfaces.OnLoadMoreListener;
import com.truworth.wellnesscorner.model.Post;
import com.truworth.wellnesscorner.model.ShareSomethingBean;
import com.truworth.wellnesscorner.ui.mainapp.createpost.CreatePostActivity;
import com.truworth.wellnesscorner.ui.mainapp.post.IPostListItem;
import com.truworth.wellnesscorner.ui.mainapp.post.PostRecyclerAdapter;
import com.truworth.wellnesscorner.ui.mainapp.post.postcomment.PostCommentActivity;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import im.ene.toro.PlayerSelector;
import im.ene.toro.exoplayer.ToroExo;
import im.ene.toro.widget.Container;


public class CircleHomeFragment extends BaseFragment<FragmentCircleHomeBinding, CircleHomeViewModel> implements SwipeRefreshLayout.OnRefreshListener {
    FragmentCircleHomeBinding binding;
    private static final String CIRCLE_IDENTITY = "circleIdentity";
    final Handler handler = new Handler();  // post a delay due to the visibility change
    private final int visibleThreshold = 5;
    //  private static final String CIRCLE_NAME = "circleName";
    CircleHomeViewModel viewModel;
    List<IPostListItem> postList;
    PostRecyclerAdapter adapter;
    String circleIdentity = "";
    // CircleResponse response;
    Container recyclerView;
    LinearLayoutManager linearLayoutManager;
    boolean isLoadMore = false;
    boolean isUserVisibleHintCall = false;
    ShareSomethingBean shareBean;
    @Inject
    SharedPreferenceHelper preferenceHelper;
    PlayerSelector selector = PlayerSelector.DEFAULT; // visible to user by default.
    boolean _areDataLoaded = false;
    private int page = 1;
    private OnLoadMoreListener onLoadMoreListener;
    private int lastVisibleItem, totalItemCount;
    private String TAG = "CircleHomeFragment";
    private Handler handlerCircleHomeApi = new Handler();
    private Runnable runnable = new Runnable() {
        @Override
        public void run() {
            viewModel.setCircleIdentity(circleIdentity);
            page = 1;
            viewModel.getCirclePosts(page);
        }
    };

    public CircleHomeFragment() {
        // Required empty public constructor
    }

    public static CircleHomeFragment newInstance(String circleIdentity) {
        CircleHomeFragment fragment = new CircleHomeFragment();
        Bundle args = new Bundle();
        args.putString(CIRCLE_IDENTITY, circleIdentity);
        fragment.setArguments(args);
        return fragment;
    }

    public void updateData(List<Post> list, String circleName) {
        if (adapter != null) {
            adapter.setCircleName(circleName);
            if (postList.size() > 1) {
                this.postList.addAll(1, list);
            } else {
                this.postList.addAll(list);
            }
            adapter.notifyDataSetChanged();
        }
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        TheWellnessCornerApp.getApp().component().inject(this);
        if (getArguments() != null) {
            circleIdentity = getArguments().getString(CIRCLE_IDENTITY);
        }
          //response = new Gson().fromJson(Utils.loadJSONFromAsset(getActivity()), CircleResponse.class);
    }

    @Override
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        ToroExo.with(getActivity()).getDefaultCreator();
        binding = getViewDataBinding();
        recyclerView = getViewDataBinding().rvCircleHomePosts;
        postList = new ArrayList<>();

        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                if (dy < 0) {
                    getViewDataBinding().imgUpArrow.setVisibility(View.GONE);
                } else {
                    getViewDataBinding().imgUpArrow.setVisibility(View.VISIBLE);
                }
            }
        });

        setUpRecyclerView();
        setDataObserver();
        setUpArrowObserver();
        attachRemoveLoadingObserver();
        //  viewModel.getCirclePosts();
        getViewDataBinding().swipeRefreshLayout.setColorSchemeColors(ContextCompat.getColor(getContext(),R.color.text_grey));
        binding.swipeRefreshLayout.setOnRefreshListener(this);

    }

    private void setUpRecyclerView() {
        linearLayoutManager = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(linearLayoutManager);
        linearLayoutManager.setItemPrefetchEnabled(true);
        // postList.add(0, new Post());
        shareBean = new ShareSomethingBean();
        shareBean.setProfileImage(preferenceHelper.getUserImageUrl());
        shareBean.setUserName(preferenceHelper.getUserName());
        postList.add(shareBean);
        adapter = new PostRecyclerAdapter(getActivity(), postList, circleIdentity, "");
        recyclerView.setAdapter(adapter);
        recyclerView.setCacheManager(adapter);
        setOnLoadMoreListener(linearLayoutManager);


        // FIXME Only use the following workaround when using this Fragment in ViewPager.
        boolean viewPagerMode = true;
        if (viewPagerMode) {
            recyclerView.setPlayerSelector(null);
            // Using TabLayout has a downside: once we click to a tab to change page, there will be no animation,
            // which will cause our setup doesn't work well. We need a delay to make things work.
            handler.postDelayed(() -> {
                if (recyclerView != null) recyclerView.setPlayerSelector(selector);
            }, 200);
        } else {
            recyclerView.setPlayerSelector(selector);
        }
        getViewDataBinding().rvCircleHomePosts.smoothScrollToPosition(0);
    }

  /* @Override
    public void onDestroyView() {
        isUserVisibleHintCall = false;
        handler.removeCallbacksAndMessages(null);
        linearLayoutManager = null;
        adapter = null;

        selector = null;
        super.onDestroyView();
    }
*/
    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        isUserVisibleHintCall = true;
        if (isVisibleToUser && !_areDataLoaded) {
            isLoadMore = false;
            handlerCircleHomeApi.postDelayed(runnable, 50);
            _areDataLoaded = true;
        } else {
            isUserVisibleHintCall = false;
        }
        if (isVisibleToUser) {
            selector = PlayerSelector.DEFAULT;
        } else {
            selector = PlayerSelector.NONE;
        }

        // Using TabLayout has a downside: once we click to a tab to change page, there will be no animation,
        // which will cause our setup doesn't work well. We need a delay to make things work.
        handler.postDelayed(() -> {
            if (recyclerView != null) recyclerView.setPlayerSelector(selector);
        }, 500);

    }

    @Override
    public void onResume() {
        super.onResume();
//        if (!isUserVisibleHintCall) {
//            isLoadMore = false;
//
//            handler.postDelayed(runnable, 50);
//            _areDataLoaded = true;
//        }


    }


    private void setDataObserver() {
        viewModel.getPostsList().observe(this, new Observer<List<Post>>() {
            @Override
            public void onChanged(@Nullable List<Post> posts) {
                if (!isLoadMore) {
//                    postList.clear();
//                    //adapter.notifyDataSetChanged();
//                    //  postList.add(0, shareBean);
//                    postList.subList(1, postList.size()).clear();
//                    // postList.clear();
//                    // adapter.notifyDataSetChanged();
//                    postList.addAll(1, posts);
//                    //  adapter.setItems(postList);
//                    // adapter.notifyItemRangeChanged(1, postList.size());
//                    // postList.addAll( posts);
//                    adapter.notifyDataSetChanged();
//                    recyclerView.setAdapter(adapter);
                    postList.clear();
                    postList.add(shareBean);
                    postList.addAll(posts);
                    adapter.setItems(postList);
                    // adapter.notifyDataSetChanged();
                } else {
                    postList.addAll(posts);
                    adapter.notifyDataSetChanged();
                    isLoadMore = false;
                }

            }
        });
    }

    private void setOnLoadMoreListener(final LinearLayoutManager linearLayoutManager) {
        onLoadMoreListener = new OnLoadMoreListener() {
            @Override
            public void onLoadMore() {
                if (!viewModel.isLastResult) {
                    if (postList != null && postList.size() > 5) {
                        postList.add(null);
                        adapter.notifyItemInserted(postList.size() - 1);
                        recyclerView.getLayoutManager().scrollToPosition(postList.size());
                        page = page + 1;
                        isLoadMore = true;
                        viewModel.getCirclePosts(page);
                    }
                }
            }
        };


        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                totalItemCount = linearLayoutManager.getItemCount();
                lastVisibleItem = linearLayoutManager.findLastVisibleItemPosition();
                if (!viewModel.loading && totalItemCount <= (lastVisibleItem + visibleThreshold)) {

                    onLoadMoreListener.onLoadMore();
                    viewModel.loading = true;
                }


            }
        });

    }

    private void attachRemoveLoadingObserver() {
        viewModel.getRemoveLoading().observe(this, new Observer<Void>() {
            @Override
            public void onChanged(@Nullable Void aVoid) {
                //Success, update UI
                if (postList.size() > 0 && postList.get(postList.size() - 1) == null) {
                    postList.remove(postList.size() - 1);
                    adapter.notifyDataSetChanged();
                }

            }
        });
    }

    /**
     * Override for set binding variable
     *
     * @return variable id
     */
    @Override
    public int getBindingVariable() {
        return BR.viewModel;
    }

    /**
     * @return layout resource id
     */
    @Override
    public int getLayoutId() {
        return R.layout.fragment_circle_home;
    }

    /**
     * Override for set view model
     *
     * @return view model instance
     */
    @Override
    public CircleHomeViewModel getViewModel() {
        viewModel = ViewModelProviders.of(this).get(CircleHomeViewModel.class);
        return viewModel;
    }


    @Override
    public void onDetach() {
        super.onDetach();

    }

    @Override
    public void onStop() {
        super.onStop();
        //isUserVisibleHintCall = false;
       // _areDataLoaded = false;
        if (handlerCircleHomeApi != null) {
            handlerCircleHomeApi.removeCallbacks(runnable);
        }
    }

    private void setUpArrowObserver() {
        viewModel.getUpArrow().observe(this, new Observer<Void>() {
            @Override
            public void onChanged(@Nullable Void avoid) {
                getViewDataBinding().rvCircleHomePosts.smoothScrollToPosition(0);
                new Handler().postDelayed(() -> getViewDataBinding().imgUpArrow.setVisibility(View.GONE), 500);

            }
        });
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        // super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PostCommentActivity.REQUEST_CODE) {
            int position = data.getIntExtra(PostCommentActivity.INDEX, 0);
            Post post = (Post) data.getSerializableExtra(PostCommentActivity.POST);
            postList.remove(position);
            postList.add(position, post);
            adapter.notifyItemChanged(position);
        } else if (requestCode == CreatePostActivity.REQUEST_CODE && resultCode == Activity.RESULT_OK) {
            viewModel.getCirclePosts(1);
        }
    }

    @Override
    public void onRefresh() {
        viewModel.isSwipeRefresh.set(true);
        handlerCircleHomeApi.postDelayed(runnable, 0);
    }
}
