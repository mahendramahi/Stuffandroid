package com.twc.store.adapter;

import android.app.Activity;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;


import com.twc.store.R;
import com.twc.store.R2;
import com.twc.store.fragments.StoreConfirmOrderFragment;
import com.twc.store.model.beans.CartListItem;
import com.twc.store.utils.Utils;
import com.twc.store.views.CustomTextView;

import java.util.ArrayList;
import java.util.Locale;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * Created by PalakC on 7/10/2017.
 */

public class ConfirmOrderCartAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private ArrayList<CartListItem> cartListItems;
    private Activity mActivity;


    public ConfirmOrderCartAdapter(Activity mActivity, ArrayList<CartListItem> cartListItems, StoreConfirmOrderFragment fragment) {
        this.cartListItems = cartListItems;
        this.mActivity = mActivity;

    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_mycart_store, parent, false);
        return new ItemViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, final int position) {
        final ItemViewHolder itemViewHolder = (ItemViewHolder) holder;

        itemViewHolder.tvProductTitle.setText(cartListItems.get(position).getSCart_ProductName());

        Glide.with(mActivity).load(cartListItems.get(position).getSCart_ProductImage()).apply(new RequestOptions().dontAnimate().dontTransform().placeholder(R.drawable.wellness_no_logo).error(R.drawable.wellness_no_logo)).into(itemViewHolder.ivProductImage);
        final int quantity = cartListItems.get(position).getSCart_Quantity();
        itemViewHolder.tvProductCount.setText(String.format(Locale.getDefault(), "%d", quantity));
        itemViewHolder.tvPrice.setText(mActivity.getString(R.string.rupee_symbol) + " " + Utils.getFormattedAmountManageZero(cartListItems.get(position).getSCart_TotalAmount() * quantity));
        itemViewHolder.rlBottom.setVisibility(View.GONE);

    }

    @Override
    public int getItemCount() {
        return (null != cartListItems ? cartListItems.size() : 0);
    }

    public class ItemViewHolder extends RecyclerView.ViewHolder {
        @BindView(R2.id.ivProductImage)
        ImageView ivProductImage;
        @BindView(R2.id.tvProductTitle)
        CustomTextView tvProductTitle;
        @BindView(R2.id.tvPrice)
        CustomTextView tvPrice;
        @BindView(R2.id.ivMins)
        ImageView ivMins;
        @BindView(R2.id.tvProductCount)
        CustomTextView tvProductCount;
        @BindView(R2.id.ivPlus)
        ImageView ivPlus;
        @BindView(R2.id.tvRemove)
        CustomTextView tvRemove;

        @BindView(R2.id.rlBottom)
        RelativeLayout rlBottom;

        public ItemViewHolder(View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }
    }

}

