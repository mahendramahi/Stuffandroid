package com.truworth.wellnesscorner.model;

import android.databinding.Observable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class EventBean  {
    @SerializedName("eventIdentity")
    @Expose
    private String eventIdentity;
    @SerializedName("eventName")
    @Expose
    private String eventName;
    @SerializedName("eventDesc")
    @Expose
    private String eventDesc;
    @SerializedName("eventStartDate")
    @Expose
    private String eventStartDate;
    @SerializedName("eventEndDate")
    @Expose
    private String eventEndDate;
    @SerializedName("eventLocation")
    @Expose
    private String eventLocation;
    @SerializedName("totalMembersGoing")
    @Expose
    private int totalMembersGoing;
    @SerializedName("myStatus")
    @Expose
    private String myStatus;
    @SerializedName("memberImages")
    @Expose
    private List<MemberImages> memberImages = null;

    public String getEventIdentity() {
        return eventIdentity;
    }

    public void setEventIdentity(String eventIdentity) {
        this.eventIdentity = eventIdentity;
    }

    public String getEventName() {
        return eventName;
    }

    public void setEventName(String eventName) {
        this.eventName = eventName;
    }

    public String getEventDesc() {
        return eventDesc;
    }

    public void setEventDesc(String eventDesc) {
        this.eventDesc = eventDesc;
    }

    public String getEventStartDate() {
        return eventStartDate;
    }

    public void setEventStartDate(String eventStartDate) {
        this.eventStartDate = eventStartDate;
    }

    public String getEventEndDate() {
        return eventEndDate;
    }

    public void setEventEndDate(String eventEndDate) {
        this.eventEndDate = eventEndDate;
    }

    public String getEventLocation() {
        return eventLocation;
    }

    public void setEventLocation(String eventLocation) {
        this.eventLocation = eventLocation;
    }

    public int getTotalMembersGoing() {
        return totalMembersGoing;
    }

    public void setTotalMembersGoing(int totalMembersGoing) {
        this.totalMembersGoing = totalMembersGoing;
    }

    public String getMyStatus() {
        return myStatus;
    }

    public void setMyStatus(String myStatus) {
        this.myStatus = myStatus;
    }

    public List<MemberImages> getMemberImages() {
        return memberImages;
    }

    public void setMemberImages(List<MemberImages> memberImages) {
        this.memberImages = memberImages;
    }
}
