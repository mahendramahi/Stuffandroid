package com.twc.dailylog.rest;



import com.twc.dailylog.model.requestbody.SaveWaterTrackerBody;
import com.twc.dailylog.model.requestbody.WaterTrackerDataRequest;
import com.twc.dailylog.model.response.SaveWaterTrackerResponse;
import com.twc.dailylog.model.response.WaterTrackerDataResponse;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

/**
 * Created by PalakC on 7/6/2016.
 */
public interface TrackersService {


    @POST("member/Tracker/SaveWaterTrackerData")
    Call<SaveWaterTrackerResponse> getSaveWaterTrackerData(@Body SaveWaterTrackerBody saveWaterTrackerBody);


    @POST("member/Tracker/GetWaterTrackerData")
    Call<WaterTrackerDataResponse> getWaterTrackerData(@Body WaterTrackerDataRequest waterTrackerDataRequest);


}
