package com.truworth.wellnesscorner.ui.mainapp.circledetail.challenges;

import android.databinding.ObservableBoolean;

import com.truworth.wellnesscorner.base.BaseViewModel;
import com.truworth.wellnesscorner.model.OnGoingChallengesBean;
import com.truworth.wellnesscorner.utils.DateUtils;
import com.truworth.wellnesscorner.utils.Utils;

import java.text.SimpleDateFormat;
import java.util.Date;

public class OngoingChallengeItemViewModel extends BaseViewModel {
    public MyChallengeListener myChallengeListener;
    OnGoingChallengesBean onGoingChallenge;
    private String postMapId;
    public ObservableBoolean isPrevDate = new ObservableBoolean();

    public OngoingChallengeItemViewModel(OnGoingChallengesBean onGoingChallenge, MyChallengeListener myChallengeListener, String postMapId) {
        this.onGoingChallenge = onGoingChallenge;
        this.myChallengeListener = myChallengeListener;
        this.postMapId = postMapId;
    }

    public OnGoingChallengesBean getOnGoingChallenge() {
        return onGoingChallenge;
    }

    public void setOnGoingChallenge(OnGoingChallengesBean onGoingChallenge) {
        this.onGoingChallenge = onGoingChallenge;
    }

    public String getDateinFormat(String date) {
        String newDateString = "";
        if (date != null)
            newDateString = DateUtils.formatDate(date, "yyyy-MM-dd'T'HH:mm:ss", "MMMM dd,yyyy");
        return newDateString;
    }



    public void onItemClick(boolean isOpenForCheckIn) {
        myChallengeListener.onItemClick(onGoingChallenge, postMapId,isOpenForCheckIn);
    }

    public int getProgress() {
        int progressValue;
        int daysLeft = Integer.parseInt(DateUtils.getDayDifference(onGoingChallenge.getChallengeEndDate()));
        int daysDifference = Integer.parseInt(DateUtils.getOnlyDaysDifference(onGoingChallenge.getChallengeStartDate(), onGoingChallenge.getChallengeEndDate(), "yyyy-MM-dd'T'HH:mm:ss"));
        progressValue = (int) Utils.getPercentage(daysDifference-daysLeft, daysDifference);
        return progressValue;
    }

    public interface MyChallengeListener {

        void onItemClick(OnGoingChallengesBean onGoingChallenge, String postMapId,boolean isOpenForCheckIn);
    }

    public String setStartEndDate(String startDate, String endDate){
        String dateString ="";
        if(startDate != null && endDate !=null){
            String daysDiff = DateUtils.getDayDifference(endDate);
            if((Integer.parseInt(daysDiff))<0) {
                dateString = getDateinFormat(startDate) + " - " + getDateinFormat(endDate);
                isPrevDate.set(true);
            }
            else {
                isPrevDate.set(false);
                dateString = getDateinFormat(startDate) + " - " + getDateinFormat(endDate) + "(" + daysDiff + " days left)";
            }
        }
        return dateString;
    }
}
