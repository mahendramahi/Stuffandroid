package com.twc.remindermodule.adapter;

import android.app.Activity;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;

import com.twc.remindermodule.R;
import com.twc.remindermodule.fragments.RecommendedHealthyHabitsFragment;
import com.twc.remindermodule.model.beans.HealthyHabitBean;
import com.twc.remindermodule.views.CustomTextView;

import java.util.List;


public class RecommendedHealthyHabitsAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {


    private Activity mActivity;
    private List<HealthyHabitBean> mHabitList;
    private RecommendedHealthyHabitsFragment mFragment;

    public RecommendedHealthyHabitsAdapter(Activity activity, List<HealthyHabitBean> HabitList, RecommendedHealthyHabitsFragment fragment) {
        this.mActivity = activity;
        this.mHabitList = HabitList;
        this.mFragment = fragment;
    }


    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.row_select_healthy_habits, parent, false);
        return new ItemViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, final int position) {
        final ItemViewHolder itemViewHolder = (ItemViewHolder) holder;

        itemViewHolder.tvTaskName.setText(mHabitList.get(position).getTitle());
        itemViewHolder.cbHabits.setChecked(mHabitList.get(position).isIsSelected());

        itemViewHolder.cbHabits.setTag(position);
        if (itemViewHolder.cbHabits.isChecked()) {
            itemViewHolder.view.setBackgroundColor(ContextCompat.getColor(mActivity, R.color.color_2bc4bd));
        } else {
            itemViewHolder.view.setBackgroundColor(ContextCompat.getColor(mActivity, R.color.color_b2b9bf));
        }


    }

    @Override
    public int getItemCount() {
        return mHabitList.size();
    }

    // ItemViewHolder Class for Items in each Section
    public class ItemViewHolder extends RecyclerView.ViewHolder {
        private final CheckBox cbHabits;
        private final View view;
        private CustomTextView tvTaskName;

        public ItemViewHolder(View itemView) {
            super(itemView);
            cbHabits = itemView.findViewById(R.id.cbHabits);
            view = itemView.findViewById(R.id.view);
            tvTaskName = itemView.findViewById(R.id.tvTaskName);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view1) {
                    CheckBox cb = view1.findViewById(R.id.cbHabits);
                    int clickedPos = (Integer) cb.getTag();
                    HealthyHabitBean item = mHabitList.get(clickedPos);

                    cb.setChecked(!cb.isChecked());
                    item.setIsSelected(cb.isChecked());
                    mHabitList.get(clickedPos).setIsSelected(cb.isChecked());

                    if (cb.isChecked()) {
                        mFragment.enableNextButton();
                        view.setBackgroundColor(ContextCompat.getColor(mActivity, R.color.color_2bc4bd));
                    } else {
                        view.setBackgroundColor(ContextCompat.getColor(mActivity, R.color.color_b2b9bf));
                    }


                }
            });

        }
    }


}
