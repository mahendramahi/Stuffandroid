package com.truworth.wellnesscorner.ui.mainapp.createpost;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.ImageView;

import com.truworth.wellnesscorner.R;
import com.truworth.wellnesscorner.customviews.CustomTextView;
import com.truworth.wellnesscorner.ui.mainapp.createpost.sharebeforeafter.ShareBeforeAfterFragment;
import com.truworth.wellnesscorner.ui.mainapp.createpost.sharedashboard.ShareDashboardFragment;
import com.truworth.wellnesscorner.ui.mainapp.createpost.shareexercise.ShareExerciseListFragment;
import com.truworth.wellnesscorner.ui.mainapp.createpost.sharemeal.ShareMealFragment;
import com.truworth.wellnesscorner.ui.mainapp.createpost.sharesteps.ShareStepFragment;
import com.truworth.wellnesscorner.ui.mainapp.createpost.shareweight.ShareWeightFragment;
import com.truworth.wellnesscorner.utils.AppConstants;

public class ShareActivity extends AppCompatActivity implements View.OnClickListener {
    public static final String TAG_OPEN_FOR = "openfor";

    Toolbar toolbar;
    CustomTextView tvToolbatTitle;
    ImageView ivClose;

    public static void start(Activity activity, int openFor) {
        Intent intent = new Intent(activity, ShareActivity.class);
        intent.putExtra(TAG_OPEN_FOR, openFor);
        //activity.startActivity(intent);
        activity.startActivityForResult(intent, AppConstants.SHARE_DATA_REQUEST);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_share);
        toolbar = findViewById(R.id.toolbar);
        tvToolbatTitle = findViewById(R.id.tvToolbatTitle);
        ivClose = findViewById(R.id.ivClose);
        setupToolbar(toolbar);
        int openFor = getIntent().getIntExtra(TAG_OPEN_FOR, 0);
        addProfileFragment(openFor);

        ivClose.setOnClickListener(this);
    }

    private void setupToolbar(Toolbar toolbar) {
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(false);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
            getSupportActionBar().setDisplayShowTitleEnabled(false);
        }
    }
    public void setToolBarTitle(String toolBarTitle) {
        tvToolbatTitle.setText(toolBarTitle);
        assert getSupportActionBar() != null;
        getSupportActionBar().show();
    }


    private void addProfileFragment(int openFor) {
        Fragment fragment = getFragment(openFor);
        getSupportFragmentManager()
                .beginTransaction()
                .add(R.id.shareContainer, fragment, String.valueOf(openFor))
                .commit();
    }


    private Fragment getFragment(int openFor) {

        switch (openFor) {
            case AppConstants.TAG_OPEN_FOR_DASHBOARD:
                setToolBarTitle("Share Dashboard");
                return ShareDashboardFragment.newInstance();
            case AppConstants.TAG_OPEN_FOR_MEAL:
                setToolBarTitle("Share Meal");
                return ShareMealFragment.newInstance();
            case AppConstants.TAG_OPEN_FOR_STEPS:
                setToolBarTitle("Share Steps");
                return ShareStepFragment.newInstance();

            case AppConstants.TAG_OPEN_FOR_WEIGHT:
                setToolBarTitle("Share Weight");
                return new ShareWeightFragment();
            case AppConstants.TAG_OPEN_FOR_EXERICES:
                setToolBarTitle("Share Exercise");
                return ShareExerciseListFragment.newInstance();
            case AppConstants.TAG_OPEN_FOR_BEFORE_AFTER:
                setToolBarTitle("Before & After");
                return ShareBeforeAfterFragment.newInstance();

        }
        return null;
    }

    @Override
    public void onClick(View view) {
        super.onBackPressed();
    }
}
