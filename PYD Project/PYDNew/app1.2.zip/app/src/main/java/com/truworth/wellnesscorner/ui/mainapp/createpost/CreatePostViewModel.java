package com.truworth.wellnesscorner.ui.mainapp.createpost;

import android.databinding.ObservableBoolean;
import android.databinding.ObservableField;
import android.graphics.Bitmap;
import android.text.Editable;
import android.text.InputFilter;
import android.text.Spanned;
import android.text.TextWatcher;
import android.util.Patterns;
import android.view.View;

import com.leocardz.link.preview.library.LinkPreviewCallback;
import com.leocardz.link.preview.library.SourceContent;
import com.leocardz.link.preview.library.TextCrawler;
import com.truworth.wellnesscorner.TheWellnessCornerApp;
import com.truworth.wellnesscorner.base.BaseViewModel;
import com.truworth.wellnesscorner.data.SharedPreferenceHelper;
import com.truworth.wellnesscorner.model.OnGoingChallengesBean;
import com.truworth.wellnesscorner.model.PostMediaData;
import com.truworth.wellnesscorner.model.TagPerson;
import com.truworth.wellnesscorner.repo.CreatePostRepository;
import com.truworth.wellnesscorner.repo.model.request.CreatePostRequest;
import com.truworth.wellnesscorner.repo.model.request.PostContentDataRequest;
import com.truworth.wellnesscorner.repo.model.request.PostMediaTypeDataRequest;
import com.truworth.wellnesscorner.repo.model.request.PostTagTypeDataRequest;
import com.truworth.wellnesscorner.repo.model.response.CreatePostResponse;
import com.truworth.wellnesscorner.utils.AppConstants;
import com.truworth.wellnesscorner.utils.CommonUtils;
import com.truworth.wellnesscorner.utils.SingleLiveEvent;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.inject.Inject;

import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;

public class CreatePostViewModel extends BaseViewModel {

    public final SingleLiveEvent<Void> callDialogChooser = new SingleLiveEvent<>();
    public final SingleLiveEvent<Void> onSavePost = new SingleLiveEvent<>();
    public final SingleLiveEvent<Void> checkTagList = new SingleLiveEvent<>();
    public final SingleLiveEvent<Void> checkMediaList = new SingleLiveEvent<>();
    public ObservableBoolean isProgress = new ObservableBoolean();
    public ObservableBoolean isPostUrl = new ObservableBoolean();
    public ObservableBoolean isMenuShow = new ObservableBoolean();
    public ObservableBoolean isImageView = new ObservableBoolean();
    public ObservableBoolean isVideoView = new ObservableBoolean();
    public ObservableField<String> coachName = new ObservableField<>();
    public ObservableField<String> userImage = new ObservableField<>();
    public ObservableField<String> userName = new ObservableField<>();
    public ObservableField<String> errorMessage = new ObservableField<>();
    public ObservableField<String> postDesc = new ObservableField<>();
    public ObservableField<String> etPostHint = new ObservableField<>();
    public ObservableField<String> urlTitle = new ObservableField<>();
    public ObservableField<String> url = new ObservableField<>();
    public ObservableField<String> description = new ObservableField<>();
    public ObservableField<String> currentImageSet = new ObservableField<>();
    public SingleLiveEvent<Integer> navigateOnShare = new SingleLiveEvent<>();
    public SingleLiveEvent<List<OnGoingChallengesBean>> ongoingChallenges = new SingleLiveEvent<>();
    public ObservableBoolean isEnableSave = new ObservableBoolean();
    public ObservableBoolean isCheckInValue = new ObservableBoolean();
    public SingleLiveEvent<PostMediaData> urlPreviewData = new SingleLiveEvent<>();

    @Inject
    SharedPreferenceHelper prefHelper;
    @Inject
    CreatePostRepository postRepository;
    OnGoingChallengesBean onGoingChallengesBean;
    String extractedUrl = "", prevUrl = "";
    private boolean isHastag, isHasMedia;
    private List<OnGoingChallengesBean> challengesBeans = new ArrayList<>();
    private List<PostMediaTypeDataRequest> mediaRequests = new ArrayList<>();
    private List<PostTagTypeDataRequest> tagRequests = new ArrayList<>();
    private String circleIdentity;
    private boolean isMediaType;
    private TextCrawler textCrawler = new TextCrawler();
    //   private Bitmap[] currentImageSet;
    private LinkPreviewCallback callback = new LinkPreviewCallback() {
        @Override
        public void onPre() {
            isEnableSave.set(false);
           // isProgress.set(true);

        }

        @Override
        public void onPos(SourceContent sourceContent, boolean isNull) {
            isEnableSave.set(true);
            isProgress.set(false);
            if (isNull || sourceContent.getFinalUrl().equals("")) {
                isHasMedia = false;
                isPostUrl.set(false);
                currentImageSet.set("");
                urlTitle.set("");
                url.set("");
                description.set("");
            } else {
                isPostUrl.set(true);
                if (sourceContent.getImages() != null && sourceContent.getImages().size() > 0)
                    currentImageSet.set(sourceContent.getImages().get(0));
                //  currentImageSet.set(new Bitmap[sourceContent.getImages().size()]);
                urlTitle.set(sourceContent.getTitle());
                url.set(sourceContent.getCannonicalUrl());
                description.set(sourceContent.getDescription());

                PostMediaData mediaData = new PostMediaData();
                mediaData.setDesc(description.get());
                mediaData.setTitle(urlTitle.get());
                mediaData.setUrl(url.get());
                mediaData.setFileName(currentImageSet.get());
                urlPreviewData.setValue(mediaData);


            }

        }
    };

    public CreatePostViewModel() {
        TheWellnessCornerApp.getApp().component().inject(this);
        userName.set(prefHelper.getUserName());
        userImage.set(prefHelper.getPrefKeyImageUrl());
        isMenuShow.set(true);
        isImageView.set(false);
        isEnableSave.set(true);
    }

    public SingleLiveEvent<PostMediaData> getUrlPreviewData() {
        return urlPreviewData;
    }

    public boolean isUrlMatch(String post) {
        Pattern urlPattern = Pattern.compile(
                "\\(?\\b(http|ftp|https)[-A-Za-z0-9+&amp;@#/%?=~_()|!:,.;]*[-A-Za-z0-9+&amp;@#/%=~_()|]", Pattern.CASE_INSENSITIVE);
        Matcher urlMatcher = urlPattern.matcher(post);
        if(Patterns.WEB_URL.matcher(post).matches())
        {
            isProgress.set(true);
        }
        while (urlMatcher.find()) {
            extractedUrl = post.substring(urlMatcher.start(0),
                    urlMatcher.end(0));
            return true;
        }
        return false;
    }

    public SingleLiveEvent<Integer> getNavigateOnShare() {
        return navigateOnShare;
    }

    public SingleLiveEvent<Void> getCheckTagList() {
        return checkTagList;
    }

    public SingleLiveEvent<Void> getCheckMediaList() {
        return checkMediaList;
    }

    public SingleLiveEvent<List<OnGoingChallengesBean>> getOngoingChallenges() {
        return ongoingChallenges;
    }

    public SingleLiveEvent<Void> getcallDialogChooser() {
        return callDialogChooser;
    }

    public SingleLiveEvent<Void> getOnSavePost() {
        return onSavePost;
    }

    public void openChooserDialog() {
        callDialogChooser.call();
    }

    public void setClose() {
        isMenuShow.set(true);
        isImageView.set(false);
        isVideoView.set(false);
        isPostUrl.set(false);
    }

    public void setVisiblityImage() {
        isMenuShow.set(false);
        isImageView.set(true);
        isVideoView.set(false);
    }

    public void setVisiblityVideoView() {
        isMenuShow.set(false);
        isImageView.set(false);
        isVideoView.set(true);
    }

    public void setIntentValue(String coachName, String circleIdentity, boolean isCheckIn, OnGoingChallengesBean onGoingChallengesBean) {
        this.coachName.set(coachName);
        this.circleIdentity = circleIdentity;
        isCheckInValue.set(isCheckIn);
        if (!isCheckIn) {
            etPostHint.set("Share something with your circle");
        } else {
            etPostHint.set("Write something about how you felt while completing this challenge today");
            setCheckInView(onGoingChallengesBean);
        }
    }

    public void CheckType() {
        checkMediaList.call();
        if (isMediaType) {
            setIsLoading(true);
            isEnableSave.set(false);
        } else {
            saveApiCall();
        }
    }

    public void saveApiCall() {
        isEnableSave.set(true);
        checkTagList.call();  //check post as a tag
        //check post as a url
        if (urlPreviewData.getValue() != null) {
            checkPostUrl(AppConstants.MEDIA_TYPE_URL);
        }
        CreatePostRequest postRequest = new CreatePostRequest();
        //Postmapidentity
        postRequest.setId(circleIdentity);
        postRequest.setPostFor(2);// set 2 for circle
        postRequest.setPostText(postDesc.get());
        if (onGoingChallengesBean != null) {
            postRequest.setContentTypeId(3);// for the challenge check in type
            PostContentDataRequest dataRequest = new PostContentDataRequest();
            dataRequest.setChallengeIdentity(onGoingChallengesBean.getChallengeIdentity());
            postRequest.setContentData(dataRequest);
        }
        postRequest.setIsHasTags(isHastag);
        postRequest.setIsHasMedia(isHasMedia);
        postRequest.setTagTypeValue(tagRequests);
        postRequest.setMediaTypeValue(mediaRequests);

        postRepository.savePost(postRequest).subscribe(new Observer<CreatePostResponse>() {
            @Override
            public void onSubscribe(Disposable d) {

            }

            @Override
            public void onNext(CreatePostResponse createPostResponse) {
                if (!createPostResponse.isHasError()) {
                    setIsLoading(false);
                    onSavePost.call();
                } else {
                    errorMessage.set(createPostResponse.getError().getMessage());
                }
            }

            @Override
            public void onError(Throwable e) {

            }

            @Override
            public void onComplete() {

            }
        });
    }

    private void checkPostUrl(int mediaType) {
        isHasMedia = true;
        PostMediaTypeDataRequest mRequest = new PostMediaTypeDataRequest();
        if (mediaType == AppConstants.MEDIA_TYPE_URL) {
            mRequest.setTitle(urlTitle.get());
            mRequest.setDesc(description.get());
            mRequest.setFileName(currentImageSet.get());
            mRequest.setData(url.get());
        }
        mRequest.setMediaType(mediaType);
        mediaRequests.add(mRequest);

    }

    public void navigateToShare(int value) {
        navigateOnShare.setValue(value);
    }

    public void setCheckInView(OnGoingChallengesBean onGoingChallengesBean) {
        this.onGoingChallengesBean = onGoingChallengesBean;
        challengesBeans.add((onGoingChallengesBean));
        ongoingChallenges.setValue(challengesBeans);
    }

    public void setTags(List<Object> objects) {
        PostTagTypeDataRequest mRequest = new PostTagTypeDataRequest();
        for (int i = 0; i <= objects.size(); i++) {
            mRequest.setTagIndex(i);
            mRequest.setTagName(((TagPerson) objects).getPostTagName());
            mRequest.setTagMapIdentity(((TagPerson) objects).getPostTagMapIdentity());
            mRequest.setTagTypeId(Integer.parseInt(((TagPerson) objects).getPostTagTypeName()));
            tagRequests.add(mRequest);
        }
        isHastag = true;
    }

    public void setMediaData(String todayDate, String ext, int mediaType, int width, int height) {
        if (!(todayDate.isEmpty() && ext.isEmpty())) {
            isHasMedia = true;
            PostMediaTypeDataRequest mRequest = new PostMediaTypeDataRequest();
            if (mediaType == AppConstants.MEDIA_TYPE_IMAGE) {
                mRequest.setTitle("");
                mRequest.setDesc("");
                mRequest.setHeight(height);
                mRequest.setWidth(width);
                mRequest.setData(todayDate + "." + ext);
            } else if (mediaType == AppConstants.MEDIA_TYPE_VIDEO) {
                mRequest.setTitle("");
                mRequest.setDesc("");
                mRequest.setData(todayDate + "." + "m3u8");
            }
            mRequest.setMediaType(mediaType);
            mediaRequests.add(mRequest);
            saveApiCall();

        } else {
            setIsLoading(false);
            isEnableSave.set(true);
        }
    }

    public void setMediaType(boolean isMediaType) {
        this.isMediaType = isMediaType;
    }

    public TextWatcher postWatcher() {

        return new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if (charSequence.length() > 0) {
                    if (!postDesc.get().trim().isEmpty()) {
                        if (!isUrlMatch(charSequence.toString()))
                            isPostUrl.set(false);
                        isUrlMatch(charSequence.toString());
                        if (!extractedUrl.equalsIgnoreCase(prevUrl)) {
                            prevUrl = extractedUrl;
                            textCrawler.makePreview(callback, postDesc.get());
                        }
                    } else {
                        isProgress.set(false);
                        extractedUrl = "";
                        isPostUrl.set(false);
                    }
                } else {

                    isProgress.set(false);
                    extractedUrl = "";
                    isPostUrl.set(false);
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        };
    }

    // click on close button on post preview
    public void releasePreviewArea() {
        isProgress.set(false);
        isPostUrl.set(false);
        extractedUrl = "";
        urlPreviewData.setValue(null);
    }
}
