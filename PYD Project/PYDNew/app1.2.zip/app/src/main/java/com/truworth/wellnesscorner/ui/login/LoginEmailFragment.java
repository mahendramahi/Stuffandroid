package com.truworth.wellnesscorner.ui.login;

import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.text.InputFilter;
import android.text.Spanned;
import android.view.View;

import com.truworth.wellnesscorner.BR;
import com.truworth.wellnesscorner.R;
import com.truworth.wellnesscorner.TheWellnessCornerApp;
import com.truworth.wellnesscorner.base.BaseFragment;
import com.truworth.wellnesscorner.data.SharedPreferenceHelper;
import com.truworth.wellnesscorner.databinding.FragmentFirstLoginEmailBinding;
import com.truworth.wellnesscorner.ui.registration.RegistrationActivity;
import com.truworth.wellnesscorner.utils.KeyBoardUtils;

import javax.inject.Inject;

public class LoginEmailFragment extends BaseFragment<FragmentFirstLoginEmailBinding, LoginEmailViewModel> {

    public static final String TAG = "FirstLoginEmailFragment";
    LoginEmailViewModel viewModel;
    FragmentFirstLoginEmailBinding binding;
    @Inject
    SharedPreferenceHelper preferenceHelper;

    public LoginEmailFragment() {
        // Required empty public constructor
    }


    // TODO: Rename and change types and number of parameters
    public static LoginEmailFragment newInstance() {
        LoginEmailFragment fragment = new LoginEmailFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        TheWellnessCornerApp.getApp().component().inject(this);
        setKeyboardHideOnTapOutSide(false);
    }

    @Override
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        binding = getViewDataBinding();
        binding.etUserName.requestFocus();
        binding.etUserName.setFilters(new InputFilter[]{filter});
        attachObservers();
         }
    InputFilter filter = new InputFilter() {
        @Override
        public CharSequence filter(CharSequence source, int start, int end, Spanned dest, int dstart, int dend) {
            for (int i = start; i < end; i++) {
                int type = Character.getType(source.charAt(i));
                if (type == Character.SURROGATE || type == Character.OTHER_SYMBOL) {
                    return "";
                }
            }
            return null;
        }
    };
    private void attachObservers() {
        viewModel.getEmailChecked().observe(this, new Observer<String>() {

            @Override
            public void onChanged(@Nullable String s) {
                showPasswordFragment(s);
            }
        });

       viewModel.getMoveToRegistration().observe(this, new Observer<String>() {
            @Override
            public void onChanged(@Nullable String s) {
                moveToRegistration();
            }
        });
         viewModel.getClearData().observe(this, new Observer<Void>() {
            @Override
            public void onChanged(@Nullable Void aVoid) {
                binding.etUserName.setText("");
            }
        });
    }



    /**
     * Override for set binding variable
     *
     * @return variable id
     */
    @Override
    public int getBindingVariable() {
        return BR.viewModel;
    }

    /**
     * @return layout resource id
     */
    @Override
    public int getLayoutId() {
        return R.layout.fragment_first_login_email;
    }

    /**
     * Override for set view model
     *
     * @return view model instance
     */
    @Override
    public LoginEmailViewModel getViewModel() {
        viewModel = ViewModelProviders.of(this).get(LoginEmailViewModel.class);
        return viewModel;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

    }

    @Override
    public void onDetach() {

        super.onDetach();

    }

    @Override
    public void onDestroyView() {


        super.onDestroyView();

    }

    @Override
    public void onResume() {
        super.onResume();
        preferenceHelper.clearPrefData();
    }


    public void showPasswordFragment(String email) {
        getActivity().getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.loginContainer, LoginPasswordFragment.newInstance(email), LoginPasswordFragment.TAG).addToBackStack(LoginPasswordFragment.TAG)
                .commit();
    }

    public void moveToRegistration() {
        RegistrationActivity.startRegistration(getActivity(), viewModel.email.get());
    }



}
