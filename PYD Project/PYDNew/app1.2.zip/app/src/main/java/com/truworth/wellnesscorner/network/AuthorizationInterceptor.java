package com.truworth.wellnesscorner.network;

import android.content.Context;

import com.truworth.wellnesscorner.data.SharedPreferenceHelper;

import java.io.IOException;

import okhttp3.Interceptor;
import okhttp3.Request;
import okhttp3.Response;

/**
 * Created by rajeshs on 4/6/2018.
 */

public class AuthorizationInterceptor implements Interceptor {

    private Context context;
    private SharedPreferenceHelper prefHelper;


    public AuthorizationInterceptor(Context context, SharedPreferenceHelper prefHelper) {
        this.context = context;
        this.prefHelper = prefHelper;
    }

    @Override
    public Response intercept(Chain chain) throws IOException {
        Request originalRequest = chain.request();
        Request.Builder request = originalRequest.newBuilder();
        request.addHeader("Authorization", "bearer " + prefHelper.getToken());
        request.addHeader("Content-Type", "application/json");
        Response response = chain.proceed(request.build());
        return response;
    }
}
