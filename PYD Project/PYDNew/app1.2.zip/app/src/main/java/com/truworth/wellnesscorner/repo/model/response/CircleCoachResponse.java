package com.truworth.wellnesscorner.repo.model.response;

import com.truworth.wellnesscorner.model.CircleCoach;

import java.util.ArrayList;
import java.util.List;

public class CircleCoachResponse {

    private boolean hasError;
    private Object error;
    private List<CircleCoach> data;

    public boolean isHasError() {
        return hasError;
    }

    public void setHasError(boolean hasError) {
        this.hasError = hasError;
    }

    public Object getError() {
        return error;
    }

    public void setError(Object error) {
        this.error = error;
    }

    public List<CircleCoach> getData() {
        return data;
    }

    public void setData(ArrayList<CircleCoach> data) {
        this.data = data;
    }

}
