package com.truworth.wellnesscorner.base;

import android.support.v7.app.AppCompatActivity;

/**
 * Created by rajeshs on 4/10/2018.
 */

public class BaseActivity extends AppCompatActivity {


}
