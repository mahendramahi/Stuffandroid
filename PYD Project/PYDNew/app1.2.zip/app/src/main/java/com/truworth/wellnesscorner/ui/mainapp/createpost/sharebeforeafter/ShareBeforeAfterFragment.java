package com.truworth.wellnesscorner.ui.mainapp.createpost.sharebeforeafter;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.View;

import com.karumi.dexter.Dexter;
import com.karumi.dexter.MultiplePermissionsReport;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.multi.MultiplePermissionsListener;
import com.truworth.wellnesscorner.BR;
import com.truworth.wellnesscorner.R;
import com.truworth.wellnesscorner.base.BaseFragment;
import com.truworth.wellnesscorner.databinding.FragmentShareBeforeAfterBinding;
import com.truworth.wellnesscorner.ui.mainapp.createpost.ShareActivity;
import com.truworth.wellnesscorner.utils.AppConstants;
import com.truworth.wellnesscorner.utils.CameraGalleryUtil;
import com.truworth.wellnesscorner.utils.Utils;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.util.List;

public class ShareBeforeAfterFragment extends BaseFragment<FragmentShareBeforeAfterBinding, ShareBeforeAfterViewModel> {

    ShareBeforeAfterViewModel viewModel;
    private CameraGalleryUtil cameraGalleryUtil;
    static Fragment mfragment;
    private boolean isAfterGallery = false;
    private Bitmap finalBitmap;
    private boolean isImagesCaptured = false;

    public ShareBeforeAfterFragment() {
        // Required empty public constructor
    }

    public static ShareBeforeAfterFragment newInstance() {
        ShareBeforeAfterFragment fragment = new ShareBeforeAfterFragment();
        mfragment = (Fragment) fragment;
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        cameraGalleryUtil = new CameraGalleryUtil(getActivity(), mfragment);
    }

    @Override
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        setDataObserver();
    }
    @Override
    public int getBindingVariable() {
        return BR.viewModel;
    }

    @Override
    public int getLayoutId() {
        return R.layout.fragment_share_before_after;
    }

    @Override
    public ShareBeforeAfterViewModel getViewModel() {
        viewModel = ViewModelProviders.of(this).get(ShareBeforeAfterViewModel.class);
        return viewModel;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
    }

    @Override
    public void onDetach() {
        super.onDetach();
    }

    private void setDataObserver() {

        viewModel.getOpenGallery().observe(this, new Observer<Void>() {
            @Override
            public void onChanged(@Nullable Void avoid) {
                Utils.checkForGalleryPermissions(getActivity(), cameraGalleryUtil);
            }
        });

        viewModel.getOpenCamera().observe(this, new Observer<Void>() {
            @Override
            public void onChanged(@Nullable Void avoid) {
                selectImage();
            }
        });

        viewModel.getShareBtn().observe(this, new Observer<Void>() {
            @Override
            public void onChanged(@Nullable Void avoid) {

                if (finalBitmap != null) {
                    String path = Utils.getImageUri(getContext(), finalBitmap);
                    Intent returnIntent = new Intent();
                    returnIntent.putExtra("result", path);
                    getActivity().setResult(Activity.RESULT_OK, returnIntent);
                    getActivity().finish();
                }
            }
        });
    }

    private void selectImage() {
        final CharSequence[] items = {"Take Photo", "Choose from Gallery", "Cancel"};
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle("Select Picture From:");
        builder.setItems(items, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int item) {

                if (items[item].equals("Take Photo")) {
                    Utils.checkForCameraPermissions(getActivity(), cameraGalleryUtil);

                } else if (items[item].equals("Choose from Gallery")) {

                    Utils.checkForGalleryPermissions(getActivity(), cameraGalleryUtil);
                    isAfterGallery = true;

                } else if (items[item].equals("Cancel")) {
                    dialog.dismiss();
                }

            }
        });
        builder.show();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode == Activity.RESULT_OK) {
            Uri selectedImage;

           if (requestCode == AppConstants.CAMERA_REQUEST) {
                if (cameraGalleryUtil.getCameraFilePath() != null) {

                    viewModel.showAfterImage.set(true);
                    File file = new File(cameraGalleryUtil.getCameraFilePath());
                    selectedImage = Uri.fromFile(file);
                    getViewDataBinding().ivAfter.setImageURI(selectedImage);
                    getImagesClicked();
                }
            }
           else if (requestCode == AppConstants.GALLERY_REQUEST && data != null && data.getData() != null) {
              if(isAfterGallery){

                  viewModel.showAfterImage.set(true);
                  selectedImage = data.getData();
                  getViewDataBinding().ivAfter.setImageURI(selectedImage);
                  getImagesClicked();
              }
              else{

                  viewModel.showBeforeImage.set(true);
                  selectedImage = data.getData();
                  getViewDataBinding().ivBefore.setImageURI(selectedImage);
                  getImagesClicked();
              }
              isAfterGallery = false;
            }
        } else {
            // Image not selected
             Utils.showToast(getActivity(), "File Not Select");
        }
    }

    public void setDefault() {

        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {

                Bitmap bm = Utils.layoutToImage(getViewDataBinding().rlSwitchLayout);
                ByteArrayOutputStream bytes = new ByteArrayOutputStream();
                bm.compress(Bitmap.CompressFormat.JPEG, 100, bytes);
                finalBitmap = bm;
            }
        }, 500);

    }

    private void getImagesClicked(){
        if(isImagesCaptured){
            viewModel.isShareEnabled.set(true);
            setDefault();
        }
        else{
            isImagesCaptured = true;
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        isImagesCaptured = false;
        viewModel.isShareEnabled.set(false);
        viewModel.showBeforeImage.set(false);
        viewModel.showAfterImage.set(false);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if(finalBitmap!=null){
            finalBitmap.recycle();
            finalBitmap=null;
        }


    }
}
