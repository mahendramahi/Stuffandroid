package com.truworth.wellnesscorner.ui.step;

import android.animation.ObjectAnimator;
import android.app.Activity;
import android.app.Fragment;
import android.content.DialogInterface;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.support.v4.widget.NestedScrollView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.DecelerateInterpolator;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;

import com.truworth.stepmodule.StepConnectionHelper;
import com.truworth.stepmodule.StepHelper;
import com.truworth.stepmodule.inteface.OnRangeStepsFound;
import com.truworth.stepmodule.inteface.OnTodayStepsFound;
import com.truworth.stepmodule.model.EFitMonthStepsBody;
import com.truworth.stepmodule.model.EFitMonthStepsResponse;
import com.truworth.stepmodule.model.FitBitStepsItem;
import com.truworth.stepmodule.model.StepItem;
import com.truworth.stepmodule.rest.FitBitRestClient;
import com.truworth.stepmodule.utils.FitBitConfig;
import com.truworth.wellnesscorner.R;
import com.truworth.wellnesscorner.TheWellnessCornerApp;
import com.truworth.wellnesscorner.customviews.CustomProgressDialog;
import com.truworth.wellnesscorner.customviews.CustomTextView;
import com.truworth.wellnesscorner.data.SharedPreferenceHelper;
import com.truworth.wellnesscorner.repo.StepRepository;

import com.truworth.wellnesscorner.repo.model.request.DeviceStepRequest;
import com.truworth.wellnesscorner.repo.model.request.SaveDeviceStepsBody;
import com.truworth.wellnesscorner.repo.model.response.GetMonthlyDeviceStepsResponse;
import com.truworth.wellnesscorner.repo.model.response.SaveStepsResponse;
import com.truworth.wellnesscorner.utils.AppConstants;
import com.truworth.wellnesscorner.utils.CommonUtils;
import com.truworth.wellnesscorner.utils.DateUtils;
import com.truworth.wellnesscorner.utils.Utils;

import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.inject.Inject;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class StepsTrackerFragment extends Fragment {

    @Inject
    StepRepository repository;

    @BindView(R.id.rootView)
    RelativeLayout rootView;

    @BindView(R.id.tvTotalSteps)
    CustomTextView tvTotalSteps;

    @BindView(R.id.pbSteps)
    ProgressBar pbSteps;

    @BindView(R.id.tvSyncNow)
    CustomTextView tvSyncNow;

    @BindView(R.id.nscrollMain)
    NestedScrollView nestedScrollMain;

    @BindView(R.id.rvStepCount)
    RecyclerView rvStepCount;

    @BindView(R.id.rlBaseView)
    RelativeLayout rlBaseView;

    @BindView(R.id.mainProgressBar)
    ProgressBar mainProgressBar;
    @BindView(R.id.tvLastUpdatedStep)
    CustomTextView tvLastUpdatedStep;

    @BindView(R.id.imgSyncNow)
    ImageView imgSyncNow;
    @Inject
    SharedPreferenceHelper prefHelper;
    private StepsTrackerAdapter mStepsTrackerAdapter;
    private String connectedDeviceType;
    private boolean isLastResult;
    private ArrayList<DeviceStepsItem> mStepsItemList;
    private boolean isFromSyncNowButtonPressed;
    private SimpleDateFormat sdfYYYYMMD, sdfMMDDYYYY;
    private CustomProgressDialog customProgressDialog;
    private OnStepSync onStepSync;
    private String monthDateYMD;
    private boolean apiCallStart = false;
    private Handler handler = new Handler();
    private Runnable runnable = this::fetchDevicesData;
    private StepConnectionHelper connectionHelper;
    private StepHelper stepHelper;
    private String accessToken = "";
    private Animation rotateSync;
    Runnable runnableGetDeviceSteps = new Runnable() {
        @Override
        public void run() {
            changeMonthDate();
            getDeviceStepsFromServer();
        }
    };

    public StepsTrackerFragment() {
        TheWellnessCornerApp.getApp().component().inject(this);
    }

    public static StepsTrackerFragment newInstance() {
        return new StepsTrackerFragment();
    }

    public void setConnectedDeviceType(String connectedDeviceType) {
        this.connectedDeviceType = connectedDeviceType;
        //isAlreadyLoaded = false;
        if (mStepsItemList != null)
            mStepsItemList.clear();
        isFromSyncNowButtonPressed = false;
        isLastResult = false;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        mStepsItemList = new ArrayList<>();
        mStepsTrackerAdapter = new StepsTrackerAdapter(mStepsItemList);
        sdfYYYYMMD = DateUtils.getSimpleDateFormatInstance(AppConstants.DATE_FORMAT_YYYY_MM_DD);
        sdfMMDDYYYY = DateUtils.getSimpleDateFormatInstance(AppConstants.DATE_FORMAT_MM_DD_YYYY_FORWARD_SLASH);
        customProgressDialog = new CustomProgressDialog(getActivity(), R.style.custom_progress_style, true);
        setupStepSyncCallback();
        setHasOptionsMenu(true);
    }


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_steps_tracker, container, false);
        ButterKnife.bind(this, rootView);

        setDefaultValues();
        setRecyclerView();

        if (connectedDeviceType != null && connectedDeviceType.length() > 0)
            handler.postDelayed(runnable, AppConstants.API_POST_DELAYED_TIME);
        else {
            mainProgressBar.setVisibility(View.GONE);
        }

        StepServerResponse homeDashboardResponse = TheWellnessCornerApp.getInstance().getStepServerResponse();
        if (homeDashboardResponse != null && homeDashboardResponse.getData() != null) {
            if (homeDashboardResponse.getData().getSteps() != null)
                setTodayProgress(homeDashboardResponse.getData().getSteps());
            if (homeDashboardResponse.getData().getLastStepSyncDate() != null)
                setTodayStepsSyncDate(homeDashboardResponse.getData().getLastStepSyncDate());
        }
        return rootView;
    }

    @Override
    public void onResume() {
        super.onResume();
        getView().setFocusableInTouchMode(true);
        getView().requestFocus();
        getView().setOnKeyListener(new View.OnKeyListener() {

            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (keyCode == KeyEvent.KEYCODE_BACK && event.getAction() == KeyEvent.ACTION_DOWN) {
                    onBack();
                    return true;

                }
                return false;
            }
        });

        ((StepActivity) getActivity()).setToolBarTitle(getString(R.string.toolbar_title_steps));
        ((StepActivity) getActivity()).showHomeAsUpEnableToolbar();

        if (connectedDeviceType.equalsIgnoreCase(AppConstants.FITBIT))
            accessToken = prefHelper.getPrefKeyFitBitAccessToken();
        else if (connectedDeviceType.equalsIgnoreCase(AppConstants.MISFIT))
            accessToken = prefHelper.getPrefKeyMisFitAccessToken();


        stepHelper = new StepHelper(getActivity(), accessToken);

    }

    private void setDefaultValues() {
        String date = DateUtils.GetMonthSlot(0, DateUtils.getTodayDate(AppConstants.DATE_FORMAT_DD_MMM_YYYY));
        String[] arrDate = date.split("-");
        monthDateYMD = DateUtils.formatDateStep(AppConstants.DATE_FORMAT_DD_MMM_YYYY, AppConstants.DATE_FORMAT_YYYY_MM_DD, arrDate[0]);

        isLastResult = false;
        mStepsItemList.clear();
    }

    private void setRecyclerView() {
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getActivity());
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        rvStepCount.setLayoutManager(linearLayoutManager);
        rvStepCount.setNestedScrollingEnabled(false);
        rvStepCount.setAdapter(mStepsTrackerAdapter);
        if (mStepsTrackerAdapter != null)
            mStepsTrackerAdapter.notifyDataSetChanged();

        nestedScrollMain.setOnScrollChangeListener(new NestedScrollView.OnScrollChangeListener() {
            @Override
            public void onScrollChange(NestedScrollView v, int scrollX, int scrollY, int oldScrollX, int oldScrollY) {
                if (scrollY == (v.getChildAt(0).getMeasuredHeight() - v.getMeasuredHeight()) && !apiCallStart && !isLastResult && mStepsTrackerAdapter.getItemCount() > 5) {
                    apiCallStart = true;
                    mStepsItemList.add(null);
                    mStepsTrackerAdapter.notifyItemInserted(mStepsItemList.size() - 1);
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            int targetScroll = nestedScrollMain.getScrollY() + 150;
                            nestedScrollMain.scrollTo(0, targetScroll);
                        }
                    }, 50);

                    changeMonthDate();
                    getDeviceStepsFromServer();
                }
            }
        });
    }

    private void setupStepSyncCallback() {
        onStepSync = new OnStepSync() {
            @Override
            public void OnStepSynced() {

                setDefaultValues();
                syncTodaySteps();
            }
        };
    }

    private void setTodayProgress(String totalSteps) {
        tvTotalSteps.setText(Utils.convertNumberWithCommas(totalSteps));

        if (totalSteps != null && !totalSteps.equals("")) {
            int progress = (int) Utils.getPercentage(Float.parseFloat(totalSteps), 8000f);
            ObjectAnimator animation = ObjectAnimator.ofInt(pbSteps, "progress", progress);
            animation.setDuration(500);
            animation.setInterpolator(new DecelerateInterpolator());
            animation.start();
        }
    }

    private void setTodayStepsSyncDate(String date) {
        tvLastUpdatedStep.setText(String.format(Locale.getDefault(), "Last Updated: %s", DateUtils.showDateTimeUsingServerFormatDate(date)));
    }

    @OnClick({R.id.tvSyncNow, R.id.tvLastUpdatedStep})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.tvSyncNow:
                if (isFromSyncNowButtonPressed) {
                    Utils.showToast(getActivity(), "Please wait sync is already in progress");
                } else {
                    setupAnimation();
                    if (connectedDeviceType != null) {
                        isFromSyncNowButtonPressed = true;
                        String date = DateUtils.GetMonthSlot(0, DateUtils.getTodayDate(AppConstants.DATE_FORMAT_DD_MMM_YYYY));
                        String[] arrDate = date.split("-");
                        monthDateYMD = DateUtils.formatDateStep(AppConstants.DATE_FORMAT_DD_MMM_YYYY, AppConstants.DATE_FORMAT_YYYY_MM_DD, arrDate[0]);
                        mStepsItemList.clear();
                        isLastResult = false;
                        if (mStepsTrackerAdapter != null)
                            mStepsTrackerAdapter.notifyDataSetChanged();
                        fetchDevicesData();
                    } else {
                        final StepServerResponse homeDashboardResponse = TheWellnessCornerApp.getInstance().getStepServerResponse();
                        if (homeDashboardResponse != null && homeDashboardResponse.getData() != null && homeDashboardResponse.getData().getLastConnectedDevice() != null) {
                            String msg = String.format(getString(R.string.step_already_connected), homeDashboardResponse.getData().getLastConnectedDevice());
                            CommonUtils.showAlertDialog(getActivity(), getString(R.string.app_name), 0, msg, "Proceed", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    dialogInterface.dismiss();
                                    stopAnimation();
                                    Utils.replaceFragment(getFragmentManager(), StepTrackerSettingFragment.newInstance(), StepTrackerSettingFragment.class.getSimpleName(), true, R.id.fragmentContainer);
                                }
                            }, "Cancel", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    stopAnimation();
                                    dialogInterface.dismiss();
                                }
                            }, false);
                        }
                    }
                }
                break;
            case R.id.tvLastUpdatedStep:
                break;
        }
    }

    private void fetchDevicesData() {
        final StepServerResponse homeDashboardResponse = TheWellnessCornerApp.getInstance().getStepServerResponse();
        if (homeDashboardResponse != null && homeDashboardResponse.getData() != null) {

            if (homeDashboardResponse.getData().getLastStepSyncDate() != null && homeDashboardResponse.getData().getLastStepSyncDate().length() > 0) {
                String lastStepSyncDate = homeDashboardResponse.getData().getLastStepSyncDate();
                String lastDateInStartOfDay = DateUtils.getDateFromMillis(DateUtils.getStartTimeOfGivenDay(DateUtils.getMillisFromStringDate(lastStepSyncDate, AppConstants.SERVER_DATE_FORMAT_WITH_MILLISECONDS)), AppConstants.SERVER_DATE_FORMAT_WITH_MILLISECONDS);
                String currentDateTime = DateUtils.getTodayStartTimeInFormat(AppConstants.SERVER_DATE_FORMAT_WITH_MILLISECONDS);
                long syncDaysDifference = DateUtils.getDaysDifferenceStep(lastDateInStartOfDay, currentDateTime, AppConstants.SERVER_DATE_FORMAT_WITH_MILLISECONDS);
                // In case there is difference in negative it means sync date is future date..
                if (syncDaysDifference < 0) {
                    // TODO
                } else if (syncDaysDifference == 0) {
                    // sync step for today
                    if (NetworkFactory.getInstance().isNetworkAvailable(getActivity())) {
                        syncTodaySteps();
                    }
                } else {
                    if (NetworkFactory.getInstance().isNetworkAvailable(getActivity())) {
                        syncMultipleDaysSteps(lastStepSyncDate, currentDateTime);
                    }
                }
            } else {
                // sync steps from the first step sync date
                if (homeDashboardResponse.getData() != null
                        && homeDashboardResponse.getData() != null
                        && homeDashboardResponse.getData().getFirstStepSyncDate() != null) {
                    String firstStepSyncDate = DateUtils.truncateMilliseconds(homeDashboardResponse.getData().getFirstStepSyncDate());
                    String currentDateTime = DateUtils.getTodayStartTimeInFormat(AppConstants.SERVER_DATE_FORMAT_WITH_MILLISECONDS);
                    syncMultipleDaysSteps(firstStepSyncDate, currentDateTime);
                } else {
                    // here we have to sync today steps
                    if (NetworkFactory.getInstance().isNetworkAvailable(getActivity())) {
                        syncTodaySteps();
                    }
                }
            }
        }
    }

    private void syncTodaySteps() {
        if (connectedDeviceType != null && connectedDeviceType.length() > 0) {
            if (connectedDeviceType.equalsIgnoreCase(AppConstants.FITBIT)) {
                stepHelper.getTodayStepsFromFitbit(new OnTodayStepsFound() {
                    @Override
                    public void onTodayStepsFound(ArrayList<StepItem> foundStepList) {
                        stopAnimation();
                        saveTodayStepsToServer(foundStepList.get(0).getStepCount(), foundStepList.get(0).getCalories(), AppConstants.FITBIT);
                        setDefaultValues();
                        getDeviceStepsFromServer();


                    }

                    @Override
                    public void onTodayStepsError(String error) {

                    }
                });
            } else if (connectedDeviceType.equalsIgnoreCase(AppConstants.S_HEALTH)) {

                stepHelper.getTodayStepsFromSamsung(new OnTodayStepsFound() {
                    @Override
                    public void onTodayStepsFound(ArrayList<StepItem> foundStepList) {
                        prefHelper.setPrefKeyDeviceConnected(connectedDeviceType);
                        prefHelper.clearDeviceConnectTokenPreferences();

                        saveTodayStepsToServer((foundStepList.get(0).getStepCount()), foundStepList.get(0).getCalories(), AppConstants.S_HEALTH);

                        stopAnimation();
                        setDefaultValues();
                        getDeviceStepsFromServer();
                    }

                    @Override
                    public void onTodayStepsError(String error) {

                    }
                });

            } else if (connectedDeviceType.equalsIgnoreCase(AppConstants.GOOGLE_FIT)) {
                stepHelper.getTodayStepsFromGoogle(new OnTodayStepsFound() {
                    @Override
                    public void onTodayStepsFound(ArrayList<StepItem> foundStepList) {
                        prefHelper.setPrefKeyDeviceConnected(connectedDeviceType);
                        prefHelper.clearDeviceConnectTokenPreferences();
                        saveTodayStepsToServer((foundStepList.get(0).getStepCount()), foundStepList.get(0).getCalories(), AppConstants.GOOGLE_FIT);

                        stopAnimation();
                        setDefaultValues();
                        getDeviceStepsFromServer();
                    }

                    @Override
                    public void onTodayStepsError(String error) {

                    }
                });
            } else if (connectedDeviceType.equalsIgnoreCase(AppConstants.E_FIT)) {
                getEFitTodaySteps();
            } else if (connectedDeviceType.equalsIgnoreCase(AppConstants.MISFIT)) {

                stepHelper.getTodayStepsMisfit(new OnTodayStepsFound() {
                    @Override
                    public void onTodayStepsFound(ArrayList<StepItem> foundStepList) {
                        stopAnimation();
                        saveTodayStepsToServer((foundStepList.get(0).getStepCount()), foundStepList.get(0).getCalories(), AppConstants.MISFIT);

                        setDefaultValues();
                        getDeviceStepsFromServer();

                    }

                    @Override
                    public void onTodayStepsError(String error) {

                    }
                });

            } else if (connectedDeviceType.equalsIgnoreCase(AppConstants.GARMIN)) {

            }
        }


    }


    private void syncMultipleDaysSteps(String lastStepSyncDate, String currentDateTime) {
        if (connectedDeviceType != null && connectedDeviceType.length() > 0) {
            long startDate = DateUtils.getMillisFromStringDate(lastStepSyncDate, AppConstants.SERVER_DATE_FORMAT_WITH_MILLISECONDS);
            long mStartDate = DateUtils.getStartTimeOfGivenDay(startDate);

            long endDate = DateUtils.getMillisFromStringDate(currentDateTime, AppConstants.SERVER_DATE_FORMAT_WITH_MILLISECONDS);
            long mEndDate = DateUtils.getStartTimeOfGivenDay(endDate);

            if (connectedDeviceType.equalsIgnoreCase(AppConstants.GOOGLE_FIT)) {

                stepHelper.getStepsFromGoogle(mStartDate, mEndDate, new OnRangeStepsFound() {
                    @Override
                    public void onRangeStepsFound(ArrayList<StepItem> foundStepList) {
                        stopAnimation();
                        prefHelper.setPrefKeyDeviceConnected(AppConstants.GOOGLE_FIT);
                        prefHelper.clearDeviceConnectTokenPreferences();
                        ArrayList<StepsBean> stepsBeanList = new ArrayList<>();
                        for (StepItem stepItem : foundStepList) {
                            // String date = DateUtils.formatDateStep(AppConstants.DATE_FORMAT_YYYY_MM_DD, AppConstants.DATE_FORMAT_MM_DD_YYYY_HHMM_FORWARD_SLASH, stepItem.getStepTime());
                            StepsBean stepsBean = new StepsBean();
                            stepsBean.setSteps(Integer.parseInt(stepItem.getStepCount()));
                            stepsBean.setStepsDate(stepItem.getStepTime());
                            stepsBean.setCalories(stepItem.getCalories());
                            stepsBean.setActivityDate(stepItem.getStepTime());
                            stepsBeanList.add(stepsBean);
                        }

                        saveStepsToServer(onStepSync, AppConstants.GOOGLE_FIT, stepsBeanList, stepsBeanList);
                    }

                    @Override
                    public void onStepsFoundError(String error) {

                    }
                });
            } else if (connectedDeviceType.equalsIgnoreCase(AppConstants.E_FIT)) {
                getEFitStepsForSync(mStartDate, mEndDate);
            } else if (connectedDeviceType.equalsIgnoreCase(AppConstants.S_HEALTH)) {
                stepHelper.getStepsFromSamsung(mStartDate, mEndDate, new OnRangeStepsFound() {
                    @Override
                    public void onRangeStepsFound(ArrayList<StepItem> foundStepList) {
                        prefHelper.setPrefKeyDeviceConnected(AppConstants.S_HEALTH);
                        prefHelper.clearDeviceConnectTokenPreferences();
                        ArrayList<StepsBean> stepsBeanList = new ArrayList<>();
                        for (StepItem stepItem : foundStepList) {
                            //String date = DateUtils.formatDateStep(AppConstants.DATE_FORMAT_YYYY_MM_DD, AppConstants.DATE_FORMAT_MM_DD_YYYY_HHMM_FORWARD_SLASH, stepItem.getStepTime());
                            StepsBean stepsBean = new StepsBean();
                            stepsBean.setSteps(Integer.parseInt(stepItem.getStepCount()));
                            stepsBean.setStepsDate(stepItem.getStepTime());
                            stepsBean.setCalories(stepItem.getCalories());
                            stepsBean.setActivityDate(stepItem.getStepTime());
                            stepsBeanList.add(stepsBean);
                        }

                        saveStepsToServer(onStepSync, AppConstants.S_HEALTH, stepsBeanList, stepsBeanList);
                    }

                    @Override
                    public void onStepsFoundError(String error) {

                    }
                });
            } else if (connectedDeviceType.equalsIgnoreCase(AppConstants.FITBIT)) {
                stepHelper.getStepsFromFitbit(mStartDate, mEndDate, new OnRangeStepsFound() {
                    @Override
                    public void onRangeStepsFound(ArrayList<StepItem> foundStepList) {
                        final ArrayList<StepsBean> stepsBeanList = new ArrayList<>();
                        for (StepItem stepItem : foundStepList) {
                            StepsBean stepsBean = new StepsBean();
                            stepsBean.setCalories(stepItem.getCalories());
                            stepsBean.setSteps(Integer.parseInt(stepItem.getStepCount()));

                            //String date = DateUtils.formatDateStep(AppConstants.DATE_FORMAT_MM_DD_YYYY_HHMM_FORWARD_SLASH, AppConstants.DATE_FORMAT_MM_DD_YYYY_HHMM_FORWARD_SLASH, stepItem.getStepTime());
                            stepsBean.setStepsDate(stepItem.getStepTime());
                            stepsBean.setActivityDate(stepItem.getStepTime());
                            stepsBeanList.add(stepsBean);
                        }


                        saveStepsToServer(onStepSync, AppConstants.FITBIT, stepsBeanList, stepsBeanList);
                    }

                    @Override
                    public void onStepsFoundError(String error) {

                    }
                });

            } else if (connectedDeviceType.equalsIgnoreCase(AppConstants.MISFIT)) {

                stepHelper.getStepsFromMisfit(mStartDate, mEndDate, new OnRangeStepsFound() {
                    @Override
                    public void onRangeStepsFound(ArrayList<StepItem> foundStepList) {

                        final ArrayList<StepsBean> stepsBeanList = new ArrayList<>();
                        for (StepItem stepItem : foundStepList) {
                            StepsBean stepsBean = new StepsBean();
                            stepsBean.setCalories(stepItem.getCalories());
                            stepsBean.setSteps(Integer.parseInt(stepItem.getStepCount()));

                            //String date = DateUtils.formatDateStep(AppConstants.DATE_FORMAT_YYYY_MM_DD, AppConstants.DATE_FORMAT_MM_DD_YYYY_HHMM_FORWARD_SLASH, stepItem.getStepTime());
                            stepsBean.setStepsDate(stepItem.getStepTime());
                            stepsBean.setActivityDate(stepItem.getStepTime());
                            stepsBeanList.add(stepsBean);
                        }


                        saveStepsToServer(onStepSync, AppConstants.MISFIT, stepsBeanList, stepsBeanList);

                    }

                    @Override
                    public void onStepsFoundError(String error) {

                    }
                });

            } else if (connectedDeviceType.equalsIgnoreCase(AppConstants.GARMIN)) {
                // long startTime = DateFactory.getInstance().getEpochFromStringDate(DateFactory.getInstance().formatDate(Constant.SERVER_DATE_FORMAT_WITH_MILLISECONDS, "yyyy-MM-dd HH:mm:ss.SSS zzz", lastStepSyncDate), "yyyy-MM-dd HH:mm:ss.SSS zzz") / 1000L;
                // fetchGarminStepsData(startTime);
            }
        }
    }

    private void saveTodayStepsToServer(final String steps, final int calories, String connectedDevice) {
        String date = DateUtils.getTodayDate(AppConstants.DATE_FORMAT_MM_DD_YYYY_HHMM_FORWARD_SLASH);

        StepsBean stepsBean = new StepsBean();
        stepsBean.setSteps(Integer.parseInt(steps));
        stepsBean.setCalories(calories);
        stepsBean.setStepsDate(date);
        stepsBean.setActivityDate(date);
        ArrayList<StepsBean> stepsBeanList = new ArrayList<>();
        stepsBeanList.add(stepsBean);

        SaveDeviceStepsBody saveDeviceStepsBody = new SaveDeviceStepsBody();
        saveDeviceStepsBody.setDevice(connectedDevice);
        // saveDeviceStepsBody.setMemberID(Integer.parseInt(WellnessCornerApp.getPreferenceManager().getUserId()));
        saveDeviceStepsBody.setSteps(stepsBeanList);
        saveDeviceStepsBody.setCalories(stepsBeanList);
        repository.saveDeviceSteps(saveDeviceStepsBody).subscribe(new Observer<SaveStepsResponse>() {
            @Override
            public void onSubscribe(Disposable d) {

            }

            @Override
            public void onNext(SaveStepsResponse response) {
                if (response != null) {
                    if (response.getStatus() == 0) {
                        stopAnimation();
                        setTodayProgress(String.valueOf(response.getTodaySteps()));
                        setTodayStepsSyncDate(response.getLastStepUpdatedDate());
                        if (TheWellnessCornerApp.getInstance().getStepServerResponse() != null
                                && TheWellnessCornerApp.getInstance().getStepServerResponse().getData() != null) {
                            TheWellnessCornerApp.getInstance().getStepServerResponse().getData().setLastConnectedDevice(response.getLastConnectedDevice());
                            TheWellnessCornerApp.getInstance().getStepServerResponse().getData().setLastStepSyncDate(response.getLastStepsTrackerDate());
                        }

                    }
                }
            }

            @Override
            public void onError(Throwable e) {

            }

            @Override
            public void onComplete() {

            }
        });


    }


    private void getDeviceStepsFromServer() {
        DeviceStepRequest deviceStepRequest = new DeviceStepRequest();
        deviceStepRequest.setDate(monthDateYMD);
        deviceStepRequest.setDeviceType("");
        //deviceStepRequest.setMemberID(Integer.parseInt(WellnessCornerApp.getPreferenceManager().getUserId()));

        repository.getMemberStepsFromServer(deviceStepRequest).subscribe(new Observer<GetMonthlyDeviceStepsResponse>() {
            @Override
            public void onSubscribe(Disposable d) {

            }

            @Override
            public void onNext(GetMonthlyDeviceStepsResponse getMonthlyDeviceStepsResponse) {
                if (isAdded() && getActivity() != null) {

                    mainProgressBar.setVisibility(View.GONE);
                    rlBaseView.setVisibility(View.VISIBLE);
                    removeProgressLoading();
                    GetMonthlyDeviceStepsResponse monthlyDeviceStepsResponse = getMonthlyDeviceStepsResponse;
                    if (monthlyDeviceStepsResponse != null) {
                        if (monthlyDeviceStepsResponse.getStatus() == 0 && monthlyDeviceStepsResponse.getStepData() != null) {
                           if(monthlyDeviceStepsResponse.getStepData().size()>1) {
                               insertMonthHeader(monthlyDeviceStepsResponse.getStepData());
                               mStepsItemList.addAll(monthlyDeviceStepsResponse.getStepData());
                               mStepsTrackerAdapter.notifyDataSetChanged();
                           }
                            if (monthlyDeviceStepsResponse.getStepData().size() <= 10) {
                                handler.postDelayed(runnableGetDeviceSteps, 100);
                            }

                        } else if (monthlyDeviceStepsResponse.getStatus() == 1) {
                            isFromSyncNowButtonPressed = false;
                            isLastResult = true;
                        } else {
                            isFromSyncNowButtonPressed = false;
                            CommonUtils.showAlertDialog(getActivity(), null, 0, getString(R.string.msg_api_response_null), getString(R.string.str_ok), true);
                        }
                    } else {
                        CommonUtils.showAlertDialog(getActivity(), null, 0, getString(R.string.msg_api_response_failure), getString(R.string.str_ok), true);
                    }
                    apiCallStart = false;
                }
            }

            @Override
            public void onError(Throwable e) {
                if (isAdded() && getActivity() != null) {
                    mainProgressBar.setVisibility(View.GONE);
                    removeProgressLoading();
                    apiCallStart = false;
                    isFromSyncNowButtonPressed = false;
                    CommonUtils.showAlertDialog(getActivity(), null, 0, getString(R.string.msg_api_response_failure), getString(R.string.str_ok), true);

                }
            }

            @Override
            public void onComplete() {

            }
        });


    }


    private void insertMonthHeader(List<DeviceStepsItem> mStepsList) {
        if (getActivity() != null && !isRemoving()) {
            int totalSteps = 0;
            long millisOfMonth;

            millisOfMonth = DateUtils.getMillisFromStringDate(monthDateYMD, AppConstants.DATE_FORMAT_YYYY_MM_DD);

            Calendar currentCalendar = Calendar.getInstance();
            currentCalendar.setTimeInMillis(millisOfMonth);


            for (DeviceStepsItem deviceStepsItem : mStepsList) {
                totalSteps += Integer.parseInt(deviceStepsItem.getValue());
            }


            if (mStepsList.size() > 0) {
                String monthDate = mStepsList.get(0).getDate();
                monthDate = DateUtils.formatDateStep(AppConstants.SERVER_DATE_FORMAT_WITH_MILLISECONDS, AppConstants.DATE_FORMAT_YYYY_MM_DD, monthDate);
                // if we wants to remove today steps from current month then enable this condition
                if (DateUtils.isDateFromCurrentsMonth(currentCalendar)
                        && DateUtils.getInstance().getTodayDate(AppConstants.DATE_FORMAT_YYYY_MM_DD).equalsIgnoreCase(monthDate)) {
                    //totalSteps -= Integer.parseInt(mStepsList.get(0).getValue());
                    mStepsList.remove(0);
                }
                DeviceStepsItem deviceStepsItem = new DeviceStepsItem();
                deviceStepsItem.setValue(MessageFormat.format("{0} steps", String.valueOf(totalSteps)));
                deviceStepsItem.setMonth(true);
                String monthName = DateUtils.formatDateStep(AppConstants.DATE_FORMAT_YYYY_MM_DD, AppConstants.DATE_FORMAT_MMMM, monthDate);
                deviceStepsItem.setDate(monthName);
                mStepsList.add(0, deviceStepsItem);
            }


        }
    }

    private void saveStepsToServer(OnStepSync onStepSync, String connectedDevice, ArrayList<StepsBean> stepsBeanList, ArrayList<StepsBean> caloriesBeanList) {
        SaveDeviceStepsBody saveDeviceStepsBody = new SaveDeviceStepsBody();
        saveDeviceStepsBody.setDevice(connectedDevice);
        //saveDeviceStepsBody.setMemberID(Integer.parseInt(WellnessCornerApp.getPreferenceManager().getUserId()));
        saveDeviceStepsBody.setSteps(stepsBeanList);
        if (caloriesBeanList != null && caloriesBeanList.size() > 0)
            saveDeviceStepsBody.setCalories(caloriesBeanList);

        repository.saveDeviceSteps(saveDeviceStepsBody).subscribe(new Observer<SaveStepsResponse>() {
            @Override
            public void onSubscribe(Disposable d) {

            }

            @Override
            public void onNext(SaveStepsResponse response) {
                if (response != null) {
                    if (response.getStatus() == 0) {
                        if (TheWellnessCornerApp.getInstance().getStepServerResponse() != null
                                && TheWellnessCornerApp.getInstance().getStepServerResponse().getData() != null) {
                            TheWellnessCornerApp.getInstance().getStepServerResponse().getData().setLastConnectedDevice(response.getLastConnectedDevice());
                            TheWellnessCornerApp.getInstance().getStepServerResponse().getData().setLastStepSyncDate(response.getLastStepsTrackerDate());
                        }
                        if (onStepSync != null) {
                            onStepSync.OnStepSynced();
                        }
                    }
                }
            }

            @Override
            public void onError(Throwable e) {

            }

            @Override
            public void onComplete() {

            }
        });


    }

    private void getEFitTodaySteps() {
        String fromDateEFit = DateUtils.getInstance().getTodayDate("yyyy MM dd");
        String toDateEFit = DateUtils.getInstance().getTodayDate("yyyy MM dd");
        EFitMonthStepsBody eFitMonthStepsBody = new EFitMonthStepsBody();
        eFitMonthStepsBody.setMemberId(prefHelper.getEFitUserId());
        eFitMonthStepsBody.setStartDate(fromDateEFit);
        eFitMonthStepsBody.setEndDate(toDateEFit);

        FitBitRestClient restClient = new FitBitRestClient("EFit", "", getActivity(), FitBitConfig.E_FIT_BASE_URL, false);
        restClient.getFitBitStepsService().getEFitMonthSteps(eFitMonthStepsBody).enqueue(new Callback<EFitMonthStepsResponse>() {
            @SuppressWarnings("StatementWithEmptyBody")
            @Override
            public void onResponse(Call<EFitMonthStepsResponse> call, Response<EFitMonthStepsResponse> response) {
                if (getActivity() != null && isAdded()) {
                    stopAnimation();
                    if (response != null) {
                        EFitMonthStepsResponse eFitMonthStepsResponse = response.body();
                        if (eFitMonthStepsResponse != null) {
                            if (eFitMonthStepsResponse.getSuccess().equalsIgnoreCase("1")) {
                                List<FitBitStepsItem> stepsItemList = eFitMonthStepsResponse.getStepsData();
                                if (stepsItemList != null && stepsItemList.size() > 0) {
                                    saveTodayStepsToServer(stepsItemList.get(0).getValue(), (int) stepsItemList.get(0).getCalory(), AppConstants.E_FIT);
                                    setDefaultValues();
                                    getDeviceStepsFromServer();
                                } else {
                                }
                            } else if (eFitMonthStepsResponse.getSuccess().equalsIgnoreCase("2")) {
                                // no steps available
                                saveTodayStepsToServer("0", 0, AppConstants.E_FIT);

                                setDefaultValues();
                                getDeviceStepsFromServer();
                                mainProgressBar.setVisibility(View.GONE);
                            } else {
                                CommonUtils.showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_response_failure), getString(R.string.str_ok), false);
                            }
                        } else {
                            CommonUtils.showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_response_null), getString(R.string.str_ok), false);
                        }
                    } else {
                        CommonUtils.showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_response_null), getString(R.string.str_ok), false);
                    }
                }
            }

            @Override
            public void onFailure(Call<EFitMonthStepsResponse> call, Throwable t) {
                if (getActivity() != null && isAdded()) {
                    stopAnimation();
                    CommonUtils.showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_failure), getString(R.string.str_ok), false);
                }
            }
        });
    }

    private void getEFitStepsForSync(long startDate, long endDate) {
        String fromDateEFit = DateUtils.getInstance().getDateFromMillis(startDate, AppConstants.DATE_FORMAT_YYYY_MM_DD);
        String toDateEFit = DateUtils.getInstance().getDateFromMillis(endDate, AppConstants.DATE_FORMAT_YYYY_MM_DD);

        EFitMonthStepsBody eFitMonthStepsBody = new EFitMonthStepsBody();
        eFitMonthStepsBody.setMemberId(prefHelper.getEFitUserId());
        eFitMonthStepsBody.setStartDate(fromDateEFit);
        eFitMonthStepsBody.setEndDate(toDateEFit);

        FitBitRestClient restClient = new FitBitRestClient("EFit", "", getActivity(), FitBitConfig.E_FIT_BASE_URL, false);
        restClient.getFitBitStepsService().getEFitMonthSteps(eFitMonthStepsBody).enqueue(new Callback<EFitMonthStepsResponse>() {
            @SuppressWarnings("StatementWithEmptyBody")
            @Override
            public void onResponse(Call<EFitMonthStepsResponse> call, Response<EFitMonthStepsResponse> response) {
                if (getActivity() != null && isAdded()) {
                    stopAnimation();
                    if (response != null) {
                        EFitMonthStepsResponse eFitMonthStepsResponse = response.body();
                        if (eFitMonthStepsResponse != null) {
                            if (eFitMonthStepsResponse.getSuccess().equalsIgnoreCase("1")) {
                                List<FitBitStepsItem> stepsItemList = eFitMonthStepsResponse.getStepsData();
                                if (stepsItemList != null && stepsItemList.size() > 0) {

                                    HashMap<String, FitBitStepsItem> hashMap = new HashMap<>();
                                    Calendar fromCalendar = Calendar.getInstance();
                                    fromCalendar.setTimeInMillis(startDate);

                                    Calendar toCalendar = Calendar.getInstance();
                                    toCalendar.setTimeInMillis(endDate);
                                    String dateFromMillis = DateUtils.getInstance().getDateFromMillis(startDate, AppConstants.DATE_FORMAT_YYYY_MM_DD);
                                    System.out.println("steps dateFromMillis====" + dateFromMillis);
                                    FitBitStepsItem stepItemEmpty = new FitBitStepsItem();
                                    stepItemEmpty.setDateTime(dateFromMillis);
                                    stepItemEmpty.setCalory(0);
                                    stepItemEmpty.setValue("0");
                                    hashMap.put(dateFromMillis, stepItemEmpty);

                                    String dateToMillis = DateUtils.getInstance().getDateFromMillis(endDate, AppConstants.DATE_FORMAT_YYYY_MM_DD);
                                    System.out.println("steps dateToMillis====" + dateToMillis);
                                    stepItemEmpty = new FitBitStepsItem();
                                    stepItemEmpty.setDateTime(dateToMillis);
                                    stepItemEmpty.setCalory(0);
                                    stepItemEmpty.setValue("0");
                                    hashMap.put(dateToMillis, stepItemEmpty);

                                    if (!dateFromMillis.equalsIgnoreCase(dateToMillis)) {
                                        while (!dateFromMillis.equalsIgnoreCase(dateToMillis)) {
                                            fromCalendar.add(Calendar.DATE, 1);
                                            String dateMillis = DateUtils.getInstance().getDateFromMillis(fromCalendar.getTimeInMillis(), AppConstants.DATE_FORMAT_YYYY_MM_DD);
                                            dateFromMillis = dateMillis;
                                            stepItemEmpty = new FitBitStepsItem();
                                            stepItemEmpty.setDateTime(dateMillis);
                                            stepItemEmpty.setCalory(0);
                                            stepItemEmpty.setValue("0");
                                            System.out.println("steps dateMillis====" + dateMillis);
                                            hashMap.put(dateMillis, stepItemEmpty);
                                        }
                                    }
                                    for (FitBitStepsItem fitBitStepsItem : stepsItemList) {
                                        hashMap.put(fitBitStepsItem.getDateTime(), fitBitStepsItem);
                                    }

                                    ArrayList<StepsBean> stepsBeanList = new ArrayList<>();

                                    for (Map.Entry<String, FitBitStepsItem> entry : hashMap.entrySet()) {
                                        String key = entry.getKey();
                                        FitBitStepsItem fitBitStepsItem = entry.getValue();

                                        String date = DateUtils.getInstance().formatDateStep(AppConstants.DATE_FORMAT_YYYY_MM_DD, AppConstants.DATE_FORMAT_MM_DD_YYYY_HHMM_FORWARD_SLASH, fitBitStepsItem.getDateTime());
                                        String steps = fitBitStepsItem.getValue();
                                        StepsBean stepsBean = new StepsBean();
                                        stepsBean.setSteps(Integer.parseInt(steps));
                                        stepsBean.setStepsDate(date);
                                        stepsBean.setActivityDate(date);
                                        stepsBean.setCalories((int) fitBitStepsItem.getCalory());
                                        stepsBeanList.add(stepsBean);

                                    }
                                    // As discussed with Rohit  and Testing Team zeros won't be included at the time of showing data
                                    // Steps will be shown as it is. 1/7/2017
                                    // ArrayList<StepsBean> stepListToSync = addAbsentDayWithZeroSteps(stepsBeanList, finalLastSyncedMillis);
                                    saveStepsToServer(onStepSync, AppConstants.E_FIT, stepsBeanList, stepsBeanList);
                                }

                            } else if (eFitMonthStepsResponse.getSuccess().equalsIgnoreCase("2")) {
                                // no steps available
                                HashMap<String, FitBitStepsItem> hashMap = new HashMap<>();
                                Calendar fromCalendar = Calendar.getInstance();
                                fromCalendar.setTimeInMillis(startDate);

                                Calendar toCalendar = Calendar.getInstance();
                                toCalendar.setTimeInMillis(endDate);
                                String dateFromMillis = DateUtils.getInstance().getDateFromMillis(startDate, AppConstants.DATE_FORMAT_YYYY_MM_DD);
                                System.out.println("steps dateFromMillis====" + dateFromMillis);
                                FitBitStepsItem stepItemEmpty = new FitBitStepsItem();
                                stepItemEmpty.setDateTime(dateFromMillis);
                                stepItemEmpty.setCalory(0);
                                stepItemEmpty.setValue("0");
                                hashMap.put(dateFromMillis, stepItemEmpty);

                                String dateToMillis = DateUtils.getInstance().getDateFromMillis(endDate, AppConstants.DATE_FORMAT_YYYY_MM_DD);
                                System.out.println("steps dateToMillis====" + dateToMillis);
                                stepItemEmpty = new FitBitStepsItem();
                                stepItemEmpty.setDateTime(dateToMillis);
                                stepItemEmpty.setCalory(0);
                                stepItemEmpty.setValue("0");
                                hashMap.put(dateToMillis, stepItemEmpty);

                                if (!dateFromMillis.equalsIgnoreCase(dateToMillis)) {
                                    while (!dateFromMillis.equalsIgnoreCase(dateToMillis)) {
                                        fromCalendar.add(Calendar.DATE, 1);
                                        String dateMillis = DateUtils.getInstance().getDateFromMillis(fromCalendar.getTimeInMillis(), AppConstants.DATE_FORMAT_YYYY_MM_DD);
                                        dateFromMillis = dateMillis;
                                        stepItemEmpty = new FitBitStepsItem();
                                        stepItemEmpty.setDateTime(dateMillis);
                                        stepItemEmpty.setCalory(0);
                                        stepItemEmpty.setValue("0");
                                        System.out.println("steps dateMillis====" + dateMillis);
                                        hashMap.put(dateMillis, stepItemEmpty);
                                    }
                                }
                                ArrayList<StepsBean> stepsBeanList = new ArrayList<>();

                                for (Map.Entry<String, FitBitStepsItem> entry : hashMap.entrySet()) {
                                    String key = entry.getKey();
                                    FitBitStepsItem fitBitStepsItem = entry.getValue();

                                    String date = DateUtils.getInstance().formatDateStep(AppConstants.DATE_FORMAT_YYYY_MM_DD, AppConstants.DATE_FORMAT_MM_DD_YYYY_HHMM_FORWARD_SLASH, fitBitStepsItem.getDateTime());
                                    String steps = fitBitStepsItem.getValue();
                                    StepsBean stepsBean = new StepsBean();
                                    stepsBean.setSteps(Integer.parseInt(steps));
                                    stepsBean.setStepsDate(date);
                                    stepsBean.setActivityDate(date);
                                    stepsBean.setCalories((int) fitBitStepsItem.getCalory());
                                    stepsBeanList.add(stepsBean);

                                }
                                saveStepsToServer(onStepSync, AppConstants.E_FIT, stepsBeanList, stepsBeanList);
                            } else {
                                Utils.showToast(getActivity(), "An error occurred while syncing your steps to server. Please try to connect your device again.");
                            }
                        } else {
                            Utils.showToast(getActivity(), "An error occurred while syncing your steps to server. Please try to connect your device again.");
                        }
                    } else {
                        Utils.showToast(getActivity(), "An error occurred while syncing your steps to server. Please try to connect your device again.");
                    }
                }
            }

            @Override
            public void onFailure(Call<EFitMonthStepsResponse> call, Throwable t) {
                if (getActivity() != null && isAdded()) {
                    stopAnimation();
                    Utils.showToast(getActivity(), "An error occurred while syncing your steps to server. Please try to connect your device again.");
                    CommonUtils.showAlertDialog(getActivity(), null, 0, getString(R.string.msg_api_failure), getString(R.string.str_ok), true);
                }
            }
        });
    }

    private void changeMonthDate() {
        String date = DateUtils.GetMonthSlot(-1, DateUtils.formatDateStep(AppConstants.DATE_FORMAT_YYYY_MM_DD, AppConstants.DATE_FORMAT_DD_MMM_YYYY, monthDateYMD));
        String[] arrDate = date.split("-");
        monthDateYMD = DateUtils.formatDateStep(AppConstants.DATE_FORMAT_DD_MMM_YYYY, AppConstants.DATE_FORMAT_YYYY_MM_DD, arrDate[0]);
    }

    private void removeProgressLoading() {
        if (mStepsItemList.size() > 0 && mStepsItemList.get(mStepsItemList.size() - 1) == null) {
            mStepsItemList.remove(mStepsItemList.size() - 1);
            mStepsTrackerAdapter.notifyDataSetChanged();
        }
    }

    private void setupAnimation() {
        rotateSync = AnimationUtils.loadAnimation(getActivity(), R.anim.rotator);
        rotateSync.setDuration(1000);
        imgSyncNow.startAnimation(rotateSync);
    }

    private void stopAnimation() {
        if (rotateSync != null)
            rotateSync.cancel();
    }

    public void onBack() {
        getActivity().setResult(Activity.RESULT_OK);
        getActivity().finish();
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.menu_steps_tracker, menu);
        super.onCreateOptionsMenu(menu, inflater);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_settings:
                Utils.replaceFragment(getFragmentManager(), StepTrackerSettingFragment.newInstance(), StepTrackerSettingFragment.class.getSimpleName(), true, R.id.fragmentContainer);
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        stopAnimation();

        //.disconnectServiceHealthStore();
        handler.removeCallbacks(runnableGetDeviceSteps);
        handler.removeCallbacks(runnable);
        isFromSyncNowButtonPressed = false;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        stopAnimation();
     /*   if (samsungHealthClient != null)
            samsungHealthClient.disconnectServiceHealthStore();*/
        isFromSyncNowButtonPressed = false;
        handler.removeCallbacks(runnableGetDeviceSteps);
        handler.removeCallbacks(runnable);
    }
}
