package com.twc.dailylog.fragments;

import android.app.TimePickerDialog;
import android.database.Cursor;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.MotionEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.TimePicker;


import com.twc.dailylog.MealActivity;
import com.twc.dailylog.R;
import com.twc.dailylog.R2;
import com.twc.dailylog.dialog.TimePickerFragment;
import com.twc.dailylog.interfaces.OnTrackerReadingSave;
import com.twc.dailylog.model.requestbody.SaveExerciseBody;
import com.twc.dailylog.model.response.SaveExerciseResponse;
import com.twc.dailylog.rest.RestClient;
import com.twc.dailylog.utils.DailyLogConfig;
import com.twc.dailylog.utils.DateFactory;
import com.twc.dailylog.utils.DialogFactory;
import com.twc.dailylog.utils.NetworkFactory;
import com.twc.dailylog.utils.Utils;
import com.twc.greendaolib.ExerciseItem;
import com.twc.greendaolib.ExerciseItemDao;
import com.twc.greendaolib.GreenDaoApp;

import butterknife.BindView;
import butterknife.OnClick;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by Manish Jain on 7/5/2016.
 */
public class TrackActivityFragment extends BaseFragment {

    @BindView(R2.id.evTrackName)
    TextView evTrackName;
    @BindView(R2.id.etTimeQuantity)
    EditText etTimeQuantity;
    @BindView(R2.id.evTimeMinits)
    TextView evTimeMinits;
    @BindView(R2.id.etTime)
    EditText etTime;
    @BindView(R2.id.tvCalories)
    TextView tvCalories;
    @BindView(R2.id.tvAddLog)
    TextView tvAddLog;
    @BindView(R2.id.rootView)
    LinearLayout rootView;
    @BindView(R2.id.viewScroll)
    ScrollView viewScroll;


    private int id = 0;
    private String name;
    private int duration;
    private Double caloriesBurnedIn1MIn;
    private Double caloriesBurned;

    private String time;
    private String date;
    private ExerciseItemDao exerciseitemDao;
    private OnTrackerReadingSave onTrackerReadingSave;


    public static TrackActivityFragment newInstance(Bundle bundle) {
        TrackActivityFragment fragment = new TrackActivityFragment();
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        if (getArguments() != null) {
            id = getArguments().getInt("ID");
            name = getArguments().getString("Name");
            duration = getArguments().getInt("Duration");
            caloriesBurnedIn1MIn = getArguments().getDouble("CaloriesBurnedIn1Min");
            String redirectFrom = getArguments().getString("redirectFrom");
           // time = getArguments().getString("Time");
            //date=getArguments().getString("Date",WellnessCornerApp.getPreferenceManager().getTrackDate());
           // date = getArguments().getString("Date", WellnessCornerApp.getInstance().getTrackDate());
        }
        exerciseitemDao = GreenDaoApp.getInstance(getActivity()).getDaoSession(getActivity()).getExerciseItemDao();
    }

    @Override
    public void onResume() {
        super.onResume();
        ((MealActivity) getActivity()).showHomeAsUpEnableToolbar();
        ((MealActivity) getActivity()).setToolBarTitle("Track Activity");
    }

    @Override
    public int getFragmentLayout() {
        return R.layout.fragment_trackactivity;
    }

    @Override
    public void onFragmentReady() {

            date=DateFactory.getInstance().getTodayDate("MM/dd/yyyy");
        time = DateFactory.getInstance().getCurrentTime("hh:mm aa");

        evTrackName.setText(name);
        etTimeQuantity.setText(duration + "");
        etTime.setText(time);
        caloriesBurned = 0.0;

        duration = Integer.parseInt(etTimeQuantity.getText().toString());
        caloriesBurned = caloriesBurnedIn1MIn * duration;
        tvCalories.setText(Math.round(caloriesBurned) + "");
        etTimeQuantity.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                caloriesBurned = 0.0;
                String durationStr = etTimeQuantity.getText().toString();
                if (durationStr != null && durationStr.trim().length() > 0) {

                    try {
                        duration = Integer.parseInt(etTimeQuantity.getText().toString());
                        caloriesBurned = 0.0;
                        caloriesBurned = caloriesBurnedIn1MIn * duration;
                        tvCalories.setText(Math.round(caloriesBurned) + "");
                        //  Utils.showToast(getActivity(), "..." + CaloriesBurned);
                    } catch (NumberFormatException e) {
                        etTimeQuantity.setError(getString(R.string.duration_error));
                        e.printStackTrace();
                    }
                } else
                    tvCalories.setText(Math.round(caloriesBurned) + "");
            }

            @Override
            public void afterTextChanged(Editable s) {


            }
        });

        viewScroll.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                hideKeyBoard(v);
                return false;
            }
        });

    }

    private void hideKeyBoard(View v) {
        Utils.hideSoftKeyboard(getActivity());
    }

    @OnClick(R2.id.etTime)
    public void timeDialog() {

        String TIME_FORMAT = "hh:mm a";
        String time24format = DateFactory.getInstance().formatTime(TIME_FORMAT, "HH:mm", etTime.getText().toString());
        String[] timeSplit = time24format.split(":");

        TimePickerFragment timePicker = new TimePickerFragment();
        Bundle bundle = new Bundle();
        bundle.putInt("hour", Integer.parseInt(timeSplit[0]));
        bundle.putInt("minute", Integer.parseInt(timeSplit[1]));
        bundle.putBoolean("is24hrsFormat", false);
        timePicker.setArguments(bundle);
        timePicker.setCallBack(new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                String AM_PM = " AM";
                String mm_precede = "";
                if (hourOfDay >= 12) {
                    AM_PM = " PM";
                    if (hourOfDay >= 13 && hourOfDay < 24) {
                        hourOfDay -= 12;
                    } else {
                        hourOfDay = 12;
                    }
                } else if (hourOfDay == 0) {
                    hourOfDay = 12;
                }
                if (minute < 10) {
                    mm_precede = "0";
                }
                etTime.setText(hourOfDay + ":" + mm_precede + minute + AM_PM);
            }
        });
        timePicker.show(getFragmentManager(), "dialog");

    }

    private boolean validation() {
        boolean isValid = true;
        if (etTimeQuantity.getText().toString().trim().equals("")) {
            etTimeQuantity.setError(getString(R.string.enter_duration_error));
            isValid = false;
        } else {
            int durationTime = Integer.parseInt(etTimeQuantity.getText().toString());
            if (durationTime <= 0) {
                etTimeQuantity.setError(getString(R.string.duration_error));
                isValid = false;
            }
        }
        return isValid;
    }

    @OnClick(R2.id.tvAddLog)
    public void addLog() {
        if (validation())
            saveCalorieBurnoutApiCall();
    }

    private void saveCalorieBurnoutApiCall() {
        if (NetworkFactory.getInstance().isNetworkAvailable(getActivity())) {

            String selectTime = DateFactory.getInstance().formatTime("hh:mm a", "HH:mm:ss", etTime.getText().toString().trim());
            String dateTime = date + " " + selectTime;

            SaveExerciseBody saveExerciseBody = new SaveExerciseBody();
            saveExerciseBody.setActivityID(id);
            saveExerciseBody.setActivityMemberID(Integer.parseInt(DailyLogConfig.dailyLogUser.getUserID()));
            saveExerciseBody.setActivityName(name);
            saveExerciseBody.setActivityDate(dateTime);
            saveExerciseBody.setActivityCalorie(caloriesBurned);
            saveExerciseBody.setActivityDuration(duration);

            /**---Insert data into local db---*/
            final ExerciseItem objExercise = new ExerciseItem();

            objExercise.setActivity(name);
            objExercise.setActivityDuration(duration);
            objExercise.setCaloriesBurnedIn1MIn("" + caloriesBurnedIn1MIn);

            objExercise.setDateTime(DateFactory.getInstance().formatDate("MM/dd/yyyy", "ddMMyyyy", date));

            objExercise.setCaloriesBurned("" + caloriesBurned);

            RestClient restClient = new RestClient(getActivity(), DailyLogConfig.BASE_URL, DailyLogConfig.DEBUG);
            restClient.getDailyLogService().getSaveExercise(saveExerciseBody).enqueue(new Callback<SaveExerciseResponse>() {
                @Override
                public void onResponse(Call<SaveExerciseResponse> call, Response<SaveExerciseResponse> response) {
                    if (isAdded() && getActivity() != null) {

                        if (response != null && response.body() != null) {
                            if (response.body().getStatus() == 0) {
                                objExercise.setIsDeleted(0);
                                objExercise.setIsModified(0);
                                objExercise.setIsUploaded(1);
                                if (id > 0) {
                                    //Update data in local db
                                    String query = " UPDATE " + ExerciseItemDao.TABLENAME + " SET " +
                                            ExerciseItemDao.Properties.ActivityDuration.columnName + "=" + duration + "," +
                                            ExerciseItemDao.Properties.Activity.columnName + "='" + name + "', " +
                                            ExerciseItemDao.Properties.CaloriesBurned.columnName + "=" + caloriesBurned + " , " +
                                            ExerciseItemDao.Properties.CaloriesBurnedIn1MIn.columnName + "=" + caloriesBurnedIn1MIn + " , " +
                                            ExerciseItemDao.Properties.DateTime.columnName + "='" + DateFactory.getInstance().formatDate("MM/dd/yyyy", "ddMMyyyy", date) + "'," +
                                            ExerciseItemDao.Properties.IsModified.columnName + "= 1" +
                                            " Where " + ExerciseItemDao.Properties.ServerID.columnName + "=" + response.body().getActivityID();

                                    Cursor cursor = GreenDaoApp.getInstance(getActivity()).getDaoSession(getActivity()).getDatabase().rawQuery(query, null);
                                    Utils.printLog("update exercise", cursor.getCount() + "");
                                    Utils.showToast(getActivity(), getString(R.string.activity_updated));

                                } else {
                                    // new record insert
                                    objExercise.setServerID(response.body().getActivityID());
                                    exerciseitemDao.insert(objExercise);
                                    Utils.showToast(getActivity(), getString(R.string.activity_added));

                                } if (onTrackerReadingSave!=null) {
                                    onTrackerReadingSave.onTrackerReadingSuccess();
                                    getFragmentManager().popBackStackImmediate();
                                    getFragmentManager().popBackStackImmediate();
                                }else {
                                    Bundle bundle = new Bundle();
                                    bundle.putString("date", date);
                                    Utils.replaceFragmentTopDown(getFragmentManager(), DailyLogFragment.newInstance(bundle), DailyLogFragment.class.getSimpleName(), true, R.id.fragmentContainerMeal);
                                }

                                //DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, "Success staus 0", getString(R.string.str_ok), false);
                            } else if (response.body().getStatus() == -1) {
                                DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_response_failure), getString(R.string.str_ok), false);
                                // Toast.makeText(getActivity(), getString(R.string.msg_api_response_failure), Toast.LENGTH_SHORT).show();
                            }
                        } else
                            DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_response_null), getString(R.string.str_ok), false);
                        // Toast.makeText(getActivity(), getString(R.string.msg_api_response_null), Toast.LENGTH_SHORT).show();
                    }
                }

                @Override
                public void onFailure(Call<SaveExerciseResponse> call, Throwable t) {
                    if (isAdded() && getActivity() != null) {

                        DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_failure), getString(R.string.str_ok), false);
                        // Toast.makeText(getActivity(), getString(R.string.msg_api_failure), Toast.LENGTH_SHORT).show();
                    }
                }
            });
        } else {
            Utils.showSnackBarMessage(rootView, getString(R.string.internet_not_available));
        }
    }

    public void setTrackerReadingCallback(OnTrackerReadingSave onTrackerReadingSave) {
        this.onTrackerReadingSave = onTrackerReadingSave;
    }

}
