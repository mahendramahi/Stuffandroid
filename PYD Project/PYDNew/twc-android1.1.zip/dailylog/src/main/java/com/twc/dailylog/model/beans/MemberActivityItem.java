package com.twc.dailylog.model.beans;

/**
 * Created by PankajS on 8/5/2016.
 */
public class MemberActivityItem
{
    private int activityMemberID;
    private int activityID;
    private String activityName;
    private int activityDuration;
    private double activityCalorie;
    private double totalCal;
    private String activityDate;
    private String activityTime;
    private double calories;

    public int getActivityMemberID() {
        return activityMemberID;
    }

    public void setActivityMemberID(int activityMemberID) {
        this.activityMemberID = activityMemberID;
    }

    public int getActivityID() {
        return activityID;
    }

    public void setActivityID(int activityID) {
        this.activityID = activityID;
    }

    public String getActivityName() {
        return activityName;
    }

    public void setActivityName(String activityName) {
        this.activityName = activityName;
    }

    public int getActivityDuration() {
        return activityDuration;
    }

    public void setActivityDuration(int activityDuration) {
        this.activityDuration = activityDuration;
    }

    public double getActivityCalorie() {
        return activityCalorie;
    }

    public void setActivityCalorie(double activityCalorie) {
        this.activityCalorie = activityCalorie;
    }

    public double getTotalCal() {
        return totalCal;
    }

    public void setTotalCal(double totalCal) {
        this.totalCal = totalCal;
    }

    public String getActivityDate() {
        return activityDate;
    }

    public void setActivityDate(String activityDate) {
        this.activityDate = activityDate;
    }

    public String getActivityTime() {
        return activityTime;
    }

    public void setActivityTime(String activityTime) {
        this.activityTime = activityTime;
    }

    public double getCalories() {
        return calories;
    }

    public void setCalories(double Calories) {
        this.calories = Calories;
    }
}


