package com.truworth.wellnesscorner.model;

import java.util.List;

public class ShareExerciseBean {
        private String date;
        private List<ExerciseData> exerciseData;

        public String getDate() {
            return date;
        }

        public void setDate(String date) {
            this.date = date;
        }

        public List<ExerciseData> getExerciseData() {
            return exerciseData;
        }

        public void setExerciseData(List<ExerciseData> exerciseData) {
            this.exerciseData = exerciseData;
        }
}
