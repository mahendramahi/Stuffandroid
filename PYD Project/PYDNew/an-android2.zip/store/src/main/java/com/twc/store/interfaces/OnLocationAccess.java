package com.twc.store.interfaces;

/**
 * Created by GurvinderS on 2/5/2018.
 */

public interface OnLocationAccess {
    void onAccess();
}
