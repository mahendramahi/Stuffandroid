package com.truworth.wellnesscorner.ui.registration;

import android.app.Activity;
import android.app.FragmentManager;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.app.AppCompatDelegate;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;

import com.truworth.wellnesscorner.R;
import com.truworth.wellnesscorner.TheWellnessCornerApp;
import com.truworth.wellnesscorner.data.SharedPreferenceHelper;
import com.truworth.wellnesscorner.ui.mobileverification.OTPFragment;
import com.truworth.wellnesscorner.ui.registration.registrationstepsixth.HealthGoalFragment;
import com.truworth.wellnesscorner.ui.mobileverification.LoginWithMobileNumberFragment;
import com.truworth.wellnesscorner.ui.mobileverification.MobileNumberRedirectionType;
import com.truworth.wellnesscorner.ui.registration.registrationstepfifth.EditProfileFragment;
import com.truworth.wellnesscorner.ui.registration.registrationstepfirst.RegistrationPersonalFragment;
import com.truworth.wellnesscorner.ui.registration.registrationstepfourth.LocationDetectFragment;
import com.truworth.wellnesscorner.ui.registration.registrationstepthird.HeightWeightFragment;
import com.truworth.wellnesscorner.utils.CommonUtils;
import com.twc.remindermodule.fragments.RecommendedHealthyHabitsFragment;

import javax.inject.Inject;

import static com.truworth.wellnesscorner.constants.RegistrationSteps.EDIT_PROFILE;
import static com.truworth.wellnesscorner.constants.RegistrationSteps.HEALTH_GOALS;
import static com.truworth.wellnesscorner.constants.RegistrationSteps.HEIGHT_WEIGHT_BMI;
import static com.truworth.wellnesscorner.constants.RegistrationSteps.LOCATION_ADDRESS;
import static com.truworth.wellnesscorner.constants.RegistrationSteps.MOBILE_NUMBER;
import static com.truworth.wellnesscorner.constants.RegistrationSteps.PROFILE;

public class RegistrationActivity extends AppCompatActivity {
    public static final String EMAIL = "email";
    Toolbar toolbar;
    @Inject
    SharedPreferenceHelper prefHelper;
    String emailId;

    static {
        AppCompatDelegate.setCompatVectorFromResourcesEnabled(true);
    }

    public static void startRegistration(Activity activity, String emailId) {
        Intent intent = new Intent(activity, RegistrationActivity.class);
        intent.putExtra(EMAIL, emailId);
        activity.startActivity(intent);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);
        TheWellnessCornerApp.getApp().component().inject(this);
        toolbar = findViewById(R.id.toolbarLogin);
        setupToolbar(toolbar);
        getIntentData();
        addProfileFragment();
    }

    public Toolbar getToolbar() {
        return toolbar;
    }

    private void setupToolbar(Toolbar toolbar) {
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
            getSupportActionBar().setDisplayShowTitleEnabled(false);
        }
    }

    void getIntentData() {
        emailId = getIntent().getStringExtra(EMAIL);
    }

    private void addProfileFragment() {
        int stepNumber = prefHelper.getProfileStepNumber();
        Fragment fragment = getRegisterFragment(stepNumber);
        getSupportFragmentManager()
                .beginTransaction().addToBackStack(""+stepNumber)
                .add(R.id.registerContainer, fragment, String.valueOf(stepNumber))
                .commit();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

    public Fragment getRegisterFragment(int stepNo) {
        switch (stepNo) {
            case PROFILE:
                return RegistrationPersonalFragment.newInstance(emailId);
            case MOBILE_NUMBER:
                return LoginWithMobileNumberFragment.newInstance(emailId, MobileNumberRedirectionType.FROM_REGISTRATION);
            case HEIGHT_WEIGHT_BMI:
                return HeightWeightFragment.newInstance();
            case LOCATION_ADDRESS:
                return LocationDetectFragment.newInstance();
            case EDIT_PROFILE:
                return EditProfileFragment.newInstance();
            case HEALTH_GOALS:
                return new HealthGoalFragment();
        }
        return null;
    }

    @Override
    public void onBackPressed() {
            CommonUtils.showAlertDialog(RegistrationActivity.this, getString(R.string.app_name), 0, getString(R.string.msg_registration_back), "OK", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {

                    dialogInterface.dismiss();
                    if (getSupportFragmentManager().getBackStackEntryCount() <= 1) {
                        finish();
                    }
                    else {
                            RegistrationActivity.super.onBackPressed();
                    }
                }
            }, "Cancel", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {

                    dialogInterface.dismiss();
                }
            }, false);
    }

}
