package com.truworth.wellnesscorner.repo;

import com.truworth.wellnesscorner.network.ApiServices;
import com.truworth.wellnesscorner.repo.model.request.SaveMemberHealthGoalsRequest;
import com.truworth.wellnesscorner.repo.model.request.SaveProfileRequest;
import com.truworth.wellnesscorner.repo.model.request.BMIRequest;
import com.truworth.wellnesscorner.repo.model.request.ScreenNameRequest;
import com.truworth.wellnesscorner.repo.model.response.BMIResponse;
import com.truworth.wellnesscorner.repo.model.response.HealthGoalResponse;
import com.truworth.wellnesscorner.repo.model.response.SaveMemberHealthGoalsResponse;
import com.truworth.wellnesscorner.repo.model.response.SaveProfileResponse;
import com.truworth.wellnesscorner.repo.model.response.ScreenNameResponse;

import javax.inject.Inject;
import javax.inject.Singleton;

import io.reactivex.Observable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.schedulers.Schedulers;

/**
 * Created by PalakC on 4/5/2018.
 */
@Singleton
public class RegistrationRepository {
    private final ApiServices apiService;

    @Inject
    public RegistrationRepository(ApiServices apiService) {

        this.apiService = apiService;
    }

    public Observable<HealthGoalResponse> healthGoal() {
        return apiService.getHealthGoal()
                .subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread());
    }

    public Observable<SaveProfileResponse> saveProfile(SaveProfileRequest request) {
        return apiService.saveMemberProfile(request).subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread());
    }


    public Observable<ScreenNameResponse> checkScreenName(ScreenNameRequest request) {
        return apiService.checkScreenName(request).subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread());
    }

    public Observable<BMIResponse> getBMIAndIBW(BMIRequest bmiRequest) {
        return apiService.getMemberBMIAndIBW(bmiRequest)
                .subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread());
    }

    public Observable<SaveMemberHealthGoalsResponse> saveGoals(SaveMemberHealthGoalsRequest goalsRequest) {
        return apiService.saveMemberHealthGoals(goalsRequest)
                .subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread());
    }

}
