package com.truworth.wellnesscorner.ui.mainapp.circledetail.challenges;

import android.databinding.DataBindingUtil;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import com.truworth.wellnesscorner.R;
import com.truworth.wellnesscorner.databinding.RowPreviousChallengesBinding;
import com.truworth.wellnesscorner.model.PreviousChallengesBean;

import java.util.List;

public class PreviousChallengeAdapter extends RecyclerView.Adapter<PreviousChallengeAdapter.ViewHolder> {
    List<PreviousChallengesBean> previousChallengeList;
    String circleIdentity;

    public PreviousChallengeAdapter(List<PreviousChallengesBean> previousChallengeList, String circleIdentity) {
        this.previousChallengeList = previousChallengeList;
        this.circleIdentity = circleIdentity;
    }


    @NonNull
    @Override
    public PreviousChallengeAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        RowPreviousChallengesBinding binding = DataBindingUtil.inflate(LayoutInflater.from(parent.getContext()), R.layout.row_previous_challenges, parent, false);
        return new PreviousChallengeAdapter.ViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull PreviousChallengeAdapter.ViewHolder holder, int position) {
        holder.bind(previousChallengeList.get(position));
    }

    @Override
    public int getItemCount() {
        return previousChallengeList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements PreviousChallengeItemViewModel.MyChallengeListener {
        private RowPreviousChallengesBinding mBinding;

        public ViewHolder(RowPreviousChallengesBinding binding) {
            super(binding.getRoot());
            mBinding = binding;
        }

        public void bind(@NonNull PreviousChallengesBean previousChallengesBean) {

            PreviousChallengeItemViewModel viewModel = new PreviousChallengeItemViewModel(previousChallengesBean, this, circleIdentity);

            mBinding.setViewModel(viewModel);
            mBinding.executePendingBindings();
        }

        @Override
        public void onItemClick(PreviousChallengesBean previousChallenge, String postMapId) {
            int challengeTypeId = previousChallengeList.get(getAdapterPosition()).getChallengeTypeId();

            ChallengeDetailActivity.start(itemView.getContext(), previousChallengeList.get(getAdapterPosition()).getChallengeIdentity(), circleIdentity, challengeTypeId);
            //}
        }
    }


}

