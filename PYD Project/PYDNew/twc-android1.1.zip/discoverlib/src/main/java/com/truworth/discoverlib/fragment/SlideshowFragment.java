package com.truworth.discoverlib.fragment;


import android.app.ProgressDialog;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Html;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RatingBar;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.ViewFlipper;

import com.bumptech.glide.Glide;
import com.facebook.CallbackManager;
import com.truworth.discoverlib.DiscoverActivity;
import com.truworth.discoverlib.R;
import com.truworth.discoverlib.R2;
import com.truworth.discoverlib.adapter.RelatedSlideshowAdapter;
import com.truworth.discoverlib.interfaces.OnFacebookShare;
import com.truworth.discoverlib.model.AddToFavoriteBody;
import com.truworth.discoverlib.model.AddToFavouritResponse;
import com.truworth.discoverlib.model.RateDiscoverBody;
import com.truworth.discoverlib.model.RateDiscoverResponse;
import com.truworth.discoverlib.model.RemoveFromFavoriteBody;
import com.truworth.discoverlib.model.RemoveFromFavouriteResponse;
import com.truworth.discoverlib.model.SharedConfirmationBody;
import com.truworth.discoverlib.model.SharedConfirmationResponse;
import com.truworth.discoverlib.model.SlideShowRequestBody;
import com.truworth.discoverlib.model.SlideshowResponse;
import com.truworth.discoverlib.model.SlideshowResponse.DataBean.DetailsBean;
import com.truworth.discoverlib.model.SlideshowResponse.DataBean.RelatedSlideBean;
import com.truworth.discoverlib.rest.RestClient;
import com.truworth.discoverlib.utils.Constant;
import com.truworth.discoverlib.utils.CustomTextView;
import com.truworth.discoverlib.utils.DateFactory;
import com.truworth.discoverlib.utils.DialogFactory;
import com.truworth.discoverlib.utils.DiscoverConfig;
import com.truworth.discoverlib.utils.FacebookShareUtil;
import com.truworth.discoverlib.utils.NetworkFactory;
import com.truworth.discoverlib.utils.Utils;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class SlideshowFragment extends BaseFragment implements Callback<SlideshowResponse>, RatingBar.OnRatingBarChangeListener, OnFacebookShare {


    @BindView(R2.id.seekBar)
    SeekBar mSeekBar;
    @BindView(R2.id.llSeekBar)
    LinearLayout llSeekBar;
    @BindView(R2.id.tvArticleTitle)
    CustomTextView tvArticleTitle;
    @BindView(R2.id.tvArticleBy)
    CustomTextView tvArticleBy;
    @BindView(R2.id.tvAddedTime)
    CustomTextView tvAddedTime;
    @BindView(R2.id.rbArticleRating)
    RatingBar rbArticleRating;
    @BindView(R2.id.ivSlideImage)
    ImageView ivSlideImage;
    @BindView(R2.id.tvDescription)
    CustomTextView tvDescription;
    @BindView(R2.id.tvStartSlideshow)
    CustomTextView tvStartSlideshow;
    @BindView(R2.id.tvSlideshowNext)
    CustomTextView tvSlideshowNext;
    @BindView(R2.id.tvSlideshowPrev)
    CustomTextView tvSlideshowPrev;
    @BindView(R2.id.ivFavorite)
    ImageView ivFavorite;
    @BindView(R2.id.progressBar)
    ProgressBar progressBar;
    @BindView(R2.id.rbUserRating)
    RatingBar rbUserRating;
    @BindView(R2.id.rvRelatedSlideshow)
    RecyclerView rvRelatedSlideshow;
    @BindView(R2.id.tvNoRelatedArticles)
    CustomTextView tvNoRelatedArticles;
    @BindView(R2.id.tvSlidNumbers)
    CustomTextView tvSlidNumbers;
    @BindView(R2.id.flipperSlideshow)
    ViewFlipper flipperSlideshow;
    @BindView(R2.id.tvSlideTitle)
    CustomTextView tvSlideTitle;
    @BindView(R2.id.slideRootLayout)
    RelativeLayout slideRootLayout;
    @BindView(R2.id.rootLayout)
    View rootLayout;

    private int slideshowId;
    private List<DetailsBean> slideshowDetailList;
    private boolean isSlideshowFavourite;
    private ArrayList<RelatedSlideBean> relatedSlideshowList;
    private RelatedSlideshowAdapter mRelatedSlideshowAdapter;
    private SlideshowResponse.DataBean slideData;
    private Resources resources;
    private int totalSlide;
    private ProgressDialog progressDialog;
    private CallbackManager shareDialogCallbackManager;
    private String slideshowUrl;

    public static SlideshowFragment newInstance(Bundle bundle) {
        SlideshowFragment slideshowFragment = new SlideshowFragment();
        slideshowFragment.setArguments(bundle);
        return slideshowFragment;
    }

    @Override
    public int getFragmentLayout() {
        return R.layout.fragment_slideshow;
    }

    @Override
    public void onFragmentReady() {
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getActivity());
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        rvRelatedSlideshow.setLayoutManager(linearLayoutManager);
        rbUserRating.setOnRatingBarChangeListener(this);
        rvRelatedSlideshow.setHasFixedSize(true);
        if (slideData == null && mRelatedSlideshowAdapter.getItemCount() <= 0) {
            rvRelatedSlideshow.setAdapter(mRelatedSlideshowAdapter);
            if (NetworkFactory.getInstance().isNetworkAvailable(getActivity())) {
                getSlideshowDetail();
            } else {
                Utils.showSnackBarMessage(rootLayout, getString(R.string.internet_not_available));
            }
        } else {
            rvRelatedSlideshow.setAdapter(mRelatedSlideshowAdapter);
            mRelatedSlideshowAdapter.notifyDataSetChanged();
            setUiData();
        }
        setZoomChangeListener();
    }

    private void setZoomChangeListener() {
        mSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {


            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                View view = flipperSlideshow.getCurrentView();

                TextView tvArticleTitle = view.findViewById(R.id.tvSlideTitle);
                TextView tvDescription = view.findViewById(R.id.tvDescription);

                tvDescription.setTextSize(progress + 14);
                tvArticleTitle.setTextSize(progress + 16);

            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        });

    }

    private void getSlideshowDetail() {
        slideRootLayout.setVisibility(View.GONE);
        progressBar.setVisibility(View.VISIBLE);
        tvNoRelatedArticles.setVisibility(View.GONE);
        SlideShowRequestBody slideShowRequestBody = new SlideShowRequestBody();
        slideShowRequestBody.setSlideID(String.valueOf(slideshowId));
        slideShowRequestBody.setMemberid(Integer.parseInt(DiscoverConfig.discoverUser.getUserID()));
        RestClient restClient = new RestClient(getActivity(), DiscoverConfig.BASE_URL, DiscoverConfig.DEBUG);
        restClient.getDiscoverService().getSlideshowDetails(slideShowRequestBody).enqueue(this);
    }

    private void setDefaultTextSize() {
        View view = flipperSlideshow.getCurrentView();
        TextView tvDescription = view.findViewById(R.id.tvDescription);
        tvDescription.setTextSize(14);
    }

    private void setCurrentPageTextSize() {
        View view = flipperSlideshow.getCurrentView();
        TextView tvDescription = view.findViewById(R.id.tvDescription);
        tvDescription.setTextSize(mSeekBar.getProgress() + 14);
    }

    private void setSlideshowVisibility(boolean visible) {
        if (visible) {
            tvStartSlideshow.setVisibility(View.GONE);
            tvSlideshowPrev.setVisibility(View.VISIBLE);
            tvSlideshowNext.setVisibility(View.VISIBLE);
            tvSlidNumbers.setVisibility(View.VISIBLE);
            tvSlideTitle.setVisibility(View.VISIBLE);
            addSlides();
        } else {
            tvStartSlideshow.setVisibility(View.VISIBLE);
            tvSlideshowPrev.setVisibility(View.GONE);
            tvSlideshowNext.setVisibility(View.GONE);
            tvSlidNumbers.setVisibility(View.GONE);
            tvSlideTitle.setVisibility(View.GONE);
            removeSlides();
        }
    }

    private void addToFavorite() {
        progressDialog = new ProgressDialog(getActivity());
        progressDialog.setMessage(getString(R.string.msg_please_wait));
        progressDialog.show();

        AddToFavoriteBody addToFavoriteBody = new AddToFavoriteBody();
        addToFavoriteBody.setID(slideshowId);
        addToFavoriteBody.setType(Constant.RATING_TYPE_SLIDESHOW);
        addToFavoriteBody.setMemberID(Integer.parseInt(DiscoverConfig.discoverUser.getUserID()));
        RestClient restClient = new RestClient(getActivity(), DiscoverConfig.BASE_URL, DiscoverConfig.DEBUG);
        restClient.getDiscoverService().addToFavourite(addToFavoriteBody).enqueue(new Callback<AddToFavouritResponse>() {
            @Override
            public void onResponse(@NonNull Call<AddToFavouritResponse> call, Response<AddToFavouritResponse> response) {
                if (isAdded() && getActivity() != null) {
                    if (progressDialog.isShowing()) {
                        progressDialog.dismiss();
                    }
                    if (response.body() != null) {

                        if (response.body().getStatus() == 0) {
                            ivFavorite.setImageResource(R.drawable.ic_remove_from_fav);
                            isSlideshowFavourite = true;
                            slideData.setIsFavourites(true);
                        } else {
                            DialogFactory.getInstance().showAlertDialog(getActivity(), null, 0, getString(R.string.msg_api_response_failure), getString(R.string.str_ok), true);
                        }

                    } else {
                        DialogFactory.getInstance().showAlertDialog(getActivity(), null, 0, getString(R.string.msg_api_response_null), getString(R.string.str_ok), true);
                    }
                }
            }

            @Override
            public void onFailure(Call<AddToFavouritResponse> call, Throwable t) {
                if (isAdded() && getActivity() != null) {
                    if (progressDialog.isShowing()) {
                        progressDialog.dismiss();
                    }
                    DialogFactory.getInstance().showAlertDialog(getActivity(), null, 0, getString(R.string.msg_api_failure), getString(R.string.str_ok), true);
                }
            }
        });

    }

    private void callRemoveFromFavorite() {
        progressDialog = new ProgressDialog(getActivity());
        progressDialog.setMessage(getString(R.string.msg_please_wait));
        progressDialog.show();

        RemoveFromFavoriteBody removeFromFavoriteBody = new RemoveFromFavoriteBody();
        removeFromFavoriteBody.setID(slideshowId);
        removeFromFavoriteBody.setType(Constant.RATING_TYPE_SLIDESHOW);
        removeFromFavoriteBody.setMemberID(Integer.parseInt(DiscoverConfig.discoverUser.getUserID()));
        RestClient restClient = new RestClient(getActivity(), DiscoverConfig.BASE_URL, DiscoverConfig.DEBUG);
        restClient.getDiscoverService().removeFromFavourite(removeFromFavoriteBody).enqueue(new Callback<RemoveFromFavouriteResponse>() {
            @Override
            public void onResponse(Call<RemoveFromFavouriteResponse> call, Response<RemoveFromFavouriteResponse> response) {
                if (isAdded() && getActivity() != null) {
                    if (progressDialog.isShowing()) {
                        progressDialog.dismiss();
                    }

                    if (response != null && response.body() != null) {
                        if (response.body().getStatus() == 0) {
                            ivFavorite.setImageResource(R.drawable.ic_add_to_favorites);
                            isSlideshowFavourite = false;
                            slideData.setIsFavourites(false);
                        } else {
                            DialogFactory.getInstance().showAlertDialog(getActivity(), null, 0, getString(R.string.msg_api_response_failure), getString(R.string.str_ok), true);
                        }

                    } else {
                        DialogFactory.getInstance().showAlertDialog(getActivity(), null, 0, getString(R.string.msg_api_response_null), getString(R.string.str_ok), true);
                    }
                }
            }

            @Override
            public void onFailure(Call<RemoveFromFavouriteResponse> call, Throwable t) {
                if (isAdded() && getActivity() != null) {
                    if (progressDialog.isShowing()) {
                        progressDialog.dismiss();
                    }
                    DialogFactory.getInstance().showAlertDialog(getActivity(), null, 0, getString(R.string.msg_api_failure), getString(R.string.str_ok), true);
                }
            }
        });

    }

    private void showSlideOrder(int index) {
        //        int slideOrder = slideshowDetailList.get(index).getSlideOrder();
        String slideNumber = resources.getString(R.string.slideOrder, index, totalSlide);
        tvSlidNumbers.setText(slideNumber);
    }

    @SuppressWarnings("deprecation")
    private void addSlides() {
        for (int index = 0; index < slideshowDetailList.size(); index++) {
            View view = View.inflate(getActivity(), R.layout.layout_slideshow_flipper, null);
            ImageView ivSlideImage = view.findViewById(R.id.ivSlideImage);
            TextView tvDescription = view.findViewById(R.id.tvDescription);
            TextView tvSlideTitle = view.findViewById(R.id.tvSlideTitle);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                tvDescription.setText(Html.fromHtml(slideshowDetailList.get(index).getSlideText(), Html.FROM_HTML_MODE_LEGACY));
            } else {
                tvDescription.setText(Html.fromHtml(slideshowDetailList.get(index).getSlideText()));
            }

            tvSlideTitle.setText(slideshowDetailList.get(index).getSubHeading());
            Glide.with(getActivity()).load(slideshowDetailList.get(index).getImage()).into(ivSlideImage);
            flipperSlideshow.addView(view);
        }
    }

    private void removeSlides() {
        flipperSlideshow.removeViews(1, flipperSlideshow.getChildCount() - 1);
    }

    @Override
    public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
        int i = ratingBar.getId();
        if (i == R.id.rbUserRating) {
            if (fromUser) {
                if (NetworkFactory.getInstance().isNetworkAvailable(getActivity())) {
                    rateDiscover(rating);
                } else {
                    Utils.showSnackBarMessage(rootLayout, getString(R.string.internet_not_available));
                }
            }

        }
    }

    private void rateDiscover(float rating) {
        RateDiscoverBody rateDiscoverBody = new RateDiscoverBody();
        rateDiscoverBody.setMemberID(Integer.parseInt(DiscoverConfig.discoverUser.getUserID()));
        rateDiscoverBody.setID(slideshowId);
        rateDiscoverBody.setRating((int) rating);
        rateDiscoverBody.setType(Constant.RATING_TYPE_SLIDESHOW);
        RestClient restClient = new RestClient(getActivity(), DiscoverConfig.BASE_URL, DiscoverConfig.DEBUG);

        Call<RateDiscoverResponse> call = restClient.getDiscoverService().rateDiscover(rateDiscoverBody);
        call.enqueue(new Callback<RateDiscoverResponse>() {
            @Override
            public void onResponse(Call<RateDiscoverResponse> call, Response<RateDiscoverResponse> response) {
                if (isAdded() && getActivity() != null) {
                    if (response != null && response.body() != null) {
                        if (response.body().getStatus() == 0) {
                        } else if (response.body().getStatus() == -1) {
                            DialogFactory.getInstance().showAlertDialog(getActivity(), null, 0, getString(R.string.msg_api_response_failure), getString(R.string.str_ok), true);
                        }
                    } else {
                        DialogFactory.getInstance().showAlertDialog(getActivity(), null, 0, getString(R.string.msg_api_response_null), getString(R.string.str_ok), true);
                    }
                }
            }

            @Override
            public void onFailure(Call<RateDiscoverResponse> call, Throwable t) {
                if (isAdded() && getActivity() != null) {
                    DialogFactory.getInstance().showAlertDialog(getActivity(), null, 0, getString(R.string.msg_api_failure), getString(R.string.str_ok), true);
                }
            }
        });

    }

    private void setUiData() {

        slideRootLayout.setVisibility(View.VISIBLE);
        String articleTitle = slideData.getTitle();
        String articleDescription = slideData.getDescription();
        String articleImageUrl = slideData.getImage();

        int articleUserRating = slideData.getMemberRating();
        int articleRating = slideData.getRating();
        slideshowDetailList = slideData.getSlideshowDetail();
        if (slideshowDetailList == null) {
            slideshowDetailList = new ArrayList<>();
        }
        isSlideshowFavourite = slideData.isIsFavourites();
        totalSlide = slideshowDetailList.size();
        Glide.with(getActivity()).load(articleImageUrl).into(ivSlideImage);
        tvArticleTitle.setText(articleTitle);
        tvDescription.setText(articleDescription);
        String articleModifiedDate = slideData.getModifiedOn();
        articleModifiedDate = DateFactory.getInstance().truncateMilliseconds(articleModifiedDate);
        //  String relativeTime = DateFactory.getInstance().getCustomRelativeTime(Constant.SERVER_DATE_FORMAT_WITH_MILLISECONDS, articleModifiedDate);
        String relativeTime = DateFactory.getInstance().timeAgo(DateFactory.getInstance().getMillisFromStringDate(articleModifiedDate, Constant.SERVER_DATE_FORMAT_WITH_MILLISECONDS) / 1000);
        tvAddedTime.setText(relativeTime);
        rbArticleRating.setRating((float) articleRating);
        rbUserRating.setRating((float) articleUserRating);

        ivFavorite.setImageResource(isSlideshowFavourite ? R.drawable.ic_remove_from_fav : R.drawable.ic_add_to_favorites);

        if (slideData.getRelatedSlide() == null && slideData.getRelatedSlide().size() <= 0) {
            tvNoRelatedArticles.setVisibility(View.VISIBLE);
        } else {
            tvNoRelatedArticles.setVisibility(View.GONE);
            rvRelatedSlideshow.setAdapter(mRelatedSlideshowAdapter);
            mRelatedSlideshowAdapter.notifyDataSetChanged();
        }
    }

    @OnClick({R2.id.tvStartSlideshow, R2.id.tvSlideshowNext, R2.id.tvSlideshowPrev, R2.id.ivFavorite})
    public void onClick(View view) {
        int i = view.getId();
        if (i == R.id.tvStartSlideshow) {
            setDefaultTextSize();
            setSlideshowVisibility(true);
            flipperSlideshow.setDisplayedChild(1);
            showSlideOrder(1);
            setCurrentPageTextSize();

        } else if (i == R.id.tvSlideshowNext) {
            setDefaultTextSize();
            flipperSlideshow.setInAnimation(AnimationUtils.loadAnimation(getActivity(), R.anim.slide_in_fade_from_right));
            flipperSlideshow.setOutAnimation(AnimationUtils.loadAnimation(getActivity(), R.anim.slide_out_fade_to_left));

            flipperSlideshow.showNext();
            showSlideOrder(flipperSlideshow.getDisplayedChild());
            if (flipperSlideshow.getDisplayedChild() == flipperSlideshow.getChildCount() - 1) {
                tvSlideshowNext.setVisibility(View.GONE); // Setting visibility of next button on last slide
            }

            setCurrentPageTextSize();


        } else if (i == R.id.tvSlideshowPrev) {
            setDefaultTextSize();

            if (tvSlideshowNext.getVisibility() == View.GONE) {
                tvSlideshowNext.setVisibility(View.VISIBLE);
            }
            if (flipperSlideshow.getDisplayedChild() == 1) {
                flipperSlideshow.setInAnimation(null);
                flipperSlideshow.setOutAnimation(null);
                setSlideshowVisibility(false);
            } else {
                flipperSlideshow.setInAnimation(AnimationUtils.loadAnimation(getActivity(), R.anim.slide_in_fade_from_left));
                flipperSlideshow.setOutAnimation(AnimationUtils.loadAnimation(getActivity(), R.anim.slide_out_fade_to_right));
                flipperSlideshow.showPrevious();
                showSlideOrder(flipperSlideshow.getDisplayedChild());
            }
            setCurrentPageTextSize();

        } else if (i == R.id.ivFavorite) {
            if (isSlideshowFavourite) {
                if (NetworkFactory.getInstance().isNetworkAvailable(getActivity())) {
                    callRemoveFromFavorite();
                } else {
                    Utils.showSnackBarMessage(rootLayout, getString(R.string.internet_not_available));
                }
            } else {
                if (NetworkFactory.getInstance().isNetworkAvailable(getActivity())) {
                    addToFavorite();
                } else {
                    Utils.showSnackBarMessage(rootLayout, getString(R.string.internet_not_available));
                }
            }

        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        shareDialogCallbackManager.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
        Bundle bundle = getArguments();
        slideshowId = bundle.getInt(Constant.BUNDLE_KEY_SLIDESHOW_ID);
        slideshowUrl = bundle.getString(Constant.BUNDLE_KEY_SLIDESHOW_URL);
        relatedSlideshowList = new ArrayList<>();
        mRelatedSlideshowAdapter = new RelatedSlideshowAdapter(getActivity(), relatedSlideshowList);
        resources = getResources();

    }

    @Override
    public void onResponse(Call<SlideshowResponse> call, Response<SlideshowResponse> response) {
        if (isAdded() && getActivity() != null) {
            progressBar.setVisibility(View.GONE);
            if (response != null && response.body() != null) {
                if (response.body().getStatus() == 0) {
                    slideData = response.body().getData();
                    List<RelatedSlideBean> relatedSlides = slideData.getRelatedSlide();
                    relatedSlideshowList.addAll(relatedSlides);
                    setUiData();
                } else if (response.body().getStatus() == -1) {
                    DialogFactory.getInstance().showAlertDialog(getActivity(), null, 0, getString(R.string.msg_api_response_failure), getString(R.string.str_ok), true);
                }

            } else {
                DialogFactory.getInstance().showAlertDialog(getActivity(), null, 0, getString(R.string.msg_api_response_null), getString(R.string.str_ok), true);
            }
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        ((DiscoverActivity) getActivity()).showHomeAsUpEnableToolbar();
        ((DiscoverActivity) getActivity()).setToolBarTitle("");
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        getActivity().getMenuInflater().inflate(R.menu.menu_zoom_text, menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int i = item.getItemId();
        if (i == R.id.zoom) {
            llSeekBar.setVisibility(llSeekBar.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE);
            return true;
        } else if (i == R.id.share) {
            shareDialogCallbackManager = CallbackManager.Factory.create();
            FacebookShareUtil facebookShareUtil = new FacebookShareUtil(this, shareDialogCallbackManager, this);

            try {
                facebookShareUtil.share(slideData.getSlideId(), slideData.getTitle(), slideData.getDescription(), slideshowUrl, slideData.getImage());
            } catch (Exception e) {
                Utils.showToast(getActivity(), "An error occurred while sharing to facebook");
            }

            return true;
        } else {
            return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void onShareSuccess(int itemId, String postId) {
        // Post successfully shared
        Utils.printLog("Facebook", "Shared post ID " + postId);
        SharedConfirmationBody sharedConfirmationBody = new SharedConfirmationBody();
        sharedConfirmationBody.setItemID(itemId);
        sharedConfirmationBody.setItemType("SLIDE");
        sharedConfirmationBody.setMemberID(Integer.parseInt(DiscoverConfig.discoverUser.getUserID()));
        sharedConfirmationBody.setShareThrough("FB");

        RestClient restClient = new RestClient(getActivity(), DiscoverConfig.BASE_URL, DiscoverConfig.DEBUG);
        restClient.getDiscoverService().sharedItemConfirmation(sharedConfirmationBody).enqueue(new Callback<SharedConfirmationResponse>() {
            @Override
            public void onResponse(Call<SharedConfirmationResponse> call, Response<SharedConfirmationResponse> response) {
            }

            @Override
            public void onFailure(Call<SharedConfirmationResponse> call, Throwable t) {

            }
        });

    }

    @Override
    public void onFailure(Call<SlideshowResponse> call, Throwable t) {
        if (isAdded() && getActivity() != null) {
            progressBar.setVisibility(View.GONE);
            DialogFactory.getInstance().showAlertDialog(getActivity(), null, 0, getString(R.string.msg_api_failure), getString(R.string.str_ok), true);
        }
    }

    @Override
    public void onShareError(String error) {
        // Error occurred after showing share dialog
        DialogFactory.getInstance().showAlertDialog(getActivity(), null, 0, error, getString(R.string.str_ok), true);
    }


}
