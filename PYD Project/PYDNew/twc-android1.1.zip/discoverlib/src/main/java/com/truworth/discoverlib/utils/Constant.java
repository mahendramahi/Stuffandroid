package com.truworth.discoverlib.utils;

/**
 * If this code works, it was written by Somesh Kumar  on 09 April, 2018. If not, I don't know who wrote it.
 */
public class Constant {
    /*KEYS FOR DISCOVER MODULE */

    public static final String ARTICLE_TYPE_SLIDESHOW = "SLIDESHOWS";
    public static final String ARTICLE_TYPE_SLIDESHOW_SEARCH = "slides"; // one extra key because key is different for article in slideshow
    public static final String ARTICLE_TYPE_ARTICLES = "ARTICLES";

    public static final String DISCOVER_FILTER_ALL = "All";
    public static final String DISCOVER_FILTER_GET_FIT = "Get Fit";
    public static final String DISCOVER_FILTER_EAT_RIGHT = "Eat Right";
    public static final String DISCOVER_FILTER_STAY_HAPPY = "Stay Happy";
    public static final String DISCOVER_FILTER_LOOK_BETTER = "Look Better";
    public static final String DISCOVER_FILTER_BE_HEALTHY = "Be Healthy";
    public static final String DISCOVER_FILTER_OTHER = "Others";



    public static final String RATING_TYPE_SLIDESHOW = "Slideshow";
    public static final String RATING_TYPE_ARTICLE = "Article";
    public static final String MY_FAV_TYPE_ARTICLE = "Article";
    public static final String MY_FAV_TYPE_SLIDESHOW = "Slide";


    public static final String BUNDLE_KEY_ARTICLE_ID = "ARTICLE_ID";
    public static final String BUNDLE_KEY_SLIDESHOW_ID = "SLIDESHOW_ID";


    public static final String ARTICLE = "ARTICLE";
    public static final int API_POST_DELAYED_TIME = 500;
    public static final String BUNDLE_KEY_SLIDESHOW_URL = "SLIDESHOW_URL";
    public static final String SERVER_DATE_FORMAT_WITH_MILLISECONDS = "yyyy-MM-dd'T'HH:mm:ss";

}
