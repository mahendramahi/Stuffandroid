package com.twc.dailylog.model.beans;

/**
 * Created by ManishJ1 on 8/4/2016.
 */
public class AddFoodItem {

    /**
     * NutritionMemberID : 252330
     * NutritionMealType : Breakfast
     * NutritionID : 0
     * NutritionFat : 9.2
     * NutritionQuantity : 1
     * NutritionFoodItem : Alle Piyav Gashi, Karnataka
     * NutritionCarbs : 9.2
     * FoodID : 46476
     * NutritionDate : 05/26/2016 04:25:33
     * NutritionSodium : 206.4
     * NutritionProtien : 21.3
     * NutritionStandardServing : Plate
     * NutritionCalorie : 201.2
     */

    private String NutritionMemberID;
    private String NutritionMealType;
    private int NutritionID;
    private double NutritionFat;
    private double NutritionQuantity;
    private String NutritionFoodItem;
    private double NutritionCarbs;
    private int FoodID;
    private String NutritionDate;
    private double NutritionSodium;
    private double NutritionProtien;
    private String NutritionStandardServing;
    private double NutritionCalorie;

    public String getNutritionMemberID() {
        return NutritionMemberID;
    }

    public void setNutritionMemberID(String NutritionMemberID) {
        this.NutritionMemberID = NutritionMemberID;
    }

    public String getNutritionMealType() {
        return NutritionMealType;
    }

    public void setNutritionMealType(String NutritionMealType) {
        this.NutritionMealType = NutritionMealType;
    }

    public int getNutritionID() {
        return NutritionID;
    }

    public void setNutritionID(int NutritionID) {
        this.NutritionID = NutritionID;
    }

    public double getNutritionFat() {
        return NutritionFat;
    }

    public void setNutritionFat(double NutritionFat) {
        this.NutritionFat = NutritionFat;
    }

    public double getNutritionQuantity() {
        return NutritionQuantity;
    }

    public void setNutritionQuantity(double NutritionQuantity) {
        this.NutritionQuantity = NutritionQuantity;
    }

    public String getNutritionFoodItem() {
        return NutritionFoodItem;
    }

    public void setNutritionFoodItem(String NutritionFoodItem) {
        this.NutritionFoodItem = NutritionFoodItem;
    }

    public double getNutritionCarbs() {
        return NutritionCarbs;
    }

    public void setNutritionCarbs(double NutritionCarbs) {
        this.NutritionCarbs = NutritionCarbs;
    }

    public int getFoodID() {
        return FoodID;
    }

    public void setFoodID(int FoodID) {
        this.FoodID = FoodID;
    }

    public String getNutritionDate() {
        return NutritionDate;
    }

    public void setNutritionDate(String NutritionDate) {
        this.NutritionDate = NutritionDate;
    }

    public double getNutritionSodium() {
        return NutritionSodium;
    }

    public void setNutritionSodium(double NutritionSodium) {
        this.NutritionSodium = NutritionSodium;
    }

    public double getNutritionProtien() {
        return NutritionProtien;
    }

    public void setNutritionProtien(double NutritionProtien) {
        this.NutritionProtien = NutritionProtien;
    }

    public String getNutritionStandardServing() {
        return NutritionStandardServing;
    }

    public void setNutritionStandardServing(String NutritionStandardServing) {
        this.NutritionStandardServing = NutritionStandardServing;
    }

    public double getNutritionCalorie() {
        return NutritionCalorie;
    }

    public void setNutritionCalorie(double NutritionCalorie) {
        this.NutritionCalorie = NutritionCalorie;
    }
}
