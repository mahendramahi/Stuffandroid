package com.truworth.wellnesscorner.ui.mainapp.createpost.sharemeal;

import android.databinding.ObservableField;
import android.text.SpannableStringBuilder;

import com.truworth.wellnesscorner.base.BaseViewModel;
import com.truworth.wellnesscorner.model.FoodsBean;
import com.truworth.wellnesscorner.utils.Utils;

public class ShareMealDetailItemViewModel extends BaseViewModel {

    public FoodsBean foodsBean;

    public ShareMealDetailItemViewModel(FoodsBean foodsBean) {
        this.foodsBean = foodsBean;
    }

    public FoodsBean getFoodsBean() {
        return foodsBean;
    }

    public void setFoodsBean(FoodsBean foodsBean) {
        this.foodsBean = foodsBean;
    }

    public ObservableField<SpannableStringBuilder> foodData = new ObservableField<>();

    public ObservableField<SpannableStringBuilder> setMealQuantity(String name, double quantity, String serving){
        String mealQuantityString = "";
        if(serving !=null && !serving.equals("N/A"))
            mealQuantityString = ", "+ Utils.doubleToString(quantity) +" "+ serving;
        else
            mealQuantityString = ", "+ Utils.doubleToString(quantity);

       foodData.set(Utils.makeSpecificTextBoldSize(name +""+ mealQuantityString, name,1.1f));

       return foodData;
    }
}
