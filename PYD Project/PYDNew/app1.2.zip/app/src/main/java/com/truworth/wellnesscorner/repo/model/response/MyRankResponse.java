package com.truworth.wellnesscorner.repo.model.response;

import com.truworth.wellnesscorner.model.ChallengeLeaderboardBean;

import java.util.List;

public class MyRankResponse {

    private DataBean data;
    private boolean hasError;
    private Object error;

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public boolean isHasError() {
        return hasError;
    }

    public void setHasError(boolean hasError) {
        this.hasError = hasError;
    }

    public Object getError() {
        return error;
    }

    public void setError(Object error) {
        this.error = error;
    }

    public static class DataBean {
        private int pageIndex;
        private int rank;
        private List<ChallengeLeaderboardBean> challengeLeaderboard;

        public int getPageIndex() {
            return pageIndex;
        }

        public void setPageIndex(int pageIndex) {
            this.pageIndex = pageIndex;
        }

        public int getRank() {
            return rank;
        }

        public void setRank(int rank) {
            this.rank = rank;
        }

        public List<ChallengeLeaderboardBean> getChallengeLeaderboard() {
            return challengeLeaderboard;
        }

        public void setChallengeLeaderboard(List<ChallengeLeaderboardBean> challengeLeaderboard) {
            this.challengeLeaderboard = challengeLeaderboard;
        }

    }
}
