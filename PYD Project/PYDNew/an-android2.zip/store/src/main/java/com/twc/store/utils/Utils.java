package com.twc.store.utils;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Fragment;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.provider.Settings;
import android.provider.Settings.Secure;
import android.support.design.widget.Snackbar;
import android.support.v4.content.ContextCompat;
import android.text.Html;
import android.text.InputFilter;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.style.RelativeSizeSpan;
import android.text.style.StyleSpan;
import android.util.Base64;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.twc.store.R;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;
import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.spec.RSAPrivateCrtKeySpec;
import java.security.spec.RSAPrivateKeySpec;
import java.security.spec.RSAPublicKeySpec;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.Calendar;
import java.util.Locale;
import java.util.regex.Pattern;

import javax.crypto.Cipher;

public class Utils {

    public static InputFilter decimalFilter = new InputFilter() {
        @Override
        public CharSequence filter(CharSequence arg0, int arg1, int arg2, Spanned arg3, int arg4, int arg5) {
            for (int k = arg1; k < arg2; k++) {
                if (!(Character.isDigit(arg0.charAt(k)) || arg0.charAt(k) == '.')) {
                    return "";
                } // the first editor deleted this bracket when it is definitely
                // necessary...
            }
            return null;
        }
    };
    public static InputFilter numericFilter = new InputFilter() {
        @Override
        public CharSequence filter(CharSequence arg0, int arg1, int arg2, Spanned arg3, int arg4, int arg5) {
            for (int k = arg1; k < arg2; k++) {
                if (!(Character.isDigit(arg0.charAt(k)))) {
                    return "";
                } // the first editor deleted this bracket when it is definitely
                // necessary...
            }
            return null;
        }
    };

    public static void setupTouchUI(View view, final Activity mActivity) {
        if (!(view instanceof EditText)) {
            view.setOnTouchListener(new View.OnTouchListener() {
                @SuppressLint("ClickableViewAccessibility")
                public boolean onTouch(View v, MotionEvent event) {
                    hideSoftKeyboard(mActivity);
                    return false;
                }
            });
        }
        if (view instanceof ViewGroup) {
            for (int i = 0; i < ((ViewGroup) view).getChildCount(); i++) {
                View innerView = ((ViewGroup) view).getChildAt(i);
                setupTouchUI(innerView, mActivity);
            }
        }
    }

    public static void openSoftKeyBoard(Activity activity) {
        InputMethodManager inputMethodManager = (InputMethodManager) activity.getSystemService(Context.INPUT_METHOD_SERVICE);
        if (inputMethodManager != null) {
            inputMethodManager.showSoftInput(activity.getCurrentFocus(), 0);
        }
    }

    public static void hideSoftKeyboard(Activity activity) {
        InputMethodManager inputMethodManager = (InputMethodManager) activity.getSystemService(Activity.INPUT_METHOD_SERVICE);
        if (null != activity.getCurrentFocus()) {
            inputMethodManager.hideSoftInputFromWindow(activity.getCurrentFocus().getWindowToken(), 0);
        }
    }

    public static void hideSoftKeyboardDialogDismiss(final Activity activity) {
        new Handler().postDelayed(new Runnable() {

            @Override
            public void run() {
                activity.runOnUiThread(new Runnable() {

                    @Override
                    public void run() {
                        hideSoftKeyboard(activity);
                    }
                });
            }
        }, 1);
    }

    public static boolean isEmailIdValid(String emailId) {
        boolean isValid = false;

        Pattern EMAIL_ADDRESS_PATTERN = Pattern.compile("[a-zA-Z0-9\\+\\.\\_\\%\\-\\+]{1,256}" + "\\@" + "[a-zA-Z0-9][a-zA-Z0-9\\-]{0,64}" + "(" + "\\." + "[a-zA-Z0-9][a-zA-Z0-9\\-]{0,25}" + ")+");
        if (EMAIL_ADDRESS_PATTERN.matcher(emailId).matches()) {
            isValid = true;
        }
        return isValid;
    }

    public static void showToast(final Activity activity, final String msg) {
        activity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(activity, msg, Toast.LENGTH_LONG).show();
            }
        });
    }


    public static String getDeviceId(Activity activity) {
        String deviceID = Secure.getString(activity.getContentResolver(), Secure.ANDROID_ID);
        return deviceID;
    }


    public static boolean isAtleastOneAlphanumericValid(String character) {
        boolean isValid = false;
        Pattern Atlest_One_Alphanumaric = Pattern.compile("^(?=.*[a-zA-Z]).+$");
        if (Atlest_One_Alphanumaric.matcher(character).matches()) {
            isValid = true;
        }
        return isValid;
    }



    public static boolean isPasswordValid(String character) {
        boolean isValid = false;

        if (character.length() >= 6) {
            isValid = true;
        }
        return isValid;
    }

    public static boolean isValidEmail(CharSequence target) {
        return target != null && android.util.Patterns.EMAIL_ADDRESS.matcher(target).matches();
    }

    public static void replaceFragmentWithoutAnimation(android.app.FragmentManager fragmentManager, Fragment fragment, String tag, boolean addTobackStack, int container) {

        // transaction
        android.app.FragmentTransaction ft = fragmentManager.beginTransaction();
        if (addTobackStack) {
            ft.addToBackStack(tag);
        }

        ft.replace(container, fragment, tag);
        ft.commit();
    }

    public static void replaceFragmentWithExecutePendingTransactions(android.app.FragmentManager fragmentManager, Fragment fragment, String tag, boolean addTobackStack, int container) {

        // transaction
        android.app.FragmentTransaction ft = fragmentManager.beginTransaction();
        if (addTobackStack) {
            ft.addToBackStack(tag);
        }

        ft.replace(container, fragment, tag);
        ft.commit();

    }





    public static String convertTwoDecimalPoint(double value) {

        NumberFormat nf = new DecimalFormat("#.##");

        String res = nf.format(value);

        return res;
    }

    public static String convertNumberWithCommas(String number) {
        try {
            return NumberFormat.getIntegerInstance().format(Integer.valueOf(number));
        } catch (Exception e) {
            e.printStackTrace();
            return number;
        }

    }

    public static void showSnackBarMessage(View view, String msg) {
        Snackbar snackbar = Snackbar.make(view, msg, Snackbar.LENGTH_LONG);

        View sbView = snackbar.getView();
        FrameLayout.LayoutParams params = (FrameLayout.LayoutParams) sbView.getLayoutParams();
        params.bottomMargin = 10;
        sbView.setBackgroundColor(Color.DKGRAY);
        TextView textView = sbView.findViewById(android.support.design.R.id.snackbar_text);
        textView.setTextColor(Color.WHITE);
        textView.setTextSize(20);
        snackbar.show();
    }

    /**
     * Returns a proportion (n out of a total) as a percentage, in a float.
     */
    public static double getPercentage(float n, float total) {
        if (n == 0 || total == 0) {
            return 0.0;
        }
        try {
            float proportion = n / total;
            BigDecimal bigDecimal = new BigDecimal(proportion * 100);
            bigDecimal = bigDecimal.setScale(1, RoundingMode.HALF_UP);
            return bigDecimal.doubleValue();
        } catch (ArithmeticException e) {
            e.printStackTrace();
            return 0.0;
        }

    }

    /*
    * find the age from the dob and current date
    * */
    public static String getAgeForReport(String date) {
        String[] dob = date.split("/");
        int day = Integer.parseInt(dob[0]);
        int month = Integer.parseInt(dob[1]);
        int year = Integer.parseInt(dob[2]);
        return getAgeForReport(year, month, day);
    }

    private static String getAgeForReport(int year, int month, int day) {
        Calendar dob = Calendar.getInstance();
        Calendar today = Calendar.getInstance();
        dob.set(year, month, day);
        int age = today.get(Calendar.YEAR) - dob.get(Calendar.YEAR);
        /*
         * if (today.get(Calendar.DAY_OF_YEAR) < dob.get(Calendar.DAY_OF_YEAR))
		 * { age--; }
		 */
        if (age < 0) {
            age = 0;
        }
        String ageS = String.valueOf(age);
        return ageS;
    }

    public static String numberFormatter(int digit, double value) {
        NumberFormat formatter;
        if (digit == 1) {
            formatter = new DecimalFormat("#0.0");
        } else if (digit == 2) {
            formatter = new DecimalFormat("#0.00");
        } else if (digit == 3) {
            formatter = new DecimalFormat("#0.000");
        } else {
            formatter = new DecimalFormat("#0.0000");
        }

        return formatter.format(value);
    }

    public static String doubleToString(double value) {
        try {
            DecimalFormat format = new DecimalFormat("0.##");
            return format.format(value);
        } catch (Exception e) {
            e.printStackTrace();
            return String.valueOf(value);
        }
    }

    public static void replaceFragment(android.app.FragmentManager fragmentManager, Fragment fragment, String tag, boolean addTobackStack, int container) {

        android.app.FragmentTransaction ft = fragmentManager.beginTransaction();
        ft.setCustomAnimations(R.animator.enter, R.animator.exit, R.animator.pop_enter, R.animator.pop_exit);
        if (addTobackStack) {
            ft.addToBackStack(tag);
        }

        ft.replace(container, fragment, tag);
        ft.commit();
    }
    public static String calculateScrollForHeight(int height) {
        String ft = "" + (height * 0.032808);
        String arrft[] = ft.split("\\.");
        int mHeightFt = Integer.parseInt(arrft[0].toString());
        String inch = "." + arrft[1].toString().substring(0, 2);
        inch = "" + (Double.parseDouble(inch) * 12);
        int mHeightInch = (int) Math.round(Double.parseDouble(inch));
        //  int scroll = (onePartOfDisplayWidthHeight * mHeightFt) + (mHeightInch * (onePartOfDisplayWidthHeight / 11));


        if (mHeightInch == 12) {
            mHeightFt = mHeightFt + 1;
            mHeightInch = 0;
        }

        return mHeightFt + "'" + mHeightInch + "\"";
    }

    /*Get gradient color---at by pankaj sharma on 2016-10-20*/
    public static LayerDrawable gradientColor(String colorOption, Context context, boolean isTopCorners, boolean isBottomCorners, int strokColor, float radius) {
        LayerDrawable layerDrawable = null;
        int color1 = 0;
        int color2 = 0;
        int otherColor1 = 0;
        int otherColor2 = 0;
        boolean isTopBottom = false;
        if (colorOption.equalsIgnoreCase("teamfirst_grad")) {
            color1 = 0xdcb888;
            color2 = 0xd168a2;
            otherColor1 = Color.parseColor("#dcb888");
            otherColor2 = Color.parseColor("#d168a2");
            isTopBottom = false;
        } else if (colorOption.equalsIgnoreCase("teamsecond_grad")) {
            color1 = 0x2c6cff;
            color2 = 0x9347e1;
            otherColor1 = Color.parseColor("#2c6cff");
            otherColor2 = Color.parseColor("#d168a2");
            isTopBottom = false;
        } else if (colorOption.equalsIgnoreCase("teamthird_grad")) {
            color1 = 0x6fadc6;
            color2 = 0x5966c2;
            otherColor1 = Color.parseColor("#6fadc6");
            otherColor2 = Color.parseColor("#5966c2");
            isTopBottom = false;
        } else if (colorOption.equalsIgnoreCase("blur_green")) {
            color1 = 0x14d2af;
            color2 = 0x1566f3;
            otherColor1 = Color.parseColor("#14d2af");
            otherColor2 = Color.parseColor("#1566f3");
            isTopBottom = false;
        } else if (colorOption.equalsIgnoreCase("purple_pink")) {
            color1 = 0xe8587c;
            color2 = 0x4b2383;
            otherColor1 = Color.parseColor("#e8587c");
            otherColor2 = Color.parseColor("#4b2383");
            isTopBottom = false;
        } else if (colorOption.equalsIgnoreCase("orange_yellow")) {
            color1 = 0xf8983c;
            color2 = 0xd8620e;
            otherColor1 = Color.parseColor("#f8983c");
            otherColor2 = Color.parseColor("#d8620e");
            isTopBottom = false;
        } else if (colorOption.equalsIgnoreCase("pink_red")) {
            color1 = 0xef4337;
            color2 = 0xd52f71;
            otherColor1 = Color.parseColor("#ef4337");
            otherColor2 = Color.parseColor("#d52f71");
            isTopBottom = false;
        } else if (colorOption.equalsIgnoreCase("volet_skyblue")) {
            color1 = 0x4b9af6;
            color2 = 0x8b62dc;
            otherColor1 = Color.parseColor("#4b9af6");
            otherColor2 = Color.parseColor("#8b62dc");
            isTopBottom = false;
        } else if (colorOption.equalsIgnoreCase("deepsky_sky")) {
            color1 = 0x2abdf3;
            color2 = 0x2472f6;
            otherColor1 = Color.parseColor("#2abdf3");
            otherColor2 = Color.parseColor("#2472f6");
            isTopBottom = false;
        } else if (colorOption.equalsIgnoreCase("deeppurple_purple")) {
            color1 = 0xa54af2;
            color2 = 0x783fe8;
            otherColor1 = Color.parseColor("#a54af2");
            otherColor2 = Color.parseColor("#783fe8");
            isTopBottom = false;
        } else if (colorOption.equalsIgnoreCase("deepgreen_green")) {
            color1 = 0x7dc571;
            color2 = 0x55a8a0;
            otherColor1 = Color.parseColor("#7dc571");
            otherColor2 = Color.parseColor("#55a8a0");
            isTopBottom = false;
        } else if (colorOption.equalsIgnoreCase("purple_yellow")) {
            color1 = 0xef9913;
            color2 = 0x921ea6;
            otherColor1 = Color.parseColor("#ef9913");
            otherColor2 = Color.parseColor("#921ea6");
            isTopBottom = false;
        } else if (colorOption.isEmpty()) {
            color1 = 0xdcb888;
            color2 = 0xd168a2;
            otherColor1 = Color.parseColor("#dcb888");
            otherColor2 = Color.parseColor("#d168a2");
            isTopBottom = false;
        } else {
            color1 = 0xffffff;
            color2 = 0xffffff;
            otherColor1 = Color.parseColor("#ffffff");
            otherColor2 = Color.parseColor("#ffffff");
            isTopBottom = false;
        }
        int[] Gradinetuppercolors = {color1, color2};

        int[] upperColor = new int[2];
        String col1 = String.valueOf(color1).replace("0x", "#");
        String col2 = String.valueOf(color2).replace("0x", "#");

        upperColor[0] = otherColor1;
        upperColor[1] = otherColor2;
        layerDrawable = getGradiantColor(Gradinetuppercolors, isTopCorners, isBottomCorners, strokColor, radius, upperColor, isTopBottom);

        return layerDrawable;
    }

    private static LayerDrawable getGradiantColor(int[] gradient, boolean isTopCorners, boolean isBottomCorners, int strokColor, float radius, int[] colors, boolean isTopBottom) {
        LayerDrawable layerList = null;
        try {
            GradientDrawable shadow;
            GradientDrawable backColor;
            if (isTopBottom) {
                shadow = new GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP, gradient);
                backColor = new GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP, colors);
                shadow.setBounds(0, 98, 0, 0);
                backColor.setBounds(0, 0, 0, 4);
            } else {
                shadow = new GradientDrawable(GradientDrawable.Orientation.RIGHT_LEFT, gradient);
                backColor = new GradientDrawable(GradientDrawable.Orientation.RIGHT_LEFT, colors);
                shadow.setBounds(98, 0, 0, 0);
                backColor.setBounds(0, 0, 4, 0);
            }


            if (isTopCorners && isBottomCorners) {
                backColor.setCornerRadius(radius);
            } else if (isTopCorners && !isBottomCorners) {
                backColor.setCornerRadii(new float[]{radius, radius, radius, radius, 0, 0, 0, 0});

            } else if (!isTopCorners && isBottomCorners) {
                backColor.setCornerRadii(new float[]{0, 0, 0, 0, radius, radius, radius, radius});
            }
            //  backColor.setStroke(5, strokColor, 0, 0);


            Drawable[] layers = new Drawable[2];
            layers[0] = backColor;
            layers[1] = shadow;

            layerList = new LayerDrawable(layers);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return layerList;
    }



    public static String getColoredSpanned(String text, String color) {
        String input = "<font color=" + color + ">" + text + "</font>";
        return input;
    }

    /**
     * Create method by pankaj  for html editor
     */
    public static String toBase64(Bitmap bitmap) {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, baos);
        byte[] bytes = baos.toByteArray();
        //return Base64.encodeBase64String(bytes);
        return Base64.encodeToString(bytes, Base64.NO_WRAP);
    }

    public static Bitmap toBitmap(Drawable drawable) {
        if (drawable instanceof BitmapDrawable) {
            return ((BitmapDrawable) drawable).getBitmap();
        }

        int width = drawable.getIntrinsicWidth();
        width = width > 0 ? width : 1;
        int height = drawable.getIntrinsicHeight();
        height = height > 0 ? height : 1;

        Bitmap bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        drawable.setBounds(0, 0, canvas.getWidth(), canvas.getHeight());
        drawable.draw(canvas);

        return bitmap;
    }

    public static Bitmap decodeResource(Context context, int resId) {
        return BitmapFactory.decodeResource(context.getResources(), resId);
    }

    public static long getCurrentTime() {
        return System.currentTimeMillis();
    }

    public static boolean checkImageResource(Context ctx, ImageView imageView, int imageResource) {
        boolean result = false;
        if (ctx != null && imageView != null && imageView.getDrawable() != null) {
            Drawable.ConstantState constantState;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                constantState = ContextCompat.getDrawable(ctx, imageResource).getConstantState();
            } else {
                constantState = ContextCompat.getDrawable(ctx, imageResource).getConstantState();
            }
            if (imageView.getDrawable().getConstantState() == constantState) {
                result = true;
            }
        }
        return result;
    }

    public static SpannableStringBuilder makeSpecificTextBold(String fullText, String textToBold) {
        SpannableStringBuilder builder = new SpannableStringBuilder();

        if (textToBold.length() > 0 && !textToBold.trim().equals("")) {

            //for counting start/end indexes
            String testText = fullText.toLowerCase(Locale.US);
            String testTextToBold = textToBold.toLowerCase(Locale.US);
            int startingIndex = testText.indexOf(testTextToBold);
            int endingIndex = startingIndex + testTextToBold.length();
            //for counting start/end indexes

            if (startingIndex < 0 || endingIndex < 0) {
                return builder.append(fullText);
            } else if (startingIndex >= 0 && endingIndex >= 0) {

                builder.append(fullText);
                builder.setSpan(new StyleSpan(Typeface.BOLD), startingIndex, endingIndex, 0);
                builder.setSpan(new RelativeSizeSpan(0.8f), startingIndex, endingIndex, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            }
        } else {
            return builder.append(fullText);
        }

        return builder;
    }


    public static String ordinal(int i) {
        String[] sufixes = new String[]{"th", "st", "nd", "rd", "th", "th", "th", "th", "th", "th"};
        switch (i % 100) {
            case 11:
            case 12:
            case 13:
                return i + "th";
            default:
                return i + sufixes[i % 10];

        }
    }


    public static String ordinalSuperScript(int i) {
        String[] sufixes = new String[]{"th", "st", "nd", "rd", "th", "th", "th", "th", "th", "th"};
        switch (i % 100) {
            case 11:
            case 12:
            case 13:

                return "th";

            default:
                return sufixes[i % 10];


        }
    }


    @SuppressWarnings("deprecation")
    public static Spanned fromHtml(String html) {
        Spanned result;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            result = Html.fromHtml(html, Html.FROM_HTML_MODE_LEGACY);
        } else {
            result = Html.fromHtml(html);
        }
        return result;
    }

    public static boolean checkRootMethod1() {
        String buildTags = Build.TAGS;
        return buildTags != null && buildTags.contains("test-keys");
    }

    public static boolean checkRootMethod2() {
        String[] paths = {"/system/app/Superuser.apk", "/sbin/su", "/system/bin/su", "/system/xbin/su", "/data/local/xbin/su", "/data/local/bin/su", "/system/sd/xbin/su", "/system/bin/failsafe/su", "/data/local/su", "/su/bin/su"};
        for (String path : paths) {
            if (new File(path).exists()) {
                return true;
            }
        }
        return false;
    }

    public static boolean checkRootMethod3() {
        Process process = null;
        try {
            process = Runtime.getRuntime().exec(new String[]{"/system/xbin/which", "su"});
            BufferedReader in = new BufferedReader(new InputStreamReader(process.getInputStream()));
            return in.readLine() != null;
        } catch (Throwable t) {
            return false;
        } finally {
            if (process != null) {
                process.destroy();
            }
        }
    }

    public static int getAge(int year, int month, int day) {

        Calendar dob = Calendar.getInstance();
        Calendar today = Calendar.getInstance();

        dob.set(year, month, day);

        int age = today.get(Calendar.YEAR) - dob.get(Calendar.YEAR);

        if (today.get(Calendar.DAY_OF_YEAR) < dob.get(Calendar.DAY_OF_YEAR)) {
            age--;
        }
        return age;
    }

    public static Bitmap getMarkerBitmapFromView(View view) {
        view.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED);
        view.layout(0, 0, view.getMeasuredWidth(), view.getMeasuredHeight());
        view.buildDrawingCache();
        Bitmap returnedBitmap = Bitmap.createBitmap(view.getMeasuredWidth(), view.getMeasuredHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(returnedBitmap);
        canvas.drawColor(Color.WHITE, PorterDuff.Mode.SRC_IN);
        Drawable drawable = view.getBackground();
        if (drawable != null) {
            drawable.draw(canvas);
        }
        view.draw(canvas);
        return returnedBitmap;
    }


    //added by pankaj sharma for implements encryption and decryption

    public static String Encrypt(String encrText) {
        String result = "";
        try {
            String modulusString = "vgLSa5EyGYeuMQmkiYVFKS196jbY8HoNBO2hmT1z+DVzVkjEep519lLptW/I1lPRr9yobHpr4bpr6VLnjxGpMaon2z1nSiQMDC9aJS+PYLCDvPac+UXM5NLWQmwHFBgzN5HWWVqcRK40UZF+tyoFiFHw2V2VWUQfGjX8qOJvv2E=";
            String publicExponentString = "AQAB";

            byte[] modulusBytes = Base64.decode(modulusString, Base64.DEFAULT);
            byte[] exponentBytes = Base64.decode(publicExponentString, Base64.DEFAULT);
            BigInteger modulus = new BigInteger(1, modulusBytes);
            BigInteger publicExponent = new BigInteger(1, exponentBytes);

            RSAPublicKeySpec rsaPubKey = new RSAPublicKeySpec(modulus, publicExponent);
            KeyFactory fact = KeyFactory.getInstance("RSA");
            PublicKey pubKey = fact.generatePublic(rsaPubKey);
            Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1PADDING");
            cipher.init(Cipher.ENCRYPT_MODE, pubKey);


            byte[] plainBytes = encrText.getBytes("UTF-8");
            byte[] cipherEncryptData = cipher.doFinal(plainBytes);

            String encryptedStringBase64 = Base64.encodeToString(cipherEncryptData, Base64.DEFAULT);
            result = encryptedStringBase64;
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return result;
    }

    public static String Decrypt(String encrText) {
        String result = "";
        try {
            String modulusString = "pxmdVjHY8XcSnMaFC42foyna+ZYIYMELeNg9n2t98vO35AyivyR4ksBCoUNMf7It93ejm+8F+Zg1MynYRa0ib7uG7RlOjS3Oj9RZm+ztImhEOcVpAao+Cu8fItdOAAV6S97jfEaXzl2L7oM0Ty377o6LSrQYZW0IIg+WwQ1BUpc=";
            String publicExponentString = "AQAB";

            byte[] modulusBytes = Base64.decode(modulusString, Base64.DEFAULT);
            byte[] exponentBytes = Base64.decode(publicExponentString, Base64.DEFAULT);
            BigInteger modulus = new BigInteger(1, modulusBytes);
            BigInteger publicExponent = new BigInteger(1, exponentBytes);
            BigInteger privateExponent = publicExponent.modInverse(modulus);

            KeyFactory fact = KeyFactory.getInstance("RSA");

            String pp = "3dTww5AmmeeWRFnwivBDQky8pZvHBYmTEG8+cISRx74CFaW66Vtk7nb4tfzXnEH7oJRpeF7XxU80LYMdW3dlrQ==";
            String pq = "wNaLW+fE2cNK8vVHLpSpLMbKRXE8kxO2I/Uie+kZjwFQYUGpnFot2/EBBr3GU9F6UQw/QffCObFGfB+3aak50w==";
            String pEP = "2V4BFgA4cvLFAfEHjX1kyqCa8cQ1Pq3SF3aKPoMIvirnrAKbpnJR8oFNsDYzp//X6z/CIZr9329+92HU8H2MeQ==";
            String pEQ = "F1Veg35l6VuiJAfd1xsR5WMgcoqjI8DM10kAJTItb4pfKYWCenLG/cgJscEg0F+Wh1wOA3NxQv3aY4aK8PQTFQ==";
            String cc="tJVkVdtpa8t3GwSAOhLTnIxUphwOq5mC1i5RB12tK7CalvjOyauXm+Nv4lINsloHAvf2Av2fOzEVYFm4vaeuDA==";

            BigInteger primeP = new BigInteger(1, Base64.decode(pp, Base64.DEFAULT));
            BigInteger primeQ = new BigInteger(1, Base64.decode(pq, Base64.DEFAULT));
            BigInteger primeExponentP = new BigInteger(1, Base64.decode(pEP, Base64.DEFAULT));
            BigInteger primeExponentQ = new BigInteger(1, Base64.decode(pEQ, Base64.DEFAULT));
            BigInteger crtCoef = new BigInteger(1, Base64.decode(cc, Base64.DEFAULT));

            RSAPrivateKeySpec prvSpec = new RSAPrivateCrtKeySpec(modulus, publicExponent, privateExponent, primeP, primeQ, primeExponentP, primeExponentQ, crtCoef);

            PrivateKey privkey = fact.generatePrivate(prvSpec);

            Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
            cipher.init(Cipher.DECRYPT_MODE, privkey);

            byte[] dataDecoded = Base64.decode(encrText, Base64.DEFAULT);

            result = new String(cipher.doFinal(dataDecoded), "UTF-8");

        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return result;
    }


    public static int manipulateColor(int color, float factor) {
        int a = Color.alpha(color);
        int r = Math.round(Color.red(color) * factor);
        int g = Math.round(Color.green(color) * factor);
        int b = Math.round(Color.blue(color) * factor);
        return Color.argb(a, Math.min(r, 255), Math.min(g, 255), Math.min(b, 255));
    }

    public static String getFirsLetterFromPosition(int position) {
        //  String alphabets = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        char c = (char) (position + 65);
        return String.valueOf(c);
    }

    public static String getYouTubeImageUrl(String vedioId) {
        String url = "http://img.youtube.com/vi/" + vedioId + "/0.jpg";
        return url;
    }

    public static String getFormattedAmount(double value) {
        try {
            DecimalFormat format = new DecimalFormat("#,###,##0.00");
            return format.format(value);
        } catch (Exception e) {
            e.printStackTrace();
            return String.valueOf(value);
        }
    }

    public static String getFormattedAmountManageZero(double value) {
        try {
            DecimalFormat format = new DecimalFormat("#,###,##0.##");
            return format.format(value);
        } catch (Exception e) {
            e.printStackTrace();
            return String.valueOf(value);
        }
    }

    public static String getFormattedAmountWithoutZero(double value) {
        try {
            DecimalFormat format = new DecimalFormat("#,###,###");
            return format.format(value);
        } catch (Exception e) {
            e.printStackTrace();
            return String.valueOf(value);
        }
    }



/*    public String Decrypt(String encryptedText) throws Exception
    {

        byte[] message = Base64.decodeBase64(encryptedText.getBytes("utf-8"));

        MessageDigest md = MessageDigest.getInstance("md5");
        byte[] digestOfPassword = md.digest(secretKey.getBytes("utf-8"));
        byte[] keyBytes = Arrays.copyOf(digestOfPassword, 24);
        for (int j = 0, k = 16; j < 8;) {
            keyBytes[k++] = keyBytes[j++];
        }

        KeySpec keySpec = new DESedeKeySpec(keyBytes);
        SecretKey key = SecretKeyFactory.getInstance("DESede").generateSecret(keySpec);

        Cipher decipher = Cipher.getInstance("DESede");
        decipher.init(Cipher.DECRYPT_MODE, key);

        byte[] plainText = decipher.doFinal(message);

        String result = new String(plainText, "UTF-8");

        return result;
    }

    public String Encrypt(String message) throws Exception
    {

        MessageDigest md = MessageDigest.getInstance("md5");
        byte[] digestOfPassword = md.digest(secretKey.getBytes("utf-8"));
        byte[] keyBytes = Arrays.copyOf(digestOfPassword, 24);

        for (int j = 0, k = 16; j < 8;) {
            keyBytes[k++] = keyBytes[j++];
        }

        KeySpec keySpec = new DESedeKeySpec(keyBytes);
        SecretKey key = SecretKeyFactory.getInstance("DESede").generateSecret(keySpec);

        Cipher cipher = Cipher.getInstance("DESede");
        cipher.init(Cipher.ENCRYPT_MODE, key);

        byte[] plainTextBytes = message.getBytes("utf-8");
        byte[] buf = cipher.doFinal(plainTextBytes);
        byte[] base64Bytes =Base64. encodeBase64(buf);

        String base64EncryptedString = new String(base64Bytes);

        return base64EncryptedString;
    }*/


    public static void redirectToDetailSettings(Activity activity) {
        Intent intent = new Intent();
        intent.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        Uri uri = Uri.fromParts("package", activity.getPackageName(), null);
        intent.setData(uri);
        activity.startActivity(intent);
    }

}


