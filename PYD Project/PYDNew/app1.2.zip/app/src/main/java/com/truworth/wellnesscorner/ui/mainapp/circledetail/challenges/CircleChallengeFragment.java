package com.truworth.wellnesscorner.ui.mainapp.circledetail.challenges;

import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import com.truworth.wellnesscorner.BR;
import com.truworth.wellnesscorner.R;
import com.truworth.wellnesscorner.base.BaseFragment;
import com.truworth.wellnesscorner.databinding.FragmentCircleChallengesBinding;
import com.truworth.wellnesscorner.model.OnGoingChallengesBean;
import com.truworth.wellnesscorner.model.PreviousChallengesBean;

import java.util.ArrayList;
import java.util.List;

public class CircleChallengeFragment extends BaseFragment<FragmentCircleChallengesBinding, CircleChallengeViewModel> {
    public static final String TAG = "CircleMemberFragment";
    CircleChallengeViewModel viewModel;
    List<OnGoingChallengesBean> onGoingChallengeList;
    List<PreviousChallengesBean> prevChallengeList;
    OngoingChallengeAdapter circleOngoingChallengeAdapter;
    PreviousChallengeAdapter circlePreviousChallengeAdapter;
    private static final String CIRCLE_IDENTITY = "circleIdentity";
    private String CircleIdentity="";

    private int pageIndex =1;



    public CircleChallengeFragment() {
        // Required empty public constructor
    }

    private Handler handler = new Handler();
    private Runnable runnable = new Runnable() {
        @Override
        public void run() {
            viewModel.loadChallenges(CircleIdentity, pageIndex);
        }
    };
    public static CircleChallengeFragment newInstance(String circleIdentity) {
        CircleChallengeFragment fragment = new CircleChallengeFragment();
        Bundle args = new Bundle();
        args.putString(CIRCLE_IDENTITY, circleIdentity);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            CircleIdentity = getArguments().getString(CIRCLE_IDENTITY);
        }
    }

    @Override
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        viewModel.showOngoingChallenge.set(false);
        viewModel.showPreviousChallenge.set(false);
        onGoingChallengeList = new ArrayList<>();
        prevChallengeList = new ArrayList<>();
        setUpOngoingChallengesRecycler();
        setUpPreviousChallengesRecycler();

        setOngoingChallengesObserver();
        setPreviousChallengesObserver();
    }

    @Override
    public int getBindingVariable() {
        return BR.viewModel;
    }

    @Override
    public int getLayoutId() {
        return R.layout.fragment_circle_challenges;
    }

    @Override
    public CircleChallengeViewModel getViewModel() {
        viewModel = ViewModelProviders.of(this).get(CircleChallengeViewModel.class);
        return viewModel;
    }
    boolean _areDataLoaded = false;
    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        if (isVisibleToUser && !_areDataLoaded ) {
            handler.postDelayed(runnable, 50);
            _areDataLoaded=true;
        }
    }

    private void setUpOngoingChallengesRecycler() {
        RecyclerView recyclerView = getViewDataBinding().rvOngoingChallenges;
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false));
        circleOngoingChallengeAdapter = new OngoingChallengeAdapter(onGoingChallengeList, CircleIdentity);
        recyclerView.setAdapter(circleOngoingChallengeAdapter);
    }

    private void setUpPreviousChallengesRecycler() {
        RecyclerView recyclerView = getViewDataBinding().rvPreviousChallenges;
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false));
        circlePreviousChallengeAdapter = new PreviousChallengeAdapter(prevChallengeList,CircleIdentity);
        recyclerView.setAdapter(circlePreviousChallengeAdapter);
    }

    private void setOngoingChallengesObserver(){
        viewModel.getOngoingChallenges().observe(this, new Observer<List<OnGoingChallengesBean>>() {
            @Override
            public void onChanged(@Nullable List<OnGoingChallengesBean> onGoingChallenge){

               if(onGoingChallenge!=null){
                   onGoingChallengeList.clear();
                   onGoingChallengeList.addAll(onGoingChallenge);
                   circleOngoingChallengeAdapter.notifyDataSetChanged();
               }
            }
        });
    }
    private void setPreviousChallengesObserver(){
        viewModel.getPreviousChallenges().observe(this, new Observer<List<PreviousChallengesBean>>() {
            @Override
            public void onChanged(@Nullable List<PreviousChallengesBean> prevChallenge){
               if(prevChallenge!=null) {
                   prevChallengeList.clear();
                   prevChallengeList.addAll(prevChallenge);
                   circlePreviousChallengeAdapter.notifyDataSetChanged();
               }
            }
        });
    }

    @Override
    public void onStop() {
        super.onStop();

        if(handler!=null) {
            handler.removeCallbacks(runnable);
        }
    }
}
