package com.twc.remindermodule.utils;


import com.twc.greendaolib.DaoSession;
import com.twc.greendaolib.GreenDaoApp;
import com.twc.greendaolib.ReminderItem;
import com.twc.greendaolib.ReminderItemDao;
import com.twc.greendaolib.ReminderTimeItem;
import com.twc.greendaolib.ReminderTimeItemDao;
import com.twc.remindermodule.rest.ReminderConfig;

import java.util.List;

public class RemindersDefault {
    private static RemindersDefault remindersDefault;
    private DaoSession daoSession;
    private RemindersDefault(DaoSession daoSession) {
        this.daoSession = daoSession;
    }

    public static RemindersDefault getInstance(DaoSession daoSession) {

        if (remindersDefault == null)
            remindersDefault = new RemindersDefault(daoSession);
        return remindersDefault;
    }

    public void loadDefaultValuesOfReminders() {
        if (daoSession != null) {
            insertRemindersData(-1, "Meal Reminders", "Meal Reminders", "When you eat meals at different times rather than on a regular schedule, your body goes into stress mode. Create a regular meal schedule and do your best to stick with it.", false, false);
        } else {
            Utils.printLog("dao session", "dao session null");
        }
    }

    public void insertReminderTimeData(long mealId, String reminderType, String reminderTime, boolean isActive, boolean isCustom) {
        ReminderTimeItem reminderTimeItem = new ReminderTimeItem();
        reminderTimeItem.setReminderId(mealId);
        reminderTimeItem.setUserId(ReminderConfig.reminderUser.getUserID());
        reminderTimeItem.setReminderType(reminderType);
        reminderTimeItem.setReminderTime(reminderTime);
        reminderTimeItem.setIsActive(isActive);
        reminderTimeItem.setIsCustom(isCustom);
        ReminderTimeItemDao reminderTimeItemDao = daoSession.getReminderTimeItemDao();
        reminderTimeItemDao.insert(reminderTimeItem);
    }


    public int insertRemindersData(int serverId, String reminderName, String reminderText, String reminderDesc, boolean isActive, boolean isCustom) {
        ReminderItem reminderItem = new ReminderItem();
        reminderItem.setServerID(serverId);
        reminderItem.setUserId(ReminderConfig.reminderUser.getUserID());
        reminderItem.setReminderName(reminderName);
        reminderItem.setReminderText(reminderText);
        reminderItem.setReminderDesc(reminderDesc);
        reminderItem.setIsActive(isActive);
        reminderItem.setIsCustom(isCustom);
        ReminderItemDao reminderItemDao = daoSession.getReminderItemDao();
        long rowId = reminderItemDao.insert(reminderItem);
        return (int) rowId;
    }



    public void updateToDefaultValuesOfReminders() {
        if (daoSession != null) {

            ReminderItemDao reminderItemDao = daoSession.getReminderItemDao();

            Utils.printLog("dao session", reminderItemDao.queryBuilder().list().size() + " total in start");

            List<ReminderItem> mReminderItemList = reminderItemDao.queryBuilder().where(ReminderItemDao.Properties.IsCustom.eq(true)).list();

            Utils.printLog("dao session", mReminderItemList.size() + " before delete custom");
            reminderItemDao.deleteInTx(mReminderItemList);
            Utils.printLog("dao session", reminderItemDao.queryBuilder().list() + " after delete");

            mReminderItemList = reminderItemDao.queryBuilder().where(ReminderItemDao.Properties.IsCustom.eq(false)).list();
            Utils.printLog("dao session", mReminderItemList.size() + " total in last");
            for (ReminderItem reminderItem : mReminderItemList) {
                reminderItem.setUserId(ReminderConfig.reminderUser.getUserID());
                reminderItem.setIsActive(false);
                reminderItemDao.update(reminderItem);
            }


            Utils.printLog("dao session", "==================================================");
            ReminderTimeItemDao reminderTimeItemDao = daoSession.getReminderTimeItemDao();
            Utils.printLog("dao session", reminderTimeItemDao.queryBuilder().list().size() + " time item total in start");

            List<ReminderTimeItem> reminderTimeItemList = reminderTimeItemDao.queryBuilder().where(ReminderTimeItemDao.Properties.IsCustom.eq(true)).list();

            Utils.printLog("dao session", reminderTimeItemList.size() + " before delete custom");
            reminderTimeItemDao.deleteInTx(reminderTimeItemList);
            Utils.printLog("dao session", reminderTimeItemDao.queryBuilder().list() + " after delete");

            reminderTimeItemList = reminderTimeItemDao.queryBuilder().where(ReminderTimeItemDao.Properties.IsCustom.eq(false), ReminderTimeItemDao.Properties.ReminderId.notEq(1)).list();
            Utils.printLog("dao session", reminderTimeItemList.size() + " before delete custom");
            reminderTimeItemDao.deleteInTx(reminderTimeItemList);
            Utils.printLog("dao session", reminderTimeItemDao.queryBuilder().list() + " after delete");


            reminderTimeItemList = reminderTimeItemDao.queryBuilder().where(ReminderTimeItemDao.Properties.IsCustom.eq(false)).list();
            Utils.printLog("dao session", reminderTimeItemList.size() + " total in last");
            for (ReminderTimeItem reminderTimeItem : reminderTimeItemList) {
                reminderTimeItem.setIsActive(false);
                reminderTimeItem.setUserId(ReminderConfig.reminderUser.getUserID());
                if (reminderTimeItem.getReminderType().equalsIgnoreCase("Morning Tea"))
                    reminderTimeItem.setReminderTime("06:00 AM");
                else if (reminderTimeItem.getReminderType().equalsIgnoreCase("Breakfast"))
                    reminderTimeItem.setReminderTime("08:00 AM");
                else if (reminderTimeItem.getReminderType().equalsIgnoreCase("Morning Snack"))
                    reminderTimeItem.setReminderTime("11:00 AM");
                else if (reminderTimeItem.getReminderType().equalsIgnoreCase("Lunch"))
                    reminderTimeItem.setReminderTime("02:00 PM");
                else if (reminderTimeItem.getReminderType().equalsIgnoreCase("Evening"))
                    reminderTimeItem.setReminderTime("05:00 PM");
                else if (reminderTimeItem.getReminderType().equalsIgnoreCase("Dinner"))
                    reminderTimeItem.setReminderTime("08:00 PM");
                else if (reminderTimeItem.getReminderType().equalsIgnoreCase("Bedtime Snack"))
                    reminderTimeItem.setReminderTime("10:00 PM");
                reminderTimeItemDao.update(reminderTimeItem);
            }


        } else {
            Utils.printLog("dao session", "dao session null");
        }

    }

}
