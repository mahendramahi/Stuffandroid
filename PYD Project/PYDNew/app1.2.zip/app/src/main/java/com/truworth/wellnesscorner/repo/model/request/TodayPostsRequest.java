package com.truworth.wellnesscorner.repo.model.request;

public class TodayPostsRequest {
    public int getPageIndex() {
        return PageIndex;
    }

    public void setPageIndex(int pageIndex) {
        PageIndex = pageIndex;
    }

    public int getPageSize() {
        return PageSize;
    }

    public void setPageSize(int pageSize) {
        PageSize = pageSize;
    }

    private int PageIndex;
    private int PageSize;
}
