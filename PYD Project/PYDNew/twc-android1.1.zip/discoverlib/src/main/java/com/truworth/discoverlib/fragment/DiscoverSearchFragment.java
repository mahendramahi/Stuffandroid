package com.truworth.discoverlib.fragment;

import android.app.SearchManager;
import android.content.Context;
import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.SearchView;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;

import com.truworth.discoverlib.utils.Constant;
import com.truworth.discoverlib.DiscoverActivity;
import com.truworth.discoverlib.R;
import com.truworth.discoverlib.R2;
import com.truworth.discoverlib.adapter.TabsViewPagerAdapter;
import com.truworth.discoverlib.interfaces.OnDiscoverSearchContentChangeListener;

import butterknife.BindView;

/**
 If this code works it was written by Somesh Kumar on 08 August, 2016. If not, I don't know who wrote it.
 */
public class DiscoverSearchFragment extends BaseFragment {
    @BindView(R2.id.tabLayout)
    TabLayout tabLayout;
    @BindView(R2.id.viewPager)
    ViewPager viewPager;

    private TabsViewPagerAdapter viewPagerAdapter;
    private SearchView searchView;
    private OnDiscoverSearchContentChangeListener mArticleSearchResultCallback;
    private OnDiscoverSearchContentChangeListener mSlideshowSearchResultCallback;
    private String articleType;
    private boolean isUserSubmitted = false;
    private String query = null;

    public static DiscoverSearchFragment newInstance() {
        return new DiscoverSearchFragment();
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);


        setupViewPager();
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.menu_discover_search_list, menu);
        final MenuItem searchItem = menu.findItem(R.id.action_search);
        SearchManager searchManager = (SearchManager) getActivity().getSystemService(Context.SEARCH_SERVICE);

        if (searchItem != null) {
            searchView = (SearchView) searchItem.getActionView();
        }
        if (searchView != null) {
            searchView.setSearchableInfo(searchManager.getSearchableInfo(getActivity().getComponentName()));
            searchView.setIconifiedByDefault(true);
            searchView.onActionViewExpanded();
            searchView.setQueryHint("Search");
            if (query != null) {
                searchView.setQuery(query, true);
            }
            searchView.setOnSearchClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    ((DiscoverActivity) getActivity()).hideToolbarTitle();
                }
            });

            searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
                @Override
                public boolean onQueryTextSubmit(String query) {
                    isUserSubmitted = true;
                    searchByKeywordInChildFragment(query, true);
                    return true;
                }

                @Override
                public boolean onQueryTextChange(String newText) {
                    query = newText;
                    return false;
                }
            });
        }

        super.onCreateOptionsMenu(menu, inflater);
    }

    private void setupViewPager() {
        viewPagerAdapter = new TabsViewPagerAdapter(getChildFragmentManager());

        DiscoverSearchListFragment discoverArticlesFragment = DiscoverSearchListFragment.newInstance();
        mArticleSearchResultCallback = (OnDiscoverSearchContentChangeListener) discoverArticlesFragment;

        DiscoverSearchListFragment discoverSlideshowFragment = DiscoverSearchListFragment.newInstance();
        mSlideshowSearchResultCallback = (OnDiscoverSearchContentChangeListener) discoverSlideshowFragment;

        viewPagerAdapter.addFragment(discoverArticlesFragment, "ARTICLES");
        viewPagerAdapter.addFragment(discoverSlideshowFragment, "SLIDESHOW");
    }

    @Override
    public int getFragmentLayout() {
        return R.layout.fragment_discover_search;
    }

    @Override
    public void onFragmentReady() {
        viewPager.setAdapter(viewPagerAdapter);
        tabLayout.setupWithViewPager(viewPager);
        viewPager.setOffscreenPageLimit(4);

        viewPager.addOnPageChangeListener(new ViewPager.SimpleOnPageChangeListener() {
            @Override
            public void onPageSelected(int position) {
                super.onPageSelected(position);
                switch (position) {
                    case 0: //ARTICLES
                        mArticleSearchResultCallback.onDiscoverSearchContentChange(searchView.getQuery().toString(), isUserSubmitted);
                        break;


                    case 1: //SLIDESHOW
                        mSlideshowSearchResultCallback.onDiscoverSearchContentChange(searchView.getQuery().toString(), isUserSubmitted);
                        break;
                }

            }
        });
    }

    private void searchByKeywordInChildFragment(String query, boolean isUserSubmitted) {
        switch (getCurrentTab()) {
            case 0: //ARTICLES
                mArticleSearchResultCallback.onDiscoverSearchContentChange(query, isUserSubmitted);
                break;

            case 1: //SLIDESHOW
                mSlideshowSearchResultCallback.onDiscoverSearchContentChange(query, isUserSubmitted);
                break;
        }

    }


    private int getCurrentTab() {
        return tabLayout.getSelectedTabPosition();
    }

    public String getArticleTypeForAPI() {
        int currantTab = getCurrentTab();
        switch (currantTab) {
            case 0:
                articleType = Constant.ARTICLE_TYPE_ARTICLES;
                break;

            case 1:
                articleType = Constant.ARTICLE_TYPE_SLIDESHOW_SEARCH;
                break;
        }
        return articleType;
    }
}
