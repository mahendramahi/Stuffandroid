package com.truworth.discoverlib.model;

/**
 * Created by PalakC on 5/18/2017.
 */

public class BaseMemberIdBody {
    private String MemberID;

    public String getMemberID() {
        return MemberID;
    }

    public void setMemberID(String memberID) {
        MemberID = memberID;
    }
}
