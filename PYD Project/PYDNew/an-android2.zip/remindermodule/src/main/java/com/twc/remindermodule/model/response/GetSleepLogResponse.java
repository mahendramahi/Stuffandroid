package com.twc.remindermodule.model.response;

import java.util.List;

/**
 * Created by PalakC on 1/19/2018.
 */

public class GetSleepLogResponse {

    private int status;
    private List<DataSleepLogItem> data;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public List<DataSleepLogItem> getData() {
        return data;
    }

    public void setData(List<DataSleepLogItem> data) {
        this.data = data;
    }

    public static class DataSleepLogItem {
        private int SleepLogID;
        private String SleepLog_DateTime;
        private String SleepLog_WakeUpTime;
        private String SleepLog_Remarks;
        private int SleepLog_Feel;

        public int getSleepLogID() {
            return SleepLogID;
        }

        public void setSleepLogID(int SleepLogID) {
            this.SleepLogID = SleepLogID;
        }

        public String getSleepLog_DateTime() {
            return SleepLog_DateTime;
        }

        public void setSleepLog_DateTime(String SleepLog_DateTime) {
            this.SleepLog_DateTime = SleepLog_DateTime;
        }

        public String getSleepLog_WakeUpTime() {
            return SleepLog_WakeUpTime;
        }

        public void setSleepLog_WakeUpTime(String SleepLog_WakeUpTime) {
            this.SleepLog_WakeUpTime = SleepLog_WakeUpTime;
        }

        public String getSleepLog_Remarks() {
            return SleepLog_Remarks;
        }

        public void setSleepLog_Remarks(String SleepLog_Remarks) {
            this.SleepLog_Remarks = SleepLog_Remarks;
        }

        public int getSleepLog_Feel() {
            return SleepLog_Feel;
        }

        public void setSleepLog_Feel(int SleepLog_Feel) {
            this.SleepLog_Feel = SleepLog_Feel;
        }
    }
}
