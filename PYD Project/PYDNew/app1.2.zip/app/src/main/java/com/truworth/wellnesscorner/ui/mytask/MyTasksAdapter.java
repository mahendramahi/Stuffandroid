package com.truworth.wellnesscorner.ui.mytask;

import android.animation.ObjectAnimator;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.BounceInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.truworth.wellnesscorner.R;
import com.truworth.wellnesscorner.customviews.CustomTextView;
import com.truworth.wellnesscorner.model.MemberProgramTaskDetailItem;
import com.truworth.wellnesscorner.utils.CommonUtils;

import java.util.List;
import java.util.Locale;

import at.blogc.android.views.ExpandableTextView;

/**
 * Created by richas on 2/16/2018.
 */

public class MyTasksAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private Activity context;
    private List<MemberProgramTaskDetailItem> myTaskList;
    private MyTasksFragment fragment;

    public MyTasksAdapter(Activity context, List<MemberProgramTaskDetailItem> myTaskList, MyTasksFragment fragment) {
        this.context = context;
        this.myTaskList = myTaskList;
        this.fragment= fragment;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.row_task_card_layout, parent, false);

        return new ItemViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        ItemViewHolder itemViewHolder = (ItemViewHolder) holder;

        MemberProgramTaskDetailItem taskDetailItem = myTaskList.get(position);

        itemViewHolder.tvCalories.setVisibility(View.GONE);
        itemViewHolder.tvVeg.setVisibility(View.GONE);
        itemViewHolder.tvTaskPeps.setVisibility(View.VISIBLE);
        itemViewHolder.tvTaskDays.setVisibility(View.VISIBLE);

        // set data
        itemViewHolder.tvTaskName.setText(taskDetailItem.getItemName());
        if(taskDetailItem.getItemDesc().isEmpty())
            itemViewHolder.tvTaskDescription.setVisibility(View.GONE);
        else
            itemViewHolder.tvTaskDescription.setVisibility(View.VISIBLE);
        itemViewHolder.tvTaskDescription.setText(taskDetailItem.getItemDesc());
        itemViewHolder.tvTaskPeps.setText(String.format(Locale.getDefault(),"%d PEPs", taskDetailItem.getItemPoints()));
        itemViewHolder.tvTaskType.setText(taskDetailItem.getItemType());
        itemViewHolder.tvTaskDays.setText(String.format(Locale.getDefault(),"Day %d", taskDetailItem.getWorkshopLevel_Day()));
        if(taskDetailItem.getItemType().equalsIgnoreCase("ARTICLE"))
            itemViewHolder.viewTaskColor.setBackgroundColor(ContextCompat.getColor(context, R.color.color_04C7F3));
        else if(taskDetailItem.getItemType().equalsIgnoreCase("TASK"))
            itemViewHolder.viewTaskColor.setBackgroundColor(ContextCompat.getColor(context, R.color.color_A580E8));
        else if(taskDetailItem.getItemType().equalsIgnoreCase("PDF"))
            itemViewHolder.viewTaskColor.setBackgroundColor(ContextCompat.getColor(context, R.color.color_FF9AAD));
        else if(taskDetailItem.getItemType().equalsIgnoreCase("Exercise"))
            itemViewHolder.viewTaskColor.setBackgroundColor(ContextCompat.getColor(context, R.color.color_58DAB6));
        else
            itemViewHolder.viewTaskColor.setBackgroundColor(ContextCompat.getColor(context, R.color.color_A0A3B8));

       /* if(! myTaskList.get(position).getItemType().equalsIgnoreCase(Constant.TASK)){
            itemViewHolder.swipeLayout.setLockDrag(true);
        }*/
        // Bind your data here
        itemViewHolder.bind(taskDetailItem);
    }


    @Override
    public int getItemCount() {
        return (null != myTaskList ? myTaskList.size() : 0);
    }

    private void setRedirection(MemberProgramTaskDetailItem taskDetailItem) {
        Bundle bundle = new Bundle();
        if (taskDetailItem.getItemType().equalsIgnoreCase("ARTICLE")) {
            fragment.completeTaskApiWithRedirection(taskDetailItem.getMemberPID(), taskDetailItem.getItemType(), taskDetailItem.getID(), taskDetailItem.getItemName(), taskDetailItem.getWorkshopLevel_ID(), taskDetailItem.getURL());
        } else if (taskDetailItem.getItemType().equalsIgnoreCase("VitalsTracker")) {
            String mItemName = taskDetailItem.getItemName();
            if (mItemName.equalsIgnoreCase("BP Tracker")) {
                bundle.putString("trackerAddReading", context.getString(R.string.tacker_bp));
                fragment.launchTracker(bundle, taskDetailItem.getMemberPID(), taskDetailItem.getItemType(), taskDetailItem.getID(), taskDetailItem.getItemName(), taskDetailItem.getWorkshopLevel_ID());
            } else if (mItemName.equalsIgnoreCase("Diabetes Tracker")) {
                bundle.putString("trackerAddReading", context.getString(R.string.tracker_bg));
                fragment.launchTracker(bundle, taskDetailItem.getMemberPID(), taskDetailItem.getItemType(), taskDetailItem.getID(), taskDetailItem.getItemName(), taskDetailItem.getWorkshopLevel_ID());
            } else if (mItemName.equalsIgnoreCase("Lipid(Cholesterol) Tracker")) {
                bundle.putString("trackerAddReading", context.getString(R.string.tracker_cholesterol));
                fragment.launchTracker(bundle, taskDetailItem.getMemberPID(), taskDetailItem.getItemType(), taskDetailItem.getID(), taskDetailItem.getItemName(), taskDetailItem.getWorkshopLevel_ID());
            } else if (mItemName.equalsIgnoreCase("Thyroid Tracker")) {
                bundle.putString("trackerAddReading", context.getString(R.string.tracker_tsh));
                fragment.launchTracker(bundle, taskDetailItem.getMemberPID(), taskDetailItem.getItemType(), taskDetailItem.getID(), taskDetailItem.getItemName(), taskDetailItem.getWorkshopLevel_ID());
            } else if (mItemName.equalsIgnoreCase("Weight Tracker")) {
                bundle.putString("AddWeight", "Currentweight");
                fragment.launchWeightTracker(bundle, taskDetailItem.getMemberPID(), taskDetailItem.getItemType(), taskDetailItem.getID(), taskDetailItem.getItemName(), taskDetailItem.getWorkshopLevel_ID());
            } else if (mItemName.equalsIgnoreCase("Calorie Tracker")) {
                fragment.launchFoodTracker(bundle, taskDetailItem.getMemberPID(), taskDetailItem.getItemType(), taskDetailItem.getID(), taskDetailItem.getItemName(), taskDetailItem.getWorkshopLevel_ID());
            } else if (mItemName.equalsIgnoreCase("Activity Tracker")) {
                // as discussed with aslam on 8 Nov 2017
                //bundle.putString("itemName", mItemName);
                bundle.putString("itemName", "");
                fragment.launchExerciseTracker(bundle, taskDetailItem.getMemberPID(), taskDetailItem.getItemType(), taskDetailItem.getID(), taskDetailItem.getItemName(), taskDetailItem.getWorkshopLevel_ID());
            } else if (mItemName.equalsIgnoreCase("Sleep Log")) {
                fragment.launchSleepTracker(bundle, taskDetailItem.getMemberPID(), taskDetailItem.getItemType(), taskDetailItem.getID(), taskDetailItem.getItemName(), taskDetailItem.getWorkshopLevel_ID());
            }
        } else if (taskDetailItem.getItemType().equalsIgnoreCase("Exercise")) {
            String mItemName = taskDetailItem.getItemName();
            bundle.putString("itemName", mItemName);
            fragment.launchExerciseTracker(bundle, taskDetailItem.getMemberPID(), taskDetailItem.getItemType(), taskDetailItem.getID(), taskDetailItem.getItemName(), taskDetailItem.getWorkshopLevel_ID());
        } else if (taskDetailItem.getItemType().equalsIgnoreCase("PDF")) {
            Intent pdfOpenintent = new Intent(Intent.ACTION_VIEW);
            pdfOpenintent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            pdfOpenintent.setDataAndType(Uri.parse(taskDetailItem.getURL()), "application/pdf");
            try {
                context.startActivity(pdfOpenintent);
            } catch (ActivityNotFoundException e) {

            }
            fragment.completeTaskApiWithRedirection(taskDetailItem.getMemberPID(), taskDetailItem.getItemType(), taskDetailItem.getID(), taskDetailItem.getItemName(), taskDetailItem.getWorkshopLevel_ID(), taskDetailItem.getURL());
        }
    }

    private void doBounceAnimation(View targetView) {
        ObjectAnimator animator = ObjectAnimator.ofFloat(targetView, "translationY", 0, 0, 15);
        animator.setInterpolator(new BounceInterpolator());
        animator.setStartDelay(500);
        animator.setDuration(1500);
        animator.start();
    }

    public class ItemViewHolder extends RecyclerView.ViewHolder {

        LinearLayout llExpandable;
        CustomTextView tvTaskName;
        ExpandableTextView tvTaskDescription;
        CustomTextView tvTaskPeps;
        CustomTextView tvTaskDays;
        CustomTextView tvCalories;
        CustomTextView tvVeg;
        CustomTextView tvTaskType;
        CustomTextView tvIdidIt;
        CustomTextView tvDismiss;
        View viewTaskColor;
        LinearLayout llTaskButtons;
        CardView cardTask;
        SwipeRevealLayout swipeLayout;
        ImageView ivCheck, ivSearch, ivDelete;
        FrameLayout frameLayout;


        public ItemViewHolder(View itemView) {
            super(itemView);
            frameLayout = itemView.findViewById(R.id.frameLayout);
            swipeLayout = itemView.findViewById(R.id.swipeLayout);
            ivCheck = itemView.findViewById(R.id.ivCheck);
            ivSearch = itemView.findViewById(R.id.ivSearch);
            ivDelete = itemView.findViewById(R.id.ivDelete);
            tvTaskName = itemView.findViewById(R.id.tvTaskName);
            tvTaskDescription = itemView.findViewById(R.id.tvTaskDescription);
            tvTaskPeps = itemView.findViewById(R.id.tvTaskPeps);
            tvTaskDays = itemView.findViewById(R.id.tvTaskDays);
            tvCalories = itemView.findViewById(R.id.tvCalories);
            tvVeg = itemView.findViewById(R.id.tvVeg);
            tvTaskType = itemView.findViewById(R.id.tvTaskType);
            tvIdidIt = itemView.findViewById(R.id.tvIdidIt);
            tvDismiss = itemView.findViewById(R.id.tvDismiss);
            viewTaskColor = itemView.findViewById(R.id.viewTaskColor);
            llTaskButtons = itemView.findViewById(R.id.llTaskButtons);
            cardTask = itemView.findViewById(R.id.cardTask);
            llExpandable = itemView.findViewById(R.id.llExpandable);
            // use set tag for collapse and expand
            frameLayout.setTag(0);

            frameLayout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    int expandStatus = Integer.parseInt(view.getTag().toString());

                    if(myTaskList.get(getAdapterPosition()).getItemType().equalsIgnoreCase("TASK")) {
                        if(expandStatus==0) {
                            frameLayout.setTag(1);
                            tvTaskDescription.expand();
                            AnimationFactory.expand(llTaskButtons);
                            doBounceAnimation(llExpandable);
                        }
                        else {
                            frameLayout.setTag(0);
                            tvTaskDescription.collapse();
                            AnimationFactory.collapse(llTaskButtons);
                        }
                    }
                    else {
                       setRedirection(myTaskList.get(getAdapterPosition()));
                    }
                }
            });
        }

        public void bind(MemberProgramTaskDetailItem taskDetailItem) {
            ivCheck.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    fragment.completeTaskApiCall(taskDetailItem.getMemberPID(), taskDetailItem.getItemType(), taskDetailItem.getID(), taskDetailItem.getItemName(), taskDetailItem.getWorkshopLevel_ID(), taskDetailItem.getURL());
                }
            });

            ivSearch.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    if (myTaskList.get(getAdapterPosition()).getItemType().equalsIgnoreCase("TASK")) {
                        fragment.completeTaskApiWithRedirection(taskDetailItem.getMemberPID(), taskDetailItem.getItemType(), taskDetailItem.getID(), taskDetailItem.getItemName(), taskDetailItem.getWorkshopLevel_ID(), taskDetailItem.getURL());
                    }else
                    {
                        setRedirection(taskDetailItem);
                    }
                }
            });
            ivDelete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    CommonUtils.showAlertDialog(context, context.getString(R.string.app_name), 0, "Are you sure you want to delete this task", context.getString(R.string.str_yes), new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            fragment.deleteTaskApiCall(myTaskList.get(getAdapterPosition()),taskDetailItem.getMemberPID(), taskDetailItem.getItemType(), taskDetailItem.getID(), taskDetailItem.getItemName(), taskDetailItem.getWorkshopLevel_ID(), taskDetailItem.getURL());
                        }
                    }, context.getString(R.string.no),false);

                }
            });
            tvIdidIt.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (myTaskList.get(getLayoutPosition()).getItemType().equalsIgnoreCase("TASK")) {
                        fragment.completeTaskApiWithRedirection(taskDetailItem.getMemberPID(), taskDetailItem.getItemType(), taskDetailItem.getID(), taskDetailItem.getItemName(), taskDetailItem.getWorkshopLevel_ID(), taskDetailItem.getURL());
                    }
                }
            });
            tvDismiss.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    fragment.deleteTaskApiCall(myTaskList.get(getAdapterPosition()),taskDetailItem.getMemberPID(), taskDetailItem.getItemType(), taskDetailItem.getID(), taskDetailItem.getItemName(), taskDetailItem.getWorkshopLevel_ID(), taskDetailItem.getURL());
                }
            });
        }
    }
 }

