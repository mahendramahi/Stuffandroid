package com.truworth.wellnesscorner.ui.mainapp.createpost.sharemeal;

import android.content.Context;
import android.databinding.DataBindingUtil;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;

import com.truworth.wellnesscorner.R;
import com.truworth.wellnesscorner.databinding.RowShareMealDetailBinding;
import com.truworth.wellnesscorner.model.FoodsBean;

import java.util.List;

public class ShareMealDetailAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private List<FoodsBean> foodList;
    private Context context;
    private AdapterCallback mAdapterCallback;

    public ShareMealDetailAdapter(Context context, List<FoodsBean> foodList, AdapterCallback mAdapterCallback) {
        this.foodList = foodList;
        this.context = context;
        this.mAdapterCallback = mAdapterCallback;
    }
    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        RecyclerView.ViewHolder viewHolder = null;
        RowShareMealDetailBinding binding = DataBindingUtil.inflate(LayoutInflater.from(parent.getContext()), R.layout.row_share_meal_detail, parent, false);
        viewHolder = new ViewHolder(binding);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        ViewHolder viewHolder = (ViewHolder) holder;
        viewHolder.bind(foodList.get(position));
    }

    @Override
    public int getItemCount() {
        return foodList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private RowShareMealDetailBinding mBinding;


        public ViewHolder(RowShareMealDetailBinding binding) {
            super(binding.getRoot());
            mBinding = binding;
        }


        public void bind(@NonNull FoodsBean foodsBean) {

            ShareMealDetailItemViewModel viewModel = new ShareMealDetailItemViewModel(foodsBean);

            mBinding.setViewModel(viewModel);
            mBinding.executePendingBindings();
            CheckBox checkBoxFood= mBinding.ivCheck;

            /*checkBoxFood.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton compoundButton, boolean b) {

                    mAdapterCallback.onMethodCallback(getAdapterPosition(), b);
                    foodsBean.setItemChecked(b);
                }
            });*/
            mBinding.rootLayout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(mBinding.ivCheck.isChecked()){
                        mBinding.ivCheck.setChecked(false);
                        mAdapterCallback.onMethodCallback(getAdapterPosition(), false);
                        foodsBean.setItemChecked(false);
                    }
                    else{
                        mBinding.ivCheck.setChecked(true);
                        mAdapterCallback.onMethodCallback(getAdapterPosition(), true);
                        foodsBean.setItemChecked(true);
                    }
                }
            });
        }
    }
}
