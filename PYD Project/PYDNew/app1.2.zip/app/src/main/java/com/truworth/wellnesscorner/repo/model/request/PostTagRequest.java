package com.truworth.wellnesscorner.repo.model.request;

public class PostTagRequest extends BaseRequest {
    String SearchTerm;
    public String getSearchTerm() {
        return SearchTerm;
    }
    public void setSearchTerm(String searchTerm) {
        SearchTerm = searchTerm;
    }
}
