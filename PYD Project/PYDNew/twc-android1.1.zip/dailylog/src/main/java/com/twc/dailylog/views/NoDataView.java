package com.twc.dailylog.views;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.twc.dailylog.R;


/**
 * Created by ManishJ1 on 3/27/2017.
 */

public class NoDataView extends LinearLayout {

    private ImageView imageView;
    private TextView titleTextView;
    private TextView subTitleView;

    public NoDataView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        TypedArray a = context.getTheme().obtainStyledAttributes(
                attrs,
                R.styleable.NoDataView,
                0, 0);
        String titleText = a.getString(R.styleable.NoDataView_title);
        String subTitleText = a.getString(R.styleable.NoDataView_subtitle);
        Drawable d = null;
        TypedValue value = a.peekValue(R.styleable.NoDataView_src);
        if (value != null) {
            d = a.getDrawable(R.styleable.NoDataView_src);
        }
        a.recycle();
        setOrientation(LinearLayout.VERTICAL);
        setGravity(Gravity.CENTER_VERTICAL);
        setBackgroundColor(Color.WHITE);

        LayoutInflater inflater = (LayoutInflater) context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        inflater.inflate(R.layout.view_no_data, this, true);
        imageView = (ImageView) getChildAt(0);

        if (d != null) {
            setImageIcon(d);
        }
        titleTextView = (TextView) getChildAt(1);
        setTitleView(titleText);
        subTitleView = (TextView) getChildAt(2);
        setSubTitleView(subTitleText);
    }

    public NoDataView(Context context) {
        super(context);
    }

    public static Bitmap getDrawable(Resources res, int id) {
        return BitmapFactory.decodeStream(res.openRawResource(id));
    }

    public void setTitleView(String title) {
        titleTextView.setText(title);
    }

    public void setSubTitleView(String subTitle) {
        subTitleView.setText(subTitle);
    }

    public void setImageIcon(Drawable drawable) {
        imageView.setImageDrawable(drawable);
    }


}
