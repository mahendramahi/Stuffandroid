package com.truworth.wellnesscorner.model;

/**
 * Created by PalakC on 4/19/2018.
 */

public class Discussions {
    private int postID;
    private String member_Image;
    private String questionTitle;
    private String questionCategory;
    private String answer;
    private String answeredBy;
    private String answeredByBio;
    private int reputationScore;
    private int answerUpvotes;
    private String answeredOn;
    private int questionIsModerated;
    private int answerID;
    private boolean isBookmarked;
    private boolean isUpvoted_ans;

    public int getPostID() {
        return postID;
    }

    public void setPostID(int postID) {
        this.postID = postID;
    }

    public String getMember_Image() {
        return member_Image;
    }

    public void setMember_Image(String member_Image) {
        this.member_Image = member_Image;
    }

    public String getQuestionTitle() {
        return questionTitle;
    }

    public void setQuestionTitle(String questionTitle) {
        this.questionTitle = questionTitle;
    }

    public String getQuestionCategory() {
        return questionCategory;
    }

    public void setQuestionCategory(String questionCategory) {
        this.questionCategory = questionCategory;
    }

    public String getAnswer() {
        return answer;
    }

    public void setAnswer(String answer) {
        this.answer = answer;
    }

    public String getAnsweredBy() {
        return answeredBy;
    }

    public void setAnsweredBy(String answeredBy) {
        this.answeredBy = answeredBy;
    }

    public String getAnsweredByBio() {
        return answeredByBio;
    }

    public void setAnsweredByBio(String answeredByBio) {
        this.answeredByBio = answeredByBio;
    }

    public int getReputationScore() {
        return reputationScore;
    }

    public void setReputationScore(int reputationScore) {
        this.reputationScore = reputationScore;
    }

    public int getAnswerUpvotes() {
        return answerUpvotes;
    }

    public void setAnswerUpvotes(int answerUpvotes) {
        this.answerUpvotes = answerUpvotes;
    }

    public String getAnsweredOn() {
        return answeredOn;
    }

    public void setAnsweredOn(String answeredOn) {
        this.answeredOn = answeredOn;
    }

    public int getQuestionIsModerated() {
        return questionIsModerated;
    }

    public void setQuestionIsModerated(int questionIsModerated) {
        this.questionIsModerated = questionIsModerated;
    }

    public int getAnswerID() {
        return answerID;
    }

    public void setAnswerID(int answerID) {
        this.answerID = answerID;
    }

    public boolean isIsBookmarked() {
        return isBookmarked;
    }

    public void setIsBookmarked(boolean isBookmarked) {
        this.isBookmarked = isBookmarked;
    }

    public boolean getIsUpvoted_ans() {
        return isUpvoted_ans;
    }

    public void setIsUpvoted_ans(boolean isUpvoted_ans) {
        this.isUpvoted_ans = isUpvoted_ans;
    }

}
