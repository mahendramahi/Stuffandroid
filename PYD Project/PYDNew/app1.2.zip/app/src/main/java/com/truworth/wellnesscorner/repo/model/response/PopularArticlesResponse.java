package com.truworth.wellnesscorner.repo.model.response;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.truworth.wellnesscorner.model.Article;

import java.util.ArrayList;

/**
 * Created by rajeshs on 4/13/2018.
 */

public class PopularArticlesResponse {
    @SerializedName("data")
    @Expose
    private ArrayList<Article> data;

    @SerializedName("hasError")
    @Expose
    private boolean hasError;



    public boolean isHasError() {
        return hasError;
    }

    public void setHasError(boolean hasError) {
        this.hasError = hasError;
    }

    public Error getError() {
        return error;
    }

    public void setError(Error error) {
        this.error = error;
    }

    @SerializedName("error")
    @Expose
    private Error error;

    public ArrayList<Article> getData() {
        return data;
    }

    public void setData(ArrayList<Article> data) {
        this.data = data;
    }
}
