package com.truworth.wellnesscorner.ui.step;

import android.app.Activity;
import android.app.Fragment;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.content.ContextCompat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.truworth.stepmodule.StepConnectionHelper;
import com.truworth.stepmodule.inteface.OnConnectionResultInfo;
import com.truworth.wellnesscorner.R;
import com.truworth.wellnesscorner.TheWellnessCornerApp;
import com.truworth.wellnesscorner.customviews.CustomTextView;
import com.truworth.wellnesscorner.data.SharedPreferenceHelper;
import com.truworth.wellnesscorner.utils.AppConstants;
import com.truworth.wellnesscorner.utils.CommonUtils;
import com.truworth.wellnesscorner.utils.DateUtils;
import com.truworth.wellnesscorner.utils.Utils;

import java.util.Locale;

import javax.inject.Inject;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class StepTrackerSettingFragment extends Fragment implements OnConnectionResultInfo {
    @BindView(R.id.rootLayout)
    LinearLayout rootLayout;
    @BindView(R.id.tvDeviceName)
    CustomTextView tvDeviceName;
    @BindView(R.id.tvLastSyncDate)
    CustomTextView tvLastSyncDate;
    @BindView(R.id.tvSyncDevice)
    CustomTextView tvSyncDevice;
    @BindView(R.id.tvConnectStatus)
    CustomTextView tvConnectStatus;
    @BindView(R.id.tvTapToRetry)
    CustomTextView tvTapToRetry;
    @BindView(R.id.ivDevice)
    ImageView ivDevice;
    @BindView(R.id.connectDeviceLayout)
    LinearLayout connectDeviceLayout;
    @BindView(R.id.stepsTimePeriodLayout)
    LinearLayout stepsTimePeriodLayout;
    private StepServerResponse homeDashboardResponse;
    private static final int GOOGLE_FITNESS_REQUEST_CODE = 9010;

    private int GOOGLE_OAUTH_REQUEST_CODE = 9011;
    private int MISFIT_REQUEST_CODE = 9012;
    private int FITBIT_REQUEST_CODE = 9013;

    @Inject
    SharedPreferenceHelper prefHelper;
    private StepConnectionHelper connectionHelper;

    public StepTrackerSettingFragment() {
        TheWellnessCornerApp.getApp().component().inject(this);
    }
    public static StepTrackerSettingFragment newInstance() {
        return new StepTrackerSettingFragment();
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        connectionHelper = new StepConnectionHelper(getActivity(), this);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_steps_tracker_setting, container, false);
        ButterKnife.bind(this, rootView);

        setDeviceConnectStatus(false);

        homeDashboardResponse = TheWellnessCornerApp.getInstance().getStepServerResponse();
        if (homeDashboardResponse != null && homeDashboardResponse.getData() != null) {
            if (homeDashboardResponse.getData().getLastConnectedDevice() != null) {
                tvDeviceName.setText(homeDashboardResponse.getData().getLastConnectedDevice());
                if (homeDashboardResponse.getData().getLastConnectedDevice().contains("Apple"))
                    ivDevice.setImageResource(R.drawable.ic_apple_health_icon);
                else if (homeDashboardResponse.getData().getLastConnectedDevice().equalsIgnoreCase(AppConstants.FITBIT))
                    ivDevice.setImageResource(R.drawable.fitbit_logo);
                else if (homeDashboardResponse.getData().getLastConnectedDevice().equalsIgnoreCase(AppConstants.S_HEALTH))
                    ivDevice.setImageResource(R.drawable.ic_samsung_health);
                else if (homeDashboardResponse.getData().getLastConnectedDevice().equalsIgnoreCase(AppConstants.GOOGLE_FIT))
                    ivDevice.setImageResource(R.drawable.ic_google_fit);
                else if (homeDashboardResponse.getData().getLastConnectedDevice().equalsIgnoreCase(AppConstants.E_FIT))
                    ivDevice.setImageResource(R.drawable.ic_efit);
                else if (homeDashboardResponse.getData().getLastConnectedDevice().equalsIgnoreCase(AppConstants.MISFIT))
                    ivDevice.setImageResource(R.drawable.ic_misfit_logo);
                else if (homeDashboardResponse.getData().getLastConnectedDevice().equalsIgnoreCase(AppConstants.GARMIN))
                    ivDevice.setImageResource(R.drawable.ic_misfit_logo);

            }
            if (homeDashboardResponse.getData().getLastStepSyncDate() != null)
                tvLastSyncDate.setText(String.format(Locale.getDefault(), "Last Synced: %s", DateUtils.showDateTimeUsingServerFormatDate(homeDashboardResponse.getData().getLastStepUpdatedDate())));

            if (prefHelper.getPrefKeyDeviceConnected() != null
                    && prefHelper.getPrefKeyDeviceConnected().length() > 0) {
                setDeviceConnectStatus(true);
            }
        }
        return rootView;
    }
    @Override
    public void onResume() {
        super.onResume();
        ((StepActivity) getActivity()).setToolBarTitle("Step Tracker Settings");
        ((StepActivity) getActivity()).showHomeAsUpEnableToolbar();
    }

    private void setDeviceConnectStatus(boolean status) {
        if (status) {
            tvConnectStatus.setText("Connected");
            tvConnectStatus.setTextColor(ContextCompat.getColor(getActivity(), R.color.colorPrimary));
            tvTapToRetry.setVisibility(View.GONE);
        } else {
            tvConnectStatus.setText("Disconnected");
            tvConnectStatus.setTextColor(ContextCompat.getColor(getActivity(), R.color.color_fa6363));
            tvTapToRetry.setVisibility(View.VISIBLE);
        }
    }
    @OnClick({R.id.tvTapToRetry, R.id.tvSyncDevice, R.id.stepsTimePeriodLayout})
    public void onClick(View view) {
        switch (view.getId()) {
           /* case R.id.connectDeviceLayout:
                String connectedDevice = "";
                boolean isConnected = false;
                if (!isConnected) {
                    Bundle bundle = new Bundle();
                    bundle.putString(Constant.BUNDLE_KEY_DEVICE_NAME, connectedDevice);
                    Utils.replaceFragment(getActivity().getFragmentManager(), ConnectDeviceDetailFragment.newInstance(bundle), ConnectDeviceDetailFragment.class.getSimpleName(), true, R.id.fragmentContainer);
                }
                break;*/
            case R.id.tvSyncDevice:
                if (homeDashboardResponse != null && homeDashboardResponse.getData() != null && homeDashboardResponse.getData().getLastConnectedDevice() != null) {
                    String msg = String.format(getString(R.string.step_already_connected), homeDashboardResponse.getData().getLastConnectedDevice());
                    CommonUtils.showAlertDialog(getActivity(), getString(R.string.app_name), 0, msg, "Proceed", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            dialogInterface.dismiss();
                            Utils.replaceFragment(getFragmentManager(), ConnectDeviceListFragment.newInstance(null), ConnectDeviceListFragment.class.getSimpleName(), true, R.id.fragmentContainer);
                        }
                    }, "Cancel", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            dialogInterface.dismiss();

                        }
                    }, false);
                } else {
                    Utils.replaceFragment(getFragmentManager(), ConnectDeviceListFragment.newInstance(null), ConnectDeviceListFragment.class.getSimpleName(), true, R.id.fragmentContainer);
                }
                break;
            case R.id.stepsTimePeriodLayout:
                if (prefHelper.getPrefKeyDeviceConnected() != null
                        && prefHelper.getPrefKeyDeviceConnected().length() > 0) {
                    Utils.replaceFragment(getFragmentManager(), SyncStepsFragment.newInstance(), SyncStepsFragment.class.getSimpleName(), true, R.id.fragmentContainer);
                } else {
                    CommonUtils.showAlertDialog(getActivity(), getString(R.string.app_name), 0, "Please connect your device before sync steps.", getString(R.string.str_ok), false);
                }
                break;
            case R.id.tvTapToRetry:
                if (tvConnectStatus.getText().toString().equalsIgnoreCase("Disconnected")) {
                    if (homeDashboardResponse != null && homeDashboardResponse.getData() != null) {
                        if (homeDashboardResponse.getData().getLastConnectedDevice() != null) {
                            if (homeDashboardResponse.getData().getLastConnectedDevice().contains("Apple")) {
                                CommonUtils.showAlertDialog(getActivity(), getString(R.string.app_name), 0, homeDashboardResponse.getData().getLastConnectedDevice() + " is not compatible. Please setup a new device.", getString(R.string.str_ok), false);
                            } else {
                                connectDevice(homeDashboardResponse.getData().getLastConnectedDevice());
                            }
                        } else {
                            Utils.replaceFragment(getFragmentManager(), ConnectDeviceListFragment.newInstance(null), ConnectDeviceListFragment.class.getSimpleName(), true, R.id.fragmentContainer);
                        }
                    } else
                        Utils.replaceFragment(getFragmentManager(), ConnectDeviceListFragment.newInstance(null), ConnectDeviceListFragment.class.getSimpleName(), true, R.id.fragmentContainer);
                }
                break;
        }
    }

    private void connectDevice(String deviceName) {
        switch (deviceName) {
            case AppConstants.S_HEALTH:

                connectSamsungHealth();
                break;

            case AppConstants.FITBIT:
                connectFitbit();
                break;
            case AppConstants.GOOGLE_FIT:
                connectGoogleFit();
                break;
            case AppConstants.E_FIT:
                Bundle bundle = new Bundle();
                bundle.putBoolean("isRedirectFromRecommendation", false);
                bundle.putBoolean("isRedirectFromStepTrackerSetting", true);
                Utils.replaceFragment(getFragmentManager(), EFitLoginFragment.newInstance(bundle), EFitLoginFragment.class.getSimpleName(), true, R.id.fragmentContainer);
                break;
            case AppConstants.MISFIT:
                connectMisFit();
                break;
            case AppConstants.GARMIN:

                break;
        }
    }
    private void connectMisFit() {

            connectionHelper.startMisfitProcess(MISFIT_REQUEST_CODE);

    }

    private void connectFitbit() {

            connectionHelper.startFitbitProcess(FITBIT_REQUEST_CODE);

    }

    private void connectGoogleFit(){

            connectionHelper.startGoogleFitProcess(GOOGLE_OAUTH_REQUEST_CODE, GOOGLE_FITNESS_REQUEST_CODE);

    }
    private void connectSamsungHealth(){

            connectionHelper.startSamsungProcess();

    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == GOOGLE_OAUTH_REQUEST_CODE) {
                connectionHelper.requestGoogleFitnessPermission();
            } else if (requestCode == GOOGLE_FITNESS_REQUEST_CODE) {
                connectionHelper.onGoogleFitPermissionGranted();
            } else if (requestCode == MISFIT_REQUEST_CODE) {
                String status = data.getStringExtra("misFitStatus");
                if (status.equalsIgnoreCase("success")) {
                    String deviceType = data.getStringExtra("device_type");
                    String token = data.getStringExtra("token");
                    connectionHelper.onMisFitPermissionGranted(deviceType, token);
                } else {
                    Toast.makeText(getActivity(), "Misfit connection error... Please try again", Toast.LENGTH_SHORT).show();
                }

            } else if (requestCode == FITBIT_REQUEST_CODE) {
                String status = data.getStringExtra("fitBitStatus");
                if (status.equalsIgnoreCase("success")) {
                    String deviceType = data.getStringExtra("device_type");
                    String token = data.getStringExtra("token");
                    connectionHelper.onFitbitPermissionGranted(deviceType, token);
                } else {
                    Toast.makeText(getActivity(), "fitbit connection error... Please try again", Toast.LENGTH_SHORT).show();
                }
            }
        }
    }


    @Override
    public void onResultInfo(String deviceType, String info) {
        //Toast.makeText(getActivity(), info, Toast.LENGTH_SHORT).show();

        if(deviceType.equalsIgnoreCase(AppConstants.FITBIT)){
            prefHelper.setPrefKeyFitBitAccessToken(info);
            prefHelper.setPrefKeyDeviceConnected(AppConstants.FITBIT);
            StepsTrackerFragment stepsTrackerFragment = (StepsTrackerFragment) getActivity().getFragmentManager().findFragmentByTag(StepsTrackerFragment.class.getSimpleName());

            if (stepsTrackerFragment == null) {
                stepsTrackerFragment = StepsTrackerFragment.newInstance();
                stepsTrackerFragment.setConnectedDeviceType(AppConstants.FITBIT);
                Utils.replaceFragment(getFragmentManager(), stepsTrackerFragment, StepsTrackerFragment.class.getSimpleName(), true, R.id.fragmentContainer);
            } else {
                stepsTrackerFragment.setConnectedDeviceType(AppConstants.FITBIT);
                getFragmentManager().popBackStackImmediate(StepsTrackerFragment.class.getSimpleName(), 0);
            }
        }
        else if(deviceType.equalsIgnoreCase(AppConstants.MISFIT)){
            prefHelper.setPrefKeyMisFitAccessToken(info);
            prefHelper.setPrefKeyDeviceConnected(AppConstants.MISFIT);
            StepsTrackerFragment stepsTrackerFragment = (StepsTrackerFragment) getActivity().getFragmentManager().findFragmentByTag(StepsTrackerFragment.class.getSimpleName());

            if (stepsTrackerFragment == null) {
                stepsTrackerFragment = StepsTrackerFragment.newInstance();
                stepsTrackerFragment.setConnectedDeviceType(AppConstants.MISFIT);
                Utils.replaceFragment(getFragmentManager(), stepsTrackerFragment, StepsTrackerFragment.class.getSimpleName(), true, R.id.fragmentContainer);
            } else {
                stepsTrackerFragment.setConnectedDeviceType(AppConstants.MISFIT);
                getFragmentManager().popBackStackImmediate(StepsTrackerFragment.class.getSimpleName(), 0);
            }
        }
        else if (deviceType.equalsIgnoreCase(AppConstants.S_HEALTH)){
            prefHelper.setPrefKeyDeviceConnected(AppConstants.S_HEALTH);
            prefHelper.clearDeviceConnectTokenPreferences();

            StepsTrackerFragment stepsTrackerFragment = (StepsTrackerFragment) getActivity().getFragmentManager().findFragmentByTag(StepsTrackerFragment.class.getSimpleName());

            if (stepsTrackerFragment == null) {
                stepsTrackerFragment = StepsTrackerFragment.newInstance();
                stepsTrackerFragment.setConnectedDeviceType(AppConstants.S_HEALTH);
                Utils.replaceFragment(getFragmentManager(), stepsTrackerFragment, StepsTrackerFragment.class.getSimpleName(), true, R.id.fragmentContainer);
            } else {
                stepsTrackerFragment.setConnectedDeviceType(AppConstants.S_HEALTH);
                getFragmentManager().popBackStackImmediate(StepsTrackerFragment.class.getSimpleName(), 0);
            }
        }
        else if(deviceType.equalsIgnoreCase(AppConstants.GOOGLE_FIT)){
            prefHelper.setPrefKeyDeviceConnected(AppConstants.GOOGLE_FIT);
            prefHelper.clearDeviceConnectTokenPreferences();

            StepsTrackerFragment stepsTrackerFragment = (StepsTrackerFragment) getActivity().getFragmentManager().findFragmentByTag(StepsTrackerFragment.class.getSimpleName());

            if (stepsTrackerFragment == null) {
                stepsTrackerFragment = StepsTrackerFragment.newInstance();
                stepsTrackerFragment.setConnectedDeviceType(AppConstants.GOOGLE_FIT);
                Utils.replaceFragment(getFragmentManager(), stepsTrackerFragment, StepsTrackerFragment.class.getSimpleName(), true, R.id.fragmentContainer);
            } else {
                stepsTrackerFragment.setConnectedDeviceType(AppConstants.GOOGLE_FIT);
                getFragmentManager().popBackStackImmediate(StepsTrackerFragment.class.getSimpleName(), 0);
            }
        }
        else if(deviceType.equalsIgnoreCase(AppConstants.E_FIT)){

        }

        // StepConfig.accessToken = info;


    }


    @Override
    public void onConnectionError(String error) {

    }
}
