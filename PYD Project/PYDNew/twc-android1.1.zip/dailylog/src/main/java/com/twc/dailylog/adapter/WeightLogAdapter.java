package com.twc.dailylog.adapter;

import android.app.Activity;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.twc.dailylog.R;
import com.twc.dailylog.model.beans.WeightLogItem;
import com.twc.dailylog.utils.DateFactory;
import com.twc.dailylog.utils.Utils;

import java.util.ArrayList;

public class WeightLogAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    Activity mActivity;
    private ArrayList<WeightLogItem> mWeightItems;
    private String date, dateString;

    public WeightLogAdapter(ArrayList<WeightLogItem> mWeightItems, Activity activity) {

        this.mWeightItems = mWeightItems;
        this.mActivity = activity;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.row_weightlog_item, parent, false);

        return new ItemViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {

        ItemViewHolder itemViewHolder = (ItemViewHolder) holder;

        //Format of date 2016-09-08T00:00:00
        dateString = DateFactory.getInstance().truncateMilliseconds(mWeightItems.get(position).getDate());
        date = DateFactory.getInstance().formatDate("yyyy-MM-dd'T'HH:mm:ss", "MMM dd, yyyy", dateString);
        //String logDate= DateFactory.getInstance().formatDateFromString("yyyy-MM-dd", "MMM dd, yyyy", date);;
        itemViewHolder.tvWeightLogDate.setText(date);
        double reading = (mWeightItems.get(position).getReading());
        // double readingValue = (int) reading;
        itemViewHolder.tvWeightLog.setText(Utils.doubleToString(reading) + " " + mWeightItems.get(position).getWeightUnit());
    }


    @Override
    public int getItemCount() {
        return (null != mWeightItems ? mWeightItems.size() : 0);
    }

    // ItemViewHolder Class for Items in each Section
    public class ItemViewHolder extends RecyclerView.ViewHolder {

        final TextView tvWeightLogDate;
        final TextView tvWeightLog;

        public ItemViewHolder(View itemView) {
            super(itemView);

            tvWeightLogDate = itemView.findViewById(R.id.tvWeightLogDate);
            tvWeightLog = itemView.findViewById(R.id.tvWeightLog);

            /*itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    Bundle bundle = new Bundle();
                    bundle.putInt("ID",0);//put 0 for the new activity id
                    bundle.putString("Name",mSuggestiontItems.get(getLayoutPosition()).getActivityName());
                    bundle.putInt("Duration",mSuggestiontItems.get(getLayoutPosition()).getExerciseDuration());
                    bundle.putDouble("CaloriesBurnedIn1Min",mSuggestiontItems.get(getLayoutPosition()).getTotalCaloriesBurned()/mSuggestiontItems.get(getLayoutPosition()).getExerciseDuration());
                    bundle.putString("redirectFrom", SuggestionExerciseFragment.class.getSimpleName());
                    bundle.putString("Time",DateFactory.getInstance().getCurrentTime("HH:mm aa"));
                    Utils.replaceFragment(mActivity.getFragmentManager(), TrackActivityFragment.newInstance(bundle), TrackActivityFragment.class.getSimpleName(), true, R.id.fragmentContainer);
                }
            });*/
        }

    }
}

