package com.truworth.wellnesscorner.model;

public class TodayMyChallenge {



    private String challengeIdentity;
    private String challengeName;



    private String circleIdentity;

    private String circleName;
    private String challengeStartDate;
    private String challengeEndDate;
    private int totalCheckIn;
    private int challengeTypeId;

    public String getChallengeIdentity() {
        return challengeIdentity;
    }

    public void setChallengeIdentity(String challengeIdentity) {
        this.challengeIdentity = challengeIdentity;
    }

    public String getChallengeName() {
        return challengeName;
    }

    public void setChallengeName(String challengeName) {
        this.challengeName = challengeName;
    }

    public String getChallengeStartDate() {
        return challengeStartDate;
    }

    public void setChallengeStartDate(String challengeStartDate) {
        this.challengeStartDate = challengeStartDate;
    }

    public String getChallengeEndDate() {
        return challengeEndDate;
    }

    public void setChallengeEndDate(String challengeEndDate) {
        this.challengeEndDate = challengeEndDate;
    }

    public int getTotalCheckIn() {
        return totalCheckIn;
    }

    public void setTotalCheckIn(int totalCheckIn) {
        this.totalCheckIn = totalCheckIn;
    }

    public int getChallengeTypeId() {
        return challengeTypeId;
    }
    public String getCircleName() {
        return circleName;
    }

    public void setCircleName(String circleName) {
        this.circleName = circleName;
    }
    public String getCircleIdentity() {
        return circleIdentity;
    }

    public void setCircleIdentity(String circleIdentity) {
        this.circleIdentity = circleIdentity;
    }
    public void setChallengeTypeId(int challengeTypeId) {
        this.challengeTypeId = challengeTypeId;
    }
}
