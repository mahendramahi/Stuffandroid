package com.twc.remindermodule.fragments;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;


import com.twc.remindermodule.R;
import com.twc.remindermodule.R2;
import com.twc.remindermodule.adapter.RecommendedHealthyHabitsAdapter;
import com.twc.remindermodule.model.requestbody.HealthyHabitBody;
import com.twc.remindermodule.model.requestbody.SaveMemberHabitBody;
import com.twc.remindermodule.model.response.HealthyHabitResponse;
import com.twc.remindermodule.model.response.SaveMemberHabitResponse;
import com.twc.remindermodule.rest.ReminderConfig;
import com.twc.remindermodule.rest.RestClient;
import com.twc.remindermodule.utils.DialogFactory;
import com.twc.remindermodule.utils.Utils;
import com.twc.remindermodule.views.CustomTextView;

import java.util.ArrayList;

import butterknife.BindView;
import butterknife.OnClick;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class RecommendedHealthyHabitsFragment extends BaseFragment {
    @BindView(R2.id.rvHealthyHabit)
    RecyclerView rvHealthyHabit;
    @BindView(R2.id.tvNext)
    CustomTextView tvNext;
    @BindView(R2.id.ivBack)
    ImageView ivBack;


    private RecommendedHealthyHabitsAdapter adapter;
    private HealthyHabitResponse healthyHabitResponse;

    public static RecommendedHealthyHabitsFragment newInstance(Bundle bundle) {
        RecommendedHealthyHabitsFragment fragment = new RecommendedHealthyHabitsFragment();
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


    }

    @Override
    public void onResume() {
        super.onResume();

    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
    }

    @Override
    public int getFragmentLayout() {
        return R.layout.fragment_select_healthy_habits;
    }

    @Override
    public void onFragmentReady() {

        rvHealthyHabit.setHasFixedSize(true);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getActivity());
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        rvHealthyHabit.setLayoutManager(linearLayoutManager);

        getMemberGoalHabitApiCall();
    }

    @OnClick({R2.id.tvNext, R2.id.ivBack})
    public void onClick(View view) {
        int i = view.getId();
        if (i == R.id.tvNext) {
            String CheckedIDs = getCheckedIds();
          if (CheckedIDs.equalsIgnoreCase("")) {
                DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.err_check_habit), getString(R.string.str_ok), false);
            } else {
                saveMemberHabitApiCall(CheckedIDs);
           }

        } else if (i == R.id.ivBack) {
            int count = getFragmentManager().getBackStackEntryCount();
            if (count == 1) {
                getActivity().setResult(Activity.RESULT_OK);
                getActivity().finish();
            } else {
                getActivity().getFragmentManager().popBackStack();
            }
        }
    }

    private String getCheckedIds() {
        String CheckedIDs = "";
        if (healthyHabitResponse.getData() != null) {
            for (int i = 0; i < healthyHabitResponse.getData().size(); i++) {
                if (healthyHabitResponse.getData().get(i).isIsSelected()) {
                    if (CheckedIDs.equalsIgnoreCase("")) {
                        CheckedIDs = String.valueOf(healthyHabitResponse.getData().get(i).getID());
                    } else {
                        CheckedIDs = CheckedIDs + "," + String.valueOf(healthyHabitResponse.getData().get(i).getID());
                    }
                }
            }
        }
        return CheckedIDs;
    }

    /************************************** Get Habit Api call**********************/
    private void getMemberGoalHabitApiCall() {
        //body
        HealthyHabitBody healthyHabitBody = new HealthyHabitBody();
        healthyHabitBody.setMemberID(ReminderConfig.reminderUser.getUserID());

        RestClient restClient = new RestClient(getActivity(), ReminderConfig.BASE_URL, ReminderConfig.DEBUG);
        restClient.getRecommendedService().getMemberGoalHabit(healthyHabitBody).enqueue(new Callback<HealthyHabitResponse>() {
            @Override
            public void onResponse(Call<HealthyHabitResponse> call, Response<HealthyHabitResponse> response) {

                if (isAdded() && getActivity() != null) {
                    if (response != null && response.body() != null) {
                        if (response.body().getStatus() == 0 && response.body().getData() != null) {
                            healthyHabitResponse = response.body();
                            adapter = new RecommendedHealthyHabitsAdapter(getActivity(), response.body().getData(), RecommendedHealthyHabitsFragment.this);
                            rvHealthyHabit.setAdapter(adapter);
                            adapter.notifyDataSetChanged();
                            String CheckedIDs = getCheckedIds();
                            if (CheckedIDs.equalsIgnoreCase("")) {
                                tvNext.setEnabled(false);
                            } else {
                                tvNext.setEnabled(true);
                                tvNext.setTextColor(ContextCompat.getColor(getActivity(), R.color.color_FFFFFF));
                            }

                        } else {
                            DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_response_failure), getString(R.string.str_ok), false);
                        }
                    } else {
                        DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_response_failure), getString(R.string.str_ok), false);
                    }
                }
            }

            @Override
            public void onFailure(Call<HealthyHabitResponse> call, Throwable t) {
                if (isAdded() && getActivity() != null) {
                    DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_failure), getString(R.string.str_ok), false);
                }
            }
        });
    }

    /************************************** Save Habit Api call**********************/
    private void saveMemberHabitApiCall(String checkedIDs) {

        //body
        SaveMemberHabitBody saveMemberHabitBody = new SaveMemberHabitBody();
        saveMemberHabitBody.setMemberId(Integer.parseInt(ReminderConfig.reminderUser.getUserID()));
        saveMemberHabitBody.setHabitIDs(checkedIDs);
        RestClient restClient = new RestClient(getActivity(), ReminderConfig.BASE_URL, ReminderConfig.DEBUG);
        restClient.getRecommendedService().saveMemberHabit(saveMemberHabitBody).enqueue(new Callback<SaveMemberHabitResponse>() {
            @Override
            public void onResponse(Call<SaveMemberHabitResponse> call, Response<SaveMemberHabitResponse> response) {

                if (isAdded() && getActivity() != null) {
                    if (response != null && response.body() != null) {
                        if (response.body().getStatus() == 0) {
                            Bundle bundle = new Bundle();
                            bundle.putBoolean("isRedirectFromSelectHabit", true);
                            if (getArguments().containsKey("isAddHabit"))
                                getFragmentManager().popBackStackImmediate();
                            else
                                Utils.replaceFragment(getFragmentManager(), RecommendedConfigureReminders.newInstance(bundle), RecommendedConfigureReminders.class.getSimpleName(), true, R.id.fragmentContainerReminder);

                        } else {
                            DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_response_failure), getString(R.string.str_ok), false);
                        }
                    } else {
                        DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_response_failure), getString(R.string.str_ok), false);
                    }
                }
            }

            @Override
            public void onFailure(Call<SaveMemberHabitResponse> call, Throwable t) {
                if (isAdded() && getActivity() != null) {
                    DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_failure), getString(R.string.str_ok), false);
                }
            }
        });
    }

    public void enableNextButton() {
        tvNext.setTextColor(ContextCompat.getColor(getActivity(), R.color.color_FFFFFF));
        tvNext.setEnabled(true);
    }
}
