package com.twc.store.fragments;

import android.content.DialogInterface;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;


import com.twc.store.R;
import com.twc.store.R2;
import com.twc.store.StoreActivity;
import com.twc.store.adapter.StoreProductsCategoryAdapter;
import com.twc.store.dialog.ApiErrorDialog;
import com.twc.store.dialog.NetworkErrorDialog;
import com.twc.store.interfaces.OnRetryAfterNetworkError;
import com.twc.store.model.beans.ProductItem;
import com.twc.store.model.beans.StoreDataBeanItem;
import com.twc.store.model.requestbody.BaseMemberIdBody;
import com.twc.store.model.requestbody.StoreProductsBody;
import com.twc.store.model.response.StoreCartCountResponse;
import com.twc.store.model.response.StoreProductResponse;
import com.twc.store.rest.RestClient;
import com.twc.store.utils.Constant;
import com.twc.store.utils.DialogFactory;
import com.twc.store.utils.NetworkFactory;
import com.twc.store.utils.StoreConfig;
import com.twc.store.utils.Utils;
import com.twc.store.views.CustomProgressDialog;
import com.twc.store.views.CustomTextView;

import java.util.ArrayList;
import java.util.Locale;

import butterknife.BindView;
import butterknife.OnClick;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * If this code works it was written by Somesh Kumar on 03 May, 2017. If not, I don't know who wrote it.
 */
// Last Updated on 05/02/2018 by richas implemented Error screens
public class StoreHomeFragment extends BaseFragment implements OnRetryAfterNetworkError {
    @BindView(R2.id.tvTabWellnessPlan)
    CustomTextView tvTabWellnessPlan;
    @BindView(R2.id.tvTabGymMembership)
    CustomTextView tvTabGymMembership;
    @BindView(R2.id.tvTabHealthProduct)
    CustomTextView tvTabHealthProduct;
    @BindView(R2.id.tvTabMedicine)
    CustomTextView tvTabMedicine;
    @BindView(R2.id.rvProductsCategoryList)
    RecyclerView rvProductsCategoryList;

    private CustomProgressDialog customProgressDialog;

    private boolean isApiCalled;

    private StoreProductsCategoryAdapter storeCategorylistAdapter;
    private ArrayList<StoreDataBeanItem> getStoreDataList;
    private Button notificationButton;
    private ImageView imgpendingFriend;
    private int cartItemCount;
    private int wellnessProductItmesPosition=-1, healthProductItmesPosition = -1;

    public static StoreHomeFragment newInstance() {
        return new StoreHomeFragment();
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRetainInstance(true);
        setHasOptionsMenu(true);
        getStoreDataList = new ArrayList<>();
        storeCategorylistAdapter = new StoreProductsCategoryAdapter(getStoreDataList, getActivity());
    }

    @Override
    public void onResume() {
        super.onResume();

        ((StoreActivity) getActivity()).showHomeAsUpEnableToolbar();
        ((StoreActivity) getActivity()).setToolBarTitle("Store");
    }


    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        menu.clear();

        inflater.inflate(R.menu.menu_save, menu);
        MenuItem menuItemRefresh = menu.findItem(R.id.action_save);

        menuItemRefresh = menuItemRefresh.setActionView(R.layout.pending_request_count);
        menuItemRefresh.setTitle("Notification");

        View view = menuItemRefresh.getActionView();
        RelativeLayout rlayout = view.findViewById(R.id.rlayout);
        notificationButton = view.findViewById(R.id.notif_count);
        imgpendingFriend = view.findViewById(R.id.imgpendingFriend);
        imgpendingFriend.setImageResource(R.drawable.ic_store_cartcount);

        notificationButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Utils.replaceFragment(getFragmentManager(), StoreMyCartFragment.newInstance(), StoreMyCartFragment.class.getSimpleName(), true, R.id.fragmentContainer);
            }
        });
        imgpendingFriend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Utils.replaceFragment(getFragmentManager(), StoreMyCartFragment.newInstance(), StoreMyCartFragment.class.getSimpleName(), true, R.id.fragmentContainer);
            }
        });
        getCartCountApiCall();
        super.onCreateOptionsMenu(menu, inflater);
    }

    @Override
    public int getFragmentLayout() {
        return R.layout.fragment_store_home;
    }

    @Override
    public void onFragmentReady() {

        ((StoreActivity) getActivity()).showHomeAsUpEnableToolbar();
        ((StoreActivity) getActivity()).setToolBarTitle("Store");

        LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity());
        rvProductsCategoryList.setLayoutManager(layoutManager);
        rvProductsCategoryList.setAdapter(storeCategorylistAdapter);


        if (!isApiCalled) {
            callGetProductsApi();
        } else {
            if (storeCategorylistAdapter != null) {
                storeCategorylistAdapter.notifyDataSetChanged();
            }
        }

    }

    private void callGetProductsApi() {
        if (NetworkFactory.getInstance().isNetworkAvailable(getActivity())) {
            customProgressDialog = new CustomProgressDialog(getActivity(), R.style.custom_progress_style, true);
            customProgressDialog.setCancelable(false);
            customProgressDialog.show();
            final StoreProductsBody storeProductsBody = new StoreProductsBody();
            RestClient restClient = new RestClient(getActivity(), StoreConfig.BASE_URL, StoreConfig.mdebug);

            restClient.getWellnessStoreService().getProducts(storeProductsBody).enqueue(new Callback<StoreProductResponse>() {
                @Override
                public void onResponse(Call<StoreProductResponse> call, Response<StoreProductResponse> response) {
                    if (getActivity() != null && isAdded()) {
                        customProgressDialog.dismiss();
                        if (response != null && response.body() != null) {
                            if (response.body().getStatus() == 0) {
                                isApiCalled = true;
                                if (response.body().getProducts().size() > 0) {
                                    getStoreDataList.addAll(response.body().getProducts());

                                    // used to show ic_store_healthy_plans and ic_store_gym_membership in list
                                    StoreDataBeanItem planItem = new StoreDataBeanItem();
                                    planItem.setCategoryId(-1); // set -1 static id for this
                                    getStoreDataList.add(1, planItem);
                                    // products distribution are based on categery id and vendor id as discuss with arvind sir on 18 jan 2018
                                    for (int i = 0; i < getStoreDataList.size(); i++) {
                                        // 1,1 for wellness plan
                                        if (getStoreDataList.get(i).getCategoryId() == 1 && getStoreDataList.get(i).getVendorId() == 1) {
                                            wellnessProductItmesPosition = i;
                                        }
                                        // 2,9 for healthy plan
                                        else if (getStoreDataList.get(i).getVendorId() == 2 && getStoreDataList.get(i).getCategoryId() == 9) {
                                            healthProductItmesPosition = i;
                                        }
                                    }
                                } else {
                                    // used to show ic_store_healthy_plans and ic_store_gym_membership in list
                                    StoreDataBeanItem planItem = new StoreDataBeanItem();
                                    planItem.setCategoryId(-1); // set -1 static id for this
                                    getStoreDataList.add(planItem);
                                }
                                storeCategorylistAdapter.notifyDataSetChanged();

                            } else if (response.body().getStatus() == -1) {
                                //DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_response_failure), getString(R.string.str_ok), false);
                                showApiErrorDialog();
                            }
                        } else {
                            //DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_response_null), getString(R.string.str_ok), false);
                            showApiErrorDialog();
                        }
                    }
                }

                @Override
                public void onFailure(Call<StoreProductResponse> call, Throwable t) {
                    if (getActivity() != null && isAdded()) {
                        customProgressDialog.dismiss();
                        //DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_failure), getString(R.string.str_ok), false);
                        showApiErrorDialog();
                    }
                }
            });
        } else {
            // show Network Error Screen Dialog
            NetworkErrorDialog networkErrorDialog = new NetworkErrorDialog(getActivity(), getActivity(), StoreHomeFragment.this);
            networkErrorDialog.show();
            Window window = networkErrorDialog.getWindow();
            window.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);
        }
    }

    // method to show Api Error Screen Dialog
    private void showApiErrorDialog() {
        ApiErrorDialog apiErrorDialog = new ApiErrorDialog(getActivity(), getActivity(), StoreHomeFragment.this);
        apiErrorDialog.show();
        Window window = apiErrorDialog.getWindow();
        window.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);
    }


    @OnClick({R2.id.tvTabWellnessPlan, R2.id.tvTabGymMembership, R2.id.tvTabHealthProduct, R2.id.tvTabMedicine})
    public void onViewClicked(View view) {


        if (view.getId() == R.id.tvTabWellnessPlan) {
            if (getStoreDataList != null && getStoreDataList.size() > 0) {
                if (wellnessProductItmesPosition == -1) {
                    ArrayList<ProductItem> planList = new ArrayList<>();
                    Utils.replaceFragment(getActivity().getFragmentManager(), StoreProductListingFragment.newInstance(Constant.WELLNESS_PLAN, planList), StoreProductListingFragment.class.getSimpleName(), true, R.id.fragmentContainer);
                } else {
                    Utils.replaceFragment(getActivity().getFragmentManager(), StoreProductListingFragment.newInstance(Constant.WELLNESS_PLAN, (ArrayList<ProductItem>) getStoreDataList.get(wellnessProductItmesPosition).getProduct()), StoreProductListingFragment.class.getSimpleName(), true, R.id
                            .fragmentContainer);
                }
            }


        } else if (view.getId() == R.id.tvTabGymMembership) {
            //DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, "Coming Soon!", "Ok", true);
            // Utils.replaceFragment(getActivity().getFragmentManager(), GympikCitiesDashboard.newInstance(), GympikCitiesDashboard.class.getSimpleName(), true, R.id.fragmentContainer);
        } else if (view.getId() == R.id.tvTabHealthProduct) {
            if (getStoreDataList != null && getStoreDataList.size() >= 0) {

                if(healthProductItmesPosition == -1){
                    ArrayList<ProductItem> productList = new ArrayList<>();
                    Utils.replaceFragment(getActivity().getFragmentManager(), StoreProductListingFragment.newInstance(Constant.HEALTH_PRODUCT, productList), StoreProductListingFragment.class.getSimpleName(), true, R.id
                            .fragmentContainer);
                }
                else {
                    Utils.replaceFragment(getActivity().getFragmentManager(), StoreProductListingFragment.newInstance(Constant.HEALTH_PRODUCT, (ArrayList<ProductItem>) getStoreDataList.get(healthProductItmesPosition).getProduct()), StoreProductListingFragment.class.getSimpleName(), true, R.id.fragmentContainer);
                }
            }

        } else if (view.getId() == R.id.tvTabMedicine) {
            DialogFactory.getInstance().showAlertDialog(getActivity(), null, 0, "Would you like to navigate to Netmeds.com?", "Yes", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    Utils.replaceFragment(getActivity().getFragmentManager(), NetMedFragment.newInstance(), NetMedFragment.class.getSimpleName(), true, R.id.fragmentContainer);
                }
            }, "Cancel", true);
        }

    }

    private void displayCartItemCount() {
        notificationButton.setVisibility(View.GONE);
        imgpendingFriend.setVisibility(View.VISIBLE);

        if (cartItemCount > 0) {
            notificationButton.setVisibility(View.VISIBLE);
            if (cartItemCount > 99) {
                notificationButton.setText("99+");
            } else {
                notificationButton.setText(String.format(Locale.getDefault(), "%d", cartItemCount));
            }
        }
    }

    private void getCartCountApiCall() {
        if (NetworkFactory.getInstance().isNetworkAvailable(getActivity())) {
            //body
            BaseMemberIdBody baseMemberIdBody = new BaseMemberIdBody();
            baseMemberIdBody.setMemberID(StoreConfig.storeUser.getMemberId());
            RestClient restClient = new RestClient(getActivity(), StoreConfig.BASE_URL, StoreConfig.mdebug);

            restClient.getStoreService().getCartCount(baseMemberIdBody).enqueue(new Callback<StoreCartCountResponse>() {
                @Override
                public void onResponse(Call<StoreCartCountResponse> call, Response<StoreCartCountResponse> response) {

                    if (isAdded() && getActivity() != null) {
                        if (response != null && response.body() != null) {
                            if (response.body().getStatus() == 0) {
                                cartItemCount = response.body().getData();
                                displayCartItemCount();
                            } else {
                                // DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_response_failure), getString(R.string.str_ok), false);
                                showApiErrorDialog();
                            }
                        } else {
                            //DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_response_null), getString(R.string.str_ok), false);
                            showApiErrorDialog();
                        }
                    }
                }

                @Override
                public void onFailure(Call<StoreCartCountResponse> call, Throwable t) {
                    if (isAdded() && getActivity() != null) {
                        //DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_failure), getString(R.string.str_ok), false);
                        showApiErrorDialog();
                    }
                }
            });
        } else {
            //DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.network_error), getString(R.string.str_ok), false);
        }
    }

    @Override
    public void onRetry() {
        getCartCountApiCall();
        callGetProductsApi();
    }
}
