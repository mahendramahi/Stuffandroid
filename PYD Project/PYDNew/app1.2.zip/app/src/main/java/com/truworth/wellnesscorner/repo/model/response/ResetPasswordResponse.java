package com.truworth.wellnesscorner.repo.model.response;

import com.truworth.wellnesscorner.model.ResetPasswordBean;

public class ResetPasswordResponse {


    private ResetPasswordBean data;
    private boolean hasError;
    private Error error;

    public ResetPasswordBean getData() {
        return data;
    }

    public void setData(ResetPasswordBean data) {
        this.data = data;
    }

    public boolean isHasError() {
        return hasError;
    }

    public void setHasError(boolean hasError) {
        this.hasError = hasError;
    }

    public Error getError() {
        return error;
    }

    public void setError(Error error) {
        this.error = error;
    }
}
