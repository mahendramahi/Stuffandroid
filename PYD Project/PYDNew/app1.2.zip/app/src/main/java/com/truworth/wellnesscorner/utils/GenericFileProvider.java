package com.truworth.wellnesscorner.utils;

import android.support.v4.content.FileProvider;

/**
 * Created by GurvinderS on 9/13/2017.
 */

public class GenericFileProvider extends FileProvider {
}
