package com.truworth.discoverlib.rest;


import com.truworth.discoverlib.model.AddToFavoriteBody;
import com.truworth.discoverlib.model.AddToFavouritResponse;
import com.truworth.discoverlib.model.BaseMemberIdBody;
import com.truworth.discoverlib.model.GetMyFavoriteResponse;
import com.truworth.discoverlib.model.GetRandomArticleResponse;
import com.truworth.discoverlib.model.RandomArticleBody;
import com.truworth.discoverlib.model.RateDiscoverBody;
import com.truworth.discoverlib.model.RateDiscoverResponse;
import com.truworth.discoverlib.model.RemoveFromFavoriteBody;
import com.truworth.discoverlib.model.RemoveFromFavouriteResponse;
import com.truworth.discoverlib.model.SearchDiscoverByKeywordBody;
import com.truworth.discoverlib.model.SearchDiscoverByKeywordResponse;
import com.truworth.discoverlib.model.SharedConfirmationBody;
import com.truworth.discoverlib.model.SharedConfirmationResponse;
import com.truworth.discoverlib.model.SlideShowRequestBody;
import com.truworth.discoverlib.model.SlideshowResponse;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

/**
 * Created by GurvinderS on 8/5/2016.
 */
public interface DiscoverService {


    @POST("Member/Discover/GetRandomArticle")
    Call<GetRandomArticleResponse> getRandomArticle(@Body RandomArticleBody randomArticleBody);

    @POST("Member/Discover/GetSlideShowByID")
    Call<SlideshowResponse> getSlideshowDetails(@Body SlideShowRequestBody slideShowRequestBody);

    @POST("Member/Discover/GetListOfFavorite")
    Call<GetMyFavoriteResponse> getMyFavorite(@Body BaseMemberIdBody getMyFavoriteBody);


    @POST("Member/Discover/DiscoverByKeyword")
    Call<SearchDiscoverByKeywordResponse> getDiscoverSearchByKeyword(@Body SearchDiscoverByKeywordBody searchDiscoverByKeywordBody);

    @POST("Member/Discover/Rating")
    Call<RateDiscoverResponse> rateDiscover(@Body RateDiscoverBody rateDiscoverBody);

    @POST("Member/Discover/AddToFavorite")
    Call<AddToFavouritResponse> addToFavourite(@Body AddToFavoriteBody addToFavoriteBody);

    @POST("Member/Discover/RemoveToFavorite")
    Call<RemoveFromFavouriteResponse> removeFromFavourite(@Body RemoveFromFavoriteBody removeFromFavorite);

    @POST("Member/Social/SaveMemberShareItems")
    Call<SharedConfirmationResponse> sharedItemConfirmation(@Body SharedConfirmationBody sharedConfirmationBody);

}
