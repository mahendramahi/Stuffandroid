package com.truworth.stepmodule;

import android.content.Context;
import android.os.AsyncTask;
import android.support.annotation.NonNull;
import android.util.Log;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.fitness.Fitness;
import com.google.android.gms.fitness.FitnessActivities;
import com.google.android.gms.fitness.data.Bucket;
import com.google.android.gms.fitness.data.DataPoint;
import com.google.android.gms.fitness.data.DataSet;
import com.google.android.gms.fitness.data.DataSource;
import com.google.android.gms.fitness.data.DataType;
import com.google.android.gms.fitness.data.Field;
import com.google.android.gms.fitness.request.DataReadRequest;
import com.google.android.gms.fitness.result.DataReadResponse;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.Tasks;
import com.truworth.stepmodule.inteface.OnRangeStepsFound;
import com.truworth.stepmodule.model.StepItem;
import com.truworth.stepmodule.utils.Utils;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import static java.util.concurrent.TimeUnit.SECONDS;

/**
 * If this code works, it was written by Somesh Kumar  on 26 April, 2018. If not, I don't know who wrote it.
 */
public class ReadGoogleFitStep extends AsyncTask<Object, Object, ArrayList<StepItem>> {
    private static final String DATE_FORMAT_YYYY_MM_DD = "yyyy-MM-dd";
    public static final String DATE_FORMAT_MM_DD_YYYY_HHMM_FORWARD_SLASH = "MM/dd/yyyy HH:mm:ss.SSS";
    private StepItem stepItem;
    private ArrayList<StepItem> foundStepList;
    private long toMillis;
    private long fromMillis;
    private Context context;
    private OnRangeStepsFound onRangeStepsFound;

    ReadGoogleFitStep(Context context, long from, long to, @NonNull OnRangeStepsFound onRangeStepsFound) {
        this.context = context;
        this.onRangeStepsFound = onRangeStepsFound;
        fromMillis = from;
        toMillis = to;
        foundStepList = new ArrayList<>();
        stepItem = new StepItem();
    }

    protected ArrayList<StepItem> doInBackground(Object... params) {
        HashMap<String, StepItem> hashMap = new HashMap<>();
        Calendar fromCalendar = Calendar.getInstance();
        fromCalendar.setTimeInMillis(fromMillis);

        Calendar toCalendar = Calendar.getInstance();
        toCalendar.setTimeInMillis(toMillis);
        String dateFromMillis = Utils.getInstance().getDateFromMillis(fromMillis, DATE_FORMAT_YYYY_MM_DD);
        StepItem stepItemEmpty = new StepItem();
        stepItemEmpty.setStepTime(dateFromMillis);
        stepItemEmpty.setCalories(0);
        stepItemEmpty.setStepCount("0");
        hashMap.put(dateFromMillis, stepItemEmpty);

        String dateToMillis = Utils.getInstance().getDateFromMillis(toMillis, DATE_FORMAT_YYYY_MM_DD);

        stepItemEmpty = new StepItem();
        stepItemEmpty.setStepTime(dateToMillis);
        stepItemEmpty.setCalories(0);
        stepItemEmpty.setStepCount("0");
        hashMap.put(dateToMillis, stepItemEmpty);

        if (!dateFromMillis.equalsIgnoreCase(dateToMillis)) {
            while (!dateFromMillis.equalsIgnoreCase(dateToMillis)) {
                fromCalendar.add(Calendar.DATE, 1);
                String dateMillis = Utils.getInstance().getDateFromMillis(fromCalendar.getTimeInMillis(), DATE_FORMAT_YYYY_MM_DD);
                dateFromMillis = dateMillis;
                stepItemEmpty = new StepItem();
                stepItemEmpty.setStepTime(dateMillis);
                stepItemEmpty.setCalories(0);
                stepItemEmpty.setStepCount("0");
                hashMap.put(dateMillis, stepItemEmpty);
            }
        }

        DataSource ESTIMATED_STEP_DELTAS = new DataSource.Builder()
                .setDataType(DataType.TYPE_STEP_COUNT_DELTA)
                .setType(DataSource.TYPE_DERIVED)
                .setStreamName("estimated_steps")
                .setAppPackageName("com.google.android.gms").build();

        DataReadRequest readRequest = new DataReadRequest.Builder()
                .aggregate(ESTIMATED_STEP_DELTAS, DataType.AGGREGATE_STEP_COUNT_DELTA)
                .bucketByTime(1, TimeUnit.DAYS)
                .setTimeRange(fromMillis, toMillis, TimeUnit.MILLISECONDS)
                .build();

        Task<DataReadResponse> dataReadResultTask = Fitness.getHistoryClient(context, Objects.requireNonNull(GoogleSignIn.getLastSignedInAccount(context))).readData(readRequest);
        try {
            DataReadResponse dataReadResponse = Tasks.await(dataReadResultTask, 30, SECONDS);
            if (dataReadResponse.getBuckets().size() > 0) {
                for (Bucket bucket : dataReadResponse.getBuckets()) {
                    List<DataSet> dataSets = bucket.getDataSets();
                    for (DataSet dataSet : dataSets) {
                        try {
                            for (DataPoint dataPoint : dataSet.getDataPoints()) {
                                for (Field field : dataPoint.getDataType().getFields()) {
                                    stepItem = new StepItem();
                                    if (field.getName().equalsIgnoreCase(Field.FIELD_STEPS.getName())) {
                                        stepItem.setStepCount(String.valueOf(dataPoint.getValue(Field.FIELD_STEPS)));

                                        long dayTime = dataPoint.getTimestamp(TimeUnit.MILLISECONDS);
                                        if (dataPoint.getEndTime(TimeUnit.MILLISECONDS) == dayTime) {
                                            dayTime = dataPoint.getStartTime(TimeUnit.MILLISECONDS);
                                        }

                                        String date = Utils.getInstance().getDateFromMillis(dayTime, DATE_FORMAT_YYYY_MM_DD);
                                        stepItem.setStepTime(date);
                                        hashMap.put(date, stepItem);
                                        Log.d("STEPS", "Steps Time" + stepItem.getStepTime() + " Value " + String.valueOf(dataPoint.getValue(Field.FIELD_STEPS)));
                                    }

                                }
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                            if (onRangeStepsFound != null) {
                                onRangeStepsFound.onStepsFoundError(e.getLocalizedMessage());
                            }
                        }
                    }
                }
            }
        } catch (ExecutionException | InterruptedException | TimeoutException e) {
            e.printStackTrace();
            if (onRangeStepsFound != null) {
                onRangeStepsFound.onStepsFoundError(e.getLocalizedMessage());
            }
        }

        DataReadRequest readCaloriesRequest = new DataReadRequest.Builder()
                .aggregate(DataType.TYPE_CALORIES_EXPENDED, DataType.AGGREGATE_CALORIES_EXPENDED)
                .bucketByActivitySegment(1, TimeUnit.MILLISECONDS)
                .setTimeRange(fromMillis, toMillis, TimeUnit.MILLISECONDS)
                .build();

        Task<DataReadResponse> dataReadCaloriesResponseTask = Fitness.getHistoryClient(context, Objects.requireNonNull(GoogleSignIn.getLastSignedInAccount(context))).readData(readCaloriesRequest);

        try {
            DataReadResponse dataReadResult = Tasks.await(dataReadCaloriesResponseTask, 30, SECONDS);

            if (dataReadResult.getBuckets().size() > 0) {
                for (Bucket bucket : dataReadResult.getBuckets()) {
                    // System.out.println("bucket.getActivity====" + bucket.getActivity());
                    if (bucket.getActivity().contains(FitnessActivities.WALKING) || bucket.getActivity().contains(FitnessActivities.RUNNING) || bucket.getActivity().contains(FitnessActivities
                            .ON_FOOT)) {
                        List<DataSet> dataSets = bucket.getDataSets();
                        for (DataSet dataSet : dataSets) {
                            for (DataPoint dataPoint : dataSet.getDataPoints()) {
                                for (Field field : dataPoint.getDataType().getFields()) {
                                    if (field.getName().equalsIgnoreCase(Field.FIELD_CALORIES.getName())) {
                                        long startTime = dataPoint.getStartTime(TimeUnit.MILLISECONDS);
                                        long endTime = dataPoint.getEndTime(TimeUnit.MILLISECONDS);
                                        String startDate = Utils.getInstance().getDateFromMillis(startTime, DATE_FORMAT_YYYY_MM_DD);
                                        String endDate = Utils.getInstance().getDateFromMillis(endTime, DATE_FORMAT_YYYY_MM_DD);
                                        String calories = String.valueOf(dataPoint.getValue(Field.FIELD_CALORIES));

                                        if (hashMap.get(startDate) != null) {
                                            int cal = hashMap.get(startDate).getCalories() + (int) Math.round(Double.parseDouble(calories));
                                            hashMap.get(startDate).setCalories(cal);
                                        } else {
                                            stepItem = new StepItem();
                                            stepItem.setStepTime(startDate);
                                            stepItem.setCalories((int) Double.parseDouble(calories));
                                            stepItem.setStepCount("0");
                                            hashMap.put(startDate, stepItem);
                                        }

                                        // }
                                    }
                                    //   stepItem.setStepTime(date);
                                    //    foundStepList.add(stepItem);
                                }
                            }
                        }
                    }
                }
            }
        } catch (ExecutionException | InterruptedException | TimeoutException e) {
            e.printStackTrace();
            if (onRangeStepsFound != null) {
                onRangeStepsFound.onStepsFoundError(e.getLocalizedMessage());
            }
        }

       /* for (Map.Entry<String, StepItem> entry : hashMap.entrySet()) {
            String key = entry.getKey();
            StepItem stepItem = entry.getValue();
            foundStepList.add(stepItem);
        }*/
        for (Map.Entry<String, StepItem> entry : hashMap.entrySet()) {
            System.out.println(entry.getKey() + " : " + entry.getValue());
            StepItem stepsHashMapBean = entry.getValue();

            StepItem stepsBean = new StepItem();
            stepsBean.setCalories(stepsHashMapBean.getCalories());
            stepsBean.setStepCount(stepsHashMapBean.getStepCount());

            String date = Utils.getInstance().formatDate(DATE_FORMAT_YYYY_MM_DD, DATE_FORMAT_MM_DD_YYYY_HHMM_FORWARD_SLASH,
                    stepsHashMapBean.getStepTime());
            stepsBean.setStepTime(date);
            foundStepList.add(stepsBean);
        }
        hashMap.clear();

        return foundStepList;
    }

    public void onPostExecute(ArrayList<StepItem> foundStepList) {
        super.onPostExecute(foundStepList);
        if (onRangeStepsFound != null) {
            onRangeStepsFound.onRangeStepsFound(foundStepList);
        }
    }
}