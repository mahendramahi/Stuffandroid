package com.truworth.discoverlib.utils;

import android.app.Activity;
import android.app.Fragment;
import android.graphics.Bitmap;
import android.net.Uri;
import android.support.annotation.Nullable;

import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.share.Sharer;
import com.facebook.share.model.ShareLinkContent;
import com.facebook.share.model.SharePhoto;
import com.facebook.share.model.SharePhotoContent;
import com.facebook.share.widget.ShareDialog;
import com.truworth.discoverlib.interfaces.OnFacebookShare;

/**
 * If this code works it was written by Somesh Kumar on 18 March, 2017. If not, I don't know who wrote it.
 */
public class FacebookShareUtil {
    private CallbackManager shareDialogCallbackManager;
    private ShareDialog shareDialog;
    private OnFacebookShare onFacebookShare;


    private FacebookShareUtil() {
        throw new Error("Can't make a default constructor of this class, please pass {Context} and {CallbackManager} in constructor");
    }

    public FacebookShareUtil(Activity activity, CallbackManager shareDialogCallbackManager, OnFacebookShare onFacebookShare) {
        this.shareDialogCallbackManager = shareDialogCallbackManager;
        shareDialog = new ShareDialog(activity);
        this.onFacebookShare = onFacebookShare;
    }


    public FacebookShareUtil(Fragment fragment, CallbackManager shareDialogCallbackManager, OnFacebookShare onFacebookShare) {
        this.shareDialogCallbackManager = shareDialogCallbackManager;
        shareDialog = new ShareDialog(fragment);
        this.onFacebookShare = onFacebookShare;
    }


    public void share(final int itemId, @Nullable String title, String description, String slideshowUrl, String imageUrl) {

        ShareLinkContent.Builder builder = new ShareLinkContent.Builder();

        if (title != null && title.length() > 0) {
            builder.setContentTitle(title);
        }
        if (description != null && description.length() > 0) {
            builder.setContentDescription(description);
        }
        if (slideshowUrl != null && slideshowUrl.length() > 0) {
            builder.setContentUrl(Uri.parse(slideshowUrl));
        }
        if (imageUrl != null && imageUrl.length() > 0) {
            builder.setImageUrl(Uri.parse(imageUrl));
        }

        ShareLinkContent linkContent = builder.build();

        shareDialog.show(linkContent, ShareDialog.Mode.FEED);

        shareDialog.registerCallback(shareDialogCallbackManager, new FacebookCallback<Sharer.Result>() {
            @Override
            public void onSuccess(Sharer.Result result) {
                if (onFacebookShare != null) {
                    onFacebookShare.onShareSuccess(itemId, result.getPostId());
                }
            }

            @Override
            public void onCancel() {
                if (onFacebookShare != null) {
                    //    onFacebookShare.onShareError("User canceled the dialog");
                }
            }

            @Override
            public void onError(FacebookException error) {
                if (onFacebookShare != null) {
                    onFacebookShare.onShareError("An error occurred while sharing");
                }
            }
        });
    }

    public void shareImage(Bitmap bitmapToShare,Activity activity) {

        SharePhoto photo = new SharePhoto.Builder().setBitmap(bitmapToShare).build();
        SharePhotoContent content = new SharePhotoContent.Builder().addPhoto(photo).build();
        ShareDialog dialog = new ShareDialog(activity);
        if (ShareDialog.canShow(SharePhotoContent.class)) {
            dialog.show(content);
        }
    }
}
