package com.truworth.wellnesscorner.utils;

import android.util.Base64;

import java.math.BigInteger;
import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.spec.RSAPrivateCrtKeySpec;
import java.security.spec.RSAPrivateKeySpec;
import java.security.spec.RSAPublicKeySpec;

import javax.crypto.Cipher;

/**
 * Created by rajeshs on 3/29/2018.
 */

public class RSAHelper {

    public static String Encrypt(String encrText) {
        String result = "";
        try {
            String modulusString = "pxmdVjHY8XcSnMaFC42foyna+ZYIYMELeNg9n2t98vO35AyivyR4ksBCoUNMf7It93ejm+8F+Zg1MynYRa0ib7uG7RlOjS3Oj9RZm+ztImhEOcVpAao+Cu8fItdOAAV6S97jfEaXzl2L7oM0Ty377o6LSrQYZW0IIg+WwQ1BUpc=";
            String publicExponentString = "AQAB";

            byte[] modulusBytes = android.util.Base64.decode(modulusString, android.util.Base64.DEFAULT);
            byte[] exponentBytes = android.util.Base64.decode(publicExponentString, android.util.Base64.DEFAULT);
            BigInteger modulus = new BigInteger(1, modulusBytes);
            BigInteger publicExponent = new BigInteger(1, exponentBytes);

            RSAPublicKeySpec rsaPubKey = new RSAPublicKeySpec(modulus, publicExponent);
            KeyFactory fact = KeyFactory.getInstance("RSA");
            PublicKey pubKey = fact.generatePublic(rsaPubKey);
            Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1PADDING");
            cipher.init(Cipher.ENCRYPT_MODE, pubKey);


            byte[] plainBytes = encrText.getBytes("UTF-8");
            byte[] cipherEncryptData = cipher.doFinal(plainBytes);

            String encryptedStringBase64 = android.util.Base64.encodeToString(cipherEncryptData, android.util.Base64.DEFAULT);
            result = encryptedStringBase64;
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return result;
    }

    /*public static String Decrypt(String encrText) {
        String result = "";
        try {
            String modulusString = "pxmdVjHY8XcSnMaFC42foyna+ZYIYMELeNg9n2t98vO35AyivyR4ksBCoUNMf7It93ejm+8F+Zg1MynYRa0ib7uG7RlOjS3Oj9RZm+ztImhEOcVpAao+Cu8fItdOAAV6S97jfEaXzl2L7oM0Ty377o6LSrQYZW0IIg+WwQ1BUpc=";
            String publicExponentString = "AQAB";

            byte[] modulusBytes = Base64.decode(modulusString, android.util.Base64.DEFAULT);
            byte[] exponentBytes = Base64.decode(publicExponentString, android.util.Base64.DEFAULT);
            BigInteger modulus = new BigInteger(1, modulusBytes);
            BigInteger publicExponent = new BigInteger(1, exponentBytes);
            BigInteger privateExponent = publicExponent.modInverse(modulus);

            KeyFactory fact = KeyFactory.getInstance("RSA");

            String pp = "3dTww5AmmeeWRFnwivBDQky8pZvHBYmTEG8+cISRx74CFaW66Vtk7nb4tfzXnEH7oJRpeF7XxU80LYMdW3dlrQ==";
            String pq = "wNaLW+fE2cNK8vVHLpSpLMbKRXE8kxO2I/Uie+kZjwFQYUGpnFot2/EBBr3GU9F6UQw/QffCObFGfB+3aak50w==";
            String pEP = "2V4BFgA4cvLFAfEHjX1kyqCa8cQ1Pq3SF3aKPoMIvirnrAKbpnJR8oFNsDYzp//X6z/CIZr9329+92HU8H2MeQ==";
            String pEQ = "F1Veg35l6VuiJAfd1xsR5WMgcoqjI8DM10kAJTItb4pfKYWCenLG/cgJscEg0F+Wh1wOA3NxQv3aY4aK8PQTFQ==";
            String cc="tJVkVdtpa8t3GwSAOhLTnIxUphwOq5mC1i5RB12tK7CalvjOyauXm+Nv4lINsloHAvf2Av2fOzEVYFm4vaeuDA==";

            BigInteger primeP = new BigInteger(1, Base64.decode(pp, android.util.Base64.DEFAULT));
            BigInteger primeQ = new BigInteger(1, Base64.decode(pq, android.util.Base64.DEFAULT));
            BigInteger primeExponentP = new BigInteger(1, Base64.decode(pEP, android.util.Base64.DEFAULT));
            BigInteger primeExponentQ = new BigInteger(1, Base64.decode(pEQ, android.util.Base64.DEFAULT));
            BigInteger crtCoef = new BigInteger(1, Base64.decode(cc, android.util.Base64.DEFAULT));

            RSAPrivateKeySpec prvSpec = new RSAPrivateCrtKeySpec(modulus, publicExponent, privateExponent, primeP, primeQ, primeExponentP, primeExponentQ, crtCoef);

            PrivateKey privkey = fact.generatePrivate(prvSpec);

            Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
            cipher.init(Cipher.DECRYPT_MODE, privkey);

            byte[] dataDecoded = Base64.decode(encrText, Base64.DEFAULT);

            result = new String(cipher.doFinal(dataDecoded), "UTF-8");

        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return result;
    }*/

}
