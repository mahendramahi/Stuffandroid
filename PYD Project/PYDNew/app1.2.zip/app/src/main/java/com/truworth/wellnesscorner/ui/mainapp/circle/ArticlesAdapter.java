package com.truworth.wellnesscorner.ui.mainapp.circle;

import android.content.Intent;
import android.databinding.DataBindingUtil;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.truworth.discoverlib.ArticleDetailActivity;
import com.truworth.discoverlib.model.DiscoverUser;
import com.truworth.discoverlib.utils.DiscoverConfig;
import com.truworth.wellnesscorner.R;
import com.truworth.wellnesscorner.TheWellnessCornerApp;
import com.truworth.wellnesscorner.data.SharedPreferenceHelper;
import com.truworth.wellnesscorner.databinding.RowDiscoverHealthyBigBinding;
import com.truworth.wellnesscorner.databinding.RowDiscoverHealthyLivingBinding;
import com.truworth.wellnesscorner.model.Article;
import com.truworth.wellnesscorner.utils.AppConstants;

import java.util.List;

import javax.inject.Inject;

/**
 * Created by rajeshs on 4/17/2018.
 */

public class ArticlesAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private static final int VIEW_TYPE_BIG = 0;
    private static final int VIEW_TYPE_SMALL = 1;
    List<Article> articles;
    @Inject
    SharedPreferenceHelper prefHelper;

    public ArticlesAdapter(List<Article> articles) {
        this.articles = articles;
        //  this.listener = listener;
        TheWellnessCornerApp.getApp().component().inject(this);
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        RecyclerView.ViewHolder viewHolder = null;
        View itemView;
        switch (viewType){
            case VIEW_TYPE_BIG:
                RowDiscoverHealthyBigBinding bigBinding = DataBindingUtil.inflate(LayoutInflater.from(parent.getContext()), R.layout.row_discover_healthy_big, parent, false);
                viewHolder = new ViewHolderBig(bigBinding);
                break;
            case VIEW_TYPE_SMALL:
                RowDiscoverHealthyLivingBinding binding = DataBindingUtil.inflate(LayoutInflater.from(parent.getContext()), R.layout.row_discover_healthy_living, parent, false);
                viewHolder = new ViewHolderSmall(binding);
                break;
        }
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        switch (holder.getItemViewType()) {
            case VIEW_TYPE_BIG:
                ViewHolderBig holderBig=(ViewHolderBig)holder;
                holderBig.bind(articles.get(position));
                break;
            case VIEW_TYPE_SMALL:
                ViewHolderSmall holderSmall=(ViewHolderSmall)holder;
                holderSmall.bind(articles.get(position));
                break;
        }
    }
    @Override
    public int getItemViewType(int position) {
        if (position == 0) {
            return VIEW_TYPE_BIG;
        } else {
            return VIEW_TYPE_SMALL;
        }
    }
    @Override
    public int getItemCount() {
        return articles.size();
    }

    public class ViewHolderBig extends RecyclerView.ViewHolder implements ArticleItemViewModel.ArticleListener {
        private RowDiscoverHealthyBigBinding  bigBinding;

        public ViewHolderBig(RowDiscoverHealthyBigBinding bigBinding) {
            super(bigBinding.getRoot());
            this.bigBinding=bigBinding;
        }

        public void bind(Article article) {
            ArticleItemViewModel viewModel = new ArticleItemViewModel(article, this);

            bigBinding.setViewModel(viewModel);
            //mBinding.setMyCircle(circle);
            bigBinding.executePendingBindings();
        }

        @Override
        public void onItemClick() {
            DiscoverUser discoverUser = new DiscoverUser("0", "bearer " + prefHelper.getToken());
            DiscoverConfig.init("Wellness", AppConstants.API_ENDPOINT, discoverUser, false);

            if (!DiscoverConfig.APP_NAME.isEmpty() && !DiscoverConfig.BASE_URL.isEmpty() && DiscoverConfig.discoverUser != null) {
                Intent intent = new Intent(itemView.getContext(), ArticleDetailActivity.class);
                intent.putExtra("ARTICLE_ID", articles.get(getAdapterPosition()).getUrl());
                itemView.getContext().startActivity(intent);
            }
        }
    }

    public class ViewHolderSmall extends RecyclerView.ViewHolder implements ArticleItemViewModel.ArticleListener {
        private RowDiscoverHealthyLivingBinding mBinding;

        public ViewHolderSmall(RowDiscoverHealthyLivingBinding binding) {
            super(binding.getRoot());
            mBinding = binding;
        }

        public void bind(@NonNull Article article) {

            ArticleItemViewModel viewModel = new ArticleItemViewModel(article, this);

            mBinding.setViewModel(viewModel);
            //mBinding.setMyCircle(circle);
            mBinding.executePendingBindings();
        }

        @Override
        public void onItemClick() {
            DiscoverUser discoverUser = new DiscoverUser("0", "bearer " + prefHelper.getToken());
            DiscoverConfig.init("Wellness",  AppConstants.API_ENDPOINT, discoverUser, false);

            if (!DiscoverConfig.APP_NAME.isEmpty() && !DiscoverConfig.BASE_URL.isEmpty() && DiscoverConfig.discoverUser != null) {
                Intent intent = new Intent(itemView.getContext(), ArticleDetailActivity.class);
                intent.putExtra("ARTICLE_ID", articles.get(getAdapterPosition()).getUrl());
                itemView.getContext().startActivity(intent);
            }

        }
    }

}
