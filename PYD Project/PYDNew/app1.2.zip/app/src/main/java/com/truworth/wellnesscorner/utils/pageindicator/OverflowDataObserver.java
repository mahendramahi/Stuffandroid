package com.truworth.wellnesscorner.utils.pageindicator;

import android.support.v7.widget.RecyclerView;


class OverflowDataObserver extends RecyclerView.AdapterDataObserver {

	private OverflowPagerIndicator mOverflowPagerIndicator;

	OverflowDataObserver(OverflowPagerIndicator overflowPagerIndicator) {
		mOverflowPagerIndicator = overflowPagerIndicator;
	}

	@Override
	public void onChanged() {
		mOverflowPagerIndicator.updateIndicatorsCount();
	}

	@Override
	public void onItemRangeInserted(int positionStart, int itemCount) {
		mOverflowPagerIndicator.updateIndicatorsCount();
	}

	@Override
	public void onItemRangeChanged(int positionStart, int itemCount) {
		mOverflowPagerIndicator.updateIndicatorsCount();
	}

	@Override
	public void onItemRangeChanged(int positionStart, int itemCount, Object payload) {
		mOverflowPagerIndicator.updateIndicatorsCount();
	}

	@Override
	public void onItemRangeRemoved(int positionStart, int itemCount) {
		mOverflowPagerIndicator.updateIndicatorsCount();
	}

	@Override
	public void onItemRangeMoved(int fromPosition, int toPosition, int itemCount) {
		mOverflowPagerIndicator.updateIndicatorsCount();
	}
}
