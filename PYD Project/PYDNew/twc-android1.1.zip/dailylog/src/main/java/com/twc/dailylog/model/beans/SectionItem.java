package com.twc.dailylog.model.beans;

import java.util.ArrayList;

/**
 * Created by ManishJ1 on 7/5/2016.
 */
public class SectionItem {
    private String sectionName;
    private ArrayList<FoodItem> mFoodItemArrayList;

    public String getSectionName() {
        return sectionName;
    }

    public void setSectionName(String sectionName) {
        this.sectionName = sectionName;
    }

    public ArrayList<FoodItem> getFoodItemArrayList() {
        return mFoodItemArrayList;
    }

    public void setFoodItemArrayList(ArrayList<FoodItem> foodItemArrayList) {
        mFoodItemArrayList = foodItemArrayList;
    }
}
