package com.truworth.wellnesscorner.ui.mainapp.createpost.sharemeal;

import android.content.Context;
import android.databinding.DataBindingUtil;
import android.support.annotation.NonNull;
import android.support.constraint.ConstraintLayout;
import android.support.v4.app.FragmentManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.truworth.wellnesscorner.R;
import com.truworth.wellnesscorner.customviews.CircularImageView;
import com.truworth.wellnesscorner.databinding.RowLoadingProgressBinding;
import com.truworth.wellnesscorner.databinding.RowShareMealHeaderBinding;
import com.truworth.wellnesscorner.model.FoodsBean;
import com.truworth.wellnesscorner.model.MealDataBean;
import com.truworth.wellnesscorner.model.ShareMealBean;
import com.truworth.wellnesscorner.utils.DateUtils;
import com.twc.store.utils.Utils;

import java.util.List;

public class ShareMealAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private static final int VIEW_TYPE_ITEM = 1;
    private static final int VIEW_TYPE_PROGRESS = 2;
    private List<ShareMealBean> headerList;
    private Context context;
    private FragmentManager fragmentManager;
    String memberName;
    String memberImage;

    public ShareMealAdapter(Context context, List<ShareMealBean> headerList, FragmentManager fragmentManager, String memberName, String memberImage) {
        this.headerList = headerList;
        this.context = context;
        this.fragmentManager = fragmentManager;
        this.memberName = memberName;
        this.memberImage = memberImage;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        RecyclerView.ViewHolder viewHolder = null;
        if (viewType == VIEW_TYPE_ITEM) {
            RowShareMealHeaderBinding headerBinding = DataBindingUtil.inflate(LayoutInflater.from(parent.getContext()), R.layout.row_share_meal_header, parent, false);
            viewHolder = new HeaderViewHolder(headerBinding);
        } else {
            RowLoadingProgressBinding rowLoadingProgressBinding = DataBindingUtil.inflate(LayoutInflater.from(parent.getContext()), R.layout.row_loading_progress, parent, false);
            viewHolder = new ViewHolderLoading(rowLoadingProgressBinding);
        }
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        if (holder.getItemViewType() == VIEW_TYPE_PROGRESS) {
            ViewHolderLoading viewHolderLoading = (ViewHolderLoading) holder;
            viewHolderLoading.rowLoadingProgressBinding.progressBar.setIndeterminate(true);
        } else {
            HeaderViewHolder viewHolderHeader = (HeaderViewHolder) holder;
            //viewHolderHeader.bind(headerList.get(position));

            viewHolderHeader.mHeaderBinding.tvDate.setText(getDateInFormat(headerList.get(position).getDate()));
            viewHolderHeader.mHeaderBinding.foodContainer.removeAllViews();
            if (headerList.get(position).getMealData() != null) {
                List<MealDataBean> daysMealList = headerList.get(position).getMealData();

                for (int index = 0; index < daysMealList.size(); index++) {
                    View foodView = LayoutInflater.from(context).inflate(R.layout.row_share_meal, null);
                    ConstraintLayout mealRow = foodView.findViewById(R.id.mealRow);
                    TextView tvMealType = foodView.findViewById(R.id.tvMealType);
                    TextView tvMealFoods = foodView.findViewById(R.id.tvMealFoods);
                    TextView tvTotalCalories = foodView.findViewById(R.id.tvTotalCalories);
                    CircularImageView ivMealType = foodView.findViewById(R.id.ivMealType);


                    tvMealType.setText(daysMealList.get(index).getMealType().toString().toUpperCase());

                    if (tvMealType.getText().equals("BREAKFAST")) {
                        ivMealType.setImageResource(R.drawable.breakfast);
                    } else if (tvMealType.getText().equals("LUNCH")) {
                        ivMealType.setImageResource(R.drawable.lunch);
                    } else if (tvMealType.getText().equals("SNACKS")) {
                        ivMealType.setImageResource(R.drawable.snacks);
                    } else if (tvMealType.getText().equals("DINNER")) {
                        ivMealType.setImageResource(R.drawable.dinner);
                    }
                    MealDataBean mealDataBean = daysMealList.get(index);
                    List<FoodsBean> foodList = mealDataBean.getFoods();
                    StringBuilder foodName = new StringBuilder();
                    Double totalCalories = 0.0;

                    for (int i = 0; i < foodList.size(); i++) {
                        foodName.append(foodList.get(i).getName()).append(", ");
                        totalCalories = totalCalories + foodList.get(i).getCalorie();
                    }
                    foodName.deleteCharAt(foodName.toString().trim().length() - 1);
                    tvMealFoods.setText(foodName);

                    tvTotalCalories.setText(Utils.doubleToString(totalCalories));
                    //viewHolderHeader.mHeaderBinding.foodContainer.removeAllViews();
                    viewHolderHeader.mHeaderBinding.foodContainer.addView(foodView);

                    mealRow.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            //Toast.makeText(context, "Clicked!", Toast.LENGTH_SHORT).show();
                            fragmentManager.beginTransaction().replace(R.id.shareContainer, ShareMealDetailFragment.newInstance(headerList.get(position).getDate(), tvMealType.getText().toString(), tvTotalCalories.getText().toString(), mealDataBean, memberName, memberImage),
                                    ShareMealDetailFragment.TAG).addToBackStack(ShareMealDetailFragment.TAG).commit();

                        }
                    });
                }

            }
        }
    }

    @Override
    public int getItemViewType(int position) {

        if (headerList.get(position) == null) {
            return VIEW_TYPE_PROGRESS;
        } else {
            return VIEW_TYPE_ITEM;
        }
    }

    @Override
    public int getItemCount() {
        return headerList.size();
    }


    public class HeaderViewHolder extends RecyclerView.ViewHolder {
        private RowShareMealHeaderBinding mHeaderBinding;

        public HeaderViewHolder(RowShareMealHeaderBinding binding) {
            super(binding.getRoot());
            mHeaderBinding = binding;
        }

        public void bind(@NonNull ShareMealBean shareMealBean) {

            ShareMealItemHeaderViewModel viewModel = new ShareMealItemHeaderViewModel(shareMealBean);

            mHeaderBinding.setViewModel(viewModel);
            mHeaderBinding.executePendingBindings();

        }
    }

    public class ViewHolderLoading extends RecyclerView.ViewHolder {
        private RowLoadingProgressBinding rowLoadingProgressBinding;

        public ViewHolderLoading(RowLoadingProgressBinding binding) {
            super(binding.getRoot());
            rowLoadingProgressBinding = binding;
        }
    }

    public String getDateInFormat(String date) {
        String newDateString = "";
        if (date != null) {
            newDateString = DateUtils.formatDate(date, "yyyy-MM-dd'T'HH:mm:ss", "MMMM dd, yyyy");
        }
        return newDateString;
    }

    public void setMember(String name, String url) {
        this.memberName = name;
        this.memberImage = url;

    }
}
