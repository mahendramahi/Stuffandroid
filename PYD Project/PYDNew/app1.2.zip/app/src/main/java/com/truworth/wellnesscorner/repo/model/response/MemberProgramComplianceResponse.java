package com.truworth.wellnesscorner.repo.model.response;

import com.truworth.wellnesscorner.model.MemberProgramComplianceBean;

/**
 * Created by richas on 2/26/2018.
 */

public class MemberProgramComplianceResponse {

    private int status;
    private MemberProgramComplianceBean Data;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public MemberProgramComplianceBean getData() {
        return Data;
    }

    public void setData(MemberProgramComplianceBean Data) {
        this.Data = Data;
    }
}
