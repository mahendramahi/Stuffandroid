package com.truworth.wellnesscorner.ui.step;

public class DeviceStepsItem {

    private String Date;
    private String Value;
    private String Device;
    private boolean mIsMonth;

    public String getDate() {
        return Date;
    }

    public void setDate(String date) {
        Date = date;
    }

    public String getValue() {
        return Value;
    }

    public void setValue(String value) {
        Value = value;
    }

    public String getDevice() {
        return Device;
    }

    public void setDevice(String device) {
        Device = device;
    }

    public boolean getIsMonth() {
        return mIsMonth;
    }

    public void setMonth(boolean isMonth) {
        mIsMonth = isMonth;
    }
}
