package com.truworth.wellnesscorner.ui.mainapp.circle;

import android.app.Activity;
import android.content.Intent;
import android.databinding.DataBindingUtil;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import com.truworth.wellnesscorner.R;
import com.truworth.wellnesscorner.databinding.RowMyCirclesBinding;
import com.truworth.wellnesscorner.model.MyCircle;
import com.truworth.wellnesscorner.ui.mainapp.circledetail.CircleDetailActivity;

import java.util.List;

/**
 * Created by rajeshs on 4/13/2018.
 */

public class MyCircleRecyclerAdapter extends RecyclerView.Adapter<MyCircleRecyclerAdapter.ViewHolder> {
    List<MyCircle> myCircles;

    public MyCircleRecyclerAdapter(List<MyCircle> myCircles) {
        this.myCircles = myCircles;
        //  this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        RowMyCirclesBinding binding = DataBindingUtil.inflate(LayoutInflater.from(parent.getContext()), R.layout.row_my_circles, parent, false);
        return new MyCircleRecyclerAdapter.ViewHolder(binding);
    }


    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.bind(myCircles.get(position));
    }


    @Override
    public int getItemCount() {
        return myCircles.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements MyCircleViewModel.MyCircleListener {
        private RowMyCirclesBinding mBinding;

        public ViewHolder(RowMyCirclesBinding binding) {
            super(binding.getRoot());
            mBinding = binding;
        }

        public void bind(@NonNull MyCircle circle) {
            MyCircleViewModel viewModel = new MyCircleViewModel(circle, this);
            mBinding.setViewModel(viewModel);
            mBinding.executePendingBindings();
            viewModel.getRating();
            viewModel.getNewPost();
        }

        @Override
        public void onItemClick() {
            CircleDetailActivity.start((Activity)itemView.getContext(),myCircles.get(getAdapterPosition()).getCircleIdentity());
            }
    }
}
