package com.twc.dailylog.model.response;

/**
 Created by PalakC on 7/6/2016.
 */
public class AddFoodResponse {

    private int status;
    private int id;
    private int NutritionID;

    public int getNutritionID() {
        return NutritionID;
    }

    public void setNutritionID(int nutritionID) {
        NutritionID = nutritionID;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}

