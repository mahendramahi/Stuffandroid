package com.truworth.wellnesscorner.ui.mainapp.createpost.sharemeal;

import android.databinding.ObservableField;

import com.truworth.wellnesscorner.base.BaseViewModel;
import com.truworth.wellnesscorner.utils.DateUtils;
import com.truworth.wellnesscorner.utils.SingleLiveEvent;

public class ShareMealDetailViewModel extends BaseViewModel {

    ObservableField<String> mealDate = new ObservableField<>();
    ObservableField<String> mealType = new ObservableField<>();
    ObservableField<String> TotalCalories = new ObservableField<>();

    SingleLiveEvent<Void> shareData = new SingleLiveEvent<>();

    public SingleLiveEvent<Void> getShareData() {
        return shareData;
    }

    public ObservableField<String> getMealDate() {
        return mealDate;
    }

    public ObservableField<String> getMealType() {
        return mealType;
    }

    public ObservableField<String> getTotalCalories() {
        return TotalCalories;
    }

    public String getDateInFormat(String date){
        String newDateString ="";
        if(date !=null)
            newDateString = DateUtils.formatDate(date, "yyyy-MM-dd'T'HH:mm:ss", "MMMM dd, yyyy");
        return newDateString;
    }

    public void shareFoodData(){
        shareData.call();
    }
}
