package com.truworth.wellnesscorner.di;

import android.app.Application;

import com.truworth.wellnesscorner.TheWellnessCornerApp;
import com.truworth.wellnesscorner.network.NetworkModule;
import com.truworth.wellnesscorner.ui.mainapp.HomeDashBoardActivity;
import com.truworth.wellnesscorner.ui.mainapp.circledetail.challenges.ChallengeScoreboardViewModel;
import com.truworth.wellnesscorner.ui.mainapp.createpost.CreatePostViewModel;
import com.truworth.wellnesscorner.ui.mainapp.createpost.sharedashboard.ShareDashboardViewModel;
import com.truworth.wellnesscorner.ui.mainapp.createpost.shareexercise.ShareExerciseListFragment;
import com.truworth.wellnesscorner.ui.mainapp.createpost.shareexercise.ShareExerciseListViewModel;
import com.truworth.wellnesscorner.ui.mainapp.createpost.shareexercise.ShareExerciseViewModel;
import com.truworth.wellnesscorner.ui.mainapp.createpost.sharemeal.ShareMealViewModel;
import com.truworth.wellnesscorner.ui.mainapp.createpost.sharesteps.ShareStepsViewModel;
import com.truworth.wellnesscorner.ui.mainapp.createpost.shareweight.ShareWeightViewModel;
import com.truworth.wellnesscorner.ui.mainapp.more.MoreOptionViewModel;
import com.truworth.wellnesscorner.ui.registration.registrationstepsixth.HealthGoalViewModel;
import com.truworth.wellnesscorner.ui.mainapp.circledetail.challenges.ChallengeDetailViewModel;
//import com.truworth.wellnesscorner.ui.mainapp.circledetail.challenges.ChallengeTodayViewModel;
import com.truworth.wellnesscorner.ui.mainapp.more.MoreOptionsFragment;
import com.truworth.wellnesscorner.ui.mainapp.circle.ArticlesAdapter;
import com.truworth.wellnesscorner.ui.mainapp.circle.CircleViewModel;
import com.truworth.wellnesscorner.ui.mainapp.circle.CirclesFragment;
import com.truworth.wellnesscorner.ui.mainapp.circle.PopularProductAdapter;
import com.truworth.wellnesscorner.ui.mainapp.today.TodayFragment;

import com.truworth.wellnesscorner.ui.mainapp.circledetail.CircleAboutViewModel;
import com.truworth.wellnesscorner.ui.mainapp.circledetail.challenges.CircleChallengeViewModel;
import com.truworth.wellnesscorner.ui.mainapp.circledetail.coaches.CircleCoachViewModel;
import com.truworth.wellnesscorner.ui.mainapp.circledetail.CircleDetailViewModel;
import com.truworth.wellnesscorner.ui.mainapp.circledetail.home.CircleHomeFragment;
import com.truworth.wellnesscorner.ui.mainapp.post.PostRecyclerAdapter;
import com.truworth.wellnesscorner.ui.mainapp.circledetail.home.CircleHomeViewModel;
import com.truworth.wellnesscorner.ui.mainapp.circledetail.members.CircleMemberViewModel;
import com.truworth.wellnesscorner.ui.mainapp.post.EventViewModel;
import com.truworth.wellnesscorner.ui.mainapp.post.postcomment.PostCommentItemViewModel;
import com.truworth.wellnesscorner.ui.mainapp.post.postcomment.PostCommentViewModel;
import com.truworth.wellnesscorner.ui.mainapp.post.PostViewModel;
import com.truworth.wellnesscorner.ui.mainapp.today.TodayDashBoardViewModel;
import com.truworth.wellnesscorner.ui.login.LoginEmailFragment;
import com.truworth.wellnesscorner.ui.login.LoginEmailViewModel;
import com.truworth.wellnesscorner.ui.login.LoginPasswordFragment;
import com.truworth.wellnesscorner.ui.login.LoginPasswordViewModel;
import com.truworth.wellnesscorner.ui.mobileverification.CountryListViewModel;
import com.truworth.wellnesscorner.ui.mobileverification.LoginMobileViewModel;
import com.truworth.wellnesscorner.ui.mobileverification.OTPViewModel;
import com.truworth.wellnesscorner.ui.mytask.MyTaskPagerFragment;
import com.truworth.wellnesscorner.ui.mytask.MyTasksFragment;
import com.truworth.wellnesscorner.ui.registration.RegistrationActivity;
import com.truworth.wellnesscorner.ui.registration.registrationstepfifth.EditProfileViewModel;
import com.truworth.wellnesscorner.ui.registration.registrationstepfirst.CreatePasswordViewModel;
import com.truworth.wellnesscorner.ui.registration.registrationstepfourth.CitySearchViewModel;
import com.truworth.wellnesscorner.ui.registration.registrationstepfourth.ConfirmLocationViewModel;
import com.truworth.wellnesscorner.ui.registration.registrationstepfourth.LocationDetectViewModel;
import com.truworth.wellnesscorner.ui.registration.registrationstepthird.BMICalculatingViewModel;
import com.truworth.wellnesscorner.ui.registration.registrationstepthird.BMIViewModel;
import com.truworth.wellnesscorner.ui.resetpassword.ResetPasswordViewModel;
import com.truworth.wellnesscorner.ui.splash.SplashViewModel;
import com.truworth.wellnesscorner.ui.step.ConnectDeviceAdapter;
import com.truworth.wellnesscorner.ui.step.ConnectDeviceDetailFragment;
import com.truworth.wellnesscorner.ui.step.EFitLoginFragment;
import com.truworth.wellnesscorner.ui.step.StepTrackerSettingFragment;
import com.truworth.wellnesscorner.ui.step.StepsTrackerFragment;
import com.truworth.wellnesscorner.ui.step.SyncStepsFragment;
import com.truworth.wellnesscorner.ui.tagfeature.SocialTagsCompletionView;

import javax.inject.Singleton;

import dagger.Component;


@Singleton
@AppContext
@Component(modules = AppModule.class)
public interface AppComponent {

    public static AppComponent component(Application app) {
        return DaggerAppComponent.builder().appModule(new AppModule(app)).networkModule(new NetworkModule()).build();
    }


    void inject(TheWellnessCornerApp app);

    void inject(HomeDashBoardActivity app);

    void inject(CircleHomeFragment viewModel);

    void inject(ShareWeightViewModel viewModel);

    void inject(ShareStepsViewModel viewModel);

    void inject(ShareMealViewModel viewModel);

    void inject(CreatePostViewModel viewModel);

    void inject(LoginEmailViewModel viewModel);

    void inject(ShareDashboardViewModel viewModel);

    void inject(SocialTagsCompletionView viewModel);

    void inject(LoginPasswordFragment loginFragment);

    void inject(LoginPasswordViewModel viewModel);

    void inject(LoginMobileViewModel viewModel);

    void inject(OTPViewModel viewModel);

    void inject(CreatePasswordViewModel viewModel);

    void inject(SplashViewModel viewModel);

    void inject(ConfirmLocationViewModel viewModel);

    void inject(CitySearchViewModel viewModel);

    void inject(RegistrationActivity activity);

    void inject(BMICalculatingViewModel viewModel);

    void inject(MoreOptionsFragment fragment);

    void inject(BMIViewModel viewModel);

    void inject(LocationDetectViewModel viewModel);

    void inject(EditProfileViewModel viewModel);

    void inject(HealthGoalViewModel viewModel);

    void inject(CircleViewModel viewModel);

    //void inject(TodayViewModel viewModel);
    // ActivityComponent plusActivityModule(ActivityModule activityModule);

    void inject(LoginEmailFragment fragment);

    void inject(ArticlesAdapter adapter);

    void inject(ConnectDeviceAdapter adapter);

    void inject(ConnectDeviceDetailFragment adapter);

    void inject(StepsTrackerFragment adapter);

    void inject(StepTrackerSettingFragment adapter);

    void inject(SyncStepsFragment syncStepsFragment);

    void inject(EFitLoginFragment eFitLoginFragment);

    void inject(PopularProductAdapter adapter);

    void inject(CircleHomeViewModel viewModel);

    void inject(CircleCoachViewModel viewModel);

    void inject(CircleMemberViewModel viewModel);

    void inject(CircleChallengeViewModel viewModel);

    void inject(CountryListViewModel viewModel);

    void inject(CircleAboutViewModel viewModel);

    void inject(ResetPasswordViewModel viewModel);

    void inject(ChallengeScoreboardViewModel viewModel);

   // void inject(ChallengeTodayViewModel viewModel);


    void inject(CirclesFragment fragment);

    void inject(TodayDashBoardViewModel todayDashBoardViewModel);

    void inject(TodayFragment fragment);


    void inject(PostRecyclerAdapter circleHomeRecyclerAdapter);

    void inject(MyTasksFragment fragment);


    void inject(MyTaskPagerFragment fragment);

    void inject(PostViewModel viewModel);

    void inject(PostCommentViewModel viewModel);

    void inject(EventViewModel viewModel);

    void inject(ChallengeDetailViewModel viewModel);

    void inject(PostCommentItemViewModel itemViewModel);

    void inject(CircleDetailViewModel viewModel);

    void inject(ShareExerciseListViewModel viewModel);

    void inject(ShareExerciseViewModel viewModel);

    void inject(ShareExerciseListFragment fragment);
    void inject(MoreOptionViewModel moreOptionViewModel);
}
