package com.twc.hramodule.model.beans;

/**
 Created by GurvinderS on 10/7/2016.
 */
public class HraItem {

    private long QuestionID;
    private String AnswerID;
    private String Answer;
    private boolean isSelected;
    private String screenNo;

    public long getQuestionID() {
        return QuestionID;
    }

    public void setQuestionID(long questionID) {
        QuestionID = questionID;
    }

    public String getAnswerID() {
        return AnswerID;
    }

    public void setAnswerID(String answerID) {
        AnswerID = answerID;
    }

    public String getAnswer() {
        return Answer;
    }

    public void setAnswer(String answer) {
        Answer = answer;
    }

    public boolean isSelected() {
        return isSelected;
    }

    public void setSelected(boolean selected) {
        isSelected = selected;
    }

    public String getScreenNo() {
        return screenNo;
    }

    public void setScreenNo(String screenNo) {
        this.screenNo = screenNo;
    }
}
