package com.truworth.wellnesscorner.ui.registration.registrationstepfourth;

import android.arch.lifecycle.ViewModel;
import android.databinding.ObservableBoolean;

import com.truworth.wellnesscorner.TheWellnessCornerApp;
import com.truworth.wellnesscorner.base.BaseViewModel;
import com.truworth.wellnesscorner.model.CityStateCountryData;
import com.truworth.wellnesscorner.repo.LoginRepository;
import com.truworth.wellnesscorner.repo.model.request.GetCountryStateByCityNameRequest;
import com.truworth.wellnesscorner.repo.model.response.GetCountryStateByCityNameResponse;
import com.truworth.wellnesscorner.utils.SingleLiveEvent;
import java.util.ArrayList;
import javax.inject.Inject;
import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;

/**
 * If this code works, it was written by Somesh Kumar  on 06 April, 2018. If not, I don't know who wrote it.
 */
public class LocationDetectViewModel  extends BaseViewModel{
    public ObservableBoolean progressLocation = new ObservableBoolean();
    public void setProgressLocation(ObservableBoolean progressLocation) {
        this.progressLocation = progressLocation;
    }
    public ObservableBoolean getProgressLocation() {
        return progressLocation;
    }
    public ObservableBoolean isContinueEnabled = new ObservableBoolean();
    private final SingleLiveEvent<Void> isContinueClick = new SingleLiveEvent<>();
    public SingleLiveEvent<Void> getContinueClick() {
        return isContinueClick;
    }
    public void continueClick(){
        isContinueClick.call();
    }
    public final ArrayList<CityStateCountryData> addressData = new ArrayList<>();
    SingleLiveEvent<Void> showCityStateCountryList = new SingleLiveEvent<>();

    public LocationDetectViewModel() {
        TheWellnessCornerApp.getApp().component().inject(this);
    }

    @Inject
    LoginRepository repository;

    public void loadSearchCitiesData(String city) {
        //setIsLoading(true);
        GetCountryStateByCityNameRequest getCountryStateByCityNameRequest = new GetCountryStateByCityNameRequest();
        getCountryStateByCityNameRequest.setName(city);

        repository.getCountryStateList(getCountryStateByCityNameRequest).subscribe(new Observer<GetCountryStateByCityNameResponse>() {

            @Override
            public void onSubscribe(Disposable d) {

            }
            @Override
            public void onNext(GetCountryStateByCityNameResponse getCountryStateByCityNameResponse) {
                if (!getCountryStateByCityNameResponse.isHasError()) {
                    addressData.addAll(getCountryStateByCityNameResponse.getData());
                    onGetCityStateCountryList();
                }
            }

            @Override
            public void onError(Throwable e) {

            }
            @Override
            public void onComplete() {
                //setIsLoading(false);
            }
        });
    }
    public ArrayList<CityStateCountryData> getAddressData() {
        return addressData;
    }
    public SingleLiveEvent<Void> getCityStateCountryList() {
        return showCityStateCountryList;
    }

    public void onGetCityStateCountryList() {
        showCityStateCountryList.call();
    }

}
