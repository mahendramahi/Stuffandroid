package com.twc.store.fragments;


import android.view.View;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;


import com.twc.store.R;
import com.twc.store.R2;
import com.twc.store.StoreActivity;
import com.twc.store.StoreCategoryActivity;
import com.twc.store.StoreDetailActivity;

import butterknife.BindView;

/**
 * A simple class.
 */
public class NetMedFragment extends BaseFragment {
    @BindView(R2.id.netMedWebView)
    WebView netMedWebView;
    @BindView(R2.id.progressBar)
    ProgressBar progressBar;


    public static NetMedFragment newInstance() {
        return new NetMedFragment();
    }

    @Override
    public int getFragmentLayout() {
        return R.layout.fragment_net_med;
    }

    @Override
    public void onResume() {
        super.onResume();
       // ((StoreActivity) getActivity()).showHomeAsUpEnableToolbar();
        if(getActivity() instanceof StoreActivity)
        ((StoreActivity) getActivity()).setToolBarTitle("Netmeds");
        else if(getActivity() instanceof StoreDetailActivity)
            ((StoreDetailActivity) getActivity()).setToolBarTitle("Netmeds");
        else if(getActivity() instanceof StoreCategoryActivity)
            ((StoreDetailActivity) getActivity()).setToolBarTitle("Netmeds");
    }

    @Override
    public void onFragmentReady() {
        progressBar.setVisibility(View.VISIBLE);
        netMedWebView.getSettings().setJavaScriptEnabled(true);
        netMedWebView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                progressBar.setVisibility(View.GONE);
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                super.onReceivedError(view, request, error);
                progressBar.setVisibility(View.GONE);
            }
        });
        netMedWebView.loadUrl("http://www.netmeds.com/");
    }
}
