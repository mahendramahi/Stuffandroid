package com.truworth.wellnesscorner.ui.mainapp.createpost.sharemeal;

import android.annotation.SuppressLint;
import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Toast;

import com.truworth.wellnesscorner.BR;
import com.truworth.wellnesscorner.R;
import com.truworth.wellnesscorner.base.BaseFragment;
import com.truworth.wellnesscorner.databinding.FragmentShareMealDetailBinding;
import com.truworth.wellnesscorner.model.FoodsBean;
import com.truworth.wellnesscorner.model.MealDataBean;
import com.truworth.wellnesscorner.ui.mainapp.createpost.ShareActivity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;


public class ShareMealDetailFragment extends BaseFragment<FragmentShareMealDetailBinding, ShareMealDetailViewModel> implements AdapterCallback {
    public static final String TAG = "ShareMealDetailFragment";
    private static final String DATE = "date";
    private static final String MEAL_TYPE = "mealType";
    private static final String TOTAL_CALORIES = "totalCalories";
    private static final String MEMBER_NAME = "memberName";
    private static final String MEMBER_IMAGE = "memberImage";
    private static final String MEAL_DATA = "mealData";

    List<FoodsBean> selectedList;
    MealDataBean mealDataBean;
    ShareMealDetailViewModel viewModel;
    List<FoodsBean> foodList = new ArrayList<>();
    ShareMealDetailAdapter shareMealDetailAdapter;
    RecyclerView recyclerView;
    String date, mealType, totalCalories, memberName, memberImage;

    @SuppressLint("ValidFragment")
    public ShareMealDetailFragment() {
    }

    public static ShareMealDetailFragment newInstance(String date, String mealType, String totalCalories, MealDataBean mealDataBean, String memberName, String memberImage) {
        ShareMealDetailFragment fragment = new ShareMealDetailFragment();
        Bundle args = new Bundle();
        args.putString(DATE, date);
        args.putString(MEAL_TYPE, mealType);
        args.putString(TOTAL_CALORIES, totalCalories);
        args.putString(MEMBER_NAME, memberName);
        args.putString(MEMBER_IMAGE, memberImage);
        args.putSerializable(MEAL_DATA, mealDataBean);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            date = getArguments().getString(DATE);
            mealType = getArguments().getString(MEAL_TYPE);
            totalCalories = getArguments().getString(TOTAL_CALORIES);
            memberName = getArguments().getString(MEMBER_NAME);
            memberImage = getArguments().getString(MEMBER_IMAGE);
            mealDataBean = (MealDataBean) getArguments().getSerializable(MEAL_DATA);
            foodList.clear();
            foodList.addAll(mealDataBean.getFoods());
        }
        selectedList = new ArrayList<>();
        shareMealDetailAdapter = new ShareMealDetailAdapter(getActivity(), foodList, this);
    }


    @Override
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        recyclerView = getViewDataBinding().rvSelectFood;
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false);
        recyclerView.setLayoutManager(linearLayoutManager);
        recyclerView.setAdapter(shareMealDetailAdapter);

        viewModel.getMealDate().set(date);
        viewModel.getMealType().set(mealType);
        viewModel.getTotalCalories().set(totalCalories);

        if (mealType.equals("BREAKFAST")) {
            getViewDataBinding().ivMealImage.setImageResource(R.drawable.breakfast);
        } else if (mealType.equals("LUNCH")) {
            getViewDataBinding().ivMealImage.setImageResource(R.drawable.lunch);
        } else if (mealType.equals("SNACKS")) {
            getViewDataBinding().ivMealImage.setImageResource(R.drawable.snacks);
        } else if (mealType.equals("DINNER")) {
            getViewDataBinding().ivMealImage.setImageResource(R.drawable.dinner);
        }

        attachShareDataObserver();
    }

    @Override
    public int getBindingVariable() {
        return BR.viewModel;
    }

    @Override
    public int getLayoutId() {
        return R.layout.fragment_share_meal_detail;
    }

    @Override
    public ShareMealDetailViewModel getViewModel() {
        viewModel = ViewModelProviders.of(this).get(ShareMealDetailViewModel.class);
        return viewModel;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
    }

    @Override
    public void onDetach() {
        super.onDetach();
    }

    private void attachShareDataObserver() {
        viewModel.getShareData().observe(this, new Observer<Void>() {
            @Override
            public void onChanged(@Nullable Void aVoid) {
                //Success, update UI
                if (selectedList.size() > 0) {
                    getActivity().getSupportFragmentManager().beginTransaction().replace(R.id.shareContainer, ShareMealTemplateFragment.newInstance(date, mealType, selectedList, memberName, memberImage), ShareMealTemplateFragment.TAG).addToBackStack(ShareMealTemplateFragment.TAG).commit();
                } else {
                    Toast.makeText(getActivity(), "Please select item before share!", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    @Override
    public void onMethodCallback(int position, boolean setSelected) {
        if (setSelected) {
            selectedList.add(foodList.get(position));
        } else {
            selectedList.remove(foodList.get(position));
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        //clear selected item checkbox value
        for (int i =0; i<foodList.size(); i++){
            foodList.get(i).setItemChecked(false);
        }
    }
}
