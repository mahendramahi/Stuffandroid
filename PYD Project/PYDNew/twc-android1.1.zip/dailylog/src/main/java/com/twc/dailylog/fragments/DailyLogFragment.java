package com.twc.dailylog.fragments;

import android.animation.ObjectAnimator;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.widget.DrawerLayout;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.DecelerateInterpolator;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.github.sundeepk.compactcalendarview.CompactCalendarView;
import com.twc.dailylog.MealActivity;
import com.twc.dailylog.R;
import com.twc.dailylog.R2;
import com.twc.dailylog.model.beans.DailyLogData;
import com.twc.dailylog.model.beans.DailyLogItem;
import com.twc.dailylog.model.beans.DailyLogSectionItem;
import com.twc.dailylog.model.beans.MemberActivityItem;
import com.twc.dailylog.model.beans.NutritionDataItem;
import com.twc.dailylog.model.requestbody.DailyLogBody;
import com.twc.dailylog.model.requestbody.DeleteActivityByID;
import com.twc.dailylog.model.requestbody.DeleteFoodByID;
import com.twc.dailylog.model.response.ActivityMarkAsReadResponse;
import com.twc.dailylog.model.response.GetDailyLogResponse;
import com.twc.dailylog.rest.RestClient;
import com.twc.dailylog.utils.AnimationFactory;
import com.twc.dailylog.utils.Constant;
import com.twc.dailylog.utils.DailyLogConfig;
import com.twc.dailylog.utils.DateFactory;
import com.twc.dailylog.utils.DialogFactory;
import com.twc.dailylog.utils.NetworkFactory;
import com.twc.dailylog.utils.OnSwipeTouchListener;
import com.twc.dailylog.utils.Utils;
import com.twc.dailylog.views.CustomScrollView;
import com.twc.dailylog.views.CustomTextView;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import butterknife.BindView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class DailyLogFragment extends BaseFragment implements View.OnClickListener{

    @BindView(R2.id.tvBreakfast)
    CustomTextView tvBreakfast;

    @BindView(R2.id.tvLunch)
    CustomTextView tvLunch;

    @BindView(R2.id.tvDinner)
    CustomTextView tvDinner;

    @BindView(R2.id.tvSnacks)
    CustomTextView tvSnacks;

    @BindView(R2.id.Back)
    ImageView Back;

    @BindView(R2.id.imgCalendar)
    ImageView imgCalendar;

    @BindView(R2.id.tvAddmoreBreakfast)
    CustomTextView tvAddMoreBreakfast;
    @BindView(R2.id.tvAddmoreLunch)
    CustomTextView tvAddMoreLunch;
    @BindView(R2.id.tvAddmoreSnacks)
    CustomTextView tvAddMoreSnacks;
    @BindView(R2.id.tvAddmoreDinner)
    CustomTextView tvAddMoreDinner;
    /*variable here*/
    @BindView(R2.id.tvAddmoreExercise)
    CustomTextView tvAddMoreExercise;
    @BindView(R2.id.rootView)
    LinearLayout rootLayout;
    @BindView(R2.id.scrollChildLayout)
    RelativeLayout scrollChildLayout;
    @BindView(R2.id.tvConsume)
    CustomTextView tvConsume;
    @BindView(R2.id.tvCalorieValue)
    CustomTextView tvCalorieValue;
    @BindView(R2.id.tvCalorieStatus)
    CustomTextView tvCalorieStatus;
    @BindView(R2.id.tvBurned)
    CustomTextView tvBurned;
    @BindView(R2.id.tvCarbs)
    CustomTextView tvCarbs;
    @BindView(R2.id.tvProtin)
    CustomTextView tvProtein;
    @BindView(R2.id.tvFat)
    CustomTextView tvFat;
    @BindView(R2.id.tvDate)
    CustomTextView tvDate;
    @BindView(R2.id.pbCarbs)
    ProgressBar pbCarbs;
    @BindView(R2.id.pbProtin)
    ProgressBar pbProtein;
    @BindView(R2.id.pbFat)
    ProgressBar pbFat;
    @BindView(R2.id.imgPrevious)
    ImageView imgPrevious;
    @BindView(R2.id.imgNext)
    ImageView imgNext;
    @BindView(R2.id.tvScrollMonth)
    CustomTextView tvScrollMonth;
    @BindView(R2.id.CalendarLayout)
    LinearLayout CalendarLayout;
    @BindView(R2.id.compactCalendarView)
    CompactCalendarView compactCalendarView;
    @BindView(R2.id.overAllProgres)
    ProgressBar overAllProgress;
    @BindView(R2.id.transparent)
    View transparent;
    @BindView(R2.id.linearBreakfastSubItems)
    LinearLayout linearBreakfastSubItems;
    @BindView(R2.id.linearLunchSubItems)
    LinearLayout linearLunchSubItems;
    @BindView(R2.id.linearSnacksSubItems)
    LinearLayout linearSnacksSubItems;
    @BindView(R2.id.linearDinnerSubItems)
    LinearLayout linearDinnerSubItems;
    @BindView(R2.id.linearExerciseSubItems)
    LinearLayout linearExerciseSubItems;
    @BindView(R2.id.scrollLayout)
    CustomScrollView scrollLayout;
    private DailyLogData objDailyLog;
    private List<NutritionDataItem> NutritionDataItemList;
    private List<MemberActivityItem> MemberActivityItemList;
    private String selectedDate;
    private boolean shouldShow = true;
    private boolean dateSelected = false;
    private boolean isFirstLoad = false;
    private boolean isSwipeAllow = false;
    private int compactCalendarInputDt, compactCalendarInputDateCurrentDate;
    private int cx;
    private int finalRadius;
    private int cy;

    private Handler handler = new Handler();
    private Runnable runnable = new Runnable() {
        @Override
        public void run() {
            fetchDailyLogAPI();
        }
    };

    public static DailyLogFragment newInstance(Bundle bundle) {
        DailyLogFragment fragment = new DailyLogFragment();
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
        setRetainInstance(true);
    }


    @Override
    public void onResume() {
        super.onResume();
        getView().setFocusableInTouchMode(true);
        getView().requestFocus();
        getView().setOnKeyListener(new View.OnKeyListener() {

            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (keyCode == KeyEvent.KEYCODE_BACK && event.getAction() == KeyEvent.ACTION_DOWN) {
                    getActivity().setResult(Activity.RESULT_OK);
                    getActivity().finish();
                    return true;

                }
                return false;
            }
        });
        ((MealActivity) getActivity()).getSupportActionBar().hide();
       /* ((MealActivity) getActivity()).setToolBarTitle("Daily Log");

        ((MealActivity) getActivity()).mToolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                getActivity().finish();
            }
        });*/
    }

   /* @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.menu_daily_log, menu);

        super.onCreateOptionsMenu(menu, inflater);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int i = item.getItemId();
        if (i == R.id.action_done) {

            compactCalendarView.setCurrentDate(DateFactory.getInstance().getDate(selectedDate, "EEE,MMM dd,yyyy"));

            tvScrollMonth.setText(DateFactory.getInstance().formatDate("EEEE,MMMM dd,yyyy", "MMMM - yyyy", selectedDate));
            cx = CalendarLayout.getLeft();
            cy = CalendarLayout.getTop();
            finalRadius = Math.max(CalendarLayout.getWidth(), CalendarLayout.getHeight());
            if (shouldShow) {
                AnimationFactory.circularReveal(CalendarLayout, true, cx, cy, finalRadius);
                shouldShow = false;
            } else {
                AnimationFactory.circularReveal(CalendarLayout, false, cx, cy, finalRadius);
                shouldShow = true;
            }

        }
        return super.onOptionsItemSelected(item);
    }*/

    @Override
    public int getFragmentLayout() {
        return R.layout.fragment_dailylog;
    }

    @Override
    public void onFragmentReady() {
        if (getArguments() != null) {
            selectedDate = DateFactory.getInstance().formatDate("MM/dd/yyyy", "EEEE,MMMM dd,yyyy", getArguments().getString("date"));
            tvScrollMonth.setText(DateFactory.getInstance().formatDate("EEEE,MMMM dd,yyyy", "MMMM - yyyy", selectedDate));
        } else {
            selectedDate = DateFactory.getInstance().getTodayDate("EEEE,MMMM dd,yyyy");
            tvScrollMonth.setText(DateFactory.getInstance().getTodayDate("MMMM - yyyy"));
        }

        tvDate.setText(selectedDate);

        checkFutureDate();

        setListeners();
        if (!isFirstLoad) {
            isFirstLoad = true;
            handler.postDelayed(runnable, Constant.API_POST_DELAYED_TIME);

        } else {
            DisplayData();
        }

    }


    private void checkFutureDate() {
        if (isTodayDate()) {
            imgNext.setVisibility(View.GONE);
            isSwipeAllow = false;
        } else {
            imgNext.setVisibility(View.VISIBLE);
            isSwipeAllow = true;
        }
    }

    private void setListeners() {

        Back.setOnClickListener(this);
        imgCalendar.setOnClickListener(this);
        imgNext.setOnClickListener(this);
        imgPrevious.setOnClickListener(this);

        tvBreakfast.setOnClickListener(this);
        tvLunch.setOnClickListener(this);
        tvDinner.setOnClickListener(this);
        tvSnacks.setOnClickListener(this);


        tvAddMoreBreakfast.setOnClickListener(this);
        tvAddMoreLunch.setOnClickListener(this);

        tvAddMoreSnacks.setOnClickListener(this);
        tvAddMoreDinner.setOnClickListener(this);

        tvAddMoreExercise.setOnClickListener(this);

        scrollChildLayout.setOnTouchListener(new OnSwipeTouchListener(getActivity()) {

            public void onSwipeRight() {
                if (isSwipeAllow)// check if selected date current date than swipe should not work from right to left
                {
                    selectedDate = DateFactory.getInstance().getNextDate(selectedDate, 1, "EEEE,MMMM dd,yyyy");
                    tvDate.setText(selectedDate);
                    fetchDailyLogAPI();
                }


            }

            public void onSwipeLeft() {

                selectedDate = DateFactory.getInstance().getPreviousDate(selectedDate, 1, "EEEE,MMMM dd,yyyy");
                tvDate.setText(selectedDate);
                fetchDailyLogAPI();

            }

            @Override
            public void onClick(View view) {

            }
        });


        compactCalendarView.setListener(new CompactCalendarView.CompactCalendarViewListener() {
            @Override
            public void onDayClick(Date dateClicked) {
                compactCalendarInputDt = Integer.parseInt(DateFactory.getInstance().getDateFromDateFormat(dateClicked, "yyyyMMdd"));
                compactCalendarInputDateCurrentDate = Integer.parseInt(DateFactory.getInstance().formatDate("EEEE,MMMM dd,yyyy", "yyyyMMdd", DateFactory.getInstance().getTodayDate("EEEE,MMMM dd,yyyy")));
                if (compactCalendarInputDt > compactCalendarInputDateCurrentDate) {
                    //user selected future date than show message
                    Utils.showSnackBarMessage(rootLayout, "Date should be less than or equal from current date.");
                } else {
                    selectedDate = DateFactory.getInstance().getDateFromDateFormat(dateClicked, "EEEE,MMMM dd,yyyy");
                    dateSelected = true;
                    tvDate.setText(selectedDate);
                    AnimationFactory.circularReveal(CalendarLayout, false, cx, cy, finalRadius);
                    //  compactCalendarView.hideCalendar();
                    //  transparent.setVisibility(View.GONE);
                    //   tvScrollMonth.setVisibility(View.GONE);
                    shouldShow = true;
                    if (dateSelected) {
                        dateSelected = false;
                        handler.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                // Do something after 5s = 5000ms
                                //   compactCalendarView.setVisibility(View.GONE);
                                fetchDailyLogAPI();
                            }
                        }, 500);

                    }
                }

            }

            @Override
            public void onMonthScroll(Date firstDayOfNewMonth) {
                // tvScrollMonth.setText(dateFormatForMonth.format(firstDayOfNewMonth));
                tvScrollMonth.setText(DateFactory.getInstance().getDateFromDateFormat(firstDayOfNewMonth, "MMMM - yyyy"));
            }
        });

    }

    private void fetchDailyLogAPI() {
        String callingDate = DateFactory.getInstance().formatDate("EEEE,MMMM dd,yyyy", "MM/dd/yyyy", selectedDate);
        checkFutureDate();
        if (NetworkFactory.getInstance().isNetworkAvailable(getActivity())) {
           /* final ProgressDialog pd;
            pd = ProgressDialog.show(getActivity(), "", "" + getString(R.string.app_name));*/


            DailyLogBody dailylogBody = new DailyLogBody();
            dailylogBody.setMemberID(DailyLogConfig.dailyLogUser.getUserID());
            dailylogBody.setDate(callingDate);

            RestClient restClient = new RestClient(getActivity(), DailyLogConfig.BASE_URL, DailyLogConfig.DEBUG);
            restClient.getDailyLogService().getDailyLog(dailylogBody).enqueue(new Callback<GetDailyLogResponse>() {
                @Override
                public void onResponse(Call<GetDailyLogResponse> call, Response<GetDailyLogResponse> response) {
                    if (isAdded() && getActivity() != null) {



                        if (response != null && response.body() != null) {

                            if (response.body().getStatus() == 0) {
                                objDailyLog = response.body().getData().getDietLogData();

                                NutritionDataItemList = response.body().getData().getNutritionData();
                                MemberActivityItemList = response.body().getData().getMemberActivity();
                                DisplayData();
                            } else {
                                DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_response_failure), getString(R.string.str_ok), false);
                                // Toast.makeText(getActivity(), getString(R.string.msg_api_response_failure), Toast.LENGTH_SHORT).show();

                            }

                        } else {
                            DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_response_null), getString(R.string.str_ok), false);
                            // Toast.makeText(getActivity(), getString(R.string.msg_api_response_null), Toast.LENGTH_SHORT).show();

                        }
                    }
                }

                @Override
                public void onFailure(Call<GetDailyLogResponse> call, Throwable t) {
                    if (isAdded() && getActivity() != null) {
                            DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.msg_api_failure), getString(R.string.str_ok), false);
                    }

                }
            });

        } else {
            Utils.showSnackBarMessage(rootLayout, getString(R.string.internet_not_available));
        }
    }


    private boolean isTodayDate() {
        return selectedDate.equals(DateFactory.getInstance().getTodayDate("EEEE,MMMM dd,yyyy"));
    }

    private void DisplayData() {
        SetDataToLogDetail(objDailyLog);

        if (isTodayDate()) {
            tvAddMoreBreakfast.setVisibility(View.VISIBLE);
            tvAddMoreSnacks.setVisibility(View.VISIBLE);
            tvAddMoreLunch.setVisibility(View.VISIBLE);
            tvAddMoreDinner.setVisibility(View.VISIBLE);
            tvAddMoreExercise.setVisibility(View.VISIBLE);
        } else {
            tvAddMoreBreakfast.setVisibility(View.GONE);
            tvAddMoreSnacks.setVisibility(View.GONE);
            tvAddMoreLunch.setVisibility(View.GONE);
            tvAddMoreDinner.setVisibility(View.GONE);
            tvAddMoreExercise.setVisibility(View.GONE);
        }
        /**Section create*/
        ArrayList<DailyLogSectionItem> DailyLogSectionList = new ArrayList<>();
        DailyLogSectionList.clear();
        linearBreakfastSubItems.removeAllViews();
        linearLunchSubItems.removeAllViews();
        linearSnacksSubItems.removeAllViews();
        linearDinnerSubItems.removeAllViews();
        linearExerciseSubItems.removeAllViews();

        DailyLogSectionItem sectionItem = new DailyLogSectionItem();
        sectionItem.setSectionName("Breakfast");
        ArrayList<DailyLogItem> sectionDataItem = new ArrayList<>();
        sectionItem.setDailyLogDataArrayList(sectionDataItem);
        DailyLogSectionList.add(sectionItem);

        DailyLogSectionItem sectionItem1 = new DailyLogSectionItem();
        sectionItem1.setSectionName("Snacks");
        ArrayList<DailyLogItem> sectionNutritionDataItem1 = new ArrayList<>();
        sectionItem1.setDailyLogDataArrayList(sectionNutritionDataItem1);
        DailyLogSectionList.add(sectionItem1);

        DailyLogSectionItem sectionItem2 = new DailyLogSectionItem();
        sectionItem2.setSectionName("Lunch");
        ArrayList<DailyLogItem> sectionNutritionDataItem2 = new ArrayList<>();
        sectionItem2.setDailyLogDataArrayList(sectionNutritionDataItem2);
        DailyLogSectionList.add(sectionItem2);

        DailyLogSectionItem sectionItem3 = new DailyLogSectionItem();
        sectionItem3.setSectionName("Dinner");
        ArrayList<DailyLogItem> sectionNutritionDataItem3 = new ArrayList<>();
        sectionItem3.setDailyLogDataArrayList(sectionNutritionDataItem3);
        DailyLogSectionList.add(sectionItem3);

        DailyLogSectionItem sectionItem4 = new DailyLogSectionItem();
        ArrayList<DailyLogItem> sectionMemberActivityItem4 = new ArrayList<>();
        sectionItem4.setDailyLogDataArrayList(sectionMemberActivityItem4);
        sectionItem4.setSectionName("Exercise");
        DailyLogSectionList.add(sectionItem4);

        /**---Item add for section type---*/


        List<DailyLogItem> DailyLogList = new ArrayList<>();
        if (NutritionDataItemList != null && NutritionDataItemList.size() > 0) {
            for (int i = 0; i < NutritionDataItemList.size(); i++) {
                NutritionDataItem data = NutritionDataItemList.get(i);
                DailyLogItem obj = new DailyLogItem();
                obj.setNutritionMealType(data.getNutritionMealType());
                obj.setMemberID(data.getNutritionMemberID());
                obj.setNutritionID(data.getNutritionID());
                obj.setFoodID(data.getFOODID());
                obj.setName(data.getNutritionFoodItem());
                obj.setNutritionQuantity(data.getNutritionQuantity());
                obj.setNutritionCalorie("" + data.getNutritionCalorie());
                obj.setCalorie("" + data.getCalorie());
                obj.setNutritionCarbs("" + data.getNutritionCarbs());
                obj.setNutritionFat("" + data.getNutritionFat());
                obj.setNutritionSodium("" + data.getNutritionSodium());
                obj.setNutritionProtein("" + data.getNutritionProtien());
                obj.setNutritionStandardServing(data.getNutritionStandardServing());
                obj.setDate(data.getNutritionDate());
                obj.setTime(data.getNutritionTime());
                obj.setType("Food");
                obj.setTotalCalories(false);
                DailyLogList.add(obj);
            }
        }
        if (MemberActivityItemList != null && MemberActivityItemList.size() > 0) {
            for (int i = 0; i < MemberActivityItemList.size(); i++) {
                MemberActivityItem data = MemberActivityItemList.get(i);
                DailyLogItem obj = new DailyLogItem();
                obj.setNutritionMealType("");
                obj.setActivityID(data.getActivityID());
                obj.setActivityDuration("" + data.getActivityDuration());
                obj.setActivityCalorie("" + data.getActivityCalorie());
                obj.setCalories("" + data.getCalories());
                obj.setName(data.getActivityName());
                obj.setDate(data.getActivityDate());
                obj.setTime(data.getActivityTime());
                obj.setType("Exercise");
                obj.setTotalCalories(false);
                DailyLogList.add(obj);
            }
        }
        double breakfastTotalCalories = 0.0,
                lunchTotalCalories = 0.0,
                snacksTotalCalories = 0.0,
                dinnerTotalCalories = 0.0,
                activityTotalCalories = 0.0;
        for (DailyLogItem item : DailyLogList) {
            if (item.getNutritionMealType().equalsIgnoreCase("Breakfast") && item.getType().equalsIgnoreCase("Food")) {
                DailyLogSectionList.get(0).getDailyLogDataArrayList().add(item);
                if (item.getNutritionCalorie() != null && item.getNutritionCalorie().length() > 0) {
                    breakfastTotalCalories += Double.parseDouble(item.getNutritionCalorie());
                }
            } else if (item.getNutritionMealType().equalsIgnoreCase("Lunch") && item.getType().equalsIgnoreCase("Food")) {
                DailyLogSectionList.get(2).getDailyLogDataArrayList().add(item);
                if (item.getNutritionCalorie() != null && item.getNutritionCalorie().length() > 0) {
                    lunchTotalCalories += Double.parseDouble(item.getNutritionCalorie());
                }
            } else if (item.getNutritionMealType().equalsIgnoreCase("Dinner") && item.getType().equalsIgnoreCase("Food")) {
                DailyLogSectionList.get(3).getDailyLogDataArrayList().add(item);
                if (item.getNutritionCalorie() != null && item.getNutritionCalorie().length() > 0) {
                    dinnerTotalCalories += Double.parseDouble(item.getNutritionCalorie());
                }
            } else if (item.getType().equalsIgnoreCase("Exercise")) {
                DailyLogSectionList.get(4).getDailyLogDataArrayList().add(item);
                if (item.getActivityCalorie() != null && item.getActivityCalorie().length() > 0) {
                    activityTotalCalories += Double.parseDouble(item.getActivityCalorie());
                }
            } else {
                DailyLogSectionList.get(1).getDailyLogDataArrayList().add(item);
                if (item.getNutritionCalorie() != null && item.getNutritionCalorie().length() > 0) {
                    snacksTotalCalories += Double.parseDouble(item.getNutritionCalorie());
                }
            }
        }

                    /* create a DailyLogItem item for every item to show total calories*/

        for (int i = 0; i < DailyLogSectionList.size(); i++) {
            DailyLogItem dailyLogItem = new DailyLogItem();
            dailyLogItem.setTotalCalories(true);
            if (i == 0) {
                dailyLogItem.setListTotalCalories(breakfastTotalCalories);
                DailyLogSectionList.get(0).getDailyLogDataArrayList().add(dailyLogItem);
            }
            if (i == 2) {
                dailyLogItem.setListTotalCalories(lunchTotalCalories);
                DailyLogSectionList.get(2).getDailyLogDataArrayList().add(dailyLogItem);
            }
            if (i == 3) {
                dailyLogItem.setListTotalCalories(dinnerTotalCalories);
                DailyLogSectionList.get(3).getDailyLogDataArrayList().add(dailyLogItem);
            }
            if (i == 4) {
                dailyLogItem.setListTotalCalories(activityTotalCalories);
                DailyLogSectionList.get(4).getDailyLogDataArrayList().add(dailyLogItem);
            }
            if (i == 1) {
                dailyLogItem.setListTotalCalories(snacksTotalCalories);
                DailyLogSectionList.get(1).getDailyLogDataArrayList().add(dailyLogItem);
            }
        }


                        /*DailyLogAdaptor dailyLogSectionAdapter = new DailyLogAdaptor(DailyLogSectionList, DailyLogList, selectedDate, getActivity());
                        rvLog.setAdapter(dailyLogSectionAdapter);*/

        for (DailyLogSectionItem dailyLogSectionItem : DailyLogSectionList) {
            if (dailyLogSectionItem.getSectionName().equalsIgnoreCase("Breakfast")) {
                addLayout(linearBreakfastSubItems, dailyLogSectionItem.getDailyLogDataArrayList());
            } else if (dailyLogSectionItem.getSectionName().equalsIgnoreCase("Lunch")) {
                addLayout(linearLunchSubItems, dailyLogSectionItem.getDailyLogDataArrayList());
            } else if (dailyLogSectionItem.getSectionName().equalsIgnoreCase("Snacks")) {
                addLayout(linearSnacksSubItems, dailyLogSectionItem.getDailyLogDataArrayList());
            } else if (dailyLogSectionItem.getSectionName().equalsIgnoreCase("Dinner")) {
                addLayout(linearDinnerSubItems, dailyLogSectionItem.getDailyLogDataArrayList());
            } else if (dailyLogSectionItem.getSectionName().equalsIgnoreCase("Exercise")) {
                addLayout(linearExerciseSubItems, dailyLogSectionItem.getDailyLogDataArrayList());
            }
        }

    }

    private void addLayout(LinearLayout mLinearLayout, ArrayList<DailyLogItem> dailyLogItems) {

        for (final DailyLogItem dailyLogItem : dailyLogItems) {
            View itemView = View.inflate(getActivity(), R.layout.row_daily_low, null);
            LinearLayout rowLayout = itemView.findViewById(R.id.rowLayout);
            CustomTextView tvFoodName = itemView.findViewById(R.id.tvFoodName);
            CustomTextView tvFoodDesc = itemView.findViewById(R.id.tvFoodDesc);
            ImageView imgArrow = itemView.findViewById(R.id.imgArrow);
            ImageView imgDelete = itemView.findViewById(R.id.imgDelete);

            if (dailyLogItem.isTotalCalories()) {
                imgDelete.setVisibility(View.GONE);
                imgArrow.setVisibility(View.GONE);
                tvFoodDesc.setVisibility(View.GONE);
                tvFoodName.setText(String.format("%s Calories",(int)Math.round(dailyLogItem.getListTotalCalories())));
                rowLayout.setBackgroundResource(R.drawable.bottom_curve_border);
            } else {
                rowLayout.setBackgroundResource(R.drawable.simple_curve_border);
                if (isTodayDate()) {
                    imgDelete.setVisibility(View.VISIBLE);
                    imgArrow.setVisibility(View.VISIBLE);
                } else {
                    imgDelete.setVisibility(View.GONE);
                    imgArrow.setVisibility(View.GONE);
                }

              /* if (dailyLogItem.getName().equalsIgnoreCase(Constant.S_HEALTH) || dailyLogItem.getName().equalsIgnoreCase(Constant.FITBIT) || dailyLogItem.getName().equalsIgnoreCase(Constant.E_FIT) || dailyLogItem.getName().equalsIgnoreCase(Constant.GOOGLE_FIT) || dailyLogItem.getName().equalsIgnoreCase(Constant.MISFIT) || dailyLogItem.getName().equalsIgnoreCase(Constant.GARMIN) || dailyLogItem.getName().contentEquals("Apple")) {
                imgDelete.setVisibility(View.GONE);
                   imgArrow.setVisibility(View.GONE);
             }*/

                tvFoodDesc.setVisibility(View.VISIBLE);
                tvFoodName.setText(dailyLogItem.getName());
                String desc;
                if (dailyLogItem.getType().equalsIgnoreCase("Food")) {
                    desc = dailyLogItem.getNutritionQuantity() + " " + dailyLogItem.getNutritionStandardServing() + " ," + (int)Math.round(Float.parseFloat(dailyLogItem.getNutritionCalorie())) + " calories";
                } else {
                    int activityDuration;
                    try {
                        activityDuration = Integer.parseInt(dailyLogItem.getActivityDuration());
                    } catch (Exception e) {
                        activityDuration = 0;
                    }
                    if (activityDuration != 0)
                        desc = dailyLogItem.getActivityDuration() + " mins, " + (int)Math.round(Float.parseFloat(dailyLogItem.getActivityCalorie())) + " calories";
                    else
                        desc = (int)Math.round(Float.parseFloat(dailyLogItem.getActivityCalorie())) + " calories";
                }

                tvFoodDesc.setText(desc);


            }

            itemView.setTag(dailyLogItem);
            if (isTodayDate()) {

                imgDelete.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        DialogFactory.getInstance().showAlertDialog(getActivity(), null, 0, "Are you sure want to delete it?", "Yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                dialogInterface.cancel();
                                DeleteDataFromServer(dailyLogItem);
                            }
                        }, "No", false);

                    }
                });
                itemView.setOnTouchListener(new OnSwipeTouchListener(getActivity()) {

                    public void onSwipeRight() {
                        if (isSwipeAllow)// check if selected date current date than swipe should not work from right to left
                        {
                            selectedDate = DateFactory.getInstance().getNextDate(selectedDate, 1, "EEEE,MMMM dd,yyyy");
                            tvDate.setText(selectedDate);
                            fetchDailyLogAPI();
                        }
                    }

                    public void onSwipeLeft() {
                        selectedDate = DateFactory.getInstance().getPreviousDate(selectedDate, 1, "EEEE,MMMM dd,yyyy");
                        tvDate.setText(selectedDate);
                        fetchDailyLogAPI();
                    }

                    @Override
                    public void onClick(View view) {
                        //Utils.printLog("itemView","click");
                        navigateToItemDetailView(view);
                    }
                });
            }

            mLinearLayout.addView(itemView);
        }


    }

    private void DeleteDataFromServer(DailyLogItem dailyLogItem) {
        if (NetworkFactory.getInstance().isNetworkAvailable(getActivity())) {
            final ProgressDialog pd;
            pd = ProgressDialog.show(getActivity(), "", "" + getString(R.string.app_name));
            if (dailyLogItem.getType().equalsIgnoreCase("Food"))//delete food item from server side
            {
                DeleteFoodByID deleteFoodByID = new DeleteFoodByID();
                deleteFoodByID.setNutritionID(dailyLogItem.getNutritionID());
                RestClient restClient = new RestClient(getActivity(), DailyLogConfig.BASE_URL, DailyLogConfig.DEBUG);
                restClient.getDailyLogService().getDeleteFoodByID(deleteFoodByID).enqueue(new Callback<ActivityMarkAsReadResponse>() {
                    @Override
                    public void onResponse(Call<ActivityMarkAsReadResponse> call, Response<ActivityMarkAsReadResponse> response) {
                        if (pd != null && pd.isShowing()) {
                            pd.dismiss();
                        }
                        if (response != null && response.body() != null) {
                            showAlertMessage(response.body().getStatus());
                        }
                    }

                    @Override
                    public void onFailure(Call<ActivityMarkAsReadResponse> call, Throwable t) {
                        if (pd != null && pd.isShowing()) {
                            pd.dismiss();
                            DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.network_error), getString(R.string.str_ok), false);
                        }

                    }
                });
            } else//delete Activity from server side
            {
                DeleteActivityByID deleteactivityByID = new DeleteActivityByID();
                deleteactivityByID.setActivityID(dailyLogItem.getActivityID());
                RestClient restClient = new RestClient(getActivity(), DailyLogConfig.BASE_URL, DailyLogConfig.DEBUG);
                restClient.getDailyLogService().getDeleteActivityByID(deleteactivityByID).enqueue(new Callback<ActivityMarkAsReadResponse>() {
                    @Override
                    public void onResponse(Call<ActivityMarkAsReadResponse> call, Response<ActivityMarkAsReadResponse> response) {
                        if (pd != null && pd.isShowing()) {
                            pd.dismiss();
                        }
                        if (response != null && response.body() != null) {
                            showAlertMessage(response.body().getStatus());
                        }
                    }

                    @Override
                    public void onFailure(Call<ActivityMarkAsReadResponse> call, Throwable t) {
                        if (pd != null && pd.isShowing()) {
                            pd.dismiss();
                            DialogFactory.getInstance().showAlertDialog(getActivity(), getString(R.string.app_name), 0, getString(R.string.network_error), getString(R.string.str_ok), false);
                        }

                    }
                });
            }
        } else {
            Utils.showSnackBarMessage(rootLayout, getString(R.string.internet_not_available));
        }


    }

    private void showAlertMessage(int status) {
        if (status == 0) {
            /*DialogFactory.getInstance().showAlertDialog(getActivity(), null, 0, "Data Deleted successfully", "Ok", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    dialogInterface.cancel();
                    fetchDailyLogAPI();
                }
            }, null, false);*/
            fetchDailyLogAPI();
        } else {
            Toast.makeText(getActivity(), getString(R.string.msg_api_response_failure), Toast.LENGTH_SHORT).show();
        }
    }

    private void navigateToItemDetailView(View view) {
        DailyLogItem dailyLogItem = (DailyLogItem) view.getTag();
        if (dailyLogItem.getType() != null) {
            if (dailyLogItem.getType().equalsIgnoreCase("Exercise")) {
              /*  if (dailyLogItem.getName().equalsIgnoreCase(Constant.S_HEALTH) || dailyLogItem.getName().equalsIgnoreCase(Constant.FITBIT) || dailyLogItem.getName().equalsIgnoreCase(Constant.E_FIT) || dailyLogItem.getName().equalsIgnoreCase(Constant.GOOGLE_FIT) || dailyLogItem.getName().contentEquals("Apple")|| dailyLogItem.getName().equalsIgnoreCase(Constant.MISFIT)) {
                    return;
                }*/
                double activityCal = Double.parseDouble(dailyLogItem.getActivityCalorie());
                double activityDur = Double.parseDouble(dailyLogItem.getActivityDuration());

                double CaloriesBurnedIn1Min = (activityCal / activityDur);
                Bundle bundle = new Bundle();

                bundle.putInt("ID", dailyLogItem.getActivityID());//put 0 for the new activity id
                bundle.putString("Name", dailyLogItem.getName());
                bundle.putInt("Duration", Integer.parseInt(dailyLogItem.getActivityDuration()));
                bundle.putDouble("CaloriesBurnedIn1Min", CaloriesBurnedIn1Min);
                bundle.putString("redirectFrom", DailyLogFragment.class.getSimpleName());
                bundle.putString("Time", dailyLogItem.getTime());
                bundle.putString("Date", dailyLogItem.getDate());

                Utils.replaceFragment(getFragmentManager(), TrackActivityFragment.newInstance(bundle), TrackActivityFragment.class.getSimpleName(), true, R.id.fragmentContainerMeal);
            } else {
                Bundle bundle = new Bundle();

                bundle.putInt("foodId", dailyLogItem.getFoodID());
                bundle.putInt("nutritionId", dailyLogItem.getNutritionID());
                bundle.putDouble("quantity", dailyLogItem.getNutritionQuantity());
                bundle.putString("Time", dailyLogItem.getTime());
                bundle.putString("Date", dailyLogItem.getDate());
                Utils.replaceFragment(getFragmentManager(), AddFoodFragment.newInstance(bundle), AddFoodFragment.class.getSimpleName(), true, R.id.fragmentContainerMeal);
            }
        }
    }

    private String getProgressLabelText(double value) {
        DecimalFormat df = new DecimalFormat("#.##");
        if (value < 0) {
            return df.format((-1) * (Math.round(value))) + "g over";
        } else {
            return df.format(Math.round(value)) + "g left";
        }
    }

    private void SetDataToLogDetail(DailyLogData obj) {

        if (obj != null) {
            tvConsume.setText(String.format("%d", (int)Math.round(obj.getTotalCaloriesConsumed())));
            tvBurned.setText(String.format("%d", (int)Math.round(obj.getTotalCaloriesBurned())));
            Double leftCarbs = obj.getMemberTargetCarbs() - obj.getTotalCarbsConsumed();
            Double leftProtein = obj.getMemberTargetProtein() - obj.getTotalProteinConsumed();
            Double leftFat = obj.getMemberTargetFat() - obj.getTotalFatConsumed();

            String leftCarbsText = getProgressLabelText((int)Math.round(leftCarbs));
            tvCarbs.setText(leftCarbsText);

            String leftProteinText = getProgressLabelText((int)Math.round(leftProtein));
            tvProtein.setText(leftProteinText);

            String leftFatText = getProgressLabelText((int)Math.round(leftFat));
            tvFat.setText(leftFatText);

            int setProgress = obj.getPercentage();

            //for calorie progress
            ObjectAnimator animationCalorie;
            int animationDuration = 1500; // 2500ms = 2,5s
            if (setProgress <= 0) {
                animationCalorie = ObjectAnimator.ofInt(overAllProgress, "progress", 0);
            } else {
                animationCalorie = ObjectAnimator.ofInt(overAllProgress, "progress", setProgress);
            }
            animationCalorie.setDuration(animationDuration); // 1.5 second
            animationCalorie.setInterpolator(new DecelerateInterpolator());
            animationCalorie.start();

        /*overAllProgress.setProgressBarWidth(getResources().getDimension(R.dimen.progressBarWidth));
        overAllProgress.setBackgroundProgressBarWidth(getResources().getDimension(R.dimen.progressBarWidth));*/

            // Default duration = 1500ms


            String concatenateText = "Calories";
            tvCalorieValue.setText(String.format("%d", (int)Math.round(obj.getDifference())));
            tvCalorieStatus.setText(String.format(Locale.getDefault(), "%s\n%s", concatenateText, String.valueOf(obj.getOverUnder())));
            int fatProgress = 0;
            if (obj.getTotalFatConsumed() != 0) {
                long fatPercent = 0;
                if (obj.getMemberTargetFat() > 0) {
                    fatPercent = Math.round((obj.getTotalFatConsumed() / obj.getMemberTargetFat()) * 100);
                }

                fatProgress = Integer.parseInt("" + fatPercent);
            }
            final int progress_fat = getProgressValue(leftFat, fatProgress);

            int proteinProgress = 0;
            if (obj.getTotalProteinConsumed() != 0) {
                long proteinPercent = 0;
                if (obj.getMemberTargetProtein() > 0) {
                    proteinPercent = Math.round((obj.getTotalProteinConsumed() / obj.getMemberTargetProtein()) * 100);
                }
                proteinProgress = Integer.parseInt("" + proteinPercent);
            }
            final int progress_protein = getProgressValue(leftProtein, proteinProgress);

            int carbsProgress = 0;
            if (obj.getTotalCarbsConsumed() != 0) {
                long carbsPercent = 0;
                if (obj.getMemberTargetCarbs() > 0) {
                    carbsPercent = Math.round((obj.getTotalCarbsConsumed() / obj.getMemberTargetCarbs()) * 100);
                }
                carbsProgress = Integer.parseInt("" + carbsPercent);
            }
            final int progress_carbs = getProgressValue(leftCarbs, carbsProgress);

            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    //for fat progress
                    ObjectAnimator animation = ObjectAnimator.ofInt(pbFat, "progress", progress_fat);
                    animation.setDuration(500); // 0.5 second
                    animation.setInterpolator(new DecelerateInterpolator());
                    animation.start();
                    //for protein progress
                    ObjectAnimator animation1 = ObjectAnimator.ofInt(pbProtein, "progress", progress_protein);
                    animation1.setDuration(500); // 0.5 second
                    animation1.setInterpolator(new DecelerateInterpolator());
                    animation1.start();

                    //for carbs progress
                    ObjectAnimator animation2 = ObjectAnimator.ofInt(pbCarbs, "progress", progress_carbs);
                    animation2.setDuration(500); // 0.5 second
                    animation2.setInterpolator(new DecelerateInterpolator());
                    animation2.start();


                }
            }, 500);

        }
    }

    private int getProgressValue(double value, int setValue) {
        if (value < 0) {
            return 100;
        } else {
            return setValue;
        }
    }

    @Override
    public void onClick(View v) {
        Bundle bundle = new Bundle();
        int i = v.getId();

       if(i==R.id.tvBreakfast){
           if (isTodayDate()) {
               bundle.putString("trackMealType", "Breakfast");
               Utils.replaceFragment(getActivity().getFragmentManager(), TrackMealFragment.newInstance(bundle), TrackMealFragment.class.getSimpleName(), true, R.id.fragmentContainerMeal);
           }
       }
       else if(i==R.id.tvLunch){
           if (isTodayDate()) {
               bundle.putString("trackMealType", "Lunch");
               Utils.replaceFragment(getActivity().getFragmentManager(), TrackMealFragment.newInstance(bundle), TrackMealFragment.class.getSimpleName(), true, R.id.fragmentContainerMeal);
           }
       }
       else if(i==R.id.tvSnacks){
           if (isTodayDate()) {
               bundle.putString("trackMealType", "Snacks");
               Utils.replaceFragment(getActivity().getFragmentManager(), TrackMealFragment.newInstance(bundle), TrackMealFragment.class.getSimpleName(), true, R.id.fragmentContainerMeal);
           }
       }
       else if(i==R.id.tvDinner){
           if (isTodayDate()) {
               bundle.putString("trackMealType", "Dinner");
               Utils.replaceFragment(getActivity().getFragmentManager(), TrackMealFragment.newInstance(bundle), TrackMealFragment.class.getSimpleName(), true, R.id.fragmentContainerMeal);
           }
       }
       else if(i==R.id.Back){
           getActivity().setResult(Activity.RESULT_OK);
           getActivity().finish();
       }
       else if(i==R.id.imgCalendar){
           compactCalendarView.setCurrentDate(DateFactory.getInstance().getDate(selectedDate, "EEE,MMM dd,yyyy"));

           tvScrollMonth.setText(DateFactory.getInstance().formatDate("EEEE,MMMM dd,yyyy", "MMMM - yyyy", selectedDate));
           cx = CalendarLayout.getLeft();
           cy = CalendarLayout.getTop();
           finalRadius = Math.max(CalendarLayout.getWidth(), CalendarLayout.getHeight());
           if (shouldShow) {
               AnimationFactory.circularReveal(CalendarLayout, true, cx, cy, finalRadius);
               shouldShow = false;
           } else {
               AnimationFactory.circularReveal(CalendarLayout, false, cx, cy, finalRadius);
               shouldShow = true;
           }
       }


       else if (i == R.id.imgPrevious) {
            selectedDate = DateFactory.getInstance().getPreviousDate(selectedDate, 1, "EEEE,MMMM dd,yyyy");
            tvDate.setText(selectedDate);
            fetchDailyLogAPI();

        } else if (i == R.id.imgNext) {
            selectedDate = DateFactory.getInstance().getNextDate(selectedDate, 1, "EEEE,MMMM dd,yyyy");
            tvDate.setText(selectedDate);
            fetchDailyLogAPI();

        } else if (i == R.id.tvAddmoreBreakfast) {
            if (isTodayDate()) {
                bundle.putString("trackMealType", "Breakfast");
                Utils.replaceFragment(getActivity().getFragmentManager(), TrackMealFragment.newInstance(bundle), TrackMealFragment.class.getSimpleName(), true, R.id.fragmentContainerMeal);
            }


        } else if (i == R.id.tvAddmoreLunch) {
            if (isTodayDate()) {
                bundle.putString("trackMealType", "Lunch");
                Utils.replaceFragment(getActivity().getFragmentManager(), TrackMealFragment.newInstance(bundle), TrackMealFragment.class.getSimpleName(), true, R.id.fragmentContainerMeal);
            }


        } else if (i == R.id.tvAddmoreSnacks) {
            if (isTodayDate()) {
                bundle.putString("trackMealType", "Snacks");
                Utils.replaceFragment(getActivity().getFragmentManager(), TrackMealFragment.newInstance(bundle), TrackMealFragment.class.getSimpleName(), true, R.id.fragmentContainerMeal);
            }

        } else if (i == R.id.tvAddmoreDinner) {
            if (isTodayDate()) {
                bundle.putString("trackMealType", "Dinner");
                Utils.replaceFragment(getActivity().getFragmentManager(), TrackMealFragment.newInstance(bundle), TrackMealFragment.class.getSimpleName(), true, R.id.fragmentContainerMeal);
            }

        } else if (i == R.id.tvAddmoreExercise) {
            if (isTodayDate()) {
                Utils.replaceFragment(getActivity().getFragmentManager(), TrackExerciseFragment.newInstance(null), TrackExerciseFragment.class.getSimpleName(), true, R.id.fragmentContainerMeal);
            }

        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        handler.removeCallbacks(runnable);
        ((MealActivity) getActivity()).getSupportActionBar().show();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        handler.removeCallbacks(runnable);
        ((MealActivity) getActivity()).getSupportActionBar().show();
    }

}

