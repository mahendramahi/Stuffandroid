package com.truworth.wellnesscorner.network;

import android.content.Context;

import com.truworth.wellnesscorner.utils.NetworkUtils;

import java.io.IOException;

import okhttp3.Interceptor;
import okhttp3.Request;
import okhttp3.Response;


public abstract  class ConnectivityInterceptor implements Interceptor {


//    private Context mContext;
//
//    public ConnectivityInterceptor(Context context) {
//        mContext = context;
//    }
//
//
//    @Override
//    public Response intercept(Chain chain) throws IOException {
//        if (!NetworkUtils.isOnline(mContext)) {
//            throw new NoConnectivityException();
//        }
//
//        Request.Builder builder = chain.request().newBuilder();
//        return chain.proceed(builder.build());
//    }
public abstract boolean isInternetAvailable();

    public abstract void onInternetUnavailable();

    @Override
    public Response intercept(Chain chain) throws IOException {
        Request request = chain.request();
        if (!isInternetAvailable()) {
            onInternetUnavailable();
        }
        return chain.proceed(request);
    }

}
