package com.twc.store.adapter;

import android.content.Context;
import android.support.v4.view.PagerAdapter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.twc.store.GlideConfig;

import com.twc.store.R;
import com.twc.store.model.beans.ProductItem;

import java.util.List;

import static com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions.withCrossFade;


public class WellnessPlansPagerAdapter extends PagerAdapter {
    private final List<ProductItem.ImagesBean> mImagesList;
    private final LayoutInflater mLayoutInflater;

    public WellnessPlansPagerAdapter(Context context, List<ProductItem.ImagesBean> imagesList) {
        this.mImagesList = imagesList;
        mLayoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return mImagesList.size();
    }

    @Override
    public Object instantiateItem(ViewGroup container, int position) {
        View itemView = mLayoutInflater.inflate(R.layout.row_plans_pager, container, false);

        ImageView ivCenterHra = itemView.findViewById(R.id.ivCenterHra);
        GlideConfig.getInstance().getImageLoader().load(mImagesList.get(position).getUrl()).transition(withCrossFade()).into(ivCenterHra);
        //ivCenterHra.setImageResource(mImagesList.get(position));


        container.addView(itemView);
        return itemView;
    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        container.removeView((LinearLayout) object);
    }

    @Override
    public boolean isViewFromObject(View view, Object object) {
        return view == object;
    }
}
