package com.truworth.wellnesscorner;

import android.app.Application;

import com.truworth.wellnesscorner.di.AppComponent;
import com.truworth.wellnesscorner.network.InternetConnectionListener;
import com.truworth.wellnesscorner.ui.step.StepServerResponse;
import com.twc.greendaolib.GreenDaoApp;

/**
 * Created by rajeshs on 3/26/2018.
 */

public class TheWellnessCornerApp extends Application {
    AppComponent appComponent;
    private static TheWellnessCornerApp app;
    private StepServerResponse stepServerResponse;

    public synchronized static TheWellnessCornerApp getInstance() {
        return app;
    }

    InternetConnectionListener mInternetConnectionListener;

    @Override
    public void onCreate() {
        super.onCreate();
        app = this;
        appComponent = AppComponent.component(this);
        appComponent.inject(this);
        GreenDaoApp.getInstance(this);
    }

    public AppComponent component() {
        return appComponent;
    }

    public static TheWellnessCornerApp getApp() {
        return app;
    }

    public StepServerResponse getStepServerResponse() {
        return stepServerResponse;
    }

    public void setStepServerResponse(StepServerResponse homeResponse) {
        this.stepServerResponse = homeResponse;
    }

    public void setInternetConnectionListener(InternetConnectionListener listener) {
        mInternetConnectionListener = listener;
    }

    public void removeInternetConnectionListener() {
        mInternetConnectionListener = null;
    }
    public InternetConnectionListener getInternetConnectionListener()
    {
        return mInternetConnectionListener;
    }
}
